open Hw7_data

let not_phone (e: event) : bool = 
  match e with 
  | Call(t, _) -> (match t with 
                  | Phone -> false 
                  | _ -> true)
  | _ -> true
;;

let assertions () = 
  assert (not_phone ex_zoom_doc = true);
  assert (not_phone ex_alone_reading = true);
  assert (not_phone ex_phone_spam = false);
  assert (not_phone ex_alone_lunch = true);
  assert (not_phone ex_mtg_advisor = true);
  assert (not_phone ex_mtg_study = true)
;;

