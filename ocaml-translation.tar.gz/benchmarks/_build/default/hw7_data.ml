(* Duration attendees description *)
type dur_att_desc = int * string list * string ;;

type call = 
  | Zoom 
  | Teams 
  | Phone
;;

type event = 
  | Call of call * dur_att_desc
  | Mtg of dur_att_desc
  | Alone of int * string
;;

let ex_zoom_doc = Call(Zoom, (22, ["Dr. Zoidberg"], "Doctor appointment"));;
let ex_teams_office = Call(Teams, (7, ["Mike"; "Tajel"], "Office hours"));;
let ex_phone_spam = Call(Phone, (1, ["Unknown"], "Spam"));;

let ex_mtg_study = Mtg(62, ["Rachel"; 
                            "Ross"; 
                            "Joey"; 
                            "Phoebe"; 
                            "Chandler"; 
                            "Monica"], "Study group");;
let ex_mtg_advisor = Mtg(28, ["Ali"], "Research meeting");;

let ex_alone_lunch = Alone(34, "lunch");;
let ex_alone_reading = Alone(25, "Reading Infinite Jest");;
