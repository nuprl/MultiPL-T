open Hw8_common
open ISL

(* Translating 1String to string. 1String is a string with length 1 *)
let is_avaliable_letter (l: letters) (k: string) : bool = match l with
    | Letters (center, rest) ->
        (string_equal center k) || (ormap (fun s -> string_equal s k) rest)

let assertions () =
    assert (is_avaliable_letter letters_1 "b" = true);
    assert (is_avaliable_letter letters_1 "a" = false); 
    assert (is_avaliable_letter letters_2 "e" = false); 