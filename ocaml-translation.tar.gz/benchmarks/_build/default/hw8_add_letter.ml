open Hw8_common
open ISL

(* Translating 1String to string. 1String is a string with length 1 *)
let add_letter (w: world) (c: string) = match w with
    |  World (letters, word_so_far, constructed_words, score) -> 
        World (letters, string_append word_so_far c, constructed_words, score)

let assertions () = 
    assert (add_letter init_world_1 "b" = World(letters_1, "b", [], 0));
    assert (add_letter (World(letters_1, "b", [], 0)) "e" = World(letters_1, "be", [], 0));
    assert (add_letter (World(letters_1, "be", [], 0)) "l" = World(letters_1, "bel", [], 0));
    assert (add_letter (World(letters_1, "bel", [], 0)) "l" = World(letters_1, "bell", [], 0));
