open Hw10_common
open ISL

let rec num_peeps (org : orgchart) : int = 
    let num_peeps_loo (loo: orgchart list) : int =
        foldr (fun (o: orgchart) (sum: int) -> (num_peeps o) + sum) 0 loo
    in
    match org with
    | Person (_, _, reports) -> 1 + (num_peeps_loo reports)
    | Group (_, members) -> num_peeps_loo members


let assertions () =
    assert (num_peeps (Group ("test", [])) = 0);
    assert (num_peeps org_provost = 5);
    assert (num_peeps org_cabinet = 7);
    assert (num_peeps org_nu = 8);