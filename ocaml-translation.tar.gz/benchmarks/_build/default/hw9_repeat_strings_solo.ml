open ISL

let repeat_strings_solo (n: int) (los: string list) = map (replicate n) los ;;

let assertions () =
  assert (repeat_strings_solo 3 [] = []);
  assert (repeat_strings_solo 0 ["a"; "b"; "c"] = [""; ""; ""]);
  assert (repeat_strings_solo 2 ["a"; "b"; "c"] = ["aa"; "bb"; "cc"]);
  assert (repeat_strings_solo 3 ["a"; "b"; "c"] = ["aaa"; "bbb"; "ccc"])
