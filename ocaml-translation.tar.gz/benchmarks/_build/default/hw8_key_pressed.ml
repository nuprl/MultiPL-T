open Hw8_common
open ISL

(* Copied from HW8 *)
let remove_letter (w: world) : world = match w with
    | World (_, "", _, _) -> w 
    | World (letters, word_so_far, constructed_words, score) ->
        World (letters,
               substring3 word_so_far 0 ((string_length word_so_far) - 1),
               constructed_words,
               score) 
;;

let is_word_in_list (w: string) (low: string list) : bool =
    ormap (fun l_w -> string_equal w l_w) low
;;

let is_valid_word (word: string) : bool = 
    ((string_length word) >= 4) && 
    (is_word_in_list word dictionary)
;;

let word_score (w: string) (l: letters): int = 
    let base_score = (string_length w) - 3 in
    let used_all_letters = andmap (fun letter -> string_contains letter w)
                                  (match l with
                                   | Letters (center, rest) -> center :: rest)
    in
    base_score + (if used_all_letters then 7 else 0)
;;

let try_word (w: world) : world = 
    match w with
    | World (Letters (center, rest), word_so_far, constructed_words, score) ->
        if ((string_contains center word_so_far) &&
            not (is_word_in_list word_so_far constructed_words) &&
            (is_valid_word word_so_far))
        then
            World (Letters(center, rest),
                   "",
                   append constructed_words [word_so_far],
                   (word_score word_so_far (Letters (center, rest))) + score) 
        else
            w
;;

let add_letter (w: world) (c: string) = match w with
    |  World (letters, word_so_far, constructed_words, score) -> 
        World (letters, string_append word_so_far c, constructed_words, score)

let is_avaliable_letter (l: letters) (k: string) : bool = match l with
    | Letters (center, rest) ->
        (string_equal center k) || (ormap (fun s -> string_equal s k) rest)


(* translating Key to string *)
let key_pressed (w: world) (k: string) : world = match w with
    | World (letters, _, _, _) ->
    if (is_avaliable_letter letters k) then 
        add_letter w k
    else if (string_equal k "\b") then
        remove_letter w
    else if (string_equal k "\r") then
        try_word w
    else
        w

let assertions () =
    assert (key_pressed init_world_1 "b" = World(letters_1, "b", [], 0));
    assert (key_pressed init_world_2 "\b" 
                = (match init_world_2 with
                    | World(letters, _, constructed_words, _) ->
                    World(letters, "bel", constructed_words, 0)));
    assert (key_pressed init_world_2 "\r" = init_world_3);
    assert (key_pressed init_world_3 "x" = init_world_3);