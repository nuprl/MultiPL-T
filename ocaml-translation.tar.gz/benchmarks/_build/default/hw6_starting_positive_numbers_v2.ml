open ISL
let rec take_while (pred: 'a -> bool) (l: 'a list) = match l with
    | [] -> []
    | first :: rest ->
        if not (pred first) then
            []
        else
            first :: (take_while pred rest)

let starting_positive_numbers_v2 (lon: int list) : int list =
    take_while is_positive lon

let assertions () =
    assert (starting_positive_numbers_v2 [] = []);
    assert (starting_positive_numbers_v2 [1; 2; 3; 4] = [1; 2; 3; 4]);
    assert (starting_positive_numbers_v2 [1; 2; 0; 4] = [1; 2]);
    assert (starting_positive_numbers_v2 [1; 2; 3; -4; 5] = [1; 2; 3]);