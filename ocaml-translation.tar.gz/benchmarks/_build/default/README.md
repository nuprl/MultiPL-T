```
dune build && ./_build/default/benchmarks.exe 
```