open ISL
open Hw7_data

let weekend (n: int): event list = build_list n (fun _ -> (Alone(30, "rest")));;

let assertions () = 
  assert (weekend 1 = [Alone(30, "rest")]);
  assert (weekend 3 = [Alone(30, "rest"); Alone(30, "rest"); Alone(30, "rest")])

