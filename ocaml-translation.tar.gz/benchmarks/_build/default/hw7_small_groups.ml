open ISL 
open Hw7_data

let is_small_list (lox: 'a list) : bool = (length lox) < 2;;
let is_small_group (e: event) : bool =
  match e with 
  | Call(_, (_, att, _)) -> is_small_list att
  | Mtg(_, att, _) -> is_small_list att
  | Alone(_, _) -> true
;;

let small_groups (events: event list) : event list = filter is_small_group events;;

let assertions () = 
  assert (small_groups [] = []);
  assert (small_groups [ex_zoom_doc; 
                        ex_teams_office; 
                        ex_phone_spam; 
                        ex_mtg_study; 
                        ex_mtg_advisor;
                        ex_alone_lunch;
                        ex_alone_reading] = 
        [ex_zoom_doc; 
        ex_phone_spam; 
        ex_mtg_advisor; 
        ex_alone_lunch; 
        ex_alone_reading])
