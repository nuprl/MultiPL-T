open Hw7_data

let participant_names (e: event) : string list = 
  match e with 
  | Call(_, (_, a, _)) -> a
  | Mtg(_, a, _) -> a
  | Alone(_, _) -> []
;;

let assertions () = 
  assert (participant_names ex_zoom_doc = ["Dr. Zoidberg"]);
  assert (participant_names ex_alone_reading = []);
  assert (participant_names ex_phone_spam = ["Unknown"]);
  assert (participant_names ex_alone_lunch = []);
  assert (participant_names ex_teams_office = ["Mike"; "Tajel"]);
  assert (participant_names ex_mtg_advisor = ["Ali"]);
  assert (participant_names ex_mtg_study = ["Rachel"; 
                            "Ross"; 
                            "Joey"; 
                            "Phoebe"; 
                            "Chandler"; 
                            "Monica"])
;;
