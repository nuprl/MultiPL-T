open ISL
open Hw7_data

let participant_names (e: event) : string list = 
  match e with 
  | Call(_, (_, a, _)) -> a
  | Mtg(_, a, _) -> a
  | Alone(_, _) -> []
;;

let event_names (loe: event list) : string list = foldl append [] (map participant_names loe);;

let peeps (loe: event list) : string list = 
  sort (event_names loe) string_lt_cmp
;;

let assertions () = 
  assert (peeps [] = []);
  assert (peeps [ex_teams_office] = ["Mike"; "Tajel"]);
  assert (peeps [ex_zoom_doc; 
                        ex_teams_office; 
                        ex_phone_spam; 
                        ex_mtg_study; 
                        ex_mtg_advisor;
                        ex_alone_lunch;
                        ex_alone_reading] = ["Ali"; 
                                             "Chandler"; 
                                             "Dr. Zoidberg"; 
                                             "Joey"; 
                                             "Mike"; 
                                             "Monica"; 
                                             "Phoebe"; 
                                             "Rachel"; 
                                             "Ross"; 
                                             "Tajel"; 
                                             "Unknown"])
;;
