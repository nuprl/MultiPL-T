open ISL

let hello (s: string) = string_append (string_append "Hello " s) "!"

let assertions () =
    assert (hello "Alice" = "Hello Alice!");
    assert (hello "Bob" = "Hello Bob!");