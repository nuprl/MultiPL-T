open ISL

let list_concat (lol : ('a list) list) : 'a list = 
  foldl append [] lol
;;

let assertions () = 
  assert (list_concat [] = []);
  assert (list_concat [[]] = []);
  assert (list_concat [[0]] = [0]);
  assert (list_concat [[0]; [0]] = [0; 0]);
  assert (list_concat [[1]] = [1]);
  assert (list_concat [[1]; [1]] = [1; 1]);
;;
