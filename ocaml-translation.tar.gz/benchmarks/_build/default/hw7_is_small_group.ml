open ISL
open Hw7_data

let is_small_list (lox: 'a list) : bool = (length lox) < 2;;
let is_small_group (e: event) : bool =
  match e with 
  | Call(_, (_, att, _)) -> is_small_list att
  | Mtg(_, att, _) -> is_small_list att
  | Alone(_, _) -> true
;;

let assertions () =
  assert (is_small_group ex_zoom_doc = true);
  assert (is_small_group ex_alone_reading = true);
  assert (is_small_group ex_alone_lunch = true);
  assert (is_small_group ex_phone_spam = true);
  assert (is_small_group ex_teams_office = false);
  assert (is_small_group ex_mtg_advisor = true);
  assert (is_small_group ex_mtg_study = false)
