(* The main library *)
let rec drop (lox : 'a list) (n : int) : 'a list = match (lox, n) with
  | ([], _) -> lox
  | (_, 0) -> lox
  | (_ :: xs, _) -> drop xs (n - 1)
;;

let rec dropWhile (pred : 'a -> bool) (lox : 'a list) : 'a list = 
  match lox with 
  | [] -> []
  | x :: xs -> if pred x then dropWhile pred xs else lox
;;

let rec take (lox : 'a list) (n : int) : 'a list = match (lox, n) with
  | ([], _) -> []
  | (_, 0) -> []
  | (x :: xs, _) -> x :: (take xs (n - 1))
;;

let rec takeWhile (pred : 'a -> bool) (lox : 'a list) : 'a list = 
  match lox with 
  | [] -> []
  | x :: xs -> if pred x then x :: takeWhile pred xs else []
;;

let rec map (f: 'a -> 'b) (lox: 'a list) : 'b list = match lox with 
  | [] -> []
  | x::xs -> (f x) :: (map f xs)
;;

(* Merge sort *)
let rec sort (lox: 'a list) (cmp : 'a -> 'a -> bool) = 
  let rec merge (l1: 'a list) (l2: 'a list) = 
    match (l1, l2) with 
    | (h1::t1, h2::t2) -> if cmp h1 h2 then h1 :: merge t1 l2 else h2 :: merge l1 t2
    | ([], _) -> l2
    | (_, []) -> l1
  in 
  (* Splits a list on even/odd indices *)
  let rec split (unsplit: 'a list) (next: 'a list) (prev: 'a list) = 
    match unsplit with 
    | [] -> (next, prev)
    | x :: xs -> split xs prev (x::next)
  in match lox with 
     | ([] | _::[]) -> lox
     | _ -> let (l, r) = split lox [] [] in merge (sort l cmp) (sort r cmp)
;;

let rec andmap (pred: 'a -> bool) (lox: 'a list) : bool = match lox with
  | [] -> true
  | x::xs -> if pred x then (andmap pred xs) else false
;;

let rec ormap (pred: 'a -> bool) (lox: 'a list) : bool = match lox with
  | [] -> false 
  | x::xs -> if pred x then true else (ormap pred xs)
;;

let rec filter (pred: 'a -> bool) (lox: 'a list) : 'a list = match lox with 
  | [] -> []
  | x :: xs -> if pred x then x :: (filter pred xs) else filter pred xs 
;;

let string_append (s1: string) (s2: string) : string = s1 ^ s2 ;;

let string_length (s: string) : int = String.length s;;

let string_equal (s1: string) (s2: string) : bool = String.equal s1 s2;;

let string_lt_cmp (s1: string) (s2: string) : bool = s1 <= s2;;

(* from https://stackoverflow.com/questions/8373460/substring-check-in-ocaml/30519110 *)
let string_contains (s: string) (t: string) : bool = 
  let re = Str.regexp_string s
    in
        try ignore (Str.search_forward re t 0); true
        with Not_found -> false
;; 

let substring3 (s: string) (i: int) (j: int) : string = 
  String.sub s i (j - i)
;;

let substring2 (s: string) (i: int) : string =
  substring3 s i (string_length s)
;;

(* Builds a string of n-copies of a string *)
let rec replicate (n: int) (s: string) : string = 
  if n <= 0 
    then ""
    else s ^ (replicate (n-1) s)
;;

let rec foldr (f: 'a -> 'b -> 'b) (acc: 'b) (lox: 'a list) = match lox with 
  | [] -> acc
  | x :: xs -> let rest = foldr f acc xs in f x rest
;;

let rec foldl (f: 'a -> 'b -> 'b) (acc: 'b) (lox: 'a list) = match lox with 
  | [] -> acc
  | x :: xs -> let nacc = f x acc in foldl f nacc xs
;;

let append (l1: 'a list) (l2: 'a list) = l1 @ l2 ;;

(* Fails if there is no associated key*)
let rec assoc (key: 'a) (alist: ('a * 'b) list) : 'b = match alist with
  | [] -> raise Not_found
  | (k, v) :: rest -> if k = key then v else (assoc key rest)
;;

let rec length (lox : 'a list) : int = match lox with 
  | [] -> 0
  | _ :: xs -> 1 + (length xs)
;;

let build_list (n: int) (f: int -> 'a) : 'a list= 
  let rec kern (k: int) (acc: 'a list) = 
    if k <= 0 then acc else kern (k-1) ((f n) :: acc)
  in kern n []
;;

let reverse (lox: 'a list) : 'a list =
  let rec kern rem acc = 
    match rem with 
    | [] -> acc 
    | (x :: xs) -> kern xs (x :: acc)
  in kern lox []
;;

let is_positive (n : int): bool = n > 0

let sqr (n : float) : float = n *. n

let sqrt = Float.sqrt

