let rec take (lox : 'a list) (n : int) : 'a list = match (lox, n) with
  | ([], _) -> []
  | (_, 0) -> []
  | (x :: xs, _) -> x :: (take xs (n - 1))

let assertions () = 
  assert (take [] 2 = []);
  assert (take [1; 2; 3] 1 = [1]);
  assert (take [1; 2; 3] 4 = [1; 2; 3])

