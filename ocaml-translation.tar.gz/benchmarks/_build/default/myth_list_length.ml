open ISL

let list_length (lox : 'a list) : int = 
  foldr (fun _ acc -> 1+ acc) 0 lox
;;

let assertions () = 
  assert (list_length [] = 0);
  assert (list_length [0] = 1);
  assert (list_length [0; 0] = 2);
;;
