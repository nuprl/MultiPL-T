open ISL

let string_length_float (s: string) : float = 
    (float_of_int (string_length s))

let string_half_length (s: string) : float = 
    (string_length_float s) /. 2.

let rec double_do_it (f: 'a -> 'b) (g: 'a -> 'b) (l: 'a list) : 'b list = match l with
    | [] -> []
    | first :: rest -> 
        (f first) :: (g first) :: (double_do_it f g rest)

let string_length_length (l: string list) : float list =
    double_do_it string_length_float string_half_length l
    

let assertions () = 
    assert (string_length_length [] = []);
    assert (string_length_length ["Hello"] = [5.; 2.5]);