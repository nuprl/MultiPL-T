
let _ = 
  Myth_list_append.assertions ();
  Myth_list_compress.assertions ();
  Myth_list_concat.assertions ();
  Myth_list_length.assertions ();
  Myth_list_rev.assertions ();
  Myth_list_stutter.assertions ();
