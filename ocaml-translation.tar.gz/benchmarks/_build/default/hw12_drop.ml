let rec drop (lox : 'a list) (n : int) : 'a list = match (lox, n) with
  | ([], _) -> lox
  | (_, 0) -> lox
  | (_ :: xs, _) -> drop xs (n - 1)

let assertions () =
  assert (drop [] 2 = []);
  assert (drop [1; 2; 3] 1 = [2; 3]);
  assert (drop [1; 2; 3] 4 = [])
