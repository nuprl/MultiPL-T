open ISL

let rec take_while (pred: 'a -> bool) (l: 'a list) = match l with
    | [] -> []
    | first :: rest ->
        if not (pred first) then
            []
        else
            first :: (take_while pred rest)

let assertions () =
    (* The original test uses string? which OCaml can't implement since it doesn't support type inspection. *)
    assert (take_while (fun _ -> true) [] = []);
    assert (take_while is_positive [10; -10] = [10]);