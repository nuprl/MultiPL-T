(* take_drop splits the list into two, first of length n, followed by the
   remaining items. *)
let rec take_drop (n : int) (alist : 'a list) : 'a list * 'a list = match n with
  | 0 -> ([], alist)
  | _ -> match alist with
    | [] -> ([], [])
    | x :: xs -> 
      let rec_result = take_drop (n - 1) xs in
      match rec_result with
        | (ys1, ys2) -> (x :: ys1, ys2)
  
  let assertions () =
    assert (take_drop 1 [1; 2; 3] = ([1], [2; 3]));
    assert (take_drop 3 [1; 2; 3] = ([1; 2; 3], []))