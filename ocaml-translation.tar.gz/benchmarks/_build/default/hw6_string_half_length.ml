open ISL

let string_half_length (s: string) : float = 
    (float_of_int (string_length s)) /. 2.

let assertions () = 
    assert (string_half_length "Hello" = 2.5);
    assert (string_half_length "" = 0.);
