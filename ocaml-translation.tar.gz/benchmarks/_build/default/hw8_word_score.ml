open Hw8_common
open ISL

let word_score (w: string) (l: letters): int = 
    let base_score = (string_length w) - 3
    and used_all_letters = andmap (fun letter -> string_contains letter w)
                                  (match l with
                                   | Letters (center, rest) -> center :: rest)
    in base_score + (if used_all_letters then 7 else 0)

let assertions () =
    assert (word_score "bell" letters_1 = 1);
    assert (word_score "wowee" letters_1 = 2);
    assert (word_score "elbow" letters_1 = 9);


