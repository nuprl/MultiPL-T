open ISL 
open Hw7_data

let has_lunch (s: string) : bool = string_contains "lunch" s ;; 

let is_lunch (e: event) : bool = 
  match e with
  | Call(_, (_, _, desc)) -> has_lunch desc
  | Mtg(_, _, desc) -> has_lunch desc
  | Alone(_, desc) -> has_lunch desc
;;

let assertions () = 
  assert (is_lunch ex_zoom_doc = false);
  assert (is_lunch ex_alone_lunch = true);
  assert (is_lunch (Call(Zoom, (20, ["Mom"], "virtual lunch"))) = true);
  assert (is_lunch (Mtg(20, ["Alice"; "Bob"], "group lunch")) = true)
