open ISL
open Hw7_data

let not_phone (e: event) : bool = 
  match e with 
  | Call(t, _) -> (match t with 
                  | Phone -> false 
                  | _ -> true)
  | _ -> true
;;

let anything_but_phone (loe: event list) : bool = andmap not_phone loe;; 

let assertions () = 
  assert (anything_but_phone [] = true);

  assert (anything_but_phone [ex_zoom_doc; 
                        ex_teams_office; 
                        ex_phone_spam; 
                        ex_mtg_study; 
                        ex_mtg_advisor;
                        ex_alone_lunch;
                        ex_alone_reading] = false);

  assert (anything_but_phone [ex_zoom_doc; 
                              ex_alone_reading; 
                              ex_alone_lunch; 
                              ex_teams_office;
                              ex_mtg_advisor] = true)
;;

