open ISL

let list_stutter (lox : 'a list) : 'a list = 
  foldr (fun x acc -> x :: (x:: acc) ) [] lox 
;;

let assertions () = 
  assert (list_stutter [] = []);
  assert (list_stutter [0] = [0;0]);
  assert (list_stutter [1;0] = [1;1;0;0]);
;;

