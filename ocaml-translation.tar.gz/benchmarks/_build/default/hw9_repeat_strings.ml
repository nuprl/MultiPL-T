open ISL

let rec repeat_strings (ls: string list) (ln: int list) : (string list) = 
  match ls with 
  | [] -> (match ln with 
          | [] -> []
          | hn :: tn -> (replicate hn "!") :: (repeat_strings [] tn))
  | hs :: ts -> (match ln with 
                | [] -> (replicate 2 hs) :: (repeat_strings ts [])
                | hn :: tn -> (replicate hn hs) :: (repeat_strings ts tn))
;;

let assertions () = 
  assert (repeat_strings [] [] = []);
  assert (repeat_strings ["a"; "b"; "c"] [1; 2; 3] = ["a"; "bb"; "ccc"]);
  assert (repeat_strings ["xx"; "yy"] [2; 0] = ["xxxx"; ""]);
  assert (repeat_strings ["xx"; "yy"; "zz"] [0] = [""; "yyyy"; "zzzz"]);
  assert (repeat_strings ["x"] [2; 3; 4] = ["xx"; "!!!"; "!!!!"])
