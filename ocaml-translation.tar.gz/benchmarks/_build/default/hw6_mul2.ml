let mul2 (n: int) : int = 2 * n

let assertions () = 
    assert (mul2 10 = 20);
    assert (mul2 (-10) = (-20));