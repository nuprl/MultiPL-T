open Hw7_data

let social_event_time (e : event) : int = 
  match e with 
  | Call(_, (t, _, _)) -> t
  | Mtg (t, _, _) -> t
  | Alone(_) -> 0
;;

let assertions () = 
  assert (social_event_time ex_zoom_doc = 22);
  assert (social_event_time ex_alone_reading = 0);
  assert (social_event_time ex_phone_spam = 1);
  assert (social_event_time ex_alone_lunch = 0);
  assert (social_event_time ex_teams_office = 7);
  assert (social_event_time ex_mtg_advisor = 28);
  assert (social_event_time ex_mtg_study = 62)

