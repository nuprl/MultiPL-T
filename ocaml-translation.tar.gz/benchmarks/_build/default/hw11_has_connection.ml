open ISL 
open Hw11_data

let has_connection (str: string) (stat: station) : bool = 
  let Station(_, connections) = stat 
    in ormap (fun t -> string_equal t str) connections
;;

let assertions () = 
  assert (has_connection "Fenway" ex_station_1 = true);
  assert (has_connection "Mass Ave" ex_station_1 = false);
  assert (has_connection "Newton Centre" ex_station_2 = true);
  assert (has_connection "Ruggles" ex_station_2 = false)
;;
