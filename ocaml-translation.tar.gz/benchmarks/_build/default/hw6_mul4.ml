let mul4 (n: int) : int = 4 * n

let assertions () = 
    assert (mul4 10 = 40);
    assert (mul4 (-10) = (-40));