open ISL

let hello (s: string) = string_append (string_append "Hello " s) "!"

let goodbye (s: string) = string_append (string_append "Goodbye " s) "!"

let rec double_do_it (f: 'a -> 'b) (g: 'a -> 'b) (l: 'a list) : 'b list = match l with
    | [] -> []
    | first :: rest -> 
        (f first) :: (g first) :: (double_do_it f g rest)

let hello_goodbye (l: string list) : string list = 
    double_do_it hello goodbye l

let assertions () = 
    assert (hello_goodbye [] = []);
    assert (hello_goodbye ["Alice"; "Bob"] = ["Hello Alice!"; "Goodbye Alice!"; "Hello Bob!"; "Goodbye Bob!"]);