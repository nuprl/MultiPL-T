open Hw8_common
open ISL

let remove_letter (w: world) : world = match w with
    | World (_, "", _, _) -> w 
    | World (letters, word_so_far, constructed_words, score) ->
        World (letters,
               substring3 word_so_far 0 ((string_length word_so_far) - 1),
               constructed_words,
               score) 
;;

(* remove_letter doesn't have any tests, the test are author's own *)
let assertions () = 
    assert (remove_letter (World(letters_1, "", [], 0)) = World(letters_1, "", [], 0));
    assert (remove_letter (World(letters_1, "abc", [], 0)) = World(letters_1, "ab", [], 0));