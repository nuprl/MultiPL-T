(* person [name title reports] *)
(* group [name members] *)

type orgchart =
    | Person of string * string * orgchart list
    | Group of string * orgchart list

let org_provost = 
    Person ("David Madigan",
            "Provost and Senior Vice President for Academic Affairs",
            [
                Group ("Administration",
                    [
                        Person ("Thomas Sheahan",
                                "Senior Vice Provost, Curriculum and Programs",
                                [])
                    ]);
                Group ("Academic Deans",
                    [
                        Person ("Alan Mislove",
                                "Interim Dean, Khoury College of Computer Sciences",
                                []);
                        Person ("Carmen Sceppa",
                                "Dean, Bouvé College of Health Sciences",
                                []);
                        Person ("Uta G. Poiger",
                                "Dean, College of Social Sciences & Humanities",
                                []);
                    ])
            ])

let org_cabinet = 
    Group ("Cabinet",
            [
                Person ("Karl Reid",
                        "Senior Vice Provost and Inclusion Officer",
                        []);
                Person ("Madeleine Estabrook",
                        "Senior Advisor for Global Student Experience",
                        []);
                org_provost
            ])

let org_nu = 
    Person ("Joseph E. Aoun", "President", [org_cabinet])