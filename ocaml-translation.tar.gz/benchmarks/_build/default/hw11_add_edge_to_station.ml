open ISL
open Hw11_data

let has_connection (str: string) (stat: station) : bool = 
  let Station(_, connections) = stat 
    in ormap (fun t -> string_equal t str) connections
;;

let add_edge_to_station (str: string) (stat: station) : station = 
    if (has_connection str stat) 
    then stat 
    else 
      let Station(name, connections) = stat in Station(name, str::connections)
;;

(* Probably needs more tests to even give the synthesizer a chance *)
let assertions () = 
  assert (add_edge_to_station "Fenway" ex_station_1 = ex_station_1)
;;
