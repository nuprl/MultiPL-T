open ISL

let rec double_do_it (f: 'a -> 'b) (g: 'a -> 'b) (l: 'a list) : 'b list = match l with
    | [] -> []
    | first :: rest -> 
        (f first) :: (g first) :: (double_do_it f g rest)

let assertions () = 
    assert (double_do_it sqr sqrt [] = []);
    assert (double_do_it sqr sqrt [25.; 9.] = [625.; 5.; 81.; 3.]);