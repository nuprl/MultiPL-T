(* Letters (center, rest) *)
type letters = Letters of string * (string list)

let letters_1 = Letters ("l", ["o"; "e"; "b"; "w"])
let letters_2 = Letters ("z", ["x"; "w"; "q"; "y"])
let letters_3 = Letters ("c", ["d"; "o"; "n"; "e"; "y"; "v"])
let letters_4 = Letters ("a", [])

(* World (letters, word_so_far, constructed_words, score) *)
type world = World of letters * string * (string list) * int

let init_world_1 = World (letters_1, "", [], 0)
let init_world_2 = World (letters_1, "bell", [], 0)
let init_world_3 = World (letters_1, "", ["bell"], 1)

(* Using LITTLE_DICTIONARY instead, with the words in the test added *)
let dictionary = ["explain"; "plain"; "nail"; "lap"; "bell"; "bob"]

