open ISL
open Hw8_common

(* Copied from HW8 *)
let is_word_in_list (w: string) (low: string list) : bool =
    ormap (fun l_w -> string_equal w l_w) low
;;

let is_valid_word (word: string) : bool = 
    ((string_length word) >= 4) && 
    (is_word_in_list word dictionary)
;;

let assertions () = 
    assert (is_valid_word "bell" = true);
    assert (is_valid_word "bob" = false);
    assert (is_valid_word "bobo" = false);