let rec average_lists (l1: float list) (l2: float list) : float list = 
  match l1 with 
  | [] -> []
  | hl :: tl -> (match l2 with 
                | [] -> []
                | hr :: tr -> (hl +. hr) /. 2. :: (average_lists tl tr))
;;

let assertions () = 
  assert (average_lists [] [] = []);
  assert (average_lists [1.0; 2.0; 3.0] [4.0; 5.0; 6.0] = [2.5; 3.5; 4.5]);
