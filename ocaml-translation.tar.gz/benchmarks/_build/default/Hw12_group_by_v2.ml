(* take_drop splits the list into two, first of length n, followed by the
   remaining items.
   
   This function is copied from HW12.
  *)
   let rec take_drop (n : int) (alist : 'a list) : 'a list * 'a list = match n with
   | 0 -> ([], alist)
   | _ -> match alist with
     | [] -> ([], [])
     | x :: xs -> 
       let rec_result = take_drop (n - 1) xs in
       match rec_result with
         | (ys1, ys2) -> (x :: ys1, ys2)

let rec group_by (alist : 'a list) (group_size : int) : 'a list list = match alist with
  | [] -> []
  | _ -> match take_drop group_size alist with
    | (group_1, rest) -> group_1 :: group_by rest group_size

let assertions () = 
  assert (group_by [] 2 = []);
  assert (group_by [1; 2; 3] 1 = [[1]; [2]; [3]]);
  assert (group_by [1; 2; 3] 2 = [[1; 2]; [3]])