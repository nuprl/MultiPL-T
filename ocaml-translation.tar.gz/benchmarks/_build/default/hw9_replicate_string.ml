open ISL 

let rec replicate (n: int) (s: string) : string = 
  match n with 
  | 0 -> ""
  | _ -> string_append s (replicate (n-1) s)
;;

let assertions () = 
  assert (replicate 0 "a" = "");
  assert (replicate 0 "b" = "");
  assert (replicate 0 "c" = "");
  assert (replicate 1 "a" = "a");
  assert (replicate 1 "b" = "b");
  assert (replicate 1 "c" = "c");
  assert (replicate 2 "a" = "aa");
  assert (replicate 2 "b" = "bb");
  assert (replicate 2 "c" = "cc");
  assert (replicate 3 "a" = "aaa");
  assert (replicate 3 "b" = "bbb");
  assert (replicate 3 "c" = "ccc")
