open ISL

let rec take_while (pred: 'a -> bool) (l: 'a list) = match l with
    | [] -> []
    | first :: rest ->
        if not (pred first) then
            []
        else
            first :: (take_while pred rest)

let not_period (s: string): bool =
   not (string_equal s ".")

let words_until_period_v2 (los: string list) : string list = 
    take_while not_period los

let assertions () = 
    assert (words_until_period_v2 [] = []);
    assert (words_until_period_v2 ["Hello"; "World"] = ["Hello"; "World"]);
    assert (words_until_period_v2 ["Hello"; "World"; "."] = ["Hello"; "World"]);
    assert (words_until_period_v2 ["Hello"; "World"; "."; "!"] = ["Hello"; "World"]);