
let _ =
  Hw6_hello_everyone.assertions ();
  Hw6_words_until_period.assertions ();
  Hw6_words_until_period_v2.assertions ();
  Hw6_starting_positive_numbers.assertions ();
  Hw6_starting_positive_numbers_v2.assertions ();
  Hw6_take_while.assertions ();
  Hw6_not_period.assertions ();
  Hw6_double_do_it.assertions ();
  Hw6_hello.assertions ();
  Hw6_goodbye.assertions ();
  Hw6_hello_goodbye.assertions ();
  Hw6_mul2.assertions ();
  Hw6_mul4.assertions ();
  Hw6_double_double.assertions ();
  Hw6_string_half_length.assertions ();
  Hw6_string_length_length.assertions ();

  Hw7_is_lunch.assertions ();
  Hw7_has_lunch.assertions ();
  Hw7_had_lunch.assertions ();
  Hw7_is_small_list.assertions ();
  Hw7_is_small_group.assertions ();
  Hw7_small_groups.assertions ();
  Hw7_weekends.assertions ();
  Hw7_social_event_time.assertions ();
  Hw7_social_time.assertions ();
  Hw7_anything_but_phone.assertions ();
  Hw7_not_phone.assertions ();
  Hw7_participant_names.assertions ();
  Hw7_event_names.assertions ();
  Hw7_peeps.assertions ();

  Hw8_remove_letter.assertions ();
  Hw8_word_in_list.assertions ();
  Hw8_valid_word.assertions ();
  Hw8_word_score.assertions ();
  Hw8_try_word.assertions ();
  Hw8_add_letter.assertions ();
  Hw8_avaliable_letter.assertions ();
  Hw8_key_pressed.assertions ();

  Hw9_replicate_string.assertions ();
  Hw9_repeat_strings.assertions ();
  Hw9_repeat_strings_solo.assertions ();
  Hw9_average_list.assertions ();
  Hw9_student_grades.assertions ();

  Hw10_num_peeps.assertions ();
  Hw10_full_title.assertions ();

  Hw11_has_connection.assertions ();
  Hw11_add_edge_to_station.assertions ();
  Hw11_add_edge.assertions();

  Hw12_drop.assertions ();
  Hw12_take.assertions ();
  Hw12_group_by_v1.assertions ();
  Hw12_take_drop.assertions ();
  Hw12_group_by_v2.assertions ();

  Myth_list_append.assertions ();
  Myth_list_compress.assertions ();
  Myth_list_concat.assertions ();
  Myth_list_length.assertions ();
  Myth_list_rev.assertions ();
  Myth_list_stutter.assertions ();
