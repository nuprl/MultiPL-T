let rec words_until_period (los: string list) : string list = match los with
    | [] -> []
    | "." :: _ -> []
    | first :: rest -> (first :: words_until_period rest)

let assertions () = 
    assert (words_until_period [] = []);
    assert (words_until_period ["Hello"; "World"] = ["Hello"; "World"]);
    assert (words_until_period ["Hello"; "World"; "."] = ["Hello"; "World"]);
    assert (words_until_period ["Hello"; "World"; "."; "!"] = ["Hello"; "World"]);