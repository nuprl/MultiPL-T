open ISL

let list_rev (lox: 'a list) : 'a list = 
  foldl (fun x acc -> x :: acc) [] lox
;;

let assertions () = 
  assert (list_rev [] = []);
  assert (list_rev [0] = [0]);
  assert (list_rev [1] = [1]);
  assert (list_rev [0;1] = [1;0]);
  assert (list_rev [0;0;1] = [1;0;0]);
;;
