open ISL

let goodbye (s: string) = string_append (string_append "Goodbye " s) "!"

let assertions () =
    assert (goodbye "Alice" = "Goodbye Alice!");
    assert (goodbye "Bob" = "Goodbye Bob!");