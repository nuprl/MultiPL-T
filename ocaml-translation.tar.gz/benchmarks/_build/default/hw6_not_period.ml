open ISL

let not_period (s: string): bool =
   not (string_equal s ".")

let assertions () = 
    assert (not_period "x" = true);
    assert (not_period "A" = true);
    assert (not_period "." = false);
    assert (not_period "," = true);