let mul2 (n: int) : int = 2 * n

let mul4 (n: int) : int = 4 * n

let rec double_do_it (f: 'a -> 'b) (g: 'a -> 'b) (l: 'a list) : 'b list = match l with
    | [] -> []
    | first :: rest -> 
        (f first) :: (g first) :: (double_do_it f g rest)

let double_double (l : int list) : int list =
    double_do_it mul2 mul4 l

let assertions () = 
    assert (double_double [] = []);
    assert (double_double [10; 20] = [20; 40; 40; 80])