open ISL

let is_word_in_list (w: string) (low: string list) : bool =
    ormap (fun l_w -> string_equal w l_w) low
;;

let assertions () = 
    assert (is_word_in_list "a" [] = false);
    assert (is_word_in_list "a" ["a"; "b"; "c"] = true);
    assert (is_word_in_list "a" ["b"; "c"] = false);