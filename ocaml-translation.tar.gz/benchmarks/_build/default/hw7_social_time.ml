open ISL
open Hw7_data

let social_event_time (e : event) : int = 
  match e with 
  | Call(_, (t, _, _)) -> t
  | Mtg (t, _, _) -> t
  | Alone(_) -> 0
;;

let social_time (events: event list) : int = foldr (+) 0 (map social_event_time events);;

let assertions () = 
  assert (social_time [] = 0);
  assert (social_time [ex_zoom_doc; 
                        ex_teams_office; 
                        ex_phone_spam; 
                        ex_mtg_study; 
                        ex_mtg_advisor;
                        ex_alone_lunch;
                        ex_alone_reading] = 120)
