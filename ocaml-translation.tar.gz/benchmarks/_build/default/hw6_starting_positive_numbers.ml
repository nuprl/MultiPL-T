let rec starting_positive_numbers (lon: int list) : int list = match lon with
    | [] -> []
    | first :: rest ->
        if (first <= 0) then
            []
        else
            first :: (starting_positive_numbers rest)

let assertions () =
    assert (starting_positive_numbers [] = []);
    assert (starting_positive_numbers [1; 2; 3; 4] = [1; 2; 3; 4]);
    assert (starting_positive_numbers [1; 2; 0; 4] = [1; 2]);
    assert (starting_positive_numbers [1; 2; 3; -4; 5] = [1; 2; 3]);