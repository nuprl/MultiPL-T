open ISL
open Hw8_common

(* Copied from HW8 *)
let is_word_in_list (w: string) (low: string list) : bool =
    ormap (fun l_w -> string_equal w l_w) low
;;

let is_valid_word (word: string) : bool = 
    ((string_length word) >= 4) && 
    (is_word_in_list word dictionary)
;;

let word_score (w: string) (l: letters): int = 
    let base_score = (string_length w) - 3 in
    let used_all_letters = andmap (fun letter -> string_contains letter w)
                                  (match l with
                                   | Letters (center, rest) -> center :: rest)
    in
    base_score + (if used_all_letters then 7 else 0)
;;

let try_word (w: world) : world = 
    match w with
    | World (Letters (center, rest), word_so_far, constructed_words, score) ->
        if ((string_contains center word_so_far) &&
            not (is_word_in_list word_so_far constructed_words) &&
            (is_valid_word word_so_far))
        then
            World (Letters(center, rest),
                   "",
                   append constructed_words [word_so_far],
                   (word_score word_so_far (Letters (center, rest))) + score) 
        else
            w
;;

let assertions () =
    assert (try_word init_world_1 = init_world_1);
    assert (try_word (World(letters_1,"b",[],0)) = World(letters_1,"b",[],0));
    assert (try_word (World(letters_1,"bell",["bell"],1)) = World(letters_1,"bell",["bell"],1));
    assert (try_word (World(letters_1,"ebow",[],0)) = World(letters_1,"ebow",[],0));
    assert (try_word (World(letters_1,"wellbow",[],0)) = World(letters_1,"wellbow",[],0));
    assert (try_word init_world_2 = init_world_3);

    