open ISL 

let rec list_compress (lox : 'a list) : 'a list = 
  match lox with 
  | [] -> []
  | x :: xs -> x :: list_compress (dropWhile (fun y -> y = x) xs)
;;

let assertions () = 
  assert (list_compress [] = []);
  assert (list_compress [0] = [0]);
  assert (list_compress [1] = [1]);
  assert (list_compress [0; 0] = [0]);
  assert (list_compress [1; 1] = [1]);
  assert (list_compress [2; 0] = [2; 0]);
  assert (list_compress [1; 0; 0] = [1; 0]);
  assert (list_compress [0; 1; 1] = [0; 1]);
  assert (list_compress [2; 1; 0; 0] = [2; 1; 0]);
  assert (list_compress [2; 2; 1; 0; 0] = [2; 1; 0]);
  assert (list_compress [2; 2; 0] = [2; 0]);
  assert (list_compress [2; 2; 2; 0] = [2; 0]);
  assert (list_compress [1; 2; 2; 2; 0] = [1; 2; 0]);
;;
