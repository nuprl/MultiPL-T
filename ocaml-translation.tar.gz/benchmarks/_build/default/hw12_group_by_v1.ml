let group_by (alist : 'a list) (group_size : int) : 'a list list =
  let rec helper (this_group_size : int) (alist : 'a list) : 'a list list =
    match alist with
      | [] -> []
      | (x :: xs) -> match this_group_size with
        | 0 -> [] :: helper group_size alist
        | _ -> let rec_result = helper (this_group_size - 1) xs in
          match rec_result with
            | [] -> [x :: []]
            | (y :: ys) -> (x :: y) :: ys
  in helper group_size alist

  let assertions () = 
  assert (group_by [] 2 = []);
  assert (group_by [1; 2; 3] 1 = [[1]; [2]; [3]]);
  assert (group_by [1; 2; 3] 2 = [[1; 2]; [3]])