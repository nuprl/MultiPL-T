open ISL

let list_append (l1: 'a list) (l2: 'a list) : 'a list =
  foldr (fun x acc -> x :: acc) l2 l1
;;

let assertions () = 
  assert (list_append [] [] = []);
  assert (list_append [] [0] = [0]);
  assert (list_append [] [1] = [1]);
  assert (list_append [0] [] = [0]);
  assert (list_append [0] [0] = [0; 0]);
  assert (list_append [0] [1] = [0; 1]);
  assert (list_append [1] [] = [1]);
  assert (list_append [1] [0] = [1; 0]);
  assert (list_append [1] [1] = [1; 1]);
  assert (list_append [0;0] [] = [0;0]);
  assert (list_append [0;0] [0] = [0;0;0]);
  assert (list_append [0;0] [1] = [0;0;1]);
;;
