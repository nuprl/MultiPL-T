open Hw10_common
open ISL

let rec full_title (org: orgchart) (name: string) =
    let
        f = fun (o: orgchart) -> full_title o name
    in
    match org with
    | Person (pname, title, reports) ->
        Person (pname, 
                string_append title (string_append " (" (string_append name ")")),
                map f reports)
    | Group (gname, members) ->
        Group (gname,
               map f members)

let assertions () = 
    assert (full_title org_nu "Northeastern University" = 
            Person ("Joseph E. Aoun", "President (Northeastern University)", [
                Group ("Cabinet",
                [
                    Person ("Karl Reid",
                            "Senior Vice Provost and Inclusion Officer (Northeastern University)",
                            []);
                    Person ("Madeleine Estabrook",
                            "Senior Advisor for Global Student Experience (Northeastern University)",
                            []);
                            Person ("David Madigan",
                                    "Provost and Senior Vice President for Academic Affairs (Northeastern University)",
                                    [
                                        Group ("Administration",
                                            [
                                                Person ("Thomas Sheahan",
                                                        "Senior Vice Provost, Curriculum and Programs (Northeastern University)",
                                                        [])
                                            ]);
                                        Group ("Academic Deans",
                                            [
                                                Person ("Alan Mislove",
                                                        "Interim Dean, Khoury College of Computer Sciences (Northeastern University)",
                                                        []);
                                                Person ("Carmen Sceppa",
                                                        "Dean, Bouvé College of Health Sciences (Northeastern University)",
                                                        []);
                                                Person ("Uta G. Poiger",
                                                        "Dean, College of Social Sciences & Humanities (Northeastern University)",
                                                        []);
                                            ])
                                    ])
                ])
            ]))