
type station = 
  | Station of string * (string list) 

let ex_station_1 = Station("Newton Centre", ["Fenway"; "Kenmore"]) ;;
let ex_station_2 = Station("Fenway", ["Newton Highlands"; "Newton Centre"]);; 
let ex_station_3 = Station("Kenmore", ["Newton Centre"]);;
let ex_station_4 = Station("Newton Highlands", ["Fenway"]);;

let ex_subway_1 = [ex_station_1; ex_station_2; ex_station_3; ex_station_4];;
let ex_subway_2 = [];;
let ex_subway_3 = [
  Station("A", ["B"; "D"]);
  Station("B", ["C"; "A"]);
  Station("C", ["D"; "B"]);
  Station("D", ["A"; "C"]);
];;

