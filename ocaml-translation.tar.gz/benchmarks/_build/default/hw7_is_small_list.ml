open ISL

let is_small_list (lox: 'a list) : bool = (length lox) < 2;;

let assertions () = 
  assert (is_small_list [] = true);
  assert (is_small_list ["a"] = true);
  assert (is_small_list ["a"; "b"] = false);
  assert (is_small_list ["a"; "b"; "c";] = false);
  assert (is_small_list ["a"; "b"; "c"; "d"] = false)
