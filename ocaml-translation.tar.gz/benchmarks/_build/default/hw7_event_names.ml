open ISL
open Hw7_data

let participant_names (e: event) : string list = 
  match e with 
  | Call(_, (_, a, _)) -> a
  | Mtg(_, a, _) -> a
  | Alone(_, _) -> []
;;

let event_names (loe: event list) : string list = foldl append [] (map participant_names loe);;

let assertions () = 
  assert (event_names [] = []);
  assert (event_names [ex_teams_office] = ["Mike"; "Tajel"]);
  assert (event_names [ex_zoom_doc; 
                        ex_teams_office; 
                        ex_phone_spam; 
                        ex_mtg_study; 
                        ex_mtg_advisor;
                        ex_alone_lunch;
                        ex_alone_reading] = 
                          ["Ali";"Rachel";
                           "Ross";
                           "Joey";
                           "Phoebe";
                           "Chandler";
                           "Monica";
                           "Unknown";
                           "Mike"; 
                           "Tajel"; "Dr. Zoidberg"])
;;
