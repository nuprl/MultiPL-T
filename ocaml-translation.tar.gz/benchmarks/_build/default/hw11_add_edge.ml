open ISL
open Hw11_data

let has_connection (str: string) (stat: station) : bool = 
  let Station(_, connections) = stat 
    in ormap (fun t -> string_equal t str) connections
;;

let add_edge_to_station (str: string) (stat: station) : station = 
    if (has_connection str stat) 
    then stat 
    else 
      let Station(name, connections) = stat in Station(name, str::connections)
;;

let rec add_edge (from: string) (towards: string) (sub: station list) : station list = 
  match sub with 
  | [] -> sub 
  | x::xs -> let Station(name, _) = x 
             in if string_equal from name 
                then (add_edge_to_station towards x) :: xs
                else x :: (add_edge from towards xs)
;;

let assertions () = 
  assert (add_edge "Fenway" "Kenmore" ex_subway_2 = ex_subway_2);
  assert (add_edge "Fenway" "Kenmore" ex_subway_1 = [ 
    ex_station_1;
    Station("Fenway", ["Kenmore"; "Newton Highlands"; "Newton Centre"]);
    ex_station_3;
    ex_station_4;
  ]);
  assert (add_edge "Kenmore" "Newton Centre" ex_subway_1 = ex_subway_1);
  assert (add_edge "A" "C" ex_subway_3 = [ 
    Station("A", ["C"; "B"; "D"]);
    Station("B", ["C"; "A"]);
    Station("C", ["D"; "B"]);
    Station("D", ["A"; "C"])
  ])
;;

 



