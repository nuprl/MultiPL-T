open ISL 

let has_lunch (s: string) : bool = string_contains "lunch" s ;; 

let assertions () = 
  assert (has_lunch "" = false);
  assert (has_lunch "doctor appointment" = false);
  assert (has_lunch "lunch" = true);
  assert (has_lunch "virtual lunch" = true);
  assert (has_lunch "group lunch" = true)
