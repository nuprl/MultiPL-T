let rec hello_everyone (los: string list) : string list = 
    match los with
    | [] -> []
    | hl :: tl -> ("Hello, " ^ hl ^ "!") :: (hello_everyone tl)
;;

let assertions () = 
    assert (hello_everyone [] = []);
    assert (hello_everyone ["Arjun"; "Donald"] = ["Hello, Arjun!"; "Hello, Donald!"]);
    assert (hello_everyone ["Arjun"; "Donald"; "Barry"] = ["Hello, Arjun!"; "Hello, Donald!"; "Hello, Barry!"]);