#!/bin/bash

set -e

echo "Running the master / solution file ..."
racket hw12-master.rkt
python3 ../../Homeworks/split_master.py hw12-master.rkt
echo "Running the starter file ..."
racket hw12-problem1.rkt


