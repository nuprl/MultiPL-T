import os
import sys
import re
import subprocess
import concurrent.futures

FLAG_RE = re.compile('\((append|map|filter|reverse)')
DEFINE_STRUCT_RE = re.compile('\(define-struct')
FILENAME_RE = re.compile('assignment_(\d+)/(\d+)')
RUN_OUTPUT_RE = re.compile('^All \d+ tests passed!\n')


# List all .rkt files in subdirectories of the path.
def list_dirs(path):
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith(".rkt"):
                yield os.path.join(root, file)

def analyze(rkt_file):
    filename_m = FILENAME_RE.match(rkt_file)
    url = f'https://handins.ccs.neu.edu/courses/147/assignments/3499/submissions/{filename_m.group(2)}'
    flagged = 'OK'
    define_struct = ''
    with open(rkt_file, "r") as f:
        # Read the file line by line.
        for line in f:
            m = FLAG_RE.search(line)
            if m is not None:
                flagged = m.group(1)
            m = DEFINE_STRUCT_RE.search(line)
            if m is not None:
                define_struct = 'define-struct'
    try:
        run_output = subprocess.check_output(['racket', rkt_file], 
            stderr = subprocess.STDOUT,
            timeout = 10)
        if RUN_OUTPUT_RE.search(run_output.decode('utf-8')) is None:
            run_output = 'Run error'
        else:
            run_output = 'All tests passed'
    except subprocess.CalledProcessError:
        run_output = 'Run failed'
    except subprocess.TimeoutExpired:
        run_output = 'Timeout'
    return f'{url},{flagged},{define_struct},{run_output}'

DIR = 'assignment_3499'
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as executor:
    for result in executor.map(analyze, list_dirs(DIR)):
        print(result)