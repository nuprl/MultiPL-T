#!/bin/bash
for F in */*.rkt; do 
    echo "(require test-engine/racket-tests)" >> "$F"
    echo "(test)" >> "$F"
done