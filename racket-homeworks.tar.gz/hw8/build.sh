#!/bin/bash

set -e

# Run this function on exit
function finish {
    kill $PID
}
trap finish EXIT

Xvfb :99 &
PID=$!
export DISPLAY=:99
echo "Running the master / solution file ..."
racket hw8-master.rkt
python3 ../../Homeworks/split_master.py hw8-master.rkt
echo "Running the starter file ..."
racket hw8-all-problems.rkt


