#!/bin/bash

set -e

# Run this function on exit
function finish {
    kill $PID
}
trap finish EXIT

Xvfb :99 &
PID=$!
export DISPLAY=:99
echo "Running the master / solution file ..."
racket hw4-master.rkt
python3 ../../Homeworks/split_master.py hw4-master.rkt
echo "Running the starter file ..."
racket hw4-problem1.rkt
racket hw4-problem2.rkt
racket hw4-problem3.rkt
