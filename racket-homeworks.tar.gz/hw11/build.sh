#!/bin/bash

set -e

echo "Running the master / solution file ..."
racket hw11-master.rkt
python3 ../../Homeworks/split_master.py hw11-master.rkt
echo "Running the starter file ..."
racket hw11-problem1.rkt


