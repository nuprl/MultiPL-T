#!/bin/bash

set -e

echo "Running the master / solution file ..."
racket hw10-master.rkt
python3 ../../Homeworks/split_master.py hw10-master.rkt
echo "Running the starter file ..."
racket hw10-problem1.rkt


