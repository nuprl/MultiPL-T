def score_closing_characters(closing_characters: str) -> int:
    """Calculate the autocomplete score for a set of closing characters."""
    ### Canonical solution below ###

    closing_char_mapping = {")": 1, "]": 2, "}": 3, ">": 4}

    autocomplete_score = 0

    for char in closing_characters:

        autocomplete_score *= 5

        autocomplete_score += closing_char_mapping[char]

    return autocomplete_score


### Unit tests below ###
def check(candidate):
	assert candidate(closing_characters=")") == 1
	assert candidate(closing_characters = "}}]])})]") == 288957
	assert candidate(closing_characters="") == 0
	assert candidate(closing_characters="}}>}>))))") == 1480781
	assert candidate(closing_characters="}") == 3
	assert candidate(closing_characters=">") == 4
	assert candidate(closing_characters="]") == 2
	assert candidate(closing_characters="}}]])})]") == 288957
	assert candidate(closing_characters="])}>") == 294
	assert candidate(closing_characters="]]}}]}]}>") == 995444
	assert candidate(closing_characters=")}>]})") == 5566
def test_check():
	check(score_closing_characters)
