def abs_value(value):
    """replaces the value with a absolute value, 0 for non number"""
    ### Canonical solution below ###
    try:
        float(value)
    except:
        value = 0 
    return abs(value)


### Unit tests below ###
def check(candidate):
	assert candidate(0) == 0, "candidate(0) == 0"
	assert candidate(1.23) == 1.23
	assert candidate(100) == 100
	assert candidate(False) == 0
	assert candidate("xyz") == 0
	assert candidate(2) == 2
	assert candidate(10) == 10, "candidate(10) == 10"
	assert candidate(1.1) == 1.1
	assert candidate("asdf") == 0
	assert candidate(-5.5) == 5.5
	assert candidate(-123) == 123
	assert candidate("foo") == 0
	assert candidate("a1a") == 0
	assert candidate("") == 0
	assert candidate(0) == 0
	assert candidate("a") == 0
	assert candidate(-5) == 5
	assert candidate('foo') == 0
	assert candidate("abc123") == 0
	assert candidate(-1.23) == 1.23
	assert candidate(True) == 1
	assert candidate(123) == 123
	assert candidate(-0.1) == 0.1
	assert candidate("a1.1a") == 0
	assert candidate('None') == 0
	assert candidate(1) == 1
	assert candidate(-2) == 2
	assert candidate("text") == 0
	assert candidate(None) == 0
	assert candidate('[]') == 0
	assert candidate(-10) == 10, "candidate(-10) == 10"
	assert candidate(-1) == 1
	assert candidate(-100) == 100
	assert candidate('a') == 0
	assert candidate('abc') == 0
	assert candidate(42) == 42
	assert candidate('()') == 0
	assert candidate("a1.1") == 0
	assert candidate(10) == 10
	assert candidate(-10) == 10
	assert candidate({}) == 0
	assert candidate("1a") == 0
	assert candidate(-42) == 42
	assert candidate("A") == 0, "candidate('A') == 0"
	assert candidate("abc") == 0
	assert candidate([]) == 0
	assert candidate("1.1a") == 0
	assert candidate('hello') == 0
	assert candidate(5.4) == 5.4
	assert candidate(5) == 5
	assert candidate(2.5) == 2.5
	assert candidate(0.1) == 0.1
def test_check():
	check(abs_value)
