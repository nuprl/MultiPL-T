def _ExtractLongWords(ngrams, lengths, preferences, dicts):
    """ Return dict{length, set of extracted ngrams}
     
     For each length of 10+ found in lengths, set aside any ngrams that must
     be used to construct a word of that length.
     """
	### Canonical solution below ###    
    length_to_ngrams = {}
    for length in lengths:
        if length in length_to_ngrams:
            continue
            solutions = set()
            _FindEnumeratedSeq(new_word="", next_ngram="",
                               unused_enums=lengths, soln="",
                               preferences=preferences, dicts=dicts,
                               solutions=solutions)
            length_to_ngrams[length] = _FindCommonNgrams(ngrams, solutions)

    return length_to_ngrams

### Unit tests below ###
def check(candidate):
	assert candidate(
    ['a', 'b', 'c'], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    {'length': 6}, {}) == {}
	assert candidate(set("ab"), set([3, 4]), {"ab": 6}, {}) == {}
	assert candidate(set(["A", "B", "C"]), set([2]), set(["A", "B", "C"]),
                         {"A":set(["A"]), "B":set(["B"]), "C":set(["C"])}) == {}
	assert candidate(set("ab"), set([2, 3]), {}, {}) == {}
	assert candidate(set(["12345"]), set([6]), [], {}) == {}
	assert candidate(
    ['a', 'b', 'c'], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], {}, {}) == {}
	assert candidate(set("ab"), set(), {}, {}) == {}
	assert candidate(set(["AB", "BC", "CD"]), [3, 4], [], []) == {}
	assert candidate(set("cat dog"), set([2, 3]), {}, {}) == {}
def test_check():
	check(_ExtractLongWords)
