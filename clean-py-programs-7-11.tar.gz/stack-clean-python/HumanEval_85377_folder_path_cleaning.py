def folder_path_cleaning(folder):
    """ 
     Modifies string file names from Windows format to Unix format if necessary
     and makes sure there is a ``/`` at the end.
     
     Parameters
     ----------
     folder : string
     The folder path
     
     Returns
     -------
     folder_path : str
     The folder path
     """
	### Canonical solution below ###    

    folder_path = folder.replace('\\', '/')
    if folder_path[-1] != '/':
        folder_path += '/'
    return folder_path

### Unit tests below ###
def check(candidate):
	assert candidate("C:/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder/") == "C:/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder/"
	assert candidate(r'C:/Users/Brian/folder/') == r'C:/Users/Brian/folder/'
	assert candidate(r'C:/Users/test') == 'C:/Users/test/'
	assert candidate(r'C:/Users/me/') == r'C:/Users/me/'
	assert candidate(folder='test/') == 'test/'
	assert candidate(r'C:\Users\User\Desktop\folder') == r'C:/Users/User/Desktop/folder/'
	assert candidate('Users/me') == 'Users/me/'
	assert candidate(
    "C:\\Users\\myname\\Documents\\GitHub\\py_eegepe/tests/test_data/test_data_folder") == "C:/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder/"
	assert candidate(r"C:\Users\User\Desktop\folder") == r"C:/Users/User/Desktop/folder/"
	assert candidate('test') == 'test/'
	assert candidate(
    "/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder") == "/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder/"
	assert candidate(r'C:\Users\Damien\Desktop') == 'C:/Users/Damien/Desktop/'
	assert candidate(r'C:/Users/Josh/Desktop/') == 'C:/Users/Josh/Desktop/'
	assert candidate('test/') == 'test/'
	assert candidate(folder='test/test/') == 'test/test/'
	assert candidate(r'C:/Users/Juan/Desktop/folder/') == r'C:/Users/Juan/Desktop/folder/'
	assert candidate(r'/Users/User/Desktop/folder_name/') == r'/Users/User/Desktop/folder_name/'
	assert candidate(
    "C:/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder") == "C:/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder/"
	assert candidate(folder='folder/') == 'folder/'
	assert candidate(r'C:\Users\User\Desktop\folder_name') == r'C:/Users/User/Desktop/folder_name/'
	assert candidate(
    "C:/Users/User/Desktop/folder/") == "C:/Users/User/Desktop/folder/"
	assert candidate(r'C:\Users\me\folder/') == r'C:/Users/me/folder/'
	assert candidate(folder='folder/folder/') == 'folder/folder/'
	assert candidate('C:/Users/me/folder') == r'C:/Users/me/folder/'
	assert candidate(r'C:/Users/Brian/folder') == r'C:/Users/Brian/folder/'
	assert candidate(r'C:/temp') == r'C:/temp/'
	assert candidate(r'C:\temp') == r'C:/temp/'
	assert candidate(r'C:/Users/User/Downloads/folder') == r'C:/Users/User/Downloads/folder/'
	assert candidate(
    "C:\\Users\\User\\Desktop\\folder") == "C:/Users/User/Desktop/folder/"
	assert candidate('Users/Josh/Desktop') == 'Users/Josh/Desktop/'
	assert candidate(
    "C:/Users/User/Desktop/folder") == "C:/Users/User/Desktop/folder/"
	assert candidate(folder='folder') == 'folder/'
	assert candidate(r'C:/Users/Juan/Desktop/folder') == r'C:/Users/Juan/Desktop/folder/'
	assert candidate(folder='test\\') == 'test/'
	assert candidate(r'C:\Users\user\folder\folder') == r'C:/Users/user/folder/folder/'
	assert candidate(r'C:\Users\test') == 'C:/Users/test/'
	assert candidate(folder='folder\\folder\\') == 'folder/folder/'
	assert candidate(r'C:\Users\User\Desktop\test\folder') == 'C:/Users/User/Desktop/test/folder/'
	assert candidate(r'C:\Users\Test') == r'C:/Users/Test/'
	assert candidate(r'C:\test\test2') == 'C:/test/test2/'
	assert candidate(r'C:\Users\me\folder') == r'C:/Users/me/folder/'
	assert candidate(r'C:/Users/test/') == 'C:/Users/test/'
	assert candidate(r'C:\Users\User\Documents') == 'C:/Users/User/Documents/'
	assert candidate(r'C:/Users/User/Desktop/test/folder') == 'C:/Users/User/Desktop/test/folder/'
	assert candidate(r'C:\Users\Josh\Desktop') == 'C:/Users/Josh/Desktop/'
	assert candidate(folder='C:/Users/folder/') == 'C:/Users/folder/'
	assert candidate(r'C:\Users/Brian/folder') == r'C:/Users/Brian/folder/'
	assert candidate(r'C:\test') == 'C:/test/'
	assert candidate(r'C:/Users/me') == r'C:/Users/me/'
	assert candidate(r'C:\Users\user\Desktop') == 'C:/Users/user/Desktop/'
	assert candidate(r'C:/Users/User/Desktop/folder') == r'C:/Users/User/Desktop/folder/'
	assert candidate(r'C:/Users/User/Desktop/test/folder/') == 'C:/Users/User/Desktop/test/folder/'
	assert candidate(r'C:/test') == 'C:/test/'
	assert candidate('Users/user/Desktop') == 'Users/user/Desktop/'
	assert candidate(r'C:/Users/me/folder') == 'C:/Users/me/folder/'
	assert candidate('Users/Josh/Desktop/') == 'Users/Josh/Desktop/'
	assert candidate(r'C:/Users/Test') == r'C:/Users/Test/'
	assert candidate(r'C:\Users\User\Desktop\folder') == 'C:/Users/User/Desktop/folder/'
	assert candidate(r'/Users/me/') == '/Users/me/'
	assert candidate('C:/Users/jane/folder/') == 'C:/Users/jane/folder/'
	assert candidate(folder='test/test/test') == 'test/test/test/'
	assert candidate(r'C:/Users/me/folder/') == 'C:/Users/me/folder/'
	assert candidate(r'C:/Users/foo/bar') == r'C:/Users/foo/bar/'
	assert candidate(r'/Users/me') == '/Users/me/'
	assert candidate(r'C:\Users\User\Downloads\folder') == r'C:/Users/User/Downloads/folder/'
	assert candidate(r'C:\Users\user\Desktop\folder') == 'C:/Users/user/Desktop/folder/'
	assert candidate(folder='C:/Users/folder') == 'C:/Users/folder/'
	assert candidate(r'C:/Users/foo/bar/') == r'C:/Users/foo/bar/'
	assert candidate(r'C:\Users\me') == r'C:/Users/me/'
	assert candidate(folder='folder\\') == 'folder/'
	assert candidate(r'C:\Users\me') == 'C:/Users/me/'
	assert candidate(r"C:/Users/User/Desktop/folder/") == r"C:/Users/User/Desktop/folder/"
	assert candidate(r'C:/Users/User/Desktop/folder/') == r'C:/Users/User/Desktop/folder/'
	assert candidate(r'/Users/Damien/Desktop/') == '/Users/Damien/Desktop/'
	assert candidate(r'C:/Users/user/folder/folder/') == r'C:/Users/user/folder/folder/'
	assert candidate('/test/') == '/test/'
	assert candidate(folder='test') == 'test/'
	assert candidate(folder='test\\test') == 'test/test/'
	assert candidate(folder='folder\\folder') == 'folder/folder/'
	assert candidate('Users/user/Desktop/folder') == 'Users/user/Desktop/folder/'
	assert candidate(r'C:\Users\me\folder') == 'C:/Users/me/folder/'
	assert candidate('C:/Users/me/folder/') == r'C:/Users/me/folder/'
	assert candidate(r'C:\Users\Brian\folder') == r'C:/Users/Brian/folder/'
	assert candidate('/Users/me') == '/Users/me/'
	assert candidate(r'C:/temp/') == r'C:/temp/'
	assert candidate(r'C:/Users/User/Downloads/folder/') == r'C:/Users/User/Downloads/folder/'
	assert candidate(r'C:\Users\User\Desktop\folder/') == 'C:/Users/User/Desktop/folder/'
	assert candidate(folder='folder/folder') == 'folder/folder/'
	assert candidate('/Users/me/') == '/Users/me/'
	assert candidate(r'C:/test/test2') == 'C:/test/test2/'
	assert candidate(r'/Users/Josh/Desktop/') == '/Users/Josh/Desktop/'
	assert candidate('Users/me/') == 'Users/me/'
	assert candidate(r'C:\Users\foo\bar') == r'C:/Users/foo/bar/'
	assert candidate(
    "C:\\Users\\User\\Desktop\\folder\\") == "C:/Users/User/Desktop/folder/"
	assert candidate(r'C:\Users\me\folder/') == 'C:/Users/me/folder/'
	assert candidate(r'C:\Users\jane\folder') == 'C:/Users/jane/folder/'
	assert candidate(r'C:\Users\Juan\Desktop\folder/') == r'C:/Users/Juan/Desktop/folder/'
	assert candidate(folder='test/test') == 'test/test/'
	assert candidate('C:/Users/User/Documents') == 'C:/Users/User/Documents/'
	assert candidate("C:\\Users\\myname\\Documents\\GitHub\\py_eegepe/tests/test_data/test_data_folder/") == "C:/Users/myname/Documents/GitHub/py_eegepe/tests/test_data/test_data_folder/"
	assert candidate('C:/Users/jane/folder') == 'C:/Users/jane/folder/'
def test_check():
	check(folder_path_cleaning)
