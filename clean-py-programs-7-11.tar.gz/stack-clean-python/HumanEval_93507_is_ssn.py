def is_ssn(value):
    """
    Test whether a number is between 0 and 1e9.

    Note this function does not take into consideration some special numbers that are never allocated.
    https://en.wikipedia.org/wiki/Social_Security_number
    """
    ### Canonical solution below ###
    if type(value) is int:
        return 0 < value < 1e9
    elif type(value) is str:
        value = value.replace('-', '')
        if value.isdigit():
            return 0 < int(value) < 1e9
    return False


### Unit tests below ###
def check(candidate):
	assert candidate('123 45 67890') == False
	assert candidate('123 456789012') == False
	assert candidate('12345678901234567890') == False
	assert candidate('123456789000') == False
	assert candidate('1e8') == False
	assert candidate('123-45-67890') is False
	assert not candidate(4177462911)
	assert candidate('12345 6789') == False
	assert candidate('123456789')
	assert candidate('123-45-678901') == False
	assert not candidate('False')
	assert candidate(1234567890123456789) == False
	assert candidate('10000000000') == False
	assert not candidate('4177a46291')
	assert not candidate('1234567890123')
	assert candidate("518247-535") is True
	assert candidate(True) == False
	assert not candidate('123456789012345678901234567890')
	assert candidate(12345678900) == False
	assert candidate(12345678900000) == False
	assert candidate('123-45-67890A') == False
	assert not candidate('123 45 6789')
	assert candidate('a123456789') == False
	assert candidate(9876543210) == False
	assert candidate('4444444444444444') == False
	assert candidate('123.45.67890') == False
	assert candidate(417746291)
	assert candidate('1e9') == False
	assert candidate('123456789-01') == False
	assert candidate('12345678900000') == False
	assert candidate('123456789a') is False
	assert not candidate('1234567890123456')
	assert not candidate('123456789012')
	assert not candidate('10000000000')
	assert candidate(None) is False
	assert candidate('123-456-78901') == False
	assert not candidate('1000000000')
	assert not candidate('None')
	assert candidate('12345678901') == False
	assert not candidate('123456789012345')
	assert candidate('123 45678901') == False
	assert candidate('417746-291')
	assert candidate('123-45-67890123') == False
	assert candidate('000 00 0000') == False
	assert candidate('987654321') == True
	assert candidate('00000000000') == False
	assert candidate('abc') is False
	assert candidate('123-4567890') == False
	assert not candidate('417a746291')
	assert not candidate('41774629a1')
	assert not candidate(12345678901)
	assert candidate('999 99 9999') == False
	assert candidate('123-45-6789')
	assert candidate('123/45/67890') == False
	assert not candidate('123 45 67890')
	assert not candidate('abc123-45-6789')
	assert candidate(1e10) == False
	assert candidate(1234567890) == False
	assert candidate('123-45-6789') == True
	assert candidate(123456789012) == False
	assert candidate(4444444444) == False
	assert not candidate(41774629111)
	assert candidate(123.45) == False
	assert candidate(12345678901234) == False
	assert candidate('44444444444') == False
	assert not candidate(123456789012)
	assert not candidate('4177462911')
	assert candidate('123-45-6789a') is False
	assert not candidate(1000000000)
	assert not candidate('41774629111')
	assert candidate('123456789') is True
	assert candidate(4444444444444444) == False
	assert candidate('A123-45-6789') == False
	assert candidate('123-45678901') == False
	assert candidate(1e9) == False
	assert candidate(12345678900000000) == False
	assert candidate(12345678901234567890) == False
	assert candidate('1234567890123') == False
	assert candidate(0) == False
	assert candidate(444444444) == True
	assert not candidate(1234567890123)
	assert not candidate('123456789a')
	assert candidate(987654321) == True
	assert candidate(123456789012345) == False
	assert not candidate('123-45-67890')
	assert candidate('444-44-44444') == False
	assert candidate('123456789012') == False
	assert candidate('12345678901') is False
	assert candidate(123456789000) == False
	assert candidate(1234567890123) == False
	assert candidate('123-45 6789') == False
	assert candidate('123 45 6789') == False
	assert candidate('123-45-67890') == False
	assert candidate('123456789-0') == False
	assert not candidate('41774a6291')
	assert not candidate('12345678901')
	assert candidate('9999999999') == False
	assert not candidate('417746a291')
	assert candidate('1234567890') is False
	assert candidate(1234567890123456) == False
	assert not candidate(12345678901234567)
	assert candidate('123-45-6789') is True
	assert not candidate(12345678901234)
	assert not candidate(1234567890123456)
	assert candidate(12345678901) is False
	assert not candidate('1234567890')
	assert candidate('123-456789012') == False
	assert candidate('abc123-45-6789') == False
	assert candidate(1234567890000000) == False
	assert candidate('123456789') == True
	assert candidate(123456789) == True
	assert not candidate(123456789012345)
	assert not candidate('a17746291')
	assert candidate(987654321)
	assert candidate('12345678900') == False
	assert candidate('987-65-43210') == False
	assert candidate('123456789A') == False
	assert not candidate(12345678901234567890)
	assert candidate(12345678901) == False
	assert not candidate('417746291-1')
	assert candidate('1234567890000000') == False
	assert candidate('0000000000') == False
	assert candidate('123456789-012') == False
	assert candidate(123456789000000) == False
	assert not candidate('1000000000000')
	assert candidate('666 66 6666') == False
	assert candidate('987-65-4321')
	assert candidate('444-44-4444') == True
	assert candidate('123 4567890') == False
	assert not candidate('417746291a')
	assert not candidate('4177462a91')
	assert not candidate(False)
	assert not candidate(None)
	assert not candidate(1234567890)
	assert candidate('000-00-0000') == False
	assert candidate("518247 536") is False
	assert candidate(123456789012345678) == False
	assert candidate(123456789)
	assert candidate(-1) == False
	assert candidate('1234567890') == False
	assert candidate(None) == False
	assert candidate('123-45-6789A') == False
	assert candidate(999999999) == True
	assert not candidate(1234567890123456789)
	assert candidate('1234567890000') == False
	assert candidate('123-45-6789a') == False
	assert candidate('123 45-6789') == False
	assert not candidate('12345678901234')
	assert candidate(123456789) is True
	assert not candidate('41a7746291')
	assert candidate('100-000-0000') == False
	assert not candidate('True')
	assert candidate('123456789000000') == False
	assert not candidate('4a17746291')
	assert candidate('9876543210') == False
	assert candidate('123456789a') == False
	assert not candidate('123-45-678901')
	assert not candidate(123456789012345678)
	assert not candidate('417746291-11')
	assert candidate(518247535) is True
	assert candidate('100 000 0000') == False
	assert candidate('123-456-7890') == False
	assert candidate('417-746-291')
	assert not candidate('417746291-111')
	assert not candidate('100000000000')
	assert candidate('123-45-678901') is False
	assert candidate(12345678901234567) == False
	assert candidate(1234567890000) == False
	assert candidate(1234567890) is False
	assert candidate('999999999') == True
	assert not candidate(True)
	assert candidate('123 45 67890123') == False
	assert candidate("518247535") is True
	assert not candidate('987654321012345678901234567890')
	assert candidate('123 456789') == False
def test_check():
	check(is_ssn)
