def _yql_queryMock(yql):  # pylint: disable=invalid-name
    """ Mock yahoo query language query."""
	### Canonical solution below ###    
    return ('{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
            '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')

### Unit tests below ###
def check(candidate):
	assert candidate(1) == '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", "lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}'
	assert candidate(None) == ('{"query": {"count": 1, "created": '
                                 '"2017-11-17T13:40:47Z", "lang": "en-US", '
                                 '"results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(123) == ('{"query": {"count": 1, "created": '
                               '"2017-11-17T13:40:47Z", "lang": "en-US", '
                               '"results": {"place": {"woeid": '
                               '"23511632"}}}}')
	assert candidate(None) == \
    ('{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
     '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate('abc') == ('{"query": {"count": 1, "created": '
                                 '"2017-11-17T13:40:47Z", "lang": "en-US", '
                                 '"results": {"place": {"woeid": '
                                 '"23511632"}}}}')
	assert candidate(
   'select woeid from geo.places where text="London, England"') == (
        '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
        '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(
   'select * from weather.forecast where woeid=23511632') == (
    '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
    '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(
   'select * from weather.forecast where woeid = 23511632') == (
        '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
        '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate('23511632') == ('{"query": {"count": 1, "created": '
                                      '"2017-11-17T13:40:47Z", "lang": '
                                      '"en-US", "results": {"place": {"woeid": '
                                      '"23511632"}}}}')
	assert candidate(
   'select * from geo.places where text="London, UK"') == (
        '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
        '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(
   'select * from weather.forecast where woeid=23511632') == (
        '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
        '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(None) == (
    '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
    '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(
    "select * from weather.forecast where woeid=23511632") == (
        '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
        '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(  # pylint: disable=invalid-name
   'select * from weather.forecast where woeid=23511632') == (
        '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", '
        '"lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}')
	assert candidate(1234) == '{"query": {"count": 1, "created": "2017-11-17T13:40:47Z", "lang": "en-US", "results": {"place": {"woeid": "23511632"}}}}'
	assert candidate(None) == ('{"query": {"count": 1, "created": '
                                  '"2017-11-17T13:40:47Z", "lang": "en-US", '
                                  '"results": {"place": {"woeid": '
                                  '"23511632"}}}}')
	assert candidate(None) == ('{"query": {"count": 1, "created": '
                                  '"2017-11-17T13:40:47Z", "lang": '
                                  '"en-US", "results": {"place": '
                                  '{"woeid": "23511632"}}}}')
	assert candidate(None) == ('{"query": {"count": 1, "created": '
                                 '"2017-11-17T13:40:47Z", "lang": "en-US", '
                                 '"results": {"place": {"woeid": '
                                 '"23511632"}}}}')
	assert candidate(yql="select * from weather.forecast where woeid=23511632")
def test_check():
	check(_yql_queryMock)
