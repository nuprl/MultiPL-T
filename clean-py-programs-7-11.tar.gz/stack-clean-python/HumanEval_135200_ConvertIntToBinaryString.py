def ConvertIntToBinaryString(x, reverse=False):
    """
    Convert an integer to a binary string.

    Optionally reverse the output string, which is
    required for producing a Van Der Corput sequence.

    @param int  x:       The number to be converted.
    @param bool reverse: If True, the output string will be reversed.

    @returns string: A binary number as a string.
    """
    ### Canonical solution below ###
    if type(x) != int:
        raise ValueError('Input number must be an integer')

    if reverse:
        return ''.join(reversed(bin(x)[2:]))

    return ''.join(bin(x)[2:])


### Unit tests below ###
def check(candidate):
	assert candidate(17) == '10001'
	assert candidate(1, reverse=True) == '1'
	assert candidate(10, reverse=True) == '0101'
	assert candidate(18) == '10010'
	assert candidate(2, reverse=True) == '01'
	assert candidate(10, reverse=False) == '1010'
	assert candidate(12) == '1100'
	assert candidate(6, True) == '011'
	assert candidate(100) == '1100100'
	assert candidate(1) == '1'
	assert candidate(16) == '10000'
	assert candidate(100, reverse=False) == '1100100'
	assert candidate(2, True) == '01'
	assert candidate(14) == '1110'
	assert candidate(11) == '1011'
	assert candidate(100, reverse=True) == '0010011'
	assert candidate(6, False) == '110'
	assert candidate(6) == '110'
	assert candidate(4) == '100'
	assert candidate(1, True) == '1'
	assert candidate(3, reverse=False) == '11'
	assert candidate(23) == '10111'
	assert candidate(3) == '11'
	assert candidate(0, reverse=True) == '0'
	assert candidate(23)
	assert candidate(9, False) == '1001'
	assert candidate(1) == '1', 'candidate(1) failed'
	assert candidate(6, reverse=False) == '110'
	assert candidate(20) == '10100'
	assert candidate(5, True) == '101'
	assert candidate(2, False) == '10'
	assert candidate(0, reverse=False) == '0'
	assert candidate(9, reverse=False) == '1001'
	assert candidate(2, reverse=True) == '01', 'candidate(2, True) failed'
	assert candidate(10, False) == '1010'
	assert candidate(7, False) == '111'
	assert candidate(2) == '10', 'candidate(2) failed'
	assert candidate(7, reverse=False) == '111'
	assert candidate(4, False) == '100'
	assert candidate(9) == '1001'
	assert candidate(10) == '1010'
	assert candidate(8, reverse=False) == '1000'
	assert candidate(7) == '111'
	assert candidate(5) == '101'
	assert candidate(3, True) == '11'
	assert candidate(8, False) == '1000'
	assert candidate(15) == '1111'
	assert candidate(2, reverse=False) == '10'
	assert candidate(8) == '1000'
	assert candidate(0) == '0', 'candidate(0) failed'
	assert candidate(0) == '0'
	assert candidate(1, reverse=False) == '1'
	assert candidate(5, False) == '101'
	assert candidate(21) == '10101'
	assert candidate(255, reverse=False) == '11111111'
	assert candidate(1, False) == '1'
	assert candidate(4, True) == '001'
	assert candidate(1, reverse=True) == '1', 'candidate(1, True) failed'
	assert candidate(3, False) == '11'
	assert candidate(100, True) == '0010011'
	assert candidate(5, reverse=False) == '101'
	assert candidate(0, reverse=True) == '0', 'candidate(0, True) failed'
	assert candidate(8, True) == '0001'
	assert candidate(11, False) == '1011'
	assert candidate(2) == '10'
	assert candidate(7, True) == '111'
	assert candidate(25, reverse=False) == '11001'
	assert candidate(4, reverse=False) == '100'
	assert candidate(19) == '10011'
	assert candidate(22) == '10110'
	assert candidate(13) == '1101'
def test_check():
	check(ConvertIntToBinaryString)
