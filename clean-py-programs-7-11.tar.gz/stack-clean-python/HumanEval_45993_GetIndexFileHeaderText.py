def GetIndexFileHeaderText(headerinfo):#{{{
    """ 
     Get the header information of the index file in ASCII format
     """
	### Canonical solution below ###    
    (dbname, version, ext, prefix) = headerinfo
    indexFileHeaderText = []
    indexFileHeaderText.append("DEF_VERSION %s"%(version))
    indexFileHeaderText.append("DEF_DBNAME %s"%(dbname))
    indexFileHeaderText.append("DEF_EXTENSION %s"%(ext))
    indexFileHeaderText.append("DEF_PREFIX %s"%(prefix))
    return indexFileHeaderText

### Unit tests below ###
def check(candidate):
	assert candidate( ("test", "1", "pdb", "pdb") ) == [
    "DEF_VERSION 1",
    "DEF_DBNAME test",
    "DEF_EXTENSION pdb",
    "DEF_PREFIX pdb",
]
	assert candidate(
    ("mydb", "1.0", "db", "myprefix")) == [
        "DEF_VERSION 1.0",
        "DEF_DBNAME mydb",
        "DEF_EXTENSION db",
        "DEF_PREFIX myprefix"]
	assert candidate( ("testdb", "20120120", "txt", "test") ) == \
    ["DEF_VERSION 20120120", "DEF_DBNAME testdb", "DEF_EXTENSION txt", "DEF_PREFIX test"]
	assert candidate(("mydb", "20161007", "txt", "my")) == ["DEF_VERSION 20161007", "DEF_DBNAME mydb", "DEF_EXTENSION txt", "DEF_PREFIX my"]
	assert candidate( ('aa', 'bb', 'cc', 'dd')) == [ 'DEF_VERSION bb', 'DEF_DBNAME aa', 'DEF_EXTENSION cc', 'DEF_PREFIX dd' ]
	assert candidate( ("abc", "123", "xyz", "pqr") ) == \
        ["DEF_VERSION 123", "DEF_DBNAME abc", "DEF_EXTENSION xyz", "DEF_PREFIX pqr"]
	assert candidate(
    ('blast', '001', '0000000000', '')) == [
        'DEF_VERSION 001', 'DEF_DBNAME blast', 'DEF_EXTENSION 0000000000',
        'DEF_PREFIX ']
	assert candidate( ('test_db', '0.1', 'test_ext', 'test_prefix') ) == ['DEF_VERSION 0.1', 'DEF_DBNAME test_db', 'DEF_EXTENSION test_ext', 'DEF_PREFIX test_prefix']
	assert candidate( ("A", "B", "C", "D") ) == ['DEF_VERSION B', 'DEF_DBNAME A', 'DEF_EXTENSION C', 'DEF_PREFIX D']
	assert candidate( ("a","1","b","c") ) == ['DEF_VERSION 1', 'DEF_DBNAME a', 'DEF_EXTENSION b', 'DEF_PREFIX c']
	assert candidate(
    ("test_db", 1, "fna", "test")) == ["DEF_VERSION 1", "DEF_DBNAME test_db", "DEF_EXTENSION fna", "DEF_PREFIX test"]
	assert candidate( ('test', '1.0', 'txt', 'def') ) == \
        ['DEF_VERSION 1.0', 'DEF_DBNAME test', 'DEF_EXTENSION txt', 'DEF_PREFIX def']
	assert candidate( ("test", "20160222", "gz", "20160222") ) == ['DEF_VERSION 20160222', 'DEF_DBNAME test', 'DEF_EXTENSION gz', 'DEF_PREFIX 20160222'], "Failed candidate unit test"
	assert candidate( ('mydb', '1.0', 'dat','myprefix') ) == \
    ['DEF_VERSION 1.0', 'DEF_DBNAME mydb', 'DEF_EXTENSION dat', 'DEF_PREFIX myprefix']
	assert candidate(("name","1.0","ext","pre")) == \
['DEF_VERSION 1.0', 'DEF_DBNAME name', 'DEF_EXTENSION ext', 'DEF_PREFIX pre']
	assert candidate(
    ("testdb", "1.0", "fasta", "testdb")) == ["DEF_VERSION 1.0", "DEF_DBNAME testdb", "DEF_EXTENSION fasta", "DEF_PREFIX testdb"]
def test_check():
	check(GetIndexFileHeaderText)
