def move_left(t):
    """ A method that takes coordinates of bomb's
     position and returns coordinates of neighbour
     located at the left of the bomb. It returns None
     if there isn't such a neighbour """
	### Canonical solution below ###    

    x, y = t
    if y == 0:
        return None
    else:
        return (x, y - 1)

### Unit tests below ###
def check(candidate):
	assert candidate( (5, 0) ) == None
	assert candidate((0, 5)) == (0, 4)
	assert candidate( (2,2) ) == (2,1)
	assert candidate( (3,0) ) == None
	assert candidate( (8, 8) ) == (8, 7)
	assert candidate( (0,1) ) == (0,0)
	assert candidate( (4, 0) ) == None
	assert candidate( (2, 3) ) == (2, 2)
	assert candidate((1, 5)) == (1, 4)
	assert candidate( (2, 1) ) == (2, 0)
	assert candidate((1, 2)) == (1, 1)
	assert candidate((2, 5)) == (2, 4)
	assert candidate( (7, 7) ) == (7, 6)
	assert candidate((2, 3)) == (2, 2)
	assert candidate( (3,3) ) == (3,2)
	assert candidate((3, 1)) == (3, 0)
	assert candidate( (3, 4) ) == (3, 3)
	assert candidate((0, 2)) == (0, 1)
	assert candidate((0, 4)) == (0, 3)
	assert candidate( (0, 0) ) is None
	assert candidate((0, 0)) == None
	assert candidate( (0,0) ) == None
	assert candidate((2, 4)) == (2, 3)
	assert candidate((2, 1)) == (2, 0)
	assert candidate((3, 3)) == (3, 2)
	assert candidate( (0, 0) ) == None
	assert candidate((0, 0)) is None
	assert candidate( (0, 4) ) == (0, 3)
	assert candidate( (0, 2) ) == (0, 1)
	assert candidate( (9, 9) ) == (9, 8)
	assert candidate((2, 0)) == None
	assert candidate( (6, 6) ) == (6, 5)
	assert candidate( (2, 2) ) == (2, 1)
	assert candidate((1, 4)) == (1, 3)
	assert candidate((2, 2)) == (2, 1)
	assert candidate((3, 2)) == (3, 1)
	assert candidate( (1, 2) ) == (1, 1)
	assert candidate( (0, 3) ) == (0, 2)
	assert candidate( (1, 1) ) == (1, 0)
	assert candidate((0, 3)) == (0, 2)
	assert candidate((1, 1)) == (1, 0)
	assert candidate( (1, 0) ) == None
	assert candidate( (3, 5) ) == (3, 4)
	assert candidate( (5, 5) ) == (5, 4)
	assert candidate( (3, 3) ) == (3, 2)
	assert candidate((1, 3)) == (1, 2)
	assert candidate( (1,1) ) == (1,0)
	assert candidate( (4, 4) ) == (4, 3)
	assert candidate( (2, 0) ) == None
	assert candidate( (0, 1) ) == (0, 0)
	assert candidate((0, 1)) == (0, 0)
def test_check():
	check(move_left)
