def eff(effort_str):
    """Convert effort string to float.

    Various 'bad' strings are coped with: n? ?n n+ <n?
    """
    ### Canonical solution below ###
    # Munge some bad strings to be good
    if effort_str and effort_str[0] in ['<', '?']:
        effort_str = effort_str[1:]
    if effort_str and effort_str[-1] in ['?', '+']:
        effort_str = effort_str[:-1]
    # Convert to float
    if effort_str:
        return float(effort_str)
    else:
        return 0.0


### Unit tests below ###
def check(candidate):
	assert candidate("1.0") == 1.0
	assert candidate('1.1') == 1.1
	assert candidate("1+") == 1.0
	assert candidate("5") == 5.0
	assert candidate('?1?') == 1.0
	assert candidate('0.0') == 0.0
	assert candidate('3.0?') == 3.0
	assert candidate('0') == 0.0
	assert candidate("1.1") == 1.1
	assert candidate('2') == 2.0
	assert candidate("?1") == 1.0
	assert candidate("1") == 1.0
	assert candidate('1.1000') == 1.1
	assert candidate('1.10000') == 1.1
	assert candidate("1.1+") == 1.1
	assert candidate("1.2") == 1.2
	assert candidate('<1.0') == 1.0
	assert candidate('+1.1') == 1.1
	assert candidate(" 5.0 ") == 5.0
	assert candidate('1?') == 1.0
	assert candidate('1.5') == 1.5
	assert candidate('1.2?') == 1.2
	assert candidate('1.10') == 1.1
	assert candidate('1.1+') == 1.1
	assert candidate('?1.1') == 1.1
	assert candidate('10.000') == 10.0
	assert candidate("1.0+") == 1.0
	assert candidate('10.0') == 10.0
	assert candidate('1.000') == 1.0
	assert candidate('1.0?') == 1.0
	assert candidate('1.0+') == 1.0
	assert candidate('2.5') == 2.5
	assert candidate("3.14159") == 3.14159
	assert candidate("3.14") == 3.14
	assert candidate("3.1415926") == 3.1415926
	assert candidate('1.2') == 1.2
	assert candidate(None) == 0.0
	assert candidate('10') == 10.0
	assert candidate('100?') == 100.0
	assert candidate("2.5") == 2.5
	assert candidate("1?") == 1.0
	assert candidate('1.100') == 1.1
	assert candidate('') == 0.0
	assert candidate("") == 0.0
	assert candidate('?1.1+') == 1.1
	assert candidate("3") == 3.0
	assert candidate('3.0') == 3.0
	assert candidate('<1.0+') == 1.0
	assert candidate('1.1?') == 1.1
	assert candidate("2") == 2.0
	assert candidate("0") == 0.0
	assert candidate("3.0") == 3.0
	assert candidate('1') == 1.0
	assert candidate('<1.0?') == 1.0
	assert candidate('?1.0') == 1.0
	assert candidate('<1') == 1.0
	assert candidate('<1.2?') == 1.2
	assert candidate("2.0") == 2.0
	assert candidate('3') == 3.0
	assert candidate("?") == 0.0
	assert candidate('<1?') == 1.0
	assert candidate("12.3") == 12.3
	assert candidate('+1') == 1.0
	assert candidate('2.5?') == 2.5
	assert candidate('?') == 0.0
	assert candidate('1.100000') == 1.1
	assert candidate("3.141592") == 3.141592
	assert candidate('<1.1?') == 1.1
	assert candidate('1+') == 1.0
	assert candidate('1.0000') == 1.0
	assert candidate('100') == 100.0
	assert candidate("<1?") == 1.0
	assert candidate("0.5") == 0.5
	assert candidate("3.14159265") == 3.14159265
	assert candidate('1.0') == 1.0
	assert candidate('?1.1?') == 1.1
	assert candidate('1.11') == 1.11
	assert candidate("5.0") == 5.0
	assert candidate('1.00') == 1.0
	assert candidate('?1') == 1.0
	assert candidate('1.00000') == 1.0
	assert candidate("3.1") == 3.1
def test_check():
	check(eff)
