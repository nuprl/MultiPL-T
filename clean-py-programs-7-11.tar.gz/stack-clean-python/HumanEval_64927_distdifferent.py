def distdifferent(old, new, i, j):
    """Calculate how different two strings are in terms of the number
    of character removals, additions, and changes needed to go from one
    to the other."""
    ### Canonical solution below ###
    if i == 0 or len(old) < i:
        cval = 0
    else:
        cval = old[i - 1]

    if j == 0 or len(new) < j:
        dval = 0
    else:
        dval = new[j - 1]

    return cval != dval


### Unit tests below ###
def check(candidate):
	assert candidate(u"abcde", u"abc", 1, 4) == True
	assert not candidate(u"abc", u"abc", 2, 2)
	assert candidate('a', 'ab', 0, 1) == True
	assert candidate(old="abc", new="bc", i=0, j=0) == False
	assert candidate(b'abcdef', b'abcdef', 0, 0) == False
	assert candidate(
    "abcdef",
    "abcdef",
    5,
    5
) == False
	assert candidate(
    "abcdef",
    "abcdef",
    2,
    2
) == False
	assert candidate("abcd", "abc", 1, 0) == True
	assert candidate(b'hello', b'hello', 0, 2) == True
	assert candidate(
    "ab", "ac", 3, 3) == False
	assert candidate("a", "a", 0, 0) == False
	assert candidate(
    "ab", "ac", 2, 2) == True
	assert candidate(u"abcde", u"abc", 1, 13) == True
	assert candidate("abcd", "abc", 2, 1) == True
	assert candidate(
    'qabxcd', 'abycdf', 2, 0) == True
	assert candidate(b'hello', b'hello', 1, 0) == True
	assert candidate(u'ab', u'a', 1, 1) == False
	assert candidate(old="abc", new="abc", i=3, j=3) == False
	assert candidate(b'hello', b'hello', 4, 0) == True
	assert candidate('ab', 'ba', 3, 2) == True
	assert candidate(
    'qabxcd', 'abycdf', 1, 0) == True
	assert candidate(u"abcd", u"abcde", 3, 1) == True
	assert candidate(
    "a", "a", 0, 0) == False, "candidate('a', 'a', 0, 0)"
	assert candidate(u"abcde", u"abc", 1, 8) == True
	assert candidate("abcd", "abc", 4, 5) == True
	assert candidate("abcd", "abc", 1, 2) == True
	assert candidate(
    "a", "a", 1, 0) == True, "candidate('a', 'a', 1, 0)"
	assert candidate('a', 'b', 1, 0) == True
	assert candidate(u"abcde", u"abc", 1, 10) == True
	assert candidate(u"abcde", u"abc", 1, 6) == True
	assert candidate(b'abcdef', b'abcdef', 6, 6) == False
	assert candidate(u"abcd", u"abcde", 2, 3) == True
	assert candidate('ab', 'ba', 1, 2) == False
	assert candidate(old="a", new="ab", i=0, j=0) == False
	assert candidate(
    "ab", "ac", 4, 3) == False
	assert candidate(u"abcd", u"abcde", 2, 0) == True
	assert candidate(u"abcde", u"abc", 1, 11) == True
	assert candidate(old="bc", new="abc", i=0, j=0) == False
	assert candidate('ab', 'a', 1, 1) == False
	assert candidate(u"abcde", u"abc", 1, 15) == True
	assert candidate(b'abcdef', b'abcdef', 1, 1) == False
	assert candidate(u"abcde", u"abc", 1, 17) == True
	assert candidate(b'abcdef', b'abcdef', 2, 2) == False
	assert candidate(u"abcde", u"abc", 1, 5) == True
	assert candidate(
    "ab", "ac", 2, 0) == True
	assert candidate(old='', new='', i=0, j=0) == False
	assert candidate(u'', u'', 0, 0) == False
	assert candidate(
    'abcdefghijklmnopqrstuvwxyz',
    'bcdefghijklmnopqrstuvwxyza',
    0, 1) == True
	assert candidate("abcd", "abc", 0, 0) == False
	assert candidate(b'abcdef', b'abcdef', 5, 5) == False
	assert candidate(u"abc", u"abz", 2, 3)
	assert candidate(u"abcd", u"abcde", 3, 0) == True
	assert candidate(
    'qabxcd', 'abycdf', 0, 1) == True
	assert candidate(u'ab', u'a', 1, 2) == True
	assert candidate(
    "a", "b", 0, 1) == True
	assert candidate(
    "ab", "ac", 3, 4) == False
	assert candidate('ab', 'a', 1, 0) == True
	assert candidate(old="abc", new="abc", i=1, j=3) == True
	assert candidate(old="abc", new="abc", i=2, j=2) == False
	assert candidate("abcd", "abc", 2, 3) == True
	assert candidate(None, None, 0, 0) == False
	assert candidate("abc", "abc", 0, 0) == False
	assert candidate(u'a', u'b', 1, 2) == True
	assert candidate(old="abc", new="a", i=0, j=0) == False
	assert candidate(
    "ab", "ab", 0, 1) == True, "candidate('ab', 'ab', 0, 1)"
	assert candidate(
    "abcdef",
    "abcdef",
    3,
    3
) == False
	assert candidate(
    'qabxcd', 'abycdf', 3, 0) == True
	assert candidate(old="ab", new="a", i=0, j=0) == False
	assert candidate('ab', 'ba', 0, 1) == True
	assert candidate(
    "ab", "ac", 0, 2) == True
	assert candidate(b'hello', b'hello', 0, 1) == True
	assert candidate(old='abc', new='adc', i=3, j=3) == False
	assert candidate(u'b', u'a', 1, 2) == True
	assert candidate(u"abcde", u"abc", 1, 9) == True
	assert candidate(old='a', new='a', i=0, j=0) == False
	assert candidate(
    "abcdef",
    "abcdef",
    9,
    9
) == False
	assert candidate(
    "a", "b", 1, 0) == True
	assert candidate(b'hello', b'hello', 2, 2) == False
	assert candidate(
    "abcdef",
    "abccef",
    0,
    0
) == False
	assert candidate(b'hello', b'hello', 1, 1) == False
	assert candidate(b'hello', b'hello', 1, 2) == True
	assert candidate(old="abc", new="abcd", i=1, j=1) == False
	assert candidate(
    'qabxcd', 'abycdf', 0, 0) == False
	assert candidate(
    'qabxcd', 'abycdf', 1, 2) == True
	assert candidate(u'ab', u'a', 2, 1) == True
	assert candidate(
    "abcdef",
    "abccef",
    6,
    6
) == False
	assert candidate(u"abcd", u"abcde", 0, 0) == False
	assert candidate("abcd", "abc", 3, 2) == True
	assert candidate(
    "abcdef",
    "abcdef",
    8,
    8
) == False
	assert candidate(u"abcde", u"abc", 1, 16) == True
	assert candidate(u"abcd", u"abcde", 0, 1) == True
	assert candidate(
    "abcdef",
    "abcdef",
    7,
    7
) == False
	assert candidate(u"abcde", u"abc", 1, 18) == True
	assert candidate(u"abcd", u"abcde", 3, 2) == True
	assert candidate(
    "ab", "ac", 4, 4) == False
	assert candidate(b'hello', b'hello', 3, 2) == True
	assert candidate(old="abc", new="abc", i=3, j=1) == True
	assert candidate('', '', 0, 0) == False
	assert candidate(b'hello', b'hello', 2, 1) == True
	assert candidate("abc", "", 0, 0) == False
	assert candidate(old="abc", new="abcd", i=2, j=2) == False
	assert candidate(u'abc', u'axc', 1, 2)
	assert candidate(
    "ab", "ab", 0, 0) == False, "candidate('ab', 'ab', 0, 0)"
	assert candidate("abcd", "abc", 0, 1) == True
	assert candidate("abc", "abcd", 0, 0) == False
	assert candidate("abcd", "abc", 4, 4) == True
	assert candidate(u"abcd", u"abcde", 2, 1) == True
	assert candidate(
    'abcdefghijklmnopqrstuvwxyz',
    'bcdefghijklmnopqrstuvwxyza',
    1, 100) == True
	assert candidate(u'a', u'b', 1, 1) == True
	assert candidate('ab', 'ba', 3, 1) == True
	assert candidate(
    "ab", "ac", 3, 2) == True
	assert candidate(
    'abcdefghijklmnopqrstuvwxyz',
    'bcdefghijklmnopqrstuvwxyza',
    100, 1) == True
	assert candidate(u'a', u'a', 0, 0) == False
	assert candidate("ab", "ab", 0, 0) == False
	assert candidate(u'a', u'a', 1, 0) == True
	assert candidate(
    "abcdef",
    "abccef",
    3,
    4
) == False
	assert candidate(
    "a", "b", 0, 1) == True, "candidate('a', 'b', 0, 1)"
	assert candidate(u"abcde", u"abc", 1, 12) == True
	assert candidate(
    'qabxcd', 'abycdf', 0, 2) == True
	assert candidate(b'hello', b'hello', 3, 0) == True
	assert candidate(b'hello', b'hello', 2, 0) == True
	assert candidate(u"abcde", u"abc", 1, 14) == True
	assert candidate(
    "ab", "ac", 2, 3) == True
	assert candidate(old="abc", new="abcd", i=2, j=4) == True
	assert candidate(old="abc", new="abc", i=1, j=1) == False
	assert candidate(b'hello', b'hello', 2, 3) == True
	assert candidate("abcd", "abc", 3, 4) == True
	assert candidate(u'b', u'a', 0, 1) == True
	assert candidate(u"abcde", u"abc", 1, 7) == True
	assert candidate("", "", 0, 0) == False
	assert candidate(
    "abcdef",
    "abcdef",
    6,
    6
) == False
	assert candidate(u"abcd", u"abcde", 2, 2) == False
	assert candidate(
    'qabxcd', 'abycdf', 3, 1) == True
	assert candidate(b'abcdef', b'abcdef', 3, 3) == False
	assert candidate(old="abc", new="abcd", i=1, j=4) == True
	assert candidate(
    'qabxcd', 'abycdf', 2, 3) == True
	assert candidate(u'a', u'b', 1, 0) == True
	assert candidate('a', 'b', 0, 1) == True
	assert candidate(u"abcd", u"abcde", 0, 3) == True
	assert candidate("abcd", "abc", 4, 3) == True
	assert candidate(u"abcde", u"abc", 1, 20)
	assert candidate(
    "abcdef",
    "abcdef",
    10,
    10
) == False
	assert candidate('ab', 'ba', 0, 0) == False
	assert candidate(b'hello', b'hello', 3, 3) == False
	assert candidate(b'hello', b'hello', 4, 5) == True
	assert candidate(
    "abcdef",
    "abcdef",
    4,
    4
) == False
	assert candidate(
    "", "", 0, 0) == False, "candidate('', '', 0, 0)"
	assert candidate(
    "a", "a", 0, 1) == True, "candidate('a', 'a', 0, 1)"
	assert candidate(
    "abcdef",
    "abcdef",
    1,
    1
) == False
	assert candidate(b'hello', b'hello', 0, 0) == False
	assert candidate(
    'abcdefghijklmnopqrstuvwxyz',
    'bcdefghijklmnopqrstuvwxyza',
    1, 2) == True
	assert candidate(u"abcd", u"abcde", 1, 1) == False
	assert candidate(
    'abcdefghijklmnopqrstuvwxyz',
    'bcdefghijklmnopqrstuvwxyza',
    1, 0) == True
	assert candidate(
    "abcdef",
    "abcdef",
    0,
    0
) == False
	assert candidate(
    "a", "b", 1, 0) == True, "candidate('a', 'b', 1, 0)"
	assert candidate(b'hello', b'hello', 0, 4) == True
	assert candidate(old="", new="a", i=0, j=1) == True
	assert candidate(b'hello', b'hello', 0, 3) == True
	assert candidate('ab', 'ba', 2, 0) == True
	assert candidate(u'a', u'a', 1, 1) == False
	assert candidate(u"abcde", u"abc", 1, 19) == True
	assert candidate(b'abcdef', b'abcdef', 4, 4) == False
	assert candidate('ab', 'ba', 2, 1) == False
def test_check():
	check(distdifferent)
