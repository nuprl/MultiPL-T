def _clean_region(region):
    """Convert the region name to something that we can use for comparison
    without running into encoding issues."""
    ### Canonical solution below ###
    return ''.join(
        x for x in region.lower()
        if x in 'abcdefghijklmnopqrstvwxyz')


### Unit tests below ###
def check(candidate):
	assert candidate(u'Sint Maarten') == u'sintmaarten'
	assert candidate(u'NRW  ') == 'nrw'
	assert candidate(u'Ontario') == 'ontario'
	assert candidate(u'GB') == u'gb'
	assert candidate(u"Mayotte") == u"mayotte"
	assert candidate(u'BC') == 'bc'
	assert candidate(u'NRW') == 'nrw'
	assert candidate(u"Saint-Barth\xe9lemy") == u"saintbarthlemy"
	assert candidate(u'Saint Martin (French part)') == \
    u'saintmartinfrenchpart'
	assert candidate(u'Mayotte') == u'mayotte'
	assert candidate(u'Aland') == 'aland'
	assert candidate(u'MEXICO') == u'mexico'
	assert candidate(u'Saint Martin') == u'saintmartin'
	assert candidate(u'Saint Vincent and the Grenadines') == \
    u'saintvincentandthegrenadines'
	assert candidate(u'New York') == 'newyork'
	assert candidate(u'Nova Scotia') == 'novascotia'
	assert candidate(u'Saint-Martin') =='saintmartin'
	assert candidate(u'ALANDISLAND') == 'alandisland'
	assert candidate(u'aland') == 'aland'
	assert candidate(u'Bryanskaya Oblast') == u'bryanskayaoblast'
	assert candidate(u'Northern Ireland') == u'northernireland'
	assert candidate(u'Iran') == 'iran'
	assert candidate(u'nrw') == 'nrw'
	assert candidate(u'ALAND') == 'aland'
	assert candidate(u'Alberta') == 'alberta'
	assert candidate(u'Saint Kitts and Nevis') == u'saintkittsandnevis'
	assert candidate(u'EN') == u'en'
	assert candidate(u"Beyonc\xe9") == u"beyonc"
	assert candidate(u'NRW ') == 'nrw'
def test_check():
	check(_clean_region)
