def getSuffixes(algorithm, seqType) :
    """ Get the suffixes for the right algorithm with the right 
     sequence type 
     """
	### Canonical solution below ###    

    suffixes = {}
    suffixes['LAST'] = {}
    suffixes['BLAST'] = {}
    suffixes['BLAST']['nucl'] = ['nhr', 'nsq', 'nin']
    suffixes['BLAST']['prot'] = ['phr', 'psq', 'pin']

    suffixes['LAST']['nucl'] = [ 'des', 'sds', 'suf', 'bck', 'prj', 'ssp', 'tis' ]
    suffixes['LAST']['prot'] = [ 'des', 'sds', 'suf', 'bck', 'prj', 'ssp', 'tis' ]

    if not algorithm in suffixes:
        return None


    if not seqType in suffixes[algorithm]:
        return None

    return suffixes[algorithm][seqType]

### Unit tests below ###
def check(candidate):
	assert candidate( 'BLAST', 'prot') == ['phr', 'psq', 'pin']
	assert candidate( 'BLAST', 'nucl') == ['nhr', 'nsq', 'nin']
	assert candidate( 'BLAST', 'nucl' ) == [ 'nhr', 'nsq', 'nin' ]
	assert candidate('BLAST', 'prot') == [ 'phr', 'psq', 'pin' ]
	assert candidate(None, 'nucl') == None
	assert candidate('LAST', None) is None
	assert candidate('BLAST', None) is None
	assert candidate('BLAST', 'nucl') == [ 'nhr', 'nsq', 'nin' ]
	assert candidate( 'LAST', 'prot') == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate('LAST', 'nucl') == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate('LAST', 'prot') == ['des','sds','suf', 'bck', 'prj','ssp', 'tis']
	assert candidate( 'BLAST', 'prot' ) == ['phr', 'psq', 'pin']
	assert candidate( 'LAST', 'prot' ) == ['des','sds','suf', 'bck', 'prj','ssp', 'tis']
	assert candidate( 'LAST', 'blah' ) == None
	assert candidate('BLAST', 'nucl') == ['nhr', 'nsq', 'nin']
	assert candidate( 'BLAST', 'nucl') == [ 'nhr', 'nsq', 'nin' ]
	assert candidate( 'LAST', 'nucl' ) == ['des','sds','suf', 'bck', 'prj','ssp', 'tis']
	assert candidate('LAST', None) == None
	assert candidate( 'LAST',  'nucl') == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate( 'BLAST', 'prot' ) == [ 'phr', 'psq', 'pin' ]
	assert candidate( 'LAST', 'nucl' ) == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate( 'LAST', 'prot' ) == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate( 'BLAST', 'nucl' ) == ['nhr', 'nsq', 'nin']
	assert candidate('LAST', 'prot') == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate('BLAST', 'prot') == ['phr', 'psq', 'pin']
	assert candidate(None, 'nucl') is None
	assert candidate('BLAST', None) == None
	assert candidate(None, 'prot') == None
	assert candidate('LAST', 'nucl') == ['des','sds','suf', 'bck', 'prj','ssp', 'tis']
	assert candidate( 'BLAST', 'prot') == [ 'phr', 'psq', 'pin' ]
	assert candidate( 'LAST',  'prot') == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate(None, None) == None
	assert candidate(None, None) is None
	assert candidate( 'LAST', 'nucl') == [ 'des','sds','suf', 'bck', 'prj','ssp', 'tis' ]
	assert candidate( 'BLAST', 'blah' ) == None
def test_check():
	check(getSuffixes)
