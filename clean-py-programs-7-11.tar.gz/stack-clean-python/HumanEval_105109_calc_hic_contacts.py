def calc_hic_contacts(snp_gene_dict):
    """Calculates score of HiC contacts between SNP and gene.

    Args:
        snp_gene_dict: The snp and gene specific portion of the dictionary
        from find_genes

    Returns:
        cell_lines: string representing a list of cell line identifiers
        scores: string representing a list of the means of contacts in each
        cell line
        hic_score: sum of the averages of contacts per cell line.
    """
    ### Canonical solution below ###
    hic_score = 0
    cell_lines = sorted(snp_gene_dict.keys())
    scores = []
    for cell_line in cell_lines:
        score = snp_gene_dict[cell_line]['interactions'] / float(
            snp_gene_dict[cell_line]['replicates'])
        scores.append('{:.2f}'.format(score))
        hic_score += score
    return (', '.join(cell_lines), ', '.join(scores),
            "{:.4f}".format(hic_score))


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'CL1': {'interactions': 0,'replicates': 3},
     'CL2': {'interactions': 0,'replicates': 3}}) == (
        'CL1, CL2', '0.00, 0.00', '0.0000')
	assert candidate(
    {'cell_line1': {'interactions': 10,'replicates': 10},
     'cell_line2': {'interactions': 10,'replicates': 10}}
) == (
    'cell_line1, cell_line2',
    '1.00, 1.00',
    '2.0000'
)
	assert candidate(
    {'cell_line_1': {'interactions': 10,'replicates': 10}}
) == ('cell_line_1', '1.00', '1.0000')
	assert candidate(
    {'CL1': {'interactions': 10,'replicates': 2},
     'CL2': {'interactions': 5,'replicates': 2}}) == (
    'CL1, CL2', '5.00, 2.50', '7.5000')
	assert candidate(
    {'Cell1': {'interactions': 50,'replicates': 10},
     'Cell2': {'interactions': 10,'replicates': 10}}
    ) == ('Cell1, Cell2', '5.00, 1.00', '6.0000')
	assert candidate({}) == ('', '', '0.0000')
	assert candidate(
    {'A': {'interactions': 1,'replicates': 1},
     'B': {'interactions': 1,'replicates': 1}}) == (
    'A, B', '1.00, 1.00', '2.0000')
	assert candidate(
    {'cell_line1': {'interactions': 10,'replicates': 10},
     'cell_line2': {'interactions': 10,'replicates': 10}}) == (
    'cell_line1, cell_line2', '1.00, 1.00', '2.0000')
	assert candidate(
    {'CCLE_BLCA': {'interactions': 1,'replicates': 1},
     'CCLE_BRCA': {'interactions': 1,'replicates': 1}}) == (
        'CCLE_BLCA, CCLE_BRCA', '1.00, 1.00', '2.0000')
	assert candidate(
    {'cell_line1': {'interactions': 0,'replicates': 10},
     'cell_line2': {'interactions': 0,'replicates': 10}}) == (
    'cell_line1, cell_line2', '0.00, 0.00', '0.0000')
	assert candidate(
    {'cell_line1': {'interactions': 0,'replicates': 10},
     'cell_line2': {'interactions': 10,'replicates': 10}}) == (
    'cell_line1, cell_line2', '0.00, 1.00', '1.0000')
	assert candidate(
    {
        'A': {'interactions': 0,'replicates': 5},
        'B': {'interactions': 20,'replicates': 2}
    }) == ('A, B', '0.00, 10.00', '10.0000')
def test_check():
	check(calc_hic_contacts)
