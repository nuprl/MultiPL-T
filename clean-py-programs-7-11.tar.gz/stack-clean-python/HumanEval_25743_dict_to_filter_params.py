def dict_to_filter_params(d, prefix=""):
    """ 
     Translate a dictionary of attributes to a nested set of parameters suitable for QuerySet filtering. For example:
     
     {
     "name": "Foo",
     "rack": {
     "facility_id": "R101"
     }
     }
     
     Becomes:
     
     {
     "name": "Foo",
     "rack__facility_id": "R101"
     }
     
     And can be employed as filter parameters:
     
     Device.objects.filter(**dict_to_filter(attrs_dict))
     """
	### Canonical solution below ###    
    params = {}
    for key, val in d.items():
        k = prefix + key
        if isinstance(val, dict):
            params.update(dict_to_filter_params(val, k + "__"))
        else:
            params[k] = val
    return params

### Unit tests below ###
def check(candidate):
	assert candidate(dict(name="Foo", rack=dict(facility_id=None)), prefix="bar__") == {
    "bar__name": "Foo",
    "bar__rack__facility_id": None
}
	assert candidate(dict(foo=dict(bar=dict(baz="boom", bam="bam")))) == {"foo__bar__baz": "boom", "foo__bar__bam": "bam"}
	assert candidate(
    {
        "name": "Foo",
        "rack": {
            "facility_id": "R101",
            "site": {
                "name": "London"
            }
        }
    }
) == {
    "name": "Foo",
    "rack__facility_id": "R101",
    "rack__site__name": "London"
}
	assert candidate(
    {"name": "Foo", "rack": {"facility_id": "R101"}}
) == {"name": "Foo", "rack__facility_id": "R101"}
	assert candidate(dict(name="Foo", rack=dict(facility_id="R101", name="Rack 1"))) == dict(name="Foo", rack__facility_id="R101", rack__name="Rack 1")
	assert candidate(dict(a=1, b=dict(c=3, d=dict(e=5)))) == dict(a=1, b__c=3, b__d__e=5)
	assert candidate(
    {
        "name": "Foo",
        "rack": {
            "facility_id": "R101"
        }
    }
) == {
    "name": "Foo",
    "rack__facility_id": "R101"
}
	assert candidate(dict(foo=1, bar=dict(baz=3, qux=4))) == dict(foo=1, bar__baz=3, bar__qux=4)
	assert candidate(dict(a=1, b=dict(c=2, d=3))) == dict(
    a=1,
    b__c=2,
    b__d=3
)
	assert candidate(
    {
        "name": "Foo",
        "rack": {
            "facility_id": "R101",
            "position": 2
        }
    }
) == {
    "name": "Foo",
    "rack__facility_id": "R101",
    "rack__position": 2
}
	assert candidate(dict()) == dict()
	assert candidate(dict(name="Foo")) == dict(name="Foo")
	assert candidate(dict(name="Foo", rack=dict(facility_id=None))) == {
    "name": "Foo",
    "rack__facility_id": None
}
	assert candidate(dict(foo="bar")) == {"foo": "bar"}
	assert candidate(
    {"a": "b", "c": {"d": "e", "f": {"g": "h"}}}
) == {"a": "b", "c__d": "e", "c__f__g": "h"}
	assert candidate(dict(a=1, b=2)) == dict(a=1, b=2)
	assert candidate(dict(name="foo", rack=dict(facility_id="R101"))) == dict(name="foo", rack__facility_id="R101")
	assert candidate(
    {
        "name": "Foo",
        "rack": {
            "facility_id": "R101",
            "site": {
                "slug": "foo-site"
            }
        }
    }
) == {
    "name": "Foo",
    "rack__facility_id": "R101",
    "rack__site__slug": "foo-site"
}
	assert candidate(dict(foo=1, bar=2)) == dict(foo=1, bar=2)
	assert candidate(dict(name="Foo", rack=dict(facility_id="R101"))) == dict(name="Foo", rack__facility_id="R101")
	assert candidate(dict(name="Foo", rack=dict(facility_id="R101"))) == {
    "name": "Foo",
    "rack__facility_id": "R101"
}
	assert candidate(dict(foo=dict(bar="baz"))) == {"foo__bar": "baz"}
	assert candidate(dict(
    name="Foo",
    rack=dict(facility_id="R101")
)) == {
    "name": "Foo",
    "rack__facility_id": "R101"
}
	assert candidate(
    {"name": "Foo", "rack": {"facility_id": "R101"}}) == {
        "name": "Foo",
        "rack__facility_id": "R101",
    }
	assert candidate(dict(a=1, b=dict(c=3, d=4))) == dict(a=1, b__c=3, b__d=4)
	assert candidate(dict(foo=dict(bar="baz", bam="boom"))) == {"foo__bar": "baz", "foo__bam": "boom"}
def test_check():
	check(dict_to_filter_params)
