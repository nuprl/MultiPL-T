def npasser(inbox, n=None):
    """
    Passes "n" first inputs from inbox. By default passes the whole inbox.

    Arguments:

      - n(``int``) [default: ``None``]
      
    """
    ### Canonical solution below ###
    return inbox[:n]


### Unit tests below ###
def check(candidate):
	assert candidate(inbox=[1,2,3,4,5], n=10) == [1,2,3,4,5]
	assert candidate(range(10), n=5) == range(5)
	assert candidate(range(10), 3) == range(3)
	assert candidate(range(10), 5) == range(5)
	assert candidate(range(10), 0) == range(0)
	assert candidate(range(10)) == range(10)
	assert candidate(range(100)) == range(100)
	assert candidate(range(10), n=None) == range(10)
	assert candidate(list(range(10)), 5) == list(range(5))
	assert candidate(range(100), 10) == range(10)
	assert candidate(range(10), 1000) == range(10)
	assert candidate(list(range(10)), -10) == []
	assert candidate(range(100), 1000) == range(100)
	assert candidate(range(100), 100) == range(100)
	assert candidate(range(10), 100) == range(10)
	assert candidate(range(100), 101) == range(100)
	assert candidate(range(10), n=100) == range(10)
	assert candidate(range(10), 15) == range(10)
	assert candidate(list(range(10)), 3) == list(range(3))
	assert candidate(range(10), None) == range(10)
	assert candidate(inbox=[1,2,3,4,5], n=3) == [1,2,3]
	assert candidate(range(10), 10) == range(10)
	assert candidate(list(range(10)), 0) == []
	assert candidate(range(10), 2) == range(2)
	assert candidate(range(10), 11) == range(10)
	assert candidate(list(range(10))) == list(range(10))
	assert candidate(inbox=[1,2,3,4,5]) == [1,2,3,4,5]
	assert candidate(range(100), None) == range(100)
def test_check():
	check(npasser)
