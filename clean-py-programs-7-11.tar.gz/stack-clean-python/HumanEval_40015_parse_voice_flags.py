def parse_voice_flags(flags):
    """Parses flags and returns a dict that represents voice playing state."""
    ### Canonical solution below ###
    # flags: [0-9]{8}
    if flags[0] == '0':
        return {'voice': 'stop'}
    else:
        return {'voice': {
            'number': int(flags[1:3]),
            'repeat': int(flags[4:6])
        }}


### Unit tests below ###
def check(candidate):
	assert candidate(
    '00000101'
) == {'voice':'stop'}
	assert candidate('00000000') == {'voice':'stop'}
	assert candidate(
    '00000001'
) == {'voice':'stop'}
	assert candidate(
    '00000002') == {'voice':'stop'}
	assert candidate(
    '00000100'
) == {'voice':'stop'}
	assert candidate(
    '00001111'
) == {'voice':'stop'}
	assert candidate(
    '00000011'
) == {'voice':'stop'}
	assert candidate(
    '00000000') == {'voice':'stop'}
	assert candidate(
    '00000011') == {'voice':'stop'}
	assert candidate(
    '00001011'
) == {'voice':'stop'}
	assert candidate(
    '00000008') == {'voice':'stop'}
	assert candidate(
    '00000005') == {'voice':'stop'}
	assert candidate(
    '00001001'
) == {'voice':'stop'}
	assert candidate(
    '00000000'
) == {
    'voice':'stop'
}
	assert candidate(flags='00000000') == {'voice':'stop'}
	assert candidate(
    '0'
) == {'voice':'stop'}
	assert candidate(
    '00000006') == {'voice':'stop'}
	assert candidate(
    '00000111'
) == {'voice':'stop'}
	assert candidate(
    '00000009') == {'voice':'stop'}
	assert candidate(
    '00010001'
) == {'voice':'stop'}
	assert candidate(
    '00000003') == {'voice':'stop'}
	assert candidate(
    '00001100'
) == {'voice':'stop'}
	assert candidate(
    '00000014') == {'voice':'stop'}
	assert candidate('0') == {'voice':'stop'}
	assert candidate(
    '00000001') == {'voice':'stop'}
	assert candidate(
    '00001101'
) == {'voice':'stop'}
	assert candidate(
    '00010000'
) == {'voice':'stop'}
	assert candidate(
    '00000012') == {'voice':'stop'}
	assert candidate(
    '00000004') == {'voice':'stop'}
	assert candidate(
    '00000010') == {'voice':'stop'}
	assert candidate(
    '00001000'
) == {'voice':'stop'}
	assert candidate(
    '00000000'
) == {'voice':'stop'}
	assert candidate(
    '00000013') == {'voice':'stop'}
	assert candidate(
    '00000007') == {'voice':'stop'}
def test_check():
	check(parse_voice_flags)
