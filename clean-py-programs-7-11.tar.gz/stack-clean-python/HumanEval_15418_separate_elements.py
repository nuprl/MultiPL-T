def separate_elements(list1, list2):
    """Check of different values of two lists"""
    ### Canonical solution below ###
    
    print(f"Liste 1: {len(list1)}")
    print(f"Liste 2: {len(list2)}")
    
    print("\n")
    print(f"Separate elements: ")
    
    return list(set(list1) ^ set(list2))


### Unit tests below ###
def check(candidate):
	assert candidate(list1 = [1, 2, 3, 4, 5], list2 = [1, 2, 3, 4, 5]) == []
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 2, 3, 4]) == []
	assert candidate(list1=[1, 2, 3, 4], list2=[2, 3, 4]) == [1]
	assert candidate(list1=[1, 2, 3, 4, 5], list2=[]) == [1, 2, 3, 4, 5]
	assert candidate(list1=[1, 2, 3, 4, 5], list2=[5, 5, 5, 5, 5]) == [1, 2, 3, 4]
	assert candidate(
    [1, 2, 3, 4],
    [3, 4, 5, 6]
) == [1, 2, 5, 6]
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 2, 4]) == [3]
	assert candidate(list1=[], list2=[1, 2, 3, 4]) == [1, 2, 3, 4]
	assert candidate(list1=[1, 2, 3, 4], list2=[]) == [1, 2, 3, 4]
	assert candidate(
    [1, 2, 3],
    [2, 4, 5]
) == [1, 3, 4, 5]
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 3, 4]) == [2]
	assert candidate(
    [1, 2, 3],
    [3, 4, 5, 2]
) == [1, 4, 5]
	assert candidate(
    [1, 2, 3],
    [3, 4, 5]
) == [1, 2, 4, 5]
	assert candidate(list1=[1, 2, 3, 4, 5], list2=[1, 2, 3, 4, 5]) == []
	assert candidate(
    [1, 2, 3, 4, 5, 6],
    [1, 2, 3]
) == [4, 5, 6]
	assert candidate(
    [1, 2, 3],
    [2, 3, 4]
) == [1, 4]
	assert candidate(
    [1, 2, 3],
    [1, 2, 3, 4, 5, 6]
) == [4, 5, 6]
	assert candidate(list1 = [1, 2, 3], list2 = [1, 2, 3, 4, 5, 6]) == [4, 5, 6]
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]
) == []
	assert candidate(list1=[1, 2, 3], list2=[2, 3, 4]) == [1, 4]
	assert candidate([], []) == []
	assert candidate(
    [1, 2, 3],
    [4, 5, 6]
) == [1, 2, 3, 4, 5, 6]
	assert candidate(list1 = [1, 2, 3, 4, 5, 6], list2 = [1, 2, 3]) == [4, 5, 6]
	assert candidate(list1 = [1, 2, 3], list2 = [1, 2, 3]) == []
	assert candidate(list1=[], list2=[]) == []
	assert candidate(
    [1, 2, 3, 4, 5, 6],
    [1, 2, 3, 4, 5, 6]
) == []
def test_check():
	check(separate_elements)
