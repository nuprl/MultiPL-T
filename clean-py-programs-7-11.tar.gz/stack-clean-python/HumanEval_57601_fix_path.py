def fix_path(path):
    """ Method fixes Windows path
     
     Args:
     none
     
     Returns:
     str
     
     """
	### Canonical solution below ###    
    
    path = path.replace('\\', '/')
    return path

### Unit tests below ###
def check(candidate):
	assert candidate(r'/home/user/test.py') == r'/home/user/test.py'
	assert candidate(r'C:\Program Files\Python37\Lib\site-packages') == r'C:/Program Files/Python37/Lib/site-packages'
	assert candidate(r'C:\Users\user\Desktop\folder') == r'C:/Users/user/Desktop/folder'
	assert candidate(r'Documents\My Documents') == r'Documents/My Documents'
	assert candidate(r'c:\tmp\test.txt') == 'c:/tmp/test.txt'
	assert candidate(r'C:\Program Files\Python37\Lib\site-packages\tests\test_candidate.pyc') == r'C:/Program Files/Python37/Lib/site-packages/tests/test_candidate.pyc'
	assert candidate(r'C:\Program Files\Python37') == r'C:/Program Files/Python37'
	assert candidate('C:\\Users\\Alex\\Desktop') == r'C:/Users/Alex/Desktop'
	assert candidate(r'C:\Users/admin\Desktop\test.txt') == r'C:/Users/admin/Desktop/test.txt'
	assert candidate(r'Documents/My Documents') == r'Documents/My Documents'
	assert candidate(r'C:\test\path') == r'C:/test/path'
	assert candidate(r'/C/Users/John/Desktop/file.txt') == r'/C/Users/John/Desktop/file.txt'
	assert candidate(r'/Users/Username/Desktop/file.txt') == r'/Users/Username/Desktop/file.txt'
	assert candidate(r'C:\Users\User\Desktop\test') == r'C:/Users/User/Desktop/test'
	assert candidate(r'C:\Python27\Lib\site-packages\requests\sessions.py') == 'C:/Python27/Lib/site-packages/requests/sessions.py'
	assert candidate(r'C:\Users\Username\Desktop') == r'C:/Users/Username/Desktop'
	assert candidate(r'/home/user/code/test.py') == '/home/user/code/test.py'
	assert candidate(r'/C:/') == r'/C:/'
	assert candidate(r'/home/user/Desktop/test') == r'/home/user/Desktop/test'
	assert candidate(r'C:\Users\User\Music') == r'C:/Users/User/Music'
	assert candidate(r'C:\temp\hello.txt') == r'C:/temp/hello.txt'
	assert candidate(r'C:/Users\User\Desktop/test') == r'C:/Users/User/Desktop/test'
	assert candidate(r'C:\Users\Alex\Desktop\file.txt') == r'C:/Users/Alex/Desktop/file.txt'
	assert candidate(r'C:/Users/Bernardo/Desktop/test/test/test/test') == 'C:/Users/Bernardo/Desktop/test/test/test/test'
	assert candidate(r'C:\Users\test\test2') == r'C:/Users/test/test2'
	assert candidate(r'C:/Users/User/Desktop/test') == r'C:/Users/User/Desktop/test'
	assert candidate(r'C:/Users/User\Desktop\test') == r'C:/Users/User/Desktop/test'
	assert candidate(r'C:\Program Files\Python37\Lib') == r'C:/Program Files/Python37/Lib'
	assert candidate(r'C:\Users/User\Desktop/test') == r'C:/Users/User/Desktop/test'
	assert candidate(r'/home/user/Desktop/folder/file.txt') == r'/home/user/Desktop/folder/file.txt'
	assert candidate(r'C:/Users/Bernardo/Desktop/test/test/test') == 'C:/Users/Bernardo/Desktop/test/test/test'
	assert candidate(r'/Users/Username/Desktop') == r'/Users/Username/Desktop'
	assert candidate(r'C:\Users\Dmitry\Downloads\file.txt') == r'C:/Users/Dmitry/Downloads/file.txt'
	assert candidate(r'C:/Users/Alex/Desktop/file.txt') == r'C:/Users/Alex/Desktop/file.txt'
	assert candidate(r'C:\Users\Bernardo\Desktop\test\test') == 'C:/Users/Bernardo/Desktop/test/test'
	assert candidate(r'c:\Windows\System32') == r'c:/Windows/System32'
	assert candidate(r'C:/Users/Alex/Desktop') == r'C:/Users/Alex/Desktop'
	assert candidate('C:\\Users\\Alex\\Desktop\\file.txt') == r'C:/Users/Alex/Desktop/file.txt'
	assert candidate(r'C:\Users\user\Desktop') == r'C:/Users/user/Desktop'
	assert candidate('/Users/Alex/Desktop/file.txt') == '/Users/Alex/Desktop/file.txt'
	assert candidate(r'c:\Users\user\code\test.py') == 'c:/Users/user/code/test.py'
	assert candidate(r'/temp/hello.txt') == r'/temp/hello.txt'
	assert candidate(r'C:\Users/admin/Desktop/test.txt') == r'C:/Users/admin/Desktop/test.txt'
	assert candidate(r'C:/Users/Bernardo/Desktop/test/test/test/') == 'C:/Users/Bernardo/Desktop/test/test/test/'
	assert candidate(r'C:/Users/username') == r'C:/Users/username'
	assert candidate(r'C:\Users\User1\Desktop\file.txt') == r'C:/Users/User1/Desktop/file.txt'
	assert candidate(r'C:/Users/Bernardo/Desktop/test/test') == 'C:/Users/Bernardo/Desktop/test/test'
	assert candidate(r'/Users/username') == r'/Users/username'
	assert candidate(r'C:\Users\user\Desktop\folder\file.txt') == r'C:/Users/user/Desktop/folder/file.txt'
	assert candidate(r'C:\Program Files\Python36\Lib') == r'C:/Program Files/Python36/Lib'
	assert candidate(r'C:\Documents\My Documents') == r'C:/Documents/My Documents'
	assert candidate(r'/C/Users/John/Desktop/file.txt/') == r'/C/Users/John/Desktop/file.txt/'
	assert candidate(r'/Users/username/Desktop/somefile.txt') == r'/Users/username/Desktop/somefile.txt'
	assert candidate(r'/test') == '/test'
	assert candidate(r'C:/Users/Bernardo/Desktop/test/test/') == 'C:/Users/Bernardo/Desktop/test/test/'
	assert candidate(r'C:\Users\user\test.py') == r'C:/Users/user/test.py'
	assert candidate('C:/Users/Alex/Desktop') == r'C:/Users/Alex/Desktop'
	assert candidate(r'/Users/Username') == r'/Users/Username'
	assert candidate(r'C:/Users\User/Desktop\test') == r'C:/Users/User/Desktop/test'
	assert candidate('/Users/Alex/Desktop') == '/Users/Alex/Desktop'
	assert candidate(r'/tmp/test.txt') == '/tmp/test.txt'
	assert candidate(r'C:\Users/User\Desktop\test') == r'C:/Users/User/Desktop/test'
	assert candidate(r'C:\Users\username') == r'C:/Users/username'
	assert candidate(r'C:/Documents/My Documents') == r'C:/Documents/My Documents'
	assert candidate(r'c:/test') == 'c:/test'
	assert candidate('C:/Users/Alex/Desktop/file.txt') == r'C:/Users/Alex/Desktop/file.txt'
	assert candidate(r'/usr/bin') == r'/usr/bin', "Should be '/usr/bin'"
	assert candidate(r'C:\Program Files\Python36') == r'C:/Program Files/Python36'
	assert candidate(r'/home/user/Downloads/file.txt') == r'/home/user/Downloads/file.txt'
	assert candidate(r'C:/Users/User1/Desktop/file.txt') == r'C:/Users/User1/Desktop/file.txt'
	assert candidate(r'C:/Users/Bernardo/Desktop/test/test/test/test/') == 'C:/Users/Bernardo/Desktop/test/test/test/test/'
	assert candidate(r'C:\Program Files\Python37\Lib\site-packages\tests\test_candidate.py') == r'C:/Program Files/Python37/Lib/site-packages/tests/test_candidate.py'
	assert candidate(r'c:\test') == 'c:/test'
	assert candidate(r'C:\Users\admin\Desktop\test.txt') == r'C:/Users/admin/Desktop/test.txt'
	assert candidate(r'C:\Program Files') == r'C:/Program Files'
	assert candidate(r'C:\Users\Alex\Desktop') == r'C:/Users/Alex/Desktop'
	assert candidate(r'c:\windows\system32') == r'c:/windows/system32', "Should be 'c:/windows/system32'"
	assert candidate(r'C:/test/path') == r'C:/test/path'
	assert candidate(r'C:\Users\Username\Desktop\file.txt') == r'C:/Users/Username/Desktop/file.txt'
	assert candidate(r'C:\Users\test') == r'C:/Users/test'
	assert candidate('C:\\Users\\Test\\file.txt') == 'C:/Users/Test/file.txt'
	assert candidate(r'C:test/path') == r'C:test/path'
	assert candidate(r'/home/user/Desktop') == r'/home/user/Desktop'
	assert candidate(r'/C:\Users/admin/Desktop/test.txt') == r'/C:/Users/admin/Desktop/test.txt'
	assert candidate(r'C:\Program Files\Python37\Lib\site-packages\tests') == r'C:/Program Files/Python37/Lib/site-packages/tests'
	assert candidate(r'C:/Users/admin/Desktop/test.txt') == r'C:/Users/admin/Desktop/test.txt'
	assert candidate(r'C:\Users\username\Desktop\somefile.txt') == r'C:/Users/username/Desktop/somefile.txt'
	assert candidate(r'c:/windows/system32') == r'c:/windows/system32', "Should be 'c:/windows/system32'"
	assert candidate(r'C:\Users\Username') == r'C:/Users/Username'
	assert candidate(r'C:\Users\User/Desktop\test') == r'C:/Users/User/Desktop/test'
	assert candidate(r'c:\Windows') == r'c:/Windows'
	assert candidate(r'/home/user/Desktop/folder') == r'/home/user/Desktop/folder'
	assert candidate(r'C:/') == r'C:/'
def test_check():
	check(fix_path)
