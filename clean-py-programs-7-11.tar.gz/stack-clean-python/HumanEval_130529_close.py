def close(session_attrs, fulfillment_state, message):
    """ 
     Close session in Lex.
     """
	### Canonical solution below ###    
    response = {
        'sessionAttributes': session_attrs,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': {'contentType': 'PlainText', 'content': message}
        }
    }

    return response

### Unit tests below ###
def check(candidate):
	assert candidate(None, None, None) == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': None,
       'message': {'contentType': 'PlainText', 'content': None}
    }
}
	assert candidate(
    session_attrs={},
    fulfillment_state='Fulfilled',
    message='Hello'
) == {
   'sessionAttributes': {},
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Fulfilled',
       'message': {'contentType': 'PlainText', 'content': 'Hello'}
    }
}
	assert candidate(None, 'Fulfilled', 'Hello') == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Fulfilled',
       'message': {'contentType': 'PlainText', 'content': 'Hello'}
    }
}
	assert candidate(
    {},
    'Fulfilled',
    'Bye'
) == {
   'sessionAttributes': {},
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Fulfilled',
       'message': {'contentType': 'PlainText', 'content': 'Bye'}
    }
}
	assert candidate(session_attrs={}, fulfillment_state='Fulfilled', message='test') == {
   'sessionAttributes': {},
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Fulfilled',
       'message': {'contentType': 'PlainText', 'content': 'test'}
    }
}
	assert candidate(
    {'a': 1},
    'Fulfilled',
    'Hello'
) == {
   'sessionAttributes': {'a': 1},
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Fulfilled',
       'message': {'contentType': 'PlainText', 'content': 'Hello'}
    }
}
	assert candidate(
    {'key1': 'value1'},
    'Fulfilled',
    'Hello world!'
) == {
   'sessionAttributes': {'key1': 'value1'},
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Fulfilled',
       'message': {'contentType': 'PlainText', 'content': 'Hello world!'}
    }
}
	assert candidate({}, 'Fulfilled', 'test message') == {
   'sessionAttributes': {},
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Fulfilled',
       'message': {'contentType': 'PlainText', 'content': 'test message'}
    }
}
	assert candidate(None, 'Failed', 'Hello') == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Close',
        'fulfillmentState': 'Failed',
       'message': {'contentType': 'PlainText', 'content': 'Hello'}
    }
}
def test_check():
	check(close)
