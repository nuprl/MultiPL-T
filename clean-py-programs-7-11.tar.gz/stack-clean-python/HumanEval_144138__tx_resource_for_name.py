def _tx_resource_for_name(name):
    """ Return the Transifex resource name """
	### Canonical solution below ###    
    if name == 'core':
        return "django-core.core"
    else:
        return "django-core.contrib-%s" % name

### Unit tests below ###
def check(candidate):
	assert candidate('contrib') == "django-core.contrib-contrib"
	assert candidate("databrowse") == "django-core.contrib-databrowse", candidate("databrowse")
	assert candidate('comments') == "django-core.contrib-comments"
	assert candidate('foobar') == "django-core.contrib-foobar"
	assert candidate(u'test') == "django-core.contrib-test", "Should have mapped 'test' to django-core.contrib-test"
	assert candidate(name='docs') == "django-core.contrib-docs"
	assert candidate('core') == "django-core.core"
	assert candidate('auth') == 'django-core.contrib-auth'
	assert candidate('contenttypes') == "django-core.contrib-contenttypes"
	assert candidate('auth') == "django-core.contrib-auth"
	assert candidate(name="auth") == "django-core.contrib-auth"
	assert candidate('admin') == "django-core.contrib-admin"
	assert candidate(name='auth') == "django-core.contrib-auth"
	assert candidate("foo") == "django-core.contrib-foo"
	assert candidate("messages") == "django-core.contrib-messages", candidate("messages")
	assert candidate(name='core') == "django-core.core"
	assert candidate('foobar') == "django-core.contrib-foobar", \
    "Did not match contrib project resource"
	assert candidate('core') == 'django-core.core'
	assert candidate("staticfiles") == "django-core.contrib-staticfiles", candidate("staticfiles")
	assert candidate("redirects") == "django-core.contrib-redirects", candidate("redirects")
	assert candidate('core') == "django-core.core", \
       "candidate('core') is wrong"
	assert candidate('django') == "django-core.contrib-django"
	assert candidate("syndication") == "django-core.contrib-syndication", candidate("syndication")
	assert candidate('docs') == 'django-core.contrib-docs', candidate('docs')
	assert candidate("core") == "django-core.core"
	assert candidate('core') == 'django-core.core', candidate('core')
	assert candidate("sites") == "django-core.contrib-sites", candidate("sites")
	assert candidate("admindocs") == "django-core.contrib-admindocs", candidate("admindocs")
	assert candidate('foo') == "django-core.contrib-foo"
	assert candidate(u'storage') == u'django-core.contrib-storage'
	assert candidate(u'core') == u'django-core.core'
	assert candidate(name='foo') == "django-core.contrib-foo"
	assert candidate("admin") == "django-core.contrib-admin", candidate("admin")
	assert candidate(name='core') == 'django-core.core'
	assert candidate("core") == "django-core.core", candidate("core")
	assert candidate(name="core") == "django-core.core"
	assert candidate(u'core') == "django-core.core", "Should have mapped 'core' to django-core.core"
	assert candidate(name='admin') == "django-core.contrib-admin"
	assert candidate("flatpages") == "django-core.contrib-flatpages", candidate("flatpages")
def test_check():
	check(_tx_resource_for_name)
