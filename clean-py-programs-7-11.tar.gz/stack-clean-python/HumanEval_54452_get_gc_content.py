def get_gc_content(sequence):
    """This function returns gc content for string sequence"""
    ### Canonical solution below ###
    return 100.0*len([base for base in sequence if base in "GC"])/len(sequence)


### Unit tests below ###
def check(candidate):
	assert candidate('T'*10000) == 0.0
	assert candidate('ACGT') == 50
	assert candidate('ACGTACGT') == 50
	assert candidate('A') == 0
	assert candidate('AG') == 50
def test_check():
	check(get_gc_content)
