def _make_sentence(txt):
    """ Make a sentence from a piece of text."""
	### Canonical solution below ###    
    # Make sure first letter is capitalized
    txt = txt.strip(' ')
    txt = txt[0].upper() + txt[1:] + '.'
    return txt

### Unit tests below ###
def check(candidate):
	assert candidate(
    "hello; world"
) == "Hello; world."
	assert candidate('A B') == 'A B.'
	assert candidate(
    "This is a test sentence") == "This is a test sentence."
	assert candidate('hello world ') == 'Hello world.'
	assert candidate('a b c ') == 'A b c.'
	assert candidate('a') == 'A.'
	assert candidate(
    "hello\" world"
) == "Hello\" world."
	assert candidate(' a b c ') == 'A b c.'
	assert candidate(
    "this is a short sentence") == "This is a short sentence."
	assert candidate(
    'This is a sentence.')!= 'this is a sentence'
	assert candidate('a b ') == 'A b.'
	assert candidate(
    'this is a test sentence') == 'This is a test sentence.'
	assert candidate(
    'This is a sentence.')!= 'This is a sentence'
	assert candidate(txt='hello world') == 'Hello world.'
	assert candidate(u'Hello, world') == u'Hello, world.'
	assert candidate(
    "hello world"
) == "Hello world."
	assert candidate(
    "this is a test sentence") == "This is a test sentence."
	assert candidate(
        "this is a test sentence") == "This is a test sentence."
	assert candidate('a b') == 'A b.'
	assert candidate(
    'this is a sentence') == 'This is a sentence.'
	assert candidate(' a b') == 'A b.'
	assert candidate(' hello ') == 'Hello.'
	assert candidate(txt="Hello world") == "Hello world."
	assert candidate(
    "hello, world"
) == "Hello, world."
	assert candidate(
    "hello: world"
) == "Hello: world."
	assert candidate(
    "hello. world"
) == "Hello. world."
	assert candidate(' hello world ') == 'Hello world.'
	assert candidate(
    "hello— world"
) == "Hello— world."
	assert candidate(
    "the quick brown fox jumped over the lazy dog") == \
    "The quick brown fox jumped over the lazy dog."
	assert candidate("the lazy dog") == "The lazy dog."
	assert candidate(txt='a short sentence') == 'A short sentence.'
	assert candidate(' a b c') == 'A b c.'
	assert candidate(u'hello world') == u'Hello world.'
	assert candidate(
    "hello- world"
) == "Hello- world."
	assert candidate(
    'This is a test sentence') == 'This is a test sentence.'
	assert candidate(u'hello! world') == u'Hello! world.'
	assert candidate('A') == 'A.'
	assert candidate(
    "hello' world"
) == "Hello' world."
	assert candidate(
    "this is a test") == "This is a test."
	assert candidate('A B C') == 'A B C.'
	assert candidate(
    'The quick brown fox jumps over the lazy dog'
) == 'The quick brown fox jumps over the lazy dog.'
	assert candidate(
    "hello? world"
) == "Hello? world."
	assert candidate(u'hello? world') == u'Hello? world.'
	assert candidate(
    "This is a test") == "This is a test."
	assert candidate(' a b ') == 'A b.'
	assert candidate('hello') == 'Hello.'
	assert candidate(txt="hello world") == "Hello world."
	assert candidate(u'hello. world') == u'Hello. world.'
	assert candidate('a b c') == 'A b c.'
	assert candidate(u'hello, world... world') == u'Hello, world... world.'
	assert candidate(
    "hello! world"
) == "Hello! world."
	assert candidate(u'hello, world') == u'Hello, world.'
	assert candidate(
    'This is a sentence.')!= 'This is a sentence.'
	assert candidate(u'first') == u'First.'
	assert candidate(u'First') == u'First.'
	assert candidate(
    'This is a sentence.')!= 'this is a sentence.'
	assert candidate('hello world') == 'Hello world.'
def test_check():
	check(_make_sentence)
