def is_equal_lists(list1, list2):
    """
    Function for checking if list1 and list2 equal.
    :param list1: list
        First list for checking.
    :param list2: list
        Second list for checking.
    :return:
        True if equal, False otherwise.
    """
    ### Canonical solution below ###
    if not isinstance(list1, list) or not isinstance(list2, list):
        raise TypeError
    for elem1 in list1:
        flag = False
        for i, elem2 in enumerate(list2):
            if list2[i] == elem1:
                del list2[i]
                flag = True
                break
        if not flag:
            return False
    return not list2


### Unit tests below ###
def check(candidate):
	assert not candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 4]
)
	assert not candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 3, 5]
)
	assert candidate(list(range(10)), list(range(5, 15))) == False
	assert candidate(list1=[1, 2, 3], list2=[3, 2, 1])
	assert candidate(list1=[], list2=[1]) is False
	assert candidate([1, 2, 3, 4, 5], [1, 2, 3, 4, 5])
	assert candidate(list1=[1, 2, 3], list2=[1, 2, 3, 4]) == False
	assert not candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 4, 5]
)
	assert candidate(list(range(10)), list(range(10, 20))) == False
	assert candidate(list(range(10)), list(range(20))) == False
	assert candidate(
    [1, 2, 3, 4, 5],
    []
) == False
	assert candidate(list(range(10)), list(range(1, 10))) == False
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 4]
) == True
	assert candidate(
    [1, 1, 1, 1],
    [1, 1, 1, 1]
) is True
	assert not candidate(
    [1, 2, 3, 4, 5, 6],
    [1, 2, 3, 4, 5, 6, 7]
)
	assert candidate([1, 2, 3, 4], [1, 2, 3, 5]) == False
	assert candidate(
    [1, 2, 3],
    [1, 3, 2]
)
	assert candidate(list(range(10)), list(range(0, 9))) == False
	assert not candidate(list(), [1])
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]
) == True
	assert candidate(list(range(10)), list(range(-1, 11))) == False
	assert candidate(list(range(10)), list(range(10))) == True
	assert candidate(
    ['a', 'b', 'c'],
    ['b']
) == False
	assert candidate([1, 2, 3], [1, 2, 4]) == False
	assert candidate([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6])
	assert candidate(
    [],
    [1, 2, 3, 4, 5]
) == False
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 2, 3, 4]) is True
	assert not candidate(list1=[1, 2, 3], list2=[1, 2])
	assert candidate([1, 1, 1], [1]) == False
	assert candidate(list(range(10)), list(range(1, 11))) == False
	assert candidate([1, 2, 3], [1, 2, 3]) == True
	assert candidate([1, 2, 3, 4], [4, 3, 2, 5]) == False
	assert candidate(list(range(10)), list(range(10)))
	assert candidate([1, 2], [1]) == False
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 2, 3, 3]) is False
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5]
) == True
	assert candidate(
    [1, 2, 3],
    [1, 2, 3, 4]
) == False
	assert candidate(
    [1, 2, 3],
    [3, 2]
) == False
	assert candidate([1, 2, 3, 4], [1, 2, 3, 4])
	assert candidate([1, 2, 3, 4], [1, 2, 3, 4, 5]) == False
	assert not candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5, 6, 7]
)
	assert not candidate([1, 2, 3], [1, 2, 3, 4, 5])
	assert candidate(
    ['a', 'b', 'c'],
    ['c']
) == False
	assert not candidate([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 7])
	assert candidate([1], [1, 1, 1]) == False
	assert not candidate(list1=[1, 2, 3], list2=[1, 2, 3, 4])
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5]
)
	assert candidate(list(range(10)), list(range(1, 5))) == False
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 2, 3]) is False
	assert candidate(list(range(10)), list(range(100))) == False
	assert candidate(
    ["a", "b", "c"],
    ["a", "b", "c"]
)
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b', 'c']
) == True
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 4, 5]
) is False
	assert not candidate([1, 2, 3], [1, 2, 4])
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b', 'c', 'b', 'c', 'c', 'd']
) == False
	assert candidate([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]) == True
	assert not candidate(list1=[1, 2, 3], list2=[1, 2, 4])
	assert candidate(
    [1, 2, 3],
    [1, 2, 3, 4]
) is False
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 2, 3, 4, 5]) is False
	assert candidate([1, 2], [1, 2]) == True
	assert candidate(list1=[], list2=[]) is True
	assert candidate(list(range(10)), list(range(0, 11))) == False
	assert candidate([1, 2, 3, 4], [1, 2, 3]) == False
	assert candidate(
    ['a', 'b', 'c'],
    ['a']
) == False
	assert candidate([1, 2], [1, 2])
	assert not candidate([1, 2, 3], [1, 2])
	assert not candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
)
	assert candidate(
    [1, 2, 3],
    [1, 2, 3, 2, 3]
) == False
	assert candidate(
    [1, 2, 3],
    [1, 2, 4]
) is False
	assert candidate([1, 2, 3, 4], [4, 3, 2, 1]) == True
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 4]
)
	assert candidate([1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6]) == False
	assert candidate([1, 2, 3], [3, 2, 1]) == True
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]
) is True
	assert candidate(list(range(10)), list(range(-1, 10))) == False
	assert candidate(list1=[1, 2, 3, 4], list2=[1, 2, 4, 3]) is True
	assert candidate(
    [1, 2, 3],
    [3, 2, 1]
) == True
	assert candidate([1, 2], [1, 2, 3]) == False
	assert candidate(list(), list())
	assert not candidate(
    ["a", "b", "c"],
    ["c", "b", "a", "d"]
)
	assert candidate(list1=[1, 2, 3], list2=[1, 2, 3]) == True
	assert candidate(
    [1, 2, 3, 4, 5, 6],
    [1, 2, 3, 4, 5]
) is False
	assert not candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4]
)
	assert not candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
)
	assert not candidate([1, 2, 3, 4, 5], [1, 2, 3, 4, 6])
	assert candidate(list1=[1, 2, 3], list2=[1, 2, 3, 4]) is False
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5, 6]
) == False
	assert not candidate([1, 2, 3, 4], [1, 2, 3, 5])
	assert candidate(
    ['a', 'b', 'c'],
    ['b', 'c']
) == False
	assert candidate([], []) == True
	assert candidate(list1=[1, 2, 3], list2=[1, 2, 3])
	assert not candidate([1], list())
	assert candidate([], [1, 2, 3]) == False
	assert candidate(list1=[1, 2, 3], list2=[1, 2]) == False
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4]
) == False
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
)
	assert candidate([], [])
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3]
) == False
	assert candidate([1, 1], [1, 1]) == True
	assert not candidate([1, 2], [1, 3])
	assert candidate(
    [1],
    [1]
) is True
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b', 'd']
) == False
	assert candidate(list1=[1, 2, 3, 4, 5], list2=[1, 2, 3, 6]) is False
	assert candidate(list(range(10)), list(range(11, 20))) == False
	assert candidate(
    ['a', 'b', 'c'],
    []
) == False
	assert candidate([1, 2, 3], [1, 3, 2])
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 4, 5]
) == False
	assert candidate(list(range(10)), list(range(5, 10))) == False
	assert not candidate([1], [])
	assert candidate(
    [],
    []
) is True
	assert candidate([1, 2, 3], [1, 2, 3, 3]) == False
	assert candidate(
    ["a", "b", "c"],
    ["c", "b", "a"]
)
	assert candidate(
    [1, 2, 3, 4, 5, 6],
    [1, 2, 3, 4, 5, 6]
)
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b', 'c', 'd']
) == False
	assert candidate(
    [1, 2, 3],
    [1, 2, 3, 2]
) == False
	assert candidate([1, 2, 3], []) == False
	assert candidate([1, 2, 3, 4, 5], [1, 2, 3, 4]) == False
	assert candidate([1], [1]) == True
	assert candidate(list1=[1, 2, 3], list2=[1, 2]) is False
	assert not candidate(
    [1, 2, 3],
    [1, 3, 2, 4]
)
	assert candidate([1, 2, 3], [1, 2, 3, 4]) == False
	assert not candidate([], [1])
	assert not candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 6]
)
	assert not candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 11]
)
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b']
) == False
	assert candidate([1, 2, 3, 4], [4, 3, 2]) == False
	assert candidate([1, 2, 3], [1, 2, 3])
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4]
) is False
	assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == True
	assert candidate(
    [1, 2, 3, 4, 5],
    [5, 4, 3, 2, 1, 0]
) == False
	assert candidate(list1=[1, 2, 3], list2=[1, 2, 3]) is True
	assert candidate(
    [1, 2, 3, 4, 5, 6],
    [6, 5, 4, 3, 2, 1]
)
	assert not candidate([1, 2, 3], [1, 2, 3, 4])
	assert candidate(
    [],
    []
) == True
	assert candidate(list1=[1, 2], list2=[1, 2, 3]) is False
	assert not candidate([1, 2], [1])
	assert not candidate([1], [2, 1])
	assert candidate(list(range(10)), list(range(10, 15))) == False
	assert candidate(list(), list()) == True
	assert candidate(list1=[1, 2, 3], list2=[1, 2, 4]) == False
	assert not candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5, 7]
)
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3]
) is False
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]
)
	assert not candidate([1], [2])
	assert not candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5, 6]
)
	assert candidate([1], [1])
	assert candidate(
    [1, 2, 3],
    [3, 2, 1, 2]
) == False
	assert candidate(
    [1, 1, 1, 1],
    [1, 1, 1]
) is False
	assert not candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    [1, 2, 3, 4, 5, 6, 7, 8, 9]
)
def test_check():
	check(is_equal_lists)
