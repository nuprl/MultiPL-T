def _from_quoted_string(quoted):
    """ Strip quotes"""
	### Canonical solution below ###    
    return quoted.strip('"').replace('""', '"')

### Unit tests below ###
def check(candidate):
	assert candidate(r'"aaa\032aaa"') == r'aaa\032aaa'
	assert candidate(r'"aaaaaaaaaaa"') == 'aaaaaaaaaaa'
	assert candidate(r'"a"') == 'a'
	assert candidate(r'"a""b""c"') == 'a"b"c'
	assert candidate(r'"foo \v bar"') == r'foo \v bar'
	assert candidate(r'"foo \n bar"') == r'foo \n bar'
	assert candidate(r'"aaa\naaa"') == r'aaa\naaa'
	assert candidate(r'"aaaaaaaaaaaaa"') == 'aaaaaaaaaaaaa'
	assert candidate(r'"foo \' bar"') == r'foo \' bar'
	assert candidate(r'"abc"') == "abc"
	assert candidate(r'"foo \f bar"') == r'foo \f bar'
	assert candidate(r'""') == ''
	assert candidate(r'"aaaa"') == 'aaaa'
	assert candidate(r'"this') == 'this'
	assert candidate(r'"ab""c"') == 'ab"c'
	assert candidate(r'"aaaaaaaaaa"') == 'aaaaaaaaaa'
	assert candidate(r'"foo \x01 bar"') == r'foo \x01 bar'
	assert candidate(r'"aaaaaaaaaaaa"') == 'aaaaaaaaaaaa'
	assert candidate(r'"aaaaaa"') == 'aaaaaa'
	assert candidate(r'"foo \" bar"') == r'foo \" bar'
	assert candidate(r'"foo "" bar"') == 'foo " bar'
	assert candidate(r'"foo \x00 bar"') == r'foo \x00 bar'
	assert candidate(r'"foo \t bar"') == r'foo \t bar'
	assert candidate(r'"abc"') == 'abc'
	assert candidate(r'"aaaaaaaaaaaaaa"') == 'aaaaaaaaaaaaaa'
	assert candidate(r'"foo \b bar"') == r'foo \b bar'
	assert candidate(r'"aaaaaaaaaaaaaaaaaaa"') == 'aaaaaaaaaaaaaaaaaaa'
	assert candidate(r'"aaaaaaaaaaaaaaaaa"') == 'aaaaaaaaaaaaaaaaa'
	assert candidate(r'"foo \a bar"') == r'foo \a bar'
	assert candidate(r'"foo\rbar"') == r'foo\rbar'
	assert candidate(r'"abc def"') == 'abc def'
	assert candidate(r'"foo \r bar"') == r'foo \r bar'
	assert candidate(r'"aaaaaaaaa"') == 'aaaaaaaaa'
	assert candidate(r'"aaa\000aaa"') == r'aaa\000aaa'
	assert candidate(r'"aaaaaaaaaaaaaaa"') == 'aaaaaaaaaaaaaaa'
	assert candidate(r'"a""b"') == 'a"b'
	assert candidate(r'"foo"') == "foo"
	assert candidate(r'"foo""bar"') == "foo\"bar"
	assert candidate(r'"Hello"') == "Hello"
	assert candidate(r'"aa"') == 'aa'
	assert candidate(r'"aaa"') == 'aaa'
	assert candidate(r'"foo"') == 'foo'
	assert candidate(r'"foo \x1f bar"') == r'foo \x1f bar'
	assert candidate(r'"ab""cd"') == 'ab"cd'
	assert candidate(r'"\134"') == r'\134'
	assert candidate(r'"this""that""this"') == 'this"that"this'
	assert candidate(r'"foo\fbar"') == r'foo\fbar'
	assert candidate(r'"foo\tbar"') == r'foo\tbar'
	assert candidate(r'"aaaaaaa"') == 'aaaaaaa'
	assert candidate(r'"aaaaaaaaaaaaaaaaaa"') == 'aaaaaaaaaaaaaaaaaa'
	assert candidate(r'"foo\"bar"') == r'foo\"bar'
	assert candidate(r'"aaaaaaaaaaaaaaaa"') == 'aaaaaaaaaaaaaaaa'
	assert candidate(r'"this""that"') == 'this"that'
	assert candidate(r'"this"') == 'this'
	assert candidate(r'"aaaaaaaa"') == 'aaaaaaaa'
	assert candidate(r'"foo""bar"') == 'foo"bar'
	assert candidate(r'"foo\nbar"') == r'foo\nbar'
	assert candidate(r'"foo \x20 bar"') == r'foo \x20 bar'
	assert candidate(r'"aaaaa"') == 'aaaaa'
	assert candidate(r'"aaaaaaaaaaaaaaaaaaaa"') == 'aaaaaaaaaaaaaaaaaaaa'
def test_check():
	check(_from_quoted_string)
