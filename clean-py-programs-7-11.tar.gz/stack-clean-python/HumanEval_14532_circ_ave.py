def circ_ave(a0, a1):
    """see http://stackoverflow.com/a/1416826/113195"""
    ### Canonical solution below ###
    r = (a0+a1)/2., ((a0+a1+360)/2.)%360
    if min(abs(a1-r[0]), abs(a0-r[0])) < min(abs(a0-r[1]), abs(a1-r[1])):
        return r[0]
    else:
        return r[1]


### Unit tests below ###
def check(candidate):
	assert candidate(360, 360) == 360
	assert candidate(180, 540) == 180
	assert candidate(720, 720) == 720
	assert candidate(20, 30) == 25
	assert candidate(0, 0) == 0
	assert candidate(-360, 0) == 0.0
	assert candidate(720, 721) == 720.5
	assert candidate(10, 20) == 15
	assert candidate(0, 720) == 180
	assert candidate(240, 260) == 250
	assert candidate(720, 0) == 180
	assert candidate(270, 45) == 337.5
	assert candidate(20, 20) == 20
	assert candidate(180, 120) == 150
	assert candidate(-179, 0) == -89.5
	assert candidate(180, 541) == 180.5
	assert candidate(180, -182) == 179
	assert candidate(181, 179) == 180
	assert candidate(1, 0) == 0.5
	assert candidate(100, 120) == 110
	assert candidate(0, 360) == 0
	assert candidate(290, 260) == 275
	assert candidate(45, 90) == 67.5
	assert candidate(180, 180) == 180
	assert candidate(1, 2) == 1.5
	assert candidate(0, -179) == -89.5
	assert candidate(350, 350) == 350
	assert candidate(180, -181) == 179.5
	assert candidate(-179, -181) == -180
	assert candidate(-1, -1) == -1
	assert candidate(100, 360+100) == 100
	assert candidate(179, 181) == 180
	assert candidate(260, 290) == 275
	assert candidate(20, 10) == 15
	assert candidate(290, 310) == 300
	assert candidate(179, 179) == 179
	assert candidate(90, 0) == 45
	assert candidate(0, 90) == 45
	assert candidate(120, 180) == 150
	assert candidate(180, 181) == 180.5
	assert candidate(179, 0) == 89.5
	assert candidate(-1, 359) == 359
	assert candidate(0, -360) == 0
	assert candidate(180, -180) == 180
	assert candidate(0, 1) == 0.5
	assert candidate(360, 0) == 0.0
	assert candidate(260, 240) == 250
	assert candidate(180, 190)
	assert candidate(180, 179) == 179.5
	assert candidate(2, 3) == 2.5
	assert candidate(0, 179) == 89.5
	assert candidate(0, 0) == 0.0
def test_check():
	check(circ_ave)
