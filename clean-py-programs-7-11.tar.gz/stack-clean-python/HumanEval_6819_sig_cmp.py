def sig_cmp(u, v, O):
    """ 
     Compare two signatures by extending the term order to K[X]^n.
     
     u < v iff
     - the index of v is greater than the index of u
     or
     - the index of v is equal to the index of u and u[0] < v[0] w.r.t. O
     
     u > v otherwise
     """
	### Canonical solution below ###    
    if u[1] > v[1]:
        return -1
    if u[1] == v[1]:
        #if u[0] == v[0]:
        #    return 0
        if O(u[0]) < O(v[0]):
            return -1
    return 1

### Unit tests below ###
def check(candidate):
	assert candidate( (1, 0), (0, 1), lambda x: x ) == 1
	assert candidate( (2, 1), (1, 1), lambda x: x) == 1
	assert candidate(("b", 0), ("a", 1), lambda x: "a" if x == "" else x) == 1
	assert candidate( (0, 1), (1, 0), lambda x: x ) == -1
	assert candidate( (1, 2), (2, 1), lambda x: x) == -1
	assert candidate( (1, 2), (2, 2), lambda x: x) == -1
	assert candidate(tuple([2, 0]), tuple([1, 0]), lambda x: x) == 1
	assert candidate( (1, 1), (1, 2), lambda x: x) == 1
	assert candidate(("", 0), ("a", 0), lambda x: x) == -1
	assert candidate( (1, 2), (2, 1), lambda x: -x ) == -1
	assert candidate( (1, 0), (0, 0), lambda x: x ) == 1
	assert candidate( (1, 1), (2, 1), lambda t : t ) < 0
	assert candidate( (3, 0, 2), (3, 1, 2), lambda x: x) == 1
	assert candidate( (3, 0, 2), (3, 1, 3), lambda x: x) == 1
	assert candidate( (0, 0), (1, 0), lambda x: x ) == -1
	assert candidate( (2, 2), (1, 2), lambda t : t ) > 0
	assert candidate( (1, 1), (2, 1), lambda x: x) == -1
	assert candidate( (2, 1), (1, 2), lambda x: -x ) == 1
	assert candidate( (2, 1), (1, 1), lambda t : t ) > 0
	assert candidate( (2, 1), (1, 2), lambda x: x) == 1
def test_check():
	check(sig_cmp)
