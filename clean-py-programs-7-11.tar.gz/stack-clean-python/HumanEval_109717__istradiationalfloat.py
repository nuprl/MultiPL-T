def _istradiationalfloat(value):
    """ 
     Checks if the string can be converted to a floating point value
     Does not allow for fortran style floats, i.e -2.34321-308
     only standard floats.
     """
	### Canonical solution below ###    
    try:
        float(value)
        return True
    except ValueError:
        return False

### Unit tests below ###
def check(candidate):
	assert not candidate("1.2-3")
	assert candidate(1.0E10)
	assert candidate(0.00001) == True
	assert candidate(-1)
	assert candidate('12345.56789') == True
	assert candidate('1.2e5') == True
	assert candidate('10f10') == False
	assert candidate('1.0D15') == False
	assert candidate('-1.0e-10') == True
	assert candidate('10.0e10F10') == False
	assert candidate("123") == True
	assert candidate('1.2d5') == False
	assert candidate('10F10') == False
	assert candidate('1.2d5e10') == False
	assert candidate('-12345.56789') == True
	assert candidate('10e+10') == True
	assert candidate('-1e10') == True
	assert candidate('10.0e10e10') == False
	assert not candidate('1.2+3j')
	assert not candidate('1.0D10')
	assert candidate('1.0') == True
	assert candidate('10.0d10') == False
	assert not candidate('12345.6E2+308')
	assert candidate('10.1d5e10') == False
	assert candidate('-1.0e10') == True
	assert candidate(1.2)
	assert candidate("1") == True
	assert candidate(0.0) == True
	assert not candidate('12345.6E2-307')
	assert not candidate('1.0-10')
	assert candidate(1.0E-100)
	assert candidate('-1.') == True
	assert not candidate('12345.6E2+307')
	assert candidate(-1.23456e-3) == True
	assert not candidate('1.0+10')
	assert not candidate('12345.6E+2+308')
	assert candidate('1.') == True
	assert candidate(12345) == True
	assert candidate(-1.0003e-30) == True
	assert candidate('0.3') == True
	assert candidate(1.234e-10)
	assert candidate('10e-10') == True
	assert candidate("1.D-10") == False
	assert not candidate('1.0d10')
	assert candidate(-123.456) == True
	assert candidate(1e-10) == True
	assert candidate(10) == True
	assert candidate(-1.0e-15) == True
	assert candidate('-1.0') == True
	assert candidate(1) == True
	assert candidate('-1e-10') == True
	assert candidate("1.0e-10") == True
	assert candidate(123.456e-20) == True
	assert candidate(1.2345) == True
	assert candidate('10.0F10') == False
	assert candidate(1.0e-308)
	assert not candidate('12345.6E+2-307')
	assert candidate('10.0D10') == False
	assert candidate('10.134321-308') == False
	assert candidate(12345.6E+2)
	assert candidate(10.0) == True
	assert candidate('1.2345D-3') == False
	assert candidate("1.0000") == True
	assert candidate(12345.6)
	assert candidate(1.23456e+308) == True
	assert not candidate('12345.6E-2-307')
	assert not candidate('12345.6E-2-308')
	assert candidate(12345.6E2)
	assert candidate("123.456e-20") == True
	assert candidate('10') == True
	assert candidate(-12345.6)
	assert candidate(-2.34321e+308)
	assert candidate(1)
	assert candidate(-1.23456) == True
	assert candidate("0.000000000000001") == True
	assert candidate('10.0e10.0') == False
	assert candidate("123.456+308") == False
	assert candidate(1.23456) == True
	assert candidate(1.0)
	assert candidate(1.0e-309)
	assert candidate('10d10') == False
	assert candidate(3.45e-30) == True
	assert candidate(1.0e+309)
	assert candidate("123.456d308") == False
	assert candidate(1.23456e+3) == True
	assert candidate('10D10') == False
	assert candidate("1.0D-10") == False
	assert candidate(-12345.6E+2)
	assert candidate(-1.0) == True
	assert candidate("123.456") == True
	assert not candidate('1.0d-10')
	assert candidate('10.0e-10') == True
	assert candidate(-2.34321-308)
	assert candidate(1.234)
	assert candidate('-0.3') == True
	assert candidate(1.0e+308)
	assert candidate(123) == True
	assert candidate("1D0-10") == False
	assert candidate(12345)
	assert candidate(-12345.6E-2)
	assert candidate(.3e-4) == True
	assert candidate('10.1d5') == False
	assert candidate('1.234321-308') == False
	assert candidate('10.0e10f10') == False
	assert candidate(1.2) == True
	assert candidate('10.0e10D10') == False
	assert candidate(.3) == True
	assert candidate("1.0") == True
	assert not candidate('1.0D-10')
	assert candidate('10.1e5') == True
	assert candidate(-1.234)
	assert candidate(-1.234e-10)
	assert candidate("123.456-308") == False
	assert candidate(123.456) == True
	assert candidate(3.45) == True
	assert candidate('1.2345D+3') == False
	assert not candidate('12345.6E2-308')
	assert candidate("1")
	assert candidate(1.0E100)
	assert candidate(1.0e-15) == True
	assert candidate(1.0e15) == True
	assert candidate('1') == True
	assert candidate(-1.23456e-308) == True
	assert candidate(1.0E-10)
	assert candidate(-12345.6E2)
	assert candidate("1.0eD-10") == False
	assert not candidate('12345.6E-2+308')
	assert candidate('12345') == True
	assert candidate(1.0) == True
	assert not candidate('12345.6E+2-308')
	assert candidate(-1.0e15) == True
	assert candidate('1.2') == True
	assert candidate('10.0f10') == False
	assert candidate('10.0') == True
	assert candidate('10.0e+10') == True
	assert candidate(1.0e-10) == True
	assert candidate('10.0e-10d10') == False
	assert candidate('10.1') == True
	assert candidate(1.) == True
	assert candidate(12345.6E-2)
def test_check():
	check(_istradiationalfloat)
