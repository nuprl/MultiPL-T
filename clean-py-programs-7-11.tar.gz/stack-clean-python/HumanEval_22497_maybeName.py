def maybeName(obj):
    """ Returns an object's __name__ attribute or it's string representation.

    @param obj any object
    @return obj name or string representation
    """
    ### Canonical solution below ###
    try:
        return obj.__name__
    except (AttributeError, ):
        return str(obj)


### Unit tests below ###
def check(candidate):
	assert candidate(True) == 'True'
	assert candidate(int) == 'int'
	assert candidate(1.2) == '1.2'
	assert candidate(42) == '42'
	assert candidate(None) == str(None)
	assert candidate(list) == 'list'
	assert candidate(candidate) =='candidate'
	assert candidate(3) == '3'
	assert candidate(object) == 'object'
	assert candidate('foo') == 'foo'
	assert candidate(object().__class__) == 'object'
	assert candidate(None) == "None"
	assert candidate(type) == 'type'
	assert candidate(set) =='set'
	assert candidate('string') =='string'
	assert candidate(Exception) == 'Exception'
	assert candidate(1.0) == "1.0"
	assert candidate(False) == "False"
	assert candidate(bytes) == 'bytes'
	assert candidate(1) == "1"
	assert candidate("Hello") == "Hello"
	assert candidate(1.23) == '1.23'
	assert candidate(str) =='str'
	assert candidate(1) == str(1)
	assert candidate(lambda: None) == '<lambda>'
	assert candidate("1") == "1"
	assert candidate(memoryview) =='memoryview'
	assert candidate('abc') == 'abc'
	assert candidate(BaseException) == 'BaseException'
	assert candidate(bytearray) == 'bytearray'
	assert candidate('a') == 'a'
	assert candidate(1.0) == '1.0'
	assert candidate(False) == 'False'
	assert candidate(u'1.2') == u'1.2'
	assert candidate(candidate) == "candidate"
	assert candidate(5) == '5'
	assert candidate(123) == '123'
	assert candidate(u'unicode') == 'unicode'
	assert candidate(1) == '1'
	assert candidate(type(1)) == 'int'
	assert candidate('1.2') == '1.2'
	assert candidate(None) == 'None'
	assert candidate('1.1') == '1.1'
	assert candidate(candidate.__name__) == "candidate"
	assert candidate(lambda x: x) == "<lambda>"
	assert candidate('name') == 'name'
	assert candidate(True) == "True"
	assert candidate('Hello') == 'Hello'
	assert candidate(set()) == "set()"
	assert candidate('42') == '42'
	assert candidate(frozenset) == 'frozenset'
	assert candidate(object.mro) =='mro'
	assert candidate(dict) == 'dict'
	assert candidate(tuple) == 'tuple'
	assert candidate(0) == '0'
	assert candidate(1.1) == '1.1'
	assert candidate(object()) == "<object object at 0x%x>" % id(object())
	assert candidate(lambda x: x) == '<lambda>'
def test_check():
	check(maybeName)
