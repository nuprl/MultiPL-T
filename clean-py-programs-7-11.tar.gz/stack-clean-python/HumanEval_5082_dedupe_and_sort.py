def dedupe_and_sort(sequence, first=None, last=None):
    """ 
     De-dupe and partially sort a sequence.
     
     The `first` argument should contain all the items that might appear in
     `sequence` and for which the order (relative to each other) is important.
     
     The `last` argument is the same, but matching items will be placed at the
     end of the sequence.
     
     For example, `INSTALLED_APPS` and `MIDDLEWARE_CLASSES` settings.
     
     Items from `first` will only be included if they also appear in `sequence`.
     
     Items from `sequence` that don't appear in `first` will come
     after any that do, and retain their existing order.
     
     Returns a sequence of the same type as given.
     """
	### Canonical solution below ###    
    first = first or []
    last = last or []
    # Add items that should be sorted first.
    new_sequence = [i for i in first if i in sequence]
    # Add remaining items in their current order, ignoring duplicates and items
    # that should be sorted last.
    for item in sequence:
        if item not in new_sequence and item not in last:
            new_sequence.append(item)
    # Add items that should be sorted last.
    new_sequence.extend([i for i in last if i in sequence])
    # Return a sequence of the same type as given.
    return type(sequence)(new_sequence)

### Unit tests below ###
def check(candidate):
	assert candidate(
    ['a', 'b', 'c', 'a', 'b', 'c', 'd', 'e', 'f', 'g'],
    first=['b', 'c'],
    last=['f', 'g']
) == ['b', 'c', 'a', 'd', 'e', 'f', 'g']
	assert candidate(
    ["a", "b", "c", "d", "e"],
    first=["a", "b", "c"],
    last=["d"],
) == ["a", "b", "c", "e", "d"]
	assert candidate(list('abca'), first=['c', 'a']) == list('cab')
	assert candidate((), first=[1, 2]) == ()
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f'],
    first=['d', 'b', 'a'],
    last=['e', 'f'],
) == ['d', 'b', 'a', 'c', 'e', 'f']
	assert candidate((1, 2, 3), first=[1, 2, 3]) == (1, 2, 3)
	assert candidate(
    ['django', 'django.contrib', 'django.contrib.admin', 'django.contrib.auth'],
    ['django', 'django.contrib'],
    ['django.contrib.admin', 'django.contrib.auth']
) == ['django', 'django.contrib', 'django.contrib.admin', 'django.contrib.auth']
	assert candidate(
    ['a', 'b', 'c'],
    first=['b', 'c'],
    last=['a'],
) == ['b', 'c', 'a']
	assert candidate((1, 2), first=[1, 2]) == (1, 2)
	assert candidate(
    [1, 2, 3, 4, 5],
    first=[],
    last=[]
) == [1, 2, 3, 4, 5]
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'],
    first=['a', 'b', 'c'],
    last=['d', 'e', 'f', 'g', 'h', 'i', 'j'],
) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
	assert candidate((1, 2, 3), first=[1, 2]) == (1, 2, 3)
	assert candidate((1, 2, 3), first=[2, 3]) == (2, 3, 1)
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'],
    first=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'],
    last=[],
) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
	assert candidate((1, 2, 3), first=[2]) == (2, 1, 3)
	assert candidate(
    ['a', 'b', 'c'],
    first=['b'],
    last=['a', 'c']
) == ['b', 'a', 'c']
	assert candidate(
    ['a', 'b', 'c', 'b', 'd', 'a', 'b', 'e', 'f'],
    first=['a', 'b'],
    last=['e', 'f']
) == ['a', 'b', 'c', 'd', 'e', 'f']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'],
    first=['b', 'd', 'f', 'h'],
    last=['a', 'c', 'e', 'g', 'i', 'j'],
) == ['b', 'd', 'f', 'h', 'a', 'c', 'e', 'g', 'i', 'j']
	assert candidate((), first=[]) == ()
	assert candidate((1, 2), first=[2]) == (2, 1)
	assert candidate(
    ['django', 'django.contrib.contenttypes', 'django.contrib.auth'],
    ['django.contrib.auth'],
    ['django.contrib.auth.context_processors']
) == ['django.contrib.auth', 'django', 'django.contrib.contenttypes']
	assert candidate((1, 2, 3), first=[3]) == (3, 1, 2)
	assert candidate(
    ['a', 'a', 'b', 'c'],
    first=['a'],
    last=['b', 'c']
) == ['a', 'b', 'c']
	assert candidate(
    ['a', 'b', 'c', 'd'],
    first=['a', 'b', 'c'],
    last=['d']) == ['a', 'b', 'c', 'd']
	assert candidate(
    ['a', 'b', 'c'],
    first=['b', 'c'],
    last=['a']
) == ['b', 'c', 'a']
	assert candidate(
    ["a", "b", "c", "d", "e"],
    first=["a", "b", "c"],
    last=["d", "e"],
) == ["a", "b", "c", "d", "e"]
	assert candidate(
    ['django.contrib.auth', 'django.contrib.contenttypes', 'django.contrib.sessions'],
    first=['django.contrib.contenttypes'],
    last=['django.contrib.auth', 'django.contrib.sessions'],
) == [
    'django.contrib.contenttypes',
    'django.contrib.auth',
    'django.contrib.sessions',
]
	assert candidate(
    ['a', 'b', 'c', 'd', 'e'],
    first=['b', 'c', 'e'],
    last=['a', 'd']
) == ['b', 'c', 'e', 'a', 'd']
	assert candidate(
    [1, 2, 3, 4, 5],
    first=[1, 2, 3],
    last=[]
) == [1, 2, 3, 4, 5]
	assert candidate(
    ['a', 'a', 'b', 'c'],
    first=['b'],
    last=['a', 'c']
) == ['b', 'a', 'c']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
    ['b', 'd', 'f'],
    ['a', 'c', 'e', 'g'],
) == ['b', 'd', 'f', 'a', 'c', 'e', 'g']
	assert candidate(
    ['a', 'b', 'c'],
    first=['a', 'b', 'c'],
) == ['a', 'b', 'c']
	assert candidate(
    ['django', 'django.contrib.contenttypes', 'django.contrib.auth'],
    ['django'],
    ['django.contrib.auth']
) == ['django', 'django.contrib.contenttypes', 'django.contrib.auth']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f'],
    first=['d', 'b', 'a'],
    last=['e', 'f', 'g'],
) == ['d', 'b', 'a', 'c', 'e', 'f']
	assert candidate(
    ['django', 'django.contrib.contenttypes', 'django.contrib.auth'],
    ['django'],
    ['django.contrib.auth.context_processors']
) == ['django', 'django.contrib.contenttypes', 'django.contrib.auth']
	assert candidate(
    ["a", "b", "a", "c", "b", "c", "d"],
    ["a", "b", "c"],
    ["d"]
) == ["a", "b", "c", "d"]
	assert candidate(list('abca')) == list('abc')
	assert candidate(
    [1, 2, 3, 4, 5],
    first=[1, 2, 3],
    last=[4, 5]
) == [1, 2, 3, 4, 5]
	assert candidate(('a', 'b', 'c', 'd', 'e', 'f'), first=('a', 'b', 'c'), last=('d', 'e', 'f')) == ('a', 'b', 'c', 'd', 'e', 'f')
def test_check():
	check(dedupe_and_sort)
