def _join_tag_version(tag, version):
    """ 
     Join a tag (not image tag) and version by prepending the version to the tag
     with a '-' character.
     """
	### Canonical solution below ###    
    return '-'.join((version, tag))

### Unit tests below ###
def check(candidate):
	assert candidate('1.2.3', 'latest') == 'latest-1.2.3'
	assert candidate('tag','version') =='version-tag'
	assert candidate(tag='tag', version='version-version') =='version-version-tag'
	assert candidate(
    'alpine',
    '1.2.3') == '1.2.3-alpine'
	assert candidate(
    'latest',
    '1.2.3',
) == '1.2.3-latest'
	assert candidate('v1', 'v2') == 'v2-v1'
	assert candidate('foo', '1.0.0') == '1.0.0-foo'
	assert candidate('1.2.3', '4.5.6') == '4.5.6-1.2.3'
	assert candidate('v1.2.3', 'v4.5.6') == 'v4.5.6-v1.2.3'
	assert candidate('1.0.0', '1.0.0') == '1.0.0-1.0.0'
	assert candidate('latest', 'v1.2.3') == 'v1.2.3-latest'
	assert candidate('latest', 'latest') == 'latest-latest'
	assert candidate('1.0', '2.0') == '2.0-1.0'
	assert candidate('latest', '1.0') == '1.0-latest'
	assert candidate('1.0', '1.0') == '1.0-1.0'
	assert candidate('latest', '1.2.3') == '1.2.3-latest'
	assert candidate(tag='foo', version='bar') == 'bar-foo'
	assert candidate(tag='1.2.3', version='v1.2.3') == 'v1.2.3-1.2.3'
	assert candidate(
    'alpine-1.2.3',
    '4.5.6') == '4.5.6-alpine-1.2.3'
	assert candidate('0.1.2', '1.2.3') == '1.2.3-0.1.2'
	assert candidate('1.0.0-latest', '1.0.0') == '1.0.0-1.0.0-latest'
	assert candidate('v1.2.3', 'v1.2.3') == 'v1.2.3-v1.2.3'
	assert candidate('1.0.0', '1.0.0-1.0.0') == '1.0.0-1.0.0-1.0.0'
	assert candidate('foo', '1.2.3') == '1.2.3-foo'
	assert candidate('master', '1.0.0') == '1.0.0-master'
	assert candidate(tag='foo', version='1.0.0') == '1.0.0-foo'
	assert candidate('foo', '1.0') == '1.0-foo'
	assert candidate(tag='tag', version='version') =='version-tag'
	assert candidate('latest', '1.0.0') == '1.0.0-latest'
def test_check():
	check(_join_tag_version)
