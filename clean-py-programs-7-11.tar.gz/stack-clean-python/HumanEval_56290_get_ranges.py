def get_ranges(uid_number, inc=0):
    """
    Return two block ranges to be used to create subnets for
    Atmosphere users.

    NOTE: If you change MAX_SUBNET then you should likely change
    the related math.
    """
    ### Canonical solution below ###
    MAX_SUBNET = 4064  # Note 16 * 256
    n = uid_number % MAX_SUBNET

    # 16-31
    block1 = (n + inc) % 16 + 16

    # 1-254
    block2 = ((n + inc) / 16) % 254 + 1

    return (block1, block2)


### Unit tests below ###
def check(candidate):
	assert candidate(4064) == (16, 1)
	assert candidate(1, 20)
	assert candidate(24)
	assert candidate(0) == (16, 1)
def test_check():
	check(get_ranges)
