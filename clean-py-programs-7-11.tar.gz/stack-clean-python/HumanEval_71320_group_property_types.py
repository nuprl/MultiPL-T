def group_property_types(row : str) -> str:
    """ 
     This functions changes each row in the dataframe to have the one
     of five options for building type:
     - Residential
     - Storage
     - Retail
     - Office
     - Other
     this was done to reduce the dimensionality down to the top building
     types.
     
     :param: row (str) : The row of the pandas series
     :rvalue: str
     :return: One of 5 building types.
     """
	### Canonical solution below ###    
    if row == 'Multifamily Housing' or\
    row == 'Residence Hall/Dormitory' or\
    row == 'Hotel' or\
    row == 'Other - Lodging/Residential' or\
    row == 'Residential Care Facility':
        return 'Residential'
    elif row == 'Non-Refrigerated Warehouse' or\
    row == 'Self-Storage Facility' or\
    row == 'Refrigerated Warehouse':
        return 'Storage'
    elif row == 'Financial Office' or\
    row == 'Office':
        return 'Office'
    elif row == 'Restaurant' or\
    row == 'Retail Store' or\
    row == 'Enclosed Mall' or\
    row == 'Other - Mall' or\
    row == 'Strip Mall' or\
    row == 'Personal Services (Health/Beauty, Dry Cleaning, etc.)' or\
    row == 'Lifestyle Center' or\
    row == 'Wholesale Club/Supercenter':
        return 'Retail'
    else:
        return 'Other'

### Unit tests below ###
def check(candidate):
	assert candidate(
    'Retail Store') == 'Retail', "Retail"
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage', "Testing candidate"
	assert candidate(row='Strip Mall') == 'Retail',\
    "candidate failed"
	assert candidate(row='Financial Office') == 'Office',\
    "candidate failed"
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage',\
    'Non-Refrigerated Warehouse should be Storage'
	assert candidate(
    'Retail Store'
) == 'Retail'
	assert candidate(
    'Strip Mall') == 'Retail',\
    "candidate did not return the correct value"
	assert candidate(
    "Other - Lodging/Residential") == 'Residential'
	assert candidate(row='Multifamily Housing') == 'Residential'
	assert candidate(
    'Retail Store') == 'Retail'
	assert candidate(
    'Enclosed Mall'
) == 'Retail',\
    'Enclosed Mall should be Retail'
	assert candidate(
    'Restaurant'
) == 'Retail'
	assert candidate(
    "Refrigerated Warehouse") == 'Storage'
	assert candidate(
    'Other - Mall') == 'Retail', 'Other - Mall'
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential', "candidate() failed"
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential', "Residential"
	assert candidate(
    'Financial Office') == 'Office', 'Financial Office'
	assert candidate(
    'Self-Storage Facility') == 'Storage',\
    "candidate does not work for storage buildings"
	assert candidate(row='Other - Mall') == 'Retail'
	assert candidate(
    "Hotel") == 'Residential'
	assert candidate(
    'Office') == 'Office',\
    "candidate does not work for office buildings"
	assert candidate(
    'Multifamily Housing') == 'Residential', "Testing candidate"
	assert candidate(
    'Financial Office'
) == 'Office', 'Office property type'
	assert candidate(
    'Financial Office') == 'Office',\
    'Financial Office should return Office'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage', 'Storage'
	assert candidate(
    'Financial Office') == 'Office', "Office"
	assert candidate(row = 'Something else') == 'Other'
	assert candidate(
    'Other - Mall') == 'Retail'
	assert candidate('Hotel') == 'Residential'
	assert candidate(
    'Financial Office') == 'Office'
	assert candidate(
    'Self-Storage Facility') == 'Storage',\
    'Self-Storage Facility should be Storage'
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage',\
    "candidate did not return the correct value"
	assert candidate(
    'Office'
) == 'Office',\
    'Office should be Office'
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential',\
    'Residence Hall/Dormitory should return Residential'
	assert candidate(
    'Enclosed Mall') == 'Retail', 'Retail'
	assert candidate(
    'Financial Office') == 'Office',\
    'Financial Office should be Office'
	assert candidate(
    'Restaurant') == 'Retail', "Testing candidate"
	assert candidate(
    'Office') == 'Office', 'Office'
	assert candidate(
    'Enclosed Mall'
) == 'Retail'
	assert candidate(
    'Self-Storage Facility') == 'Storage', 'Self-Storage Facility'
	assert candidate(
    'Restaurant') == 'Retail'
	assert candidate(
    'Office') == 'Office'
	assert candidate(
    'Self-Storage Facility') == 'Storage', "Testing candidate"
	assert candidate(row='Personal Services (Health/Beauty, Dry Cleaning, etc.)') == 'Retail'
	assert candidate(row='Other - Lodging/Residential') == 'Residential'
	assert candidate(
    'Office') == 'Office', "Office"
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential',\
    "candidate does not work for residential buildings"
	assert candidate(row='Financial Office') == 'Office'
	assert candidate('Hotel') == 'Residential', "Testing candidate"
	assert candidate(
    'Other - Mall') == 'Retail', 'Retail'
	assert candidate('Financial Office') == 'Office'
	assert candidate(
    "Financial Office") == 'Office'
	assert candidate(
    'Hotel') == 'Residential',\
    "candidate does not work for residential buildings"
	assert candidate(
    'Residential Care Facility') == 'Residential',\
    "candidate does not work for residential buildings"
	assert candidate(
    'Residential Care Facility') == 'Residential',\
    'Residential Care Facility should be Residential'
	assert candidate(
    'Residential Care Facility') == 'Residential', 'Residential'
	assert candidate("Non-Refrigerated Warehouse") == 'Storage', "candidate failed for Non-Refrigerated Warehouse"
	assert candidate('Refrigerated Warehouse') == 'Storage'
	assert candidate(None) == 'Other', "candidate failed for None"
	assert candidate(row='Wholesale Club/Supercenter') == 'Retail'
	assert candidate(row='Hotel') == 'Residential'
	assert candidate(
    'Restaurant') == 'Retail', 'Retail'
	assert candidate(
    'Wholesale Club/Supercenter') == 'Retail',\
    "candidate did not return the correct value"
	assert candidate(
    'Non-Refrigerated Warehouse'
) == 'Storage', 'Storage property type'
	assert candidate(row='Restaurant') == 'Retail',\
    "candidate failed"
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage', 'Non-Refrigerated Warehouse'
	assert candidate(
    'Other - Mall'
) == 'Retail', 'Retail property type'
	assert candidate(
    'Other - Lodging/Residential') == 'Residential', 'Other - Lodging/Residential'
	assert candidate(
    'Restaurant') == 'Retail', "candidate() failed"
	assert candidate(
    "Retail Store") == 'Retail'
	assert candidate('Personal Services (Health/Beauty, Dry Cleaning, etc.)') == 'Retail'
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage', "Storage"
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage'
	assert candidate(
    'Strip Mall') == 'Retail', 'Strip Mall'
	assert candidate(
    "Self-Storage Facility") == 'Storage'
	assert candidate(
    "Enclosed Mall") == 'Retail'
	assert candidate(
    'Residential Care Facility') == 'Residential', "Testing candidate"
	assert candidate(
    'Personal Services (Health/Beauty, Dry Cleaning, etc.)') == 'Retail', 'Retail'
	assert candidate("Hotel") == 'Residential', "candidate failed for Hotel"
	assert candidate(
    "Office") == 'Office'
	assert candidate(
    "Wholesale Club/Supercenter") == 'Retail'
	assert candidate(
    'Residence Hall/Dormitory'
) == 'Residential'
	assert candidate(
    'Restaurant') == 'Retail', 'Restaurant'
	assert candidate(
    'Retail Store') == 'Retail', "Testing candidate"
	assert candidate(row='Enclosed Mall') == 'Retail'
	assert candidate(
    'Restaurant') == 'Retail', "Retail"
	assert candidate(
    'Enclosed Mall') == 'Retail', 'Enclosed Mall'
	assert candidate(row = 'Multifamily Housing') == 'Residential'
	assert candidate(
    "Personal Services (Health/Beauty, Dry Cleaning, etc.)") == 'Retail'
	assert candidate('Restaurant') == 'Retail'
	assert candidate('Strip Mall') == 'Retail'
	assert candidate(
    'Restaurant') == 'Retail',\
    'Restaurant should be Retail'
	assert candidate(
    'Multifamily Housing') == 'Residential', 'Residential'
	assert candidate(
    'Restaurant') == 'Retail',\
    "candidate does not work for retail buildings"
	assert candidate(
    'Multifamily Housing') == 'Residential',\
    "candidate did not return the correct value"
	assert candidate(
    'Retail Store') == 'Retail', 'Retail Store'
	assert candidate(
    'Other - Mall') == 'Retail', "Testing candidate"
	assert candidate(row = 'Restaurant') == 'Retail'
	assert candidate(
    'Self-Storage Facility') == 'Storage',\
    'candidate: failed on Self-Storage Facility'
	assert candidate(
    'Personal Services (Health/Beauty, Dry Cleaning, etc.)'
) == 'Retail'
	assert candidate(
    'Hotel'
) == 'Residential', 'Residential property type'
	assert candidate(
    'Retail Store'
) == 'Retail', 'Retail property type'
	assert candidate(row = 'Hotel') == 'Residential'
	assert candidate('Other - Mall') == 'Retail'
	assert candidate(row='Residence Hall/Dormitory') == 'Residential'
	assert candidate(
    'Residential Care Facility'
) == 'Residential',\
    'Residential Care Facility should be Residential'
	assert candidate(
    'Other - Lodging/Residential') == 'Residential',\
    'candidate: failed on Other - Lodging/Residential'
	assert candidate(
    'Strip Mall'
) == 'Retail'
	assert candidate(
    'Strip Mall') == 'Retail',\
    'Strip Mall should return Retail'
	assert candidate(
    'Other - Lodging/Residential'
) == 'Residential'
	assert candidate(
    "Multifamily Housing") == 'Residential'
	assert candidate(
    'Wholesale Club/Supercenter') == 'Retail'
	assert candidate(
    'Lifestyle Center'
) == 'Retail'
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential',\
    'candidate: failed on Residence Hall/Dormitory'
	assert candidate(
    'Self-Storage Facility') == 'Storage'
	assert candidate('Multifamily Housing') == 'Residential'
	assert candidate(
    'Other - Mall') == 'Retail', "Retail"
	assert candidate(
    'Other - Lodging/Residential') == 'Residential', "candidate() failed"
	assert candidate('Wholesale Club/Supercenter') == 'Retail'
	assert candidate(
    'Restaurant') == 'Retail',\
    "candidate did not return the correct value"
	assert candidate(
    'Financial Office') == 'Office',\
    "candidate does not work for office buildings"
	assert candidate(
    'Multifamily Housing') == 'Residential'
	assert candidate(
    'Other - Mall') == 'Retail', "candidate() failed"
	assert candidate(
    'Financial Office'
) == 'Office',\
    'Financial Office should be Office'
	assert candidate(
    'Retail Store') == 'Retail', 'Retail'
	assert candidate(
    'Residential Care Facility') == 'Residential', "Residential"
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage', "candidate() failed"
	assert candidate(row='Restaurant') == 'Retail'
	assert candidate(
    'Personal Services (Health/Beauty, Dry Cleaning, etc.)') == 'Retail', "Retail"
	assert candidate(row = 'Lifestyle Center') == 'Retail'
	assert candidate(
    'Financial Office') == 'Office', 'Office'
	assert candidate(
    'Enclosed Mall'
) == 'Retail', 'Retail property type'
	assert candidate(
    'Hotel') == 'Residential', 'Hotel'
	assert candidate(
    'Residence Hall/Dormitory'
) == 'Residential', 'Residential property type'
	assert candidate(
    "Lifestyle Center") == 'Retail'
	assert candidate(row = 'Strip Mall') == 'Retail'
	assert candidate(row='Non-Refrigerated Warehouse') == 'Storage'
	assert candidate(
    'Financial Office') == 'Office', "Testing candidate"
	assert candidate(
    'Residential Care Facility'
) == 'Residential'
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage',\
    'candidate: failed on Non-Refrigerated Warehouse'
	assert candidate(row = 'Personal Services (Health/Beauty, Dry Cleaning, etc.)') == 'Retail'
	assert candidate(row = 'Self-Storage Facility') == 'Storage'
	assert candidate(
    'Multifamily Housing') == 'Residential',\
    'Multifamily Housing should be Residential'
	assert candidate(
    'Lifestyle Center') == 'Retail'
	assert candidate(
    'Residence Hall/Dormitory'
) == 'Residential',\
    'Residence Hall/Dormitory should be Residential'
	assert candidate(
    'Office') == 'Office', "candidate() failed"
	assert candidate(row = 'Wholesale Club/Supercenter') == 'Retail'
	assert candidate(row = 'Other') == 'Other'
	assert candidate(
    'Hotel'
) == 'Residential'
	assert candidate('Office') == 'Office'
	assert candidate(
    'Financial Office') == 'Office',\
    'candidate: failed on Financial Office'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage', "candidate() failed"
	assert candidate(
    'Refrigerated Warehouse'
) == 'Storage', 'Storage property type'
	assert candidate(
    'Hotel') == 'Residential'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage',\
    'candidate: failed on Refrigerated Warehouse'
	assert candidate(
    'Residential Care Facility') == 'Residential',\
    'candidate: failed on Residential Care Facility'
	assert candidate("Residence Hall/Dormitory") == 'Residential', "candidate failed for Residence Hall/Dormitory"
	assert candidate(
    'Other - Lodging/Residential') == 'Residential', 'Residential'
	assert candidate("Refrigerated Warehouse") == 'Storage', "candidate failed for Refrigerated Warehouse"
	assert candidate(row='Multifamily Housing') == 'Residential',\
    "candidate failed"
	assert candidate('Retail Store') == 'Retail'
	assert candidate(
    'Restaurant'
) == 'Retail', 'Retail property type'
	assert candidate(
    'Enclosed Mall') == 'Retail', "candidate() failed"
	assert candidate(
    'Financial Office') == 'Office',\
    "candidate did not return the correct value"
	assert candidate(
    'Multifamily Housing') == 'Residential', "Residential"
	assert candidate(row = 'Refrigerated Warehouse') == 'Storage'
	assert candidate(
    "Non-Refrigerated Warehouse") == 'Storage'
	assert candidate(
    'Financial Office') == 'Office', "candidate() failed"
	assert candidate(
    'Other - Lodging/Residential') == 'Residential', "Residential"
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential', 'Residence Hall/Dormitory'
	assert candidate(row='Hotel') == 'Residential',\
    "candidate failed"
	assert candidate('Other - Lodging/Residential') == 'Residential'
	assert candidate(
    'Strip Mall') == 'Retail'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage', "Storage"
	assert candidate("Self-Storage Facility") == 'Storage', "candidate failed for Self-Storage Facility"
	assert candidate(row = 'Other - Mall') == 'Retail'
	assert candidate(
    'Other - Mall'
) == 'Retail'
	assert candidate(
    'Restaurant') == 'Retail',\
    'candidate: failed on Restaurant'
	assert candidate(
    'Residential Care Facility') == 'Residential', "candidate() failed"
	assert candidate(row = 'Non-Refrigerated Warehouse') == 'Storage'
	assert candidate("Residential Care Facility") == 'Residential', "candidate failed for Residential Care Facility"
	assert candidate(
    'Office'
) == 'Office', 'Office property type'
	assert candidate(
    'Self-Storage Facility'
) == 'Storage',\
    'Self-Storage Facility should be Storage'
	assert candidate(
    'Other - Lodging/Residential'
) == 'Residential',\
    'Other - Lodging/Residential should be Residential'
	assert candidate(
    'Financial Office'
) == 'Office'
	assert candidate(row='Strip Mall') == 'Retail'
	assert candidate('Enclosed Mall') == 'Retail'
	assert candidate('Non-Refrigerated Warehouse') == 'Storage'
	assert candidate("Other - Lodging/Residential") == 'Residential', "candidate failed for Other - Lodging/Residential"
	assert candidate(
    'Office'
) == 'Office'
	assert candidate(
    'Residential Care Facility') == 'Residential'
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage',\
    "candidate does not work for storage buildings"
	assert candidate('Residence Hall/Dormitory') == 'Residential'
	assert candidate(
    'Restaurant'
) == 'Retail',\
    'Restaurant should be Retail'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage', 'Refrigerated Warehouse'
	assert candidate(
    'Enclosed Mall') == 'Retail',\
    'Enclosed Mall should return Retail'
	assert candidate(
    'Hotel') == 'Residential', "candidate() failed"
	assert candidate(
    'Other - Lodging/Residential') == 'Residential', "Testing candidate"
	assert candidate(
    'Other') == 'Other'
	assert candidate(row = 'Residence Hall/Dormitory') == 'Residential'
	assert candidate(
    'Hotel') == 'Residential', "Residential"
	assert candidate(
    'Retail Store'
) == 'Retail',\
    'Retail Store should be Retail'
	assert candidate(
    'Multifamily Housing') == 'Residential', "candidate() failed"
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential',\
    'Residence Hall/Dormitory should be Residential'
	assert candidate(row = 'Retail Store') == 'Retail'
	assert candidate(row = 'Residential Care Facility') == 'Residential'
	assert candidate(
    'Refrigerated Warehouse'
) == 'Storage',\
    'Refrigerated Warehouse should be Storage'
	assert candidate("Financial Office") == 'Office', "candidate failed for Financial Office"
	assert candidate(
    'Refrigerated Warehouse') == 'Storage'
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential', 'Residential'
	assert candidate(
    'Hotel') == 'Residential', 'Residential'
	assert candidate(row = 'Other - Lodging/Residential') == 'Residential'
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential', "Testing candidate"
	assert candidate("Restaurant") == 'Retail', "candidate failed for Restaurant"
	assert candidate(
    'Personal Services (Health/Beauty, Dry Cleaning, etc.)') == 'Retail'
	assert candidate(
    'Office') == 'Office',\
    'Office should be Office'
	assert candidate('Lifestyle Center') == 'Retail'
	assert candidate(
    "Residential Care Facility") == 'Residential'
	assert candidate(
    'Non-Refrigerated Warehouse'
) == 'Storage'
	assert candidate(
    'Strip Mall') == 'Retail', 'Retail'
	assert candidate(
    'Other - Lodging/Residential') == 'Residential',\
    'Other - Lodging/Residential should be Residential'
	assert candidate('Residential Care Facility') == 'Residential'
	assert candidate(
    'Retail Store') == 'Retail',\
    'Retail Store should be Retail'
	assert candidate(
    'Enclosed Mall') == 'Retail', "Testing candidate"
	assert candidate(
    "Residence Hall/Dormitory") == 'Residential'
	assert candidate(
    'Multifamily Housing'
) == 'Residential', 'Residential property type'
	assert candidate(
    'Residential Care Facility') == 'Residential', 'Residential Care Facility'
	assert candidate(
    'Hotel'
) == 'Residential',\
    'Hotel should be Residential'
	assert candidate(
    "Other - Mall") == 'Retail'
	assert candidate(row='Office') == 'Office'
	assert candidate(
    'Self-Storage Facility'
) == 'Storage', 'Storage property type'
	assert candidate(
    'Other - Lodging/Residential') == 'Residential'
	assert candidate(
    'Non-Refrigerated Warehouse'
) == 'Storage',\
    'Non-Refrigerated Warehouse should be Storage'
	assert candidate(
    'Multifamily Housing') == 'Residential',\
    'candidate: failed on Multifamily Housing'
	assert candidate("Multifamily Housing") == 'Residential', "candidate failed for Multifamily Housing"
	assert candidate(
    'Self-Storage Facility') == 'Storage', 'Storage'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage',\
    "candidate does not work for storage buildings"
	assert candidate(
    'Office') == 'Office',\
    'candidate: failed on Office'
	assert candidate(
    'Refrigerated Warehouse'
) == 'Storage'
	assert candidate(
    'Self-Storage Facility') == 'Storage', "Storage"
	assert candidate(
    'Enclosed Mall') == 'Retail'
	assert candidate(
    'Residence Hall/Dormitory') == 'Residential'
	assert candidate(
    'Retail Store') == 'Retail',\
    "candidate does not work for retail buildings"
	assert candidate(
    'Residential Care Facility'
) == 'Residential', 'Residential property type'
	assert candidate(row = 'Office') == 'Office'
	assert candidate(
    'Strip Mall') == 'Retail', "Retail"
	assert candidate('Self-Storage Facility') == 'Storage'
	assert candidate(
    'Hotel') == 'Residential',\
    'Hotel should be Residential'
	assert candidate(
    'Office') == 'Office', "Testing candidate"
	assert candidate(
    'Self-Storage Facility'
) == 'Storage'
	assert candidate(row = 'Enclosed Mall') == 'Retail'
	assert candidate(
    "Restaurant") == 'Retail'
	assert candidate("Office") == 'Office', "candidate failed for Office"
	assert candidate(
    'Enclosed Mall') == 'Retail', "Retail"
	assert candidate(row='Residential Care Facility') == 'Residential'
	assert candidate(row='Lifestyle Center') == 'Retail',\
    "candidate failed"
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage',\
    'Non-Refrigerated Warehouse should return Storage'
	assert candidate(row='Refrigerated Warehouse') == 'Storage'
	assert candidate(row='Retail Store') == 'Retail'
	assert candidate(row='Self-Storage Facility') == 'Storage'
	assert candidate(
    'Hotel') == 'Residential',\
    'candidate: failed on Hotel'
	assert candidate(
    "Strip Mall") == 'Retail'
	assert candidate("Retail Store") == 'Retail', "candidate failed for Retail Store"
	assert candidate(
    'Retail Store') == 'Retail', "candidate() failed"
	assert candidate(
    'Other - Lodging/Residential'
) == 'Residential', 'Residential property type'
	assert candidate(
    'Other - Lodging/Residential') == 'Residential',\
    "candidate does not work for residential buildings"
	assert candidate(
    'Multifamily Housing'
) == 'Residential'
	assert candidate(
    'Wholesale Club/Supercenter'
) == 'Retail'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage', "Testing candidate"
	assert candidate(row='Lifestyle Center') == 'Retail'
	assert candidate(row = 'Financial Office') == 'Office'
	assert candidate(
    'Non-Refrigerated Warehouse') == 'Storage', 'Storage'
	assert candidate(
    'Refrigerated Warehouse') == 'Storage',\
    'Refrigerated Warehouse should be Storage'
	assert candidate(
    'Self-Storage Facility') == 'Storage', "candidate() failed"
def test_check():
	check(group_property_types)
