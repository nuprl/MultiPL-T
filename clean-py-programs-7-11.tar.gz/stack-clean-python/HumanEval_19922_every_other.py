def every_other(seq):
    """ Returns a new sequence containing every other element of the input sequence, starting with
     the first. If the input sequence is empty, a new empty sequence of the same type should be
     returned.
     
     Example: every_other("abcde")
     "ace"
     """
	### Canonical solution below ###    
    newSeq = seq * 0
    for i in range(len(seq)):
        if i % 2 == 0:
            newSeq += seq[i]
    return newSeq

### Unit tests below ###
def check(candidate):
	assert candidate("abcdefgh") == "aceg"
	assert candidate("") == ""
	assert candidate(tuple()) == tuple()
	assert candidate(str("abcde")) == str("ace"), "candidate on str failed"
	assert candidate("abc") == "ac"
	assert candidate("abcdefg") == "aceg"
	assert candidate(list("abcde")) == ["a", "c", "e"]
	assert candidate("abcdef") == "ace"
	assert candidate([]) == []
	assert candidate(list("abcde")) == list("ace"), "candidate on list failed"
	assert candidate("abcde") == "ace"
	assert candidate(list("abcde")) == list("ace")
	assert candidate(list("abcde")) == list("ace"), "candidate should work with lists"
	assert candidate(str("abcde")) == "ace", "candidate should work with strings"
def test_check():
	check(every_other)
