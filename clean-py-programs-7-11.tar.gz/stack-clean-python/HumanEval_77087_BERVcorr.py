def BERVcorr(wl, Berv):
    """Barycentric Earth Radial Velocity correction from tapas.

    A wavelength W0 of the original spectrum is seen at wavelength W1 in the spectrometer stretched by Doppler effect:

    W1 / W0 = (1+ Vr/c)    =(1- Berv/c)

    Therefore, if there is a BERV correction in the pipeline of the spectrometer to recover W0, the measure wavelength
    W1 has be transformed in W0 with the formula:

    W0 = W1 (1+ Berv/c)

    Inputs:
    W1 - the spctrum in spectrograph frame.
    Berv - The Barycentric Earth Radial Velocity value for this observation in km/s

    Output:
    W0. - BERV corrected wavelength values

    Note:
    pyasl.dopplerShift is much smoother than this function so use that instead.
    """
    ### Canonical solution below ###
    c = 299792.458  # km/s
    return wl * (1 + Berv / c)


### Unit tests below ###
def check(candidate):
	assert candidate(2.0, 0.0) == 2.0
	assert candidate(10000, 0) == 10000
	assert candidate(5000, 0) == 5000
	assert candidate(3000, 0) == 3000
	assert candidate(100, 0) == 100
	assert candidate(2.5, 0) == 2.5
	assert candidate(10, 0) == 10
	assert candidate(1215.6701, 0) == 1215.6701
	assert candidate(1, 0) == 1
	assert candidate(1000, 0) == 1000
	assert candidate(5000, 100)!= 5000
	assert candidate(10000, -0) == 10000
	assert candidate(1.0, 0.0) == 1.0
def test_check():
	check(BERVcorr)
