def apply_threshold(objects, threshold):
    """ 
     Filter out objects below a certain score.
     """
	### Canonical solution below ###    
    return [obj for obj in objects if obj['score'] >= threshold]

### Unit tests below ###
def check(candidate):
	assert candidate(
    [{'name': 'golden retriever','score': 0.9999999},
     {'name': 'golden retriever','score': 0.999999},
     {'name': 'golden retriever','score': 0.99999},
     {'name': 'golden retriever','score': 0.9999},
     {'name': 'golden retriever','score': 0.999}],
    0.999999) == [{'name': 'golden retriever','score': 0.9999999},
                 {'name': 'golden retriever','score': 0.999999}]
	assert candidate(
    [
        {'score': 0.95},
        {'score': 0.70},
        {'score': 0.20},
        {'score': 0.10},
    ],
    0.5,
) == [
    {'score': 0.95},
    {'score': 0.70},
]
	assert candidate(
    [{'score': 0.999}, {'score': 0.8}], threshold=0.9) == [{'score': 0.999}]
	assert candidate(
    [
        {'score': 0.98},
        {'score': 0.5},
        {'score': 0.98},
        {'score': 0.3},
        {'score': 0.98},
    ],
    threshold=0.8,
) == [
    {'score': 0.98},
    {'score': 0.98},
    {'score': 0.98},
]
	assert candidate(
    [{'name': 'car','score': 0.8}, {'name': 'truck','score': 0.4}],
    0.5) == [{'name': 'car','score': 0.8}]
	assert candidate(
    [{'name': 'laptop','score': 0.75}, {'name': 'chair','score': 0.2}], 0.5) == \
    [{'name': 'laptop','score': 0.75}]
	assert candidate(
    [{'score': 0.95}, {'score': 0.6}, {'score': 0.92}],
    0.9) == [{'score': 0.95}, {'score': 0.92}]
	assert candidate(
    [
        {'score': 0.9, 'label': 'a'},
        {'score': 0.5, 'label': 'b'},
        {'score': 0.1, 'label': 'c'},
    ],
    0.5,
) == [
    {'score': 0.9, 'label': 'a'},
    {'score': 0.5, 'label': 'b'},
]
	assert candidate(
    [{'name': 'golden retriever','score': 0.9999999},
     {'name': 'golden retriever','score': 0.999999},
     {'name': 'golden retriever','score': 0.99999},
     {'name': 'golden retriever','score': 0.9999},
     {'name': 'golden retriever','score': 0.999}],
    0.9999999) == [{'name': 'golden retriever','score': 0.9999999}]
	assert candidate(
    [
        {"image_id": 1, "category_id": 1, "bbox": [25, 25, 50, 50], "score": 0.9},
        {"image_id": 1, "category_id": 1, "bbox": [100, 100, 200, 200], "score": 0.7},
    ],
    0.8,
) == [
    {"image_id": 1, "category_id": 1, "bbox": [25, 25, 50, 50], "score": 0.9},
]
def test_check():
	check(apply_threshold)
