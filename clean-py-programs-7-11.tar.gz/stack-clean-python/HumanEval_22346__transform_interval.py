def _transform_interval(
        interval, first_domain_start, first_domain_end, second_domain_start, second_domain_end
):
    """
    Transform an interval from one domain to another.
    The interval should be within the first domain [first_domain_start, first_domain_end]
    For example, _transform_interval((3, 5), 0, 10, 100, 200) would return (130, 150)
    """
    ### Canonical solution below ###
    def transform_value(value):
        position = (value - first_domain_start) / (first_domain_end - first_domain_start)
        return position * (second_domain_end - second_domain_start) + second_domain_start

    return [transform_value(value) for value in interval]


### Unit tests below ###
def check(candidate):
	assert candidate(
    (3, 5), 10, 20, 100, 100
) == [100, 100]
	assert candidate(
    (3, 5), 0, 10, 100, 200
) == candidate(
    (3, 5), 0, 10, 100, 200
)
	assert candidate(
    (3, 5), 0, 10, 100, 200) == [130, 150]
	assert candidate(
    (3, 5), 0, 10, 100, 200
)!= candidate(
    (3, 5), 1, 10, 100, 200
)
	assert candidate(
    (3, 5), 0, 10, 100, 200
)!= candidate(
    (3, 5), 0, 10, 99, 200
)
	assert candidate(
    (0, 0),
    0,
    10,
    100,
    200
) == [100, 100]
	assert candidate(
    (0, 10),
    0,
    10,
    100,
    200
) == [100, 200]
	assert candidate(
    (-10, 10),
    -10,
    10,
    0,
    100
) == [0, 100]
	assert candidate(
    (1, 1), 0, 10, 100, 100
) == [100, 100]
	assert candidate(
    (3, 5), 0, 10, 100, 100
) == [100, 100]
	assert candidate(
    (3, 5),
    0,
    10,
    100,
    200
) == [130, 150]
	assert candidate(
    (-10, -10),
    -10,
    10,
    0,
    100
) == [0, 0]
	assert candidate(
    (1, 1), 10, 20, 100, 100
) == [100, 100]
	assert candidate(
    (3, 5), 0, 10, 100, 200
) == [130, 150]
	assert candidate(
    (3, 5), 0, 10, 100, 200
)!= candidate(
    (5, 3), 0, 10, 100, 200
)
	assert candidate(
    (10, 10), 0, 10, 100, 200
) == [200, 200]
	assert candidate(
    (3, 5), 0, 10, 100, 200
)!= candidate(
    (3, 5), 0, 11, 100, 200
)
def test_check():
	check(_transform_interval)
