def _convert_strip_time(arg_list):
    """
    Handler for the "strip_time" meta-function.
    @param IN arg_list List of arguments
    @return DB function call string
    """
    ### Canonical solution below ###

    nb_args = len(arg_list)
    if nb_args != 1:
        raise Exception("The 'strip_time' meta-function should take exactly 1 argument "
            "(%d provided)" % nb_args)
    return "DATE(%s)" % arg_list[0]


### Unit tests below ###
def check(candidate):
	assert candidate(
    ["TO_DATE('2015-12-10 12:30:00', 'YYYY-MM-DD HH24:MI:SS')"]) == \
    "DATE(TO_DATE('2015-12-10 12:30:00', 'YYYY-MM-DD HH24:MI:SS'))"
	assert candidate(["A"]) == "DATE(A)"
	assert candidate( ["a"] ) == "DATE(a)"
	assert candidate( ["t.col"] ) == "DATE(t.col)"
	assert candidate( ["now()"] ) == "DATE(now())"
	assert candidate(["test"]) == "DATE(test)"
	assert candidate( ["foo"] ) == "DATE(foo)"
	assert candidate( ["now() + interval '1 day'"] ) == "DATE(now() + interval '1 day')"
	assert candidate( ("foo",) ) == "DATE(foo)"
	assert candidate(["foo"]) == "DATE(foo)"
	assert candidate( ["'2011-01-02 03:04:05'"] ) == "DATE('2011-01-02 03:04:05')"
	assert candidate(["a"]) == "DATE(a)"
	assert candidate(
    ['"2001-01-01 01:01:01"']) == "DATE(\"2001-01-01 01:01:01\")"
	assert candidate( ['TO_CHAR(CAST(NOW() AS TIMESTAMP), \'YYYY-MM-DD\')'] ) == "DATE(TO_CHAR(CAST(NOW() AS TIMESTAMP), 'YYYY-MM-DD'))"
def test_check():
	check(_convert_strip_time)
