def next_state(s,counter,N,args):
	""" implements magnetization conservation. """
    ### Canonical solution below ###
	if(s==0): return s;
	#
	t = (s | (s - 1)) + 1
	return t | ((((t & (0-t)) // (s & (0-s))) >> 1) - 1)


### Unit tests below ###
def check(candidate):
	assert candidate(0,0,6,0) == 0
	assert candidate(3,0,100,None) == 5
	assert candidate(9,0,10,10)==10
	assert candidate(0,0,16,0) == 0
	assert candidate(1,8,2,{})==2
	assert candidate(0,0,20,0) == 0
	assert candidate(0,20,10,1) == 0
	assert candidate(0,0,4,0) == 0
	assert candidate(21,0,10,None)==22
	assert candidate(1,0,3,None) == 2
	assert candidate(0,1,10,None) == 0
	assert candidate(0,0,1000,None)==0
	assert candidate(1,23,2,{})==2
	assert candidate(4,0,3,None) == 8
	assert candidate(21,0,10,10)==22
	assert candidate(0,0,7,0) == 0
	assert candidate(0,0,10,None) == 0
	assert candidate(0,10,10,1) == 0
	assert candidate(0,0,1,0) == 0
	assert candidate(1,6,4,0) == 2
	assert candidate(13,0,10,None)==14
	assert candidate(0,1,0,0) == 0
	assert candidate(5,0,10,None)==6
	assert candidate(0,0,17,0) == 0
	assert candidate(9,0,1000,None)==10
	assert candidate(0,0,14,0) == 0
	assert candidate(9,0,10,None)==10
	assert candidate(1,14,2,{})==2
	assert candidate(0,0,11,0) == 0
	assert candidate(0,0,2,0) == 0
	assert candidate(1,2,2,{})==2
	assert candidate(0,0,10,{}) == 0
	assert candidate(6,0,2,0)
	assert candidate(0,0,10,1) == 0
	assert candidate(0,0,10,[100,100,100,100])==0
	assert candidate(5,0,10,[100,100,100,100])==6
	assert candidate(1,14,4,0) == 2
	assert candidate(1,18,4,0) == 2
	assert candidate(17,0,10,10)==18
	assert candidate(0,0,19,0) == 0
	assert candidate(1,0,10,[100,100,100,100])==2
	assert candidate(0,0,8,0) == 0
	assert candidate(0,0,100,None) == 0
	assert candidate(13,0,10,10)==14
	assert candidate(1,0,10,{}) == 2
	assert candidate(0,0,10,None)==0
	assert candidate(1,5,2,{})==2
	assert candidate(0,0,12,0) == 0
	assert candidate(9,0,10,{}) == 10
	assert candidate(5,0,1000,None)==6
	assert candidate(0,1,2,None)==0
	assert candidate(0,0,3,None) == 0
	assert candidate(0,0,9,0) == 0
	assert candidate(13,0,1000,None)==14
	assert candidate(1,20,2,{})==2
	assert candidate(0,0,10,0) == 0
	assert candidate(0,0,21,0) == 0
	assert candidate(0,0,5,0) == 0
	assert candidate(17,0,10,None)==18
	assert candidate(1,17,2,{})==2
	assert candidate(1,2,4,0) == 2
	assert candidate(0,0,1,None) == 0
	assert candidate(0,0,13,0) == 0
	assert candidate(0,0,22,0) == 0
	assert candidate(5,0,10,10)==6
	assert candidate(1,10,4,0) == 2
	assert candidate(1,0,10,None)==2
	assert candidate(1,0,10,0) == 2
	assert candidate(0,0,3,0) == 0
	assert candidate(0,0,10,10)==0
	assert candidate(1,0,1000,None)==2
	assert candidate(0,0,0,0) == 0
	assert candidate(0,0,15,0) == 0
	assert candidate(17,0,1000,None)==18
	assert candidate(0,0,18,0) == 0
	assert candidate(1,0,100,None) == 2
	assert candidate(0,0,0,0)==0
	assert candidate(1,0,10,10)==2
	assert candidate(1,11,2,{})==2
	assert candidate(13,0,10,0) == 14
	assert candidate(11,0,10,None) == 13
	assert candidate(17,0,10,0) == 18
	assert candidate(5,0,10,0) == 6
	assert candidate(6,0,3,None) == 9
	assert candidate(9,0,10,0) == 10
	assert candidate(0,0,100,None)==0
	assert candidate(0,0,4,None)==0
	assert candidate(1,22,4,0) == 2
def test_check():
	check(next_state)
