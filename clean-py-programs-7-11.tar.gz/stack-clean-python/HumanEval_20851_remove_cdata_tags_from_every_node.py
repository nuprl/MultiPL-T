def remove_cdata_tags_from_every_node(content: str):
    """[removes a CDATA tag from every node in the document] """
    ### Canonical solution below ###
    content = content.replace(']]>', '>')
    content = content.replace('<![CDATA[', '<')
    return content


### Unit tests below ###
def check(candidate):
	assert candidate(
    '<html><head><title>XML Parsing</title></head>'
    '<body><p>This is some text.</p></body>'
    '</html>') == '<html><head><title>XML Parsing</title></head>' \
                 '<body><p>This is some text.</p></body>' \
                 '</html>'
	assert candidate(
    '<!DOCTYPE html>\n<html>\n<head>\n<title>Hello, World!</title>\n</head>\n<body>\n<h1>Hello, World!</h1>\n</body>\n</html>') == '<!DOCTYPE html>\n<html>\n<head>\n<title>Hello, World!</title>\n</head>\n<body>\n<h1>Hello, World!</h1>\n</body>\n</html>'
	assert candidate(
    "<html><head></head><body><p>this should be kept</p></body></html>") == "<html><head></head><body><p>this should be kept</p></body></html>"
	assert candidate(
    "<![CDATA[my content]]>").replace(" ", "") == "<mycontent>"
	assert candidate(
    '<![CDATA[hello]]><![CDATA[world]]>!') == '<hello><world>!'
def test_check():
	check(remove_cdata_tags_from_every_node)
