def insertion_sort(lista):
    """ Retorna a lista ordenada usando o algoritmo InsertionSort.
     """
	### Canonical solution below ###    
    for j in range(len(lista))[1:]:
        chave = lista[j]
        i = j - 1
        while i >= 0 and lista[i] > chave:
            lista[i + 1] = lista[i]
            i = i - 1
        lista[i + 1] = chave
    return lista

### Unit tests below ###
def check(candidate):
	assert candidate(list([3, 4, 1, 2])) == list([1, 2, 3, 4])
	assert candidate(list([1])) == list([1])
	assert candidate(
    [1, 3, 5, 2, 4, 6, 8, 7, 9, 0]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(list([4, 3, 7, 5, 6, 8])) == [3, 4, 5, 6, 7, 8]
	assert candidate([1, 3, 5, 2, 4]) == [1, 2, 3, 4, 5]
	assert candidate(list([3, 4, 2, 1])) == list([1, 2, 3, 4])
	assert candidate([3, 2, 1, 0]) == [0, 1, 2, 3]
	assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
	assert candidate(list([3])) == [3]
	assert candidate(list([3, 1, 2])) == [1, 2, 3]
	assert candidate([2, 1, 3, 4]) == [1, 2, 3, 4]
	assert candidate([1, 5, 3, 7, 9, 10, 6]) == [1, 3, 5, 6, 7, 9, 10]
	assert candidate(list([4, 2, 3, 1])) == list([1, 2, 3, 4])
	assert candidate(list([1, 4, 3, 2])) == list([1, 2, 3, 4])
	assert candidate(list([1, 5, 2, 4, 3])) == list([1, 2, 3, 4, 5])
	assert candidate(list([1])) == [1]
	assert candidate([5, 3, 2, 6, 1, 4]) == [1, 2, 3, 4, 5, 6]
	assert candidate([]) == []
	assert candidate(list([1, 3, 2])) == [1, 2, 3]
	assert candidate(list([5, 4, 3])) == list([3, 4, 5])
	assert candidate([5, 2, 3, 1, 4]) == [1, 2, 3, 4, 5]
	assert candidate([0, 2, 3, 1]) == [0, 1, 2, 3]
	assert candidate([1, 3, 2, 0, 4]) == [0, 1, 2, 3, 4]
	assert candidate( [1] ) == [1]
	assert candidate([10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == list(range(1, 11))
	assert candidate([4, 3, 2, 1]) == [1, 2, 3, 4]
	assert candidate(list([1, 3, 5, 2, 4])) == list([1, 2, 3, 4, 5])
	assert candidate([1, 3, 2]) == [1, 2, 3]
	assert candidate( [3,2,1] ) == [1,2,3]
	assert candidate([1]) == [1]
	assert candidate(
    [54, 26, 93, 17, 77, 31, 44, 55, 20]) == [17, 20, 26, 31, 44, 54, 55, 77, 93]
	assert candidate(list([5, 3, 1, 2, 4])) == [1, 2, 3, 4, 5]
	assert candidate(list([2, 4, 3, 1])) == list([1, 2, 3, 4])
	assert candidate( [] ) == []
	assert candidate([0, 3, 1, 2]) == [0, 1, 2, 3]
	assert candidate(list(range(10))) == list(range(10))
	assert candidate([2, 3, 1]) == [1, 2, 3]
	assert candidate( [2,3,1] ) == [1,2,3]
	assert candidate([3, 2, 5, 1]) == [1, 2, 3, 5]
	assert candidate( [3,2,1,0] ) == [0,1,2,3]
	assert candidate(list([4, 3, 1, 2])) == list([1, 2, 3, 4])
	assert candidate(list([1, 3, 2])) == list([1, 2, 3])
	assert candidate([0, 1, 2, 3]) == [0, 1, 2, 3]
	assert candidate([3, 1, 2]) == [1, 2, 3]
	assert candidate([1, 2]) == [1, 2]
	assert candidate([3, 2, 4, 1]) == [1, 2, 3, 4]
	assert candidate([1, 2, 5, 4, 3]) == [1, 2, 3, 4, 5]
	assert candidate(list([2, 3, 1])) == list([1, 2, 3])
	assert candidate([0, 3, 2, 1]) == [0, 1, 2, 3]
	assert candidate(list()) == []
	assert candidate([5, 2, 4, 6, 1, 3]) == [1, 2, 3, 4, 5, 6]
	assert candidate([4, 3, 1, 2]) == [1, 2, 3, 4]
	assert candidate(list([2, 1, 3])) == list([1, 2, 3])
	assert candidate([1, 4, 3, 2]) == [1, 2, 3, 4]
	assert candidate(list([2, 3, 1, 4])) == list([1, 2, 3, 4])
	assert candidate([0, 1, 3, 2]) == [0, 1, 2, 3]
	assert candidate([1, 3, 2, 5, 4]) == [1, 2, 3, 4, 5]
	assert candidate([5, 3, 2, 1]) == [1, 2, 3, 5]
	assert candidate([1, 3, 2, 0]) == [0, 1, 2, 3]
	assert candidate(list([2, 1])) == list([1, 2])
	assert candidate([3, 2, 1]) == [1, 2, 3]
	assert candidate(list([3, 1, 2])) == list([1, 2, 3])
	assert candidate(list([1, 2, 3, 4])) == list([1, 2, 3, 4])
	assert candidate(list([1, 5, 4, 3, 2])) == list([1, 2, 3, 4, 5])
	assert candidate(list([3, 2, 1])) == list([1, 2, 3])
	assert candidate([-2, -5, -45]) == [-45, -5, -2]
	assert candidate(list()) == list()
	assert candidate([2, 1]) == [1, 2]
	assert candidate([4, 3, 2, 1, 0]) == [0, 1, 2, 3, 4]
	assert candidate(list([2, 2, 2, 2, 2])) == [2, 2, 2, 2, 2]
	assert candidate([1, 5, 2, 4, 3]) == [1, 2, 3, 4, 5]
	assert candidate([3]) == [3]
	assert candidate(list([5, 4])) == list([4, 5])
	assert candidate(list([3, 1, 4, 2])) == list([1, 2, 3, 4])
	assert candidate(list([1, 3, 5, 2, 4])) == [1, 2, 3, 4, 5]
	assert candidate([2, 1, 3]) == [1, 2, 3]
	assert candidate([5]) == [5]
	assert candidate(list([5, 4, 3, 2, 1])) == list([1, 2, 3, 4, 5])
	assert candidate([1, 2, 3, 0]) == [0, 1, 2, 3]
	assert candidate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate(list([1, 2, 3])) == list([1, 2, 3])
	assert candidate(
    [1, 5, 2, 10, 7, 3, 6, 4, 11, 8, 9, 0]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
	assert candidate( [3,2,1,0,0,1,2,3,4,5,6,7,8,9,10] ) == [0,0,1,1,2,2,3,3,4,5,6,7,8,9,10]
	assert candidate(list([1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
	assert candidate(list([5, 4, 3, 2, 1])) == [1, 2, 3, 4, 5]
	assert candidate([0, 2, 1, 3]) == [0, 1, 2, 3]
	assert candidate(list([1, 2])) == list([1, 2])
	assert candidate(list([5, 4, 3, 2])) == list([2, 3, 4, 5])
	assert candidate(list([5, 3, 2, 4, 1])) == [1, 2, 3, 4, 5]
	assert candidate(list([4, 3, 2, 1])) == list([1, 2, 3, 4])
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(list([2, 4, 3, 1, 5])) == [1, 2, 3, 4, 5]
	assert candidate([1, 3, 2, 5, 4, 7, 6, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([2, 4, 6, 8, 10, 1, 3, 5, 7, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate( [3,2,1,0,0] ) == [0,0,1,2,3]
	assert candidate(list([2, 4, 1, 3, 5])) == [1, 2, 3, 4, 5]
	assert candidate(list(range(5))) == [0, 1, 2, 3, 4]
	assert candidate([3, 2, 1, 5]) == [1, 2, 3, 5]
	assert candidate([3, 1, 4, 2]) == [1, 2, 3, 4]
	assert candidate(list([5])) == list([5])
	assert candidate(list([1, 2, 3, 4, 5])) == list([1, 2, 3, 4, 5])
def test_check():
	check(insertion_sort)
