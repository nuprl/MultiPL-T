def indent(*args) -> str:
    """ Return joined string representations of objects with indented lines."""
	### Canonical solution below ###    
    text = '\n'.join(str(arg) for arg in args)
    return '\n'.join(
        ('  ' + line if line else line) for line in text.splitlines() if line
    )[2:]

### Unit tests below ###
def check(candidate):
	assert candidate("abc") == "abc"
	assert candidate('') == ''
	assert candidate(1, 2, 3) == '''
  1
  2
  3
'''.strip()
	assert candidate(1, 2, 3) == candidate(1, '2', 3)
	assert candidate(1) == "1"
	assert candidate() == ""
	assert candidate() == ''
	assert candidate(1) == '1'
	assert candidate(1, 2, 3) == candidate(1, 2, 3)
	assert candidate(0) == '0'
	assert candidate('one\ntwo\nthree') == 'one\n  two\n  three'
	assert candidate(1, 2, 3) == candidate('1', '2', '3')
	assert candidate(0, '') == '0'
	assert candidate(1, 2) == '1\n  2'
def test_check():
	check(indent)
