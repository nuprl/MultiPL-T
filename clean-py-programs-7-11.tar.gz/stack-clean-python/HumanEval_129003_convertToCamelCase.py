def convertToCamelCase(input, firstIsLowercase=False):
	"""Given an input string of words (separated by space), converts
	it back to camel case.

	'Foo Bar' (firstIsLowercase=False)  --> 'FooBar'
	'Foo Bar' (firstIsLowercase=True)   --> 'fooBar'
	'foo bar' (firstIsLowercase=False)  --> 'FooBar'

	Args:
	    input (str): The string of words to convert
	    firstIsLowercase (bool, optional): By default, title cases all words
	    	in the input string (i.e. 'foo bar' will become
	    	'FooBar' rather than 'fooBar'). If True, the first word is forced
	    	to become lowercase

	Returns:
	    str: The camelcased string
	"""
    ### Canonical solution below ###
	words = input.split()

	for i, word in enumerate(words):
		if i == 0 and firstIsLowercase:
			words[0] = words[0].lower()
		else:
			words[i] = words[i].title()

	return ''.join(words)


### Unit tests below ###
def check(candidate):
	assert candidate(
	'foo bar'
) == 'FooBar'
	assert candidate(
	'Foo Bar',
	firstIsLowercase=True
) == 'fooBar', "candidate failed"
	assert candidate('foo bar baz') == 'FooBarBaz'
	assert candidate(
	'foo bar') == 'FooBar', 'candidate failed'
	assert candidate(
	'foo bar baz', firstIsLowercase=False) == 'FooBarBaz', \
	"candidate('foo bar baz', firstIsLowercase=False)"
	assert candidate(input='foo Bar', firstIsLowercase=True) == 'fooBar'
	assert candidate(
	'Foo', True) == 'foo', 'candidate("Foo", True)!= "foo"'
	assert candidate(
	'Foo Bar Baz',
	firstIsLowercase=True
) == 'fooBarBaz'
	assert candidate(
	'Foo Bar',
	firstIsLowercase=True) == 'fooBar'
	assert candidate(
	'foo Bar baz', firstIsLowercase=True) == 'fooBarBaz', 'All words are forced to lowercase, even after title case'
	assert candidate(
	'foo bar baz quux',
	firstIsLowercase=False,
) == 'FooBarBazQuux'
	assert candidate(
	'foo bar baz',
	True
) == 'fooBarBaz'
	assert candidate(
	'foo bar baz quux',
	firstIsLowercase=False
) == 'FooBarBazQuux', 'foo bar baz quux'
	assert candidate(
	'Foo Bar', True) == 'fooBar', 'Simple test with first lowercase failed'
	assert candidate(
	'foo bar',
	False
) == 'FooBar'
	assert candidate(
	'foo bar baz',
	True
) == 'fooBarBaz', 'candidate failed'
	assert candidate(input='foo bar', firstIsLowercase=False) == 'FooBar'
	assert candidate(
	'foo bar',
	firstIsLowercase=False
) == 'FooBar', "candidate failed"
	assert candidate(input='Foo Bar', firstIsLowercase=True) == 'fooBar'
	assert candidate(
	'foo bar') == 'FooBar', "candidate('foo bar') failed"
	assert candidate(
	'foo bar',
	firstIsLowercase=False
) == 'FooBar'
	assert candidate(
	'Foo Bar'
) == 'FooBar'
	assert candidate(
	'foo bar baz',
	False
) == 'FooBarBaz'
	assert candidate(
	'Foo bar', True) == 'fooBar', 'candidate("Foo bar", True)!= "fooBar"'
	assert candidate(
	'foo bar',
	True
) == 'fooBar'
	assert candidate('foo bar  baz', True) == 'fooBarBaz'
	assert candidate(
	'foo bar baz quux',
	firstIsLowercase=True
) == 'fooBarBazQuux', 'foo bar baz quux'
	assert candidate('Foo Bar Baz', True) == 'fooBarBaz'
	assert candidate(
	'Foo Bar') == 'FooBar', 'Simple test failed'
	assert candidate(
	'foo bar baz',
	firstIsLowercase=False
) == 'FooBarBaz'
	assert candidate('foo  bar', True) == 'fooBar'
	assert candidate(
	'foo bar',
	firstIsLowercase=True
) == 'fooBar'
	assert candidate(
	'foo bar baz') == 'FooBarBaz', "candidate('foo bar baz')"
	assert candidate(
	'foo Bar baz',
	firstIsLowercase=True
) == 'fooBarBaz'
	assert candidate('Foo Bar', True) == 'fooBar'
	assert candidate(
	'Foo Bar', True) == 'fooBar', "candidate('Foo Bar', True) failed"
	assert candidate(
	'foo bar baz',
	False
) == 'FooBarBaz', 'candidate failed'
	assert candidate(
	'foo bar baz', True) == 'fooBarBaz', 'candidate("foo bar baz", True)!= "fooBarBaz"'
	assert candidate(input='foo bar', firstIsLowercase=True) == 'fooBar'
	assert candidate(
	'foo bar baz', firstIsLowercase=True) == 'fooBarBaz', \
	"candidate('foo bar baz', firstIsLowercase=True)"
	assert candidate(
	'Foo Bar Baz',
	firstIsLowercase=False
) == 'FooBarBaz'
	assert candidate(
	'foo bar') == 'FooBar', 'Simple test with lowercase first failed'
	assert candidate(
	'foo bar', True) == 'fooBar', 'candidate("foo bar", True)!= "fooBar"'
	assert candidate(
	'foo Bar',
	firstIsLowercase=True
) == 'fooBar'
	assert candidate(
	'Foo Bar Baz', True) == 'fooBarBaz', 'candidate("Foo Bar Baz", True)!= "fooBarBaz"'
	assert candidate(
	'Foo Bar',
	firstIsLowercase=False,
) == 'FooBar'
	assert candidate(
	'foo bar',
	firstIsLowercase=False,
) == 'FooBar'
	assert candidate(
	"foo bar", True) == "fooBar"
	assert candidate(
	'foo bar',
	firstIsLowercase=True
) == 'fooBar', "candidate failed"
	assert candidate(
	'Foo Bar',
	firstIsLowercase=False
) == 'FooBar', "candidate failed"
	assert candidate(input='foo bar') == 'FooBar'
	assert candidate(
	'foo bar baz quux',
	firstIsLowercase=False,
) == candidate(
	'foo bar baz quux',
	firstIsLowercase=False,
)
	assert candidate(
	'foo bar baz'
) == 'FooBarBaz', 'candidate failed'
	assert candidate(
	'foo bar baz quux',
	firstIsLowercase=True,
) == 'fooBarBazQuux'
	assert candidate(
	"Foo Bar", True) == "fooBar"
	assert candidate('foo bar') == 'FooBar'
	assert candidate(
	'foo Bar Baz', firstIsLowercase=True) == 'fooBarBaz', 'All words are forced to lowercase'
	assert candidate(
	'foo bar', True) == 'fooBar', 'Simple test with lowercase first failed'
	assert candidate(
	'Foo Bar') == 'FooBar'
	assert candidate(
	'foo Bar baz',
	firstIsLowercase=False
) == 'FooBarBaz'
	assert candidate(
	'foo bar baz',
	firstIsLowercase=True
) == 'fooBarBaz'
	assert candidate(
	'Foo Bar',
	firstIsLowercase=False
) == 'FooBar'
	assert candidate(input='foo bar baz', firstIsLowercase=False) == 'FooBarBaz'
	assert candidate(
	'Foo Bar', True) == 'fooBar', 'candidate failed'
	assert candidate(
	'foo Bar',
	firstIsLowercase=False
) == 'FooBar'
	assert candidate(
	'foo', True) == 'foo', 'candidate("foo", True)!= "foo"'
	assert candidate('') == ''
	assert candidate(
	'Foo Bar',
	firstIsLowercase=True,
) == 'fooBar'
	assert candidate('foo bar baz', True) == 'fooBarBaz'
	assert candidate(
	'Foo Bar') == 'FooBar', 'candidate failed'
	assert candidate('foo bar', True) == 'fooBar'
	assert candidate(
	'Foo Bar',
	firstIsLowercase=True
) == 'fooBar'
	assert candidate(
	'foo Bar', firstIsLowercase=True) == 'fooBar', 'First word is forced to lowercase'
	assert candidate(
	'Foo Bar',
	firstIsLowercase=True
) == 'fooBar', 'First word should be lowercase'
	assert candidate(input='Foo Bar', firstIsLowercase=False) == 'FooBar'
	assert candidate(
	'Foo Bar') == 'FooBar', "candidate('Foo Bar') failed"
	assert candidate(
	'Foo Bar',
	firstIsLowercase=False
) == 'FooBar', 'First word should be uppercase'
def test_check():
	check(convertToCamelCase)
