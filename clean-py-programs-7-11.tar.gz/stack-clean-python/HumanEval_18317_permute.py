def permute(v):
    """
    permute 16 bits values (Vol 6, Part B, 4.5.8.3.2)
    """
    ### Canonical solution below ###
    b0 = int(bin((v&0xff00)>>8)[2:].rjust(8,'0')[::-1], 2)
    b1 = int(bin((v&0x00ff))[2:].rjust(8,'0')[::-1], 2)
    return (b0<<8) | b1


### Unit tests below ###
def check(candidate):
	assert candidate(0x1000) == 0x0800
	assert candidate(0x0004) == 0x0020
	assert candidate(0x000b) == 0x00d0
	assert candidate(0x0020) == 0x0004
	assert candidate(0x0013) == 0x00c8
	assert candidate(0xFFFF) == 0xFFFF
	assert candidate(0xf0f0) == 0x0f0f
	assert candidate(0x0009) == 0x0090
	assert candidate(0x0100) == 0x8000
	assert candidate(0x0200) == 0x4000
	assert candidate(0x0011) == 0x0088
	assert candidate(0x0040) == 0x0002
	assert candidate(0x5a5a) == 0x5a5a
	assert candidate(0x0002) == 0x0040
	assert candidate(0x6666) == 0x6666
	assert candidate(0x0012) == 0x0048
	assert candidate(0x000d) == 0x00b0
	assert candidate(0x0f0f) == 0xf0f0
	assert candidate(0x0000) == 0x0000
	assert candidate(0x0005) == 0x00a0
	assert candidate(0x0007) == 0x00e0
	assert candidate(0x0080) == 0x0001
	assert candidate(0x55AA) == 0xAA55
	assert candidate(0x2000) == 0x0400
	assert candidate(0x0006) == 0x0060
	assert candidate(0x000e) == 0x0070
	assert candidate(0x0001) == 0x0080
	assert candidate(0x0400) == 0x2000
	assert candidate(0x9999) == 0x9999
	assert candidate(0x0008) == 0x0010
	assert candidate(0xffff) == 0xffff
	assert candidate(0x4000) == 0x0200
	assert candidate(0x0003) == 0x00c0
	assert candidate(0x1122) == 0x8844
	assert candidate(0x000c) == 0x0030
	assert candidate(0x8000) == 0x0100
	assert candidate(0x0800) == 0x1000
	assert candidate(0x000a) == 0x0050
	assert candidate(0x000f) == 0x00f0
	assert candidate(0x0010) == 0x0008
def test_check():
	check(permute)
