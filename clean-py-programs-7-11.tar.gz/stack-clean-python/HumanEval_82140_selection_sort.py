def selection_sort(lista):
    """ Retorna a lista ordenada usando o algoritmo SelectionSort.
     """
	### Canonical solution below ###    
    for i in range(len(lista)):
        menor = i
        for j in range(i + 1, len(lista)):
            if lista[j] < lista[menor]:
                menor = j
        temp = lista[menor]
        lista[menor] = lista[i]
        lista[i] = temp
    return lista

### Unit tests below ###
def check(candidate):
	assert candidate(candidate([1, 3, 1, 2])) == [1, 1, 2, 3]
	assert candidate(list(range(10))) == sorted(list(range(10)))
	assert candidate(
    [1]) == [1], "Tente com [1]"
	assert candidate(list(range(5))) == [0, 1, 2, 3, 4]
	assert candidate(list([5, 4, 3, 2, 1])) == list([1, 2, 3, 4, 5])
	assert candidate( [5, 4, 3, 2, 1] ) == [1, 2, 3, 4, 5]
	assert candidate([5, 2, 6, 3, 1, 4]) == [1, 2, 3, 4, 5, 6]
	assert candidate(list([2, 1, 3])) == list([1, 2, 3])
	assert candidate([6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6]
	assert candidate( [3,1,4,2] ) == [1,2,3,4]
	assert candidate([42, 1, 5, 3, 6]) == [1, 3, 5, 6, 42]
	assert candidate([3, 5, 4, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate([3, 4, 1, 2]) == [1, 2, 3, 4]
	assert candidate(list([3, 2, 1])) == list([1, 2, 3])
	assert candidate([1, 3, 2, 5, 4]) == [1, 2, 3, 4, 5]
	assert candidate(candidate([3, 2, 1])) == [1, 2, 3]
	assert candidate(candidate([2, 1, 3])) == [1, 2, 3]
	assert candidate([1, 5, 3, 4, 2]) == [1, 2, 3, 4, 5]
	assert candidate(list([1, 2, 3])) == list([1, 2, 3])
	assert candidate(candidate([2, 3, 1])) == [1, 2, 3]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == sorted([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
	assert candidate([2, 4, 1, 3, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
	assert candidate(
    [5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5], "Tente com [5, 4, 3, 2, 1]"
	assert candidate([1, 2, 4, 3]) == [1, 2, 3, 4]
	assert candidate([2, 1, 1]) == [1, 1, 2]
	assert candidate( [1,3,2,4] ) == [1,2,3,4]
	assert candidate([42]) == [42]
	assert candidate([2, 1, 4, 3]) == [1, 2, 3, 4]
	assert candidate([2, 3, 1, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([5, 3, 4, 6, 2]) == [2, 3, 4, 5, 6]
	assert candidate(list([2])) == list([2])
	assert candidate( [1,4,3,2] ) == [1,2,3,4]
	assert candidate([4, 2, 3, 1, 0]) == [0, 1, 2, 3, 4]
	assert candidate( [2,3,4,1] ) == [1,2,3,4]
	assert candidate( [1, 2, 3, 4, 5] ) == [1, 2, 3, 4, 5]
	assert candidate([2, 1, 3]) == [1, 2, 3]
	assert candidate([3, 2, 4, 1]) == [1, 2, 3, 4]
	assert candidate(
    [5, 2, 4, 1, 3]) == [1, 2, 3, 4, 5], "Tente com [5, 2, 4, 1, 3]"
	assert candidate([3, 1, 2, 4]) == [1, 2, 3, 4]
	assert candidate([1, 3, 2, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([5, 3, 4, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate([2]) == [2]
	assert candidate([1, 0]) == [0, 1]
	assert candidate([1, 1, 1]) == [1, 1, 1]
	assert candidate([3, 2, 1]) == [1, 2, 3]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
	assert candidate([1, 3, 4, 2]) == [1, 2, 3, 4]
	assert candidate([42, 1, 5, 3, 6, 9, 10, 2]) == [1, 2, 3, 5, 6, 9, 10, 42]
	assert candidate([1]) == [1]
	assert candidate(
    [54, 26, 93, 17, 77, 31, 44, 55, 20]) == [17, 20, 26, 31, 44, 54, 55, 77, 93]
	assert candidate( [3,4,2,1] ) == [1,2,3,4]
	assert candidate(list([4, 3, 2, 1])) == list([1, 2, 3, 4])
	assert candidate([1, 2, 0, 4, 3]) == [0, 1, 2, 3, 4]
	assert candidate(list()) == []
	assert candidate(list([1])) == list([1])
	assert candidate(list([3, 1, 2])) == list([1, 2, 3])
	assert candidate( [3,2,1,4] ) == [1,2,3,4]
	assert candidate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate(candidate([2, 1, 1, 3])) == [1, 1, 2, 3]
	assert candidate(candidate([1, 2, 3, 1])) == [1, 1, 2, 3]
	assert candidate(list([1, 3, 2])) == list([1, 2, 3])
	assert candidate(candidate([1, 1, 2, 3])) == [1, 1, 2, 3]
	assert candidate([2, 3, 1]) == [1, 2, 3]
	assert candidate([3, 1, 2]) == [1, 2, 3]
	assert candidate( [4,3,1,2] ) == [1,2,3,4]
	assert candidate(list([2, 1])) == list([1, 2])
	assert candidate([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate([1, 4, 3, 5, 2]) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
	assert candidate([2, 3, 1, 4]) == [1, 2, 3, 4]
	assert candidate([1, 2]) == [1, 2]
	assert candidate([5, 3, 1, 2, 4]) == [1, 2, 3, 4, 5]
	assert candidate(candidate([2, 1, 3, 1])) == [1, 1, 2, 3]
	assert candidate(list(reversed(range(10)))) == sorted(list(reversed(range(10))))
	assert candidate([1, 3, 2]) == [1, 2, 3]
	assert candidate([1, 4, 2, 3]) == [1, 2, 3, 4]
	assert candidate( [2,4,3,1] ) == [1,2,3,4]
	assert candidate(candidate([1, 2, 3])) == [1, 2, 3]
	assert candidate( [4,2,3,1] ) == [1,2,3,4]
	assert candidate([4, 2, 1, 3]) == [1, 2, 3, 4]
	assert candidate([1, 4, 3, 2]) == [1, 2, 3, 4]
	assert candidate(list(range(100))) == list(range(100))
	assert candidate([2, 1, 2]) == [1, 2, 2]
	assert candidate(
    []) == [], "Tente com []"
	assert candidate( [1, 3, 2, 5, 4] ) == [1, 2, 3, 4, 5]
	assert candidate([1, 3, 5, 2, 4]) == [1, 2, 3, 4, 5]
	assert candidate([]) == []
	assert candidate([2, 5, 1, 6, 3, 7, 4, 8, 0, 9]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([42, 1, 5, 3, 6, 9]) == [1, 3, 5, 6, 9, 42]
	assert candidate( [4,1,3,2] ) == [1,2,3,4]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate([2, 1, 5, 3, 4]) == [1, 2, 3, 4, 5]
	assert candidate([2, 1, 3, 4]) == [1, 2, 3, 4]
	assert candidate(list([2, 3, 1])) == list([1, 2, 3])
	assert candidate( [1,2,3,4] ) == [1,2,3,4]
	assert candidate([1, 2, 2]) == [1, 2, 2]
	assert candidate([42, 1, 5, 3, 6, 9, 10]) == [1, 3, 5, 6, 9, 10, 42]
	assert candidate([42, 1]) == [1, 42]
	assert candidate([2, 2, 1]) == [1, 2, 2]
	assert candidate( [5, 4, 3, 1, 2] ) == [1, 2, 3, 4, 5]
	assert candidate(
    [1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5], "Tente com [1, 2, 3, 4, 5]"
	assert candidate([4, 2, 3, 1]) == [1, 2, 3, 4]
	assert candidate( [4,3,2,1] ) == [1,2,3,4]
	assert candidate(candidate([3, 1, 2])) == [1, 2, 3]
	assert candidate( [2,1,4,3] ) == [1,2,3,4]
	assert candidate([1, 2, 1]) == [1, 1, 2]
	assert candidate( [1,2,4,3] ) == [1,2,3,4]
	assert candidate( [2,3,1,4] ) == [1,2,3,4]
	assert candidate([2, 4, 3, 1])
	assert candidate([-2, -5, -45]) == [-45, -5, -2]
	assert candidate([1, 3, 2, 4]) == [1, 2, 3, 4]
	assert candidate(candidate([1, 2, 1, 3])) == [1, 1, 2, 3]
	assert candidate([2, 4, 3, 1]) == [1, 2, 3, 4]
	assert candidate( [3,2,4,1] )
	assert candidate([11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
	assert candidate([42, 1, 5]) == [1, 5, 42]
	assert candidate([10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([3, 1, 4, 2]) == [1, 2, 3, 4]
	assert candidate(candidate([1, 3, 2])) == [1, 2, 3]
	assert candidate([2, 1]) == [1, 2]
	assert candidate([1, 1, 1, 1, 1]) == [1, 1, 1, 1, 1]
	assert candidate([5, 2, 7, 1, 8, 3]) == [1, 2, 3, 5, 7, 8]
	assert candidate([5, 2, 3, 1, 4]) == [1, 2, 3, 4, 5]
	assert candidate([1, 1, 2]) == [1, 1, 2]
	assert candidate(list()) == list()
	assert candidate(list(range(10))) == list(range(10))
	assert candidate(list(range(0, 100, 10))) == list(range(0, 100, 10))
	assert candidate([4, 2, 5, 3, 1]) == [1, 2, 3, 4, 5]
	assert candidate([4, 3, 2, 1]) == [1, 2, 3, 4]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
def test_check():
	check(selection_sort)
