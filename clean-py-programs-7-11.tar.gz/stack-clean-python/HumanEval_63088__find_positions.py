def _find_positions(hash_list, pHash, pattern, text):
    """
    Function for finding position of pattern in text

    Args:
        hash_list: list of hashes from text
        pHash: hash of pattern
        pattern: pattern itself
        text:  text itself

    Returns:
        list of positions where pattern was found

    """
    ### Canonical solution below ###

    result = []
    for i in range(0, len(text) - len(pattern) + 1):
        if pHash != hash_list[i]:
            continue
        if text[i:i + len(pattern)] == pattern:  # Only if hashes are the same we compare text symbol by symbol
            result.append(i)
    return result


### Unit tests below ###
def check(candidate):
	assert candidate(list(map(hash, 'aaaaa')), hash('a'), 'a', 'aaaaa') == [0, 1, 2, 3, 4]
	assert candidate(list(map(hash, 'abracadabra')), hash('kadab'), 'kadab', 'abracadabra') == []
	assert candidate(list(map(hash, 'abracadabra')), hash('abraccad'), 'abraccad', 'abracadabra') == []
	assert candidate(list(map(hash, 'aaaaa')), hash('b'), 'a', 'aaaaa') == []
	assert candidate(list("ABCDE"), 1, "B", "ABCDE") == []
	assert candidate(list('abcdefghijklmnopqrstuvwxyz'), 100, 'defgh', 'abcdefghijklmnopqrstuvwxy') == []
	assert candidate(list("ABCDE"), 6, "F", "ABCDE") == []
	assert candidate(list(map(hash, 'abracadabra')), hash('abracc'), 'abracc', 'abracadabra') == []
	assert candidate(list("ABCDE"), 0, "BCD", "ABCDE") == []
	assert candidate(list("ABCDE"), 1, "BCD", "ABCDE") == []
	assert candidate(list("ABCDE"), 0, "B", "ABCDE") == []
def test_check():
	check(_find_positions)
