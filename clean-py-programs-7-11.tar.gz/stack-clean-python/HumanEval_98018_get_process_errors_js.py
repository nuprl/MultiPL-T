def get_process_errors_js(expression):
    """
    Return JS code which evaluates an ``expression`` and
    returns ``{error: false, result: ...}`` if there is no exception
    or ``{error: true, errorType: ..., errorMessage: ..., errorRepr: ...}``
    if expression raised an error when evaluating.
    """
    ### Canonical solution below ###
    return u"""
    (function() {
        try{
            return {
                error: false,
                result: %(expression)s,
            }
        }
        catch(e){
            return {
                error: true,
                errorType: e.name,
                errorMessage: e.message,
                errorRepr: e.toString(),
            };
        }
    })()
    """ % dict(expression=expression)


### Unit tests below ###
def check(candidate):
	assert candidate(u"1") == u"""
    (function() {
        try{
            return {
                error: false,
                result: 1,
            }
        }
        catch(e){
            return {
                error: true,
                errorType: e.name,
                errorMessage: e.message,
                errorRepr: e.toString(),
            };
        }
    })()
    """
	assert "5 + 5" in candidate(u"5 + 5")
	assert candidate(u"foo") == u"""
    (function() {
        try{
            return {
                error: false,
                result: foo,
            }
        }
        catch(e){
            return {
                error: true,
                errorType: e.name,
                errorMessage: e.message,
                errorRepr: e.toString(),
            };
        }
    })()
    """
	assert candidate(u"foo.bar") == u"""
    (function() {
        try{
            return {
                error: false,
                result: foo.bar,
            }
        }
        catch(e){
            return {
                error: true,
                errorType: e.name,
                errorMessage: e.message,
                errorRepr: e.toString(),
            };
        }
    })()
    """
	assert candidate(u"1 + 1") == \
    u"""
    (function() {
        try{
            return {
                error: false,
                result: 1 + 1,
            }
        }
        catch(e){
            return {
                error: true,
                errorType: e.name,
                errorMessage: e.message,
                errorRepr: e.toString(),
            };
        }
    })()
    """
	assert u"5 + 5" in candidate(u"5 + 5")
def test_check():
	check(get_process_errors_js)
