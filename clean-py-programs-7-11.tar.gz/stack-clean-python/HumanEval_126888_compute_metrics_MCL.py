def compute_metrics_MCL(pred, gt):
    """
    Compute the metrics {Precision, Recall, F1-score} for MCL.

    :param pred: target algorithm's output
    :param gt: ground truth

    :return dictionary of computed metrics
    """
    ### Canonical solution below ###
    metrics = {}

    tp = len(set(pred).intersection(set(gt)))
    fp = len(set(pred).difference(set(gt)))
    fn = len(set(gt).difference(set(pred)))

    metrics[f'precision'] = p = 0 if tp+fp == 0 else tp / (tp + fp)
    metrics[f'recall'] = r = 0 if tp+fn == 0 else tp / (tp + fn)
    metrics[f'F1-score'] = 0 if p+r == 0 else 2 * (p * r) / (p + r)

    return metrics


### Unit tests below ###
def check(candidate):
	assert candidate(pred=[], gt=['a', 'b', 'c']) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(pred=[1,2,3], gt=[1,2,3]) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0,
}
	assert candidate(pred=[1, 1, 2], gt=[]) == {'precision': 0.0,'recall': 0.0, 'F1-score': 0.0}
	assert candidate(pred=[0, 1, 2], gt=[0, 1, 2]) == {'precision': 1.0,'recall': 1.0, 'F1-score': 1.0}
	assert candidate(pred=[1, 2, 3], gt=[4, 5, 6]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(pred = [1, 2, 3], gt = []) == {f'precision': 0.0, f'recall': 0.0, f'F1-score': 0.0}
	assert candidate(pred = [], gt = [1, 2, 3]) == {f'precision': 0.0, f'recall': 0.0, f'F1-score': 0.0}
	assert candidate(pred=['a', 'b', 'c'], gt=['d', 'e', 'f']) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(
    ['A', 'B', 'C'],
    ['A', 'B', 'D']
) == {
    'precision': 0.6666666666666666,
   'recall': 0.6666666666666666,
    'F1-score': 0.6666666666666666
}
	assert candidate(pred=[1, 2, 3], gt=[]) == {'precision': 0,'recall': 0, 'F1-score': 0}
	assert candidate(pred=[1, 2, 3], gt=[4, 5, 6]) == {'precision': 0.0,'recall': 0.0, 'F1-score': 0.0}
	assert candidate(pred=[0, 1, 1, 2, 3, 4, 4, 5], gt=[0, 1, 1, 2, 3, 4, 4, 5]) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0
}
	assert candidate(pred=['a', 'b', 'c'], gt=['a', 'b', 'c']) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0
}
	assert candidate(pred=[0, 1, 2], gt=[0, 1, 2]) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0
}
	assert candidate(
    pred=['a', 'b', 'c'],
    gt=['a', 'b', 'd']) == {
        'precision': 2/3,
       'recall': 2/3,
        'F1-score': 2/3}
	assert candidate(pred=[1, 2, 3], gt=[]) == {'precision': 0.0,'recall': 0.0, 'F1-score': 0.0}
	assert candidate(pred=[1,2,3], gt=[4,5,6]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0,
}
	assert candidate(set([]), set([1,2,3])) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(pred=[1,2,3,4,5,6], gt=[1,2,3,4,5,6]) == {
    'precision': 1.0,'recall': 1.0, 'F1-score': 1.0
}
	assert candidate(pred=[1, 2, 3], gt=[1, 2, 3]) == {'precision': 1,'recall': 1, 'F1-score': 1}
	assert candidate(set([1,2,3]), set([1,2,3])) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0
}
	assert candidate(pred=[1, 2, 3, 4], gt=[1, 2, 3, 4]) == {'precision': 1,'recall': 1, 'F1-score': 1}
	assert candidate(pred=[], gt=['A', 'B', 'C']) == {'precision': 0,'recall': 0, 'F1-score': 0}
	assert candidate(pred=['a', 'b', 'c'], gt=['a', 'b', 'c', 'd']) == {
    'precision': 1.0,
   'recall': 0.75,
    'F1-score': 0.8571428571428571
}
	assert candidate(pred=[], gt=[]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(pred=[1, 2], gt=[1, 2, 3]) == {
    'precision': 1,
   'recall': 0.6666666666666666,
    'F1-score': 0.8
}
	assert candidate(pred=[1, 2, 3, 4], gt=[]) == {'precision': 0,'recall': 0, 'F1-score': 0}
	assert candidate(pred=[1, 2, 3], gt=[4, 5]) == {'precision': 0,'recall': 0, 'F1-score': 0}
	assert candidate(pred=[], gt=[1, 2]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(
    ['A', 'B', 'C'],
    ['A', 'B', 'C']
) == {
    'precision': 1,
   'recall': 1,
    'F1-score': 1
}
	assert candidate(pred=[1, 2], gt=[1, 2]) == {
    'precision': 1,
   'recall': 1,
    'F1-score': 1
}
	assert candidate(pred=['a', 'b', 'c'], gt=['a', 'b', 'c']) == {'precision': 1.0,'recall': 1.0, 'F1-score': 1.0}
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]) == {'precision': 1.0,'recall': 1.0, 'F1-score': 1.0}
	assert candidate(pred=[1, 2, 3], gt=[1, 2, 3]) == {
    'precision': 1,
   'recall': 1,
    'F1-score': 1
}
	assert candidate(pred=['a', 'b', 'c'], gt=[]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(set([1,2]), set([1,2])) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0
}
	assert candidate(pred=[1, 2, 3], gt=[1, 2, 4]) == {'precision': 0.6666666666666666,'recall': 0.6666666666666666, 'F1-score': 0.6666666666666666}
	assert candidate(
    pred=[],
    gt=['a']) == {
        'precision': 0,
       'recall': 0,
        'F1-score': 0}
	assert candidate(
    pred=[],
    gt=['A', 'B', 'C']
) == {
    'precision': 0,
   'recall': 0,
    'F1-score': 0
}
	assert candidate(pred=[1, 2, 3], gt=[1, 2, 3]) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0
}
	assert candidate(pred=['A', 'B', 'C'], gt=['A', 'B', 'C']) == {'precision': 1,'recall': 1, 'F1-score': 1}
	assert candidate(
    ['A', 'B', 'C'],
    ['D']
) == {
    'precision': 0,
   'recall': 0,
    'F1-score': 0
}
	assert candidate(pred = [], gt = []) == {f'precision': 0.0, f'recall': 0.0, f'F1-score': 0.0}
	assert candidate(pred=[], gt=[1, 2]) == {'precision': 0.0,'recall': 0.0, 'F1-score': 0.0}
	assert candidate(set([1,2,3]), set([])) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(pred=[0, 1, 2, 3], gt=[0, 1, 2, 3]) == {
    'precision': 1.0,
   'recall': 1.0,
    'F1-score': 1.0
}
	assert candidate(pred=[1, 2, 3], gt=[1, 2, 3]) == {'precision': 1.0,'recall': 1.0, 'F1-score': 1.0}
	assert candidate(set([1, 2, 3]), set([1, 2, 3])) == {'precision': 1.0,'recall': 1.0, 'F1-score': 1.0}
	assert candidate(pred=[1, 2, 3], gt=[]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(
    pred=['A', 'B', 'C'],
    gt=['B', 'C', 'D']
) == {
    'precision': 2/3,
   'recall': 2/3,
    'F1-score': 2/3
}
	assert candidate(pred=[1, 2], gt=[1, 2]) == {'precision': 1.0,'recall': 1.0, 'F1-score': 1.0}
	assert candidate(set(), set()) == {'precision': 0.0,'recall': 0.0, 'F1-score': 0.0}
	assert candidate(pred=[], gt=[1, 2, 3]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(pred=['a', 'b', 'c'], gt=['d', 'd', 'd']) == {'precision': 0.0,'recall': 0.0, 'F1-score': 0.0}
	assert candidate(pred=[1, 2, 3], gt=[1, 2, 3, 4]) == {
    'precision': 1.0,
   'recall': 0.75,
    'F1-score': 0.8571428571428571
}
	assert candidate(pred=[1, 2, 3], gt=[4]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(pred=[0, 1, 2], gt=[]) == {
    'precision': 0.0,
   'recall': 0.0,
    'F1-score': 0.0
}
	assert candidate(
    pred=['A', 'B', 'C'],
    gt=['A', 'B', 'C']
) == {
    'precision': 1,
   'recall': 1,
    'F1-score': 1
}
	assert candidate(
    pred=['A', 'B', 'C'],
    gt=[]
) == {
    'precision': 0,
   'recall': 0,
    'F1-score': 0
}
	assert candidate(
    pred=['a', 'b'],
    gt=['a', 'b']) == {
        'precision': 1,
       'recall': 1,
        'F1-score': 1}
	assert candidate(pred = [1, 2, 3], gt = [1, 2, 3]) == {f'precision': 1.0, f'recall': 1.0, f'F1-score': 1.0}
	assert candidate(set([1, 2]), set([1, 2])) == {'precision': 1.0,'recall': 1.0, 'F1-score': 1.0}
def test_check():
	check(compute_metrics_MCL)
