def capwords(s, sep=None):
    """ capwords(s [,sep]) -> string
     Split the argument into words using split, capitalize each
     word using capitalize, and join the capitalized words using
     join.  If the optional second argument sep is absent or None,
     runs of whitespace characters are replaced by a single space
     and leading and trailing whitespace are removed, otherwise
     sep is used to split and join the words.
     """
	### Canonical solution below ###    
    return (sep or ' ').join(x.capitalize() for x in s.split(sep))

### Unit tests below ###
def check(candidate):
	assert candidate(
    'a short sentence', None) == 'A Short Sentence', 'candidate test 13'
	assert candidate('\t\ta\nb\tc\td\te\tf\t\t') == 'A B C D E F'
	assert candidate(
    'hello, world') == 'Hello, World', 'candidate hello, world'
	assert candidate( 'hello world', '@@' ) == 'Hello world'
	assert candidate(
    'hello\tworld') == 'Hello World', 'candidate hello\tworld'
	assert candidate(
   '  aLPHA   bETa   gAMMA   dELTA   ') == 'Alpha Beta Gamma Delta'
	assert candidate( 'abc def' ) == 'Abc Def'
	assert candidate( 'abc\rdef' ) == 'Abc Def'
	assert candidate(
    'look: it is working!') == 'Look: It Is Working!', 'candidate test 7'
	assert candidate(' i like fishing') == 'I Like Fishing'
	assert candidate('   aBc  dEf   ') == 'Abc Def'
	assert candidate('abc\t def  \nghi') == 'Abc Def Ghi'
	assert candidate('alpha   beta   gamma delta   epsilon') == 'Alpha Beta Gamma Delta Epsilon'
	assert candidate(
    'hello       world'
) == 'Hello World'
	assert candidate('   alpha\t\tbeta\t\tgamma\t\tdelta\t\tepsilon   ') == 'Alpha Beta Gamma Delta Epsilon'
	assert candidate(
    'hello world') == 'Hello World', 'candidate hello world'
	assert candidate(
    'look: it is working!') == 'Look: It Is Working!', 'candidate test 5'
	assert candidate(
    '\taLPHA\t\t\tbETa\t\t\tgAMMA\t\t\tdELTA\t\t') == 'Alpha Beta Gamma Delta'
	assert candidate(
    'hello, world') == 'Hello, World'
	assert candidate(
    'alpha\tbeta\tgamma\tdelta') == 'Alpha Beta Gamma Delta'
	assert candidate(
    'a short sentence') == 'A Short Sentence', 'candidate test 1'
	assert candidate( 'hello\nworld' ) == 'Hello World'
	assert candidate('ABC\tdef') == 'Abc Def'
	assert candidate(
    'alpha beta gamma delta epsilon') == 'Alpha Beta Gamma Delta Epsilon'
	assert candidate( 'hello_world' ) == 'Hello_world'
	assert candidate('i like fishing, and eating') == 'I Like Fishing, And Eating'
	assert candidate(
    'look: it is working!') == 'Look: It Is Working!', 'candidate test 8'
	assert candidate(' alpha\t\tbeta\t\tgamma\t\tdelta\t\tepsilon') == 'Alpha Beta Gamma Delta Epsilon'
	assert candidate('abc\tdef\nghi\njkl\tmno\npqr\nstu\nvwx\nyz') == 'Abc Def Ghi Jkl Mno Pqr Stu Vwx Yz'
	assert candidate( 'abc\t  def ') == 'Abc Def'
	assert candidate('\t\t\t\t') == ''
	assert candidate( 'abc\tdef' ) == 'Abc Def'
	assert candidate(
    '123hello world', '_'
) == '123hello world'
	assert candidate('\taBc\t\tdEf\t\t') == 'Abc Def'
	assert candidate('\ta\nb\tc\td\te\tf\t') == 'A B C D E F'
	assert candidate(r'  hello  world  ') == 'Hello World'
	assert candidate(
    'alpha   beta   gamma   delta') == 'Alpha Beta Gamma Delta'
	assert candidate(
    'hello      world',
) == 'Hello World'
	assert candidate(
    'hello-world',
    '-',
) == 'Hello-World'
	assert candidate( 'abc def   ghi' ) == 'Abc Def Ghi'
	assert candidate(
   '   hello world    '
) == 'Hello World'
	assert candidate(
    'alpha beta gamma delta') == 'Alpha Beta Gamma Delta'
	assert candidate('abc\tdef\nghi') == 'Abc Def Ghi'
	assert candidate(
    'hello world') == 'Hello World'
	assert candidate('12345') == '12345'
	assert candidate( 'abc\vdef' ) == 'Abc Def'
	assert candidate('ABC\tDEF') == 'Abc Def'
	assert candidate('  abc   def   ghi  ') == 'Abc Def Ghi'
	assert candidate(
   '  hello   world  ') == 'Hello World'
	assert candidate('ABC DEF', None) == 'Abc Def'
	assert candidate( 'abc\ndef' ) == 'Abc Def'
	assert candidate('ABC-DEF', '-') == 'Abc-Def'
	assert candidate( 'abc\t   def  \nghi' ) == 'Abc Def Ghi'
	assert candidate(
    'hello    world'
) == 'Hello World'
	assert candidate('   abc def   ') == 'Abc Def'
	assert candidate( 'hello    world' ) == 'Hello World'
	assert candidate( 'hello_world', '_' ) == 'Hello_World'
	assert candidate(
    'hello world, how are you this fine Tuesday?') == \
    'Hello World, How Are You This Fine Tuesday?'
	assert candidate( 'abc\x0bdef' ) == 'Abc Def'
	assert candidate( 'abc\x0cdef' ) == 'Abc Def'
	assert candidate( 'hello world' ) == 'Hello World'
	assert candidate(' alpha\tbeta\tgamma\tdelta\tepsilon') == 'Alpha Beta Gamma Delta Epsilon'
	assert candidate( 'abc\t  def  \nghi' ) == 'Abc Def Ghi'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'candidate test 3'
	assert candidate('') == ''
	assert candidate(
   '  hello   world   ') == 'Hello World'
	assert candidate( 'abc\tdef\nghi' ) == 'Abc Def Ghi'
	assert candidate(
    'alpha beta gamma delta epsilon zeta eta theta iota kappa '
    'lambda mu nu xi omicron pi rho sigma tau upsilon phi chi '
    'psi omega') == (
    'Alpha Beta Gamma Delta Epsilon Zeta Eta Theta Iota Kappa '
    'Lambda Mu Nu Xi Omicron Pi Rho Sigma Tau Upsilon Phi Chi '
    'Psi Omega')
	assert candidate( 'hello   world' ) == 'Hello World'
	assert candidate(
    'hello world',
) == 'Hello World'
	assert candidate(
    'hello_world',
) == 'Hello_world'
	assert candidate(r'hello world') == r'Hello World'
	assert candidate(
    'hello    world') == 'Hello World', 'candidate hello    world'
	assert candidate('i like fishing ') == 'I Like Fishing'
	assert candidate('i like fishing') == 'I Like Fishing'
	assert candidate('ABC DEF GHI JKL MNO PQR STU VWX YZ') == 'Abc Def Ghi Jkl Mno Pqr Stu Vwx Yz'
	assert candidate('  abc def   ghi' ) == 'Abc Def Ghi'
	assert candidate(
    'a lazy fox') == 'A Lazy Fox', 'candidate test 2'
	assert candidate( 'abc  def   ghi' ) == 'Abc Def Ghi'
	assert candidate('hello world') == 'Hello World'
	assert candidate( 'hello\tworld' ) == 'Hello World'
	assert candidate(
   ' hello world  '
) == 'Hello World'
	assert candidate('abc def ghi') == 'Abc Def Ghi'
	assert candidate('ABC-DEF-GHI', '-') == 'Abc-Def-Ghi'
	assert candidate(
    'hello\t \tworld\r\n') == 'Hello World'
	assert candidate( 'abc def ghi' ) == 'Abc Def Ghi'
	assert candidate(
    'hello world'
) == 'Hello World'
	assert candidate(
    'abc def ghi jkl mno pqr stu vwx yz') == 'Abc Def Ghi Jkl Mno Pqr Stu Vwx Yz'
	assert candidate(
    'hello-world',
) == 'Hello-world'
def test_check():
	check(capwords)
