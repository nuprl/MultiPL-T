def percentage_string(val):
    """ Returns a percentage-formatted string for a value, e.g. 0.9234 becomes 92.34% """
    ### Canonical solution below ###

    return '{:,.2%}'.format(val)


### Unit tests below ###
def check(candidate):
	assert candidate(0.000000000001) == '0.00%'
	assert candidate(0.0000000001) == '0.00%'
	assert candidate(1.0000000000000001) == '100.00%'
	assert candidate(1.01) == '101.00%', 'candidate(1.01) should be 101.00%'
	assert candidate(0.00000000001234) == '0.00%'
	assert candidate(1.00000000000000011) == '100.00%'
	assert candidate(0.00000001) == '0.00%'
	assert candidate(0.9234) == '92.34%'
	assert candidate(0.1234) == '12.34%'
	assert candidate(0) == '0.00%'
	assert candidate(0.92349) == '92.35%'
	assert candidate(0.00000001234) == '0.00%'
	assert candidate(1.0) == '100.00%', 'candidate(1.0) should be 100.00%'
	assert candidate(0.00001234) == '0.00%'
	assert candidate(0.9234) == '92.34%', 'candidate(0.9234) should be 92.34%'
	assert candidate(0.123456) == '12.35%'
	assert candidate(1.00001) == '100.00%'
	assert candidate(0.12345678) == '12.35%'
	assert candidate(0.00000000001) == '0.00%'
	assert candidate(0.0000000000000001) == '0.00%'
	assert candidate(0.99999999) == '100.00%'
	assert candidate(0.00000000000001) == '0.00%'
	assert candidate(0.00000000000000001) == '0.00%'
	assert candidate(0.00000000000001234) == '0.00%'
	assert candidate(0.9234000000000001) == "92.34%"
	assert candidate(0.92341) == '92.34%'
	assert candidate(0.0001) == '0.01%'
	assert candidate(0.92345) == '92.34%'
	assert candidate(0.000000000001234) == '0.00%'
	assert candidate(0.000001234) == '0.00%'
	assert candidate(0.000001) == '0.00%'
	assert candidate(0.99999) == "100.00%", "candidate(0.99999) should return 100.00%"
	assert candidate(0.9999) == '99.99%'
	assert candidate(0.9234) == "92.34%"
	assert candidate(0.0000001234) == '0.00%'
	assert candidate(0.0) == '0.00%'
	assert candidate(0.000000000000001) == '0.00%'
	assert candidate(0.0) == "0.00%"
	assert candidate(0.123) == '12.30%'
	assert candidate(0.01) == '1.00%', 'candidate(0.01) should be 1.00%'
	assert candidate(0.000000001) == '0.00%'
	assert candidate(0.12345) == '12.35%'
	assert candidate(0.0234) == '2.34%'
	assert candidate(0.01) == '1.00%'
	assert candidate(0.001) == '0.10%'
	assert candidate(0.1) == '10.00%'
	assert candidate(0.0000001) == '0.00%'
	assert candidate(0.9234) == "92.34%", "candidate(0.9234) should return 92.34%"
	assert candidate(0.0123) == '1.23%'
	assert candidate(1.0) == '100.00%'
	assert candidate(0.01234) == '1.23%'
	assert candidate(0.0001234) == '0.01%'
	assert candidate(0.0000000000001234) == '0.00%'
	assert candidate(0.999999999) == '100.00%'
	assert candidate(-0.9234) == '-92.34%'
	assert candidate(0.92340000000000011) == '92.34%'
	assert candidate(1.0) == "100.00%"
	assert candidate(0.92344) == '92.34%'
	assert candidate(0.0000) == '0.00%'
	assert candidate(1) == '100.00%'
	assert candidate(0.9234000000000001) == '92.34%'
	assert candidate(1.000001) == '100.00%'
	assert candidate(0.00123) == "0.12%"
	assert candidate(0.001234) == '0.12%'
	assert candidate(0.000000001234) == '0.00%'
	assert candidate(0.0004) == '0.04%'
	assert candidate(0.0000000001234) == '0.00%'
	assert candidate(0.0000000000001) == '0.00%'
	assert candidate(0.00001) == '0.00%'
def test_check():
	check(percentage_string)
