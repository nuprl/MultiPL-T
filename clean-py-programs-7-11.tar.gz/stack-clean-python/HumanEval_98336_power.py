def power(base, exp):
    """ 
     Write a program to find x to power y using recursion
     :param base:
     :param exp:
     :return:
     """
	### Canonical solution below ###    
    if exp == 0:
        return 1
    if exp != 0:
        return base * power(base, exp - 1)

### Unit tests below ###
def check(candidate):
	assert candidate(4, 3) == 64
	assert candidate(2, 7) == 128
	assert candidate(3, 0) == 1
	assert candidate(2, 17) == 131072
	assert candidate(2, 0) == 1
	assert candidate(2, 16) == 65536
	assert candidate(4, 2) == 16
	assert candidate(5, 0) == 1
	assert candidate(3, 9) == 19683
	assert candidate(4, 6) == 4096
	assert candidate(-2, 3) == -8
	assert candidate(10, 0) == 1
	assert candidate(2, 21) == 2097152
	assert candidate(2, 6) == 64
	assert candidate(1, 2) == 1
	assert candidate(3, 1) == 3
	assert candidate(4, 7) == 16384
	assert candidate(3, 5) == 243
	assert candidate(2, 20) == 1048576
	assert candidate(-2, 2) == 4
	assert candidate(2, 22) == 4194304
	assert candidate(4, 8) == 65536
	assert candidate(2, 10) == 1024
	assert candidate(2, 13) == 8192
	assert candidate(3, 4) == 81
	assert candidate(3, 6) == 729
	assert candidate(3, 2) == 9
	assert candidate(2, 12) == 4096
	assert candidate(3, 3) == 27
	assert candidate(4, 0) == 1
	assert candidate(0, 3) == 0
	assert candidate(10, 4) == 10000
	assert candidate(10, 2) == 100
	assert candidate(2, 18) == 262144
	assert candidate(2, 2) == 4
	assert candidate(2, 8) == 256
	assert candidate(5, 1) == 5
	assert candidate(2, 19) == 524288
	assert candidate(5, 3) == 125
	assert candidate(4, 4) == 256
	assert candidate(2, 9) == 512
	assert candidate(0, 2) == 0
	assert candidate(2, 11) == 2048
	assert candidate(2, 3) == 8
	assert candidate(4, 1) == 4
	assert candidate(5, 2) == 25
	assert candidate(2, 14) == 16384
	assert candidate(2, 1) == 2
	assert candidate(2, 4) == 16
	assert candidate(2, 5) == 32
	assert candidate(3, 7) == 2187
	assert candidate(3, 8) == 6561
	assert candidate(5, 4) == 625
	assert candidate(5, 5) == 3125
	assert candidate(2, 15) == 32768
	assert candidate(4, 5) == 1024
	assert candidate(-3, 3) == -27
def test_check():
	check(power)
