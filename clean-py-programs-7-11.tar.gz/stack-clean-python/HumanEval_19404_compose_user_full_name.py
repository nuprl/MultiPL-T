def compose_user_full_name(username, first_name, last_name):
    """ 
     Return user's full name representation for the views.
     
     Needed because of unrequired first and last names.
     """
	### Canonical solution below ###    
    name = (first_name or last_name) and ' '.join((first_name, last_name))
    return '{} ({})'.format(name, username) if name else username

### Unit tests below ###
def check(candidate):
	assert candidate(
    username='john',
    first_name=None,
    last_name=None
) == 'john'
	assert candidate(username='a', first_name=None, last_name=None) == 'a'
	assert candidate('foo', None, None) == 'foo'
	assert candidate('username', 'First', 'Last') == 'First Last (username)'
	assert candidate('foo', '', '') == 'foo'
	assert candidate(username='a', first_name='b', last_name='c') == 'b c (a)'
	assert candidate(
    'username',
    'first_name',
    'last_name'
) == 'first_name last_name (username)'
	assert candidate(username='foo', first_name=None, last_name=None) == 'foo'
	assert candidate(
    'john', '', '') == 'john'
	assert candidate(username='john', first_name='', last_name='') == 'john'
	assert candidate(username='user', first_name=None, last_name=None) == 'user'
	assert candidate(
    'user',
    None,
    None
) == 'user'
	assert candidate('user', 'first', 'last') == 'first last (user)'
	assert candidate(
    '',
    '',
    ''
) == ''
	assert candidate('johndoe', '', '') == 'johndoe'
	assert candidate('John', None, None) == 'John'
	assert candidate('johndoe', None, None) == 'johndoe'
	assert candidate(
    username='john',
    first_name='',
    last_name=''
) == 'john'
	assert candidate(username='a', first_name='', last_name='') == 'a'
	assert candidate('foo', 'bar', 'baz') == 'bar baz (foo)'
	assert candidate(None, None, None) is None
	assert candidate('user', None, None) == 'user'
	assert candidate('User', None, None) == 'User'
	assert candidate(
    'username',
    '',
    ''
) == 'username'
	assert candidate('username', 'first', 'last') == 'first last (username)'
	assert candidate('username', 'first_name', 'last_name') == 'first_name last_name (username)'
	assert candidate(
    'john', None, None) == 'john'
	assert candidate(username='user', first_name='', last_name='') == 'user'
	assert candidate(username='John', first_name=None, last_name=None) == 'John'
	assert candidate('username', None, None) == 'username'
	assert candidate('a', None, None) == 'a'
	assert candidate(username='user', first_name='first', last_name='last') == 'first last (user)'
	assert candidate(username='foo', first_name='Foo', last_name='Bar') == 'Foo Bar (foo)'
	assert candidate(None, None, None) == None
	assert candidate(username='bob', first_name=None, last_name=None) == 'bob'
	assert candidate(username='John', first_name='', last_name='') == 'John'
def test_check():
	check(compose_user_full_name)
