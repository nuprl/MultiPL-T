def gcd_2(n, m):
    """ finds the gcd of n and m"""
	### Canonical solution below ###    
    if(n < m):##swaps n and m
        n ^= m
        m ^= n
        n ^= m
    while(m!=0):
        k = n%m
        n = m
        m = k
    return n

### Unit tests below ###
def check(candidate):
	assert candidate(20, 16) == 4
	assert candidate(120, 90) == 30
	assert candidate(120, 180) == 60
	assert candidate(12, 3) == 3
	assert candidate(18, 12) == 6
	assert candidate(100, 15) == 5
	assert candidate(1000, 1000) == 1000
	assert candidate(24, 60) == 12
	assert candidate(20, 20) == 20
	assert candidate(5, 1) == 1
	assert candidate(24, 36) == 12
	assert candidate(39, 91) == 13
	assert candidate(0, 4) == 4
	assert candidate(5, 5) == 5
	assert candidate(1, 0) == 1
	assert candidate(1, 2) == 1
	assert candidate(9, 9) == 9
	assert candidate(100, 100) == 100
	assert candidate(7, 5) == 1
	assert candidate(2*3*5*7, 2*3*5*11) == 2*3*5
	assert candidate(3*5*7, 2*3*5*7) == 3*5*7
	assert candidate(20, 24) == 4
	assert candidate(11, 10)
	assert candidate(2, 4) == 2
	assert candidate(1000, 400) == 200
	assert candidate(20, 28) == 4
	assert candidate(5, 15) == 5
	assert candidate(6, 7) == 1
	assert candidate(12, 18) == 6
	assert candidate(3, 2) == 1
	assert candidate(20, 32) == 4
	assert candidate(60, 90) == 30
	assert candidate(20, 9) == 1
	assert candidate(34, 19) == 1
	assert candidate(20, 1) == 1
	assert candidate(100, 20) == 20
	assert candidate(17, 13) == 1
	assert candidate(9, 12) == 3
	assert candidate(3, 5) == 1
	assert candidate(8, 20) == 4
	assert candidate(27, 18) == 9
	assert candidate(12, 12) == 12
	assert candidate(20, 8) == 4
	assert candidate(100, 25) == 25
	assert candidate(15, 20) == 5
	assert candidate(4, 5) == 1
	assert candidate(0, 1) == 1
	assert candidate(10, 1) == 1
	assert candidate(1000, 2000) == 1000
	assert candidate(30, 40) == 10
	assert candidate(2, 0) == 2
	assert candidate(10, 11) == 1
	assert candidate(100, 10) == 10
	assert candidate(1071, 0) == 1071
	assert candidate(21, 14) == 7
	assert candidate(4, 4) == 4
	assert candidate(10, 10) == 10
	assert candidate(20, 12) == 4
	assert candidate(10, 20) == 10
	assert candidate(20, 15) == 5
	assert candidate(6, 12) == 6
	assert candidate(99, 12) == 3
	assert candidate(4, 0) == 4
	assert candidate(1, 1) == 1
	assert candidate(20, 80) == 20
	assert candidate(12, 36) == 12
	assert candidate(17, 12) == 1
	assert candidate(2, 3) == 1
	assert candidate(3, 12) == 3
	assert candidate(8, 9) == 1
	assert candidate(2, 12) == 2
	assert candidate(10, 15) == 5
	assert candidate(2, 2) == 2
	assert candidate(12, 17) == 1
	assert candidate(15, 100) == 5
	assert candidate(30, 25) == 5
	assert candidate(2000, 1000) == 1000
	assert candidate(7, 7) == 7
	assert candidate(1071, 487) == 1
	assert candidate(16, 20) == 4
	assert candidate(30, 45) == 15
	assert candidate(15, 3) == 3
	assert candidate(2**3*5*7, 2**3*5*11) == 2**3*5
	assert candidate(3, 15) == 3
	assert candidate(8, 8) == 8
	assert candidate(1, 20) == 1
	assert candidate(1, 5) == 1
	assert candidate(10, 5) == 5
	assert candidate(0, 0) == 0
	assert candidate(21, 20) == 1
	assert candidate(3, 7) == 1
	assert candidate(60, 60) == 60
	assert candidate(9, 8) == 1
	assert candidate(5, 4) == 1
	assert candidate(7, 6) == 1
	assert candidate(9, 6) == 3
	assert candidate(30, 20) == 10
	assert candidate(30, 12) == 6
	assert candidate(3, 3) == 3
	assert candidate(2, 1) == 1
	assert candidate(1071, 462) == 21
	assert candidate(75, 14) == 1
	assert candidate(3*5*7, 3*5*11) == 3*5
def test_check():
	check(gcd_2)
