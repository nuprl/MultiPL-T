def solution(a: int, b: int, k: int) -> int:
    """
    :return: The number of integers within the range [a..b]
             that are divisible by k.

    >>> solution(6, 11, 2)
    3
    >>> solution(3, 14, 7)
    2
    """
    ### Canonical solution below ###
    count = (b - a + 1) // k
    if b % k == 0:
        count += 1
    return count


### Unit tests below ###
def check(candidate):
	assert candidate(3, 5, 21) == 0
	assert candidate(1, 1000, 7) == 142
	assert candidate(1, 1000, 9) == 111
	assert candidate(3, 3, 3) == 1
	assert candidate(1, 10, 8) == 1
	assert candidate(3, 5, 15) == 0
	assert candidate(1, 1, 4) == 0
	assert candidate(10, 100, 22) == 4
	assert candidate(0, 0, 1000) == 1
	assert candidate(1, 5, 4) == 1
	assert candidate(1, 5, 2) == 2
	assert candidate(10, 10, 10) == 1
	assert candidate(10, 100, 26) == 3
	assert candidate(3, 5, 17) == 0
	assert candidate(3, 5, 20) == 0
	assert candidate(10, 100, 10) == 10
	assert candidate(10, 100, 27) == 3
	assert candidate(1, 10, 7) == 1
	assert candidate(3, 7, 8) == 0
	assert candidate(2, 8, 3) == 2
	assert candidate(1, 100, 6) == 16
	assert candidate(3, 5, 11) == 0
	assert candidate(3, 5, 4) == 0
	assert candidate(1, 10, 9) == 1
	assert candidate(3, 14, 15) == 0
	assert candidate(1, 10, 6) == 1
	assert candidate(1, 2, 3) == 0
	assert candidate(1, 1, 3) == 0
	assert candidate(3, 14, 14) == 1
	assert candidate(3, 5, 18) == 0
	assert candidate(1, 1, 2) == 0
	assert candidate(1, 7, 14) == 0
	assert candidate(10, 11, 10) == 0
	assert candidate(3, 14, 5) == 2
	assert candidate(10, 12, 3) == 2
	assert candidate(1000000000, 1000000000, 1000000000) == 1
	assert candidate(3, 14, 16) == 0
	assert candidate(1, 100, 7) == 14
	assert candidate(6, 11, 2) == 3
	assert candidate(3, 5, 16) == 0
	assert candidate(3, 5, 7) == 0
	assert candidate(3, 4, 3) == 0
	assert candidate(3, 5, 6) == 0
	assert candidate(10, 100, 20) == 5
	assert candidate(1, 100, 8) == 12
	assert candidate(3, 5, 12) == 0
	assert candidate(1, 3, 4) == 0
	assert candidate(3, 5, 14) == 0
	assert candidate(3, 5, 8) == 0
	assert candidate(3, 5, 19) == 0
	assert candidate(3, 5, 3) == 1
	assert candidate(1, 5, 6) == 0
	assert candidate(2, 2, 2) == 1
	assert candidate(3, 7, 7) == 1
	assert candidate(1, 3, 2) == 1
	assert candidate(3, 5, 13) == 0
	assert candidate(10, 100, 25) == 4
	assert candidate(2, 2, 3) == 0
	assert candidate(3, 14, 6) == 2
	assert candidate(3, 14, 7) == 2
	assert candidate(1, 1, 7) == 0
	assert candidate(10, 100, 28) == 3
	assert candidate(1, 1000, 10) == 101
	assert candidate(1, 10, 11) == 0
	assert candidate(3, 5, 9) == 0
	assert candidate(14, 14, 7) == 1
	assert candidate(3, 7, 1) == 6
	assert candidate(2, 7, 3) == 2
	assert candidate(1, 100, 9) == 11
	assert candidate(1, 2, 4) == 0
	assert candidate(3, 5, 10) == 0
	assert candidate(10, 15, 3) == 3
def test_check():
	check(solution)
