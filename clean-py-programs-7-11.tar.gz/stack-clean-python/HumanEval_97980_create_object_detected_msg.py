def create_object_detected_msg(position):
    """creates an xyz message of target location"""
    ### Canonical solution below ###
    return {'coords':position}


### Unit tests below ###
def check(candidate):
	assert candidate(position=(20,10)) == {'coords':(20,10)}
	assert candidate(position=(1,1))!= {'coords':(1,1,1)}
	assert candidate(position=[1,2,3])=={'coords':[1,2,3]}
	assert candidate(position=(1,1))!= {'coords':(1,2)}
	assert candidate(position=(1,1))!= {'coords':(1,1,'a')}
	assert candidate(position=(1,1)) == {'coords':(1,1)}
	assert candidate(position=(0.0, 0.0, 0.0)) == {'coords': (0.0, 0.0, 0.0)}
	assert candidate(position=(1,1))!= {'coords':(20,10)}
	assert candidate((1,2,3)) == {'coords':(1,2,3)}
def test_check():
	check(create_object_detected_msg)
