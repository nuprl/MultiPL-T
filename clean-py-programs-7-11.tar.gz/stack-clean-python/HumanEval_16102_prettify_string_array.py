def prettify_string_array(array, max_length):
	"""Returns a human readable string from an array of strings."""
    ### Canonical solution below ###
	_string = ''
	
	_i = 0
	for entry in array:
		if len(_string) > max_length:
			_string += ', and %s more.' % (_i+1)
			
			break
		
		if _i == 0:
			_string += entry
		elif 0<_i<len(array)-1:
			_string += ', %s' % entry
		elif _i == len(array)-1:
			_string += ' and %s.' % entry
		
		_i += 1
	
	return _string


### Unit tests below ###
def check(candidate):
	assert candidate(array=['a', 'b'], max_length=2) == 'a and b.'
	assert candidate(array=[], max_length=0) == ''
	assert candidate(array=[], max_length=5) == ''
	assert candidate(
	[],
	1
) == ''
	assert candidate([], 10) == ''
	assert candidate(array=['a'], max_length=1) == 'a'
	assert candidate(array=['A', 'B', 'C', 'D'], max_length=0) == 'A, and 2 more.'
	assert candidate(array=[], max_length=20) == ''
	assert candidate([], 20) == ''
	assert candidate(['A'], 10) == 'A'
	assert candidate(
	['hello', 'world'],
	10
) == 'hello and world.'
	assert candidate(
	['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N'],
	50
) == 'A, B, C, D, E, F, G, H, I, J, K, L, M and N.'
	assert candidate(
	[],
	10) == ''
	assert candidate(array=['a','b'], max_length=2) == 'a and b.'
	assert candidate(array=[], max_length=10) == ''
	assert candidate(array=[], max_length=1) == ''
	assert candidate(
	['this', 'is', 'a', 'test'],
	2) == 'this, and 2 more.'
	assert candidate(
	['hello', 'world', 'foo', 'bar'],
	20
) == 'hello, world, foo and bar.'
	assert candidate(array=['a'], max_length=10) == 'a'
	assert candidate(['a'], 20) == 'a'
	assert candidate(
	[],
	10000
) == ''
	assert candidate(['a'], 10) == 'a'
	assert candidate(array=['a'], max_length=2) == 'a'
	assert candidate(array=[], max_length=2) == ''
	assert candidate(
	[],
	10
) == ''
def test_check():
	check(prettify_string_array)
