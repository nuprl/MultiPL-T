def _empty_list_entry(schema):
    """Generate an empty list entry for the provided schema.
    """
    ### Canonical solution below ###
    entry = {}
    for ldap_field, _obj_field, _field_type in schema:
        entry[ldap_field] = []

    return entry


### Unit tests below ###
def check(candidate):
	assert candidate([
    ('foo', 'bar','string'),
    ('baz', 'baz', 'integer'),
]) == {
    'foo': [],
    'baz': [],
}
	assert candidate(
    schema=[
        ('cn', 'cn', str),
        ('description', 'description', str),
    ]
) == {
    'cn': [],
    'description': [],
}
	assert candidate([]) == {}
def test_check():
	check(_empty_list_entry)
