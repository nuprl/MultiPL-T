def _get_criteria_symbol(criteria_met, criteria_active):
    """ Return symbol for inactive: "o" met: "*" or unmet: " " """
	### Canonical solution below ###    

    symbol = "*" if criteria_met else ""

    if not criteria_active:
        symbol = "o"

    return symbol

### Unit tests below ###
def check(candidate):
	assert candidate(False, False) == "o"
	assert candidate(True, True) == "*"
	assert candidate(False, True) == ""
	assert candidate(True, False) == "o"
def test_check():
	check(_get_criteria_symbol)
