def is_role(profile):
    """ Checks to see if the given profile is a role profile.
     A profile is a role profile if it contains a 'role_arn' and a 'source_profile'.
     
     Parameters
     ----------
     - profile - the profile to inspect
     
     Returns
     -------
     True if the profile is a role profile, False if it doesn't.
     """
	### Canonical solution below ###    
    if 'source_profile' in profile and 'role_arn' in profile:
        return True
    return False

### Unit tests below ###
def check(candidate):
	assert candidate({'role_arn': 'bar'}) == False
	assert candidate({'source_profile': 'foo', 'role_arn': 'bar'}) == True
	assert candidate({'source_profile': 'foo'}) == False
	assert candidate(
    {'source_profile': 'foo', 'role_arn': 'bar'}
)
	assert candidate(profile={'source_profile': 'profile1', 'role_arn': 'arn:aws:iam::123456789012:role/role1','region': 'us-east-1'}) == True
	assert candidate({}) is False
	assert candidate(profile={'role_arn': 'arn:aws:iam::123456789012:role/role1'}) == False
	assert not candidate( {'role_arn': 'bar'} )
	assert candidate(profile={}) == False
	assert candidate(
    {'role_arn': 'test_role_arn'}) is False
	assert not candidate(
    {
        'role_arn': 'arn:aws:iam::123456789012:role/rolename'
    }
)
	assert not candidate( {'source_profile': 'foo'} )
	assert candidate( {'source_profile': 'foo', 'role_arn': 'bar'} )
	assert candidate({}) == False
	assert not candidate(
    {'role_arn': 'arn:aws:iam::012345678901:role/my-role'}
)
	assert candidate(dict()) == False
	assert candidate(profile={'source_profile': 'profile1'}) == False
	assert candidate(
    {'source_profile': 'test_source_profile', 'role_arn': 'test_role_arn'}) is True
	assert candidate(profile={'source_profile': 'profile1', 'role_arn': 'arn:aws:iam::123456789012:role/role1'}) == True
	assert candidate(
    {'source_profile': 'test_source_profile'}) is False
	assert not candidate(
    {'role_arn': 'bar'}
)
	assert candidate(
    {
        'role_arn': 'arn:aws:iam::123456789012:role/rolename',
       'source_profile':'source_profile'
    }
)
	assert candidate(
    {'role_arn': 'arn:aws:iam::012345678901:role/my-role','source_profile': 'default'}
)
	assert not candidate(
    {
       'source_profile':'source_profile'
    }
)
	assert candidate({'role_arn': 'foo'}) == False
	assert not candidate(
    {'source_profile': 'foo'}
)
	assert not candidate(
    {'source_profile': 'default'}
)
def test_check():
	check(is_role)
