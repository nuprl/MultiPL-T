def epoch2checkpoint(_epoch: int) -> str:
    """
    Args:
        _epoch:           e.g. 2

    Returns:
        _checkpoint_name: e.g. 'epoch=2.ckpt'
    """
    ### Canonical solution below ###
    return f"epoch={_epoch}.ckpt"


### Unit tests below ###
def check(candidate):
	assert candidate(12) == "epoch=12.ckpt"
	assert candidate(7) == 'epoch=7.ckpt'
	assert candidate(5) == 'epoch=5.ckpt'
	assert candidate(21) == "epoch=21.ckpt"
	assert candidate(17) == 'epoch=17.ckpt'
	assert candidate(0) == 'epoch=0.ckpt'
	assert candidate(2) == "epoch=2.ckpt"
	assert candidate(9) == "epoch=9.ckpt"
	assert candidate(2) == 'epoch=2.ckpt', "Failed unit test for candidate"
	assert candidate(200) == "epoch=200.ckpt"
	assert candidate(20) == 'epoch=20.ckpt'
	assert candidate(16) == "epoch=16.ckpt"
	assert candidate(18) == "epoch=18.ckpt"
	assert candidate(1000) == "epoch=1000.ckpt"
	assert candidate(11) == 'epoch=11.ckpt'
	assert candidate(6) == 'epoch=6.ckpt'
	assert candidate(13) == "epoch=13.ckpt"
	assert candidate(18) == 'epoch=18.ckpt'
	assert candidate(2) == "epoch=2.ckpt", "Unit test failed."
	assert candidate(99) == "epoch=99.ckpt"
	assert candidate(17) == "epoch=17.ckpt"
	assert candidate(4) == 'epoch=4.ckpt'
	assert candidate(-10) == 'epoch=-10.ckpt'
	assert candidate(99) == 'epoch=99.ckpt'
	assert candidate(8) == "epoch=8.ckpt"
	assert candidate(22) == "epoch=22.ckpt"
	assert candidate(7) == "epoch=7.ckpt"
	assert candidate(1) == 'epoch=1.ckpt'
	assert candidate(2) == 'epoch=2.ckpt'
	assert candidate(5) == "epoch=5.ckpt"
	assert candidate(15) == "epoch=15.ckpt"
	assert candidate(10) == 'epoch=10.ckpt'
	assert candidate(11) == "epoch=11.ckpt"
	assert candidate(-1) == 'epoch=-1.ckpt'
	assert candidate(15) == 'epoch=15.ckpt'
	assert candidate(3) == "epoch=3.ckpt"
	assert candidate(9) == 'epoch=9.ckpt'
	assert candidate(19) == "epoch=19.ckpt"
	assert candidate(10) == "epoch=10.ckpt"
	assert candidate(0) == "epoch=0.ckpt"
	assert candidate(13) == 'epoch=13.ckpt'
	assert candidate(4) == "epoch=4.ckpt"
	assert candidate(14) == "epoch=14.ckpt"
	assert candidate(8) == 'epoch=8.ckpt'
	assert candidate(6) == "epoch=6.ckpt"
	assert candidate(1) == "epoch=1.ckpt"
	assert candidate(12) == 'epoch=12.ckpt'
	assert candidate(20) == "epoch=20.ckpt"
	assert candidate(3) == 'epoch=3.ckpt'
	assert candidate(19) == 'epoch=19.ckpt'
	assert candidate(16) == 'epoch=16.ckpt'
	assert candidate(14) == 'epoch=14.ckpt'
	assert candidate(100) == 'epoch=100.ckpt'
def test_check():
	check(epoch2checkpoint)
