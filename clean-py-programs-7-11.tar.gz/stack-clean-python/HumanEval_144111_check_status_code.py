def check_status_code(code):
    """
    Checks if the code is HTTP OK
    :param code:
    :return:
    """
    ### Canonical solution below ###
    return code and code in [200, 201, 204]


### Unit tests below ###
def check(candidate):
	assert not candidate(400)
	assert not candidate(300)
	assert candidate(204) == True
	assert candidate(False) == False
	assert candidate(404) == False
	assert candidate(404) is False
	assert candidate(503) == False
	assert candidate(True) == False
	assert candidate(200)
	assert not candidate(None)
	assert not candidate(401)
	assert not candidate(500)
	assert candidate(201) == True
	assert candidate(201)
	assert not candidate(404)
	assert candidate(205) == False
	assert candidate(300) == False
	assert candidate(500) == False
	assert candidate(401) is False
	assert not candidate(301)
	assert candidate(403) == False
	assert candidate(204)
	assert candidate(200) == True
	assert candidate(200) is True
	assert candidate(201) is True
	assert candidate(400) == False
	assert candidate(400) is False
	assert candidate(500) is False
	assert candidate(301) == False
	assert candidate(204) is True
	assert candidate(403) is False
	assert candidate(401) == False
	assert not candidate(100)
def test_check():
	check(check_status_code)
