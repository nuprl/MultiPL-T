def _check_histories(history1, history2):
    """Check if two histories are the same."""
    ### Canonical solution below ###
    if history1.replace("\n", "").replace(" ", "") == history2.replace(
        "\n", ""
    ).replace(" ", ""):
        return True
    else:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate(
    "2017-10-29 07:56:00.719264 2017-10-29 07:56:00.719264 1\n2017-10-29 07:56:00.719264 2017-10-29 07:56:00.719264 2",
    "2017-10-29 07:56:00.719264 2017-10-29 07:56:00.719264 1\n2017-10-29 07:56:00.719264 2017-10-29 07:56:00.719264 2",
)
	assert not candidate(
    "0.5 0.6 0.7 0.8", "0.5 0.6 0.7 0.7"
), "The histories should be different."
	assert not candidate(
    "1 2 3", "1 2 3 4 5 6"
), "The two histories should not be the same"
	assert candidate(
    "1 2 3\n4 5 6\n", "1 2 3\n5 6 7\n"
) == False
	assert candidate(
    "1 2 3 4 5", "1 2 3 4 5"
), "Should be the same"
	assert not candidate(
    "1 2 3\n4 5 6", "1 2 3\n4 5 7"
), "candidate test 2 failed"
	assert not candidate(
    "1 + 1\n2 + 2\n3 + 3\n4 + 4\n5 + 5\n6 + 6\n7 + 7\n8 + 8\n9 + 9\n10 + 11\n",
    "1 + 1\n2 + 2\n3 + 3\n4 + 4\n5 + 5\n6 + 6\n7 + 7\n8 + 8\n9 + 9\n10 + 10\n",
)
	assert not candidate(
    "1 + 2\n3 + 4\n", "1 + 2\n3 + 4\n5 + 6\n7 + 8\n"
), "candidate failed"
	assert candidate(
        "1 + 2\n3 + 4\n", "1 + 2\n3 + 4\n"
    ), "candidate failed"
	assert candidate(
    "1 2 3\n4 5 6\n", "1 2 3\n4 5 6\n"
) == True
	assert candidate(
    "0.5 0.6 0.7 0.8", "0.5 0.6 0.7 0.8"
), "The histories should be the same."
	assert candidate(
    "1 1 1 1 1", "1 1 1 1 0"
) == False
	assert not candidate(
    "1 2 3 4 5", "1 2 3 4 5 6"
), "Should be different"
	assert candidate(
    "1 2 3\n4 5 6\n7 8 9",
    "1 2 3\n4 5 6\n7 8 9\n",
)
	assert candidate(
    "1 1 1 1 1", "1 1 1 0 1"
) == False
	assert not candidate(
    "1 2 3\n4 5 6", "1 2 3\n4 5 6\n7 8 9"
), "candidate test 3 failed"
	assert candidate(
    "0 1 2\n1 2 3\n2 3 4\n", "0 1 2\n1 2 3\n2 3 4\n0 1 2\n1 2 3\n2 3 4\n"
) == False, "The histories should not be the same"
	assert candidate(
    "1 2 3", "1 2 3"
), "The two histories should be the same"
	assert not candidate(
    "123456789", "123456799"
), "Should not be the same"
	assert not candidate(
    "1 2 3", "1 2 3 4"
), "The two histories should not be the same"
	assert candidate(
    "1 2 3 4 5", "1 2 3 4 5"
), "Should be True for same histories"
	assert candidate(
    "123456789", "123456789"
), "Should be the same"
	assert candidate(
    "1 1 1 1 1", "1 1 0 1 1"
) == False
	assert not candidate(
    "1 2 3\n4 5 6\n7 8 9\n10 11 12", "1 2 3\n4 5 6\n7 8 9\n10 11 12\n13 14 15"
), "candidate test 7 failed"
	assert candidate(
    "1 1 1 1 1", "1 1 1 1 1"
) == True
	assert not candidate(
    "1 2 3\n4 5 6", "1 2 3\n4 5 6\n7 8 9\n10 11 12"
), "candidate test 6 failed"
	assert candidate(
    "1 2 3 4 5 6 7 8 9", "1 2 3 4 5 6 7 8 9"
), "Should be True"
	assert candidate(
    "2017-10-29 07:56:00.719264 2017-10-29 07:56:00.719264 1",
    "2017-10-29 07:56:00.719264 2017-10-29 07:56:00.719264 1",
)
	assert not candidate(
        "1 + 2\n3 + 4\n", "1 + 2\n3 + 4\n5 + 6\n7 + 8\n"
    ), "candidate failed"
	assert not candidate(
    "1 2 3\n4 5 6", "1 2 3\n4 5"
), "candidate test 5 failed"
	assert not candidate(
    "123456789", "123456788"
), "Should not be the same"
	assert candidate(
    "1 2 3\n4 5 6", "1 2 3\n4 5 6"
), "candidate test 1 failed"
	assert candidate(
    "23\n34\n45\n",
    "23\n34\n45\n"
) == True
	assert candidate(
    "", ""
) == True
	assert not candidate(
    "1 2 3\n4 5 6", "1 2 3"
), "candidate test 4 failed"
	assert candidate(
    "1 2 3\n4 5 6\n7 8 9",
    "1 2 3\n4 5 6\n7 8 9",
)
	assert candidate(
    "1 + 1\n2 + 2\n3 + 3\n4 + 4\n5 + 5\n6 + 6\n7 + 7\n8 + 8\n9 + 9\n10 + 10\n",
    "1 + 1\n2 + 2\n3 + 3\n4 + 4\n5 + 5\n6 + 6\n7 + 7\n8 + 8\n9 + 9\n10 + 10\n",
)
	assert candidate(
    "1 + 2\n3 + 4\n", "1 + 2\n3 + 4\n"
), "candidate failed"
	assert not candidate(
    "123456789", "123456781"
), "Should not be the same"
	assert candidate(
    "1 1 1 1 1", "0 1 1 1 1"
) == False
	assert candidate(
    "1 1 1 1 1", "1 1 1 1 1 1"
) == False
	assert not candidate(
    "1 2 3 4 5", "1 2 3 4 6"
), "Should be different"
	assert candidate(
    "1 2 3", "1 2 3"
) == True
	assert candidate(
    "0 1 2\n1 2 3\n2 3 4\n", "0 1 2\n1 2 3\n2 3 4\n"
) == True, "The histories should be the same"
	assert candidate(
    "1 1 1 1 1", "1 0 1 1 1"
) == False
	assert not candidate(
    "1 2 3", "1 2"
), "The two histories should not be the same"
	assert candidate(
    "1 2 3\n4 5 6\n", "1 2 3\n4 5 6\n7 8 9\n"
) == False
	assert not candidate(
    "1 2 3", "1 3 2"
), "The two histories should not be the same"
	assert not candidate(
    "1 2 3", "1 2 3 4 5"
), "The two histories should not be the same"
	assert candidate(
    "23\n34\n45\n",
    "23\n34\n45\n67\n"
) == False
	assert candidate(
    "1 2 3\n4 5 6\n", "1 2 3\n4 5 6\n7 8 9\n10 11 12\n13 14 15\n"
) == False
	assert candidate(
    "1 2 3\n4 5 6\n", "1 2 3\n4 5 6\n7 8 9\n10 11 12\n"
) == False
def test_check():
	check(_check_histories)
