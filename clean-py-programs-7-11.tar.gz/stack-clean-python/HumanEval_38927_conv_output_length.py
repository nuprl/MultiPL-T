def conv_output_length(input_length, filter_size, stride, pad=0):
    """Helper function to compute the output size of a convolution operation
    From Lasagne

    """
    ### Canonical solution below ###
    if input_length is None:
        return None
    if pad == 'valid':
        output_length = input_length - filter_size + 1
    elif pad == 'full':
        output_length = input_length + filter_size - 1
    elif pad == 'same':
        output_length = input_length
    elif isinstance(pad, int):
        output_length = input_length + 2 * pad - filter_size + 1
    else:
        raise ValueError('Invalid pad: {0}'.format(pad))

    # This is the integer arithmetic equivalent to
    # np.ceil(output_length / stride)
    output_length = (output_length + stride - 1) // stride

    return output_length


### Unit tests below ###
def check(candidate):
	assert candidate(10, 2, 2, 0) == 5
	assert candidate(10, 5, 1,'same') == 10
	assert candidate(10, 3, 1, pad='full') == 12
	assert candidate(10, 2, 2,'same') == 5
	assert candidate(None, 3, 1) == None
	assert candidate(None, 5, 1, pad=0) is None
	assert candidate(7, 3, 1, pad='valid') == 5
	assert candidate(None, 3, 2) == None
	assert candidate(None, 5, 2) == None
	assert candidate(7, 3, 1, pad='same') == 7
	assert candidate(7, 5, 1, pad='same') == 7
	assert candidate(10, 5, 1, pad='same') == 10
	assert candidate(10, 2, 1, 'valid') == 9
	assert candidate(10, 5, 2, pad='full') == 7
	assert candidate(None, 2, 1, 0) is None
	assert candidate(100, 10, 2,'same') == 50
	assert candidate(10, 2, 1, 'full') == 11
	assert candidate(100, 5, 2, pad='same') == 50
	assert candidate(7, 5, 2,'same') == 4
	assert candidate(10, 3, 2, pad='full') == 6
	assert candidate(7, 3, 2, 'full') == 5
	assert candidate(6, 5, 2, 2) == 3
	assert candidate(100, 6, 3, 'full') == 35
	assert candidate(7, 5, 1, 'valid') == 3
	assert candidate(100, 5, 1,'same') == 100
	assert candidate(10, 5, 2, pad='same') == 5
	assert candidate(100, 6, 2) == 48
	assert candidate(7, 3, 2,'same') == 4
	assert candidate(7, 2, 3, 'valid') == 2
	assert candidate(10, 3, 2, pad=1) == 5
	assert candidate(7, 3, 2, 'valid') == 3
	assert candidate(10, 3, 2, pad='same') == 5
	assert candidate(100, 5, 1, 0) == 96
	assert candidate(10, 5, 1, pad=2)
	assert candidate(None, 5, 1, 'valid') is None
	assert candidate(10, 3, 1, pad='same') == 10
	assert candidate(8, 3, 1,'same') == 8
	assert candidate(None, 5, 1) is None
	assert candidate(100, 7, 2, pad='same') == 50
	assert candidate(10, 2, 1,'same') == 10
	assert candidate(10, 3, 1, pad=1) == 10
	assert candidate(7, 5, 1, 2) == 7
	assert candidate(7, 3, 2, 1) == 4
	assert candidate(10, 2, 2, 'full') == 6
	assert candidate(None, 3, 1, 0) == None
	assert candidate(10, 5, 2,'same') == 5
	assert candidate(7, 3, 1, 'valid') == 5
	assert candidate(None, 2, 3) is None
	assert candidate(7, 3, 1, pad=0) == 5
	assert candidate(100, 5, 1, 'valid') == 96
	assert candidate(10, 3, 2, pad='valid') == 4
	assert candidate(7, 10, 1, pad='same') == 7
	assert candidate(None, 3, 2) is None
	assert candidate(None, 2, 1, pad=0) is None
	assert candidate(None, 5, 1, 2) == None
	assert candidate(7, 5, 1,'same') == 7
	assert candidate(7, 3, 1,'same') == 7
def test_check():
	check(conv_output_length)
