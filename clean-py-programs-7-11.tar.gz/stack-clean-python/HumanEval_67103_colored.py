def colored(str, color="red"):
    """ 
     Color a string for terminal output
     @params
     str - Required : the string to color
     color - Optional : the color to use. Default value: red. Available options: red, yellow, blue
     """
	### Canonical solution below ###    

    colors = {
        "red": "\033[91m",
        "yellow": "\33[33m",
        "blue": "\33[34m",
        "green": "\33[32m"
    }
    end = "\033[0m"
    return f"{colors[color]}{str}{end}"

### Unit tests below ###
def check(candidate):
	assert candidate("baz", "green") == candidate("baz", "green")
	assert candidate("1234", "red") == "\033[91m1234\033[0m"
	assert candidate("Test", "red") == "\033[91mTest\033[0m"
	assert candidate("red", "blue") == candidate("red", "blue")
	assert candidate("red", "red") == candidate("red", "red")
	assert candidate(
    "this is a red string", color="red") == "\033[91mthis is a red string\033[0m"
	assert candidate("Hello", "red") == "\033[91mHello\033[0m"
	assert candidate("hello", "blue") == "\33[34mhello\033[0m"
	assert candidate("Test", "blue") == "\33[34mTest\33[0m"
	assert candidate(123, "red") == candidate("123", "red")
	assert candidate("test", "yellow") == candidate("test", "yellow")
	assert candidate("1234", "blue") == "\33[34m1234\033[0m"
	assert candidate("Hello, World!", "red") == candidate("Hello, World!", "red")
	assert candidate("red", "blue")!= candidate("red", "red")
	assert candidate("Hello", "green") == candidate("Hello", "green")
	assert candidate("Hello World", "green") == "\33[32mHello World\033[0m", "Error: coloring is broken"
	assert candidate(
    "this is a yellow string", color="yellow") == "\33[33mthis is a yellow string\33[0m"
	assert candidate(
    "Test", "red") == "\033[91mTest\033[0m"
	assert candidate("hello", "yellow") == "\33[33mhello\033[0m"
	assert candidate(1234) == candidate("1234")
	assert candidate("test", "green") == candidate("test", "green")
	assert candidate("Hello", "red") == candidate("Hello", "red")
	assert candidate(
    "Test", "yellow") == "\33[33mTest\33[0m"
	assert candidate("bar", "blue") == candidate("bar", "blue")
	assert candidate(
    "I'm red", color="red") == "\033[91mI'm red\033[0m"
	assert candidate(str="test") == "\x1b[91mtest\x1b[0m"
	assert candidate("1234", "yellow") == "\33[33m1234\033[0m"
	assert candidate(
    "test", "red") == "\x1b[91mtest\x1b[0m"
	assert candidate(
    "This is a green string", "green") == "\33[32mThis is a green string\33[0m"
	assert candidate("hello", "red") == "\033[91mhello\033[0m"
	assert candidate("Hello World", "blue") == "\33[34mHello World\033[0m", "Error: coloring is broken"
	assert candidate(
    "I'm green", color="green") == "\33[32mI'm green\33[0m"
	assert candidate("test", "blue") == candidate("test", "blue")
	assert candidate("hello", "red")!= candidate("hello", "blue")!= candidate("hello", "green")!= candidate("hello", "yellow")!= candidate("hello", "red")
	assert candidate(None, "red") == candidate(None)
	assert candidate("Hello", "yellow") == candidate("Hello", "yellow")
	assert candidate("Hello", "yellow") == "\33[33mHello\33[0m"
	assert candidate("red") == candidate("red", "red")
	assert candidate("Hello", "blue") == candidate("Hello", "blue")
	assert candidate("test", "green") == "\x1b[32mtest\x1b[0m"
	assert candidate(
    "Test", "blue") == "\33[34mTest\33[0m"
	assert candidate(str="test", color="yellow") == "\x1b[33mtest\x1b[0m"
	assert candidate("test", "blue")!= candidate("test", "yellow")
	assert candidate("hello", "green") == "\33[32mhello\033[0m"
	assert candidate("foo", "yellow") == candidate("foo", "yellow")
	assert candidate("test", "blue") == "\x1b[34mtest\x1b[0m"
	assert candidate(
    "Test", "green") == "\33[32mTest\33[0m"
	assert candidate("test", "red") == candidate("test", "red")
	assert candidate("Test", "yellow") == "\33[33mTest\33[0m"
	assert candidate("red", "yellow") == candidate("red", "yellow")
	assert candidate("test", "red")!= candidate("test", "yellow")
	assert candidate("This is a yellow string",
               "yellow") == "\33[33mThis is a yellow string\33[0m"
	assert candidate("1234", "green") == "\33[32m1234\033[0m"
	assert candidate("Hello World", "red") == "\033[91mHello World\033[0m", "Error: coloring is broken"
	assert candidate("test", "yellow") == "\x1b[33mtest\x1b[0m"
	assert candidate(
    "this is a green string", color="green") == "\33[32mthis is a green string\33[0m"
	assert candidate("red", "green") == candidate("red", "green")
	assert candidate("Test", "green") == "\33[32mTest\33[0m"
	assert candidate(
    "I'm blue", color="blue") == "\33[34mI'm blue\33[0m"
	assert candidate(
    "this is a blue string", color="blue") == "\33[34mthis is a blue string\33[0m"
	assert candidate("hello", "red")!= candidate("hello", "blue")
	assert candidate("I'm yellow", color="yellow") == "\33[33mI'm yellow\33[0m"
	assert candidate(str="test", color="green") == "\x1b[32mtest\x1b[0m"
	assert candidate("test") == candidate("test", "red")
	assert candidate("This is a blue string",
               "blue") == "\33[34mThis is a blue string\33[0m"
	assert candidate("test") == "\x1b[91mtest\x1b[0m"
	assert candidate("Hello", "blue") == "\33[34mHello\33[0m"
	assert candidate(
    "This is a red string", "red") == "\033[91mThis is a red string\033[0m"
	assert candidate("test", "yellow")!= candidate("test", "blue")
	assert candidate(str="test", color="blue") == "\x1b[34mtest\x1b[0m"
	assert candidate("Hello", "green") == "\33[32mHello\33[0m"
	assert candidate("Hello World", "yellow") == "\33[33mHello World\033[0m", "Error: coloring is broken"
def test_check():
	check(colored)
