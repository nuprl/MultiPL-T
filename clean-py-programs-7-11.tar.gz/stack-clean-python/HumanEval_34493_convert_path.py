def convert_path(path):
    """Convert a reverse linked tuple path (3, (2, (1, ()))) to a forwards list [1, 2, 3]."""
    ### Canonical solution below ###
    result = []
    while path:
        step, path = path
        result.append(step)
    result.reverse()
    return result


### Unit tests below ###
def check(candidate):
	assert candidate( (2, ()) ) == [2]
	assert candidate( (3, (2, (1, ()))) ) == [1, 2, 3]
	assert candidate((1, (2, (3, ())))) == [3, 2, 1]
	assert candidate( () ) == []
	assert candidate((1, ())) == [1]
	assert candidate((3, (2, (1, ())))) == [1, 2, 3]
	assert candidate((),) == []
	assert candidate( (3, (2, (1, (0, ())))) ) == [0, 1, 2, 3]
	assert candidate( (2, (1, ())) ) == [1, 2]
	assert candidate( (2, (1, (3, ()))) ) == [3, 1, 2]
def test_check():
	check(convert_path)
