def return_list():
    """ 
     This function returns a list.
     """
	### Canonical solution below ###    
    l = [1, 2, 3, 4, 5, 6, 7]
    return l

### Unit tests below ###
def check(candidate):
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "The function does not return the correct list."
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "The function does not return the expected list."
	assert candidate(
)!= [1, 2, 3, 4, 5, 6], "The function does not return the correct list."
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "Check your function."
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "The function does not work as expected"
	assert candidate( ) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate( )!= [1, 2, 3, 4, 5, 6, 8]
	assert candidate( ) == [1, 2, 3, 4, 5, 6, 7], "Try again"
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "The function should return [1, 2, 3, 4, 5, 6, 7]."
	assert candidate(
)!= [1, 2, 3, 4, 5, 6, 7, 8], "The function does not return the correct list."
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "The function does not work properly"
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "The function is not working"
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(
) == [1, 2, 3, 4, 5, 6, 7], "The function does not return [1, 2, 3, 4, 5, 6, 7]"
def test_check():
	check(return_list)
