def strides_from_shape(shape):
    """ Calculates strdes of a tensor from shape attibute.
     
     Notes (jovsa): Strides are the offset translations
     required to map index of a tensor to a position on
     a contigious array. These offsets can be calculated
     by finding the product of shapes except self.
     
     working example:
     let shape  = (3, 5, 2)
     then prod(shape) = 30
     General algo:
     1 - [prod(shape)/i for i in shape]
     ex: [30/3, (30/3)/5, ....]
     2 - last dim always == 1 since you don't need an offset
     
     """
	### Canonical solution below ###    
    layout = [1]
    offset = 1
    for s in reversed(shape):
        layout.append(s * offset)
        offset = s * offset
    return tuple(reversed(layout[:-1]))

### Unit tests below ###
def check(candidate):
	assert candidate(shape=(10, 20)) == (20, 1)
	assert candidate((1, 1)) == (1, 1)
	assert candidate((1, 2, 3)) == (6, 3, 1)
	assert candidate((1,)) == (1,)
	assert candidate(shape=(10, 20, 30)) == (600, 30, 1)
	assert candidate(shape=(1, 1, 1, 1, 1, 1)) == (1, 1, 1, 1, 1, 1)
	assert candidate(shape=(1, 2, 3, 4)) == (24, 12, 4, 1)
	assert candidate(shape=(3, 5)) == (5, 1)
	assert candidate(shape=(5, 1, 1)) == (1, 1, 1)
	assert candidate(shape=(3,)) == (1,)
	assert candidate((1, 2, 3, 4)) == (24, 12, 4, 1)
	assert candidate(tuple()) == tuple()
	assert candidate((1, 2)) == (2, 1)
	assert candidate(shape=(3, 5, 1)) == (5, 1, 1)
	assert candidate(shape=(1,)) == (1,)
	assert candidate(shape=(1, 2, 3)) == (6, 3, 1)
	assert candidate(shape=(1, 1, 1)) == (1, 1, 1)
	assert candidate(shape=(1, 1)) == (1, 1)
	assert candidate(shape=(10, 20, 30, 40)) == (24000, 1200, 40, 1)
	assert candidate((3,)) == (1,)
def test_check():
	check(strides_from_shape)
