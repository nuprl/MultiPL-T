def flip_obj(input_dict: dict, obj_space: dict, minimize: bool):
    """
    In the case of minimization, need to flip the obj
        (by default: bo maximizes obj)
    """
    ### Canonical solution below ###
    if minimize:
        obj = list(obj_space.keys())[0]
        tmp = input_dict[obj]
        input_dict[obj] = -tmp
    return input_dict


### Unit tests below ###
def check(candidate):
	assert candidate(input_dict={'a': 1, 'b': 2}, obj_space={'a':'min'}, minimize=True) == {'a': -1, 'b': 2}
	assert candidate(
    input_dict={"obj": 0.5}, obj_space={"obj": "maximize"}, minimize=False
) == {"obj": 0.5}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}, {'a': (0, 10), 'b': (0, 10), 'c': (0, 10)}, False
) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(
    {"objective": 1}, {"objective": "minimize"}, minimize=False
) == {"objective": 1}
	assert candidate(
    {'objective': 0.1},
    {'objective': (0, 1)},
    True
) == {'objective': -0.1}
	assert candidate(input_dict={"a": 1}, obj_space={"a": (-1, 1)}, minimize=True) == {"a": -1}
	assert candidate(
    {"x1": 1, "x2": 2},
    {"x1": (-10, 10), "x2": (-10, 10)},
    True
) == {"x1": -1, "x2": 2}
	assert candidate(
    {"a": 1, "b": 1}, {"a": "maximize", "b": "minimize"}, False) == {"a": 1, "b": 1}
	assert candidate(input_dict={'a': 1, 'b': 2}, obj_space={'a':'minimize'}, minimize=True) == {'a': -1, 'b': 2}
	assert candidate(input_dict={"a": 1, "b": 2},
                obj_space={"a": "cat"}, minimize=False) == {"a": 1, "b": 2}
	assert candidate(
    input_dict={"obj": 1},
    obj_space={"obj": "minimize"},
    minimize=True
) == {"obj": -1}
	assert candidate(dict(x=1), dict(x=(0, 1)), True) == dict(x=-1)
	assert candidate(
    {"a": 1, "b": 1}, {"a": "minimize", "b": "minimize"}, False) == {"a": 1, "b": 1}
	assert candidate(dict(x=1), dict(x=(1, 2)), False) == dict(x=1)
	assert candidate(
    input_dict={'objective': 1},
    obj_space={'objective': (0, 1)},
    minimize=False) == {'objective': 1}
	assert candidate(
    {'x': 1, 'y': 2, 'z': 3},
    {'x': (-1, 1), 'y': (-2, 2), 'z': (-3, 3)},
    False
) == {'x': 1, 'y': 2, 'z': 3}
	assert candidate(
    {"a": 1, "b": 1}, {"a": "maximize", "b": "maximize"}, False) == {"a": 1, "b": 1}
	assert candidate(
    {'objective': 0.1},
    {'objective': (0, 1)},
    False
) == {'objective': 0.1}
	assert candidate(dict(x=1), dict(x=(1, 2)), True) == dict(x=-1)
	assert candidate(
    {"a": 1, "b": 1}, {"a": "minimize", "b": "maximize"}, False) == {"a": 1, "b": 1}
	assert candidate(input_dict={"x1": 1, "x2": 2, "obj": 3}, obj_space={"obj": (4, 0)}, minimize=False) == {"x1": 1, "x2": 2, "obj": 3}
	assert candidate(input_dict={'a': 1, 'b': 2}, obj_space={'a':'max'}, minimize=False) == {'a': 1, 'b': 2}
	assert candidate(dict(x=1), dict(x=(1, 1)), True) == dict(x=-1)
	assert candidate(
    input_dict={"obj": 1},
    obj_space={"obj": "maximize"},
    minimize=False
) == {"obj": 1}
	assert candidate(
    {'x': 1, 'y': 2}, {'x': (-1, 1), 'y': (0, 10)}, True) == {'x': -1, 'y': 2}
	assert candidate(
    input_dict={'objective': 1},
    obj_space={'objective': (0, 1)},
    minimize=True
)['objective'] == -1
	assert candidate(
    {"objective": 1}, {"objective": "minimize"}, minimize=True
) == {"objective": -1}
	assert candidate(
    input_dict={'objective': 1},
    obj_space={'objective': (0, 1)},
    minimize=False
)['objective'] == 1
	assert candidate(input_dict={"a": 1, "b": 2},
                obj_space={"a": "cat"}, minimize=True) == {"a": -1, "b": 2}
	assert candidate(
    {"a": 1, "b": 2}, {"a": "integer", "b": "integer"}, False
) == {"a": 1, "b": 2}
	assert candidate(
    {'a': 0.5, 'b': 0.5}, {'a': (0., 1.), 'b': (0., 1.)}, False) == {'a': 0.5, 'b': 0.5}
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 'INTEGER', 'b': 'INTEGER'},
    False
) == {'a': 1, 'b': 2}
	assert candidate(
    {'x': 1, 'y': 2}, {'x': (-1, 1), 'y': (0, 10)}, False) == {'x': 1, 'y': 2}
	assert candidate(input_dict={"a": -1}, obj_space={"a": (-1, 1)}, minimize=True) == {"a": 1}
	assert candidate(input_dict={'a': 1, 'b': 2}, obj_space={'a':'minimize'}, minimize=False) == {'a': 1, 'b': 2}
	assert candidate(dict(x=1), dict(x=(0, 1)), False) == dict(x=1)
	assert candidate(
    {"a": 1, "b": 1}, {"a": "minimize", "b": "maximize"}, True) == {"a": -1, "b": 1}
	assert candidate(dict(x=1), dict(x=(1, 1)), False) == dict(x=1)
	assert candidate(
    {"x1": 1, "x2": 2},
    {"x1": (-10, 10), "x2": (-10, 10)},
    False
) == {"x1": 1, "x2": 2}
	assert candidate(
    {'a': 1, 'b': -1},
    {'a': (0, 100), 'b': (-100, 100)},
    minimize=False
) == {'a': 1, 'b': -1}
	assert candidate(
    input_dict={'objective': 1},
    obj_space={'objective': (0, 1)},
    minimize=True) == {'objective': -1}
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 'INTEGER', 'b': 'INTEGER'},
    True
) == {'a': -1, 'b': 2}
	assert candidate(input_dict={"a": 2}, obj_space={"a": (-1, 1)}, minimize=True) == {"a": -2}
	assert candidate(input_dict={"x1": 1, "x2": 2, "obj": 3}, obj_space={"obj": (0, 4)}, minimize=True) == {"x1": 1, "x2": 2, "obj": -3}
def test_check():
	check(flip_obj)
