def _sort_keys_by_values(p):
    """Returns a sorted list of keys of p sorted by values of p."""
    ### Canonical solution below ###
    return sorted((pn for pn in p if p[pn]), key=lambda pn: p[pn])


### Unit tests below ###
def check(candidate):
	assert candidate({1: 1, 2: 2, 3: 3, 4: 4}) == [1, 2, 3, 4]
	assert candidate({'c': 3, 'a': 1, 'b': 2}) == ['a', 'b', 'c']
	assert candidate({'b': 2, 'c': 3, 'a': 1}) == ['a', 'b', 'c']
	assert candidate(dict(a=1, b=1)) == ['a', 'b']
	assert candidate(dict(A=1, B=2, C=3, D=4)) == ['A', 'B', 'C', 'D']
	assert candidate(dict(a=1, b=2, c=3)) == ['a', 'b', 'c']
	assert candidate(dict(a=3, b=2, c=1)) == ['c', 'b', 'a']
	assert candidate(dict(a=2, b=1)) == ['b', 'a']
	assert candidate({'a': 1}) == ['a']
	assert candidate(dict(a=0, b=1, c=2)) == ['b', 'c']
	assert candidate(dict(a=1, b=0)) == ['a']
	assert candidate({'a': 1, 'b': 2, 'c': 3}) == ['a', 'b', 'c']
	assert candidate({'c': 3, 'b': 2, 'a': 1}) == ['a', 'b', 'c']
	assert candidate({'b': 2, 'a': 1}) == ['a', 'b']
	assert candidate(dict(a=0, b=0, c=0)) == []
	assert candidate(dict(a=0, b=1)) == ['b']
	assert candidate(dict(a=0, b=0, c=2)) == ['c']
	assert candidate(dict()) == list()
	assert candidate(dict(a=2, b=1, c=3)) == ['b', 'a', 'c']
	assert candidate(dict(a=1)) == ['a']
	assert candidate(dict(a=3, b=1, c=2)) == ['b', 'c', 'a']
	assert candidate({'a': 1, 'b': 2}) == ['a', 'b']
	assert candidate({1: 1, 2: 2, 3: 3}) == [1, 2, 3]
	assert candidate(dict(a=1, b=0, c=2)) == ['a', 'c']
	assert candidate(dict()) == []
	assert candidate({1: 4, 2: 3, 3: 2, 4: 1}) == [4, 3, 2, 1]
	assert candidate({1: 3, 2: 2, 3: 1}) == [3, 2, 1]
	assert candidate({'a': 1, 'b': 1, 'c': 1}) == ['a', 'b', 'c']
	assert candidate(dict(a=1, b=1, c=1, d=1)) == ['a', 'b', 'c', 'd']
	assert candidate(dict(a=2, b=3, c=1)) == ['c', 'a', 'b']
	assert candidate(dict(a=None, b=3, c=1)) == ['c', 'b']
	assert candidate({'b': 2, 'a': 1, 'c': 3}) == ['a', 'b', 'c']
	assert candidate(dict(a=1, b=2)) == ['a', 'b']
	assert candidate(dict(a=1, b=1, c=1)) == ['a', 'b', 'c']
	assert candidate({1: 3, 2: 2, 3: 1, 4: 4}) == [3, 2, 1, 4]
def test_check():
	check(_sort_keys_by_values)
