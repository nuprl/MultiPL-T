def craft_sqlite_project_names_update(project_name,
    """ Given values for each field of the `project_names` table,
     return a tuple of the parameterized update statement and the record
     to pass to sqlite3.Connection.cursor.execute()
     """
	### Canonical solution below ###                                      page,
                                      api_has_been_queried,
                                      api_query_succeeded):
    
    update_query = f"""UPDATE project_names SET
                    api_has_been_queried={api_has_been_queried},
                    api_query_succeeded={api_query_succeeded},
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='{project_name}'
                    AND page={page}"""
    return update_query

### Unit tests below ###
def check(candidate):
	assert candidate(project_name="test",
                                         page=1,
                                         api_has_been_queried=1,
                                         api_query_succeeded=1) == """UPDATE project_names SET
                    api_has_been_queried=1,
                    api_query_succeeded=1,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='test'
                    AND page=1"""
	assert candidate(project_name='test_project',
                                         page=1,
                                         api_has_been_queried=1,
                                         api_query_succeeded=0) == """UPDATE project_names SET
                    api_has_been_queried=1,
                    api_query_succeeded=0,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='test_project'
                    AND page=1"""
	assert candidate(project_name='javascript',
                                         page=1,
                                         api_has_been_queried=1,
                                         api_query_succeeded=0) == """UPDATE project_names SET
                    api_has_been_queried=1,
                    api_query_succeeded=0,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='javascript'
                    AND page=1"""
	assert candidate(project_name='python',
                                         page=1,
                                         api_has_been_queried=0,
                                         api_query_succeeded=1) == """UPDATE project_names SET
                    api_has_been_queried=0,
                    api_query_succeeded=1,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='python'
                    AND page=1"""
	assert candidate(project_name='numpy',
                                         page=1,
                                         api_has_been_queried=1,
                                         api_query_succeeded=1) == """UPDATE project_names SET
                    api_has_been_queried=1,
                    api_query_succeeded=1,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='numpy'
                    AND page=1"""
	assert candidate(project_name='test_project',
                                         page=1,
                                         api_has_been_queried=1,
                                         api_query_succeeded=1) == """UPDATE project_names SET
                    api_has_been_queried=1,
                    api_query_succeeded=1,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='test_project'
                    AND page=1"""
	assert candidate(
   'my_project', 1, 0, 1) == """UPDATE project_names SET
                    api_has_been_queried=0,
                    api_query_succeeded=1,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='my_project'
                    AND page=1"""
	assert candidate(
    "test_project", 1, 1, 1) == f"""UPDATE project_names SET
                    api_has_been_queried=1,
                    api_query_succeeded=1,
                    execution_error=?,
                    contributors=?,
                    ts=current_timestamp
                    WHERE project_name='test_project'
                    AND page=1"""
def test_check():
	check(craft_sqlite_project_names_update)
