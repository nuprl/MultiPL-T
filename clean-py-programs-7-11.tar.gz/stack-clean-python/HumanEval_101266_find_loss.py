def find_loss(prediction, target):
    """ 
     Calculating the squared loss on the normalized GED.
     """
	### Canonical solution below ###    
    prediction = prediction
    target = target
    score = (prediction-target)**2
    return score

### Unit tests below ###
def check(candidate):
	assert candidate(1.0, 1.0) == 0.0, "Should be 0.0"
	assert candidate(prediction=1, target=0) == 1
	assert candidate(prediction=0, target=1) == 1
	assert candidate(1.0, 1.0) == 0.0
	assert candidate(0.1, 0.1) == 0
	assert candidate(prediction=1, target=1) == 0
	assert candidate(1,1) == 0
	assert candidate(1, 1) == 0
	assert candidate(prediction=0, target=2) == 4, "Should be 4"
	assert candidate(5.0, 10.0) == 25.0
	assert candidate(100, 100) == 0
	assert candidate(3, 1) == 4
	assert candidate(0.5, -0.1) == 0.36
	assert candidate(0.7, 0.7) == 0.0
	assert candidate(0.5,1) == 0.25
	assert candidate(10.0, 5.0) == 25.0
	assert candidate(0,1) == 1
	assert candidate(0.0, 0.0) == 0.0
	assert candidate(1, 3) == 4
	assert candidate(0.5, 0.5) == 0.0
	assert candidate(0.5, 0.5) == 0
	assert candidate(10, 15) == 25
	assert candidate(-2.0, -2.0) == 0.0, "Should be 0.0"
	assert candidate(0, 1) == 1
	assert candidate(0, 0) == 0
	assert candidate(prediction=0.5, target=0.5) == 0
	assert candidate(1, 2) == 1
	assert candidate(2, 1) == 1
	assert candidate(0.8, 0.8) == 0.0
	assert candidate(-1.0, 1.0) == 4.0, "Should be 4.0"
	assert candidate(1, 0.5) == 0.25
	assert candidate(1, 2.5) == 2.25
	assert candidate(2, 2) == 0
	assert candidate(prediction=10, target=5) == 25
	assert candidate(10, 0) == 100
	assert candidate(10, 10) == 0
	assert candidate(0, 100) == 10000
	assert candidate(0.6, 0.6) == 0.0
	assert candidate(3, 3) == 0
	assert candidate(2.0, 2.0) == 0.0, "Should be 0.0"
	assert candidate(10, 5) == 25
	assert candidate(prediction=10, target=10) == 0
	assert candidate(100, 10) == 8100
	assert candidate(0.0, 0.0) == 0.0, "Should be 0.0"
	assert candidate(0.5, -0.4) == 0.81
	assert candidate(prediction=1, target=2) == 1, "Should be 1"
	assert candidate(10, 20) == 100
	assert candidate(100, 0) == 10000
	assert candidate(0.0, 1.0) == 1.0
	assert candidate(0.5, 0.0) == 0.25
	assert candidate(0.5, 0.2) == 0.09
	assert candidate(1, 0) == 1
	assert candidate(0, 2) == 4
	assert candidate(1.0, 0.0) == 1.0
	assert candidate(-1.0, -1.0) == 0.0, "Should be 0.0"
	assert candidate(0.5, -0.5) == 1
	assert candidate(5, 10) == 25
	assert candidate(1.0, -1.0) == 4.0, "Should be 4.0"
	assert candidate(2, 3.5) == 2.25
	assert candidate(5.0, 5.0) == 0.0
def test_check():
	check(find_loss)
