def convert_iface(iface):
    """ Convert iface string like 'any', 'eth', 'eth0' to route iface naming like *, eth+, eth0. """
	### Canonical solution below ###    
    if iface == 'any':
        return '*'
    else:
        # append '+' quantifier to iface
        if not iface[-1].isdigit():
            iface += '+'
        return iface

### Unit tests below ###
def check(candidate):
	assert candidate('eth0.0') == 'eth0.0'
	assert candidate('eth0.1') == 'eth0.1'
	assert candidate('any') == '*'
	assert candidate('eth10') == 'eth10'
	assert candidate('eth1') == 'eth1'
	assert candidate('eth') == 'eth+'
	assert candidate('eth0.11') == 'eth0.11'
	assert candidate('eth11') == 'eth11'
	assert candidate('eth0') == 'eth0'
	assert candidate('eth0123') == 'eth0123'
def test_check():
	check(convert_iface)
