def oooc_to_ooow(formula):
    """Convert (proprietary) formula from calc format to writer format.

    Arguments:

        formula -- str

    Return: str
    """
    ### Canonical solution below ###
    prefix, formula = formula.split(":=", 1)
    assert "oooc" in prefix
    # Convert cell addresses
    formula = formula.replace("[.", "<").replace(":.", ":").replace("]", ">")
    # Convert functions
    formula = formula.replace("SUM(", "sum ").replace(")", "")
    return "ooow:" + formula


### Unit tests below ###
def check(candidate):
	assert candidate(r"oooc:=SUM([.A1:.A4])") == r"ooow:sum <A1:A4>"
	assert candidate(
    "oooc:=sum <A1:A3> * <B1:B3> + <C1:C3> + <D1:D3> + <E1:E3>") == "ooow:sum <A1:A3> * <B1:B3> + <C1:C3> + <D1:D3> + <E1:E3>"
	assert candidate(
    "oooc:=sum <A1:A3> * <B1:B3> + <C1:C3>") == "ooow:sum <A1:A3> * <B1:B3> + <C1:C3>"
	assert candidate(
    "oooc:=sum <A1:A3> * <B1:B3>") == "ooow:sum <A1:A3> * <B1:B3>"
	assert candidate(r"oooc:=SUM([.A1:A4])") == r"ooow:sum <A1:A4>"
	assert candidate("oooc:A1:=SUM(A1:A2)") == "ooow:sum A1:A2"
	assert candidate(
    "oooc:=sum <A1:A3> * <B1:B3> + <C1:C3> + <D1:D3>") == "ooow:sum <A1:A3> * <B1:B3> + <C1:C3> + <D1:D3>"
def test_check():
	check(oooc_to_ooow)
