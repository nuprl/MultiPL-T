def gen_pair(row, V, PBC=False):
    """ 
     assume row is an in order array generate a cyclic pairs
     in the row array given with interaction strength V.
     For example: row = [1, 2, 3, 5]
     will gives [(1, 2, V), (2, 3, V), (3, 5, V), (5, 1, V)]
     """
	### Canonical solution below ###    
    if PBC:
        return [(row[i], row[(i + 1) % len(row)], V) for i in range(len(row))]
    else:
        return [(row[i], row[(i + 1) % len(row)], V) for i in range(len(row) - 1)]

### Unit tests below ###
def check(candidate):
	assert candidate(range(5), 1, PBC=True) == [(0, 1, 1), (1, 2, 1), (2, 3, 1), (3, 4, 1), (4, 0, 1)]
	assert candidate(range(5), 1, PBC=False) == [(0, 1, 1), (1, 2, 1), (2, 3, 1), (3, 4, 1)]
	assert candidate(row=[1, 2, 3, 4, 5], V=1, PBC=True) == [(1, 2, 1), (2, 3, 1), (3, 4, 1), (4, 5, 1), (5, 1, 1)]
	assert candidate(row=[1, 2, 3, 5], V=1, PBC=True) == [(1, 2, 1), (2, 3, 1), (3, 5, 1), (5, 1, 1)]
	assert candidate(row=[1, 2, 3, 5], V=0.25, PBC=True) == [(1, 2, 0.25), (2, 3, 0.25), (3, 5, 0.25), (5, 1, 0.25)]
	assert candidate(row=[1, 2, 3, 5], V=1, PBC=False) == [(1, 2, 1), (2, 3, 1), (3, 5, 1)]
	assert candidate(row=[1, 2, 3], V=1, PBC=True) == [(1, 2, 1), (2, 3, 1), (3, 1, 1)]
	assert candidate(row=[1, 2, 3, 5], V=0.25, PBC=False) == [(1, 2, 0.25), (2, 3, 0.25), (3, 5, 0.25)]
def test_check():
	check(gen_pair)
