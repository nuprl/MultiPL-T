def quasi_newton( f , xi , step , epsilon=1e-5 , max=100 ):
    """ 
     quasi_newton( f , xi , step , epsilon , max ). 
     This is a root-finding method that finds the minimum of a function (f) using quasi-newton method.
     
     Parameters:
     f (function): the function to minimize
     xi (float): the starting point for the iterative process
     step (float): small step size to calculate an approached value to the derivatives
     epsilon (float): very small number
     max (int): max number of iterations
     
     Returns:
     x: optimum value
     
     """
	### Canonical solution below ###    
    k=0
    x=xi
    fx=f(x)
    fplus=f(x+step)
    fmoins=f(x-step)
    x=x-((step*(fplus-fmoins))/(2*(fplus-2*fx+fmoins)))
    fplus=f(x+step)
    fmoins=f(x-step)
    dfx=(fplus-fmoins)/(2*step)
    while abs(dfx)>epsilon and k<max:
        fplus=f(x+step)
        fmoins=f(x-step)
        fx=f(x)
        dfx=(fplus-fmoins)/(2*step)
        x=x-((step*(fplus-fmoins))/(2*(fplus-2*fx+fmoins)))
        k+=1
    if k==max:
        print("Error")
    else:
        return x

### Unit tests below ###
def check(candidate):
	assert candidate( f=lambda x: x**2, xi=0, step=10 ) == 0.0
	assert candidate( lambda x: x**3-2*x**2+1, 1, 0.1, 1e-5, 100)!= 1.00000000001208981
	assert candidate( f=lambda x: x**2, xi=0, step=100 ) == 0.0
	assert candidate( f=lambda x: x**2, xi=0, step=0.1 ) == 0.0
	assert candidate( f=lambda x: x**2, xi=0, step=1 ) == 0.0
	assert candidate( f=lambda x: x**2, xi=0, step=0.01 ) == 0.0
def test_check():
	check(quasi_newton)
