def write_rex_file(bytes, path: str):
    """Write to disk a rexfile from its binary format"""
    ### Canonical solution below ###

    new_file = open(path + ".rex", "wb")
    new_file.write(bytes)
    return True


### Unit tests below ###
def check(candidate):
	assert candidate(bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]), "tests/test_candidate")
	assert candidate(bytes([0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]), "test.rex")
	assert candidate(bytes([0, 1, 2]), "test\\rex")
	assert candidate(b"hello", "hello")
	assert candidate(b"Test", "test")
	assert candidate(b"\x00\x01\x02\x03", "test_candidate") == True
	assert candidate(b"\x01\x02\x03\x04", "test_copy.rex")
	assert candidate(b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', "test_candidate") == True
	assert candidate(bytearray([0, 0, 0, 0]), "test")
	assert candidate(bytes(b"Hello world"), "test") == True
	assert candidate(bytes(0x10000), "test_rex_file.rex") == True
	assert candidate(b"123456", "test")
	assert candidate(b"Rexfile", "test") == True
	assert candidate(b"", "tests/test.rex") == True
	assert candidate(b"\x01\x02\x03", "test.rex")
	assert candidate(bytes([0, 1, 2]), "test.rex")
	assert candidate(b"test", "tests/test")
	assert candidate(bytearray([1, 2, 3, 4, 5]), "test") == True
	assert candidate(bytes([0, 1, 2]), "test")
def test_check():
	check(write_rex_file)
