def size_from_shape(shape) :
    """Returns size from the shape sequence 
    """
    ### Canonical solution below ###
    size=1
    for d in shape : size*=d
    return size


### Unit tests below ###
def check(candidate):
	assert candidate(shape=(2,3,4))==24
	assert candidate( (2,3) ) == 6
	assert candidate( (2,3)   )==6
	assert candidate( (3,4,5) ) == 60
	assert candidate( (10,2,3) ) == 10*2*3
	assert candidate( (10,10,10) ) == 1000
	assert candidate( (1,3,1) ) == 3
	assert candidate( (1,3,4) ) == 12
	assert candidate( (10,20,30) ) == 6000
	assert candidate( (10,10,10,10) ) == 10000
	assert candidate( (2,2,2) ) == 8
	assert candidate( (3,2,1) ) == 6
	assert candidate( (1,2,3,4,5,6) ) == 720
	assert candidate( (10,20) ) == 200
	assert candidate( (1,2,3,4,5) )==120
	assert candidate( (3,4,5) )==60
	assert candidate( (2,3,4) )==24
	assert candidate( (1,2,3,4,5) ) == 120
	assert candidate( (2,1,1) ) == 2
	assert candidate( (3,2,4) ) == 24
	assert candidate( (3,4) )==12
	assert candidate( () ) == 1
	assert candidate( (2,) ) == 2
	assert candidate( (10,10) ) == 100
	assert candidate( (2,2) ) == 4
	assert candidate(shape=(2,3,4,5))==120
	assert candidate( (1,2,3,4) ) == 24
	assert candidate( (2,3,4) ) == 24
	assert candidate( (2,3,4,5) ) == 120
	assert candidate( (1,2,3) ) == 6
	assert candidate( (3,4) ) == 12
	assert candidate( (5,2,3,4,6) ) == 720
	assert candidate( (1,2,3) )==6
	assert candidate( (5,2,3,4) ) == 120
	assert candidate( (10,) ) == 10
	assert candidate( (2,3,4,5) )==120
	assert candidate( (1,1,1) ) == 1
	assert candidate( (1,2) ) == 2
	assert candidate(shape=(2,3))==6
	assert candidate( (1,) ) == 1
	assert candidate( (3,2,4,5) ) == 120
	assert candidate( (1,1,4) ) == 4
	assert candidate( (1,1) ) == 1
	assert candidate( (3,3,3) ) == 27
	assert candidate( (5,2,3) ) == 30
def test_check():
	check(size_from_shape)
