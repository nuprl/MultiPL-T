def pinned_cores_from_vars(ansible_vars):
    """ Get requested number of pinned CPU cores for PMD from Ansible Role run
        and return integer """
    ### Canonical solution below ###

    numa_nodes = ansible_vars["numa_nodes"]
    total_num_cores = 0

    for node in sorted(numa_nodes.keys()):
        num_cores = numa_nodes[node]["no_physical_cores_pinned"]
        total_num_cores += num_cores

    return total_num_cores


### Unit tests below ###
def check(candidate):
	assert candidate(
    {"numa_nodes": {
        "0": {"no_physical_cores_pinned": 0},
        "1": {"no_physical_cores_pinned": 0},
        "2": {"no_physical_cores_pinned": 0}}}) == 0
	assert candidate(
    {'numa_nodes': {'0': {'no_physical_cores_pinned': 1}, '1': {'no_physical_cores_pinned': 2}, '2': {'no_physical_cores_pinned': 3}}}
) == 6
	assert candidate(
    {"numa_nodes": {
        0: {"no_physical_cores_pinned": 0, "no_logical_cores_pinned": 0},
        1: {"no_physical_cores_pinned": 1, "no_logical_cores_pinned": 0},
        2: {"no_physical_cores_pinned": 1, "no_logical_cores_pinned": 1},
        3: {"no_physical_cores_pinned": 0, "no_logical_cores_pinned": 0},
    }}
) == 2
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 1},
                    1: {"no_physical_cores_pinned": 1},
                    2: {"no_physical_cores_pinned": 1}}}
) == 3
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 1}}}
) == 1
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 1},
                    1: {"no_physical_cores_pinned": 2}}}) == 3
	assert candidate(
    {
        "numa_nodes": {
            "0": {
                "no_physical_cores_pinned": 4,
                "no_logical_cores_pinned": 4
            },
            "1": {
                "no_physical_cores_pinned": 4,
                "no_logical_cores_pinned": 4
            }
        }
    }
) == 8
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 1},
                    1: {"no_physical_cores_pinned": 1}}}
) == 2
	assert candidate(
    {'numa_nodes': {'0': {'no_physical_cores_pinned': 1}, '1': {'no_physical_cores_pinned': 2}, '2': {'no_physical_cores_pinned': 3}, '3': {'no_physical_cores_pinned': 4}}}
) == 10
	assert candidate(
    {"numa_nodes": {
        "0": {"no_physical_cores_pinned": 1},
        "1": {"no_physical_cores_pinned": 2},
        "2": {"no_physical_cores_pinned": 3}}}) == 6
	assert candidate(
    {"numa_nodes": {"0": {"no_physical_cores_pinned": 1},
                    "1": {"no_physical_cores_pinned": 2}}}
    ) == 3
	assert candidate(
    {"numa_nodes": {
        "0": {
            "no_physical_cores_pinned": 4
        },
        "1": {
            "no_physical_cores_pinned": 8
        }
    }}) == 12
	assert candidate(
    {'numa_nodes': {'0': {'no_physical_cores_pinned': 1}, '1': {'no_physical_cores_pinned': 2}}}
) == 3
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 2},
                    1: {"no_physical_cores_pinned": 2},
                    2: {"no_physical_cores_pinned": 2}}}) == 6
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 2},
                    1: {"no_physical_cores_pinned": 2}}}) == 4
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 4},
                    1: {"no_physical_cores_pinned": 2}}}) == 6
	assert candidate(
    {"numa_nodes": {}}
) == 0
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 2},
                    1: {"no_physical_cores_pinned": 2},
                    2: {"no_physical_cores_pinned": 2},
                    3: {"no_physical_cores_pinned": 2}}}) == 8
	assert candidate(
    {"numa_nodes": {0: {"no_physical_cores_pinned": 1},
                    1: {"no_physical_cores_pinned": 1},
                    2: {"no_physical_cores_pinned": 1},
                    3: {"no_physical_cores_pinned": 1}}}
) == 4
def test_check():
	check(pinned_cores_from_vars)
