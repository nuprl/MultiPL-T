def uvCooToBitmapIndex(TGAXres, TGAYres, U, V):
    """ 
    
    This function takes UV coordinates and a bitmap resolution as input and 
    returns an index to the position of a pixel in the bitmap.
     
    UV coordinates are used to map 2D images to 3D surfaces. 
    In the case of the MakeHuman mesh, each face has 3 vertices each of which has 
    a pair of uv-coordinates that provide a horizontal and vertical value between 0 and 1 
    to point to the location on an image map from which to read a value.
    
    For an image with a resolution of Xn x Ym, any UV coordinate will lie within 
    a square whose bottom left corner has a pixel coordinate between <0,0> and 
    <Xn-1,Ym-1>. 
    This in turn can be transformed into a pixel index in the bitmap image by multiplying 
    the Y value by Xn and adding the X value. In the example on the right the UV coordinates
    <0.38,0.32> lie in the pixel whose bottom left coordinates are <3,2>, giving a pixel index 
    of 2x8+3 = 19. 
    (This will be the 20th pixel in the bitmap because the first is numbered '0'). 
    
    Parameters
    ----------

    TGAXres:
        *integer*. The X component of the resolution of the bitmap.
    TGAYres:
        *integer*. The Y component of the resolution of the bitmap.
    U:
        *float*. The horizontal component of the UV coordinates. A value between 0 and 1.
    V:
        *float*. The vertical component of the UV coordinate. A value between 0 and 1
    """
    ### Canonical solution below ###

    # We use 'resolution - 1' in both dimensions as multiplication
    # factors to work out which pixel the UV coordinate sits in.
    # The calculated coordinates are integer values counting from '0'.

    UVimageCoordX = int(abs((TGAXres - 1) * U))
    UVimageCoordY = int(abs((TGAYres - 1) * V))
    pixelIndex = UVimageCoordX + UVimageCoordY * TGAXres
    return pixelIndex


### Unit tests below ###
def check(candidate):
	assert candidate(3, 3, 1, 1) == 8
	assert candidate(2, 2, 0.25, 0.25) == 0
	assert candidate(64, 64, 0.0, 0.0) == 0
	assert candidate(10, 10, 0.0, 0.0) == 0
	assert candidate(1, 1, 0.5, 0.5) == 0
	assert candidate(8, 8, 1, 1) == 63
	assert candidate(10, 10, 1.0, 1.0) == 99
	assert candidate(2,2,0,0) == 0
	assert candidate(1, 1, 1, 0) == 0
	assert candidate(3, 3, 0, 1) == 6
	assert candidate(2, 2, 0, 1) == 2
	assert candidate(3, 3, 0, 0) == 0
	assert candidate(3,3,1,1) == 8
	assert candidate(3, 3, 0.5, 0.5) == 4
	assert candidate(10, 10, 0, 0) == 0
	assert candidate(10,10,0,0) == 0
	assert candidate(4, 3, 0.5, 0.5) == 5
	assert candidate(TGAXres=10, TGAYres=10, U=0, V=0) == 0
	assert candidate(6, 8, 1.0, 0.0) == 5, "candidate test 2 failed"
	assert candidate(3, 3, 1.0, 1.0) == 8
	assert candidate(1,1,0,0) == 0
	assert candidate(3,3,0.5,0.5) == 4
	assert candidate(20, 20, 1, 1) == 20*20 - 1
	assert candidate(10, 10, 0.1, 0.1) == 0
	assert candidate(64, 64, 1.0, 1.0) == 4095
	assert candidate(2, 4, 0.0, 0.0) == 0
	assert candidate(16, 16, 0.0, 0.0) == 0
	assert candidate(10, 10, 1.1, 1.1) == 99
	assert candidate(3, 3, 0.0, 1.0) == 6
	assert candidate(2, 2, 1, 0) == 1
	assert candidate(3, 3, 0.0, 0.0) == 0
	assert candidate(20, 20, 0.0, 0.0) == 0
	assert candidate(6, 8, 0.0, 0.0) == 0, "candidate test 5 failed"
	assert candidate(8, 8, 0, 0) == 0
	assert candidate(20, 10, 1, 0) == 19
	assert candidate(2, 8, 1, 0.5) == 7
	assert candidate(3,3,0,0) == 0
	assert candidate(2, 4, 1.0, 1.0) == 7
	assert candidate(20,20,0.0,0.0) == 0
	assert candidate(10, 10, 1, 0) == 9
	assert candidate(2, 4, 0.25, 0.25) == 0
	assert candidate(100, 100, 0.0, 0.0) == 0
	assert candidate(2, 2, 0.5, 0.5) == 0
	assert candidate(20, 20, 0, 0) == 0
	assert candidate(2, 2, 0.5, 1) == 2
	assert candidate(3, 3, 1.0, 0.5) == 5
	assert candidate(TGAXres=10, TGAYres=10, U=1, V=1) == 99
	assert candidate(3, 3, 0.5, 1.0) == 7
	assert candidate(8, 8, 1, 0) == 7
	assert candidate(1, 1, 0, 0) == 0
	assert candidate(16, 16, 1.0, 0.0) == 15
	assert candidate(10, 10, 1.0, 0.0) == 9
	assert candidate(20, 10, 0.0, 0.0) == 0
	assert candidate(8, 8, 0.0, 0.0) == 0
	assert candidate(100, 100, 1.0, 1.0) == 9999
	assert candidate(1, 1, 0, 1) == 0
	assert candidate(8, 8, 1.0, 0.0) == 7
	assert candidate(100, 100, 0.0001, 0.0001) == 0
	assert candidate(2, 8, 0, 0) == 0
	assert candidate(2, 2, 0, 0) == 0
	assert candidate(2, 2, 1, 1) == 3
	assert candidate(4,4,0,0) == 0
	assert candidate(2, 8, 1, 1) == 15
	assert candidate(20, 10, 0, 0) == 0
	assert candidate(1, 1, 1, 1) == 0
def test_check():
	check(uvCooToBitmapIndex)
