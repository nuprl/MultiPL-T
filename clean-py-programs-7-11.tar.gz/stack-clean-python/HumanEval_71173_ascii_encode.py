def ascii_encode(string: str):
    """
    Encodes the string in ascii in ignore mode

    Args:
        string: The string

    Returns:
        The string in ascii
    """
    ### Canonical solution below ###

    return str(string.encode('ascii', 'ignore'))[2:-1]


### Unit tests below ###
def check(candidate):
	assert candidate("Hello, World!") == "Hello, World!"
	assert candidate(
    'hello world'
) == 'hello world', 'hello world test failed'
	assert candidate("🤣") == ""
	assert candidate("😂12345") == "12345"
	assert candidate(r'«Hola»') == 'Hola'
	assert candidate('abc') == 'abc'
	assert candidate(string='my string🐍') =='my string'
	assert candidate("12345😂") == "12345"
	assert candidate("Hello") == "Hello"
	assert candidate(string = '😀😀😀') == ''
	assert candidate('a1b2c3') == 'a1b2c3'
	assert candidate(u"£20")!= u"£20£"
	assert candidate('🙂') == ''
	assert candidate('Hello World') == "Hello World"
	assert candidate('123') == '123'
	assert candidate("£") == ""
	assert candidate(string='!@#') == '!@#'
	assert candidate(candidate('test')) == 'test'
	assert candidate(u"ascii") == "ascii"
	assert candidate(string='my string') =='my string'
	assert candidate('£') == ''
	assert candidate(string = '12345') == '12345'
	assert candidate(string = '😀abc') == 'abc'
	assert candidate(string='3456') == '3456'
	assert candidate(string = '😀😀abc') == 'abc'
	assert candidate(u' ') == u' '
	assert candidate(string='!@#$%^&*()_+') == '!@#$%^&*()_+'
	assert candidate(string = '😀') == ''
	assert candidate(string = '🚗') == ''
	assert candidate('This is a test string 1234567890') == 'This is a test string 1234567890', \
    'candidate is not working'
	assert candidate(candidate("Hello")) == "Hello"
	assert candidate("12345") == "12345"
	assert candidate(string = '12345😀') == '12345'
	assert candidate(string='my string🐍🐍') =='my string'
	assert candidate(string="c") == "c"
	assert candidate(string='test') == 'test'
	assert candidate(u"£20")!= u"£"
	assert candidate(
    'This is a test string') == 'This is a test string', 'candidate is not working'
	assert candidate(string = '12345😀abc') == '12345abc'
	assert candidate('a') == 'a'
	assert candidate("👨‍🚀") == ""
	assert candidate(string = 'abc') == 'abc'
	assert candidate(string='my string🐍🐍🐍') =='my string'
def test_check():
	check(ascii_encode)
