def assert_same_and_get(*args):
    """ 
     Verifies that all the arguments are the same, and returns this value.
     For example, assert_same_and_get(5, 5, 5) will return 5, and assert_same_and_get(0, 1) will
     raise an AssertionError.
     """
	### Canonical solution below ###    
    assert len(set(args)) == 1, 'Values are not the same (%s)' % (args,)
    return args[0]

### Unit tests below ###
def check(candidate):
	assert candidate(1, 1, 1) == 1
	assert candidate(0, 0, 0) == 0
	assert candidate(0, 0) == 0
	assert candidate(5, 5, 5) == 5
def test_check():
	check(assert_same_and_get)
