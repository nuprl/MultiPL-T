def switch_01(value):
    """ Switches 0 to 1 and 1 to 0
     :param value: integer, 0 or 1
     :return: integer, 1 or 0
     """
	### Canonical solution below ###    
    if value not in (0, 1): raise ValueError('value has to be equal to 0 or 1')
    return 0 if value else 1

### Unit tests below ###
def check(candidate):
	assert candidate(1) == 0, '1 to 0'
	assert candidate(0) == 1,'candidate(0) returns 1'
	assert candidate(1) == 0,'candidate(1) returns 0'
	assert candidate(0) == 1, "Error: value is 0"
	assert candidate(0.0) == 1
	assert candidate(0) == 1, '0 to 1'
	assert candidate(1) == 0
	assert candidate(1) == 0, "Error: value is 1"
	assert candidate(1) == 0, "candidate(1) should return 0"
	assert candidate(0) == 1, "candidate(0) should return 1"
	assert candidate(True) == 0
	assert candidate(0) == 1
	assert candidate(False) == 1
	assert candidate(0) == 1, "Function candidate(0) is incorrect."
	assert candidate(1.0) == 0
	assert candidate(1) == 0, '1 is 0'
	assert candidate(1) == 0, "Function candidate(1) is incorrect."
	assert candidate(0) == 1, '0 is 1'
def test_check():
	check(switch_01)
