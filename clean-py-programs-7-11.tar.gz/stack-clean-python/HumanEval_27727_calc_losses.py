def calc_losses(earth_atmospheric_losses, all_other_losses):
    """
    Estimates the transmission signal losses.

    Parameters
    ----------
    earth_atmospheric_losses : int
        Signal losses from rain attenuation.
    all_other_losses : float
        All other signal losses.

    Returns
    -------
    losses : float
        The estimated transmission signal losses.

    """
    ### Canonical solution below ###
    losses = earth_atmospheric_losses + all_other_losses

    return losses


### Unit tests below ###
def check(candidate):
	assert candidate(20, 20) == 40
	assert candidate(earth_atmospheric_losses=50, all_other_losses=100) == 150
	assert candidate(earth_atmospheric_losses=100, all_other_losses=0) == 100
	assert candidate(0.5, 0.25) == 0.75, "Should be 0.75"
	assert candidate(20, 10.5) == 30.5
	assert candidate(100, 1000) == 1100
	assert candidate(0, 0.5) == 0.5, "Should be 0.5"
	assert candidate(1.25, 0.75) == 2, "Should be 2"
	assert candidate(earth_atmospheric_losses=100, all_other_losses=50) == 150
	assert candidate(0.5, 0) == 0.5, "Should be 0.5"
	assert candidate(100, 100) == 200
	assert candidate(0.5, 0.5) == 1, "Should be 1"
	assert candidate(0, 1) == 1
	assert candidate(earth_atmospheric_losses=10, all_other_losses=20) == 30
	assert candidate(10, 5) == 15
	assert candidate(10, 20) == 30, "Incorrect losses"
	assert candidate(1.25, 2.75) == 4, "Should be 4"
	assert candidate(earth_atmospheric_losses=5, all_other_losses=2.5) == 7.5
	assert candidate(20, 10) == 30
	assert candidate(earth_atmospheric_losses=0, all_other_losses=1000) == 1000
	assert candidate(2.1, 2.4) == 4.5
	assert candidate(earth_atmospheric_losses=5, all_other_losses=0) == 5
	assert candidate(2, 3) == 5, "Incorrect value for earth_atmospheric_losses"
	assert candidate(0.25, 0.75) == 1, "Should be 1"
	assert candidate(1, 3) == 4, "Incorrect value for all_other_losses"
	assert candidate(0, 10) == 10
	assert candidate(0.75, 1.25) == 2, "Should be 2"
	assert candidate(0, 1) == 1, "Should be 1"
	assert candidate(0.15, 0.15) == 0.30
	assert candidate(10, 0) == 10
	assert candidate(-10, 0) == -10
	assert candidate(10, 10) == 20
	assert candidate(1, 1) == 2
	assert candidate(0.0, 1.0) == 1.0
	assert candidate(0.1, 0.10) == 0.20
	assert candidate(1.5, 2.5) == 4, "Should be 4"
	assert candidate(1, 2) == 3, "Should be 3"
	assert candidate(0, 0) == 0, "Should be 0"
	assert candidate(1.7, 2.8) == 4.5
	assert candidate(earth_atmospheric_losses=1, all_other_losses=2) == 3
	assert candidate(1, 0) == 1, "Should be 1"
	assert candidate(earth_atmospheric_losses=0, all_other_losses=100) == 100
	assert candidate(0, 20) == 20
	assert candidate(earth_atmospheric_losses=1000, all_other_losses=0) == 1000
	assert candidate(0.5, 0.7) == 1.2
	assert candidate(20.5, 100) == 120.5
	assert candidate(1.5, 2.5) == 4, "Incorrect value for all_other_losses"
	assert candidate(1.5, 3.3) == 4.8
	assert candidate(earth_atmospheric_losses=0, all_other_losses=0) == 0
	assert candidate(10, 100) == 110
	assert candidate(1.5, 2.1) == 3.6
	assert candidate(1.0, 0.0) == 1.0
	assert candidate(10, 10)!= 15, 'The total signal losses are not correct'
	assert candidate(10, 20) == 30
	assert candidate(250, 100) == 350
	assert candidate(2.5, 2.5) == 5.0
	assert candidate(earth_atmospheric_losses=5, all_other_losses=10) == 15
	assert candidate(5, 10) == 15
	assert candidate(0, -5) == -5
	assert candidate(earth_atmospheric_losses=1, all_other_losses=0) == 1
	assert candidate(0, 5) == 5
	assert candidate(0, 100) == 100
	assert candidate(5.3, 2.5) == 7.8, "Incorrect value for all_other_losses"
	assert candidate(0.05, 0.05) == 0.10
	assert candidate(1.0, 1.0) == 2.0
	assert candidate(100, 0) == 100
	assert candidate(0.0, 0.0) == 0.0
	assert candidate(0.75, 0.25) == 1, "Should be 1"
	assert candidate(earth_atmospheric_losses = 0, all_other_losses = 5) == 5
	assert candidate(20.5, 100.5) == 121.0
	assert candidate(earth_atmospheric_losses=0, all_other_losses=10) == 10
	assert candidate(0, 0) == 0
	assert candidate(0.2, 0.20) == 0.40
	assert candidate(0, 2) == 2
	assert candidate(1, 0) == 1
	assert candidate(1, 1) == 2, "Should be 2"
	assert candidate(-10, -5) == -15
	assert candidate(1, 2) == 3
	assert candidate(0, 1.9) == 1.9
	assert candidate(20, 100) == 120
	assert candidate(10, 10) == 20, 'The total signal losses are not correct'
	assert candidate(0, 0) == 0, "The function is not working."
	assert candidate(earth_atmospheric_losses = 3, all_other_losses = 5) == 8
	assert candidate(2, 1) == 3
	assert candidate(10, 10)!= 25, 'The total signal losses are not correct'
	assert candidate(100, 20) == 120
	assert candidate(earth_atmospheric_losses=1, all_other_losses=10) == 11
def test_check():
	check(calc_losses)
