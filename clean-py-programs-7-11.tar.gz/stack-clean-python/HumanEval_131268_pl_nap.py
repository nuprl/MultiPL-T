def pl_nap(time, nap_min):
    """power law nap time"""
    ### Canonical solution below ###
    if(time<nap_min):
        return nap_min
    a = 2.
    b = 0.5
    nap_max = 3600 #1 hour
    return (a*time**b)%nap_max


### Unit tests below ###
def check(candidate):
	assert candidate(0, 30) == 30
	assert candidate(1, 45) == 45
	assert candidate(1, 1800) == 1800
	assert candidate(1,2) == 2
	assert candidate(1, 259200) == 259200
	assert candidate(0, 300)==300
	assert candidate(1, 1000) == 1000
	assert candidate(300, 3600) == 3600
	assert candidate(1,10) == 10
	assert candidate(1,1000) == 1000
	assert candidate(0, 100000000) == 100000000
	assert candidate(1, 12) == 12
	assert candidate(1, 3) == 3
	assert candidate(1, 9676800) == 9676800
	assert candidate(10,100)==100
	assert candidate(100,100000) == 100000
	assert candidate(1, 450) == 450
	assert candidate(1, 28800) == 28800
	assert candidate(4, 1) == 4
	assert candidate(1, 86400) == 86400
	assert candidate(1, 172800) == 172800
	assert candidate(100, 10000) == 10000
	assert candidate(0,1) == 1
	assert candidate(1, 1209600) == 1209600
	assert candidate(0, 0) == 0
	assert candidate(0, 10) == 10
	assert candidate(1, 2) == 2
	assert candidate(100, 120) == 120
	assert candidate(10,100000) == 100000
	assert candidate(10, 1000) == 1000
	assert candidate(1, 30) == 30
	assert candidate(10, 10000) == 10000
	assert candidate(1,10000) == 10000
	assert candidate(3600,36000) == 36000
	assert candidate(0, 100) == 100
	assert candidate(1,3600) == 3600
	assert candidate(1, 14400) == 14400
	assert candidate(1, 20) == 20
	assert candidate(100, 1000) == 1000
	assert candidate(1000, 10000) == 10000
	assert candidate(1, 10) == 10
	assert candidate(1000,100000) == 100000
	assert candidate(1, 345600) == 345600
	assert candidate(1, 4838400) == 4838400
	assert candidate(1, 2419200) == 2419200
	assert candidate(100,10000)==10000
	assert candidate(1, 270) == 270
	assert candidate(1,100000) == 100000
	assert candidate(1, 15) == 15
	assert candidate(1,100000)==100000
	assert candidate(1, 120) == 120
	assert candidate(1, 6) == 6
	assert candidate(10000,100000) == 100000
	assert candidate(2, 10) == 10
	assert candidate(1, 180) == 180
	assert candidate(50, 1800) == 1800
	assert candidate(1, 7200) == 7200
	assert candidate(1, 900) == 900
	assert candidate(10,1000)==1000
	assert candidate(1, 90) == 90
	assert candidate(100, 3600) == 3600
	assert candidate(1, 43200) == 43200
	assert candidate(10,10000)==10000
	assert candidate(1,1000)==1000
	assert candidate(1, 3600) == 3600
	assert candidate(1,10000)==10000
	assert candidate(1,10)==10
	assert candidate(10, 100) == 100
	assert candidate(100,1000)==1000
	assert candidate(1, 604800) == 604800
	assert candidate(0, 1) == 1
	assert candidate(10,100000)==100000
	assert candidate(100,100000)==100000
	assert candidate(0, 600) == 600
	assert candidate(1, 4) == 4
	assert candidate(1, 60) == 60
	assert candidate(1, 9) == 9
	assert candidate(0,10) == 10
	assert candidate(1,100)==100
	assert candidate(1,100) == 100
	assert candidate(1, 100) == 100
def test_check():
	check(pl_nap)
