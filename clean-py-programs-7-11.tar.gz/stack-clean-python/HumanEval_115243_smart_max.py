def smart_max(v1, v2):
    """ 
     Returns max value even if one value is None.
     
     Python cannot compare None and int, so build a wrapper
     around it.
     """
	### Canonical solution below ###    
    if v1 is None:
        return v2

    if v2 is None:
        return v1

    return max(v1, v2)

### Unit tests below ###
def check(candidate):
	assert candidate(2, 1) == 2
	assert candidate(3, None) == 3
	assert candidate(None, 3) == 3
	assert candidate(None, 5) == 5
	assert candidate(2, None) == 2
	assert candidate(2, 3) == 3
	assert candidate(3, 2) == 3
	assert candidate(5, None) == 5
	assert candidate(10, None) == 10
	assert candidate(None, 1) == 1
	assert candidate(None, 2) == 2
	assert candidate(1, 2) == 2
	assert candidate(5, 3) == 5
	assert candidate(None, 10) == 10
	assert candidate(10, 5) == 10
	assert candidate(1, None) == 1
	assert candidate(1, 1) == 1
	assert candidate(5, 10) == 10
	assert candidate(None, None) is None
	assert candidate(3, 5) == 5
	assert candidate(None, None) == None
def test_check():
	check(smart_max)
