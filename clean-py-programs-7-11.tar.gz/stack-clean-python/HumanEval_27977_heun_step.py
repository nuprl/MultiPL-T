def heun_step(f, x0, t0, t1):
    """
    One time step of Heun's method

    f  : function dx_dt(t0, x0)
    x0 : initial condition
    t0 : this step time
    t1 : next step time
    """
    ### Canonical solution below ###

    # time step
    delta_t = t1 - t0

    # slope
    s1 = f(t0, x0)

    # next step by Euler
    x1_euler = x0 + s1 * delta_t

    # slope at next step
    s2 = f(t1, x1_euler)

    # average of two slopes
    s_average = (s1 + s2) * 0.5

    # next step by Heun's method
    x1 = x0 + s_average * delta_t

    return x1


### Unit tests below ###
def check(candidate):
	assert candidate(lambda t, x: 0, 1, 0, 1) == 1
	assert candidate(lambda t, x: 1, 0, 0, 1) == 1
	assert candidate(lambda t, x: t * x, 0, 0, 1) == 0
	assert candidate(lambda t, x: 1.0, 1.0, 0.0, 1.0) == 2.0
	assert candidate(lambda t, x: 2 * t, 1, 0, 2) == 5
	assert candidate(lambda t, x: 1.0, 1.0, 0.0, 2.0) == 3.0
	assert candidate(lambda t, x: 1.0, 1.0, 0.0, 0.5) == 1.5
	assert candidate(lambda t, x: 1, 1, 0, 0.5) == 1.5
	assert candidate(lambda t,x: -1, 1, 0, 1) == 0
	assert candidate(lambda t,x: 0.5, 1, 0, 1) == 1.5
	assert candidate(lambda t,x: 1, 1, 0, 1) == 2
	assert candidate(lambda t, x: 1.0, 0.0, 0.0, 1.0) == 1.0
	assert candidate(lambda t, x: 1.0, 1.0, 0.0, 0.1) == 1.1
	assert candidate(lambda t, x: 1, 0, 0, 0.5) == 0.5
	assert candidate(lambda t, x: t, 1, 0, 1) == 1.5
	assert candidate(lambda t, x: 1, 0, 0, 1) == 1.0
	assert candidate(lambda t, x: 1, 1, 0, 1) == 2
	assert candidate(lambda t, x: -1, 1, 0, 1) == 0
	assert candidate(lambda t, x: 2.0 * t, 1.0, 0.0, 1.0) == 2.0
	assert candidate(lambda t, x: 1, 1, 0, 0.75) == 1.75
	assert candidate(lambda t,x: 1, 1.0, 0.0, 1.0) == 2.0
	assert candidate(lambda t, x: 1, 1, 0, 2) == 3
	assert candidate(lambda t, x: t * x, 1, 0, 1) == 1.5
	assert candidate(lambda t, x: 1, 1, 0, 0.25) == 1.25
def test_check():
	check(heun_step)
