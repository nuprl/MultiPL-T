def update_alpha_hat(alpha,q,eta,s_hat):
    """
    Args: q, eta: scalar
          alpha, s_hat: 1d numpy array
    Return: 1d numpy array
    """
    ### Canonical solution below ###
    return alpha+q*eta*s_hat


### Unit tests below ###
def check(candidate):
	assert candidate(0,1,0,1) == 0
	assert candidate(0,0,1,0) == 0
	assert candidate(0,1,1,0) == 0
	assert candidate(1,1,0,0) == 1
	assert candidate(0, 1, 0, 0) == 0
	assert candidate(1,0,0,1) == 1
	assert candidate(0, 1, 0, 1) == 0
	assert candidate(1, 1, 0, 1) == 1
	assert candidate(1,1,0,1) == 1
	assert candidate(0,0,0,0) == 0
	assert candidate(1,0,1,0) == 1
	assert candidate(0,0,0,1) == 0
	assert candidate(1,1,1,0) == 1
	assert candidate(0,1,0,0) == 0
	assert candidate(1,0,0,0) == 1
def test_check():
	check(update_alpha_hat)
