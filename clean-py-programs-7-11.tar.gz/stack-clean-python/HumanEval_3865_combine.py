def combine(value, function, *args, **kwargs):
    """ 
     Call ``function``, return its result and ``value`` as a tuple.
     
     ``function`` is invoked with ``value``, ``*args`` and ``**kwargs`` and
     then we return a 2-tuple of whatever ``function`` returned and ``value``.
     
     Use this to add a function to a callback chain that combines its return
     value with the previous value::
     
     >>> d = defer.succeed(42)
     >>> d.addCallback(combine, lambda: 47)
     >>> d.addCallback(print)
     (37, 42)
     """
	### Canonical solution below ###    
    y = function(value, *args, **kwargs)
    return (y, value)

### Unit tests below ###
def check(candidate):
	assert candidate(42, lambda x, y: x + y, 2) == (44, 42)
	assert candidate(42, lambda x: x+1) == (43, 42)
	assert candidate(1, lambda x: 2 * x) == (2, 1)
	assert candidate(42, lambda x, y: x+y, 1) == (43, 42)
	assert candidate(1, lambda x, y: x + y, 2) == (3, 1)
	assert candidate(42, lambda x, y: x + y, 4) == (46, 42)
	assert candidate(1, lambda x: x + 1) == (2, 1)
	assert candidate(37, lambda x: x + 10) == (47, 37)
	assert candidate(2, lambda x: x-1) == (1, 2)
	assert candidate(1, lambda x, y=2: x + y) == (3, 1)
	assert candidate(3, lambda x: x + 4) == (7, 3)
	assert candidate(1, lambda x, y: x + y, 10) == (11, 1)
	assert candidate(42, lambda x, y, z, w, v: x + y + z + w + v, 10, 10, 10, 10) == (82, 42)
	assert candidate(2, lambda x, y, z: x + y + z, 10, 20) == (32, 2)
	assert candidate(10, lambda x, y: x + y, 100) == (110, 10)
	assert candidate(42, lambda x: x + 10) == (52, 42)
	assert candidate(42, lambda x: x + 1) == (43, 42)
	assert candidate(2, lambda x: x + 10) == (12, 2)
	assert candidate(2, lambda x: x**2) == (4, 2)
	assert candidate(2, lambda x: x+1) == (3, 2)
	assert candidate(42, lambda x: x + 2) == (44, 42)
	assert candidate(2, lambda x: x/2) == (1, 2)
	assert candidate(2, lambda x, y: x + y, 1) == (3, 2)
	assert candidate(1, lambda x, y=2: x + y, y=3) == (4, 1)
	assert candidate(42, lambda x: x) == (42, 42)
	assert candidate(1, lambda x, y: x + y, 3) == (4, 1)
	assert candidate(42, lambda x, y, z, w: x + y + z + w, 10, 10, 10) == (72, 42)
	assert candidate(3, lambda x: x * 2) == (6, 3)
	assert candidate(2, lambda x: x**4) == (16, 2)
	assert candidate(42, lambda x, y: x + y, 10) == (52, 42)
	assert candidate(1, lambda x, y, z: x+y+z, 2, 3) == (6, 1)
	assert candidate(2, lambda x: x**3) == (8, 2)
	assert candidate(1, lambda x, y: x + y, y=2) == (3, 1)
	assert candidate(1, lambda x, y=2: x + y, 3) == (4, 1)
	assert candidate(42, lambda x, y, z: x + y + z, z=2, y=3) == (47, 42)
	assert candidate(2, lambda x, y: x + y, y=1) == (3, 2)
	assert candidate(42, lambda x, y: x + y, y=2) == (44, 42)
	assert candidate(2, lambda x: x*2) == (4, 2)
	assert candidate(2, lambda x, y: x + y, 10) == (12, 2)
	assert candidate(10, lambda x: x + 1) == (11, 10)
	assert candidate(1, lambda x: x * 2) == (2, 1)
	assert candidate(2, lambda x: x + 1) == (3, 2)
	assert candidate(1, lambda x: x+1) == (2, 1)
	assert candidate(10, lambda x, y: x + y, y=100) == (110, 10)
	assert candidate(42, lambda x, y, z: x + y + z, 10, 10) == (62, 42)
	assert candidate(1, lambda x, y: x+y, 2) == (3, 1)
	assert candidate(42, lambda x, y, z: x+y+z, 1, 2) == (45, 42)
def test_check():
	check(combine)
