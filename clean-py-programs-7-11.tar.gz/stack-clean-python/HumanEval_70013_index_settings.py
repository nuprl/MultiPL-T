def index_settings(shards=5, replicas=2):
    """Configure an index in ES with support for text transliteration."""
    ### Canonical solution below ###
    return {
        "index": {
            "number_of_shards": str(shards),
            "number_of_replicas": str(replicas),
            # "refresh_interval": refresh,
            "analysis": {
                "analyzer": {
                    "latin_index": {
                        "tokenizer": "standard",
                        "filter": ["latinize"]
                    },
                    "icu_latin": {
                        "tokenizer": "standard",
                        "filter": ["latinize"]
                    },
                    "latin_query": {
                        "tokenizer": "standard",
                        "filter": ["latinize", "synonames"]
                    }
                },
                "normalizer": {
                    "latin_index": {
                        "type": "custom",
                        "filter": ["latinize"]
                    }
                },
                "filter": {
                    "latinize": {
                        "type": "icu_transform",
                        "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                    },
                    "synonames": {
                        "type": "synonym",
                        "lenient": "true",
                        "synonyms_path": "synonames.txt"
                    }
                }
            }
        }
    }


### Unit tests below ###
def check(candidate):
	assert candidate(shards=2, replicas=1)['index']['number_of_shards'] == '2'
	assert candidate(shards=5, replicas=2)["index"]["number_of_shards"] == "5"
	assert candidate(1, 0) == {
    "index": {
        "number_of_shards": "1",
        "number_of_replicas": "0",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(5, 1)["index"]["number_of_shards"] == "5"
	assert candidate(shards=1, replicas=1) == {
    "index": {
        "number_of_shards": "1",
        "number_of_replicas": "1",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["analyzer"]["icu_latin"]["tokenizer"] == "standard"
	assert candidate(shards=2, replicas=1)['index']['number_of_replicas'] == '1'
	assert candidate(2, 1)["index"]["number_of_shards"] == "2"
	assert candidate(shards=1, replicas=0) == {
    "index": {
        "number_of_shards": "1",
        "number_of_replicas": "0",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(shards=1, replicas=1)["index"]["number_of_shards"] == "1"
	assert candidate(2, 1)["index"]["number_of_replicas"] == "1"
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["normalizer"]["latin_index"]["type"] == "custom"
	assert candidate(shards=1) == {
    "index": {
        "number_of_shards": "1",
        "number_of_replicas": "2",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(3, 2)["index"]["number_of_shards"] == "3"
	assert candidate(1, 1)["index"]["number_of_replicas"] == "1"
	assert candidate(shards=2, replicas=1) == {
    "index": {
        "number_of_shards": "2",
        "number_of_replicas": "1",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(shards=5, replicas=2) == {
    'index': {
        'number_of_shards': '5',
        'number_of_replicas': '2',
        'analysis': {
            'analyzer': {
                'latin_index': {
                    'tokenizer':'standard',
                    'filter': ['latinize']
                },
                'icu_latin': {
                    'tokenizer':'standard',
                    'filter': ['latinize']
                },
                'latin_query': {
                    'tokenizer':'standard',
                    'filter': ['latinize','synonames']
                }
            },
            'normalizer': {
                'latin_index': {
                    'type': 'custom',
                    'filter': ['latinize']
                }
            },
            'filter': {
                'latinize': {
                    'type': 'icu_transform',
                    'id': 'Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC'  # noqa
                },
               'synonames': {
                    'type':'synonym',
                    'lenient': 'true',
                   'synonyms_path':'synonames.txt'
                }
            }
        }
    }
}
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["filter"]["latinize"]["type"] == "icu_transform"
	assert candidate(1, 0)["index"]["number_of_shards"] == "1"
	assert candidate(1, 1)["index"]["number_of_shards"] == "1"
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["analyzer"]["latin_query"]["tokenizer"] == "standard"
	assert candidate(shards=1, replicas=2)["index"]["number_of_replicas"] == "2"
	assert candidate(shards=1) == {
    "index": {
        "number_of_shards": "1",
        "number_of_replicas": "2",
        # "refresh_interval": refresh,
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(shards=5, replicas=2) == {
    "index": {
        "number_of_shards": "5",
        "number_of_replicas": "2",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["analyzer"]["icu_latin"]["filter"] == ["latinize"]
	assert candidate(shards=5, replicas=2)["index"]["number_of_replicas"] == "2"
	assert candidate(3, 0)["index"]["number_of_shards"] == "3"
	assert candidate(5, 2)["index"]["number_of_replicas"] == "2"
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["normalizer"]["latin_index"]["filter"] == ["latinize"]
	assert candidate(shards=5, replicas=2) == {
    'index': {
        'number_of_replicas': '2',
        'number_of_shards': '5',
        'analysis': {
            'analyzer': {
                'latin_index': {
                    'filter': ['latinize'],
                    'tokenizer':'standard'
                },
                'icu_latin': {
                    'filter': ['latinize'],
                    'tokenizer':'standard'
                },
                'latin_query': {
                    'filter': ['latinize','synonames'],
                    'tokenizer':'standard'
                }
            },
            'filter': {
                'latinize': {
                    'id': 'Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC',  # noqa
                    'type': 'icu_transform'
                },
               'synonames': {
                    'lenient': 'true',
                   'synonyms_path':'synonames.txt',
                    'type':'synonym'
                }
            },
            'normalizer': {
                'latin_index': {
                    'filter': ['latinize'],
                    'type': 'custom'
                }
            }
        }
    }
}
	assert candidate(shards=5, replicas=2) == {
    "index": {
        "number_of_shards": "5",
        "number_of_replicas": "2",
        # "refresh_interval": refresh,
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(5, 1)["index"]["number_of_replicas"] == "1"
	assert candidate(shards=10, replicas=2) == {
    "index": {
        "number_of_shards": "10",
        "number_of_replicas": "2",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(shards=3, replicas=1) == {
    "index": {
        "number_of_shards": "3",
        "number_of_replicas": "1",
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["analyzer"]["latin_query"]["filter"] == ["latinize", "synonames"]
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["analyzer"]["latin_index"]["tokenizer"] == "standard"
	assert candidate(3, 4)["index"]["number_of_shards"] == "3"
	assert candidate(2, 2)["index"]["number_of_replicas"] == "2"
	assert candidate(shards=5, replicas=2)["index"]["analysis"]["analyzer"]["latin_index"]["filter"] == ["latinize"]
	assert candidate(5, 2)["index"]["number_of_shards"] == "5"
	assert candidate(3, 1)["index"]["number_of_shards"] == "3"
	assert candidate(2, 2)["index"]["number_of_shards"] == "2"
	assert candidate(2, 0)["index"]["number_of_shards"] == "2"
	assert candidate(1, 0) == {
    "index": {
        "number_of_shards": "1",
        "number_of_replicas": "0",
        # "refresh_interval": refresh,
        "analysis": {
            "analyzer": {
                "latin_index": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "icu_latin": {
                    "tokenizer": "standard",
                    "filter": ["latinize"]
                },
                "latin_query": {
                    "tokenizer": "standard",
                    "filter": ["latinize", "synonames"]
                }
            },
            "normalizer": {
                "latin_index": {
                    "type": "custom",
                    "filter": ["latinize"]
                }
            },
            "filter": {
                "latinize": {
                    "type": "icu_transform",
                    "id": "Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC"  # noqa
                },
                "synonames": {
                    "type": "synonym",
                    "lenient": "true",
                    "synonyms_path": "synonames.txt"
                }
            }
        }
    }
}
	assert candidate(3, 3)["index"]["number_of_shards"] == "3"
	assert candidate(shards=2, replicas=1) == {
    'index': {
        'number_of_replicas': '1',
        'number_of_shards': '2',
        'analysis': {
            'analyzer': {
                'latin_index': {
                    'filter': ['latinize'],
                    'tokenizer':'standard'
                },
                'icu_latin': {
                    'filter': ['latinize'],
                    'tokenizer':'standard'
                },
                'latin_query': {
                    'filter': ['latinize','synonames'],
                    'tokenizer':'standard'
                }
            },
            'filter': {
                'latinize': {
                    'id': 'Any-Latin; NFKD; Lower(); [:Nonspacing Mark:] Remove; NFKC',  # noqa
                    'type': 'icu_transform'
                },
               'synonames': {
                    'lenient': 'true',
                   'synonyms_path':'synonames.txt',
                    'type':'synonym'
                }
            },
            'normalizer': {
                'latin_index': {
                    'filter': ['latinize'],
                    'type': 'custom'
                }
            }
        }
    }
}
def test_check():
	check(index_settings)
