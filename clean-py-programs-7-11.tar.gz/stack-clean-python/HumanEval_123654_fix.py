def fix(x, field):
	"""
	makes square field feels like Thor
	"""
    ### Canonical solution below ###
	a = len(field)
	if x >= a:
		return x - a
	if x < 0:
		return x + a
	return x


### Unit tests below ###
def check(candidate):
	assert candidate(2, [0, 1]) == 0
	assert candidate(3, [1, 2]) == 1
	assert candidate(1, [0, 0, 1, 0]) == 1
	assert candidate(-3, [1,2,3]) == 0
	assert candidate(1, (3, 3)) == 1
	assert candidate(4, [1,2,3]) == 1
	assert candidate(0, [1, 2, 3, 4]) == 0
	assert candidate(4, [1, 2, 3]) == 1
	assert candidate(-1, (5, 4)) == 1
	assert candidate(-1, [1, 2, 3, 4]) == 3
	assert candidate(0, [3, 3]) == 0
	assert candidate(1, (4, 4)) == 1
	assert candidate(4, [0, 1, 2]) == 1
	assert candidate(0, [0]) == 0
	assert candidate(1, [1, 2]) == 1
	assert candidate(1, (5, 4)) == 1
	assert candidate(1, [3, 3, 3]) == 1
	assert candidate(1, [0, 1]) == 1
	assert candidate(1, []) == 1
	assert candidate(-1, [0, 1]) == 1
	assert candidate(0, [3]) == 0
	assert candidate(-1, [1,2,3]) == 2
	assert candidate(-1, [1]) == 0
	assert candidate(1, [0, 1, 2]) == 1
	assert candidate(0, [1, 2, 3, 4, 5]) == 0
	assert candidate(1, [3, 3]) == 1
	assert candidate(2, [1, 2, 3]) == 2
	assert candidate(0, [3, 3, 3]) == 0
	assert candidate(5, [1, 2, 3]) == 2
	assert candidate(2, [1, 2]) == 0
	assert candidate(5, [1,2,3]) == 2
	assert candidate(-1, [1, 2]) == 1
	assert candidate(4, [3, 3, 3]) == 1
	assert candidate(1, [0, 1, 0, 0]) == 1
	assert candidate(3, [0, 1, 2]) == 0
	assert candidate(2, [0, 1, 2]) == 2
	assert candidate(3, [1, 2, 3, 4]) == 3
	assert candidate(1, (4, 3)) == 1
	assert candidate(1, [0, 0, 0, 1]) == 1
	assert candidate(-2, [1,2,3]) == 1
	assert candidate(3, [1, 2, 3]) == 0
	assert candidate(1, (2, 2)) == 1
	assert candidate(3, [3, 3, 3]) == 0
	assert candidate(5, [3, 3, 3]) == 2
	assert candidate(-3, [1, 2, 3]) == 0
	assert candidate(5, [1, 2, 3, 4]) == 1
	assert candidate(1, (1, 1)) == 1
	assert candidate(-1, (2, 2)) == 1
	assert candidate(0, []) == 0
	assert candidate(0, [1, 2]) == 0
	assert candidate(1, (5, 5)) == 1
	assert candidate(2, [3, 3, 3]) == 2
	assert candidate(-2, [1, 2]) == 0
	assert candidate(1, [1, 2, 3]) == 1
	assert candidate(-1, [1, 2, 3]) == 2
	assert candidate(-2, [1, 2, 3]) == 1
	assert candidate(1, [1, 0, 0, 0]) == 1
	assert candidate(0, [1, 2, 3]) == 0
	assert candidate(-2, [0, 1]) == 0
	assert candidate(0, [1]) == 0
	assert candidate(-1, (4, 5)) == 1
	assert candidate(0, [0, 1]) == 0
	assert candidate(1, (4, 5)) == 1
	assert candidate(0, [0, 1, 2]) == 0
	assert candidate(-1, (4, 4)) == 1
	assert candidate(1, (3, 4)) == 1
	assert candidate(2, []) == 2
	assert candidate(-1, [1, 2, 3, 4, 5]) == 4
	assert candidate(0, [3, 3, 3, 3]) == 0
	assert candidate(1, [1, 1, 1, 1]) == 1
	assert candidate(-1, [0, 1, 2]) == 2
	assert candidate(3, [0, 1]) == 1
	assert candidate(1, [3, 3, 3, 3]) == 1
	assert candidate(2, [3, 3, 3, 3]) == 2
	assert candidate(-1, (3, 4)) == 1
def test_check():
	check(fix)
