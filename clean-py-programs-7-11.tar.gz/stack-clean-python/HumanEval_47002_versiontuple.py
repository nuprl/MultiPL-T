def versiontuple(v):
    """utility for compare dot separate versions. Fills with zeros to proper number comparison
    package version will be something like 4.0.1.post11+gb3f024d.dirty-1. Where 4.0.1 is the git tag, postXX is the
    number of commits from this tag, and +XXXXXXX is the git commit short id. Total length is 16 with until 999 commits
    """
    ### Canonical solution below ###
    filled = []
    for point in v.split("."):
        filled.append(point.zfill(16))
    return tuple(filled)


### Unit tests below ###
def check(candidate):
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0.post11+gb3f024d.dirty-1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") < candidate("4.0.1.post11+gb3f024d.dirty-2")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0.post11")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0")
	assert candidate("4.0.1") < candidate("4.0.1.post1")
	assert candidate("4.0.1.post11+gb3f024d.dirty-101") < candidate(
    "4.0.1.post11+gb3f024d.dirty-102")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-2") < candidate("4.0.1.post11+gb3f024d.dirty-10")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post11+gb3f024d.1")
	assert candidate("4.0.1") < candidate("4.0.2")
	assert candidate("4.0.1") < candidate("5.0.0")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0.post11+gb3f024d-1.post1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0.post11+gb3f024d-1.post11")
	assert candidate("4.0.1") < candidate(
    "4.0.1.post11+gb3f024d.dirty-1")
	assert candidate("4.0.1") < candidate("6.0.0")
	assert candidate("4.0.1.post11+gb3f024d.dirty-100") < candidate(
    "4.0.1.post11+gb3f024d.dirty-101")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post11+gb3f024d.2-1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post11+gb3f024d")
	assert candidate("4.0.1.post11+gb3f024d.dirty-2") < candidate(
    "4.0.1.post11+gb3f024d.dirty-10")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-10") < candidate("4.0.1.post12+gb3f024d.dirty-10")
	assert candidate("4.0.1.post11+gb3f024d.dirty-1") < candidate(
    "4.0.1.post11+gb3f024d.dirty-2")
	assert candidate("4.0.1") < candidate("4.0.1.post11")
	assert candidate("4.0.1.post11") < candidate("4.0.1.post12")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0.post11+gb3f024d-1")
	assert candidate("4.0.1") < candidate("5.1.0")
	assert candidate("4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post11+gb3f024d.dirty-0")
	assert candidate("4.0.1") > candidate("3.0.1.post11+gb3f024d-1")
	assert candidate("4.0.1") < candidate("5.0.1")
	assert candidate("4.0.1.post1") < candidate("4.0.1.post11")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0.post11+gb3f024d")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") < candidate("4.0.1.post12+gb3f024d.dirty-1")
	assert candidate("4.0.1.post11") > candidate("4.0.1.post10")
	assert candidate(v="4.0.1.post11+gb3f024d.dirty-1") > candidate(v="4.0.1.post10+gb3f024d.dirty-1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post11+gb3f024d.dirty-0")
	assert candidate("4.0.1.post11+gb3f024d.dirty-1") < candidate(
    "4.0.1.post12+gb3f024d.dirty-1")
	assert candidate("4.0.1") < candidate("4.1.0")
	assert candidate("4.0.1.post10") > candidate("4.0.1.post9")
	assert candidate(
    "4.0.1") < candidate("4.0.2")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") < candidate("4.0.1.post12+gb3f024d-0")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post11+gb3f024d.10-1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") == candidate("4.0.1.post11+gb3f024d.dirty-1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.0.post1")
	assert candidate("4.0.1.post9") > candidate("4.0.1.dev1")
	assert candidate("4.0.1.dev1") > candidate("4.0.1.dev0")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") < candidate("4.0.1.post12+gb3f024d.dirty-0")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") < candidate("4.0.1.post12+gb3f024d-1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") < candidate("4.0.1.post12+gb3f024c-1")
	assert candidate(v="4.0.1.post11+gb3f024d.dirty-1") > candidate(v="4.0.1.post11+gb3f024d.dirty-0")
	assert candidate("4.0.1.post11+gb3f024d.dirty-1") < candidate(
    "4.0.1.post11+gb3f024d.dirty-100")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post11+gb3f024d.1-1")
	assert candidate(
    "4.0.1.post11+gb3f024d.dirty-1") > candidate("4.0.1.post1")
def test_check():
	check(versiontuple)
