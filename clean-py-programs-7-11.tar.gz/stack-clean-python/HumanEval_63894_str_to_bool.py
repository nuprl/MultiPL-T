def str_to_bool(parameter):
    """ 
     Utility for converting a string to its boolean equivalent.
     """
	### Canonical solution below ###    
    if isinstance(parameter, bool):
        return parameter
    if parameter.lower() in {'false', 'f', '0', 'no', 'n'}:
        return False
    elif parameter.lower() in {'true', 't', '1', 'yes', 'y'}:
        return True
    raise ValueError(f'"{parameter}" is not a valid boolean value.')

### Unit tests below ###
def check(candidate):
	assert candidate("no") == False
	assert candidate('T') == True
	assert candidate('true') is True
	assert candidate('1') == True
	assert candidate("t") == True
	assert candidate('YES') == True
	assert candidate('n') is False
	assert candidate(True) is True
	assert not candidate('0')
	assert candidate('f') == False
	assert candidate('0') is False
	assert candidate('false') is False
	assert candidate('y') is True
	assert candidate("TRUE") == True
	assert candidate('NO') is False
	assert candidate('T') is True
	assert candidate('F') == False
	assert candidate('Y') is True
	assert candidate("1") == True
	assert candidate('t')
	assert candidate('No') is False
	assert candidate("n") == False
	assert candidate('N') is False
	assert candidate("0") == False
	assert not candidate('no')
	assert candidate('f') is False
	assert candidate("yes") == True
	assert candidate('nO') is False
	assert candidate('t') == True
	assert candidate('YES') is True
	assert candidate('y') == True
	assert candidate('Y') == True
	assert not candidate('FALSE')
	assert candidate('yes') is True
	assert candidate('false') == False
	assert candidate('YeS') is True
	assert not candidate('NO')
	assert candidate('no') == False
	assert candidate("FALSE") == False
	assert candidate('Yes') is True
	assert candidate('False') is False
	assert candidate('N') == False
	assert not candidate('False')
	assert candidate('n') == False
	assert not candidate('N')
	assert candidate('0') == False
	assert candidate('No') == False
	assert candidate('True') is True
	assert candidate('1') is True
	assert candidate(False) == False
	assert candidate("false") == False
	assert candidate('True') == True
	assert candidate("f") == False
	assert candidate('FALSE') == False
	assert candidate('F') is False
	assert candidate('Yes') == True
	assert candidate('False') == False
	assert candidate('no') is False
	assert candidate("T") == True
	assert candidate('y')
	assert candidate("y") == True
	assert candidate(True) == True
	assert candidate("False") == False
	assert candidate("true") == True
	assert candidate('TRUE') is True
	assert candidate("True") == True
	assert candidate('TRUE') == True
	assert not candidate('F')
	assert candidate('yes')
	assert candidate('FALSE') is False
	assert candidate(True)
	assert candidate('true')
	assert candidate('yes') == True
	assert candidate("F") == False
	assert candidate('NO') == False
	assert candidate('true') == True
	assert candidate('t') is True
	assert candidate(False) is False
	assert not candidate('n')
def test_check():
	check(str_to_bool)
