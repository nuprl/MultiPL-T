def _get_regular_HIP_name(name):
    """Convert an HIP name in *Hipparcos Catalogue* to its regular form
    `"HIP NNN"`.

    Args:
        name (str or int): Name or HIP number of a star (e.g. `"HIP8276"`,
            `"HIP 8276"`, `8443`).
    Returns:
        str: Regular HD name `"HIP NNNN"`.
    See also:
        * :ref:`catalog_hip`
    """
    ### Canonical solution below ###

    if isinstance(name, str):
        name = name.strip()
        if name[-1].isalpha():
            comp = name[-1]
            return 'HIP %d %s'%(int(name[3:-1]), comp)
        else:
            return 'HIP %d'%(int(name[3:]))
    elif isinstance(name, int):
        return 'HIP %d'%name
    else:
        raise ValueError


### Unit tests below ###
def check(candidate):
	assert candidate('HIP 8443 B') == 'HIP 8443 B'
	assert candidate('HIP 8276 b ') == 'HIP 8276 b'
	assert candidate('HIP8276b') == 'HIP 8276 b'
	assert candidate('HIP8276') == 'HIP 8276'
	assert candidate('HIP 8276D') == 'HIP 8276 D'
	assert candidate('HIP 0008276') == 'HIP 8276'
	assert candidate('HIP 8276F') == 'HIP 8276 F'
	assert candidate('HIP 8276 b') == 'HIP 8276 b'
	assert candidate('HIP 008276') == 'HIP 8276'
	assert candidate('  HIP  8276') == 'HIP 8276'
	assert candidate('HIP 8276a') == 'HIP 8276 a'
	assert candidate('HIP 8276B') == 'HIP 8276 B'
	assert candidate('HIP 8276 D') == 'HIP 8276 D'
	assert candidate('HIP 8276G') == 'HIP 8276 G'
	assert candidate('HIP 8276 C') == 'HIP 8276 C'
	assert candidate('HIP 8443A') == 'HIP 8443 A'
	assert candidate('HIP 8276 c') == 'HIP 8276 c'
	assert candidate('HIP 8276 e') == 'HIP 8276 e'
	assert candidate('HIP 8276 A') == 'HIP 8276 A'
	assert candidate('HIP 100000000') == 'HIP 100000000'
	assert candidate('HIP 8276b ') == 'HIP 8276 b'
	assert candidate('HIP 8276 ') == 'HIP 8276'
	assert candidate('HIP 8443B') == 'HIP 8443 B'
	assert candidate('HIP 8276H') == 'HIP 8276 H'
	assert candidate('HIP 8276 c') == candidate('HIP8276c')
	assert candidate(8276) == candidate('HIP8276')
	assert candidate('HIP 8276 E') == 'HIP 8276 E'
	assert candidate(8276) == 'HIP 8276'
	assert candidate(8276) == candidate('HIP 8276')
	assert candidate('HIP 8276C') == 'HIP 8276 C'
	assert candidate('HIP 008443b') == 'HIP 8443 b'
	assert candidate('HIP 8276 f') == 'HIP 8276 f'
	assert candidate(' HIP 8276 ') == 'HIP 8276'
	assert candidate(100000000) == 'HIP 100000000'
	assert candidate('HIP 8443') == 'HIP 8443'
	assert candidate('HIP 8276E') == 'HIP 8276 E'
	assert candidate('HIP 8276 B') == candidate('HIP8276B')
	assert candidate('HIP8276 A') == 'HIP 8276 A'
	assert candidate(8443) == 'HIP 8443'
	assert candidate('HIP8443') == 'HIP 8443'
	assert candidate('HIP 8443 b') == 'HIP 8443 b'
	assert candidate('HIP 8276') == candidate('HIP8276')
	assert candidate('HIP8443b') == 'HIP 8443 b'
	assert candidate('HIP 8443a') == 'HIP 8443 a'
	assert candidate('HIP8276A') == 'HIP 8276 A'
	assert candidate('HIP 8276 B') == 'HIP 8276 B'
	assert candidate(' HIP 8276 B') == 'HIP 8276 B'
	assert candidate('HIP 8276') == 'HIP 8276'
	assert candidate('HIP 8276b') == 'HIP 8276 b'
	assert candidate('HIP 8443 C') == 'HIP 8443 C'
	assert candidate('HIP 8276A') == 'HIP 8276 A'
	assert candidate('HIP 8443 b ') == 'HIP 8443 b'
	assert candidate('HIP 8276 b') == candidate('HIP8276b')
	assert candidate('HIP 8443 A') == 'HIP 8443 A'
	assert candidate('HIP 8276 d') == 'HIP 8276 d'
	assert candidate('HIP 08276') == 'HIP 8276'
def test_check():
	check(_get_regular_HIP_name)
