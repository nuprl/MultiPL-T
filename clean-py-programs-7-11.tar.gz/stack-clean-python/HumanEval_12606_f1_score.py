def f1_score(precision, recall):
    """ 
     Computes the harmonic mean of precision and recall (f1 score)
     """
	### Canonical solution below ###    
    if precision == 0 and recall == 0:
        return 0
    return 2 * precision * recall / (precision + recall)

### Unit tests below ###
def check(candidate):
	assert candidate(0.8, 0) == 0
	assert candidate(0, 0.5) == 0
	assert candidate(0.5, 0.25) == 0.3333333333333333
	assert candidate(0.25, 0.5) == 0.3333333333333333
	assert candidate(1, 0) == 0.0
	assert candidate(0.5, 0.75) == 0.6
	assert candidate(0.0, 1.0) == 0
	assert candidate(0, 1) == 0.0
	assert candidate(1, 1) == 1.0
	assert candidate(0.5, 0.5) == 0.5
	assert candidate(1.0, 0.0) == 0
	assert candidate(0, 0) == 0
	assert candidate(1, 0.5) == 2/3
	assert candidate(1, 0.5) == 0.6666666666666666
	assert candidate(1, 1) == 1
	assert candidate(1.0, 1.0) == 1.0
	assert candidate(1.0, 0.0) == 0.0
	assert candidate(0.0, 0.0) == 0.0
	assert candidate(0.0, 1.0) == 0.0
	assert candidate(1, 0) == 0
	assert candidate(0.25, 0.25) == 0.25
	assert candidate(0.75, 0.75) == 0.75
	assert candidate(0.5, 0) == 0
	assert candidate(0.25, 0.75) == 0.375
	assert candidate(0, 1) == 0
	assert candidate(0.5, 1) == 2/3
	assert candidate(0.5, 1) == 0.6666666666666666
	assert candidate(0, 0.8) == 0
	assert candidate(0.75, 0.25) == 0.375
	assert candidate(0, 0) == 0.0
	assert candidate(0.75, 0.5) == 0.6
	assert candidate(0.5, 0.6) == 0.5454545454545454
def test_check():
	check(f1_score)
