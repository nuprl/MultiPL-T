def check_filename_by_pattern(filename, include=None, exclude=None):
    """Check whether filename contain specific pattern.

    Parameters
    ----------
    filename : str
        Filename to be checked.

    include : list
        List of allowed patterns.

    exclude : list
        List of not allowed patterns.

    Returns
    -------
    bool
        True if filename contains any pattern from include list, False if
        filename contains any pattern from exclude list.

    """
    ### Canonical solution below ###
    assert not (include is not None and exclude is not None)
    if include is not None:
        if any([i.lower() in filename.lower() for i in include]) is False:
            return False

    if exclude is not None:
        if any([e.lower() in filename.lower() for e in exclude]) is False:
            return False

    return True


### Unit tests below ###
def check(candidate):
	assert candidate(
    '190626_181513_000.jpg',
    include=['.jpg']) is True
	assert candidate(
    filename='test.nii.gz', exclude=['nii', 'gz'])
	assert candidate(
    'file.txt',
    include=['.jpg']
) is False
	assert candidate(
    '2015-08-01_10-10-10_C00012345678_D00000000001_S0001_E0001_I00001_B0001_V0001.dcm',
    exclude=['dcm', 'D00000000001', 'I00001', 'B0001', 'V0001']) is True
	assert candidate(
    filename='test.nii.gz', include=['nii'])
	assert not candidate(filename='file.txt', include=['png'])
	assert candidate(
    "test.nii.gz", exclude=[".nii"]) is True
	assert candidate(filename='filename.txt',
                                 include=['txt'])
	assert candidate(
    "test_file.txt", include=["txt"]) is True
	assert candidate(
    'file.txt',
    include=['.txt']
) is True
	assert candidate(
    '190626_181513_000.jpg',
    include=['.jpg', '.png']) is True
	assert candidate(
    "my_file.txt",
    include=None,
    exclude=["*.zip"]
) is False
	assert candidate(
    filename='image.jpg',
    include=['.png'],
    exclude=None
) is False
	assert candidate(
    'test.nii.gz', exclude=['*.nii.gz']) is False
	assert candidate(filename='test.txt', include=['.txt'])
	assert candidate(filename='test', include=['te'], exclude=None)
	assert candidate(filename='test.txt', include=['.txt', '.csv'])
	assert candidate(
    "test_file.txt", include=["csv"]) is False
	assert not candidate(
    'file.txt', include=['*.csv'])
	assert candidate(
    'test.nii', include=['.txt']) == False
	assert candidate(
    'file.txt',
    include=['.dat']) is False
	assert candidate(filename='test', include=['test'])
	assert candidate(
    'test.nii', include=['.nii']) == True
	assert candidate(
    'file.nii', include=['.nii.gz']) is False
	assert not candidate(filename='filename.txt',
                                     include=['csv'])
	assert candidate(filename='file.txt', include=['txt'])
	assert candidate(
    filename='image.jpg',
    include=['.jpg'],
    exclude=None
) is True
	assert candidate(filename='test', exclude=['test'])
	assert candidate(
    'file.nii', include=['.nii']) is True
	assert candidate(filename="file.txt", include=[".txt"]) is True
	assert candidate(
    '2015-08-01_10-10-10_C00012345678_D00000000001_S0001_E0001_I00001_B0001_V0001.dcm',
    include=['dcm', 'D00000000001']) is True
	assert candidate(
    'test.txt', include=['.txt']) == True
	assert candidate(
    filename='file.txt', include=['.txt'], exclude=None) is True
	assert candidate(
    'test.txt', include=['.txt']) is True
	assert candidate(
    filename='test.txt', include=['.csv']) == False
	assert candidate(
    filename='test.nii.gz', include=['gz'])
	assert candidate(
    "file.txt", exclude=["file", ".jpg"]) is True
	assert candidate(
    filename='test.txt', include=['.txt']) == True
	assert candidate(
    'test.txt', include=['.py']) == False
	assert candidate(
    'a.txt', include=['.txt']
)
	assert candidate(
    'test.nii', include=['.nii', '.txt']) == True
	assert candidate(filename="file.txt", include=[".pdf"]) is False
	assert candidate(
    filename='test.nii.gz', exclude=['nii'])
	assert candidate(
    'test.txt', include=['.txt', 'txt']) is True
	assert candidate(
    'hello_world.txt',
    exclude=['world']
) == True
	assert candidate(
    "filename.nii.gz", include=[".nii.gz"]
) is True
	assert not candidate(
    'file.txt', exclude=['*.txt'])
	assert candidate(
    filename='file.txt', include=['.txt', '.png'], exclude=None) is True
	assert candidate(
    'test.txt', include=['txt']) is True
	assert candidate(
    'file.txt',
    include=['.txt']) is True
	assert candidate(
    filename='test.nii.gz', exclude=['gz'])
	assert candidate(
    '190626_181513_000.jpg',
    include=['.png']) is False
	assert candidate(
    filename='image.jpg',
    include=['.jpg', '.png'],
    exclude=None
) is True
	assert candidate(
    "test.nii.gz", include=[".nii", ".nii.gz"]) is True
	assert candidate(
    "filename.nii.gz", exclude=[".nii"]
) is True
	assert candidate(
    filename='test.nii.gz', include=['nii', 'gz'])
	assert candidate(
    "my_file.txt",
    include=None,
    exclude=None
) is True
def test_check():
	check(check_filename_by_pattern)
