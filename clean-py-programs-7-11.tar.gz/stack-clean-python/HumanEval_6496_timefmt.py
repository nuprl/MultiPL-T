def timefmt(thenumber):
    """ 
     
     Parameters
     ----------
     thenumber
     
     Returns
     -------
     
     """
	### Canonical solution below ###    
    return "{:10.2f}".format(thenumber)

### Unit tests below ###
def check(candidate):
	assert candidate(1000000000000.0)
	assert candidate(1234567890.12345678901234) == '1234567890.12'
	assert candidate(1) == "      1.00"
	assert candidate(12345670000.0) == '12345670000.00'
	assert candidate(1000000000000) == "1000000000000.00"
	assert candidate(0) == "      0.00"
	assert candidate(12345.6789) == "  12345.68"
	assert candidate(123.456789) == "    123.46"
	assert candidate(1234567000.0) == '1234567000.00'
	assert candidate(0.1) == "      0.10"
	assert candidate(1234567890.123456) == '1234567890.12'
	assert candidate(1000000.123456) == "1000000.12"
	assert candidate(1000000000) == "1000000000.00"
	assert candidate(10.123456789) == "     10.12"
	assert candidate(12345678) == '12345678.00'
	assert candidate(1234567.0) == "1234567.00"
	assert candidate(12345.67) =='  12345.67'
	assert candidate(100.123456) == "    100.12"
	assert candidate(1234567890.1234567) == '1234567890.12'
	assert candidate(1234567.89) == "1234567.89"
	assert candidate(1234567890.123456789012) == '1234567890.12'
	assert candidate(1234.567) == "   1234.57"
	assert candidate(0.123456789) == "      0.12"
	assert candidate(1234567890.1234567890123) == '1234567890.12'
	assert candidate(10000000) == "10000000.00"
	assert candidate(12345670.0) == '12345670.00'
	assert candidate(100000000000) == "100000000000.00"
	assert candidate(0.000000001) == "      0.00"
	assert candidate(1234567890.12345678901) == '1234567890.12'
	assert candidate(1234567890.1234567890) == '1234567890.12'
	assert candidate(100000000) == "100000000.00"
	assert candidate(123456.7) ==' 123456.70'
	assert candidate(1234567890.123456789) == '1234567890.12'
	assert candidate(12345) =='  12345.00'
	assert candidate(1234567.0) =='1234567.00'
	assert candidate(123456700.0) == '123456700.00'
	assert candidate(123456789.0) == "123456789.00"
	assert candidate(12345678.0) == "12345678.00"
	assert candidate(10000000000000) == "10000000000000.00"
	assert candidate(1234567890.12345678) == '1234567890.12'
	assert candidate(10.123456) == "     10.12"
	assert candidate(0.0000001) == "      0.00"
	assert candidate(10000000000) == "10000000000.00"
def test_check():
	check(timefmt)
