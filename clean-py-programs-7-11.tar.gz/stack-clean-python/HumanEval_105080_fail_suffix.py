def fail_suffix(i):
  """Filename suffix for the ith failing file"""
    ### Canonical solution below ###
  if i == 0:
    return '_fail'
  else:
    return '_fail_' + str(i+1)


### Unit tests below ###
def check(candidate):
	assert candidate(18) == '_fail_19'
	assert candidate(5) == '_fail_6'
	assert candidate(12) == '_fail_13'
	assert candidate(2) == '_fail_3'
	assert candidate(3) == '_fail_4'
	assert candidate(16) == '_fail_17'
	assert candidate(13) == '_fail_14'
	assert candidate(20) == '_fail_21'
	assert candidate(7) == '_fail_8'
	assert candidate(100) == '_fail_101'
	assert candidate(6) == '_fail_7'
	assert candidate(21) == '_fail_22'
	assert candidate(23) == '_fail_24'
	assert candidate(1234) == '_fail_1235'
	assert candidate(123) == '_fail_124'
	assert candidate(17) == '_fail_18'
	assert candidate(24) == '_fail_25'
	assert candidate(15) == '_fail_16'
	assert candidate(0) == '_fail'
	assert candidate(8) == '_fail_9'
	assert candidate(19) == '_fail_20'
	assert candidate(14) == '_fail_15'
	assert candidate(25) == '_fail_26'
	assert candidate(1) == '_fail_2'
	assert candidate(4) == '_fail_5'
	assert candidate(10) == '_fail_11'
	assert candidate(9) == '_fail_10'
	assert candidate(11) == '_fail_12'
	assert candidate(22) == '_fail_23'
def test_check():
	check(fail_suffix)
