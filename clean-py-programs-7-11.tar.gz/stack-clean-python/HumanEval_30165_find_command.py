def find_command(command, all_commands):
    """ 
     Looks up a command in a list of dictioraries, returns a dictionary from a list
     
     :param command: Command to look up
     :param all_commands: list of all commands
     :return: dictionary
     """
	### Canonical solution below ###    
    for item in all_commands:
        if item["command"] == command:
            return item

### Unit tests below ###
def check(candidate):
	assert candidate(command="test1", all_commands=[{"command": "test", "message": "This is a test"}]) == None
	assert candidate(
    "command_1", [
        {"command": "command_1", "description": "command_1"},
        {"command": "command_2", "description": "command_2"},
        {"command": "command_3", "description": "command_3"}
    ]
) == {"command": "command_1", "description": "command_1"}
	assert candidate(
    "ping",
    [
        {
            "command": "ping",
            "description": "Ping the bot",
            "syntax": "",
            "function": "ping",
        }
    ]
)["description"] == "Ping the bot"
	assert candidate(
    "get-route-map",
    [
        {
            "command": "get-route-map",
            "arguments": [
                {"name": "route-map", "optional": False},
                {"name": "filter", "optional": True},
            ],
        },
        {"command": "set-route-map", "arguments": [{"name": "route-map", "optional": False}]},
    ],
) == {
    "command": "get-route-map",
    "arguments": [
        {"name": "route-map", "optional": False},
        {"name": "filter", "optional": True},
    ],
}
	assert candidate(
    "set_timer",
    [
        {
            "command": "set_alarm",
            "description": "Set an alarm",
            "arguments": {
                "time": "HH:MM",
                "message": "A message to include in the alarm"
            }
        },
        {
            "command": "set_timer",
            "description": "Set a timer",
            "arguments": {
                "time": "HH:MM",
                "message": "A message to include in the alarm"
            }
        },
    ]
) == {
    "command": "set_timer",
    "description": "Set a timer",
    "arguments": {
        "time": "HH:MM",
        "message": "A message to include in the alarm"
    }
}
	assert candidate(
    "help",
    [
        {"command": "help", "response": "displays this help text"},
        {"command": "ping", "response": "pong!"},
    ],
) == {"command": "help", "response": "displays this help text"}
	assert candidate(
    "get-route-map",
    [
        {
            "command": "get-route-map",
            "arguments": [
                {"name": "route-map", "optional": False},
                {"name": "filter", "optional": True},
            ],
        }
    ],
) == {
    "command": "get-route-map",
    "arguments": [
        {"name": "route-map", "optional": False},
        {"name": "filter", "optional": True},
    ],
}
	assert candidate(
    "ls",
    [
        {"command": "ls", "description": "list files"},
        {"command": "pwd", "description": "print working directory"},
        {"command": "echo", "description": "display a line of text"},
    ]
) == {"command": "ls", "description": "list files"}
	assert candidate(
    "pwd",
    [
        {"command": "ls", "description": "list files"},
        {"command": "pwd", "description": "print working directory"},
        {"command": "echo", "description": "display a line of text"},
    ]
) == {"command": "pwd", "description": "print working directory"}
	assert candidate(command="test", all_commands=[{"command": "test", "message": "This is a test"}]) == {"command": "test", "message": "This is a test"}
	assert candidate(
    "test",
    [
        {"command": "run", "description": "Run the application"},
        {"command": "test", "description": "Run tests"},
    ],
) == {"command": "test", "description": "Run tests"}
	assert candidate(
    "command_a", [
        {
            "command": "command_a",
            "description": "description_a",
            "arguments": [
                {
                    "name": "argument_a",
                    "description": "description_a",
                    "type": "string",
                    "default": "default_a"
                },
                {
                    "name": "argument_b",
                    "description": "description_b",
                    "type": "integer",
                    "default": "default_b"
                }
            ]
        },
        {
            "command": "command_b",
            "description": "description_b",
            "arguments": [
                {
                    "name": "argument_a",
                    "description": "description_a",
                    "type": "string",
                    "default": "default_a"
                },
                {
                    "name": "argument_b",
                    "description": "description_b",
                    "type": "integer",
                    "default": "default_b"
                }
            ]
        }
    ]
) == {
    "command": "command_a",
    "description": "description_a",
    "arguments": [
        {
            "name": "argument_a",
            "description": "description_a",
            "type": "string",
            "default": "default_a"
        },
        {
            "name": "argument_b",
            "description": "description_b",
            "type": "integer",
            "default": "default_b"
        }
    ]
}
	assert candidate(
    "hello", [{"command": "hello", "description": "Say hello"}, {"command": "world", "description": "Say world"}]
)!= {"command": "world", "description": "Say world"}
	assert candidate(
    "ping",
    [
        {
            "command": "ping",
            "description": "Ping the bot",
            "syntax": "",
            "function": "ping",
        }
    ]
)["function"] == "ping"
	assert candidate("test_command", []) == None, "Should return None"
	assert candidate(command="restart", all_commands=[{"command": "start", "description": "Starts the service"}, {"command": "stop", "description": "Stops the service"}]) == None
	assert candidate(command="test", all_commands=[{"command": "test"}, {"command": "test2"}]) == {"command": "test"}
	assert candidate(
    "foo",
    [
        {"command": "help", "response": "displays this help text"},
        {"command": "ping", "response": "pong!"},
    ],
) is None
	assert candidate(
    "start",
    [
        {"command": "start", "response": "Starting!"},
        {"command": "stop", "response": "Stopping!"},
    ]
) == {
    "command": "start",
    "response": "Starting!"
}
	assert candidate(
    "delete",
    [
        {"command": "create", "description": "Create a new file"},
        {"command": "delete", "description": "Delete a file"},
    ],
) == {"command": "delete", "description": "Delete a file"}
	assert candidate(
    "command_2", [
        {"command": "command_1", "description": "command_1"},
        {"command": "command_2", "description": "command_2"},
        {"command": "command_3", "description": "command_3"}
    ]
) == {"command": "command_2", "description": "command_2"}
	assert candidate(
    "set_alarm",
    [
        {
            "command": "set_alarm",
            "description": "Set an alarm",
            "arguments": {
                "time": "HH:MM",
                "message": "A message to include in the alarm"
            }
        },
        {
            "command": "set_timer",
            "description": "Set a timer",
            "arguments": {
                "time": "HH:MM",
                "message": "A message to include in the alarm"
            }
        },
    ]
) == {
    "command": "set_alarm",
    "description": "Set an alarm",
    "arguments": {
        "time": "HH:MM",
        "message": "A message to include in the alarm"
    }
}
	assert candidate("ping", []) == None
	assert candidate(
    "echo",
    [
        {"command": "ls", "description": "list files"},
        {"command": "pwd", "description": "print working directory"},
        {"command": "echo", "description": "display a line of text"},
    ]
) == {"command": "echo", "description": "display a line of text"}
	assert candidate(
    "quit",
    [
        {"command": "help", "description": "Shows this help message"},
        {"command": "quit", "description": "Exits the game"},
    ],
) == {"command": "quit", "description": "Exits the game"}
	assert candidate(
    "show ip arp", [
        {
            "command": "show ip arp",
            "expected": "show ip arp"
        },
        {
            "command": "show ip arp",
            "expected": "show ip arp"
        },
        {
            "command": "show ip arp",
            "expected": "show ip arp"
        }
    ]
) == {
    "command": "show ip arp",
    "expected": "show ip arp"
}
	assert candidate("command1", [{"command": "command1", "action": "action1"}])["action"] == "action1"
	assert candidate(
    "ping",
    [
        {
            "command": "ping",
            "description": "Ping the bot",
            "syntax": "",
            "function": "ping",
        }
    ]
)["syntax"] == ""
	assert candidate(
    "create",
    [
        {"command": "create", "description": "Create a new file"},
        {"command": "delete", "description": "Delete a file"},
    ],
) == {"command": "create", "description": "Create a new file"}
	assert candidate(command="stop", all_commands=[{"command": "start", "description": "Starts the service"}, {"command": "stop", "description": "Stops the service"}]) == {"command": "stop", "description": "Stops the service"}
	assert candidate(
    "test_command",
    [
        {"command": "test_command", "description": "test_description"},
        {"command": "another_test_command", "description": "another_test_description"},
    ],
) == {"command": "test_command", "description": "test_description"}, "Should return test_command"
	assert candidate(
    "hello", [{"command": "hello", "description": "Say hello"}, {"command": "world", "description": "Say world"}]
)!= {"command": "test", "description": "Say test"}
	assert candidate(
    "command_4", [
        {"command": "command_1", "description": "command_1"},
        {"command": "command_2", "description": "command_2"},
        {"command": "command_3", "description": "command_3"}
    ]
) is None
	assert candidate(
    "hello",
    [{"command": "hello", "description": "Says hello"},
     {"command": "help", "description": "Shows the help menu"},
     {"command": "quit", "description": "Exits the program"}]) == \
    {"command": "hello", "description": "Says hello"}
	assert candidate(
    "set_colour",
    [
        {
            "command": "set_brightness",
            "description": "Set the brightness of the display",
        },
        {
            "command": "set_contrast",
            "description": "Set the contrast of the display",
        },
    ]
) is None
	assert candidate(
    "cat",
    [
        {"command": "ls", "description": "list files"},
        {"command": "pwd", "description": "print working directory"},
        {"command": "echo", "description": "display a line of text"},
    ]
) is None
	assert candidate(command="test", all_commands=[{"command": "test2"}, {"command": "test"}]) == {"command": "test"}
	assert candidate(command="start", all_commands=[{"command": "start", "description": "Starts the service"}, {"command": "stop", "description": "Stops the service"}]) == {"command": "start", "description": "Starts the service"}
	assert candidate(
    "ping",
    [
        {"command": "help", "response": "displays this help text"},
        {"command": "ping", "response": "pong!"},
    ],
) == {"command": "ping", "response": "pong!"}
	assert candidate(
    "set_brightness",
    [
        {
            "command": "set_brightness",
            "description": "Set the brightness of the display",
        },
        {
            "command": "set_contrast",
            "description": "Set the contrast of the display",
        },
    ]
) == {
    "command": "set_brightness",
    "description": "Set the brightness of the display",
}
	assert candidate(
    "restart",
    [
        {"command": "start", "response": "Starting!"},
        {"command": "stop", "response": "Stopping!"},
    ]
) is None
	assert candidate(
    "stop",
    [
        {"command": "start", "response": "Starting!"},
        {"command": "stop", "response": "Stopping!"},
    ]
) == {
    "command": "stop",
    "response": "Stopping!"
}
	assert candidate("update", [
    {"command": "create", "description": "Create a new file"},
    {"command": "delete", "description": "Delete a file"},
]) is None
	assert candidate(
    "hello", [{"command": "hello", "description": "Say hello"}, {"command": "world", "description": "Say world"}]
) == {"command": "hello", "description": "Say hello"}
	assert candidate(
    "ping",
    [
        {
            "command": "ping",
            "description": "Returns Pong!",
            "usage": "!ping",
            "aliases": ["pong"],
        },
        {
            "command": "pong",
            "description": "Returns Ping!",
            "usage": "!pong",
            "aliases": ["ping"],
        },
    ],
) == {
    "command": "ping",
    "description": "Returns Pong!",
    "usage": "!ping",
    "aliases": ["pong"],
}
	assert candidate(
    "run",
    [
        {"command": "run", "description": "Run the application"},
        {"command": "test", "description": "Run tests"},
    ],
) == {"command": "run", "description": "Run the application"}
	assert candidate(1234, []) is None
	assert candidate(
    "command_3", [
        {"command": "command_1", "description": "command_1"},
        {"command": "command_2", "description": "command_2"},
        {"command": "command_3", "description": "command_3"}
    ]
) == {"command": "command_3", "description": "command_3"}
	assert candidate(
    "add",
    [
        {
            "command": "add",
            "description": "Adds two numbers together",
            "usage": "add <number> <number>",
        },
        {
            "command": "subtract",
            "description": "Subtracts one number from another",
            "usage": "subtract <number> <number>",
        },
    ],
) == {
    "command": "add",
    "description": "Adds two numbers together",
    "usage": "add <number> <number>",
}
	assert candidate(
    "subtract",
    [
        {
            "command": "add",
            "description": "Adds two numbers together",
            "usage": "add <number> <number>",
        },
        {
            "command": "subtract",
            "description": "Subtracts one number from another",
            "usage": "subtract <number> <number>",
        },
    ],
) == {
    "command": "subtract",
    "description": "Subtracts one number from another",
    "usage": "subtract <number> <number>",
}
	assert candidate(
    "ping",
    [
        {"command": "ping", "description": "Ping a device"},
        {"command": "ssh", "description": "Connect via SSH"},
    ],
) == {"command": "ping", "description": "Ping a device"}
	assert candidate(command="test", all_commands=[{"command": "test"}]) == {"command": "test"}
	assert candidate(
    "set_contrast",
    [
        {
            "command": "set_brightness",
            "description": "Set the brightness of the display",
        },
        {
            "command": "set_contrast",
            "description": "Set the contrast of the display",
        },
    ]
) == {
    "command": "set_contrast",
    "description": "Set the contrast of the display",
}
	assert candidate(
    "help",
    [
        {"command": "help", "description": "Shows this help message"},
        {"command": "quit", "description": "Exits the game"},
    ],
) == {"command": "help", "description": "Shows this help message"}
def test_check():
	check(find_command)
