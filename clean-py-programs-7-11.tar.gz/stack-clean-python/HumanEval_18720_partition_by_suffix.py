def partition_by_suffix(iterable, func):
    """ Given an iterable and a boolean-valued function which takes in 
     elements of that iterable, outputs a list of lists, where each list 
     ends in an element for which the func returns true, (except for the 
     last one)		
     e.g. 
     iterable := [1, 2, 3, 4, 5,5, 5]
     func := lambda x: (x % 2) == 0
     returns [[1,2], [3,4], [5, 5, 5]]
     """
	### Canonical solution below ###	
	output = [] 
	sublist = [] 
	for el in iterable:
		sublist.append(el)
		if func(el):
			output.append(sublist)
			sublist = []

	if len(sublist) > 0:
		output.append(sublist)
	return output

### Unit tests below ###
def check(candidate):
	assert candidate(range(6), lambda x: False) == [[0, 1, 2, 3, 4, 5]]
	assert candidate(range(10), lambda x: False) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
	assert candidate([], lambda x: True) == []
	assert candidate([1, 2, 3, 4, 5], lambda x: False) == [[1, 2, 3, 4, 5]]
	assert candidate([1], lambda x: False) == [[1]]
	assert candidate([1, 2, 3, 4, 5,5, 5], lambda x: False) == [[1, 2, 3, 4, 5, 5, 5]]
	assert candidate([1, 2, 3, 4, 5, 5, 5], lambda x: (x % 2) == 0) == [[1,2], [3,4], [5, 5, 5]]
	assert candidate([1, 2, 3, 4, 5,5, 5], lambda x: True) == [[1], [2], [3], [4], [5], [5], [5]]
	assert candidate(range(6), lambda x: True) == [[0], [1], [2], [3], [4], [5]]
	assert candidate([], lambda x: False) == []
	assert candidate(range(5), lambda x: x == 0) == [[0], [1, 2, 3, 4]]
	assert candidate(range(6), lambda x: x > 5) == [[0, 1, 2, 3, 4, 5]]
	assert candidate([1, 2, 3, 4, 5,5, 5], lambda x: x % 2 == 0) == [[1,2], [3,4], [5, 5, 5]]
	assert candidate([1, 2, 3, 4, 5, 5, 5], lambda x: x == 6) == [[1, 2, 3, 4, 5, 5, 5]]
	assert candidate([1, 2, 3, 4, 5,5, 5], lambda x: (x % 2) == 0) == [[1,2], [3,4], [5, 5, 5]]
def test_check():
	check(partition_by_suffix)
