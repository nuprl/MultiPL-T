def mlp_check_dimensions(x, y, ws, bs):
    """
    Return True if the dimensions in double_u and beta agree.
    :param x: a list of lists representing the x matrix.
    :param y: a list output values.
    :param ws: a list of weight matrices (one for each layer)
    :param bs: a list of biases (one for each layer)
    :return: True if the dimensions of x, y, ws and bs match
    """
    ### Canonical solution below ###
    ## W rows should equal X columns, b col should equal W col
    result = True
    if len(ws) != len(bs):
        return False
    if len(x[0]) != len(ws[0]):
        return False
    if len(x) != len(y):
        return False
    if len(y[0]) != len(bs[len(bs) - 1][0]):
        return False
    for layer in range(len(ws)):
        if len(ws[layer][0]) != len(bs[layer][0]):
            return False
        if layer == 0:
            pass
        else:
            prev_w = ws[layer - 1]
            if len(ws[layer]) != len(prev_w[0]):
                return False

        
    return result


### Unit tests below ###
def check(candidate):
	assert candidate([[1, 2, 3], [4, 5, 6]], [[1], [2]], [[[1, 2, 3]], [[1, 2, 3]]], [[[1], [1]]]) == False
	assert candidate(
    [[1, 2, 3], [4, 5, 6]],
    [7, 8],
    [[1, 1, 1], [1, 1, 1]],
    [[1, 1, 1], [1, 1, 1], [1, 1, 1]]) is False
	assert candidate(
    [[0, 1, 1],
     [1, 1, 1],
     [0, 1, 0]],
    [0, 1, 1],
    [
        [[1, 1], [1, 1]],
        [[1, 1], [1, 1]]
    ],
    [
        [[1, 1]],
        [[1, 1]],
        [[1, 1]]
    ]
) == False
	assert candidate([[1, 2, 3], [4, 5, 6]], [[1], [2]], [[[1, 2, 3]], [[1, 2]]], [[[1], [1]]]) == False
	assert candidate(
    [[0, 0], [1, 1], [2, 2]],
    [[0], [1], [2]],
    [[[0, 0], [0, 0]], [[0, 0], [0, 0]]],
    [[[0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0]]]) == False
	assert candidate(
    [[0, 0], [1, 1], [2, 2]],
    [[0], [1], [2]],
    [[[0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0]]],
    [[[0, 0], [0, 0]], [[0, 0], [0, 0]]]) == False
	assert candidate(
    [[1, 2, 3], [4, 5, 6]],
    [7, 8],
    [[1, 1, 1], [1, 1, 1]],
    [[1, 1, 1]]) is False
	assert not candidate(
    [[1, 2, 3], [4, 5, 6]],
    [[1, 2, 3], [4, 5, 6]],
    [[[1, 2, 3], [4, 5, 6], [7, 8, 9]], [[1, 2, 3], [4, 5, 6], [7, 8, 9]]],
    [[[1, 2, 3], [4, 5, 6]]])
	assert candidate(
    [[0, 1, 1],
     [1, 1, 1],
     [0, 1, 0]],
    [0, 1, 1],
    [
        [[1, 1], [1, 1]],
        [[1, 1], [1, 1]],
        [[1, 1], [1, 1]]
    ],
    [
        [[1, 1]],
        [[1, 1]],
        [[1, 1]]
    ]
) == False
	assert candidate(
    [[1, 2, 3], [4, 5, 6]],
    [[1, 2, 3], [4, 5, 6]],
    [[[1, 2, 3], [4, 5, 6], [7, 8, 9]], [[1, 2, 3], [4, 5, 6], [7, 8, 9]]],
    [[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])
	assert candidate([[1, 2, 3], [4, 5, 6]], [[1], [2]], [[[1, 2, 3]], [[1, 2, 3]]], [[[1], [1]], [[1]]]) == False
def test_check():
	check(mlp_check_dimensions)
