def input_require_int(raw_input):
    """ 
     Utility function that requires a given input to be an integer greater zero.
     In case the given input is not an integer or zero or negative, the user is requested to provide a valid input.
     :param raw_input: the initial user input
     :type raw_input: str
     :return: a number greater zero the user inserted
     :rtype: int
     """
	### Canonical solution below ###    
    while True:
        try:
            if int(raw_input) > 0:
                return int(raw_input)
            else:
                raise ValueError
        except ValueError:
            raw_input = input("Please input a valid number\n")

### Unit tests below ###
def check(candidate):
	assert candidate(100) == 100
	assert candidate(2) == 2
	assert candidate(1.1) == 1
	assert candidate("1") == 1
	assert candidate(10) == 10
	assert candidate(5) == 5
	assert candidate(1000000) == 1000000
	assert candidate("3") == 3
	assert candidate(3) == 3
	assert candidate("10") == 10
	assert candidate("1000") == 1000
	assert candidate(1.0) == 1
	assert candidate("5") == 5
	assert candidate(1000) == 1000
	assert candidate("0100") == 100
	assert candidate("1000000") == 1000000
	assert candidate("4") == 4
	assert candidate("2") == 2
	assert candidate(1.5) == 1
	assert candidate("10000000") == 10000000
	assert candidate("100") == 100
	assert candidate(1) == 1
def test_check():
	check(input_require_int)
