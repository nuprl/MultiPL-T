def is_path(name):
    """ Returns True if the given name is a path. Does not validate if the path
     is correct except basic invalid characters. """
	### Canonical solution below ###    
    if name is None or len(name) < 3:
        return False

    # if ('"' in name) or ('<' in name) or ('>' in name) or \
    #     ('|' in name) or ('*' in name):
    #     return False

    if name.startswith("\\") or name.startswith("/"):
        # \sysroot\etc\a.exe, /home/user/a.out, \??\C:\Program Files\a.exe, etc.
        return True
    if str.isalpha(name[0]) and name[1] == ":" and name[2] == "\\":
        # C:\Program Files, D:\Program Files, etc.
        return True

    return False

### Unit tests below ###
def check(candidate):
	assert candidate("a.txt.bkp2") == False
	assert candidate("abc.gif") == False
	assert candidate("\\sysroot\\etc\\a.exe") == True
	assert candidate("D:\\\\Program Files\\\\") == True
	assert candidate("\\\\?\\C:/Program Files/a.exe") == True
	assert candidate("abc.pyw") == False
	assert candidate("a.pdb") is False
	assert candidate("abc.txt.exe") == False
	assert candidate("a.ogg") == False
	assert candidate("C:\\Program Files\\a.exe") is True
	assert candidate("a.exe\\a.exe\\a.exe a.exe") is False
	assert candidate("a.ilk") is False
	assert candidate(" ") is False
	assert candidate(r"a.exe") == False
	assert candidate("a.dll.7z") == False
	assert candidate("abc.py") == False
	assert candidate(r"\\?\C:\Program Files\a.exe")
	assert candidate("a.xsd") == False
	assert candidate("a.exe\\a.exe\\a.exe\\a.exe ") is False
	assert candidate("a.jpeg") == False
	assert candidate("a.sys") is False
	assert candidate("a.bas") is False
	assert candidate("a.lib") is False
	assert candidate("a.py") == False
	assert candidate("abc.css") is False
	assert candidate("\\\\server\\share\\path\\") == True
	assert candidate("C:\\Program Files\\a.exe\\a.exe\\a.exe ") == True
	assert candidate("a.cmd") == False
	assert candidate("a.pyz") == False
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz.abc.def.ghi.jkl.mno.pqr.stu") == False
	assert candidate("c:\\a.exe") == True
	assert candidate("a.exe a.exe") is False
	assert candidate("a.mpeg") == False
	assert candidate("C:\\Program Files") == True
	assert candidate("C:\\a.exe") == True
	assert candidate("a.htm") == False
	assert candidate("/a.exe") == True
	assert candidate("a.vbs ") is False
	assert candidate("a.txt.old") == False
	assert candidate("abc.dll") == False
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz.abc") == False
	assert candidate("abc.jpeg") == False
	assert candidate("a.exe") == False
	assert candidate("abc.bin") is False
	assert candidate("a.exe\\a.exe\\a.exe\\a.exe") is False
	assert candidate("a.pdb") == False
	assert candidate("a.exe\\a.exe a.exe") is False
	assert candidate("a.iso") == False
	assert candidate(r"c:\test.exe") == True
	assert candidate("abc.zip") is False
	assert candidate("a.exe<") == False
	assert candidate("") is False
	assert candidate("a.ilk") == False
	assert candidate("a.md") == False
	assert candidate("a.tgz") == False
	assert candidate(r"a") == False
	assert candidate(r"\\?\c:/test.exe") == True
	assert candidate("a.pyw") == False
	assert candidate("D:\\Program Files") == True
	assert candidate("a.def") == False
	assert candidate(r"\\?\C:\Program Files")
	assert candidate("a.txt") == False
	assert candidate("a.cmd") is False
	assert not candidate(r"C:Program Files\a.exe")
	assert candidate("a.exe.7z") == False
	assert candidate("a.dll.gz") == False
	assert candidate("abc.jpg") is False
	assert candidate("\\\\host\\") == True
	assert candidate("\\\\server\\a.out") == True
	assert candidate(r"/home")
	assert candidate("abc.ttf") == False
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz") == False
	assert candidate("a.ps1") == False
	assert candidate("C:\\Program Files\\a\\b") == True
	assert candidate("abc.bat") == False
	assert candidate("a.txt.temp") == False
	assert candidate("a.jpg") == False
	assert candidate("\\\\server\\share\\path\\file.exe\\") == True
	assert candidate("abc.jpg") == False
	assert candidate("a.dylib") is False
	assert candidate("C:\\\\Program Files") == True
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz.abc.def.ghi.jkl.mno") == False
	assert candidate("abc.txt") is False
	assert candidate("a.scr") is False
	assert candidate("\\sysroot\\etc\\a.exe\\ ") == True
	assert candidate("a.bmp") is False
	assert candidate("a\\a") is False
	assert candidate("<a.exe>") == False
	assert candidate("\\??\\C:\\Program Files") == True
	assert candidate("abc.png") is False
	assert candidate("abc.txt.txt.exe") == False
	assert candidate("C:\\a") == True
	assert candidate("a.vbe") is False
	assert candidate("abc.cmd") == False
	assert candidate("\\\\?\\UNC\\a\\b\\c\\d") == True
	assert candidate("C:\\") == True
	assert candidate("a:b") == False
	assert candidate("abc.bat") is False
	assert candidate("a.tar") == False
	assert candidate("abc.txt.exe.com.dll.sys") == False
	assert candidate("C:\\Program Files\\a.exe") == True
	assert candidate("a.ps1 ") is False
	assert candidate("\\\\?\\UNC\\a\\b\\c") == True
	assert candidate(r"\\?\c:\test.exe") == True
	assert candidate("\\??\\C:\\Program Files\\a.exe") == True
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz.abc.def") == False
	assert candidate("abc.html") == False
	assert candidate("abc") == False
	assert candidate("\\\\.\\a\\b\\c.exe") == True
	assert candidate("C:\\Program Files\\a.exe\\a.exe\\") == True
	assert candidate("a.exe ") == False
	assert candidate("a.tar.gz") == False
	assert candidate("a.so") is False
	assert candidate("a.tiff") is False
	assert candidate("abc.com") == False
	assert candidate("abc.tar") is False
	assert candidate("abc.rar") is False
	assert candidate("a.xsl") == False
	assert candidate("a.bat ") is False
	assert candidate("a") == False
	assert candidate("a.exe.tar") == False
	assert candidate("a.exe.zip") == False
	assert candidate("c:\\a\\b\\c") == True
	assert candidate("a.pyd") == False
	assert candidate("abc.pyc") is False
	assert candidate(r"\??\C:\Program Files\a.exe") == True
	assert candidate("C:\\a\\b\\c") == True
	assert candidate("a.out") == False
	assert candidate("a.drv") is False
	assert candidate("a\\") is False
	assert candidate("\\\\server\\share\\path") == True
	assert candidate("a.txt.bkp") == False
	assert candidate("a.exe>") == False
	assert candidate("C:Program Files") == False
	assert candidate("\\a\\b\\c") == True
	assert candidate("a.txt.bkp3") == False
	assert candidate("a.dat") == False
	assert candidate("a.jse") is False
	assert candidate(r"/home/")
	assert candidate("a.log") == False
	assert candidate("a.bz2") == False
	assert candidate("a.txt.temp2") == False
	assert candidate("abc.gif") is False
	assert candidate("abc.dll") is False
	assert candidate("a.html") == False
	assert candidate("a.txt.bkp4") == False
	assert candidate("a.rc") is False
	assert candidate("a.js") == False
	assert candidate("abc.css") == False
	assert candidate("a.exe\\a.exe ") == False
	assert candidate("a.rar") == False
	assert candidate("a.gz") == False
	assert candidate("abc.txt.exe.com") == False
	assert candidate("a/b") == False
	assert candidate("\\\\?\\C:\\Program Files\\a.exe") == True
	assert candidate("abc.htm") == False
	assert candidate("a.7z") == False
	assert candidate("a.txt.bak") == False
	assert candidate("\\\\?\\UNC\\a\\b\\c\\d\\e\\f") == True
	assert candidate("a.exe\\a.exe") is False
	assert candidate("C:\\Program Files\\a.exe\\a.exe ") == True
	assert candidate("\\\\server\\share\\a.exe") == True
	assert candidate("a.js") is False
	assert candidate("c:\\") == True
	assert candidate(r"c:") == False
	assert candidate("a.bat") is False
	assert candidate("a.exe.gz") == False
	assert candidate(None) is False
	assert candidate("abc.ani") == False
	assert candidate("a.drv") == False
	assert candidate("a.wsh") is False
	assert candidate("a.exe\\a.exe\\a.exe a") is False
	assert candidate("D:\\\\Program Files") == True
	assert candidate("a.flac") == False
	assert candidate("a.xslt") == False
	assert candidate("C:") == False
	assert candidate("abc.sys") is False
	assert candidate("a.map") is False
	assert candidate("a.sql") == False
	assert candidate("abc.pyz") is False
	assert candidate("a.xz") == False
	assert candidate("a.mp4") == False
	assert candidate("C:\\Program Files\\a.exe\\") == True
	assert candidate("\\device\\harddiskvolume1\\a.out") == True
	assert candidate(r"C:\Program Files\a.exe")
	assert candidate("abc.bmp") == False
	assert candidate("a.exe\x00") == False
	assert candidate("abc.tga") == False
	assert candidate("a.zip") == False
	assert candidate("a.msc") is False
	assert candidate("a.ini") == False
	assert candidate("a.bmp") == False
	assert candidate("a.wav") == False
	assert candidate("a.exe b.exe") is False
	assert candidate("a.exe|") == False
	assert candidate("a.com ") is False
	assert candidate("/home/user") == True
	assert candidate("a.jpeg") is False
	assert candidate(r"\sysroot\etc\a.exe") == True
	assert candidate("/") == False
	assert candidate("\\\\.\\Volume{12341234-1234-1234-1234}") == True
	assert candidate("a.dll.bz2") == False
	assert candidate("abc.html") is False
	assert candidate("abc.tif") == False
	assert candidate("a.sys") == False
	assert candidate("a.tif") is False
	assert candidate("abc.com") is False
	assert candidate("\\a.exe") == True
	assert candidate("\\\\.\\Volume{1234-1234}") == True
	assert candidate("abc.txt.exe.com.dll") == False
	assert candidate("a.com") == False
	assert candidate("a.exe\\a.exe ") is False
	assert candidate("a.mpg") == False
	assert candidate("a.exe\\ ") == False
	assert candidate(r"/home/user")
	assert candidate("a.sh") == False
	assert candidate("/home/user/a.out") == True
	assert candidate("a\\a.exe") is False
	assert candidate("a.dll ") is False
	assert candidate("a.wsf") is False
	assert candidate("abc.png") == False
	assert candidate("C:\\Program Files\\a.exe\\ ") == True
	assert candidate(r"/home/user/a.out/")
	assert candidate("a.txt.swp") == False
	assert candidate("a.exe ") is False
	assert candidate("a.txt.swn2") == False
	assert candidate("abc.htm") is False
	assert candidate("\\") == False
	assert candidate("a.xml") == False
	assert candidate("abc.jpeg") is False
	assert candidate(r"\\?\c:\test") == True
	assert candidate(r"\\") == False
	assert candidate("abc.bz2") is False
	assert candidate("\\\\?\\C:\\Program Files\\a.exe") is True
	assert candidate("a.rsp") == False
	assert candidate("a.pyzw") == False
	assert candidate("abc.txt.txt") == False
	assert candidate("C:\\Program Files\\a\\b\\c") == True
	assert candidate("a.exe\\a.exe a") is False
	assert not candidate(r"C:Program Files")
	assert candidate("abc.js") is False
	assert candidate("a.exe.rar") == False
	assert candidate("C:\\Program Files\\a.out") == True
	assert candidate("D:\\Program Files\\") == True
	assert candidate(r"\??\C:\Program Files")
	assert candidate("a.ico") == False
	assert candidate("a.obj") is False
	assert candidate("ab") == False
	assert candidate("a.tar") is False
	assert not candidate(r"\\")
	assert candidate("\\\\.\\PhysicalDrive1234") == True
	assert candidate("abc.svg") is False
	assert candidate("a.exe a") is False
	assert candidate("a.efi") == False
	assert candidate("abc.xml") is False
	assert candidate("a.pyo") == False
	assert candidate("a.lnk") is False
	assert candidate("a/b/c") == False
	assert candidate("a.gif") is False
	assert candidate("abc.ico") is False
	assert candidate("//host/") == True
	assert candidate(r"\\?\c:/test") == True
	assert candidate("a.css") == False
	assert candidate("\\\\host\\a") == True
	assert candidate("C:\\Program Files\\a.exe\\a.exe") == True
	assert candidate("abc.cur") == False
	assert candidate("\\\\?\\UNC\\server\\share\\a.exe") == True
	assert candidate("a.txt.swn") == False
	assert candidate("\\??\\C:\\") == True
	assert candidate("a.exe\\a.exe\\a.exe ") is False
	assert candidate("\\\\.\\a\\b.exe") == True
	assert candidate("a.exp") is False
	assert candidate("a.exe*") == False
	assert candidate("a.aac") == False
	assert candidate("a.ps1") is False
	assert candidate("a.pl") == False
	assert candidate("abc.txt") == False
	assert candidate("a.out") is False
	assert candidate("C:\\Program Files\\a.exe\\a.exe\\a.exe") == True
	assert candidate("a.vbe ") is False
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz.abc.def.ghi.jkl.mno.pqr") == False
	assert candidate("a.tgz") is False
	assert candidate("a") is False
	assert candidate("a.pyc") == False
	assert candidate("a.vbs") is False
	assert candidate("abc.txt.exe.com.dll.sys.etc") == False
	assert candidate("a.dll") is False
	assert candidate("abc.ico") == False
	assert candidate("a.php") == False
	assert candidate("abc.js") == False
	assert candidate("a.xquery") == False
	assert candidate("a.png") == False
	assert candidate(r"\??\C:\Program Files\a.exe")
	assert candidate("\\\\.\\a\\b\\c\\d.exe") == True
	assert candidate("a.exe\\a.exe\\a.exe") is False
	assert candidate(r"c:\test") == True
	assert candidate("abc") is False
	assert candidate("a.avi") == False
	assert candidate("abc.dat") is False
	assert candidate("a.txt.swx") == False
	assert candidate("a.txt.tmp2") == False
	assert candidate("abc.sys") == False
	assert candidate("a.idb") is False
	assert candidate("C:\\Program Files\\") == True
	assert candidate("abc.eot") == False
	assert candidate("a.pyd") is False
	assert candidate("a.gif") == False
	assert candidate("a.txt.tmp") == False
	assert candidate("\\\\.\\a\\b\\c\\d\\e.exe") == True
	assert candidate("\\\\.\\a") == True
	assert candidate("abc.py") is False
	assert candidate("a.manifest") is False
	assert candidate("a.lib") == False
	assert candidate("\\\\server\\share\\path\\file.exe") == True
	assert candidate("a.bat") == False
	assert candidate("a.txt.old2") == False
	assert candidate("a.txt.swx2") == False
	assert candidate("a.exe\\a.exe b.exe") is False
	assert candidate("C:\\Program Files\\a.exe\\a.exe\\ ") == True
	assert candidate("a.exe\\a.exe\\a.exe b.exe") is False
	assert candidate("a.zip") is False
	assert candidate("\\sysroot\\Program Files") == True
	assert candidate("a.exe.tgz") == False
	assert candidate("C:Program Files\\a.exe") == False
	assert candidate("abc.tiff") == False
	assert candidate("a.mp3") == False
	assert candidate("a.txt.swo2") == False
	assert candidate("a.svg") == False
	assert candidate("") == False
	assert candidate("a.jpg") is False
	assert candidate("abc.woff") == False
	assert candidate(r"C:\Program Files")
	assert candidate("a.manifest") == False
	assert candidate("abc.msi") is False
	assert candidate("a.exe") is False
	assert candidate("a.obj") == False
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz.abc.def.ghi") == False
	assert candidate("C:\\Program Files\\a") == True
	assert candidate("/??/C:/Program Files/a.exe") == True
	assert candidate("a.dll.rar") == False
	assert candidate("\\sysroot\\etc\\a.exe\\") == True
	assert candidate("a.exe.manifest") == False
	assert candidate("\\\\?\\C:\\Program Files") == True
	assert candidate("//host/a") == True
	assert candidate("a.cpl") is False
	assert candidate("a.vb") is False
	assert candidate(r"/home/user/a.out")
	assert candidate(r"/") == False
	assert candidate("abc.txt.exe.com.dll.sys.etc.xyz.abc.def.ghi.jkl") == False
	assert candidate("abc.pyw") is False
	assert candidate("a.exe.bz2") == False
	assert candidate("a.reg") is False
	assert candidate("\\\\.\\a.exe") == True
	assert candidate("abc.exe") is False
	assert candidate("c:\\Program Files/a.exe") == True
	assert candidate("|a.exe|") == False
	assert candidate("a\\b") == False
	assert candidate("abc.exe") == False
	assert candidate("a.sql.txt") == False
	assert candidate("a.txt.swp2") == False
	assert candidate("a.exp") == False
	assert candidate("\\\\.\\PhysicalDrive1") == True
	assert candidate("\\sysroot\\etc\\a.exe\\a.exe") == True
	assert candidate("\\home\\user") == True
	assert candidate("a.bin") == False
	assert candidate("a.sys ") is False
	assert candidate("abc.gz") is False
	assert candidate("a.inf") is False
	assert candidate(" ") == False
	assert candidate("a.xhtml") == False
	assert candidate("a.txt.swo") == False
	assert candidate("a.dll") == False
	assert candidate("a.py") is False
	assert candidate("abc.pyd") == False
	assert candidate("/usr/local/bin/a.exe") is True
	assert candidate("a.png") is False
	assert candidate("abc.json") is False
	assert candidate("C:\\Program Files/a.exe") == True
	assert candidate("/a/b/c") == True
	assert candidate(None) == False
	assert candidate("abc.pyc") == False
	assert candidate("a.txt.bkp5") == False
	assert candidate(r"/home/user/a.out") == True
	assert candidate("\\\\?\\c:\\a\\b\\c") == True
	assert candidate("a.pdf") == False
	assert candidate("c:\\Program Files\\a.exe") == True
	assert candidate("\\\\.\\CdRom1") == True
	assert candidate(r"/home/user/")
	assert candidate("a.com") is False
	assert candidate("a.exe\\a.exe") == False
	assert candidate("C:\\\\Program Files\\\\") == True
	assert candidate("\"a.exe\"") == False
	assert candidate(r"") == False
	assert candidate("abc.otf") == False
	assert candidate("a.exe\\") == False
	assert candidate("a.ico") is False
	assert candidate("\\\\.\\CdRom1234") == True
	assert candidate("a.txt.bak2") == False
def test_check():
	check(is_path)
