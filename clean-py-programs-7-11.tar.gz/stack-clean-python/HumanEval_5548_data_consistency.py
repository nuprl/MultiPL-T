def data_consistency(k, k0, mask, noise_lvl=None):
    """
    k    - input in k-space
    k0   - initially sampled elements in k-space
    mask - corresponding nonzero location
    """
    ### Canonical solution below ###
    v = noise_lvl
    if v:  # noisy case
        out = (1 - mask) * k + mask * (k + v * k0) / (1 + v)
    else:  # noiseless case
        out = (1 - mask) * k + mask * k0
    return out


### Unit tests below ###
def check(candidate):
	assert candidate(1, 1, 0, 0.5) == 1.0
	assert candidate(1, 1, 0, 0.1) == 1.0
	assert candidate(1, 1, 0) == 1
	assert candidate(1, 0, 1, 0) == 0
	assert candidate(1, 2, 0) == 1
	assert candidate(1, 2, 0, noise_lvl=0) == 1
	assert candidate(0, 0, 0) == 0
	assert candidate(1, 2, 1, noise_lvl=0) == 2
	assert candidate(1, 1, 1) == 1
	assert candidate(1, 2, 1, 0) == 2
	assert candidate(0, 0, 1) == 0
	assert candidate(1, 2, 1, 1) == 1.5
	assert candidate(0, 2, 1) == 2
	assert candidate(1, 0, 0) == 1
	assert candidate(0, 1, 1) == 1
	assert candidate(1, 2, 1) == 2
	assert candidate(0, 1, 0) == 0
	assert candidate(1, 2, 0, 1) == 1
	assert candidate(0, 1, 0, 2) == 0
def test_check():
	check(data_consistency)
