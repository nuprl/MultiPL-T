def StripTypeInfo(rendered_data):
    """ Strips type information from rendered data. Useful for debugging."""
	### Canonical solution below ###  

  if isinstance(rendered_data, (list, tuple)):
    return [StripTypeInfo(d) for d in rendered_data]
  elif isinstance(rendered_data, dict):
    if "value" in rendered_data:
      return StripTypeInfo(rendered_data["value"])
    else:
      result = {}
      for k, v in rendered_data.items():
        result[k] = StripTypeInfo(v)
      return result
  else:
    return rendered_data

### Unit tests below ###
def check(candidate):
	assert candidate({"a": 1, "b": [2, candidate(3)]}) == {"a": 1, "b": [2, 3]}
	assert candidate("foo") == "foo"
	assert candidate({"value": {"value": {"a": 1, "b": "c"}}}) == {"a": 1, "b": "c"}
	assert candidate(1.0 + 2.0j) == 1.0 + 2.0j
	assert candidate([{"value": {"foo": 3}}]) == [{"foo": 3}]
	assert candidate({"value": "hello"}) == "hello"
	assert candidate(True) is True
	assert candidate({"x": {"y": 1}}) == {"x": {"y": 1}}
	assert candidate([{"type": "int", "value": 1}, "a", 1]) == [1, "a", 1]
	assert candidate({"value": 123.456}) == 123.456
	assert candidate({"a": candidate(None), "b": 2, "c": 3}) == {"a": None, "b": 2, "c": 3}
	assert candidate([candidate({"a": {"b": candidate(2)}, "c": candidate(3)})]) == [{"a": {"b": 2}, "c": 3}]
	assert candidate({"x": {"value": 1}}) == {"x": 1}
	assert candidate({"type": "a", "value": 1}) == 1
	assert candidate([12, None]) == [12, None]
	assert candidate([{"a": {"b": candidate(2)}, "c": candidate(3)}]) == [{"a": {"b": 2}, "c": 3}]
	assert candidate(
    {"value": {"value": "test", "type": "string"}, "type": "string"}) == "test"
	assert candidate({"foo": {"bar": 5}}) == {"foo": {"bar": 5}}
	assert candidate({"value": True}) == True
	assert candidate(1) == 1
	assert candidate({"value": {"foo": ["bar", 5]}}) == {"foo": ["bar", 5]}
	assert candidate({"type": "float", "value": 1.0}) == 1.0
	assert candidate({"x": [1, {"y": 2}, 3]}) == {"x": [1, {"y": 2}, 3]}
	assert candidate({"value": [1, "a"], "type": "list"}) == [1, "a"]
	assert candidate({"a": 1, "b": {"c": 2, "d": candidate(3)}}) == {"a": 1, "b": {"c": 2, "d": 3}}
	assert candidate([candidate([candidate(None), 2, 3])]) == [[None, 2, 3]]
	assert candidate({"x": 1}) == {"x": 1}
	assert candidate(123.456) == 123.456
	assert candidate({"x": [1, 2, 3]}) == {"x": [1, 2, 3]}
	assert candidate({"type": "number", "value": 1.0}) == 1.0
	assert candidate({"a": 1, "b": "2", "c": [1, "2", 3]}) == {
    "a": 1,
    "b": "2",
    "c": [1, "2", 3]
}
	assert candidate([{"value": "foo"}]) == ["foo"]
	assert candidate({"value": [1, 2]}) == [1, 2]
	assert candidate({"a": 1}) == {"a": 1}
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(5) == 5
	assert candidate({"value": [1, "a"]}) == [1, "a"]
	assert candidate([1, "a", {"type": "int", "value": 1}]) == [1, "a", 1]
	assert candidate({}) == {}
	assert candidate({"x": [1, {"value": 2}, 3]}) == {"x": [1, 2, 3]}
	assert candidate({1: 1, 2: 2, 3: 3}) == {1: 1, 2: 2, 3: 3}
	assert candidate({"value": {"value": "a"}, "type": "str"}) == "a"
	assert candidate({"value": []}) == []
	assert candidate({"a": {"b": candidate(2)}}) == {"a": {"b": 2}}
	assert candidate(["foo", "bar"]) == ["foo", "bar"]
	assert candidate({"foo": 1, "bar": ["foo", 1, False]}) == {"foo": 1, "bar": ["foo", 1, False]}
	assert candidate({"type": "array", "value": []}) == []
	assert candidate([{"foo": ["bar", 5]}]) == [{"foo": ["bar", 5]}]
	assert candidate({"value": {"a": 3, "b": "foo"}}) == {"a": 3, "b": "foo"}
	assert candidate({"type": "string", "value": "foo"}) == "foo"
	assert candidate({"value": False}) == False
	assert candidate({"value": 1, "type": "int"}) == 1
	assert candidate(
    {"value": {"value": 3, "type": "float"}, "type": "integer"}) == 3.0
	assert candidate("string") == "string"
	assert candidate(None) == None
	assert candidate([candidate([candidate([1, 2, 3])])]) == [[[1, 2, 3]]]
	assert candidate({"a": candidate(1), "b": 2}) == {"a": 1, "b": 2}
	assert candidate({"type": "object", "value": {}}) == {}
	assert candidate([1, candidate(2)]) == [1, 2]
	assert candidate({"value": [1, 2, 3]}) == [1, 2, 3]
	assert candidate({"a": 1, "b": candidate(2)}) == {"a": 1, "b": 2}
	assert candidate(["foo", 1, False]) == ["foo", 1, False]
	assert candidate({"type": "int", "value": 1}) == 1
	assert candidate([{"foo": {"bar": 5}}]) == [{"foo": {"bar": 5}}]
	assert candidate({"a": 1, "b": "2", "c": {"type": "int", "value": 3}}) == {
    "a": 1,
    "b": "2",
    "c": 3
}
	assert candidate({"value": 3}) == 3
	assert candidate({"value": [3, "foo"]}) == [3, "foo"]
	assert candidate({"type": "list", "value": [{"type": "int", "value": 1}, {"type": "int", "value": 2}, {"type": "int", "value": 3}]}) == [1, 2, 3]
	assert candidate({"value": {"value": 1}, "type": "int"}) == 1
	assert candidate({"value": 123}) == 123
	assert candidate([{"foo": 3}]) == [{"foo": 3}]
	assert candidate(3) == 3
	assert candidate("a") == "a"
	assert candidate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
	assert candidate({"value": 1}) == 1
	assert candidate({"value": {"a": 1, "b": "c"}}) == {"a": 1, "b": "c"}
	assert candidate({"value": 1.0}) == 1.0
	assert candidate([]) == []
	assert candidate({"foo": 1, "bar": False}) == {"foo": 1, "bar": False}
	assert candidate(None) is None
	assert candidate({"a": 1, "b": "c"}) == {"a": 1, "b": "c"}
	assert candidate(1.0) == 1.0
	assert candidate([candidate(1), candidate(2), candidate(3)]) == [1, 2, 3]
	assert candidate({"type": "dict", "value": {"a": {"type": "int", "value": 1}, "b": {"type": "int", "value": 2}}}) == {"a": 1, "b": 2}
	assert candidate([{"foo": "bar"}]) == [{"foo": "bar"}]
	assert candidate({"a": {"b": 12}}) == {"a": {"b": 12}}
	assert candidate({"foo": 3}) == {"foo": 3}
	assert candidate([3, "foo"]) == [3, "foo"]
	assert candidate(
    {"type": "a", "value": {"type": "b", "value": [1, {"type": "c", "value": 2}]}}) == [1, 2]
	assert candidate(
    {"value": {"value": 3, "type": "float"}, "type": "float"}) == 3.0
	assert candidate({"value": "a", "type": "str"}) == "a"
	assert candidate(1.2) == 1.2
	assert candidate(
    {"type": "list", "value": [{"type": "list", "value": [{"type": "int", "value": 0}]}]}) == [[0]]
	assert candidate(
    {"value": {"value": 3, "type": "integer"}, "type": "integer"}) == 3
	assert candidate([1, "foo"]) == [1, "foo"]
	assert candidate(12) == 12
	assert candidate({"value": {"value": 1}}) == 1
	assert candidate({"value": {"foo": "bar"}}) == {"foo": "bar"}
	assert candidate(
    [
        {"value": "test", "type": "Text"},
        {"value": "test", "type": "Text"},
    ],
) == [
    "test",
    "test",
]
	assert candidate({"type": "string", "value": "hello"}) == "hello"
	assert candidate([candidate(1), 2]) == [1, 2]
	assert candidate(True) == True
	assert candidate([{"value": 3}]) == [3]
	assert candidate({"value": {"foo": 3}}) == {"foo": 3}
	assert candidate({"value": {"foo": {"bar": 5}}}) == {"foo": {"bar": 5}}
	assert candidate({"foo": ["bar", 5]}) == {"foo": ["bar", 5]}
	assert candidate({"type": "number", "value": 1}) == 1
	assert candidate({"value": None}) == None
	assert candidate({"value": {"a": 1, "b": "c"}, "type": "dict"}) == {"a": 1, "b": "c"}
	assert candidate([candidate(None), 2, 3]) == [None, 2, 3]
	assert candidate({"a": [12, None]}) == {"a": [12, None]}
	assert candidate({"a": 3, "b": "foo"}) == {"a": 3, "b": "foo"}
	assert candidate({"value": {"value": "a"}}) == "a"
	assert candidate(
    [1, "2", {"type": "int", "value": 3}, {"type": "string", "value": "4"}]) == [
        1, "2", 3, "4"
    ]
	assert candidate({"a": candidate(1), "b": candidate(2)}) == {"a": 1, "b": 2}
	assert candidate({"a": None, "b": 1, "c": "abc", "d": True, "e": False}) == {"a": None, "b": 1, "c": "abc", "d": True, "e": False}
	assert candidate({"a": {"b": candidate(2)}, "c": candidate(3)}) == {"a": {"b": 2}, "c": 3}
	assert candidate(123) == 123
	assert candidate(
    {"value": {"value": "test", "type": "string"}, "type": "integer"}) == "test"
	assert candidate({"type": "dict", "value": {"a": 1, "b": 2}}) == {"a": 1, "b": 2}
	assert candidate({"value": {"type": "int", "value": 1}, "extra": 2}) == 1
	assert candidate(False) is False
	assert candidate([3]) == [3]
	assert candidate({"type": "dict", "value": {"a": 1}}) == {"a": 1}
	assert candidate({"value": "string"}) == "string"
	assert candidate([{"type": "int", "value": 1}, "a", [1, 2, 3]]) == [1, "a", [1, 2, 3]]
	assert candidate(
    {"value": {"value": 3, "type": "integer"}, "type": "float"}) == 3.0
	assert candidate(
    {"value": {"value": "test", "type": "string"}, "type": "float"}) == "test"
	assert candidate("hello") == "hello"
	assert candidate({"a": candidate([candidate(None), 2, 3]), "b": 2, "c": 3}) == {"a": [None, 2, 3], "b": 2, "c": 3}
	assert candidate(
    [
        {
            "value": [
                {"value": "test", "type": "Text"},
                {"value": "test", "type": "Text"},
            ],
            "type": "List",
        },
        {
            "value": [
                {"value": "test", "type": "Text"},
                {"value": "test", "type": "Text"},
            ],
            "type": "List",
        },
    ],
) == [
    [
        "test",
        "test",
    ],
    [
        "test",
        "test",
    ],
]
	assert candidate([candidate([candidate([candidate(None), 2, 3])])]) == [[[None, 2, 3]]]
	assert candidate({"type": "null", "value": None}) is None
	assert candidate(
    {"type": "Foo", "value": [
        {"type": "Bar", "value": "baz"},
        {"type": "Baz", "value": 42},
    ]}) == ["baz", 42]
	assert candidate({"value": {"value": {1: 2}}}) == {1: 2}
	assert candidate({"value": {1: 2}}) == {1: 2}
	assert candidate({"a": 1, "b": {"c": [candidate(2), 3], "d": 4}}) == {"a": 1, "b": {"c": [2, 3], "d": 4}}
	assert candidate([1, "a"]) == [1, "a"]
	assert candidate({"a": 1, "b": {"c": candidate(2), "d": 3}}) == {"a": 1, "b": {"c": 2, "d": 3}}
	assert candidate({"value": {1: 1, 2: 2, 3: 3}}) == {1: 1, 2: 2, 3: 3}
	assert candidate({"value": {"a": 1, "b": 2}}) == {"a": 1, "b": 2}
	assert candidate(
    {"type": "a", "value": {"type": "b", "value": {"type": "c", "value": 1}}}) == 1
	assert candidate(
    {"type": "Foo", "value": {"type": "Bar", "value": "baz"}}) == "baz"
	assert candidate({"type": "int", "value": 1, "extra": 2}) == 1
	assert candidate({"a": 12}) == {"a": 12}
	assert candidate(
    {"type": "list", "value": [{"type": "list", "value": []}]}) == [[]]
	assert candidate({"value": None}) is None
	assert candidate([None, 1, "abc", True, False]) == [None, 1, "abc", True, False]
	assert candidate([1, 2]) == [1, 2]
	assert candidate({1: 2}) == {1: 2}
	assert candidate({"foo": "bar"}) == {"foo": "bar"}
	assert candidate({"a": 1, "b": [candidate(2), 3]}) == {"a": 1, "b": [2, 3]}
	assert candidate(["foo"]) == ["foo"]
	assert candidate(
    {"type": "dict", "value": {"a": {"type": "int", "value": 0}, "b": {"type": "str", "value": "hello"}}}) == {"a": 0, "b": "hello"}
	assert candidate({"value": "a"}) == "a"
	assert candidate({"a": {"b": candidate(2)}, "c": 3}) == {"a": {"b": 2}, "c": 3}
	assert candidate({"value": "foo"}) == "foo"
	assert candidate({"value": {"value": [1, 2]}}) == [1, 2]
	assert candidate([candidate([1, 2, 3])]) == [[1, 2, 3]]
	assert candidate([{"type": "a", "value": 1}, {"type": "a", "value": 2}]) == [1, 2]
	assert candidate("abc") == "abc"
	assert candidate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
	assert candidate({"value": {"value": [1, "a"]}}) == [1, "a"]
	assert candidate({"value": {}}) == {}
	assert candidate(
    [
        {"value": "test", "type": "Text"},
        {"value": "test", "type": "Text"},
    ]
) == [
    "test",
    "test",
]
	assert candidate({"a": candidate([1, 2, 3]), "b": 2, "c": 3}) == {"a": [1, 2, 3], "b": 2, "c": 3}
	assert candidate(False) == False
	assert candidate(
    {"type": "Foo", "value": {
        "type": "Bar",
        "value": {
            "type": "Baz",
            "value": 42,
        }
    }}) == 42
	assert candidate({"a": {"b": 2}}) == {"a": {"b": 2}}
	assert candidate({"foo": 1, "bar": 2}) == {"foo": 1, "bar": 2}
	assert candidate({"value": ["foo", "bar"]}) == ["foo", "bar"]
	assert candidate(
    {"value": {"value": "test", "type": "string"}, "type": "boolean"}) == "test"
	assert candidate({"x": [1, {"y": {"value": 2}}, 3]}) == {"x": [1, {"y": 2}, 3]}
	assert candidate({"type": "list", "value": [1, 2, 3]}) == [1, 2, 3]
def test_check():
	check(StripTypeInfo)
