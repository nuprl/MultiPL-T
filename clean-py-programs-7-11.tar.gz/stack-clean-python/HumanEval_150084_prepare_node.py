def prepare_node(data):
    """ Prepare node for catalog endpoint
     
     Parameters:
     data (Union[str, dict]): Node ID or node definition
     Returns:
     Tuple[str, dict]: where first is ID and second is node definition
     
     Extract from /v1/health/service/<service>::
     
     {
     "Node": {
     "Node": "foobar",
     "Address": "10.1.10.12",
     "TaggedAddresses": {
     "lan": "10.1.10.12",
     "wan": "10.1.10.12"
     }
     },
     "Service": {...},
     "Checks": [...]
     }
     """
	### Canonical solution below ###    
    if not data:
        return None, {}

    if isinstance(data, str):
        return data, {}

    # from /v1/health/service/<service>
    if all(field in data for field in ("Node", "Service", "Checks")):
        return data["Node"]["Node"], data["Node"]

    result = {}
    if "ID" in data:
        result["Node"] = data["ID"]
    for k in ("Datacenter", "Node", "Address",
              "TaggedAddresses", "Service",
              "Check", "Checks"):
        if k in data:
            result[k] = data[k]
    if list(result) == ["Node"]:
        return result["Node"], {}
    return result.get("Node"), result

### Unit tests below ###
def check(candidate):
	assert candidate(None) == (None, {})
	assert candidate("foobar") == ("foobar", {})
	assert candidate("test") == ("test", {})
	assert candidate({"ID": "foobar", "Node": "foobar"}) == ("foobar", {})
	assert candidate({"ID": "foobar"}) == ("foobar", {})
	assert candidate({"ID": "foo"}) == ("foo", {})
	assert candidate({"Node": "bar"}) == ("bar", {})
	assert candidate("foo") == ("foo", {})
	assert candidate({}) == (None, {})
	assert candidate({"ID": "abc"}) == ("abc", {})
	assert candidate({"Node": "foobar"}) == ("foobar", {})
	assert candidate({"ID": "test"}) == ("test", {})
	assert candidate("") == (None, {})
	assert candidate("abc") == ("abc", {})
def test_check():
	check(prepare_node)
