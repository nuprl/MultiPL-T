def average_predictions(predictions):
    """
    Returns the average of all predictions.

    Parameters
    ----------
    predictions : list
        Predictions (i.e. NN activation functions).

    Returns
    -------
    numpy array
        Averaged prediction.

    """
    ### Canonical solution below ###
    # average predictions if needed
    if len(predictions) > 1:
        # average the predictions
        predictions = sum(predictions) / len(predictions)
    else:
        # nothing to average since we have only one prediction
        predictions = predictions[0]
    # return the (averaged) predictions
    return predictions


### Unit tests below ###
def check(candidate):
	assert candidate(predictions=[[[1, 2, 3]]]) == [[1, 2, 3]]
	assert candidate(predictions=[0, 1, 2]) == 1
	assert candidate(predictions=[1, 2, 3]) == 2
	assert candidate(predictions=[0, 1]) == 0.5
	assert candidate(predictions=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 5.5
	assert candidate(predictions=[1, 1, 1, 1]) == 1
	assert candidate(predictions=[1, 2, 3]) == 2.0
	assert candidate(predictions=[0, 0, 0]) == 0
	assert candidate(predictions=[[[0.1, 0.2, 0.3]]]) == [[0.1, 0.2, 0.3]]
	assert candidate(predictions=[1, 2, 3, 4, 5]) == 3.0
	assert candidate(predictions=[[[0.1, 0.2, 0.3], [0.1, 0.2, 0.3]]]) == [[0.1, 0.2, 0.3], [0.1, 0.2, 0.3]]
	assert candidate(predictions=[1, 2, 3, 4, 5, 6]) == 3.5
	assert candidate(predictions=[1, 2, 3, 4, 5]) == 3
	assert candidate(predictions=[0, 0]) == 0
	assert candidate(predictions=[1, 2, 3, 4]) == 2.5, "Should be 2.5"
	assert candidate(predictions=[1, 2, 3, 4, 5, 6, 7, 8, 9]) == 5
	assert candidate(predictions=[[1]]) == [1]
	assert candidate(predictions=[1, 2, 3])!= 1.0
	assert candidate(predictions=[0]) == 0
	assert candidate(predictions=[1, 2, 3]) == 2, "Should be 2"
	assert candidate(predictions=[[[1, 2, 3], [4, 5, 6]]]) == [[1, 2, 3], [4, 5, 6]], "Should be [[1, 2, 3], [4, 5, 6]]"
	assert candidate(predictions=[1, 1, 1]) == 1
	assert candidate(predictions=[1, 2, 3, 4]) == 2.5
	assert candidate(predictions=[1, 1, 1, 1, 1]) == 1
def test_check():
	check(average_predictions)
