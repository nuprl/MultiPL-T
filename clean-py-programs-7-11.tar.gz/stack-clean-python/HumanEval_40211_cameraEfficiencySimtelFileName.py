def cameraEfficiencySimtelFileName(site, telescopeModelName, zenithAngle, label):
    """ 
     Camera efficiency simtel output file name.
     
     Parameters
     ----------
     site: str
     South or North.
     telescopeModelName: str
     LST-1, MST-FlashCam-D, ...
     zenithAngle: float
     Zenith angle (deg).
     label: str
     Instance label.
     
     Returns
     -------
     str
     File name.
     """
	### Canonical solution below ###    
    name = "camera-efficiency-{}-{}-za{:.1f}".format(
        site, telescopeModelName, zenithAngle
    )
    name += "_{}".format(label) if label is not None else ""
    name += ".dat"
    return name

### Unit tests below ###
def check(candidate):
	assert candidate(
    site="North", telescopeModelName="LST-1", zenithAngle=0, label="test"
) == "camera-efficiency-North-LST-1-za0.0_test.dat"
	assert candidate(
    "South", "LST-1", 0, None
) == "camera-efficiency-South-LST-1-za0.0.dat"
	assert candidate(
    "South", "LST-1", 20.0, None
) == "camera-efficiency-South-LST-1-za20.0.dat"
	assert candidate(
    "North", "LST-1", 20.0, label=None
) == "camera-efficiency-North-LST-1-za20.0.dat"
	assert candidate(
    "North", "LST-1", 20.0, "test"
) == "camera-efficiency-North-LST-1-za20.0_test.dat"
	assert candidate(
    site="South", telescopeModelName="MST-FlashCam-D", zenithAngle=30, label=None
) == "camera-efficiency-South-MST-FlashCam-D-za30.0.dat"
	assert candidate(
    site="North", telescopeModelName="LST-1", zenithAngle=20.0, label="test"
) == "camera-efficiency-North-LST-1-za20.0_test.dat"
	assert candidate(
    "South", "LST-1", 20, "label"
) == "camera-efficiency-South-LST-1-za20.0_label.dat"
	assert candidate(
    "North", "LST-1", 20.0, None
) == "camera-efficiency-North-LST-1-za20.0.dat"
	assert candidate(
    "North", "LST-1", 0, "test"
) == "camera-efficiency-North-LST-1-za0.0_test.dat"
	assert candidate(
    site="North", telescopeModelName="LST-1", zenithAngle=20.0, label=None
) == "camera-efficiency-North-LST-1-za20.0.dat"
	assert candidate(
    "South", "LST-1", 0.0, "test"
) == "camera-efficiency-South-LST-1-za0.0_test.dat"
	assert candidate(
    "South", "LST-1", 20.0, "test"
) == "camera-efficiency-South-LST-1-za20.0_test.dat"
	assert candidate(
    "North", "LST-1", 180, "test"
) == "camera-efficiency-North-LST-1-za180.0_test.dat"
	assert candidate(
    "South", "LST-1", 20, None
) == "camera-efficiency-South-LST-1-za20.0.dat"
	assert candidate(
    "South", "LST-1", 20, "test"
) == "camera-efficiency-South-LST-1-za20.0_test.dat"
	assert candidate(
    "North", "LST-1", 10.0, None
) == "camera-efficiency-North-LST-1-za10.0.dat"
	assert candidate(
    site="North",
    telescopeModelName="LST-1",
    zenithAngle=20,
    label="test",
) == "camera-efficiency-North-LST-1-za20.0_test.dat"
	assert candidate(
    "South", "LST-1", 20.0, label=None
) == "camera-efficiency-South-LST-1-za20.0.dat"
	assert candidate(
    "North", "LST-1", 0.0, None
) == "camera-efficiency-North-LST-1-za0.0.dat"
	assert candidate(
    "North", "MST-FlashCam-D", 20.0, "test"
) == "camera-efficiency-North-MST-FlashCam-D-za20.0_test.dat"
	assert candidate(
    "North", "MST-FlashCam-D", 10.0, None
) == "camera-efficiency-North-MST-FlashCam-D-za10.0.dat"
	assert candidate(
    "South", "LST-1", 20.0, label="test"
) == "camera-efficiency-South-LST-1-za20.0_test.dat"
	assert candidate(
    "North", "LST-1", 20.0, label="test"
) == "camera-efficiency-North-LST-1-za20.0_test.dat"
	assert candidate(
    "North", "LST-1", 20.0, "test123"
) == "camera-efficiency-North-LST-1-za20.0_test123.dat"
	assert candidate(
    "North", "LST-1", 10.0, "test"
) == "camera-efficiency-North-LST-1-za10.0_test.dat"
	assert candidate(
    "North", "LST-1", 180, None
) == "camera-efficiency-North-LST-1-za180.0.dat"
	assert candidate(
    "North", "MST-FlashCam-D", 80, None
) == "camera-efficiency-North-MST-FlashCam-D-za80.0.dat"
	assert candidate(
    "North", "LST-1", 20, None
) == "camera-efficiency-North-LST-1-za20.0.dat"
	assert candidate(
    site="North", telescopeModelName="LST-1", zenithAngle=0, label=None
) == "camera-efficiency-North-LST-1-za0.0.dat"
def test_check():
	check(cameraEfficiencySimtelFileName)
