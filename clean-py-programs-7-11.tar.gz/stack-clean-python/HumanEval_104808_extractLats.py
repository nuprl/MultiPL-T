def extractLats(listoftups):
    """Given a sequence of tuples the first two elements of which are
    longitude and latitude, return list of lons"""
    ### Canonical solution below ###
    return [item[1] for item in listoftups]


### Unit tests below ###
def check(candidate):
	assert candidate(
    [(0, 1), (1, 2), (2, 3), (3, 4)]) == [1, 2, 3, 4]
	assert candidate( ((0,1),(1,2)) ) == [1,2]
	assert candidate(
    [(1, 2), (3, 4), (5, 6), (7, 8), (9, 10)]) == [2, 4, 6, 8, 10]
	assert candidate(
    [(1, 2), (3, 4), (5, 6), (7, 8)]) == [2, 4, 6, 8]
	assert candidate([('a', 1.0), ('b', 2.0)]) == [1.0, 2.0]
	assert candidate([(1,2), (3,4), (5,6)]) == [2, 4, 6]
	assert candidate(
    [(130.0, -34.0), (131.0, -35.0), (132.0, -36.0)]) == [-34.0, -35.0, -36.0]
	assert candidate( ((0,1),(1,2),(2,3)) ) == [1,2,3]
	assert candidate( [(1,2), (3,4), (5,6)] ) == [2, 4, 6]
def test_check():
	check(extractLats)
