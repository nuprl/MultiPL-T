def prep_difflines(content):
    """ difflib takes input in this "readlines" compatible format """
    ### Canonical solution below ###
    return [ x+"\n" for x in content.split("\n") ]


### Unit tests below ###
def check(candidate):
	assert candidate(u"a") == [u"a\n"]
	assert candidate(
    "one\ntwo\nthree\nfour\nfive\nsix\nseven\neight\nnine\nten") == [
    "one\n", "two\n", "three\n", "four\n", "five\n", "six\n", "seven\n",
    "eight\n", "nine\n", "ten\n"]
	assert candidate(u"a\nb") == [u"a\n", u"b\n"]
	assert candidate(u"a\nb\nc") == [u"a\n", u"b\n", u"c\n"]
	assert candidate( "a" ) == [ "a\n" ]
	assert candidate(u"foo\nbar") == [u"foo\n", u"bar\n"]
	assert candidate( "a\nb" ) == [ "a\n", "b\n" ]
	assert candidate(u"foo") == [u"foo\n"]
	assert candidate(u"one\ntwo\nthree") == [u"one\n", u"two\n", u"three\n"]
	assert candidate(
    "foo\nbar\nbaz"
) == ["foo\n", "bar\n", "baz\n"]
	assert candidate(u"one\ntwo\nthree\n") == [u"one\n", u"two\n", u"three\n", u"\n"]
	assert candidate(
    "This is a test.\nThis is another test.\n") == [
    "This is a test.\n", "This is another test.\n", "\n"]
	assert candidate(r"""
1
2
3
4
5
6
7
8
9
10
""") == candidate(r"""
1
2
3
4
5
6
7
8
9
10
""")
def test_check():
	check(prep_difflines)
