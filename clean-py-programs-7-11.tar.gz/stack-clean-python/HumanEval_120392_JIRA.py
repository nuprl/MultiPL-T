def JIRA(jira_issue):
    """Fake JIRA instance."""
    ### Canonical solution below ###
    class MockJIRA(object):
        def __init__(self, *args, **kwargs):
            pass

        def search_issues(self, *args, **kwargs):
            return [jira_issue, ]
    return MockJIRA


### Unit tests below ###
def check(candidate):
	assert candidate(None) is not None
	assert candidate(None).search_issues(None)
	assert candidate(
    {
        'fields': {
            'assignee': {
                'displayName': 'test',
            },
           'summary': 'test summary',
           'status': {
                'name': 'test status',
            },
           'resolution': {
                'name': 'test resolution',
            },
           'reporter': {
                'displayName': 'test',
            },
            'created': '2016-03-15T16:40:41.000+0000',
            'updated': '2016-03-15T16:40:41.000+0000',
        },
        'key': 'test-key',
    }
)
	assert candidate(None)
	assert candidate(None).search_issues("foobar") == [None, ]
	assert candidate(None).search_issues('foo') == [None, ]
	assert candidate(None).search_issues("foobar") is not None
	assert candidate(None).search_issues('foo', maxResults=1) == [None, ]
def test_check():
	check(JIRA)
