def _search_on_path(filenames):
    """Find file on system path."""
    ### Canonical solution below ###
    # http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/52224

    from os.path import exists, abspath, join
    from os import pathsep, environ

    search_path = environ["PATH"]

    paths = search_path.split(pathsep)
    for path in paths:
        for filename in filenames:
            if exists(join(path, filename)):
                return abspath(join(path, filename))


### Unit tests below ###
def check(candidate):
	assert candidate(filenames=['python2']) == '/usr/bin/python2'
	assert candidate(
    ["ls", "ls.exe", "ls.bat", "ls.cmd"]) == "/bin/ls"
	assert candidate(["not_a_program"]) is None
	assert candidate(filenames=["ls"]) == "/bin/ls"
	assert candidate( ("grep", "grep") ) == "/bin/grep"
	assert candidate(
        ["ls.exe"]) is None
	assert candidate( ("/usr/bin/awk", "awk") ) == "/usr/bin/awk"
	assert candidate(
        ["ls.cmd"]) is None
	assert candidate(filenames=['python']) == '/usr/bin/python'
	assert candidate( ("/usr/bin/find", "find") ) == "/usr/bin/find"
	assert candidate(filenames=["/bin/foo", "ls"]) is not None
	assert candidate(filenames=['ls', 'dir']) == '/bin/ls'
	assert candidate(
    ["gcc", "gcc.exe", "gcc.bat", "gcc.sh", "gcc.pl", "gcc.csh"]
)
	assert candidate(filenames=["not_a_python_executable"]) is None
	assert candidate(
    ["ls"]
) == "/bin/ls", "expected /bin/ls, got %s" % candidate(["ls"])
	assert candidate(filenames=['python3']) == '/usr/bin/python3'
	assert candidate(filenames=["ls"]) is not None
	assert candidate(
    ["ls", "dir", "pwd", "echo", "env"]
) is not None
	assert candidate(('ls', 'df'))
	assert candidate(
        ["ls.bat"]) is None
	assert candidate( ("ls", "grep") )
	assert candidate(
    ["bogus"]
) is None, "expected None, got %s" % candidate(["bogus"])
	assert candidate(
    ['/usr/bin/python', '/usr/bin/python2.7', '/usr/bin/python2']) == \
    '/usr/bin/python'
	assert candidate(filenames=["python"]) is not None
	assert candidate(filenames=['ls', 'dir'])!= '/usr/bin/ls'
	assert candidate( ("ls",) ) == "/bin/ls"
	assert candidate(filenames=["/bin/ls"]) is not None
	assert candidate(
    ['ls', 'grep', 'cp','mv', 'diff', 'patch','mkdir', 'rm'])
	assert candidate(
    ['/usr/bin/python', '/usr/bin/python2', '/usr/bin/python2.7']) == \
    '/usr/bin/python'
	assert candidate( ("/usr/bin/head", "head") ) == "/usr/bin/head"
	assert candidate(("/bin/ls", "/usr/bin/ls")) == "/bin/ls"
	assert candidate(filenames=['python']) is not None
	assert candidate(('/bin', '/usr/bin', '/usr/local/bin'))
	assert candidate( ("/usr/bin/cut", "cut") ) == "/usr/bin/cut"
	assert candidate( ("/usr/bin/uniq", "uniq") ) == "/usr/bin/uniq"
	assert candidate(
    ["ls"]
) == "/bin/ls"
	assert candidate(
    ["find_executable_test.py", "find_executable_test.pyc", "find_executable_test.exe"]
) is None
	assert candidate(filenames=['nonexistent_filename']) is None
	assert candidate(
    ["ls", "la", "l", "la"]
) == "/bin/ls"
	assert candidate(
        ["ls"]) == "/bin/ls"
	assert candidate(filenames=['python2.7']) == '/usr/bin/python2.7'
	assert candidate(filenames = ['/bin/ls', '/usr/bin/wc'])
	assert candidate( ("/usr/bin/sort", "sort") ) == "/usr/bin/sort"
	assert candidate(
    ["ls", "la"]
) == "/bin/ls"
	assert candidate( ("/bin/ls",) ) == "/bin/ls"
	assert candidate(filenames=["/bin/foo"]) is None
	assert candidate(
    ['/usr/bin/python2.7', '/usr/bin/python2', '/usr/bin/python']) == \
    '/usr/bin/python2.7'
	assert candidate(
    ["python", "python.exe", "python2.7", "python2.7.exe", "python2.6", "python2.6.exe"])
	assert candidate(
    ["python", "python.exe", "python.bat"]) == candidate(
    ["python.exe", "python.bat", "python"])
	assert candidate(filenames=['python3.7']) == '/usr/bin/python3.7'
	assert candidate(("/bin/notthere", "/usr/bin/notthere")) is None
	assert candidate(
    ("python", "pythonw", "python2", "python2.7", "python2.6")
) is not None
	assert candidate(
    ['/usr/bin/python2', '/usr/bin/python2.7', '/usr/bin/python']) == \
    '/usr/bin/python2'
def test_check():
	check(_search_on_path)
