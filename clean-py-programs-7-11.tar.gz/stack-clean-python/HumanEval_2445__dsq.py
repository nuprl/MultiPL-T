def _dsq(x0, y0, x1, y1):
    """ 
     Returns the square of the distance between two points.
     """
	### Canonical solution below ###    
    return (x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0)

### Unit tests below ###
def check(candidate):
	assert candidate(3, 4, 3, 4) == 0
	assert candidate(0, 0, -1, 1) == 2
	assert candidate(0, 0, -1, -1) == 2
	assert candidate(0, 0, 0, -1) == 1
	assert candidate(1, 1, 0, 1) == 1
	assert candidate(0, 0, 1, 1) == 2
	assert candidate(0, 0, -3, -4) == 25
	assert candidate(0, 0, 3, 4) == 25
	assert candidate(0, 0, 3, -4) == 25
	assert candidate(0, 0, 1, 2) == 5
	assert candidate(0, 0, 1e5, 1e5) == 2e10
	assert candidate(0, 0, 2, 0) == 4
	assert candidate(0, 0, 1, -1) == 2
	assert candidate(2, 1, 1, 2) == 2
	assert candidate(0, 0, 0, 0) == 0
	assert candidate(0, 0, 1, 1) == 2.0
	assert candidate(1, 1, 0, 0) == 2
	assert candidate(0, 0, 1, 0) == 1
	assert candidate(0, 0, 1000, 1000) == 2000000
	assert candidate(3, 4, 0, 0) == 25
	assert candidate(1, 2, 2, 1) == 2
	assert candidate(0, 0, 0, 3) == 9
	assert candidate(0, 0, 2, 1) == 5
	assert candidate(1, 1, 1, 1) == 0
	assert candidate(1, 0, 0, 0) == 1
	assert candidate(1, 1, 2, 1) == 1
	assert candidate(0, 1, 0, 0) == 1
	assert candidate(1, 1, 1, 0) == 1
	assert candidate(0, 0, 0, 1) == 1
	assert candidate(0, 0, 3, 0) == 9
	assert candidate(0, 0, -3, 4) == 25
	assert candidate(0, 0, 2, 2) == 8
	assert candidate(2, 3, 2, 3) == 0
	assert candidate(0, 0, 3, 3) == 18
	assert candidate(0, 0, 0, -3) == 9
	assert candidate(1, 1, 2, 2) == 2
	assert candidate(0, 0, -3, 0) == 9
	assert candidate(0, 0, -1, 0) == 1
def test_check():
	check(_dsq)
