def sanitise_args(config):
    """
    Sanitise command-line configuration.
    :param config: Config dictionary (from docopt)
    :returns: Config dictionary with all keys stripped of '<' '>' and '--'
    """
    ### Canonical solution below ###
    sane_conf = {}
    for key, value in config.items():
        if value is not None:
            key = key.lstrip("-><").rstrip("><")
            sane_conf[key] = value

    return sane_conf


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'<input_file>': 'input.csv', '<-><output_file>': 'output.csv'}) == \
    {'input_file': 'input.csv', 'output_file': 'output.csv'}
	assert candidate(dict(a=1, b=2, c=3, d=4)) == dict(a=1, b=2, c=3, d=4)
	assert candidate(dict(config="file.json")) == dict(config="file.json")
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
	assert candidate(
    {'<input_file>': 'input.csv', '<--<output_file>': 'output.csv'}) == \
    {'input_file': 'input.csv', 'output_file': 'output.csv'}
	assert candidate(dict(config=None)) == {}
	assert candidate(
    {'<file>': 'file', '--verbose': None, '--silent': None}) == {'file': 'file'}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == dict(a=1, b=2, c=3, d=4, e=5)
	assert candidate(dict(a=1, b=2, c=3, d=4)) == {"a": 1, "b": 2, "c": 3, "d": 4}
	assert candidate(dict(a=1)) == dict(a=1)
	assert candidate(
    {'<file>': 'file', '--verbose': None, '--silent': None, '--foo': None}) == {'file': 'file'}
	assert candidate(
    {'<input_file>': 'input.csv', '-><output_file>': 'output.csv'}) == \
    {'input_file': 'input.csv', 'output_file': 'output.csv'}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == dict(a=1, b=2, c=3, d=4, e=5, f=6)
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8)) == dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8)
	assert candidate(
    {'<input_file>': 'input.txt', '-><output_file>': 'output.txt'}) == {
        'input_file': 'input.txt', 'output_file': 'output.txt'}
	assert candidate(
    {'-><input_file>': 'input.txt', '-><output_file>': 'output.txt'}) == {
        'input_file': 'input.txt', 'output_file': 'output.txt'}
	assert candidate(
    {'<input_file>': 'input.txt', '<output_file>': 'output.txt'}) == {
        'input_file': 'input.txt', 'output_file': 'output.txt'}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8, i=9)) == dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8, i=9)
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7)) == dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7)
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8)) == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8}
	assert candidate(
    {"<src>": "foo", "<dst>": "bar", "--config": "baz"}
) == {"src": "foo", "dst": "bar", "config": "baz"}
	assert candidate(dict(
    a="1",
    b="2",
    c="3",
    d="4",
)) == dict(
    a="1",
    b="2",
    c="3",
    d="4",
)
	assert candidate(dict(
    a="1",
    b="2",
    c="3",
)) == dict(
    a="1",
    b="2",
    c="3",
)
	assert candidate(dict(a=1, b=2)) == dict(a=1, b=2)
	assert candidate(
    {'-><input_file>': 'input.txt', '<output_file>': 'output.txt'}) == {
        'input_file': 'input.txt', 'output_file': 'output.txt'}
	assert candidate(
    {'--config': 'config.json', '<command>': 'ls'}) == \
    {'config': 'config.json', 'command': 'ls'}
	assert candidate(
    {'<input_file>': 'input.csv', '-><output_file>': 'output.csv',
     '-><overwrite>': True}) == \
    {'input_file': 'input.csv', 'output_file': 'output.csv',
     'overwrite': True}
	assert candidate(
    {"-><config>": "test.yaml", "-><output>": "output.png"}) == {
    "config": "test.yaml", "output": "output.png"}
	assert candidate(
    {"<src>": "foo", "<dst>": "bar", "--config": None}
) == {"src": "foo", "dst": "bar"}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7)) == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}
	assert candidate(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
	assert candidate(
    {"-><config>": "config.ini", "<-><source>": "source", "<-><target>": "target"}
) == {"config": "config.ini", "source": "source", "target": "target"}
	assert candidate(
    {
        "--config": None,
        "-><config>": "config.yaml",
        "-><port>": 8080,
        "-><address>": "0.0.0.0",
        "-><log-level>": "INFO",
        "-><log-file>": "log.txt",
        "-><api-key>": "abc",
        "-><db-name>": "test",
        "-><db-username>": "test",
        "-><db-password>": "<PASSWORD>",
        "-><db-host>": "localhost",
        "-><db-port>": 5432,
        "-><db-schema>": "schema.sql",
        "-><db-seed>": "seed.sql",
        "-><db-dump>": "dump.sql",
    }
) == {
    "config": "config.yaml",
    "port": 8080,
    "address": "0.0.0.0",
    "log-level": "INFO",
    "log-file": "log.txt",
    "api-key": "abc",
    "db-name": "test",
    "db-username": "test",
    "db-password": "<PASSWORD>",
    "db-host": "localhost",
    "db-port": 5432,
    "db-schema": "schema.sql",
    "db-seed": "seed.sql",
    "db-dump": "dump.sql",
}
	assert candidate(dict(a=1, b=2, c=3)) == {"a": 1, "b": 2, "c": 3}
def test_check():
	check(sanitise_args)
