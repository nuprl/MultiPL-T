def scenario_ids(scenarios):
    """Parse the scenarios and feed the IDs to the test function."""
    ### Canonical solution below ###
    return [test_input[1] for test_input in scenarios]


### Unit tests below ###
def check(candidate):
	assert candidate(
    [
        ('test_id', 1),
        ('test_id', 2),
        ('test_id', 3),
        ('test_id', 4),
        ('test_id', 5),
    ]
) == [1, 2, 3, 4, 5]
	assert candidate(
    [
        ('test_scenario_1', 1),
        ('test_scenario_2', 2),
        ('test_scenario_3', 3),
        ('test_scenario_4', 4),
    ]
) == [1, 2, 3, 4]
	assert candidate(
    [("test_scenario_1", 1), ("test_scenario_2", 2), ("test_scenario_3", 3)]
) == [1, 2, 3]
	assert candidate(scenarios=[
    ('Scenario 1', '1'),
    ('Scenario 2', '2'),
    ('Scenario 3', '3'),
]) == ['1', '2', '3']
	assert candidate(
    [
        ('test_id', 1),
        ('test_id', 2),
        ('test_id', 3),
    ]
) == [1, 2, 3]
	assert candidate(
    [
        ('test_scenario_1', 1),
        ('test_scenario_2', 2),
    ]
) == [1, 2]
	assert candidate(
    [
        ('test_scenario_1', 1),
        ('test_scenario_2', 2),
        ('test_scenario_3', 3),
    ]
) == [1, 2, 3]
	assert candidate(scenarios=[(1, 2), (3, 4)]) == [2, 4]
	assert candidate(scenarios=[('test_input_1', 1), ('test_input_2', 2), ('test_input_3', 3)]) == [1, 2, 3]
	assert candidate(scenarios=[('test', '1234567890')]) == ['1234567890']
	assert candidate(scenarios=[('test', '1234567890'), ('test2', '1234567891')]) == ['1234567890', '1234567891']
	assert candidate([
    ('scenario_name','scenario_id'),
    ('scenario_name2','scenario_id2'),
]) == ['scenario_id','scenario_id2'], "Scenario IDs should be returned"
	assert candidate([]) == []
	assert candidate(
    [("test_scenario_1", 1), ("test_scenario_2", 2)]
) == [1, 2]
	assert candidate(scenarios=[(1, 2), (3, 4), (1, 2)]) == [2, 4, 2]
	assert candidate(scenarios=[('01000000', 1), ('00000000', 0)]) == [1, 0]
	assert candidate(scenarios=[('00000001', 1), ('01000000', 0)]) == [1, 0]
	assert candidate(
    [
        ('test_id', 1),
        ('test_id', 2),
    ]
) == [1, 2]
	assert candidate(scenarios=[(1, 2), (1, 2)]) == [2, 2]
	assert candidate(
    [
        ('test_id', 1),
        ('test_id', 2),
        ('test_id', 3),
        ('test_id', 4),
    ]
) == [1, 2, 3, 4]
	assert candidate(
    [
        ('test_id', 1),
        ('test_id', 2),
        ('test_id', 3),
        ('test_id', 4),
        ('test_id', 5),
        ('test_id', 6),
    ]
) == [1, 2, 3, 4, 5, 6]
	assert candidate(scenarios=[('01000000', 1), ('00000001', 0)]) == [1, 0]
	assert candidate(
    [("test_a", "a"), ("test_b", "b"), ("test_c", "c"), ("test_d", "d")]
) == ["a", "b", "c", "d"]
	assert candidate(
    [("test_a", "a"), ("test_b", "b"), ("test_c", "c")]
) == ["a", "b", "c"]
	assert candidate(scenarios=[('test_input_1', 1), ('test_input_2', 2)]) == [1, 2]
def test_check():
	check(scenario_ids)
