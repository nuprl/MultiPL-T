def dominantIndex(nums):
    """ 
     :type nums: List[int]
     :rtype: int
     """
	### Canonical solution below ###	
	if len(nums) == 1:
		return 0
	number=max(nums)
	index=nums.index(number)
	nums.remove(number)
	return index if number>=max(nums)*2 else -1

### Unit tests below ###
def check(candidate):
	assert candidate(nums = [1]) == 0
	assert candidate( [3,6,1,0] ) == 1
	assert candidate( [1, 1, 1, 2, 2] ) == -1
	assert candidate(nums = [1, 2, 3, 4]) == -1
	assert candidate( [2,2,2,2] ) == -1
	assert candidate( [0, 0, 0] ) == 0
	assert candidate( [1,2,3,3] ) == -1
	assert candidate(nums = [3, 6, 1, 0]) == 1
	assert candidate( [2, 1] ) == 0
	assert candidate( [1, 2, 3, 4, 5] ) == -1
	assert candidate( [1,2,2,3] ) == -1
	assert candidate( [1, 2, 3, 4] ) == -1
	assert candidate( [3, 6, 1, 0] ) == 1
	assert candidate( [3, 6, 1, 0, 2, 5, 4, 7] ) == -1
	assert candidate( [1,2,3,4] ) == -1
	assert candidate( [2, 0] ) == 0
	assert candidate( [1] ) == 0
def test_check():
	check(dominantIndex)
