def _ljust(input, width, fillchar=None):
    """ Either ljust on a string or a list of string. Extend with fillchar."""
	### Canonical solution below ###    
    if fillchar is None:
        fillchar = ' '
    if isinstance(input, str):
        return input.ljust(width, fillchar)
    else:
        delta_len = width - len(input)
        if delta_len <= 0:
            return input
        else:
            return input + [fillchar for _ in range(delta_len)]

### Unit tests below ###
def check(candidate):
	assert candidate([], 0) == []
	assert candidate('abcde', 5) == 'abcde'
	assert candidate([1, 2, 3], 5, 'x') == [1, 2, 3, 'x', 'x']
	assert candidate('x', 3) == 'x  '
	assert candidate('123', 19) == '123                '
	assert candidate('12345', 6, 'X') == '12345X'
	assert candidate('abc', 2) == 'abc'
	assert candidate('abc', 5, fillchar='0') == 'abc00'
	assert candidate([], 3, fillchar='-') == ['-', '-', '-']
	assert candidate(['a', 'b', 'c'], 5,'') == ['a', 'b', 'c','','']
	assert candidate('123', 6) == '123   '
	assert candidate('a', 3, '0') == 'a00'
	assert candidate('abcde', 2) == 'abcde'
	assert candidate('123', 5) == '123  '
	assert candidate('a', 3) == 'a  '
	assert candidate('foo', -3) == 'foo'
	assert candidate('123', 17) == '123              '
	assert candidate('a', 2, '0') == 'a0'
	assert candidate(['a', 'b', 'c'], 2) == ['a', 'b', 'c']
	assert candidate('12345', 6) == '12345 '
	assert candidate('10', 1) == '10'
	assert candidate('123', 13) == '123          '
	assert candidate('123', 5, 'x') == '123xx'
	assert candidate('1', 2, 'X') == '1X'
	assert candidate('123', 15) == '123            '
	assert candidate(['a', 'b', 'c'], 2, '-') == ['a', 'b', 'c']
	assert candidate('abc', 11) == 'abc        '
	assert candidate('abc', 6) == 'abc   '
	assert candidate(['10'], 5, '*') == ['10', '*', '*', '*', '*']
	assert candidate(['a', 'b', 'c'], 3) == ['a', 'b', 'c']
	assert candidate('abcde', 5, '_') == 'abcde'
	assert candidate('a', 1) == 'a'
	assert candidate('123', 14) == '123           '
	assert candidate('abc', 10) == 'abc       '
	assert candidate(['a', 'b', 'c'], 3, 0)
	assert candidate('10', 0) == '10'
	assert candidate('a', 5) == 'a    '
	assert candidate('abc', 4) == 'abc '
	assert candidate('abc', 1) == 'abc'
	assert candidate('a', 2, '_') == 'a_'
	assert candidate('hello', 10, 'a') == 'helloaaaaa'
	assert candidate('abc', 3) == 'abc'
	assert candidate('123', 18) == '123               '
	assert candidate('10', 2) == '10'
	assert candidate([1,2,3,4,5], 5) == [1,2,3,4,5]
	assert candidate('test', 5, '-') == 'test-'
	assert candidate('abc', 5, fillchar='-') == 'abc--'
	assert candidate('123', 8) == '123     '
	assert candidate(['10'], 5, '') == ['10', '', '', '', '']
	assert candidate('a', 5, '-') == 'a----'
	assert candidate('foo', -5) == 'foo'
	assert candidate('abc', 8) == 'abc     '
	assert candidate('123', 20) == '123                 '
	assert candidate('abc', 7) == 'abc    '
	assert candidate('hello', 10) == 'hello     '
	assert candidate('123', 4) == '123 '
	assert candidate('x', 4) == 'x   '
	assert candidate('', 2, '-') == '--'
	assert candidate('ab', 3, '0') == 'ab0'
	assert candidate('123', 11) == '123        '
	assert candidate(['a', 'b', 'c'], 5, fillchar='0') == ['a', 'b', 'c', '0', '0']
	assert candidate(['f', 'o', 'o'], 5, '0') == ['f', 'o', 'o', '0', '0']
	assert candidate('abc', 2, '-') == 'abc'
	assert candidate('1', 2) == '1 '
	assert candidate('123', 16) == '123             '
	assert candidate('a', 2) == 'a '
	assert candidate(['10'], 0) == ['10']
	assert candidate([10], 5, '*') == [10, '*', '*', '*', '*']
	assert candidate('foo', 1) == 'foo'
	assert candidate(['10'], 1) == ['10']
	assert candidate('abc', 9) == 'abc      '
	assert candidate('123', 7) == '123    '
	assert candidate('123', 9) == '123      '
	assert candidate('ab', 3) == 'ab '
	assert candidate('test', 5) == 'test '
	assert candidate('hello', 5) == 'hello'
	assert candidate('abc', 5) == 'abc  '
	assert candidate('123', 12) == '123         '
	assert candidate('abc', -1) == 'abc'
	assert candidate('foo', 2) == 'foo'
	assert candidate('foo', -2) == 'foo'
	assert candidate('foo', 5) == 'foo  '
	assert candidate('123', 10) == '123       '
	assert candidate('foo', 2, '0') == 'foo'
	assert candidate('123', 2) == '123'
	assert candidate('', 0, '-') == ''
	assert candidate('foo', -1) == 'foo'
	assert candidate('abc', 5, '-') == 'abc--'
	assert candidate('foo', 3) == 'foo'
	assert candidate('abc', 3, '0') == 'abc'
	assert candidate('', 0) == ''
	assert candidate([1,2,3], 5, '0') == [1,2,3, '0', '0']
	assert candidate([], 0, '-') == []
def test_check():
	check(_ljust)
