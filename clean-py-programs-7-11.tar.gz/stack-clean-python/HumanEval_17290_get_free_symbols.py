def get_free_symbols(s, symbols, free_symbols=None):
    """
    Returns free_symbols present in `s`.
    """
    ### Canonical solution below ###
    free_symbols = free_symbols or []
    if not isinstance(s, list):
        if s in symbols:
            free_symbols.append(s)
        return free_symbols

    for i in s:
        free_symbols = get_free_symbols(i, symbols, free_symbols)

    return free_symbols


### Unit tests below ###
def check(candidate):
	assert candidate(1, [2]) == []
	assert candidate(2, [5, 6, 4, 3, 2]) == [2]
	assert candidate([1, [2, 3]], [2, 3]) == [2, 3]
	assert candidate('a', ['a', 'b']) == ['a']
	assert candidate([1, [2, 3]], [1, 3]) == [1, 3]
	assert candidate(2, [2, 3, 4]) == [2]
	assert candidate(2, [4, 5, 6, 3, 2]) == [2]
	assert candidate([1, [2, 3]], [3]) == [3]
	assert candidate(2, [3, 4, 5, 6, 2]) == [2]
	assert candidate(1, ['a', 'b']) == []
	assert candidate(2, [4, 5, 3, 2]) == [2]
	assert candidate(2, [3, 4, 2]) == [2]
	assert candidate([1, 2], [3]) == []
	assert candidate(
    [[[1, 2], [3, 4]], [[5, 6], [7, 8]]],
    [1, 2, 3, 4, 5, 6, 7, 8]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(2, [4, 3, 2]) == [2]
	assert candidate([1, [2, 3]], [4]) == []
	assert candidate('a+b', ['a', 'b']) == []
	assert candidate([1, 2], [2]) == [2]
	assert candidate(2, [3, 4, 5, 2]) == [2]
	assert candidate(2, [5, 4, 3, 2]) == [2]
	assert candidate(None, ['a', 'b']) == []
	assert candidate([3, 2, 1], [1, 2, 3]) == [3, 2, 1]
	assert candidate([1, 2, 3], [4, 5, 6]) == []
	assert candidate(2, [6, 5, 4, 3, 2]) == [2]
	assert candidate([1, 2, 3], [4, 5, 6, 3]) == [3]
	assert candidate('b', ['a', 'b']) == ['b']
	assert candidate('c', ['a', 'b']) == []
	assert candidate(2, [2, 3, 4, 5, 6]) == [2]
	assert candidate(1, []) == []
	assert candidate(2, [2, 3, 4, 5]) == [2]
	assert candidate(1, [1]) == [1]
	assert candidate([1, [2, 3]], [2]) == [2]
def test_check():
	check(get_free_symbols)
