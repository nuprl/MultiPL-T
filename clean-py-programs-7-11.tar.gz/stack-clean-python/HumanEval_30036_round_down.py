def round_down(x,step):
    """Rounds x down to the next multiple of step."""
    ### Canonical solution below ###
    from math import floor
    if step == 0: return x
    return floor(float(x)/float(step))*step


### Unit tests below ###
def check(candidate):
	assert candidate(11,1) == 11
	assert candidate(-10.0,5) == -10.0
	assert candidate(10,3) == 9
	assert candidate(0,100) == 0
	assert candidate(123,0) == 123
	assert candidate(123456789,10) == 123456780
	assert candidate(29,2) == 28
	assert candidate(1,3) == 0
	assert candidate(7,3) == 6
	assert candidate(9,3) == 9
	assert candidate(-1,0) == -1
	assert candidate(12,10) == 10
	assert candidate(8,3) == 6
	assert candidate(2,1) == 2
	assert candidate(12,2) == 12
	assert candidate(1000,100) == 1000
	assert candidate(-5,2) == -6
	assert candidate(123,10000) == 0
	assert candidate(11,4) == 8
	assert candidate(-10,-10) == -10
	assert candidate(7,1) == 7
	assert candidate(-6,2) == -6
	assert candidate(12,12) == 12
	assert candidate(6,0) == 6
	assert candidate(27,2) == 26
	assert candidate(0,-1) == 0
	assert candidate(12,3) == 12
	assert candidate(15,10) == 10
	assert candidate(7, 2) == 6
	assert candidate(22,2) == 22
	assert candidate(23,2) == 22
	assert candidate(17,5) == 15
	assert candidate(34,2) == 34
	assert candidate(1, 3) == 0
	assert candidate(123456789,100000000) == 100000000
	assert candidate(8,1) == 8
	assert candidate(13,1) == 13
	assert candidate(23,1) == 23
	assert candidate(11,10) == 10
	assert candidate(5,5) == 5
	assert candidate(2,0) == 2
	assert candidate(3, 1) == 3
	assert candidate(11,3) == 9
	assert candidate(123,100) == 100
	assert candidate(15,3) == 15
	assert candidate(25,2) == 24
	assert candidate(16,2) == 16
	assert candidate(123456789,10000000) == 120000000
	assert candidate(10,4) == 8
	assert candidate(19,5) == 15
	assert candidate(123,1000) == 0
	assert candidate(123, 100) == 100
	assert candidate(6,1) == 6
	assert candidate(-1, 10) == -10
	assert candidate(6,3) == 6
	assert candidate(0,4) == 0
	assert candidate(5,2) == 4
	assert candidate(28,2) == 28
	assert candidate(21,2) == 20
	assert candidate(123,100000) == 0
	assert candidate(123456789,10000) == 123450000
	assert candidate(101,100) == 100
	assert candidate(123,2) == 122
	assert candidate(12,1) == 12
	assert candidate(8,2) == 8
	assert candidate(-99,10) == -100
	assert candidate(-15,5) == -15
	assert candidate(10,2) == 10
	assert candidate(100,10) == 100
	assert candidate(123,10) == 120
	assert candidate(19,1) == 19
	assert candidate(21, 10) == 20
	assert candidate(10000,2) == 10000
	assert candidate(123456789,100) == 123456700
	assert candidate(100,100) == 100
	assert candidate(2, 2) == 2
	assert candidate(26,2) == 26
	assert candidate(-1,2) == -2
	assert candidate(14,3) == 12
	assert candidate(-100,10) == -100
	assert candidate(-11,10) == -20
	assert candidate(15.5,5) == 15.0
	assert candidate(20,1) == 20
	assert candidate(4,0) == 4
	assert candidate(5.0,5) == 5.0
	assert candidate(4, 2) == 4
	assert candidate(12, 10) == 10
	assert candidate(13,4) == 12
	assert candidate(11,2) == 10
	assert candidate(-3,0) == -3
	assert candidate(10.5,5) == 10.0
	assert candidate(1,1) == 1
	assert candidate(2, 1) == 2
	assert candidate(7,2) == 6
	assert candidate(22,1) == 22
	assert candidate(9,5) == 5
	assert candidate(6,2) == 6
	assert candidate(3,0) == 3
	assert candidate(0, 10) == 0
	assert candidate(10,1) == 10
	assert candidate(1, 1) == 1
	assert candidate(27,1) == 27
	assert candidate(12,5) == 10
	assert candidate(0,10) == 0
	assert candidate(24,1) == 24
	assert candidate(5,0) == 5
	assert candidate(-11,-10) == -10
	assert candidate(1, 2) == 0
	assert candidate(11.0,5) == 10.0
	assert candidate(1, 0) == 1
	assert candidate(10, 10) == 10
	assert candidate(0,3) == 0
	assert candidate(18,2) == 18
	assert candidate(123456789,100000) == 123400000
	assert candidate(10000,1) == 10000
	assert candidate(22, 10) == 20
	assert candidate(21,1) == 21
	assert candidate(123456789,1000000) == 123000000
	assert candidate(123, 10) == 120
	assert candidate(2,3) == 0
	assert candidate(30,2) == 30
	assert candidate(25,1) == 25
	assert candidate(3, 3) == 3
	assert candidate(1,2) == 0
	assert candidate(123456789,0) == 123456789
	assert candidate(5,1) == 5
	assert candidate(-1,1) == -1
	assert candidate(3,3) == 3
	assert candidate(4,1) == 4
	assert candidate(14,1) == 14
	assert candidate(17,3) == 15
	assert candidate(5,6) == 0
	assert candidate(3,2) == 2
	assert candidate(33,2) == 32
	assert candidate(14,2) == 14
	assert candidate(-11.5,5) == -15
	assert candidate(-10, 10) == -10
	assert candidate(-2,2) == -2
	assert candidate(4,4) == 4
	assert candidate(5,4) == 4
	assert candidate(15,2) == 14
	assert candidate(4,3) == 3
	assert candidate(-12, 10) == -20
	assert candidate(-16,5) == -20
	assert candidate(18,1) == 18
	assert candidate(20, 10) == 20
	assert candidate(9,2) == 8
	assert candidate(10,10) == 10
	assert candidate(-5,0) == -5
	assert candidate(-2,0) == -2
	assert candidate(15.0,5) == 15.0
	assert candidate(31,2) == 30
	assert candidate(-12,10) == -20
	assert candidate(-11,5) == -15
	assert candidate(18,5) == 15
	assert candidate(12,0) == 12
	assert candidate(-11, 10) == -20
	assert candidate(90,10) == 90
	assert candidate(13,3) == 12
	assert candidate(17,2) == 16
	assert candidate(123456789,1) == 123456789
	assert candidate(16,1) == 16
	assert candidate(12,4) == 12
	assert candidate(0,5) == 0
	assert candidate(0,1) == 0
	assert candidate(0,0) == 0
	assert candidate(15,1) == 15
	assert candidate(10.0,5) == 10.0
	assert candidate(11, 10) == 10
	assert candidate(17,1) == 17
	assert candidate(-4,0) == -4
	assert candidate(-4,2) == -4
	assert candidate(5.5,5) == 5.0
	assert candidate(-10,5) == -10
	assert candidate(20,5) == 20
	assert candidate(20,2) == 20
	assert candidate(10000,100) == 10000
	assert candidate(3, 2) == 2
	assert candidate(10,5) == 10
	assert candidate(10,7) == 7
	assert candidate(15,5) == 15
	assert candidate(16,3) == 15
	assert candidate(0,-10) == 0
	assert candidate(-10,10) == -10
	assert candidate(1,0) == 1
	assert candidate(6, 2) == 6
	assert candidate(32,2) == 32
	assert candidate(13,2) == 12
	assert candidate(12,6) == 12
	assert candidate(5, 2) == 4
	assert candidate(10000,0) == 10000
	assert candidate(11,5) == 10
	assert candidate(-6,0) == -6
	assert candidate(19,2) == 18
	assert candidate(123456789,1000) == 123456000
	assert candidate(24,2) == 24
	assert candidate(2,2) == 2
	assert candidate(10,0) == 10
	assert candidate(100,0) == 100
	assert candidate(26,1) == 26
	assert candidate(0,2) == 0
	assert candidate(1,100) == 0
	assert candidate(123,1) == 123
	assert candidate(-123, 100) == -200
	assert candidate(16.0,5) == 15.0
	assert candidate(-123, 10) == -130
	assert candidate(9,1) == 9
	assert candidate(3,1) == 3
	assert candidate(-100,-10) == -100
	assert candidate(-3,2) == -4
	assert candidate(5,3) == 3
	assert candidate(100,1) == 100
	assert candidate(123,1000000) == 0
	assert candidate(16,5) == 15
	assert candidate(4,2) == 4
def test_check():
	check(round_down)
