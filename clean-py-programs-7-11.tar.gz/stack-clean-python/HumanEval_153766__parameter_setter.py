def _parameter_setter(param, env_variable, default):
    """Returns value according to the provided data.

    Args:
        param: Constructor parameter value
        env_variable: Environment variable related to the parameter
        default: Constructor parameter default value
    """
    ### Canonical solution below ###
    if param is None:
        res = env_variable or default
    else:
        res = param

    return res


### Unit tests below ###
def check(candidate):
	assert candidate(None, None, 'default') == 'default'
	assert candidate(None, 'a', 'b') == 'a'
	assert candidate(None, None, '2') == '2'
	assert candidate(None, 'ENV', 'default') == 'ENV'
	assert candidate("bar", None, "foo") == "bar"
	assert candidate(1, None, 10) == 1
	assert candidate(None, None, 'b') == 'b'
	assert candidate(None, "foo", 42) == "foo"
	assert candidate("PARAM", None, "DEFAULT") == "PARAM"
	assert candidate('test', 'test', None) == 'test'
	assert candidate(None, None, 'test_default') == 'test_default'
	assert candidate('test', 'test', 'default') == 'test'
	assert candidate("param", "test", 1) == "param"
	assert candidate(None, None, 'test') == 'test'
	assert candidate('param', None, 'default') == 'param'
	assert candidate(None, None, "DEFAULT") == "DEFAULT"
	assert candidate(1, "test", 42) == 1
	assert candidate(None, "baz", "foo") == "baz"
	assert candidate(2, None, 1) == 2
	assert candidate(None, 'TEST', 2) == 'TEST'
	assert candidate('constructor', 'ENV', 'default') == 'constructor'
	assert candidate(None, None, 0) == 0
	assert candidate(1, '1', 10) == 1
	assert candidate(None, None, 1) == 1
	assert candidate(None, 10, 1) == 10
	assert candidate(None, None, 42) == 42
	assert candidate(None, "x", 1) == "x"
	assert candidate('test', 'test', 'test') == 'test'
	assert candidate('test', None, None) == 'test'
	assert candidate(None, None, "foo") == "foo"
	assert candidate(1, 'var', 2) == 1
	assert candidate(None, 'test', 'test') == 'test'
	assert candidate(None, None, None) is None
	assert candidate(None, "test", "default") == "test"
	assert candidate(1, 10, 1) == 1
	assert candidate(1, 'test', 2) == 1
	assert candidate(None, None, "default") == "default"
	assert candidate(1, None, 0) == 1
	assert candidate("foo", "bar", "baz") == "foo"
	assert candidate(1, '1', 0) == 1
	assert candidate(None, 'test', 'test_default') == 'test'
	assert candidate(None, None, 'bar') == 'bar'
	assert candidate('1', '1', 0) == '1'
	assert candidate(1, 'a', 'b') == 1
	assert candidate(1, 2, 3) == 1
	assert candidate(None, "test", 1) == "test"
	assert candidate(1, "1", 2) == 1
	assert candidate('1', '1', 10) == '1'
	assert candidate(None, 'test', None) == 'test'
	assert candidate(None, "HELLO", 5) == "HELLO"
	assert candidate('3', None, '2') == '3'
	assert candidate('foobar', None, 'bar') == 'foobar'
	assert candidate(None, '1', '2') == '1'
	assert candidate(None, 'var', 2) == 'var'
	assert candidate(0, None, 1) == 0
	assert candidate(None, None, "baz") == "baz"
	assert candidate(10, "HELLO", 5) == 10
	assert candidate(None, 'test_env', 'test_default') == 'test_env'
	assert candidate('foobar', 'baz', 'bar') == 'foobar'
	assert candidate(1, None, None) == 1
	assert candidate('test', None, 'test') == 'test'
	assert candidate(None, 'var', None) == 'var'
	assert candidate('constructor', None, 'default') == 'constructor'
	assert candidate('test_param', None, 'test_default') == 'test_param'
	assert candidate("bar", "foo", 42) == "bar"
	assert candidate(1, "test", "default") == 1
	assert candidate(None, None, 10) == 10
	assert candidate("PARAM", "TEST_ENV_VAR", "DEFAULT") == "PARAM"
	assert candidate(None, "1", 1) == "1"
	assert candidate(1, "test", 2) == 1
	assert candidate(1, 'TEST', 2) == 1
	assert candidate(None, 2, 3) == 2
	assert candidate('1', None, 0) == '1'
	assert candidate(0, "x", 1) == 0
	assert candidate(None, "1", None) == "1"
	assert candidate("bar", "baz", "foo") == "bar"
	assert candidate(None, '1', 0) == '1'
	assert candidate(None, None, 2) == 2
	assert candidate(1, None, 2) == 1
	assert candidate('test_param', 'test_env', 'test_default') == 'test_param'
	assert candidate(None, '1', 2) == '1'
	assert candidate(None, 'test', 'default') == 'test'
	assert candidate(None, None, 5) == 5
	assert candidate(None, 'env_variable', 'default') == 'env_variable'
	assert candidate("PARAM", "ENV_VAR", "DEFAULT") == "PARAM"
	assert candidate(10, None, 5) == 10
def test_check():
	check(_parameter_setter)
