def lines_are_parallel(line_1, line_2) -> bool:
    """Determine if line_1 and line_2 are parallel.

    line_1 = [a,b,c]
    line_2 = [a,b,c]   
    """
    ### Canonical solution below ###
    slope_line_1 = line_1[0] // line_1[1]
    slope_line_2 = line_2[0] // line_2[1]

    if slope_line_1 == slope_line_2:
        return True
    return False


### Unit tests below ###
def check(candidate):
	assert candidate(
    [1, 3, 5], [1, 1, 5]
) == False
	assert candidate(
    [1, 3, 5], [3, 2, 5]
) == False
	assert candidate(
    [1, 3, 5], [3, 2, 7]
) == False
	assert candidate(
    [3, 4, 5],
    [1, 2, 3]) == True
	assert candidate(
    [1, 3, 5], [3, 2, 3]
) == False
	assert candidate(line_1=[1, 2, 3], line_2=[2, 4, 6]) == True
	assert candidate( [1, 2, 3], [1, 2, 3] ) == True
	assert candidate( [1, 2, 3], [3, 4, 5] ) == True
	assert candidate(
    [1, 2, 3],
    [2, 4, 6]
) == True
	assert candidate(
    [1, 3, 5], [3, 1, 7]
) == False
	assert candidate(
    [1, 2, 3],
    [4, 8, 12]
) == True
	assert candidate(
    [1, 2, 3],
    [3, 6, 9]
) == True
	assert candidate(
    [0, 1, 1],
    [0, 1, 2]
) == True
	assert candidate(
    [1, 2, 3], [2, 4, 6]) == True
	assert candidate(
    [1, 2, 1],
    [2, 4, 2]) == True
	assert candidate(
    [0, 1, 1],
    [1, 1, 1]
) == False
	assert candidate(
    [1, 1, 1],
    [1, 1, 1]) == True
	assert candidate(
    [1, 3, 5], [3, 2, 1]
) == False
	assert candidate(line_1 = [0, 1, 1], line_2 = [1, 1, 2]) == False
	assert candidate(
    [0, 1, 1],
    [0, 1, 1]
) == True
	assert candidate(
    [1, 3, 5], [1, 1, 3]
) == False
	assert candidate(
    [1, 3, 5], [3, 1, 1]
) == False
	assert candidate( [1, 1, 1], [2, 2, 2] ) == True
	assert candidate(
    [1, 1, 1],
    [1, 1, 1]
) == True
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]
) == True
	assert candidate(
    [1, 3, 5], [1, 3, 5]
) == True
	assert candidate(
    [1, 1, 0],
    [1, 1, 1]
) == True
def test_check():
	check(lines_are_parallel)
