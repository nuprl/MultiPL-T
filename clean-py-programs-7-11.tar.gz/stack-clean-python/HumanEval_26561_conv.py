def conv(value, fromLow=0, fromHigh=0, toLow=0, toHigh=0, func=None):
    """ Re-maps a number from one range to another. That is, a value of fromLow would get mapped to toLow, a value of fromHigh to toHigh, values in-between to values in-between, etc.
     
     Does not constrain values to within the range, because out-of-range values are sometimes intended and useful. The constrain() function may be used either before or after this function, if limits to the ranges are desired.
     
     Note that the "lower bounds" of either range may be larger or smaller than the "upper bounds" so the conv() function may be used to reverse a range of numbers, for example
     y = conv(x, 1, 50, 50, 1)
     
     The function also handles negative numbers well, so that this example
     y = conv(x, 1, 50, 50, -100)
     is also valid and works well.
     
     :param value:    the number to map
     :param fromLow:  the lower bound of the value's current range
     :param fromHigh: the upper bound of the value's current range
     :param toLow:    the lower bound of the value's target range
     :param toHigh:   the upper bound of the value's target range
     :param func:     function to be applied on result
     :return:         The mapped value."""
	### Canonical solution below ###    
    result = (value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow) + toLow
    if func is None:
        return result
    else:
        return func(result)

### Unit tests below ###
def check(candidate):
	assert candidate(12, 0, 100, 0, 10) == 1.2
	assert candidate(-3, 0, 10, 0, 100, round) == -30
	assert candidate(0, 0, 1023, 0, 100) == 0
	assert candidate(100, 0, 100, 0, 200) == 200
	assert candidate(0, 0, 1, 100, -100) == 100
	assert candidate(1, 0, 10, 0, 100) == 10
	assert candidate(25, 0, 100, 0, 1) == 0.25
	assert candidate(100, 0, 100, 0, 10, round) == 10
	assert candidate(0, 0, 1, 0, 100, round) == 0
	assert candidate(10, 0, 10, 20, 10) == 10.0
	assert candidate(-50, -100, 0, -100, -200) == -150
	assert candidate(10, 0, 10, 0, 100, lambda x: -x) == -100
	assert candidate(0, 0, 1, 0, 100, int) == 0
	assert candidate(0, 0, 1, 100, 0) == 100
	assert candidate(5, 0, 10, 100, 0) == 50
	assert candidate(10, 0, 10, 0, 10) == 10
	assert candidate(0, 0, 10, -100, 0) == -100
	assert candidate(-50, -100, 0, -100, -100) == -100
	assert candidate(0.5, 0, 1, 0, 100) == 50
	assert candidate(-100, 0, 100, 0, 200) == -200
	assert candidate(0, 0, 10, 0, 1) == 0.0
	assert candidate(5, 0, 10, 0, 20) == 10
	assert candidate(0, 0, 10, 10, 11) == 10
	assert candidate(255, 0, 255, 0, -100) == -100
	assert candidate(5, 0, 10, 0, 10, lambda x: -10) == -10
	assert candidate(35, 0, 100, 0, 100) == 35
	assert candidate(1023, 0, 1023, 0, 100) == 100
	assert candidate(0, 0, 10, 10, 10) == 10.0
	assert candidate(10, 0, 10, 0, -100) == -100
	assert candidate(1, 0, 1, 100, -100) == -100
	assert candidate(10, 0, 10, 1, 0, int) == 0
	assert candidate(10, 0, 10, 0, 10, round) == 10
	assert candidate(0, -100, 100, 0, 100) == 50
	assert candidate(10, 0, 10, 0, 20) == 20
	assert candidate(50, 0, 100, 0, 1, abs) == 0.5
	assert candidate(50, 0, 100, -100, 0) == -50
	assert candidate(0, 0, 100, 0, 10) == 0
	assert candidate(5, 0, 10, 0, 10, abs) == 5
	assert candidate(5, 0, 10, 10, 10) == 10.0
	assert candidate(5, 0, 10, 0, 1) == 0.5
	assert candidate(50, 0, 100, -100, -200) == -150
	assert candidate(75, 0, 100, 0, 1) == 0.75
	assert candidate(-10, -10, 10, -10, 10) == -10
	assert candidate(10, 0, 10, 10, 20) == 20.0
	assert candidate(100, 0, 100, 0, 1) == 1
	assert candidate(0, 0, 10, 100, 0) == 100
	assert candidate(-3, -5, 5, -10, 10, int) == -6
	assert candidate(50.6, 0, 100, 0, 100, int) == 50
	assert candidate(5, 0, 10, 0, 10, int) == 5
	assert candidate(3, 0, 5, 0, 10, round) == 6
	assert candidate(255, 0, 255, 0, 100) == 100
	assert candidate(5, 0, 10, 0, 10, lambda x: 0) == 0
	assert candidate(-1, 0, 10, 0, 100) == -10
	assert candidate(100, -100, 100, 0, 100) == 100
	assert candidate(50, 0, 100, 0, 200) == 100
	assert candidate(10, 0, 10, 10, -10) == -10.0
	assert candidate(5, 0, 10, 10, 11) == 10.5
	assert candidate(0.5, 0, 1, 0, 100, round) == 50
	assert candidate(10, 0, 10, 0, 1, int) == 1
	assert candidate(5, 0, 10, 10, 0) == 5.0
	assert candidate(5, 0, 10, 1, 0) == 0.5
	assert candidate(10, 0, 10, 0, 100, abs) == 100
	assert candidate(10, 0, 100, 0, 1) == 0.1
	assert candidate(50, 0, 100, 0, 1, int) == 0
	assert candidate(10, 0, 10, 0, 10, int) == 10
	assert candidate(0, 0, 10, -10, 10) == -10
	assert candidate(50, 0, 100, 0, 100) == 50
	assert candidate(50, 0, 100, -100, -100) == -100
	assert candidate(5, 0, 10, 0, 100) == 50
	assert candidate(-50, -100, 0, 0, 100) == 50
	assert candidate(3, 0, 5, 0, 10, int) == 6
	assert candidate(-50, -100, 0, -100, 0) == -50
	assert candidate(5, 0, 10, -10, -20) == -15
	assert candidate(255, 0, 255, 0, 255) == 255
	assert candidate(-3, -5, 5, -10, 10, lambda x: x * 2) == -12
	assert candidate(0, 0, 10, 0, 2) == 0.0
	assert candidate(0, 0, 100, 0, 100) == 0
	assert candidate(100, 0, 100, 0, 10) == 10
	assert candidate(3, 0, 5, 0, 10, lambda x: x * 2) == 12
	assert candidate(0, 0, 1, 0, 100) == 0
	assert candidate(-3, -5, 5, -10, 10) == -6
	assert candidate(1, 0, 1, 0, 100, round) == 100
	assert candidate(50, 0, 100, 0, 1) == 0.5
	assert candidate(35, 0, 100, 0, 100, abs) == 35
	assert candidate(100, 0, 100, 0, 10, int) == 10
	assert candidate(0, 0, 10, 0, 10) == 0
	assert candidate(10, 0, 10, 10, 10) == 10.0
	assert candidate(100, 0, 100, 0, 10, lambda x: x+1) == 11
	assert candidate(10, 0, 10, 0, 10, lambda x: round(x)) == 10
	assert candidate(0, 0, 10, 0, 10) == 0.0
	assert candidate(10, 0, 10, 0, 1) == 1
	assert candidate(5, 0, 10, 0, 100, int) == 50
	assert candidate(100, 0, 100, 0, 10, lambda x: x/2) == 5
	assert candidate(3, 0, 10, 0, 10, int) == 3
	assert candidate(0.5, 0, 1, 100, 0) == 50
	assert candidate(10, -10, 10, -10, 10) == 10
	assert candidate(3, 0, 10, 0, 10, lambda x: round(x)) == 3
	assert candidate(-3, -5, 5, -10, 10, abs) == 6
	assert candidate(10, 0, 10, 0, 100, lambda x: x * 2) == 200
	assert candidate(3, 0, 10, 0, 10, lambda x: int(round(x))) == 3
	assert candidate(5, 0, 10, 0, 10, lambda x: 10) == 10
	assert candidate(0, 0, 10, 0, 1) == 0
	assert candidate(1, 0, 1, 0, 100) == 100
	assert candidate(5, 0, 10, 0, 10) == 5
	assert candidate(5, 0, 10, -100, 0) == -50
	assert candidate(10, 0, 10, 0, 10, lambda x: int(round(x))) == 10
	assert candidate(50, 0, 100, 0, 200, round) == 100
	assert candidate(3, 0, 10, 0, 10, round) == 3
	assert candidate(1, 0, 1, 0, 100, int) == 100
	assert candidate(10, 0, 10, -100, 0) == 0
	assert candidate(-3, 0, 10, 0, 100) == -30
	assert candidate(10, 0, 10, 10, 11) == 11
	assert candidate(-3, -5, 5, -10, 10, round) == -6
	assert candidate(0, 0, 10, 0, 20) == 0
	assert candidate(10, 0, 10, 0, 1, abs) == 1
	assert candidate(5, 0, 10, 0, 10, round) == 5
	assert candidate(-100, -100, 100, 0, 100) == 0
	assert candidate(5, 0, 10, 10, 20) == 15
	assert candidate(5, 0, 10, 10, -10) == 0.0
	assert candidate(0, 0, 100, 0, 1) == 0
	assert candidate(5, 0, 10, 0, -100) == -50
	assert candidate(5, 0, 10, -10, 10) == 0
	assert candidate(255, 0, 255, 0, 255, abs) == 255
	assert candidate(-12, -100, 0, 0, 10) == 8.8
	assert candidate(10, 0, 10, -10, 10) == 10
	assert candidate(3, 0, 10, 0, 100) == 30
	assert candidate(10, 0, 10, 100, 0) == 0
	assert candidate(5, 0, 10, -10, 0) == -5
	assert candidate(3, 0, 10, 0, 100, round) == 30
	assert candidate(100, 0, 100, 0, 100) == 100
	assert candidate(0, 0, 10, 0, 100) == 0
	assert candidate(0.5, 0, 1, 0, 100, int) == 50
	assert candidate(3, 0, 10, 0, 10) == 3
	assert candidate(-3, 0, 5, 0, 10) == -6
	assert candidate(1, 0, 1, 100, 0) == 0
	assert candidate(10, 0, 10, 0, 100) == 100
	assert candidate(100, 0, 100, 0, 200, round) == 200
	assert candidate(3, 0, 5, 0, 10, abs) == 6
	assert candidate(100, 0, 100, 0, 10, lambda x: x*2) == 20
	assert candidate(3, 0, 5, 0, 10) == 6
def test_check():
	check(conv)
