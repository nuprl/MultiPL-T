def findMinHeightTrees(n, edges):
    """ 
     :type n: int
     :type edges: List[List[int]]
     :rtype: List[int]
     """
	### Canonical solution below ###    
    if not edges or n==1:
        return [0]
    adj=[set() for i in range(n)]
    for i,j in edges:
        adj[i].add(j)
        adj[j].add(i)
    leaves=[nodeIndex for nodeIndex in range(n) if len(adj[nodeIndex])==1]
    while n>2:
        n-=len(leaves)
        newLeaves=[]
        for leaf in leaves:
            adjLeaf=adj[leaf].pop()
            adj[adjLeaf].remove(leaf)
            if len(adj[adjLeaf])==1:
                newLeaves.append(adjLeaf)
        leaves=newLeaves
    return leaves

### Unit tests below ###
def check(candidate):
	assert candidate(3, [[0, 1], [0, 2]]) == [0]
	assert candidate(6, [[3,0],[3,1],[3,2],[3,4],[5,4]]) == [3, 4]
	assert candidate(6, [[0, 3], [1, 3], [2, 3], [4, 3], [5, 4]]) == [3, 4]
	assert candidate(2, [[0,1]]) == [0,1]
	assert candidate(4, [[1,0],[1,2],[1,3]]) == [1]
	assert candidate(6, [[3,0],[3,1],[3,2],[3,4],[5,4]]) == [3,4]
	assert candidate(4, [[1, 0], [1, 2], [1, 3]]) == [1]
	assert candidate(2, [[0, 1]]) == [0, 1]
	assert candidate(3, [[0,1],[1,2]]) == [1]
	assert candidate(1, []) == [0]
	assert candidate(6, [[0,3],[1,3],[2,3],[4,3],[5,4]]) == [3,4]
	assert candidate(3, [[0, 1], [1, 2]]) == [1]
	assert candidate(6, [[3, 0], [3, 1], [3, 2], [3, 4], [5, 4]]) == [3, 4]
def test_check():
	check(findMinHeightTrees)
