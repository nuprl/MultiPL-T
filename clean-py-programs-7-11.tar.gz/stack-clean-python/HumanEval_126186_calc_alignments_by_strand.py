def calc_alignments_by_strand(fwd_rvs_align_list):
    """ 
     :param fwd_rvs_align_list: list of sorted forwards and reverse alignments
     :return: Total RPMR aligned for fwd and rvs strands (float)
     """
	### Canonical solution below ###    
    sorted_fwd_alignment = fwd_rvs_align_list[0]
    sorted_rvs_alignment = fwd_rvs_align_list[1]
    fwd_align_count = 0
    rvs_align_count = 0
    for i in sorted_fwd_alignment:
        fwd_align_count += i[1]
    for i in sorted_rvs_alignment:
        rvs_align_count -= i[1]
    return fwd_align_count, rvs_align_count

### Unit tests below ###
def check(candidate):
	assert candidate(
    [[[20, 1], [19, 1], [18, 1]], [[10, 1], [9, 1], [8, 1]]]) == (3, -3)
	assert candidate(
    [[[20, 1], [19, 1], [18, 1]], [[10, 1], [9, 1], [8, 1]], [[20, 1], [19, 1], [18, 1]], [[10, 1], [9, 1], [8, 1]]]) == (3, -3)
	assert candidate(
    [[[20, 1], [19, 1], [18, 1]], [[10, 1], [9, 1], [8, 1]], [[20, 1], [19, 1], [18, 1]]]) == (3, -3)
	assert candidate(
    [[(1, 1), (2, 1), (3, 1), (4, 1), (5, 1)], [(1, 1), (2, 1), (3, 1), (4, 1), (5, 1)]]) == (5, -5)
def test_check():
	check(calc_alignments_by_strand)
