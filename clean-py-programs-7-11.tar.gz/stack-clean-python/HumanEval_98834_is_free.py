def is_free(board: list, pos: int) -> bool:
    """checks if pos is free or filled"""
    ### Canonical solution below ###
    return board[pos] == "  "


### Unit tests below ###
def check(candidate):
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 7) == True
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 0) == True
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 2) == True
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 1) == True
	assert candidate(
    ["X ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 0) == False
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 6) == True
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 8) == True
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 4) == True
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 5) == True
	assert candidate(
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "], 3) == True
def test_check():
	check(is_free)
