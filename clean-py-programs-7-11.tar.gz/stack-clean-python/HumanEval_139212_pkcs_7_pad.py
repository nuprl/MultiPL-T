def pkcs_7_pad(input_bytes: bytes, length: int):
    """ Takes in a byte string and an integer. Outputs a byte string padded to a block size of integer following PKCS7 standards"""
	### Canonical solution below ###    
    size_needed = length - (len(input_bytes) % length)
    padded_bytes = input_bytes + (bytes([size_needed]) * size_needed)

    return padded_bytes

### Unit tests below ###
def check(candidate):
	assert candidate(b'YELLOW SUBMARINE', 20) == b'YELLOW SUBMARINE\x04\x04\x04\x04'
	assert candidate(b'', 16) == b'\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10'
	assert candidate(b'YELLOW SUBMARINE', 20) == candidate(b'YELLOW SUBMARINE', 20)
	assert candidate(b"YELLOW SUBMARINE", 16) == b'YELLOW SUBMARINE\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10'
	assert candidate(b'YELLOW SUBMARINE', 20) == b'YELLOW SUBMARINE\x04\x04\x04\x04', "Incorrect padding"
	assert candidate(b'YELLOW SUBMARINE', 1) == b'YELLOW SUBMARINE\x01'
	assert candidate(b'YELLOW SUBMARINE', 20) == b'YELLOW SUBMARINE\x04\x04\x04\x04', "PKCS#7 padding failed"
	assert candidate(b'YELLOW SUBMARINE', 8) == b'YELLOW SUBMARINE\x08\x08\x08\x08\x08\x08\x08\x08'
	assert candidate(b'', 8) == b'\x08\x08\x08\x08\x08\x08\x08\x08'
	assert candidate(b'YELLOW SUBMARINE', 2) == b'YELLOW SUBMARINE\x02\x02'
	assert candidate(b'YELLOW SUBMARINE', 16) == b'YELLOW SUBMARINE\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10'
	assert candidate(b'YELLOW SUBMARINE', 20)!= candidate(b'YELLOW SUBMARINE', 25)
	assert candidate(b'YELLOW SUBMARINE', 20)!= candidate(b'YELLOW SUBMARINE', 15)
	assert candidate(b'YELLOW SUBMARINE', 8) == b'YELLOW SUBMARINE\x08\x08\x08\x08\x08\x08\x08\x08', "Incorrect padding"
	assert candidate(b"YELLOW SUBMARINE", 20) == b'YELLOW SUBMARINE\x04\x04\x04\x04'
	assert candidate(b"YELLOW SUBMARINE", 16) == b"YELLOW SUBMARINE\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10"
	assert candidate(b"YELLOW SUBMARINE", 20) == b"YELLOW SUBMARINE\x04\x04\x04\x04"
	assert candidate(b'a', 8) == b'a\x07\x07\x07\x07\x07\x07\x07'
def test_check():
	check(pkcs_7_pad)
