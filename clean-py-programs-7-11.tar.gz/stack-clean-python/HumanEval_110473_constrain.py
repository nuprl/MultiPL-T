def constrain(val: int, min_val: int, max_val: int) -> int:
    """Keeps val in the range of min_val and max_val"""
    ### Canonical solution below ###
    return min(max_val, max(min_val, val))


### Unit tests below ###
def check(candidate):
	assert candidate(0, 2, 7) == 2
	assert candidate(15, 1, 10) == 10
	assert candidate(10, 1, 5) == 5
	assert candidate(10, 100, 5) == 5
	assert candidate(10, 5, 100) == 10
	assert candidate(1000, 0, 100) == 100
	assert candidate(8, 3, 7) == 7
	assert candidate(-1, 1, 5) == 1
	assert candidate(10, 20, 20) == 20
	assert candidate(10, 0, 5) == 5
	assert candidate(5, 1, 3) == 3
	assert candidate(50, 10, 90) == 50
	assert candidate(0, 20, 30) == 20
	assert candidate(0, 2, 13) == 2
	assert candidate(0, 1, 5) == 1
	assert candidate(6, 1, 5) == 5
	assert candidate(10, 0, 10) == 10
	assert candidate(5, 2, 7) == 5
	assert candidate(-1, 0, 15) == 0
	assert candidate(5, 1, 5) == 5
	assert candidate(10, 1, 10) == 10
	assert candidate(10, 20, 2) == 2
	assert candidate(5, 0, 20) == 5
	assert candidate(100, 200, 200) == 200
	assert candidate(22, 0, 20) == 20
	assert candidate(0, 0, 20) == 0
	assert candidate(1, 1, 10) == 1
	assert candidate(10, 5, 5) == 5
	assert candidate(10, 2, 5) == 5
	assert candidate(2, 3, 7) == 3
	assert candidate(10, 15, 15) == 15
	assert candidate(2, 3, 10) == 3
	assert candidate(3, 1, 3) == 3
	assert candidate(5, 3, 7) == 5
	assert candidate(25, 0, 20) == 20
	assert candidate(-5, 0, 20) == 0
	assert candidate(0, 0, 10) == 0
	assert candidate(0, 1, 3) == 1
	assert candidate(5, 0, 10) == 5
	assert candidate(10, 10, 10) == 10
	assert candidate(10, 2, 10) == 10
	assert candidate(10, 0, 9) == 9
	assert candidate(1, 3, 10) == 3
	assert candidate(-1, 0, 100) == 0
	assert candidate(2, 1, 10) == 2
	assert candidate(10, 3, 10) == 10
	assert candidate(4, 1, 3) == 3
	assert candidate(10, 0, 20) == 10
	assert candidate(10, 0, 100) == 10
	assert candidate(2, 1, 3) == 2
	assert candidate(2, 5, 15) == 5
	assert candidate(5, 3, 10) == 5
	assert candidate(20, 20, 30) == 20
	assert candidate(14, 2, 13) == 13
	assert candidate(10, 5, 10) == 10
	assert candidate(30, 20, 30) == 30
	assert candidate(12, 2, 12) == 12
	assert candidate(11, 1, 10) == 10
	assert candidate(10, 10, 90) == 10
	assert candidate(16, 5, 15) == 15
	assert candidate(12, 12, 13) == 12
	assert candidate(10, 0, 15) == 10
	assert candidate(5, 1, 10) == 5
	assert candidate(10, 2, 2) == 2
	assert candidate(20, 1, 10) == 10
	assert candidate(100, 100, 100) == 100
	assert candidate(1, 1, 3) == 1
	assert candidate(12, 2, 13) == 12
	assert candidate(10, 5, 15) == 10
	assert candidate(12, 3, 10) == 10
	assert candidate(100, 50, 100) == 100
	assert candidate(0, 1, 10) == 1
	assert candidate(200, 10, 90) == 90
	assert candidate(-1, 0, 20) == 0
	assert candidate(100, 50, 200) == 100
	assert candidate(8, 2, 7) == 7
	assert candidate(40, 20, 30) == 30
	assert candidate(5, 5, 5) == 5
	assert candidate(10, 20, 30) == 20
def test_check():
	check(constrain)
