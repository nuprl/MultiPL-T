def count_word_occurrence_in_string(text, word):
    """ 
     Counts how often word appears in text.
     Example: if text is "one two one two three four"
     and word is "one", then this function returns 2
     """
	### Canonical solution below ###    
    words = text.split()
    return words.count(word)

### Unit tests below ###
def check(candidate):
	assert candidate(text="", word="five") == 0
	assert candidate(text="one two one two three four",
                                       word="three") == 1
	assert candidate(text="one two one two three four", word="one") == 2
	assert candidate(
    "one two one two three four", "one") == 2
	assert candidate(
    "", "") == 0
	assert candidate(
    "one two one two three four", "four") == 1
	assert candidate(
    "one two one two three four", "one") == 2, "one is counted twice"
	assert candidate(text="one two one two three four", word="four") == 1, "Should be 1"
	assert candidate(
    "one two one two three four", "four") == 1, "Should be 1"
	assert candidate(text="one two one two three four", word="three") == 1
	assert candidate(
    "one two one two three four", "four") == 1, "four not found"
	assert candidate(text="one two one two three four", word="five") == 0, "Should be 0"
	assert candidate(
    "one two one two three four",
    "three"
) == 1
	assert candidate(
    "one two one two three four", "three") == 1, "three"
	assert candidate(
    "one two one two three four", "five") == 0, "Function is incorrect"
	assert candidate(
    "one two one two three four", "four") == 1, "four appears once"
	assert candidate(
    "one two one two three four",
    "five"
) == 0
	assert candidate(
    "one two one two three four", " ") == 0, "space does not appear"
	assert candidate(
    "one two one two three four", "four") == 1, "Function is incorrect"
	assert candidate(
    "one two one two three four", "five") == 0
	assert candidate(
    "one two one two three four", "five") == 0, "five does not appear"
	assert candidate(
    "one two one two three four", "five") == 0, "Should be 0"
	assert candidate(
    "one two one two three four", "three") == 1, "three appears once"
	assert candidate(
    "one two one two three four",
    "one"
) == 2
	assert candidate(text="one two one two three four",
                                       word="two") == 2
	assert candidate(
    "one two one two three four", "two") == 2
	assert candidate(
    "one two one two three four", " ") == 0
	assert candidate(
    "one two one two three four", "one") == 2, "one not found"
	assert candidate(text="one two one two three four",
                                       word="one") == 2
	assert candidate(
    "one two one two three four",
    "two"
) == 2
	assert candidate(text="one two one two three four", word="two") == 2
	assert candidate(text="one two one two three four", word="five") == 0
	assert candidate(
    "one two one two three four", "one") == 2, "one two one"
	assert candidate(
    "one two one two three four", "two") == 2, "Should be 2"
	assert candidate(text="one two one two three four", word="four") == 1
	assert candidate(
    "one two one two three four", "four") == 1, "four"
	assert candidate(
    "one two one two three four", "one") == 2, "Function is incorrect"
	assert candidate(text="one two one two three four",
                                       word="four") == 1
	assert candidate(
    "one two one two three four", "") == 0
	assert candidate(
    "one two one two three four",
    "four"
) == 1
	assert candidate(
    "one two one two three four", "four") == 1, "four is counted once"
	assert candidate(
    "one two one two three four", "one") == 2, "Should be 2"
	assert candidate(
    "one two one two three four", "two") == 2, "Function is incorrect"
	assert candidate(text=" ", word="") == 0
	assert candidate(
    "one two one two three four", "five") == 0, "five"
	assert candidate(
    "one two one two three four", "three") == 1
	assert candidate(
    "one two one two three four", "five") == 0, "five not found"
	assert candidate(
    "one two one two three four", "three") == 1, "Function is incorrect"
	assert candidate(text="one two one two three four",
                                       word="five") == 0
	assert candidate(text="one two one two three four",
                                       word="one two") == 0
	assert candidate(text="one two one two three four", word="one") == 2, "Should be 2"
	assert candidate(
    "one two one two three four", "five") == 0, "there are no five's"
	assert candidate(
    "one two one two three four", "two") == 2, "two not found"
	assert candidate(
    "one two one two three four", "") == 0, "empty string does not appear"
	assert candidate(
    "one two one two three four", "two") == 2, "two is counted twice"
	assert candidate(text="one two one two three four",
                                       word="three four") == 0
	assert candidate(text="one two one two three four",
                                       word="two three") == 0
	assert candidate(
    "one two one two three four", "three") == 1, "Should be 1"
	assert candidate(
    "one two one two three four", "two") == 2, "two two one"
def test_check():
	check(count_word_occurrence_in_string)
