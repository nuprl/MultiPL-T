def max_digit(n, d=1, r=0):
    """Returns the maximum digit of `n` that gives the remainder `r`
when divided by `d`.

    Parameters
    ----------
    n : int
        A number whose sum is computed.
    d : int
        The number by which each digit is to be divided. Error occurs
when `d == 0`.
    r : int
        The required remainder on division by `d`. If `r < 0` or
`r >= d` the digit will be 0

    Returns
    -------
    digit_max : int
        The maximum digit satisfying these conditions.
    """
    ### Canonical solution below ###

    # Initialisations
    n = abs(n)
    digit_max = -1 # So no digit can be outputted in the case where the
# conditions aren't satisfied

    while n >= 10:

        digit = n % 10
        n = n // 10

        if digit % d == r and digit > digit_max:
            digit_max = digit

    digit = n
    if digit % d == r and digit > digit_max:
        digit_max = digit

    if digit_max < 0:
        raise ValueError("There isn't a digit of `n` that gives\
 remainder `r` on division by `d`.")
    else:
        return "The maximum digit of `n` with remainder `r` on division\
 by `d` is ", digit_max


### Unit tests below ###
def check(candidate):
	assert candidate(1234567890, 10, 6) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 6)
	assert candidate(12, 3, 2) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 2)
	assert candidate(1234567890, 10, 5) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 5)
	assert candidate(1234567890, 10, 2) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 2)
	assert candidate(1234567890, 10, 3) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 3)
	assert candidate(1234567890, 10, 0) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 0)
	assert candidate(12, 1, 0) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 2)
	assert candidate(1000, 10, 1) == ( "The maximum digit of `n` with\
 remainder `r` on division by `d` is ", 1)
	assert candidate(1000, 10, 0) == ( "The maximum digit of `n` with\
 remainder `r` on division by `d` is ", 0)
	assert candidate(123, 1, 0) == ("The maximum digit of `n` with remainder\
 `r` on division by `d` is ", 3)
	assert candidate(123456789, 3) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 9)
	assert candidate(12, 10, 1) == ("The maximum digit of `n` with remainder\
 `r` on division by `d` is ", 1)
	assert candidate(1234567890, 10, 4) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 4)
	assert candidate(1234567890, 10, 1) == (
    "The maximum digit of `n` with remainder `r` on division by `d` is ", 1)
def test_check():
	check(max_digit)
