def div(dividend, divisor):
  """
  Takes two ints and returns a tuple (quotient, remainder)
  """
    ### Canonical solution below ###
  quotient = 0
  
  while dividend - divisor >= 0:
    dividend -= divisor
    quotient += 1
  
  return (quotient, dividend)


### Unit tests below ###
def check(candidate):
	assert candidate(10, 10) == (1, 0)
	assert candidate(0, 3) == (0, 0)
	assert candidate(12, 7) == (1, 5)
	assert candidate(10, 3) == (3, 1), "candidate test 1"
	assert candidate(10, 16) == (0, 10)
	assert candidate(10, 4) == (2, 2)
	assert candidate(10, 19) == (0, 10)
	assert candidate(7, 5) == (1, 2), "candidate test 2"
	assert candidate(10, 6.0) == (1.0, 4.0)
	assert candidate(15, 1) == (15, 0)
	assert candidate(10, 17) == (0, 10)
	assert candidate(10, 5.0) == (2.0, 0.0)
	assert candidate(10, 12) == (0, 10)
	assert candidate(10, 1) == (10, 0)
	assert candidate(15, 2) == (7, 1)
	assert candidate(10, 10) == (1, 0), "Should be (1, 0)"
	assert candidate(10, 20) == (0, 10)
	assert candidate(13, 13) == (1, 0)
	assert candidate(7, 3) == (2, 1)
	assert candidate(5, 2) == (2, 1)
	assert candidate(10, 6) == (1, 4)
	assert candidate(10.0, 3) == (3.0, 1.0)
	assert candidate(15, 3) == (5, 0)
	assert candidate(0, 2) == (0, 0)
	assert candidate(10, 3) == (3, 1)
	assert candidate(10.0, 5) == (2.0, 0.0)
	assert candidate(7, 5) == (1, 2)
	assert candidate(100, 2) == (50, 0)
	assert candidate(10.0, 6) == (1.0, 4.0)
	assert candidate(3, 2) == (1, 1)
	assert candidate(100, 1) == (100, 0)
	assert candidate(3, 3) == (1, 0)
	assert candidate(7, 2) == (3, 1)
	assert candidate(7, 1) == (7, 0)
	assert candidate(12, 12) == (1, 0)
	assert candidate(10, 8) == (1, 2)
	assert candidate(10, 5) == (2, 0), "Should be (2, 0)"
	assert candidate(10, 2) == (5, 0), "Should be (5, 0)"
	assert candidate(2, 2) == (1, 0)
	assert candidate(9, 3) == (3, 0)
	assert candidate(100, 3) == (33, 1)
	assert candidate(10, 14) == (0, 10)
	assert candidate(100, 10) == (10, 0), "Should be (10, 0)"
	assert candidate(10, 3) == (3, 1), "Should be (3, 1)"
	assert candidate(10, 13) == (0, 10)
	assert candidate(5, 3) == (1, 2)
	assert candidate(100, 5) == (20, 0)
	assert candidate(5, 5) == (1, 0)
	assert candidate(10.0, 7) == (1.0, 3.0)
	assert candidate(100, 7) == (14, 2)
	assert candidate(10, 9) == (1, 1)
	assert candidate(10, 2) == (5, 0)
	assert candidate(12, 4) == (3, 0)
	assert candidate(1, 1) == (1, 0)
	assert candidate(12, 3) == (4, 0)
	assert candidate(10, 11) == (0, 10)
	assert candidate(0, 10) == (0, 0)
	assert candidate(10, 3.0) == (3.0, 1.0)
	assert candidate(10, 5) == (2, 0)
	assert candidate(0, 1) == (0, 0)
	assert candidate(12, 5) == (2, 2)
	assert candidate(5, 7) == (0, 5)
	assert candidate(10, 15) == (0, 10)
	assert candidate(10, 18) == (0, 10)
	assert candidate(5, 10) == (0, 5)
	assert candidate(10, 7) == (1, 3)
	assert candidate(1, 2) == (0, 1)
def test_check():
	check(div)
