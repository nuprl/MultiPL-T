def merge_cms(cm1, cm2):
    """
    Merge two confusion matrices.

    Parameters
    ----------
    cm1 : dict
        Confusion matrix which has integer keys 0, ..., nb_classes - 1;
        an entry cm1[i][j] is the count how often class i was classified as
        class j.
    cm2 : dict
        Another confusion matrix.
    Returns
    -------
    dict
        merged confusion matrix
    Examples
    --------
    >>> cm1 = {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}}
    >>> cm2 = {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}}
    >>> merge_cms(cm1, cm2)
    {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
    """
    ### Canonical solution below ###
    assert 0 in cm1
    assert len(cm1[0]) == len(cm2[0])

    cm = {}
    k = len(cm1[0])
    for i in range(k):
        cm[i] = {}
        for j in range(k):
            cm[i][j] = cm1[i][j] + cm2[i][j]

    return cm


### Unit tests below ###
def check(candidate):
	assert candidate(
    {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}},
    {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}},
    ) == {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
	assert candidate( {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}}, {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}}) == {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
	assert candidate(
    {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}}, {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}}) == \
    {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
	assert candidate(
    {
        0: {0: 1, 1: 2},
        1: {0: 3, 1: 4}
    },
    {
        0: {0: 5, 1: 6},
        1: {0: 7, 1: 8}
    }
) == {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
	assert candidate(
    {
        0: {0: 1, 1: 2},
        1: {0: 3, 1: 4},
    },
    {
        0: {0: 5, 1: 6},
        1: {0: 7, 1: 8},
    },
) == {
    0: {0: 6, 1: 8},
    1: {0: 10, 1: 12},
}
	assert candidate(
    {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}},
    {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}},
) == {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
	assert candidate(
    {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}},
    {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}}) == {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
	assert candidate(
    {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}},
    {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}}
    ) == {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
	assert candidate(
    {0: {0: 1, 1: 2}, 1: {0: 3, 1: 4}},
    {0: {0: 5, 1: 6}, 1: {0: 7, 1: 8}}
) == {0: {0: 6, 1: 8}, 1: {0: 10, 1: 12}}
def test_check():
	check(merge_cms)
