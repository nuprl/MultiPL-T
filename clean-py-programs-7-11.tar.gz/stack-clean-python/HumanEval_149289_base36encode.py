def base36encode(number, alphabet='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    """Converts an integer to a base36 string."""
    ### Canonical solution below ###
    if not isinstance(number, int):
        raise TypeError('number must be an integer')

    base36 = ''
    sign = ''

    if number < 0:
        sign = '-'
        number = -number

    if 0 <= number < len(alphabet):
        return sign + alphabet[number]

    while number != 0:
        number, i = divmod(number, len(alphabet))
        base36 = alphabet[i] + base36

    return sign + base36


### Unit tests below ###
def check(candidate):
	assert candidate(12) == 'C'
	assert candidate(20) == 'K'
	assert candidate(23) == 'N'
	assert candidate(28) == 'S'
	assert candidate(22) == 'M'
	assert candidate(19) == 'J'
	assert candidate(11) == 'B'
	assert candidate(2) == '2'
	assert candidate(21) == 'L'
	assert candidate(17) == 'H'
	assert candidate(24) == 'O'
	assert candidate(-10) == '-A'
	assert candidate(36) == '10'
	assert candidate(3) == '3'
	assert candidate(9) == '9'
	assert candidate(1, '01') == '1'
	assert candidate(37) == '11'
	assert candidate(26) == 'Q'
	assert candidate(-1) == '-1'
	assert candidate(-37) == '-11'
	assert candidate(0) == '0'
	assert candidate(-35) == '-Z'
	assert candidate(4) == '4'
	assert candidate(10) == 'A'
	assert candidate(-1000) == '-RS'
	assert candidate(14) == 'E'
	assert candidate(16) == 'G'
	assert candidate(-36) == '-10'
	assert candidate(5) == '5'
	assert candidate(18) == 'I'
	assert candidate(6) == '6'
	assert candidate(15) == 'F'
	assert candidate(-1, '01') == '-1'
	assert candidate(8) == '8'
	assert candidate(1) == '1'
	assert candidate(35) == 'Z'
	assert candidate(13) == 'D'
	assert candidate(1000) == 'RS'
	assert candidate(27) == 'R'
	assert candidate(7) == '7'
	assert candidate(25) == 'P'
def test_check():
	check(base36encode)
