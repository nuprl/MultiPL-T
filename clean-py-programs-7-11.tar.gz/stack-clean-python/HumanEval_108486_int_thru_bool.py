def int_thru_bool(arg):
    """
    Convert an object to a 0 or a 1.

    Arguments
    ---------
    arg : object
        a value to test for truthiness.

    Returns
    -------
    int
        An integer 1 or 0, depending on the truthiness of the input argument.

    """
    ### Canonical solution below ###
    return int(bool(arg))


### Unit tests below ###
def check(candidate):
	assert candidate('0') == 1
	assert candidate(-1/3) == 1
	assert candidate(1/3) == 1
	assert candidate(dict(a=1)) == 1
	assert candidate(0) == 0
	assert candidate(range(10)) == 1
	assert candidate(range(3)) == 1
	assert candidate(range(2)) == 1
	assert candidate("True") == 1
	assert candidate((1, 2)) == 1
	assert candidate((1,2,3)) == 1
	assert candidate("a") == 1
	assert candidate(["False"]) == 1
	assert candidate(-1.00000001) == 1
	assert candidate(2.0) == 1
	assert candidate(1.00000001) == 1
	assert candidate(0j) == 0
	assert candidate(1j+1) == 1
	assert candidate(-1.1) == 1
	assert candidate('') == 0, 'candidate should return 0 for ""'
	assert candidate(0.9) == 1
	assert candidate(' ') == 1, 'candidate should return 1 for " "'
	assert candidate(1j-1) == 1
	assert candidate('T') == 1
	assert candidate('hello') == 1
	assert candidate("hello") == 1
	assert candidate(1+1j-1) == 1
	assert candidate('') == 0
	assert candidate(-1/3.0) == 1
	assert candidate("1.0") == 1
	assert candidate(range(12)) == 1
	assert candidate({"a": 1}) == 1
	assert candidate(100) == 1
	assert candidate('1.1') == 1
	assert candidate(1.5) == 1
	assert candidate(range(5)) == 1
	assert candidate("A") == 1
	assert candidate(0) == 0, 'candidate should return 0 for 0'
	assert candidate("non-empty string") == 1
	assert candidate(1/3.0) == 1
	assert candidate((0, 1)) == 1
	assert candidate(float('-inf')) == 1
	assert candidate({}) == 0
	assert candidate(candidate) == 1
	assert candidate("a string") == 1
	assert candidate(range(6)) == 1
	assert candidate(False) == 0, 'candidate should return 0 for False'
	assert candidate([1, 2]) == 1
	assert candidate(-1.0) == 1
	assert candidate(2) == 1
	assert candidate(range(7)) == 1
	assert candidate(range(4)) == 1
	assert candidate({'a': 1, 'b': 2}) == 1
	assert candidate(set()) == 0
	assert candidate(0.0) == 0
	assert candidate("1") == 1
	assert candidate(1) == 1, 'candidate should return 1 for 1'
	assert candidate(dict()) == 0
	assert candidate('  hello  ') == 1
	assert candidate('true') == 1
	assert candidate('Y') == 1
	assert candidate([0, 1, 2, 3]) == 1
	assert candidate(1.2) == 1
	assert candidate(['foo']) == 1
	assert candidate({"hello": 1}) == 1
	assert candidate("foo") == 1
	assert candidate([0, 1, 2]) == 1
	assert candidate(1e100) == 1
	assert candidate(None) == 0
	assert candidate('1.0') == 1
	assert candidate(1) == 1
	assert candidate(1.000001) == 1
	assert candidate(0.5) == 1
	assert candidate(range(0)) == 0
	assert candidate({'a': 1}) == 1
	assert candidate([0, 0]) == 1
	assert candidate(range(8)) == 1
	assert candidate(0.1) == 1
	assert candidate([1]) == 1
	assert candidate([0]) == 1
	assert candidate(False) == 0
	assert candidate({1}) == 1
	assert candidate(3.14) == 1, 'candidate should return 1 for 3.14'
	assert candidate('bar') == 1
	assert candidate([0, 1]) == 1
	assert candidate(-1) == 1
	assert candidate(range(11)) == 1
	assert candidate(1.1) == 1
	assert candidate(1-1j-1) == 1
	assert candidate(range(13)) == 1
	assert candidate(" ") == 1
	assert candidate(None) == 0, 'candidate should return 0 for None'
	assert candidate(1+1j) == 1
	assert candidate('1.0001') == 1
	assert candidate('hello') == 1, 'candidate should return 1 for "hello"'
	assert candidate('foo') == 1
	assert candidate([1, 0]) == 1
	assert candidate([1,2,3]) == 1
	assert candidate(1.0) == 1
	assert candidate([1, 2, 3]) == 1
	assert candidate(1-1j+1) == 1
	assert candidate(True) == 1
	assert candidate(range(9)) == 1
	assert candidate('x') == 1
	assert candidate(float('inf')) == 1
	assert candidate('a') == 1
	assert candidate(object()) == 1
	assert candidate("abc") == 1
	assert candidate(range(1)) == 1
	assert candidate((1,)) == 1
	assert candidate(1.0001) == 1
	assert candidate("") == 0
	assert candidate('1') == 1
	assert candidate('TRUE') == 1
	assert candidate('True') == 1
	assert candidate('Yes') == 1
	assert candidate("False") == 1
	assert candidate(True) == 1, 'candidate should return 1 for True'
	assert candidate(()) == 0
	assert candidate([]) == 0
	assert candidate(-1e100) == 1
	assert candidate(1+1j+1) == 1
	assert candidate(int) == 1
	assert candidate(1-1j) == 1
	assert candidate(1j) == 1
def test_check():
	check(int_thru_bool)
