def get_urn(url):
    """
    convert https://blog.scrapinghub.com/page/6/ into blog.scrapinghub.com/page/6/
    :param url:
    :return:
    """
    ### Canonical solution below ###
    if "://" in url:
        return url.split("://")[1]
    return url


### Unit tests below ###
def check(candidate):
	assert candidate(
    "https://www.scrapinghub.com/page/6/") == "www.scrapinghub.com/page/6/"
	assert candidate(
    "blog.scrapinghub.com/page/6/") == "blog.scrapinghub.com/page/6/"
	assert candidate(u"https://blog.scrapinghub.com/page/6/") == u"blog.scrapinghub.com/page/6/"
	assert candidate("http://blog.scrapinghub.com") == "blog.scrapinghub.com"
	assert candidate(u"https://blog.scrapinghub.com/page/6") == u"blog.scrapinghub.com/page/6"
	assert candidate(
    "http://www.scrapinghub.com/page/6") == "www.scrapinghub.com/page/6"
	assert candidate(
    "http://blog.scrapinghub.com/page/6") == "blog.scrapinghub.com/page/6"
	assert candidate(
    "https://www.google.com/search?q=python&hl=en&gl=us") == "www.google.com/search?q=python&hl=en&gl=us"
	assert candidate("blog.scrapinghub.com") == "blog.scrapinghub.com"
	assert candidate("http://blog.scrapinghub.com/") == "blog.scrapinghub.com/"
	assert candidate(
    "http://blog.scrapinghub.com/page/6/") == "blog.scrapinghub.com/page/6/"
	assert candidate(
    "https://blog.scrapinghub.com/page/6/foo") == "blog.scrapinghub.com/page/6/foo"
	assert candidate(
    "http://www.scrapinghub.com/page/6/") == "www.scrapinghub.com/page/6/"
	assert candidate("http://blog.scrapinghub.com/page/6/") == "blog.scrapinghub.com/page/6/"
	assert candidate("scrapinghub.com/page/6/") == "scrapinghub.com/page/6/"
	assert candidate("") == ""
	assert candidate(
    "https://blog.scrapinghub.com/page/6/?q=python&hl=en&gl=us") == "blog.scrapinghub.com/page/6/?q=python&hl=en&gl=us"
	assert candidate("blog.scrapinghub.com/page/6/") == "blog.scrapinghub.com/page/6/"
	assert candidate("https://blog.scrapinghub.com/page/6/") == "blog.scrapinghub.com/page/6/"
	assert candidate(
    "http://blog.scrapinghub.com/page/6/foo") == "blog.scrapinghub.com/page/6/foo"
	assert candidate("blog.scrapinghub.com/page/6") == "blog.scrapinghub.com/page/6"
	assert candidate("https://blog.scrapinghub.com/") == "blog.scrapinghub.com/"
	assert candidate(
    "https://blog.scrapinghub.com/page/6/") == "blog.scrapinghub.com/page/6/"
	assert candidate(
    "blog.scrapinghub.com/page/6/foo") == "blog.scrapinghub.com/page/6/foo"
	assert candidate("https://blog.scrapinghub.com") == "blog.scrapinghub.com"
	assert candidate("blog.scrapinghub.com/") == "blog.scrapinghub.com/"
	assert candidate(
    "https://www.google.com/search?q=python") == "www.google.com/search?q=python"
	assert candidate(u"blog.scrapinghub.com/page/6") == u"blog.scrapinghub.com/page/6"
	assert candidate(
    "https://blog.scrapinghub.com/page/6") == "blog.scrapinghub.com/page/6"
	assert candidate(
    "https://www.scrapinghub.com/page/6") == "www.scrapinghub.com/page/6"
	assert candidate("http://blog.scrapinghub.com/page/6") == "blog.scrapinghub.com/page/6"
def test_check():
	check(get_urn)
