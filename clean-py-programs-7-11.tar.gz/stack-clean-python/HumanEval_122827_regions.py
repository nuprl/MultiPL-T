def regions():
    """Return data structure for test regions/shapes
    """
    ### Canonical solution below ###
    return [
        {
            'name': 'unit',
            'feature': {
                'type': 'Feature',
                'properties': {'name': 'unit'},
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[0, 0], [0, 1], [1, 1], [1, 0]]]
                }
            }
        },
        {
            'name': 'half',
            'feature': {
                'type': 'Feature',
                'properties': {'name': 'half'},
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[0, 0], [0, 0.5], [1, 0.5], [1, 0]]]
                }
            }
        },
        {
            'name': 'two',
            'feature': {
                'type': 'Feature',
                'properties': {'name': 'two'},
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[0, 0], [0, 2], [1, 2], [1, 0]]]
                }
            }
        }
    ]


### Unit tests below ###
def check(candidate):
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][0][0] == 0, 'First coordinate should be 0'
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][1][0] == 0, 'Third coordinate should be 0'
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][3][1] == 0, 'Eighth coordinate should be 0'
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][3] == [1, 0]
	assert all(region['name'] in ['unit', 'half', 'two'] for region in candidate())
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][1][1] == 1, 'Fourth coordinate should be 1'
	assert all(region['feature']['properties']['name'] in ['unit', 'half', 'two'] for region in candidate())
	assert candidate(
)[2]['feature']['geometry']['coordinates'][0][2] == [1, 2]
	assert candidate(
)[1]['feature']['geometry']['coordinates'][0][2] == [1, 0.5]
	assert candidate(
)[2]['feature']['geometry']['coordinates'][0][3] == [1, 0]
	assert candidate(
)[2]['feature']['geometry']['coordinates'][0][0] == [0, 0]
	assert candidate(
)[2]['feature']['geometry']['coordinates'][0][1] == [0, 2]
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][0] == [0, 0]
	assert candidate(
) == [
    {
        'name': 'unit',
        'feature': {
            'type': 'Feature',
            'properties': {'name': 'unit'},
            'geometry': {
                'type': 'Polygon',
                'coordinates': [[[0, 0], [0, 1], [1, 1], [1, 0]]]
            }
        }
    },
    {
        'name': 'half',
        'feature': {
            'type': 'Feature',
            'properties': {'name': 'half'},
            'geometry': {
                'type': 'Polygon',
                'coordinates': [[[0, 0], [0, 0.5], [1, 0.5], [1, 0]]]
            }
        }
    },
    {
        'name': 'two',
        'feature': {
            'type': 'Feature',
            'properties': {'name': 'two'},
            'geometry': {
                'type': 'Polygon',
                'coordinates': [[[0, 0], [0, 2], [1, 2], [1, 0]]]
            }
        }
    }
]
	assert candidate(
) == [{
    'name': 'unit',
    'feature': {
        'type': 'Feature',
        'properties': {'name': 'unit'},
        'geometry': {
            'type': 'Polygon',
            'coordinates': [[[0, 0], [0, 1], [1, 1], [1, 0]]]
        }
    }
}, {
    'name': 'half',
    'feature': {
        'type': 'Feature',
        'properties': {'name': 'half'},
        'geometry': {
            'type': 'Polygon',
            'coordinates': [[[0, 0], [0, 0.5], [1, 0.5], [1, 0]]]
        }
    }
}, {
    'name': 'two',
    'feature': {
        'type': 'Feature',
        'properties': {'name': 'two'},
        'geometry': {
            'type': 'Polygon',
            'coordinates': [[[0, 0], [0, 2], [1, 2], [1, 0]]]
        }
    }
}]
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][2][1] == 1, 'Sixth coordinate should be 1'
	assert candidate(
)[0]['name'] == 'unit', 'First region should be unit'
	assert candidate(
) == [
        {
            'name': 'unit',
            'feature': {
                'type': 'Feature',
                'properties': {'name': 'unit'},
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[0, 0], [0, 1], [1, 1], [1, 0]]]
                }
            }
        },
        {
            'name': 'half',
            'feature': {
                'type': 'Feature',
                'properties': {'name': 'half'},
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[0, 0], [0, 0.5], [1, 0.5], [1, 0]]]
                }
            }
        },
        {
            'name': 'two',
            'feature': {
                'type': 'Feature',
                'properties': {'name': 'two'},
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': [[[0, 0], [0, 2], [1, 2], [1, 0]]]
                }
            }
        }
    ]
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][2][0] == 1, 'Fifth coordinate should be 1'
	assert candidate(
)[1]['feature']['geometry']['coordinates'][0][3] == [1, 0]
	assert all(set(region.keys()) == {'name', 'feature'} for region in candidate())
	assert candidate(
)[1]['feature']['geometry']['coordinates'][0][0] == [0, 0]
	assert all(isinstance(region, dict) for region in candidate())
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][0][1] == 0, 'Second coordinate should be 0'
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][2] == [1, 1]
	assert candidate(
)[1]['feature']['geometry']['coordinates'][0][1] == [0, 0.5]
	assert candidate(
)[0]['feature']['geometry']['coordinates'][0][1] == [0, 1]
def test_check():
	check(regions)
