def graphql_scalar(scalar_name, description=None):
    """ Annotate a GraphQlScalarDescriptor as a GraphQL scalar.
     
     Decorator that annotates a GraphQlScalarDescriptor subclass as a
     GraphQL scalar with the specified type name.  See
     GraphQlScalarDescriptor.  At present, we do not support annotating
     a class with multiple graphql_scalar annotations.
     
     basestring scalar_name - The type name.
     basestring description - A description of the type, or None.
     GraphQL favors the Markdown format.
     """
	### Canonical solution below ###    
    def decorator(cls):
        cls._graphql_scalar_name = scalar_name
        cls._graphql_scalar_description = description
        return cls
    return decorator

### Unit tests below ###
def check(candidate):
	assert candidate(u'Foo', u'Bar') is not candidate(u'Foo', u'Baz')
	assert candidate(u"Foo") is not None
	assert candidate(u"foo") is not None
	assert candidate(u'Foo') is not candidate(u'Bar')
	assert candidate(u'MyScalar') is not None
	assert candidate(u'Foo') is not None
	assert candidate(u'foo') is not candidate(u'bar')
	assert candidate(u"Foo")!= candidate(u"Bar")
	assert candidate('foo bar')
	assert candidate(u'foo') is not None
	assert candidate(u'Foo', u'Bar') is not None
def test_check():
	check(graphql_scalar)
