def attr(**kwargs):
    """Add attributes to a test function/method/class"""
    ### Canonical solution below ###
    def wrap(func):
        func.__dict__.update(kwargs)
        return func
    return wrap


### Unit tests below ###
def check(candidate):
	assert candidate(foo=123)(lambda: None).__dict__ == {'foo': 123}
	assert candidate(hello='world')!= 'hello world'
	assert candidate(a=1, b=2)(lambda x: x).b == 2
	assert candidate(answer=42)(lambda x: x).answer == 42
	assert candidate(answer=42)(lambda: None).__dict__ == {'answer': 42}
	assert candidate(hello="world")!= candidate(hello="world2")
	assert candidate(foo=123)(lambda: None)
	assert not hascandidate(candidate(foo=123), 'foo')
	assert candidate(foo=1)(lambda *args: 42)(21, 22, 23) == 42
	assert candidate(foo=1)(lambda x, y: 42)(21, 22) == 42
	assert candidate(hello='world')!= candidate(hello='world', goodbye='world')
	assert candidate(foo=1)(lambda: 42)() == 42
	assert candidate(a=1, b=2)(lambda x: x)
	assert candidate(foo='bar')(lambda x: x).__dict__ == {'foo': 'bar'}
	assert candidate(answer=42)(lambda x: x).__dict__ == {'answer': 42}
	assert candidate(foo=10, bar=20)(lambda: None).bar == 20
	assert candidate(foo=10, bar=20)(lambda x: x)
	assert candidate(answer=42)(lambda x: x).__dict__['answer'] == 42
	assert candidate(foo=123)(candidate(bar=456)(lambda x: x))
	assert candidate(foo=1)(lambda *args: 42)(21) == 42
	assert candidate(foo=10)(lambda: None).foo == 10
	assert candidate(foo=1)(lambda *args: 42)(21, 22) == 42
	assert candidate(one=1, two=2)(lambda x: x).one == 1
	assert candidate(hello="world")!= candidate(hello="world", bye="universe")
	assert candidate(foo=1)(lambda x, y=3: 42)(21, 22) == 42
	assert candidate(foo=123)(lambda: None).foo == 123
	assert candidate(foo='bar')(lambda: None).__dict__ == {'foo': 'bar'}
	assert candidate(foo=1)(lambda x, y: 42)(x=21, y=22) == 42
	assert candidate(hello='world', foo='bar')!= candidate(hello='world')
	assert candidate(foo=1)(lambda x: 42)(21) == 42
	assert candidate(a=1, b=2)(lambda x: x).a == 1
	assert candidate(hello='world')!= candidate(hello='not world')
	assert candidate(hello='world')!= 1234
	assert candidate(foo=123)(lambda x, y, z: (x, y, z))
	assert candidate(foo=10, bar=20)(lambda: None).foo == 10
	assert candidate(hello="world")!= candidate(bye="universe")
	assert candidate(a=1)(lambda x: x).a == 1
	assert candidate(foo=10)(lambda x: x)
	assert candidate(a=1)(lambda x: x)(10) == 10
	assert candidate(foo=123)(lambda x=1: x)
	assert candidate(one=1, two=2)(lambda x: x)
	assert candidate(foo=1)(lambda x, y=3: 42)(x=21, y=22) == 42
	assert candidate(foo=123)(lambda *args: args)
	assert candidate(foo=123)(lambda **kwargs: kwargs)
	assert candidate(foo=123)(candidate(bar=456)(candidate(baz=789)(lambda x: x)))
	assert candidate(hello='world')!= candidate(goodbye='world')
	assert candidate(a=1, b=2)(lambda: None).__dict__ == {'a': 1, 'b': 2}
	assert candidate(foo=123)(lambda x: x)
	assert candidate(foo='bar')(lambda x: x)
	assert candidate(foo=1)(lambda x, y=3: 42)(21) == 42
	assert candidate(hello='world')!= 'hello'
	assert candidate(a=1)(lambda x: x)
	assert candidate(foo=123)(candidate(bar=456)(candidate(baz=789)(candidate(quux=101112)(lambda x: x))))
	assert candidate(one=1, two=2)(lambda x: x).two == 2
	assert candidate(hello='world')!= candidate(hello='world', foo='bar')
	assert candidate(bar=20)(lambda x: x).bar == 20
	assert candidate(foo=123)(lambda x, *args: (x, args))
	assert candidate(foo=123)(lambda x, **kwargs: (x, kwargs))
	assert candidate(foo=1)(lambda x, y=3: 42)(x=21) == 42
	assert candidate(hello='world')!= candidate(hello='world2')
	assert candidate(foo=1)(lambda x: 42)(x=21) == 42
	assert candidate(hello="world", bye="universe")!= candidate(hello="world", bye="world")
	assert candidate(hello='world')!= candidate(foo='world')
def test_check():
	check(attr)
