def bytesfilter(num, suffix='B'):
    """Convert a number of bytes to a human-readable format."""
    ### Canonical solution below ###
    for unit in ['','Ki','Mi','Gi','Ti','Pi','Ei','Zi']:
        if abs(num) < 1024.0:
            return "%3.0f %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.0f %s%s" % (num, 'Yi', suffix)


### Unit tests below ###
def check(candidate):
	assert candidate(1023) == "1023 B"
	assert candidate(1000) == '1000 B'
	assert candidate(100) == "100 B"
	assert candidate(123) == '123 B'
	assert candidate(100) == '100 B'
	assert candidate(1000) == "1000 B"
	assert candidate(1023) == '1023 B'
def test_check():
	check(bytesfilter)
