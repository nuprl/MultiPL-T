def fpowx(x, n):
    """ 
     quick pow: x ** n
     """
	### Canonical solution below ###    
    res = 1
    while n:
        if n & 1:
            res = res * x
        # compute x^2 x^4 x^8
        x *= x
        n >>= 1
    return res

### Unit tests below ###
def check(candidate):
	assert candidate(2, 9) == 512
	assert candidate(0, 10) == 0
	assert candidate(2, 30) == 1024 * 1024 * 1024
	assert candidate(3, 0) == 1
	assert candidate(2, 15) == 32768
	assert candidate(2, 3) == 8
	assert candidate(5, 0) == 1
	assert candidate(10.0, 0) == 1.0
	assert candidate(2, 10) == 1024
	assert candidate(10, 3) == 1000
	assert candidate(2, 22) == 4194304
	assert candidate(1, 10) == 1
	assert candidate(3, 10) == 59049
	assert candidate(2, 0) == 1
	assert candidate(2, 20) == 1024 * 1024
	assert candidate(3, 5) == 243
	assert candidate(2, 16) == 65536
	assert candidate(1.0, 0) == 1.0
	assert candidate(2, 8) == 256
	assert candidate(2, 1) == 2
	assert candidate(2, 18) == 262144
	assert candidate(10.0, 1) == 10.0
	assert candidate(2, 20) == 1048576
	assert candidate(10, 5) == 100000
	assert candidate(2, 5) == 32
	assert candidate(2, 7) == 128
	assert candidate(2, 11) == 2048
	assert candidate(2, 13) == 8192
	assert candidate(-2, 10) == 1024
	assert candidate(10, 0) == 1
	assert candidate(10.0, 2) == 100.0
	assert candidate(3, 4) == 81
	assert candidate(10, 10) == 10000000000
	assert candidate(2, 6) == 64
	assert candidate(2, 21) == 2097152
	assert candidate(2, 14) == 16384
	assert candidate(2, 4) == 16
	assert candidate(10.0, 3) == 1000.0
	assert candidate(2, 100) == 1267650600228229401496703205376
	assert candidate(2, 50) == 1125899906842624
	assert candidate(3, 20) == 59049 * 59049
	assert candidate(2, 19) == 524288
	assert candidate(2.0, 10) == 1024.0
	assert candidate(2, 17) == 131072
	assert candidate(2, 12) == 4096
	assert candidate(10.0, 4) == 10000.0
	assert candidate(2, 2) == 4
def test_check():
	check(fpowx)
