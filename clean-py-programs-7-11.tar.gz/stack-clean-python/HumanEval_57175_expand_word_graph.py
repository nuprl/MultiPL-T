def expand_word_graph(word_graph):
    """ Expands word graph dictionary to include all words as keys."""
	### Canonical solution below ###    
    expanded_word_graph = word_graph.copy()
    for word1 in word_graph:
        for word2 in list(word_graph[word1]):
             expanded_word_graph[word2] = (expanded_word_graph.get(word2, set())
                | set([word1]))

    return expanded_word_graph

### Unit tests below ###
def check(candidate):
	assert candidate(
        {'a': set(['b', 'c']), 'b': set(['a', 'd']), 'c': set(['a'])}) == \
        {'a': set(['b', 'c']), 'b': set(['a', 'd']), 'c': set(['a']),
        'd': set(['b'])}
	assert candidate(dict(a=set(['b', 'c']))) == \
    dict(a=set(['b', 'c']), b=set(['a']), c=set(['a']))
	assert candidate({"a": set(["b", "c"]), "b": set(["c"]), "c": set([])}) == {"a": set(["b", "c"]), "b": set(["a", "c"]), "c": set(["a", "b"])}
	assert candidate(dict(a=set(['b', 'c']), b=set(['a', 'd']), c=set(['a']))) == dict(a=set(['b', 'c']), b=set(['a', 'd']), c=set(['a']), d=set(['b']))
	assert candidate({'a': {'b', 'c'}}) == {'a': {'b', 'c'}, 'b': {'a'}, 'c': {'a'}}
	assert candidate(dict()) == dict()
	assert candidate(dict(a=set(['b']), b=set(['c']))) == \
    dict(a=set(['b']), b=set(['a', 'c']), c=set(['b']))
	assert candidate(dict(a=set(['b', 'c']), b=set(['a', 'd']), c=set(['a']))) == \
    dict(a=set(['b', 'c']), b=set(['a', 'd']), c=set(['a']), d=set(['b']))
	assert candidate({'a': set()}) == {'a': set()}
	assert candidate(dict(a=set(["b", "c"]), b=set())) == (
    dict(a=set(["b", "c"]), b=set(["a"]), c=set(["a"])))
	assert candidate(dict(a=set(['b', 'c']), b=set(['a', 'd']), c=set(['a']), d=set(['b']))) == dict(a=set(['b', 'c']), b=set(['a', 'd']), c=set(['a']), d=set(['b']))
	assert candidate(dict(a=set(), b=set())) == dict(a=set(), b=set())
def test_check():
	check(expand_word_graph)
