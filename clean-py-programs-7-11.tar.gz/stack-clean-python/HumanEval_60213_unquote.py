def unquote(s):
    """ Strip single quotes from the string.
     
     :param s: string to remove quotes from
     :return: string with quotes removed
     """
	### Canonical solution below ###    
    return s.strip("'")

### Unit tests below ###
def check(candidate):
	assert candidate(r"'This is a test'") == "This is a test"
	assert candidate(r"'a'") == "a"
	assert candidate(r"'test'") == "test"
	assert candidate(r"foo") == r"foo"
	assert candidate(r"'hello world'") == "hello world"
	assert candidate(r"'abc def'") == "abc def"
	assert candidate(r"'Hello World'") == "Hello World"
	assert candidate(r"'") == ''
	assert candidate(r"a'b") == r"a'b"
	assert candidate(r"'foo'bar'") == r"foo'bar"
	assert candidate("Hello") == "Hello"
	assert candidate(r"'") == ""
	assert candidate(r"'this is a string'") == r'this is a string'
	assert candidate(r"test' test") == r"test' test"
	assert candidate(r"''") == r''
	assert candidate(r"'abc\ def'") == "abc\ def"
	assert candidate(r"test 'test") == r"test 'test"
	assert candidate(r"'x'") == "x"
	assert candidate("'") == ''
	assert candidate(r"test") == "test"
	assert candidate("''") == r""
	assert candidate(r"'this is a string'") == 'this is a string'
	assert candidate(r"a") == "a"
	assert candidate(r"'some'string'") == "some'string"
	assert candidate(r"'ab'") == "ab"
	assert candidate(r"'hello'") == "hello"
	assert candidate(r"''abc''") == 'abc'
	assert candidate(r"abc") == "abc"
	assert candidate("'hi'") == 'hi'
	assert candidate(r"Hello") == "Hello"
	assert candidate("'foo'") == "foo"
	assert candidate(r"'foo'") == "foo"
	assert candidate(r"hello") == 'hello'
	assert candidate(r"'Hello'") == "Hello"
	assert candidate(r"'hello'") == 'hello'
	assert candidate(r"'a'") == 'a'
	assert candidate("'Hello'") == "Hello"
	assert candidate(r"123") == "123"
	assert candidate(r"") == ""
	assert candidate('"foo"') == '"foo"'
	assert candidate(r"") == r""
	assert candidate(r"'abc'") == "abc"
	assert candidate(r"this is a string") == 'this is a string'
	assert candidate(r"'x") == "x"
	assert candidate(r"'") == r""
	assert candidate(r"'foo bar'") == "foo bar"
	assert candidate(r"this is a string") == r"this is a string"
	assert candidate(r"''") == ''
	assert candidate(r" 'foo' bar ") == r" 'foo' bar "
	assert candidate('"foo') == '"foo'
	assert candidate(r"test 'test' test") == r"test 'test' test"
	assert candidate(r"'123'") == "123"
	assert candidate(r"'foo'bar") == r"foo'bar"
	assert candidate(r"''") == ""
	assert candidate(r"'abc'") == 'abc'
	assert candidate("'I'm a string'") == "I'm a string"
	assert candidate(r"hello world") == "hello world"
	assert candidate(r"'foo'") == 'foo'
	assert candidate(r"C:\Users\User\Desktop") == r"C:\Users\User\Desktop"
	assert candidate('foo"') == 'foo"'
	assert candidate(r"'some string'") == "some string"
	assert candidate(r"test' test' test") == r"test' test' test"
	assert candidate(r"'''some string'''") == "some string"
	assert candidate("hi'hi") == "hi'hi"
	assert candidate(r"I'm a string") == "I'm a string"
	assert candidate(r"This is a test") == "This is a test"
def test_check():
	check(unquote)
