def get_path_format(mod_path, output):
    """ Use the module path '.' file name for api documentation
     Use the file path '/' file name for plugin documentation
     
     :param mod_path: module path for file
     :param output: the type of file output required eg. api or plugin
     :return: string in correct path format
     """
	### Canonical solution below ###    
    if output == "plugin_documentation":
        mod_path = mod_path.replace(".", "/")
    return mod_path

### Unit tests below ###
def check(candidate):
	assert candidate(mod_path="foo/bar", output="plugin_documentation") == "foo/bar"
	assert candidate(mod_path="test.test.test", output="plugin_documentation") == "test/test/test"
	assert candidate(
    "tests.test_documentation.test_documentation",
    "plugin_documentation") == "tests/test_documentation/test_documentation"
	assert candidate(
    "test.path.to.module", "plugin_documentation") == "test/path/to/module"
	assert candidate(mod_path=".", output="plugin_documentation") == "/"
	assert candidate(
    "plugins.extract.file.csv_extractor", "plugin_documentation") == "plugins/extract/file/csv_extractor"
	assert candidate(
    "plugins.data.extract.test_extract.TestExtract.test_extract_csv", "plugin_documentation"
) == "plugins/data/extract/test_extract/TestExtract/test_extract_csv"
	assert candidate("plugins.plugin_name", "api_documentation") == "plugins.plugin_name"
	assert candidate(mod_path=".", output="api") == "."
	assert candidate(mod_path="my_module", output="api_documentation") == "my_module"
	assert candidate(mod_path="test.test", output="plugin_documentation") == "test/test"
	assert candidate("plugins.plugin_name", "plugin_documentation") == "plugins/plugin_name"
	assert candidate(mod_path="test", output="plugin_documentation") == "test"
	assert candidate(
    "plugins.module_utils.source_control.git_lab", "plugin_documentation") == "plugins/module_utils/source_control/git_lab"
	assert candidate(mod_path="path.to.file", output="plugin_documentation") == "path/to/file"
	assert candidate(mod_path="test", output="api_documentation") == "test"
	assert candidate(mod_path="foo/bar", output="api") == "foo/bar"
	assert candidate("plugins.data.extract.test_extract.test_extract_csv", "plugin_documentation") == "plugins/data/extract/test_extract/test_extract_csv"
	assert candidate(
    "tests.test_documentation.test_documentation.test_documentation",
    "plugin_documentation") == "tests/test_documentation/test_documentation/test_documentation"
	assert candidate(mod_path="my_module", output="plugin_documentation") == "my_module"
	assert candidate(mod_path="path/to/file", output="api") == "path/to/file"
	assert candidate("test.test_module.test_class",
                       "plugin_documentation") == "test/test_module/test_class"
	assert candidate("plugins.extract.file.csv_extractor", "api") == "plugins.extract.file.csv_extractor"
	assert candidate(mod_path="path/to/file", output="plugin_documentation") == "path/to/file"
def test_check():
	check(get_path_format)
