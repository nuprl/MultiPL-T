def generate_empty_conjunction(nr_of_elements):
    """ 
     Generate a conjunction which maps everything to 0.
     
     Parameters
     ----------
     nr_of_elements : int
     
     Returns
     -------
     list
     """
	### Canonical solution below ###    
    conjunction = []
    for i in range(nr_of_elements):
        line = []
        for j in range(nr_of_elements):
            line.append(0)
        conjunction.append(line)
    return conjunction

### Unit tests below ###
def check(candidate):
	assert candidate(2) == [[0, 0], [0, 0]]
	assert candidate(0) == []
	assert candidate(1) == [[0]]
	assert candidate(4) == [[0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]]
	assert candidate(3) == [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
	assert candidate(2) == [[0,0],[0,0]]
	assert candidate(3) == [[0,0,0], [0,0,0], [0,0,0]]
	assert candidate(3) == [[0,0,0],[0,0,0],[0,0,0]]
	assert candidate(5) == [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]
	assert candidate(4) == [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
def test_check():
	check(generate_empty_conjunction)
