def rgb_to_grb(color_tuple):
    """ Convert RGB tuple to GRB tuple.
    """
    ### Canonical solution below ###
    r, g, b = color_tuple
    return (g, r, b)


### Unit tests below ###
def check(candidate):
	assert candidate( (0, 128, 255) ) == (128, 0, 255)
	assert candidate( (1, 2, 3) ) == (2, 1, 3)
	assert candidate( (128, 0, 255) ) == (0, 128, 255)
	assert candidate( (100, 200, 50) ) == (200, 100, 50)
	assert candidate( (120, 0, 255) ) == (0, 120, 255)
	assert candidate( (128, 128, 128) ) == (128, 128, 128)
	assert candidate( (255,255,255) ) == (255,255,255)
	assert candidate( (120, 255, 0) ) == (255, 120, 0)
	assert candidate((1, 2, 3)) == (2, 1, 3)
	assert candidate( (254, 253, 252) ) == (253, 254, 252)
	assert candidate( (0, 0, 0) ) == (0, 0, 0)
	assert candidate( (50, 100, 150) ) == (100, 50, 150)
	assert candidate( (127,0,0) ) == (0,127,0)
	assert candidate( (0,0,0) ) == (0,0,0)
	assert candidate( (10, 20, 30) ) == (20, 10, 30)
	assert candidate( (100, 100, 100) ) == (100, 100, 100)
	assert candidate( (253, 252, 251) ) == (252, 253, 251)
	assert candidate( (4, 5, 6) ) == (5, 4, 6)
	assert candidate( (128,0,0) ) == (0,128,0)
	assert candidate( (255, 255, 255) ) == (255, 255, 255)
	assert candidate( (255, 0, 0) ) == (0, 255, 0)
	assert candidate( (128,128,128) ) == (128,128,128)
def test_check():
	check(rgb_to_grb)
