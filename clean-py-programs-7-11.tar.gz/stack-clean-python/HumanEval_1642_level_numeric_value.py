def level_numeric_value(level):
    """ 
     Convert string levels like 'debug' to number.
     :param level:
     :return:
     """
	### Canonical solution below ###    
    if level is "debug":
        level = 10
    elif level is "info":
        level = 30
    elif level is "warning":
        level = 50
    return level

### Unit tests below ###
def check(candidate):
	assert candidate(14) is 14
	assert candidate("warning")!= 30
	assert candidate(6) is 6
	assert candidate("warning") is 50
	assert candidate("info")!= 50
	assert candidate(10) is 10
	assert candidate(1) is 1
	assert candidate("info") is 30
	assert candidate("debug")!= 30
	assert candidate(12) is 12
	assert candidate(10) == 10
	assert candidate(20) is 20
	assert candidate(21) is 21
	assert candidate(18) is 18
	assert candidate("debug")!= 50
	assert candidate(level="debug") == 10
	assert candidate(None) is None
	assert candidate(16) is 16
	assert candidate(3) is 3
	assert candidate(30) == 30
	assert candidate("info")!= 10
	assert candidate(4) is 4
	assert candidate(11) is 11
	assert candidate(0) is 0
	assert candidate("info") == 30
	assert candidate("warning") == 50
	assert candidate(13) is 13
	assert candidate("warning")!= 10
	assert candidate(15) is 15
	assert candidate(17) is 17
	assert candidate(level="warning") == 50
	assert candidate(5) is 5
	assert candidate(7) is 7
	assert candidate(8) is 8
	assert candidate(50) == 50
	assert candidate(2) is 2
	assert candidate("debug") is 10
	assert candidate(0) == 0
	assert candidate(9) is 9
	assert candidate("debug") == 10
	assert candidate(None) == None
	assert candidate(24)
	assert candidate(22) is 22
	assert candidate(19) is 19
	assert candidate(level="info") == 30
	assert candidate(23) is 23
def test_check():
	check(level_numeric_value)
