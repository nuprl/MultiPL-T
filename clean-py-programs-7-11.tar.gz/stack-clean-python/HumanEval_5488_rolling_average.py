def rolling_average(current_avg: float, new_value: float, total_count: int) -> float:
    """ Recalculate a running (or moving) average
     
     Needs the current average, a new value to include, and the total samples
     """
	### Canonical solution below ###    
    new_average = float(current_avg)
    new_average -= new_average / total_count
    new_average += new_value / total_count
    return new_average

### Unit tests below ###
def check(candidate):
	assert candidate(100, 50, 3) == 83.33333333333333
	assert candidate(100, 100, 4) == 100
	assert candidate(100, 50, 2) == 75
	assert candidate(10, 20, 2) == 15
	assert candidate(1, 1, 1) == 1
	assert candidate(10, 10, 1) == 10.0
	assert candidate(10.0, 5.0, 2) == 7.5
	assert candidate(100, 100, 10) == 100
	assert candidate(100, 100, 1) == 100
	assert candidate(10, 20, 2) == 15.0
	assert candidate(1.5, 3, 3) == 2
	assert candidate(2, 4, 4) == 2.5
	assert candidate(1.0, 1.0, 2) == 1.0
	assert candidate(1.0, 1.0, 3) == 1.0
	assert candidate(0, 10, 1) == 10.0
	assert candidate(10, 10, 2) == 10.0
	assert candidate(100, 100, 105) == 100
	assert candidate(10, 5, 1) == 5
	assert candidate(0, 1, 2) == 0.5
	assert candidate(1.0, 1.0, 4) == 1.0
	assert candidate(0.0, 2.0, 1) == 2.0
	assert candidate(100, 100, 103) == 100
	assert candidate(0, 0, 1) == 0
	assert candidate(0.0, 10.0, 5) == 2.0
	assert candidate(0.0, 10.0, 9) == 1.1111111111111112
	assert candidate(0, 0, 4) == 0
	assert candidate(0.0, 10.0, 4) == 2.5
	assert candidate(100, 50, 1) == 50
	assert candidate(0, 0, 3) == 0
	assert candidate(100, 100, 5) == 100
	assert candidate(100, 100, 104) == 100
	assert candidate(0.0, 10.0, 6) == 1.6666666666666667
	assert candidate(0.0, 10.0, 10) == 1.0
	assert candidate(10, 5, 4) == 8.75
	assert candidate(10, 11, 2) == 10.5
	assert candidate(100, 100, 6) == 100
	assert candidate(100, 100, 9) == 100
	assert candidate(2.0, 2.0, 1) == 2.0
	assert candidate(0.0, 10.0, 3) == 3.3333333333333335
	assert candidate(5.0, 10.0, 2) == 7.5
	assert candidate(1, 10, 1) == 10
	assert candidate(100, 100, 3) == 100
	assert candidate(1, 2, 1) == 2
	assert candidate(0, 1, 1) == 1
	assert candidate(5, 10, 2) == 7.5
	assert candidate(100, 100, 2) == 100
	assert candidate(100, 100, 101) == 100
	assert candidate(100, 100, 8) == 100
	assert candidate(0.0, 10.0, 1) == 10.0
	assert candidate(0, 1, 3) == 1/3
	assert candidate(1, 2, 2) == 1.5
	assert candidate(0.0, 1.0, 1) == 1.0
	assert candidate(1.0, 2.0, 1) == 2.0
	assert candidate(0.0, 10.0, 2) == 5.0
	assert candidate(1.0, 2.0, 2) == 1.5
	assert candidate(0, 0, 2) == 0
	assert candidate(100, 100, 102) == 100
	assert candidate(10, 5, 2) == 7.5
	assert candidate(1.0, 1.0, 1) == 1.0
	assert candidate(1, 2, 21)
	assert candidate(0.0, 10.0, 7) == 1.4285714285714286
	assert candidate(0, 1, 4) == 1/4
	assert candidate(0.0, 10.0, 8) == 1.25
	assert candidate(100, 100, 100) == 100
	assert candidate(100, 100, 7) == 100
def test_check():
	check(rolling_average)
