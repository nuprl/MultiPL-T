def lxnor(x, y):
    """ Logical XNOR"""
	### Canonical solution below ###    
    return not (x ^ y)

### Unit tests below ###
def check(candidate):
	assert candidate(1, 2) == 0
	assert candidate(2, 2) == 1
	assert candidate(1, 1)
	assert candidate(1, 1) == True
	assert candidate(3, 3) == 1
	assert candidate(2, 3) == 0
	assert not candidate(1, 0)
	assert candidate(0, 1000) == False
	assert candidate(10, 0) == False
	assert candidate(1, 0) == 0
	assert candidate(3, 2) == 0
	assert not candidate(0, 1)
	assert candidate(0, 0) == True
	assert candidate(2, 1) == 0
	assert candidate(1000000, 0) == False
	assert candidate(0, 1) == 0
	assert candidate(0, 1000000) == False
	assert candidate(False, False) == True
	assert candidate(0, 1) == False
	assert candidate(1, 3) == 0
	assert candidate(1, 0) == False
	assert candidate(0, 0)
	assert candidate(1000, 0) == False
	assert candidate(0, 0) == 1
	assert candidate(0, 10) == False
	assert candidate(1, 1) == 1
	assert candidate(3, 1) == 0
def test_check():
	check(lxnor)
