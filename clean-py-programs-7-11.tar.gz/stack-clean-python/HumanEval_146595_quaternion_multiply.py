def quaternion_multiply(q, r):
    """ 
     Computes quaternion multiplication
     :param q: Quaternion
     :param r: Quaternion
     :return:
     """
	### Canonical solution below ###    
    q_w = q[0]
    q_x = q[1]
    q_y = q[2]
    q_z = q[3]
    r_w = r[0]
    r_x = r[1]
    r_y = r[2]
    r_z = r[3]
    return [
        q_w * r_w - q_x * r_x - q_y * r_y - q_z * r_z,
        q_w * r_x + q_x * r_w + q_y * r_z - q_z * r_y,
        q_w * r_y + q_y * r_w + q_z * r_x - q_x * r_z,
        q_w * r_z + q_z * r_w + q_x * r_y - q_y * r_x
    ]

### Unit tests below ###
def check(candidate):
	assert candidate(
    candidate([1, 0, 0, 0], [0, 1, 0, 0]),
    [0, 0, 1, 0]
) == [0, 0, 0, 1]
	assert candidate(
    [0, 0, 0, 1], [1, 0, 0, 0]) == [0, 0, 0, 1]
	assert candidate(
    [1, 0, 0, 0], [1, 0, 0, 0]) == [1, 0, 0, 0]
	assert candidate(candidate([1, 0, 0, 0], [0, 1, 0, 0]), [0, 0, 1, 0]) == [0, 0, 0, 1]
	assert candidate(
    [1, 0, 0, 0], [0, 0, 1, 0]) == [0, 0, 1, 0]
	assert candidate([1, 0, 0, 0], [0, 1, 0, 0]) == [0, 1, 0, 0]
	assert candidate(
    [1, 0, 0, 0], [0, 1, 0, 0]) == [0, 1, 0, 0]
	assert candidate(
    candidate([0, 0, 1, 0], [0, 0, 1, 0]),
    [0, 1, 0, 0]
) == [0, -1, 0, 0]
	assert candidate(
    candidate([0, 0, 1, 0], [0, 1, 0, 0]),
    [0, 0, 1, 0]
) == [0, 1, 0, 0]
	assert candidate([0, 1, 0, 0], [1, 0, 0, 0]) == [0, 1, 0, 0]
	assert candidate(
    [1, 2, 3, 4],
    [5, 6, 7, 8]
) == [-60, 12, 30, 24]
	assert candidate([1, 0, 0, 0], [0, 0, 0, 1]) == [0, 0, 0, 1]
	assert candidate(
    candidate([1, 0, 0, 0], [0, 0, 1, 0]),
    [0, 0, 0, 1]
) == [0, 1, 0, 0]
	assert candidate(
    [0, 1, 0, 0], [0, 1, 0, 0]) == [-1, 0, 0, 0]
	assert candidate(
    [0, 1, 0, 0], [1, 0, 0, 0]) == [0, 1, 0, 0]
	assert candidate(
    [0, 0, 1, 0], [1, 0, 0, 0]) == [0, 0, 1, 0]
	assert candidate(
    [1, 0, 0, 0],
    [1, 0, 0, 0]
) == [1, 0, 0, 0]
def test_check():
	check(quaternion_multiply)
