def tlv_find_tags(tlv_data, tags, num_results=None):
    """Find (and return) all instances of tags in the given tlv structure (as
    returned by unpack).  If num_results is specified then at most that many
    results will be returned."""
    ### Canonical solution below ###

    results = []

    def find_recursive(tlv_data):
        for d in tlv_data:
            t, l, v = d[:3]
            if t in tags:
                results.append(d)
            else:
                if isinstance(v, list):
                    find_recursive(v)

            if num_results is not None and len(results) >= num_results:
                return

    find_recursive(tlv_data)

    return results


### Unit tests below ###
def check(candidate):
	assert candidate(
    [ (1, 1, 1), (2, 1, 2), (3, 1, 3), (1, 1, 4), (1, 1, 5) ],
    [ 1 ],
    2
) == [
    (1, 1, 1), (1, 1, 4)
]
	assert candidate(
    [ (1, 1, 1), (2, 1, 2), (3, 1, 3), (1, 1, 4), (1, 1, 5) ],
    [ 1 ]
) == [
    (1, 1, 1), (1, 1, 4), (1, 1, 5)
]
	assert candidate(
    [ [ 1, 1, 1 ], [ 2, 1, 2 ], [ 2, 1, 3 ], [ 3, 1, 4 ] ], [ 2 ]
) == [ [ 2, 1, 2 ], [ 2, 1, 3 ] ]
	assert candidate(
    [ [ 1, 1, 1 ], [ 2, 1, 2 ], [ 2, 1, 3 ], [ 3, 1, 4 ] ], [ 2 ], 1
) == [ [ 2, 1, 2 ] ]
	assert candidate(
    [
        [0x01, 0x01, 0x01],
        [0x02, 0x02, 0x02],
        [0x03, 0x03, 0x03],
        [0x04, 0x04, 0x04],
        [0x01, 0x01, 0x01],
        [0x02, 0x02, 0x02],
        [0x03, 0x03, 0x03],
        [0x04, 0x04, 0x04],
        [0x05, 0x05, 0x05],
        [0x06, 0x06, 0x06],
    ],
    [0x01],
) == [
    [0x01, 0x01, 0x01],
    [0x01, 0x01, 0x01],
]
def test_check():
	check(tlv_find_tags)
