def namespaceTypeLabel(namespace) :
    """
    Provide a consistent naming scheme to users for embedded workflows
    """
    ### Canonical solution below ###
    if namespace == "" :
        return "master workflow"
    else :
        return "sub-workflow"


### Unit tests below ###
def check(candidate):
	assert candidate(namespace="") == "master workflow"
	assert candidate(namespace="test") == "sub-workflow"
	assert candidate("namespace") == "sub-workflow"
	assert candidate("") == "master workflow"
	assert candidate("foo") == "sub-workflow"
	assert candidate( "sub-workflow" ) == "sub-workflow"
	assert candidate( "subworkflow" ) == "sub-workflow", "Failed candidate test for subworkflow"
	assert candidate("my-namespace") == "sub-workflow"
	assert candidate("ns1") == "sub-workflow"
	assert candidate( "" ) == "master workflow", "Failed candidate test for master workflow"
	assert candidate( "namespace" ) == "sub-workflow"
	assert candidate( "" ) == "master workflow"
	assert candidate("test") == "sub-workflow"
	assert candidate( "" ) == "master workflow", "candidate failed on empty string"
	assert candidate( "a" ) == "sub-workflow"
	assert candidate( "foo" ) == "sub-workflow"
def test_check():
	check(namespaceTypeLabel)
