def _in_cis(chrom, pos, gene_id, tss_dict, window=1000000):
    """ Test if a variant-gene pair is in cis"""
	### Canonical solution below ###    
    if chrom==tss_dict[gene_id]['chr']:
        tss = tss_dict[gene_id]['tss']
        if pos>=tss-window and pos<=tss+window:
            return True
        else:
            return False
    else:
        return False

### Unit tests below ###
def check(candidate):
	assert candidate(1, 1000000, 'gene1', {'gene1':{'chr':1, 'tss':1100000}}, 100000) == True
	assert candidate(2, 1000000, 'gene1', {'gene1':{'chr':1, 'tss':1100000}}, 100000) == False
	assert candidate(1, 1000000, 'gene1', {'gene1':{'chr':1, 'tss':900000}}) == True
	assert candidate(2, 1000000, 'gene1', {'gene1':{'chr':2, 'tss':1100000}}, 100000) == True
def test_check():
	check(_in_cis)
