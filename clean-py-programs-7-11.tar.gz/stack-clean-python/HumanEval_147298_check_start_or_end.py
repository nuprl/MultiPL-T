def check_start_or_end(dates, today):
    """ 
     Function:
     check_start_or_end
     Description:
     checks if given date starts or ends today
     Input:
     - dates - a list containing start and end date (strings) for an event
     - today - today's date (string)
     Output:
     - 0 if no event starts or ends today
     - 1 if event starts and ends today
     - 2 if event starts today and ends on a later date
     - 3 if event started on a previous date and ends today
     """
	### Canonical solution below ###    
    if today == dates[0]:
        if today == dates[1]:
            return 1
        else:
            return 2
    elif today == dates[1]:
        return 3
    else:
        return 0

### Unit tests below ###
def check(candidate):
	assert candidate(
    ['2018-09-09', '2018-09-10'], '2018-09-09') == 2
	assert candidate(
    ['2015-12-07', '2015-12-08'], '2015-12-06') == 0, "Testing candidate"
	assert candidate(dates=["2019-10-03", "2019-10-04"], today="2019-10-03") == 2
	assert candidate(
    ['2018-08-10', '2018-08-10'],
    '2018-08-10'
    ) == 1,'should be 1'
	assert candidate(dates=['2019-04-14', '2019-04-17'], today='2019-04-18') == 0
	assert candidate(
    ["2017-03-17", "2017-03-19"], "2017-03-18") == 0
	assert candidate(dates=['2018-03-12', '2018-03-15'], today='2018-03-11') == 0
	assert candidate(dates=["2020-05-11", "2020-05-12"], today="2020-05-10") == 0
	assert candidate(
    ['2021-01-01', '2021-01-03'], '2020-12-31') == 0
	assert candidate(dates=['2019-04-14', '2019-04-17'], today='2019-04-13') == 0
	assert candidate(dates=['2018-06-01', '2018-06-02'], today='2018-06-02') == 3
	assert candidate(dates=['10-05-2021', '10-05-2021'], today='10-05-2021') == 1
	assert candidate(dates=["2021-09-08", "2021-09-09"], today="2021-09-10") == 0
	assert candidate(
    ['2019-09-10', '2019-09-11'], '2019-09-12') == 0
	assert candidate(dates=['2018-03-12', '2018-03-15'], today='2018-03-15') == 3
	assert candidate(dates=['10-05-2021', '10-05-2022'], today='10-05-2021') == 2
	assert candidate(dates=["2020-05-11", "2020-05-12"], today="2020-05-13") == 0
	assert candidate(
    ['2021-01-01', '2021-01-03'], '2021-01-04') == 0
	assert candidate(dates=['2018-01-01', '2018-01-02'], today='2018-01-02') == 3
	assert candidate(dates=['2018-01-01', '2018-01-02'], today='2018-01-04') == 0
	assert candidate(dates=['2021-08-20', '2021-08-21'], today='2021-08-22') == 0
	assert candidate(dates=["2018-11-11", "2018-11-12"], today="2018-11-12") == 3
	assert candidate(dates=["2019-10-03", "2019-10-03"], today="2019-10-04") == 0
	assert candidate(dates=["2021-09-08", "2021-09-09"], today="2021-09-07") == 0
	assert candidate(dates=["2018-11-12", "2018-11-13"], today="2018-11-12") == 2
	assert candidate(dates=['2021-01-01', '2021-01-02'], today='2021-01-03') == 0
	assert candidate(dates=['2021-01-01', '2021-01-02'], today='2021-01-02') == 3
	assert candidate(
    ['2018-09-09', '2018-09-10'], '2018-09-08') == 0
	assert candidate(dates=["2019-10-03", "2019-10-05"], today="2019-10-05") == 3
	assert candidate(dates=['01/01/2020', '01/02/2020'], today='01/03/2020') == 0
	assert candidate(dates=["2021-02-19", "2021-02-20"], today="2021-02-20") == 3
	assert candidate(dates=['2018-12-31', '2018-12-31'], today='2018-12-31') == 1
	assert candidate(dates=['2018-06-01', '2018-06-02'], today='2018-06-03') == 0
	assert candidate(dates=["2018-11-13", "2018-11-14"], today="2018-11-12") == 0
	assert candidate(dates=["2019-10-03", "2019-10-03"], today="2019-10-03") == 1
	assert candidate(
    ['2019-09-10', '2019-09-11'], '2019-09-11') == 3
	assert candidate(
    ["2017-03-16", "2017-03-18"], "2017-03-18") == 3
	assert candidate(dates=['2018-01-01', '2018-01-02'], today='2018-01-03') == 0
	assert candidate(
    ['2020-06-01', '2020-06-02'], '2020-06-03') == 0
	assert candidate(dates=['2020-03-04', '2020-03-05'], today='2020-03-03') == 0
	assert candidate(dates=['2019-04-14', '2019-04-17'], today='2019-04-17') == 3
	assert candidate(dates=["2021-09-08", "2021-09-09"], today="2021-09-09") == 3
	assert candidate(dates=["2021-02-19", "2021-02-20"], today="2021-02-21") == 0
	assert candidate(
    ["2017-03-18", "2017-03-20"], "2017-03-18") == 2
	assert candidate(dates=["2020-01-01", "2020-01-02"], today="2020-01-03") == 0
	assert candidate(dates=["2018-11-12", "2018-11-12"], today="2018-11-12") == 1
	assert candidate(dates=['09-05-2021', '10-05-2021'], today='10-05-2021') == 3
	assert candidate(
    ["2018-09-01", "2018-09-02"], "2018-08-31"
) == 0, "Test 3"
	assert candidate(dates=["2020-01-01", "2020-01-02"], today="2020-01-02") == 3
	assert candidate(dates=["2020-05-11", "2020-05-12"], today="2020-05-12") == 3
	assert candidate(dates=['2018-06-01', '2018-06-02'], today='2018-05-31') == 0
	assert candidate(
    ['2018-08-10', '2018-08-11'],
    '2018-08-10'
    ) == 2,'should be 2'
	assert candidate(dates=["2019-10-03", "2019-10-05"], today="2019-10-04") == 0
	assert candidate(
    ['2021-01-01', '2021-01-03'], '2021-01-02') == 0
	assert candidate(dates=["2019-10-03", "2019-10-04"], today="2019-10-04") == 3
	assert candidate(
    ['2019-09-10', '2019-09-11'], '2019-09-09') == 0
	assert candidate(
    ['2018-08-10', '2018-08-11'],
    '2018-08-12'
    ) == 0,'should be 0'
	assert candidate(
    ["2017-03-18", "2017-03-20"], "2017-03-19") == 0
def test_check():
	check(check_start_or_end)
