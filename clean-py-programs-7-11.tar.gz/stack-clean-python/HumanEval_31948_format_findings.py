def format_findings(findings, root):
    """ Format findings."""
	### Canonical solution below ###    
    for details in findings.values():
        tmp_dict = {}
        for file_meta in details['files']:
            file_meta['file_path'] = file_meta[
                'file_path'].replace(root, '', 1)
            file_path = file_meta['file_path']
            start = file_meta['match_lines'][0]
            end = file_meta['match_lines'][1]
            if start == end:
                match_lines = start
            else:
                exp_lines = []
                for i in range(start, end + 1):
                    exp_lines.append(i)
                match_lines = ','.join(str(m) for m in exp_lines)
            if file_path not in tmp_dict:
                tmp_dict[file_path] = str(match_lines)
            elif tmp_dict[file_path].endswith(','):
                tmp_dict[file_path] += str(match_lines)
            else:
                tmp_dict[file_path] += ',' + str(match_lines)
        details['files'] = tmp_dict
    return findings

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'file1': {'files': [{'file_path': 'file1','match_lines': [1, 2]}]}},
    'root'
) == {'file1': {'files': {'file1': '1,2'}}}
	assert candidate(
    {'a': {'files': [{'file_path': 'b','match_lines': [1, 2]}]},
     'b': {'files': [{'file_path': 'a','match_lines': [3, 4]}]}}, '') == {
        'a': {'files': {'b': '1,2'}}, 'b': {'files': {'a': '3,4'}}}
	assert candidate(
    {'file1': {'files': [{'file_path': 'file1','match_lines': [1, 2]}]},
     'file2': {'files': [{'file_path': 'file2','match_lines': [3, 4]}]}},
    'root'
) == {'file1': {'files': {'file1': '1,2'}},
      'file2': {'files': {'file2': '3,4'}}}
	assert candidate(
    {'foo': {'files': [{'file_path': '/foo','match_lines': [1, 2]}]}},
    '/foo/bar') == {'foo': {'files': {'/foo': '1,2'}}}
	assert candidate(
    {'file.txt': {'files': [{'file_path': 'file.txt','match_lines': [1, 2]}]}},
    '/root') == {
        'file.txt': {'files': {'file.txt': '1,2'}}}
	assert candidate(
    {'test.txt': {'files': [{'file_path': 'test.txt','match_lines': [1, 2]}, {'file_path': 'test2.txt','match_lines': [3, 4]}]}},
    'test/root/') == {'test.txt': {'files': {'test.txt': '1,2', 'test2.txt': '3,4'}}}
	assert candidate(
    {'file.txt': {'files': [{'file_path': 'file.txt','match_lines': [1, 2]},
                            {'file_path': 'file.txt','match_lines': [3, 4]}]}},
    '/root') == {
        'file.txt': {'files': {'file.txt': '1,2,3,4'}}}
	assert candidate(
    {'a': {'files': [{'file_path': '/tmp/a','match_lines': [1, 2]}],
           'description': 'a',
          'severity': 'INFO'}},
    '/tmp/b') == {
    'a': {'files': {'/tmp/a': '1,2'},
          'description': 'a',
         'severity': 'INFO'}}
	assert candidate(
    {'file': {'files': [{'file_path': 'file.txt','match_lines': (1, 1)}]}},
    'root') == {
        'file': {
            'files': {
                'file.txt': '1'
            }
        }
    }
	assert candidate(
    {'foo': {'files': [{'file_path': '/foo','match_lines': [1, 2]}]}},
    '/bar') == {'foo': {'files': {'/foo': '1,2'}}}
	assert candidate(
    {'file': {'files': [{'file_path': 'file.txt','match_lines': (1, 2)}]}},
    'root') == {
        'file': {
            'files': {
                'file.txt': '1,2'
            }
        }
    }
	assert candidate(
    {'a': {'files': [{'file_path': 'a','match_lines': (1, 1)},
                    {'file_path': 'a','match_lines': (2, 2)},
                    {'file_path': 'a','match_lines': (3, 3)}]}},
    'b') == {
    'a': {
        'files': {
            'a': '1,2,3'
        }
    }
}
	assert candidate(
    {'file1': {'files': [{'file_path': 'file1','match_lines': [1, 2]},
                         {'file_path': 'file1','match_lines': [3, 4]}]}},
    'root'
) == {'file1': {'files': {'file1': '1,2,3,4'}}}
	assert candidate(
    {'file1': {'files': [{'file_path': '/root/file1','match_lines': [1, 2]}, {'file_path': '/root/file2','match_lines': [3, 4]}]}},
    '/root') == {'file1': {'files': {'/file1': '1,2', '/file2': '3,4'}}}
	assert candidate(
    {'a': {'files': [{'file_path': 'a','match_lines': [1, 2]}]}}, '') == {
        'a': {'files': {'a': '1,2'}}}
	assert candidate(
    {'file': {'files': [{'file_path': 'file.txt','match_lines': (1, 1)},
                        {'file_path': 'file.txt','match_lines': (2, 2)},
                        {'file_path': 'file.txt','match_lines': (3, 3)}]}},
    'root') == {
        'file': {
            'files': {
                'file.txt': '1,2,3'
            }
        }
    }
	assert candidate(
    {'file.py': {'files': [{'file_path': 'file.py','match_lines': [1, 2]}]}},
    '/path/to/') == {'file.py': {'files': {'file.py': '1,2'}}}
	assert candidate(
    {'a': {'files': [{'file_path': 'a','match_lines': (1, 1)},
                    {'file_path': 'a','match_lines': (2, 2)},
                    {'file_path': 'a','match_lines': (3, 3)}]}},
    '') == {
    'a': {
        'files': {
            'a': '1,2,3'
        }
    }
}
	assert candidate(
    {'foo': {'files': [{'file_path': '/foo/bar','match_lines': [1, 2]}]}},
    '/foo') == {'foo': {'files': {'/bar': '1,2'}}}
	assert candidate(
    {'file.py': {'files': [{'file_path': 'file.py','match_lines': [1, 2]},
                           {'file_path': 'file.py','match_lines': [3, 4]}]}},
    '/path/to/') == {'file.py': {'files': {'file.py': '1,2,3,4'}}}
	assert candidate(
    {'f1': {'files': [{'file_path': 'a.txt','match_lines': [1, 2]},
                      {'file_path': 'b.txt','match_lines': [3, 4]}],
           'findings': 'f1',
          'reason': 'f1',
          'recommendation': 'f1'},
     'f2': {'files': [{'file_path': 'b.txt','match_lines': [1, 2]}],
           'findings': 'f2',
          'reason': 'f2',
          'recommendation': 'f2'},
     'f3': {'files': [{'file_path': 'a.txt','match_lines': [1, 2]}],
           'findings': 'f3',
          'reason': 'f3',
          'recommendation': 'f3'}},
    '/path/to/') == {
    'f1': {'files': {'a.txt': '1,2', 'b.txt': '3,4'},
           'findings': 'f1',
          'reason': 'f1',
          'recommendation': 'f1'},
    'f2': {'files': {'b.txt': '1,2'},
           'findings': 'f2',
          'reason': 'f2',
          'recommendation': 'f2'},
    'f3': {'files': {'a.txt': '1,2'},
           'findings': 'f3',
          'reason': 'f3',
          'recommendation': 'f3'}}
	assert candidate(
    {'a': {'files': [{'file_path': 'b','match_lines': [1, 2]}]}}, 'a') == {
        'a': {'files': {'b': '1,2'}}}
	assert candidate(
    {'file.txt': {'files': [{'file_path': 'file.txt','match_lines': [1, 2]},
                            {'file_path': 'file.txt','match_lines': [3, 4]},
                            {'file_path': 'file.txt','match_lines': [5, 6]}]}},
    '/root') == {
        'file.txt': {'files': {'file.txt': '1,2,3,4,5,6'}}}
	assert candidate(
    {'file1': {'files': [{'file_path': '/root/file1','match_lines': [1, 2]}, {'file_path': '/root/file1','match_lines': [3, 4]}]}},
    '/root') == {'file1': {'files': {'/file1': '1,2,3,4'}}}
	assert candidate(
    {'test.txt': {'files': [{'file_path': 'test.txt','match_lines': [1, 2]}, {'file_path': 'test.txt','match_lines': [3, 4]}]}},
    'test/root/') == {'test.txt': {'files': {'test.txt': '1,2,3,4'}}}
	assert candidate(
    {'file': {'files': [{'file_path': 'file.txt','match_lines': (1, 1)},
                        {'file_path': 'file.txt','match_lines': (2, 2)}]}},
    'root') == {
        'file': {
            'files': {
                'file.txt': '1,2'
            }
        }
    }
	assert candidate(
    {
        'file1': {
            'files': [
                {
                    'file_path': 'file1',
                   'match_lines': (1, 1)
                }
            ],
            'description': 'desc1'
        },
        'file2': {
            'files': [
                {
                    'file_path': 'file2',
                   'match_lines': (1, 2)
                }
            ],
            'description': 'desc2'
        }
    },
    '/tmp') == {
        'file1': {
            'files': {
                'file1': '1'
            },
            'description': 'desc1'
        },
        'file2': {
            'files': {
                'file2': '1,2'
            },
            'description': 'desc2'
        }
    }
	assert candidate(
    {'test.txt': {'files': [{'file_path': 'test.txt',
                           'match_lines': (1, 2)},
                           {'file_path': 'test2.txt',
                           'match_lines': (3, 4)}]}},
    'test/').get('test.txt').get('files').get('test.txt') == '1,2'
	assert candidate(
    {'a': {'files': [{'file_path': 'b','match_lines': [1, 2]}]}}, '') == {
        'a': {'files': {'b': '1,2'}}}
	assert candidate(
    {'test.txt': {'files': [{'file_path': 'test.txt','match_lines': [1, 2]}]}},
    'test/root/') == {'test.txt': {'files': {'test.txt': '1,2'}}}
	assert candidate(
    {'file1': {'files': [{'file_path': '/root/file1','match_lines': [1, 2]}]}},
    '/root') == {'file1': {'files': {'/file1': '1,2'}}}
	assert candidate(
    {'file1': {'files': [{'file_path': 'file2','match_lines': [3, 4]}]}},
    'root'
) == {'file1': {'files': {'file2': '3,4'}}}
	assert candidate(
    {'file1': {'files': [{'file_path': 'file1','match_lines': [1, 2]},
                         {'file_path': 'file2','match_lines': [3, 4]}]}},
    'root'
) == {'file1': {'files': {'file1': '1,2', 'file2': '3,4'}}}
def test_check():
	check(format_findings)
