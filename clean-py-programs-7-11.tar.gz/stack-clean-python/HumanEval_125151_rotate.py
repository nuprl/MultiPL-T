def rotate(list_a: list, places: int):
    """ Problem 19: Rotate a List N places to the left.
     
     Parameters
     ----------
     list_a : list
     The input list
     places : int
     The number of places to rotate the list to the left
     
     Returns
     -------
     list
     A list rotated n places to the left.
     
     Raises
     ------
     TypeError
     If the given argument is not of `list` type
     
     """
	### Canonical solution below ###    
    if not isinstance(list_a, list):
        raise TypeError('The argument given is not of `list` type.')

    places = places % len(list_a)
    rotated = list_a[places:]
    rotated.extend(list_a[:places])
    return rotated

### Unit tests below ###
def check(candidate):
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=0) == [1, 2, 3, 4, 5, 6]
	assert candidate(list_a=[1, 2, 3, 4, 5], places=3) == [4, 5, 1, 2, 3]
	assert candidate(list('abcde'), 5) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(list_a=list('abcde'), places=15) == list('abcde')
	assert candidate(list('abcde'), 10) == list('abcde')
	assert candidate(list_a=[1, 2, 3, 4, 5], places=-1) == [5, 1, 2, 3, 4]
	assert candidate(list_a=[1, 2, 3, 4, 5], places=7) == [3, 4, 5, 1, 2]
	assert candidate(list_a=list('abcde'), places=-5) == list('abcde')
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=-3) == [4, 5, 6, 1, 2, 3]
	assert candidate(list_a=[1, 2, 3], places=9) == [1, 2, 3]
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=-4) == [3, 4, 5, 6, 1, 2]
	assert candidate(list('abcdefghijklmnopqrstuvwxyz'), 13) == list('nopqrstuvwxyzabcdefghijklm')
	assert candidate(list('ABC'), 6) == list('ABC')
	assert candidate(list_a=list(range(10)), places=5) == [5, 6, 7, 8, 9, 0, 1, 2, 3, 4]
	assert candidate(list('ABC'), 2) == list('CAB')
	assert candidate(list_a=list('abcde'), places=2) == ['c', 'd', 'e', 'a', 'b']
	assert candidate(list('abcde'), 6) == list('bcdea')
	assert candidate(list_a=list('abcde'), places=3) == ['d', 'e', 'a', 'b', 'c']
	assert candidate(list_a=list('abcde'), places=5) == list('abcde')
	assert candidate(list_a=list('abcde'), places=10) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(list_a=[1, 2, 3], places=6) == [1, 2, 3]
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=6) == [1, 2, 3, 4, 5, 6]
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 10) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(list('ABCDE'), 0) == ['A', 'B', 'C', 'D', 'E']
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(list_a=list('abcde'), places=-10) == list('abcde')
	assert candidate(list_a=[1, 2, 3, 4, 5], places=-9)
	assert candidate(list_a=[1, 2, 3], places=3) == [1, 2, 3]
	assert candidate(list_a=list('abcde'), places=3) == list('deabc')
	assert candidate(list('ABC'), 8) == list('CAB')
	assert candidate(list('ABCDE'), 3) == ['D', 'E', 'A', 'B', 'C']
	assert candidate(list('abcde'), 15) == list('abcde')
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=-1) == [6, 1, 2, 3, 4, 5]
	assert candidate(list_a=[1, 2, 3, 4, 5], places=2) == [3, 4, 5, 1, 2]
	assert candidate(list_a=[1, 2, 3, 4, 5], places=5) == [1, 2, 3, 4, 5]
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=-2) == [5, 6, 1, 2, 3, 4]
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=3) == [4, 5, 6, 1, 2, 3]
	assert candidate(list_a=list('abcde'), places=4) == list('eabcd')
	assert candidate(list_a=[1, 2, 3, 4, 5], places=0) == [1, 2, 3, 4, 5]
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3) == [4, 5, 6, 7, 8, 9, 10, 1, 2, 3]
	assert candidate(list('abcde'), 5) == list('abcde')
	assert candidate(list_a=list('abcde'), places=-15) == list('abcde')
	assert candidate(list_a=list('abcde'), places=2) == list('cdeab')
	assert candidate(list('abcde'), 9) == list('eabcd')
	assert candidate(list('ABC'), 3) == list('ABC')
	assert candidate(list_a=list('abcde'), places=0) == list('abcde')
	assert candidate(['a', 'b', 'c', 'd', 'e'], 5) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1000000) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(list_a=list('abcde'), places=5) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(list_a=list('abcde'), places=10) == list('abcde')
	assert candidate(list_a=list('abcde'), places=1) == list('bcdea')
	assert candidate(list_a=list('abcde'), places=0) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(list_a=[1, 2, 3, 4, 5, 6], places=2) == [3, 4, 5, 6, 1, 2]
def test_check():
	check(rotate)
