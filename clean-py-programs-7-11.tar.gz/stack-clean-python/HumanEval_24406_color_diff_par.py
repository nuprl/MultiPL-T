def color_diff_par(pair):
    """ 
     Find the difference between two colors. This is part of `closest_color_parallel`
     below, but multiprocessing cannot pickle nested functions.
     
     Parameters
     ----------
     pair : (rgb, pixel)
     Check how close `rgb` is to `pixel`.
     
     Returns
     -------
     int
     The difference between `rgb` and `pixel`.
     """
	### Canonical solution below ###    
    rgb, x = pair
    r, g, b = rgb
    return abs(r - x[0]) ** 2 + abs(g - x[1]) ** 2 + abs(b - x[2]) ** 2

### Unit tests below ###
def check(candidate):
	assert candidate(
    ((128, 0, 0), (128, 0, 0))
) == 0
	assert candidate(
    ((14, 14, 14), (14, 14, 14))) == 0
	assert candidate(
    ((0, 0, 0), (10, 10, 10))) == 300
	assert candidate(
    (
        (1, 1, 1),
        (0, 0, 0)
    )
) == 3
	assert candidate( ((1, 1, 1), (0, 0, 0)) ) == 3
	assert candidate( ((128,128,128), (128,128,128)) ) == 0
	assert candidate( ((255,255,255), (0,0,0)) ) == 195075
	assert candidate( ((0, 0, 0), (0, 255, 0)) ) == 65025
	assert candidate(
    ((0, 0, 255), (0, 0, 255))
) == 0
	assert candidate( ((0,255,0), (0,255,0)) ) == 0
	assert candidate(
    ((0, 0, 0), (0, 0, 0))
) == 0
	assert candidate( ((255,0,0), (255,0,0)) ) == 0
	assert candidate( ((0, 0, 0), (0, 0, 0)) ) == 0
	assert candidate( ((1, 1, 1), (1, 1, 1)) ) == 0
	assert candidate(
    ((0, 0, 0), (255, 255, 255))
) == 195075
	assert candidate(
    ((0, 0, 0), (0, 0, 0))) == 0
	assert candidate(
    ((128, 0, 0), (129, 0, 0))
) == 1
	assert candidate(
    ((14, 14, 14), (15, 15, 14))) == 2
	assert candidate(
    (
        (123, 123, 123),
        (123, 123, 123)
    )
) == 0
	assert candidate( ((1, 2, 3), (1, 2, 3)) ) == 0
	assert candidate(
    ((255, 255, 255), (0, 0, 0))) == 195075
	assert candidate( ((0,0,255), (0,0,255)) ) == 0
	assert candidate( ((0, 0, 0), (255, 0, 0)) ) == 65025
	assert candidate(
    (
        (123, 123, 123),
        (123, 122, 123)
    )
) == 1
	assert candidate(
    ((128, 0, 0), (128, 0, 1))
) == 1
	assert candidate( ((1, 1, 1), (1, 2, 3)) ) == 5
	assert candidate(
    ((255, 255, 255), (255, 255, 255))
) == 0
	assert candidate( ((1, 1, 1), (1, 1, 0)) ) == 1
	assert candidate( ((0,0,0), (255,255,255)) ) == 195075
	assert candidate(
    (
        (1, 1, 1),
        (1, 1, 1)
    )
) == 0
	assert candidate(
    (
        (123, 123, 123),
        (123, 123, 122)
    )
) == 1
	assert candidate(
    ((14, 14, 14), (15, 14, 14))) == 1
	assert candidate( ((0, 0, 0), (0, 0, 255)) ) == 65025
	assert candidate(
    (
        (123, 123, 123),
        (122, 123, 123)
    )
) == 1
	assert candidate(
    ((127, 127, 127), (127, 127, 127))
) == 0
	assert candidate(
    ((255, 255, 255), (255, 255, 255))) == 0
	assert candidate(
    ((10, 10, 10), (0, 0, 0))) == 300
	assert candidate(
    ((10, 10, 10), (10, 10, 10))) == 0
	assert candidate(
    ((255, 255, 255), (0, 0, 0))
) == 195075
	assert candidate(
    ((255, 0, 0), (255, 0, 0))) == 0
	assert candidate( ((0,0,0), (0,0,0)) ) == 0
	assert candidate(
    ((128, 0, 0), (128, 1, 0))
) == 1
	assert candidate( ((255,255,255), (255,255,255)) ) == 0
	assert candidate( ((0, 0, 0), (1, 1, 1)) ) == 3
	assert candidate( ((255, 255, 255), (255, 255, 255)) ) == 0
	assert candidate(
    ((14, 14, 14), (15, 15, 15))) == 3
	assert candidate(
    ((128, 0, 0), (128, 1, 1))
) == 2
def test_check():
	check(color_diff_par)
