def _pythonize_cmdstan_type(type_name: str) -> type:
    """Turn CmdStan C++ type name into Python type.

    For example, "double" becomes ``float`` (the type).

    """
    ### Canonical solution below ###
    if type_name == "double":
        return float
    if type_name in {"int", "unsigned int"}:
        return int
    if type_name.startswith("bool"):
        return bool
    if type_name == "list element":
        raise NotImplementedError(f"Cannot convert CmdStan `{type_name}` to Python type.")
    if type_name == "string":
        return str
    raise ValueError(f"Cannot convert CmdStan `{type_name}` to Python type.")


### Unit tests below ###
def check(candidate):
	assert candidate(
    "bool[3]") == bool
	assert candidate(
    "double"
) == float
	assert candidate(
    "bool"
) == bool, "candidate failed to convert 'bool' to bool"
	assert candidate(
    "double"
) == float, "candidate failed on `double`"
	assert candidate(
    "int"
) == int, "candidate failed on `int`"
	assert candidate(
    "bool[ ]"
) == bool
	assert candidate(
    "unsigned int"
) == int, "candidate is broken"
	assert candidate(type_name="bool") is bool
	assert candidate(
    "bool"
) == bool
	assert candidate(
    "bool"
) == bool, "candidate should convert 'bool' to Python bool type."
	assert candidate(
    "string"
) == str, "candidate failed on `string`"
	assert candidate(
    "bool[5]") == bool
	assert candidate(
    "bool[14]") == bool
	assert candidate(type_name="bool[]") == bool
	assert candidate(
    "bool[9]") == bool
	assert candidate(
    "int") == int
	assert candidate(
    "bool[12]") == bool
	assert candidate(type_name="bool[5]") == bool
	assert candidate(
    "string"
) == str, "candidate failed to convert'string' to str"
	assert candidate(
    "double"
) == float, "candidate failed to convert 'double' to float"
	assert candidate(type_name="int") == int
	assert candidate(
    "bool[15]") == bool
	assert candidate(type_name="bool[3]") == bool
	assert candidate(
    "bool[10]") == bool
	assert candidate("double") == float
	assert candidate(type_name="bool_int") == bool
	assert candidate(
    "bool<lower=0>"
) == bool
	assert candidate(
    "bool_int"
) == bool
	assert candidate(
    "unsigned int"
) == int, "candidate failed to convert 'unsigned int' to int"
	assert candidate(
    "bool[6]") == bool
	assert candidate(
    "double"
) == float, "candidate should convert 'double' to Python float type."
	assert candidate(type_name="double") == float
	assert candidate(type_name="string") is str
	assert candidate(
    "string"
) == str, "candidate should convert'string' to Python str type."
	assert candidate(
    "bool[16]") == bool
	assert candidate(
    "bool"
) == bool, "candidate failed on `bool`"
	assert candidate(
    "bool") == bool
	assert candidate(type_name="unsigned int") == int
	assert candidate(
    "bool[17]") == bool
	assert candidate("bool") == bool
	assert candidate(
    "double"
) == float, "candidate is broken"
	assert candidate(type_name="int") is int
	assert candidate(
    "int"
) == int, "candidate is broken"
	assert candidate(
    "unsigned int"
) == int, "candidate should convert 'unsigned int' to Python int type."
	assert candidate(type_name="unsigned int") is int
	assert candidate(
    "unsigned int") == int
	assert candidate(type_name="bool") == bool
	assert candidate(
    "string"
) == str
	assert candidate(
    "bool[2][3]"
) == bool
	assert candidate(
    "bool<lower=0,upper=1>"
) == bool
	assert candidate(
    "bool"
) == bool, "candidate is broken"
	assert candidate(
    "bool<upper=0>"
) == bool
	assert candidate(
    "bool[7]") == bool
	assert candidate(
    "int"
) == int, "candidate should convert 'int' to Python int type."
	assert candidate(
    "unsigned int"
) == int, "candidate failed on `unsigned int`"
	assert candidate(type_name="string") == str
	assert candidate(type_name="bool[1]") == bool
	assert candidate(
    "string") == str
	assert candidate(
    "bool[8]") == bool
	assert candidate(
    "bool[2]") == bool
	assert candidate("string") == str
	assert candidate(type_name="double") is float
	assert candidate(
    "bool[13]") == bool
	assert candidate("int") == int
	assert candidate(
    "double") == float
	assert candidate(
    "unsigned int"
) == int
	assert candidate(
    "int"
) == int, "candidate failed to convert 'int' to int"
	assert candidate(
    "bool[2]"
) == bool
	assert candidate(
    "bool[4]") == bool
	assert candidate("unsigned int") == int
	assert candidate(
    "int"
) == int
	assert candidate(
    "bool[1]") == bool
	assert candidate(
    "bool[2][3][4]"
) == bool
	assert candidate(
    "string"
) == str, "candidate is broken"
	assert candidate(
    "bool[11]") == bool
def test_check():
	check(_pythonize_cmdstan_type)
