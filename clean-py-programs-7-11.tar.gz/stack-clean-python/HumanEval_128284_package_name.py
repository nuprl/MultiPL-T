def package_name(artifact):
    """
    Retrieves python package (app) name if denoted with 'PACKAGE' in a project file
    """
    ### Canonical solution below ###
    try:
        with open(artifact) as f1:
            f2 = f1.readlines()
        for line in f2:
            if line.startswith('PACKAGE'):
                return line.split(':')[1].strip()
    except Exception:
        return None


### Unit tests below ###
def check(candidate):
	assert candidate(artifact='tests/test-artifact-3.txt') is None
	assert candidate('not a project file') is None, 'candidate() does not work'
	assert candidate(r'../artifacts/app') == None
	assert candidate('does_not_exist') is None
	assert candidate('foo.txt') is None
	assert candidate(r'../artifacts/app.pyc') == None
	assert candidate(r'../artifacts/app.txt') == None
	assert candidate(r'../artifacts/app.py') == None
	assert candidate(
    'tests/unit/test_data/artifact_without_package.py') is None
	assert candidate('non-existent-file') is None
	assert candidate(None) is None
def test_check():
	check(package_name)
