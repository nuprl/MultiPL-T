def remove_multiedges(E):
    """Returns ``(s, d, w)`` with unique ``(s, d)`` values and `w` minimized.

    :param E:       a set of edges
    :type E:        [(int, int, float)]
    :return:        a subset of edges `E`
    :rtype:         [(int, int, float), ...]
    """
    ### Canonical solution below ###
    result = []
    exclusion = set()
    for i, (si, di, wi) in enumerate(E):
        if i in exclusion:
            continue
        minimum = 0
        for j in range(i + 1, len(E)):
            if j in exclusion:
                continue
            sj, dj, wj = E[j]
            if si == sj and di == dj:
                if wi > wj:
                    exclusion.add(i)
                elif wi < wj:
                    exclusion.add(j)
        if i in exclusion:
            continue
        result.append(E[i])
    return result


### Unit tests below ###
def check(candidate):
	assert candidate(
    [(1, 2, 1), (1, 2, 2), (2, 3, 1), (2, 3, 3)]
) == [(1, 2, 1), (2, 3, 1)]
	assert candidate(
    [(0, 0, 1), (0, 1, 2), (0, 1, 3), (1, 1, 1), (1, 2, 2), (2, 2, 1)]) == \
    [(0, 0, 1), (0, 1, 2), (1, 1, 1), (1, 2, 2), (2, 2, 1)]
	assert candidate([(0, 0, 1)]) == [(0, 0, 1)]
	assert candidate(
    [(1, 2, 1), (1, 2, 2), (2, 3, 1), (1, 4, 1), (1, 4, 2), (1, 4, 3)]
) == [(1, 2, 1), (2, 3, 1), (1, 4, 1)]
	assert candidate(
    [(0, 1, 1), (0, 1, 2), (0, 1, 3), (0, 2, 1), (0, 2, 2), (1, 2, 1)]) == \
    [(0, 1, 1), (0, 2, 1), (1, 2, 1)]
	assert candidate(
    [(0, 1, 0.1), (0, 1, 0.2), (0, 1, 0.3), (0, 1, 0.4), (0, 1, 0.5), (0, 1, 0.6)]) == [(0, 1, 0.1)]
	assert candidate(
    [(1, 2, 1), (1, 2, 2), (1, 2, 3), (3, 4, 1), (3, 4, 2), (3, 4, 3)]) == \
    [(1, 2, 1), (3, 4, 1)]
	assert candidate(
    [(0, 0, 1), (0, 0, 2), (0, 1, 3), (0, 2, 4), (1, 2, 5)]) == \
    [(0, 0, 1), (0, 1, 3), (0, 2, 4), (1, 2, 5)]
	assert candidate(
    [(0, 1, 10), (0, 1, 20), (0, 1, 30), (0, 2, 40), (1, 2, 50), (1, 2, 60)]
) == [(0, 1, 10), (0, 2, 40), (1, 2, 50)]
	assert candidate(
    [(0, 1, 0.1), (0, 1, 0.2), (0, 1, 0.3), (0, 1, 0.4), (0, 1, 0.5), (0, 1, 0.6), (0, 1, 0.7)]) == [(0, 1, 0.1)]
	assert candidate(
    [(0, 1, 1), (0, 1, 2), (0, 1, 3), (0, 1, 4), (1, 2, 1), (1, 2, 2), (1, 2, 3)]
) == [(0, 1, 1), (1, 2, 1)]
	assert candidate(
    [(1, 2, 1), (1, 2, 2), (2, 3, 1), (2, 3, 3), (3, 4, 1), (3, 4, 3)]
) == [(1, 2, 1), (2, 3, 1), (3, 4, 1)]
	assert candidate(
    [(0, 1, 0.5), (1, 2, 1.0), (2, 3, 0.25), (3, 0, 0.25)]) == \
    [(0, 1, 0.5), (1, 2, 1.0), (2, 3, 0.25), (3, 0, 0.25)]
	assert candidate([(0, 0, 1), (0, 1, 1), (1, 1, 1)]) == \
    [(0, 0, 1), (0, 1, 1), (1, 1, 1)]
	assert candidate(
    [(0, 1, 1), (0, 1, 2), (1, 2, 3), (2, 3, 1), (3, 4, 2), (4, 5, 1)]) == \
    [(0, 1, 1), (1, 2, 3), (2, 3, 1), (3, 4, 2), (4, 5, 1)]
	assert candidate([(0, 0, 1), (0, 0, 2)]) == [(0, 0, 1)]
	assert candidate([(0, 0, 1), (0, 0, 2), (0, 1, 1), (1, 1, 1)]) == \
    [(0, 0, 1), (0, 1, 1), (1, 1, 1)]
	assert candidate(
    [(0, 1, 1), (0, 1, 2), (0, 2, 1), (0, 2, 2), (1, 2, 1)]) == \
    [(0, 1, 1), (0, 2, 1), (1, 2, 1)]
	assert candidate(
    [(0, 1, 0.1), (0, 1, 0.2), (0, 1, 0.3), (0, 1, 0.4), (0, 1, 0.5), (0, 1, 0.6), (0, 1, 0.7), (0, 1, 0.8)]) == [(0, 1, 0.1)]
	assert candidate(
    [(0, 0, 0.0), (0, 1, 1.0), (0, 1, 2.0), (1, 1, 3.0), (1, 1, 4.0)]) == \
    [(0, 0, 0.0), (0, 1, 1.0), (1, 1, 3.0)]
	assert candidate(
    [(1, 2, 1), (1, 2, 2), (3, 4, 3), (3, 4, 4)]) == \
    [(1, 2, 1), (3, 4, 3)]
	assert candidate(
    [(0, 1, 1), (0, 1, 2), (0, 2, 1), (0, 2, 2), (1, 2, 1), (1, 3, 1)]) == \
    [(0, 1, 1), (0, 2, 1), (1, 2, 1), (1, 3, 1)]
def test_check():
	check(remove_multiedges)
