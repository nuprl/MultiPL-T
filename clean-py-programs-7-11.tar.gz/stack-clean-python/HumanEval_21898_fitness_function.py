def fitness_function(solution, answer):
    """fitness_function(solution, answer) Returns a fitness score of a solution compaired to the desired answer. This score is the absolute 'ascii' distance between characters."""
    ### Canonical solution below ###
    score =0
    for i in range(len(answer)):
        score += (abs(solution[i]-answer[i]))
    return score


### Unit tests below ###
def check(candidate):
	assert candidate(b"aaaaa",b"aaaab") == 1
	assert candidate(b'a', b'a') == 0
	assert candidate(b'ab', b'ba') == 2
	assert candidate(b"h",b"h") == 0
	assert candidate(b'123', b'421') == 5
	assert candidate(b"aaaaa",b"aaaaa") == 0
	assert candidate(b'Hello', b'Hello') == 0
	assert candidate(b"hello",b"hello") == 0
	assert candidate(b'abcde', b'abcde') == 0
	assert candidate(b'123', b'124') == 1
	assert candidate(b"",b"") == 0
	assert candidate(b'abcde', b'abcdd') == 1
	assert candidate(b'a', b'b') == 1
	assert candidate(b"hello", b"hello") == 0
	assert candidate(b'123', b'123') == 0
def test_check():
	check(fitness_function)
