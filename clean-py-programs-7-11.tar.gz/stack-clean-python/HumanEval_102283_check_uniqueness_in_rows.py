def check_uniqueness_in_rows(board: list) -> bool:
    """ 
     Check buildings of unique height in each row.
     
     Return True if buildings in a row have unique length,
     False otherwise.
     
     >>> check_uniqueness_in_rows(['***21**', '412453*', '423145*',\
     '*543215', '*35214*', '*41532*', '*2*1***'])
     True
     >>> check_uniqueness_in_rows(['***21**', '452453*', '423145*',\
     '*543215', '*35214*', '*41532*', '*2*1***'])
     False
     >>> check_uniqueness_in_rows(['***21**', '412453*', '423145*',\
     '*553215', '*35214*', '*41532*', '*2*1***'])
     False
     """
	### Canonical solution below ###    
    # We chop each row
    for row in board[1:-1]:
        elements_int = []
        for elem in row[1:-1]:
            # If element can't be converted to int, it is skipped
            try:
                if int(elem) in elements_int:
                    return False
                else:
                    elements_int.append(int(elem))
            except:
                continue
    return True

### Unit tests below ###
def check(candidate):
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows #2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) == False, "Third"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']
) is False, "Uniqueness in rows test 2"
	assert candidate(['***']) == True
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows test 1"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows test 3"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "uniqueness in rows"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test 2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*',
     '*2*1***']) == False
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Second"
	assert candidate(
['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == False
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "First"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***'])
	assert not candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***'])
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows #3"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']
) is True, "Uniqueness in rows test 1"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Third"
	assert candidate(
['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***'])
	assert candidate(['*']) == True
	assert candidate(['***21**', '412453*', '423145*', '*553215',\
'*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows #3"
	assert not candidate(
['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***'])
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']
) is False, "Uniqueness in rows #2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']
) is False, "Uniqueness in rows test 3"
	assert candidate(
['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) == False
	assert not candidate(
['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***'])
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "uniqueness in rows"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*',
     '*2*1***']) == True
	assert candidate(['**']) == True
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']
) is True, "Uniqueness in rows #1"
	assert candidate(['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test 3"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == True, "Uniqueness in rows test 1"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) \
== False
	assert candidate(['***21**', '452453*', '423145*', '*543215',\
'*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows #2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']
) is False, "Uniqueness in rows #3"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test"
	assert not candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***'])
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) \
== True
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows test 2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "uniqueness in rows"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == False, "Second"
	assert candidate(['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test 2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) \
== False
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows #1"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == True, "First"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*',
     '*2*1***']) == False
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test 3"
	assert candidate(
['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == True
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows"
def test_check():
	check(check_uniqueness_in_rows)
