def isAnagramB(s, t):
    """ 
     :type s: str
     :type t: str
     :rtype: bool
     """
	### Canonical solution below ###	
	s=sorted(s)
	t=sorted(t)
	
	return s == t

### Unit tests below ###
def check(candidate):
	assert candidate("", "a") == False
	assert candidate("rat", "car") == False
	assert candidate( 'ab', 'ba' )
	assert candidate("abc", "abc") == True
	assert candidate( "ab", "aa") == False
	assert candidate("cat", "tac") == True
	assert candidate("abcde", "edcba") == True
	assert candidate("", "") == True
	assert candidate("abc", "acb") == True
	assert candidate('ba', 'ab') == True
	assert candidate( "rat", "car" ) == False
	assert candidate( "ab", "ba") == True
	assert candidate( "aa", "ab") == False
	assert candidate("abcd", "bacd") == True
	assert candidate('ab', 'abc') == False
	assert candidate("abc", "cba") == True
	assert candidate("abcd", "abcdf") == False
	assert candidate("dog", "god") == True
	assert candidate("anagram", "nagaram") == True
	assert candidate("a", "a") == True
	assert candidate("ab", "bb") == False
	assert candidate("a", "") == False
	assert candidate("ab", "ab") == True
	assert candidate( "car", "car") == True
	assert candidate("aab", "baa") == True
	assert candidate( "aabb", "abab") == True
	assert candidate("abcd", "deab") == False
	assert candidate( "a", "b") == False
	assert candidate( "anagram", "nagaram" ) == True
	assert candidate( "rat", "car") == False
	assert candidate("ab", "a") == False
	assert candidate( "abba", "baba" ) == True
	assert candidate("ab", "ba") == True
	assert candidate("aa", "bb") == False
	assert candidate("abcd", "bcda") == True
	assert candidate("aa", "ab") == False
	assert candidate("car", "rat") == False
	assert candidate("ab", "ac") == False
	assert candidate("abcd", "bcde") == False
	assert candidate("aab", "aab") == True
	assert candidate("abc", "ab") == False
	assert candidate( "a", "a" ) == True
	assert candidate('ab', 'ba') == True
	assert candidate("ab", "aa") == False
	assert candidate( "ab", "ba" ) == True
	assert candidate('aab', 'baa') == True
	assert candidate( "a", "a") == True
	assert candidate("abcd", "dcba") == True
	assert candidate("a", "b") == False
	assert not candidate( 'a', 'b' )
	assert candidate( "ab", "a") == False
	assert candidate('aabb', 'abab') == True
	assert candidate("abcd", "abcde") == False
	assert not candidate( 'ab', 'aa' )
	assert candidate("aab", "abb") == False
	assert candidate( 'aab', 'aba' )
	assert candidate("abca", "abc") == False
	assert candidate( "a", "" ) == False
	assert candidate('ab', 'bb') == False
	assert candidate('aabbcc', 'ababcc') == True
	assert candidate('ab', 'ab') == True
	assert candidate("ab", "abc") == False
	assert candidate("dog", "doggy") == False
	assert candidate( "a", "b" ) == False
	assert candidate("abc", "bca") == True
	assert candidate( "ab", "bb") == False
	assert not candidate( 'ab', 'ac' )
	assert candidate('a', 'b') == False
	assert candidate("a", "ab") == False
	assert candidate( "ab", "abx" ) == False
	assert candidate('a', 'a') == True
	assert candidate( "ab", "ab" ) == True
	assert not candidate( 'rat', 'car' )
	assert candidate("abcd", "cdab") == True
	assert candidate( "anagram", "nagaram") == True
	assert candidate( "aa", "bb" ) == False
	assert candidate('abc', 'cba') == True
	assert candidate('', '') == True
	assert candidate( 'anagram', 'nagaram' )
	assert candidate( 'ab', 'ab' )
	assert candidate( "aab", "aba") == True
	assert candidate('aabbcc', 'ababca') == False
def test_check():
	check(isAnagramB)
