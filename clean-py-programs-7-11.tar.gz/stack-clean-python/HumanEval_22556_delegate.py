def delegate(session_attributes, slots):
    """ 
     Defines a delegate slot type response.
     """
	### Canonical solution below ###    

    return {
        "sessionAttributes": session_attributes,
        "dialogAction": {"type": "Delegate", "slots": slots},
    }

### Unit tests below ###
def check(candidate):
	assert candidate(
    {"k1": "v1"},
    {"k2": "v2"},
) == {
    "sessionAttributes": {"k1": "v1"},
    "dialogAction": {"type": "Delegate", "slots": {"k2": "v2"}},
}
	assert candidate(None, None) == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Delegate',
       'slots': None
    }
}
	assert candidate(None, {"key": "value"}) == {
    "sessionAttributes": None,
    "dialogAction": {"type": "Delegate", "slots": {"key": "value"}},
}
	assert candidate(None, {}) == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Delegate',
       'slots': {}
    }
}
	assert candidate({'a': 'b'}, {'c': 'd'}) == {
   'sessionAttributes': {'a': 'b'},
    'dialogAction': {
        'type': 'Delegate',
       'slots': {'c': 'd'}
    }
}
	assert candidate(
    {"key1": "value1"},
    {"key2": "value2"},
) == {
    "sessionAttributes": {"key1": "value1"},
    "dialogAction": {"type": "Delegate", "slots": {"key2": "value2"}},
}
	assert candidate({'foo': 'bar'}, None) == {
   'sessionAttributes': {'foo': 'bar'},
    'dialogAction': {
        'type': 'Delegate',
       'slots': None
    }
}
	assert candidate({"key": "value"}, None) == {
    "sessionAttributes": {"key": "value"},
    "dialogAction": {"type": "Delegate", "slots": None},
}
	assert candidate(None, None) == {
    "sessionAttributes": None,
    "dialogAction": {"type": "Delegate", "slots": None}
}
	assert candidate({"key": "value"}, {"key": "value"}) == {
    "sessionAttributes": {"key": "value"},
    "dialogAction": {"type": "Delegate", "slots": {"key": "value"}},
}
	assert candidate(None, {"key": "value"}) == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Delegate',
       'slots': {"key": "value"}
    }
}
	assert candidate({"k": "v"}, {"x": "y"}) == {
    "dialogAction": {"type": "Delegate", "slots": {"x": "y"}},
    "sessionAttributes": {"k": "v"}
}
	assert candidate(None, None) == {
    "sessionAttributes": None,
    "dialogAction": {"type": "Delegate", "slots": None},
}
	assert candidate({'foo': 'bar'}, {}) == {
   'sessionAttributes': {'foo': 'bar'},
    'dialogAction': {
        'type': 'Delegate',
       'slots': {}
    }
}
	assert candidate(None, None) == {
   'sessionAttributes': None,
    'dialogAction': {'type': 'Delegate','slots': None}
}
	assert candidate({'foo': 'bar'}, {'baz': 'qux'}) == {
   'sessionAttributes': {'foo': 'bar'},
    'dialogAction': {
        'type': 'Delegate',
       'slots': {'baz': 'qux'}
    }
}
	assert candidate(
    {}, {"name": {"name": "Joey", "value": "Joey"}}
) == {
    "sessionAttributes": {},
    "dialogAction": {
        "type": "Delegate",
        "slots": {"name": {"name": "Joey", "value": "Joey"}},
    },
}
	assert candidate(None, {'foo': 'bar'}) == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Delegate',
       'slots': {'foo': 'bar'}
    }
}
	assert candidate(None, None) == {
    "sessionAttributes": None,
    "dialogAction": {
        "type": "Delegate",
        "slots": None
    }
}
	assert candidate(
    {},
    {
        "foo": "bar",
        "baz": "qux",
    }
) == {
    "sessionAttributes": {},
    "dialogAction": {
        "type": "Delegate",
        "slots": {
            "foo": "bar",
            "baz": "qux",
        },
    },
}
	assert candidate({"key": "value"}, None) == {
   'sessionAttributes': {"key": "value"},
    'dialogAction': {
        'type': 'Delegate',
       'slots': None
    }
}
	assert candidate({}, {}) == {
    "sessionAttributes": {},
    "dialogAction": {"type": "Delegate", "slots": {}},
}
	assert candidate(session_attributes={}, slots={"foo": "bar"}) == {
    "sessionAttributes": {},
    "dialogAction": {
        "type": "Delegate",
        "slots": {"foo": "bar"},
    },
}
	assert candidate(None, None) == {
    "dialogAction": {"type": "Delegate", "slots": None},
    "sessionAttributes": None
}
	assert candidate(None, {"slot": "value"}) == {
    "sessionAttributes": None,
    "dialogAction": {"type": "Delegate", "slots": {"slot": "value"}},
}
	assert candidate(
    {"mode": "on"}, {"mode": "off"}) == {
        "sessionAttributes": {"mode": "on"},
        "dialogAction": {
            "type": "Delegate",
            "slots": {"mode": "off"}
        }
    }
	assert candidate(None, {'c': 'd'}) == {
   'sessionAttributes': None,
    'dialogAction': {
        'type': 'Delegate',
       'slots': {'c': 'd'}
    }
}
	assert candidate({'a': 'b'}, None) == {
   'sessionAttributes': {'a': 'b'},
    'dialogAction': {
        'type': 'Delegate',
       'slots': None
    }
}
	assert candidate({}, {}) == {
   'sessionAttributes': {},
    'dialogAction': {
        'type': 'Delegate',
       'slots': {}
    }
}
def test_check():
	check(delegate)
