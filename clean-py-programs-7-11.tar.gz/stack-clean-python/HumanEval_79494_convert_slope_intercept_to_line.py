def convert_slope_intercept_to_line(y1, y2 , line):
    """ 
     Fetching end coordinates from line from equation :  y = mx + c
     """
	### Canonical solution below ###    
    if line is None:
        return None
    
    slope, intercept = line
    x1 = int((y1- intercept)/slope)
    y1 = int(y1)
    x2 = int((y2- intercept)/slope)
    y2 = int(y2)
    return((x1, y1),(x2, y2))

### Unit tests below ###
def check(candidate):
	assert candidate(0, 10, (1, 0)) == ((0, 0), (10, 10))
	assert candidate(0, 3, (1, 0)) == ((0, 0), (3, 3))
	assert candidate(1, 1, (1, 0)) == ((1, 1), (1, 1))
	assert candidate(0, 10, None) == None
	assert candidate(3, 4, None) == None
	assert candidate(0, 9, (1, 0)) == ((0, 0), (9, 9))
	assert candidate(3, 10, None) == None
	assert candidate(0, 4, (1, 0)) == ((0, 0), (4, 4))
	assert candidate(0, 100, None) == None
	assert candidate(0, 7, (1, 0)) == ((0, 0), (7, 7))
	assert candidate(0, 5, (1, 0)) == ((0, 0), (5, 5))
	assert candidate(0, 1, (1, 0)) == ((0, 0), (1, 1))
	assert candidate(10, 20, None) is None
	assert candidate(0, 1, None) == None
	assert candidate(1, 1, None) is None
	assert candidate(0, 0, None) is None
	assert candidate(0,10,(1,0)) == ((0, 0), (10, 10)), "x = 0, y = 1"
	assert candidate(0, 8, (1, 0)) == ((0, 0), (8, 8))
	assert candidate(0, 6, (1, 0)) == ((0, 0), (6, 6))
	assert candidate(0, 2, (1, 0)) == ((0, 0), (2, 2))
def test_check():
	check(convert_slope_intercept_to_line)
