def _to_full_shapes(shapes, device_num):
    """ Expanding batch dimension according to device_num, adapt to mindspore minddata graph solution."""
	### Canonical solution below ###    
    new_shapes = []
    for shape in shapes:
        new_shape = ()
        for i, item in enumerate(shape):
            if i == 0:
                new_shape += (item * device_num,)
            else:
                new_shape += (item,)
        new_shapes.append(new_shape)
    return new_shapes

### Unit tests below ###
def check(candidate):
	assert candidate(shapes=[(2, 3, 4)], device_num=4) == [(8, 3, 4)]
	assert candidate(
    shapes=[(2, 3), (4, 5)], device_num=2) == [(4, 3), (8, 5)]
	assert candidate(
    [(), (1,), (1, 1), (2, 2)], 1) == [(), (1,), (1, 1), (2, 2)]
	assert candidate(shapes=[(1, 2, 3), (2, 2)], device_num=2) == [(2, 2, 3), (4, 2)]
	assert candidate(shapes=[(1, 2), (3, 4)], device_num=1) == [(1, 2), (3, 4)]
	assert candidate(
    [(1, 2, 3), (4, 5), (6,)], 1) == [(1, 2, 3), (4, 5), (6,)]
	assert candidate(
    shapes=[(2, 3), (4, 5)], device_num=3) == [(6, 3), (12, 5)]
	assert candidate(
    [(1, 2, 3), (4, 5), (6,)], 3) == [(3, 2, 3), (12, 5), (18,)]
	assert candidate(
    [(10, 2), (3, 4)], 8) == [(80, 2), (24, 4)], "candidate test3 failed"
	assert candidate(shapes=[(1, 2, 3), (4, 5)], device_num=1) == [(1, 2, 3), (4, 5)]
	assert candidate(shapes=[(32, 3, 32, 32), (32, 10)], device_num=2) == [(64, 3, 32, 32), (64, 10)]
	assert candidate(shapes=[(1, 2, 3), (4, 5, 6)], device_num=2) == [(2, 2, 3), (8, 5, 6)]
	assert candidate(
    [(10, 2), (3, 4)], 2) == [(20, 2), (6, 4)], "candidate test1 failed"
	assert candidate(shapes=[(1, 2), (3, 4)], device_num=3) == [(3, 2), (9, 4)]
	assert candidate(
    shapes=[(2, 3), (2, 3), (2, 3)], device_num=2) == [(4, 3), (4, 3), (4, 3)]
	assert candidate(
    [(2, 3, 4), (5, 6, 7), (8, 9, 10)], 1) == [(2, 3, 4), (5, 6, 7), (8, 9, 10)]
	assert candidate(
    [(10, 2), (3, 4)], 4) == [(40, 2), (12, 4)], "candidate test2 failed"
	assert candidate(shapes=[(1, 2), (3, 4)], device_num=4) == [(4, 2), (12, 4)]
	assert candidate(shapes=[(2, 3, 4)], device_num=1) == [(2, 3, 4)]
	assert candidate(
    [(1, 2, 3), (4, 5), (6,)], 2) == [(2, 2, 3), (8, 5), (12,)]
	assert candidate(
    [(1, 2, 3), (4, 5, 6)], 2) == [(2, 2, 3), (8, 5, 6)]
	assert candidate(shapes=[(3, 10), (4, 10)], device_num=4) == [(12, 10), (16, 10)]
	assert candidate(shapes=[(1, 2), (3, 4)], device_num=2) == [(2, 2), (6, 4)]
	assert candidate(
    [
        (2,),
        (3, 2),
        (4, 2, 3),
    ], 3) == [
        (6,),
        (9, 2),
        (12, 2, 3),
    ]
	assert candidate(shapes=[(32, 3, 32, 32), (32, 10)], device_num=1) == [(32, 3, 32, 32), (32, 10)]
	assert candidate(shapes=[(32, 3, 32, 32), (32, 10)], device_num=8) == [(256, 3, 32, 32), (256, 10)]
	assert candidate(
    [
        (2,),
        (3, 2),
        (4, 2, 3),
    ], 2) == [
        (4,),
        (6, 2),
        (8, 2, 3),
    ]
	assert candidate(shapes=[(2, 3, 4), (5, 6)], device_num=2) == [(4, 3, 4), (10, 6)]
	assert candidate(shapes=[(1, 2, 3), (2, 2)], device_num=3) == [(3, 2, 3), (6, 2)]
def test_check():
	check(_to_full_shapes)
