def is_float(s):
    """ 
     Given a string s, returns whether s is a string-encoded float.
     """
	### Canonical solution below ###    
    try:
        float(s)
    except ValueError:
        return False
    return True

### Unit tests below ###
def check(candidate):
	assert candidate(3.0)
	assert candidate(1.5) == True
	assert candidate('-1.0') == True
	assert candidate(-1000.0)
	assert candidate("1.0.0.0") == False
	assert candidate(1e-1234567890) == True
	assert candidate(2) == True
	assert candidate(0.0)
	assert candidate("1.0") == True
	assert candidate(str(0.0))
	assert candidate('1.0e-10') == True
	assert candidate('bar') == False
	assert not candidate("1.0\n\n1.0")
	assert candidate(' \n ') == False
	assert candidate("") == False
	assert not candidate("1.0 \r\n\t1.0")
	assert candidate(1.1) == True
	assert candidate('') == False
	assert not candidate(u'3.14a')
	assert candidate("foo1") == False
	assert candidate("1.1") == True
	assert candidate(1e6) == True
	assert candidate(10.0)
	assert not candidate("1.0\r\r1.0")
	assert candidate('1') == True
	assert candidate(' \r ') == False
	assert candidate(1e-6) == True
	assert candidate(4.0) == True
	assert candidate(3.14159)
	assert candidate(-100.0)
	assert candidate("1.0e-10") == True
	assert candidate(1.23) == True
	assert not candidate("1.0\t\t1.0")
	assert candidate('1e-5') == True
	assert candidate("0.0") == True
	assert candidate('3.0.0') == False
	assert candidate('3.0')
	assert candidate('3.14159')
	assert candidate("1.0e10") == True
	assert candidate(1.0)
	assert candidate('2.0.0') == False
	assert candidate("1.1.1") == False
	assert candidate('1.0') == True
	assert candidate('5.0') == True
	assert candidate('foo') == False
	assert candidate(' \t ') == False
	assert candidate(1e-100) == True
	assert candidate(1000.0)
	assert not candidate("1.0 1.0")
	assert not candidate("1.0\n1.0")
	assert candidate("1.0.0") == False
	assert candidate(3.14)
	assert candidate(str(1.0))
	assert candidate("foo") == False
	assert candidate('1.0e5') == True
	assert candidate('10.5.5') == False
	assert candidate(1) == True
	assert candidate(-10.0)
	assert candidate('10.5') == True
	assert candidate("0.1") == True
	assert candidate('1e+5') == True
	assert candidate(-1.0)
	assert candidate(str(-1.0))
	assert candidate(100.0)
	assert candidate(0.5) == True
	assert candidate(5.0) == True
	assert candidate(0.1) == True
	assert candidate(10.5) == True
	assert candidate('-1') == True
	assert candidate('1e5') == True
	assert candidate(0.0) == True
	assert candidate('1.0e-5') == True
	assert candidate("1.0.0-alpha") == False
	assert not candidate("1.0\r1.0")
	assert candidate('3.14')
	assert not candidate(u'3.14.15')
	assert candidate('5.0.0') == False
	assert candidate("1") == True
	assert not candidate("1.0\t1.0")
	assert candidate(1.0) == True
	assert candidate("1.23") == True
	assert candidate("1foo") == False
	assert not candidate('hello')
	assert candidate('3.0') == True
	assert candidate('a') == False
	assert candidate(u'314')
	assert candidate(2.0) == True
	assert candidate(' ') == False
	assert not candidate("1.0 \r\r1.0")
	assert candidate("1.0e+10") == True
	assert not candidate('cake')
	assert candidate("a") == False
	assert candidate(u'3.14')
	assert candidate(1.0000)
	assert candidate(1234567890.0) == True
def test_check():
	check(is_float)
