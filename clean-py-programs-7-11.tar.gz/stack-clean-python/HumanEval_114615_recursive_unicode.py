def recursive_unicode(obj):
    """ Walks a simple data structure, converting byte strings to unicode.
     
     Supports lists, tuples, and dictionaries.
     """
	### Canonical solution below ###    
    if isinstance(obj, dict):
        return dict((recursive_unicode(k), recursive_unicode(v)) for (k, v) in obj.items())
    elif isinstance(obj, list):
        return list(recursive_unicode(i) for i in obj)
    elif isinstance(obj, tuple):
        return tuple(recursive_unicode(i) for i in obj)
    elif isinstance(obj, bytes):
        return obj.decode("utf-8")
    else:
        return obj

### Unit tests below ###
def check(candidate):
	assert candidate(None) is None
	assert candidate(
    {'a': [u'a', 1, {u'b': u'c'}], 'd': u'd'}) == {'a': [u'a', 1, {u'b': u'c'}], 'd': u'd'}
	assert candidate({"a": (1, 2), "b": 2}) == {"a": (1, 2), "b": 2}
	assert candidate([b"abc", u"def"]) == [u"abc", u"def"]
	assert candidate(u'abc') == u'abc'
	assert candidate((u"a", "b")) == (u"a", u"b")
	assert candidate({b'abc': u'abc'.encode('latin1')}) == {'abc': 'abc'}
	assert candidate((b"hello", 1)) == (u"hello", 1)
	assert candidate([1, (2, 3), b"foo"]) == [1, (2, 3), "foo"]
	assert candidate((b"hello", u"world")) == (u"hello", u"world")
	assert candidate({"a": (1, 2), "b": [2, b"abc"]}) == {"a": (1, 2), "b": [2, "abc"]}
	assert candidate(1) == 1
	assert candidate(u"abc".encode("utf-8")) == u"abc"
	assert candidate([1, [2, 3]]) == [1, [2, 3]]
	assert candidate([u"foo"]) == [u"foo"]
	assert candidate("foo") == "foo"
	assert candidate({b"foo": b"bar"}) == {u"foo": u"bar"}
	assert candidate([u"foo".encode("utf-8")]) == [u"foo"]
	assert candidate((b"abc",)) == ("abc",)
	assert candidate(b"hello") == u"hello"
	assert candidate((u"foo", u"bar")) == (u"foo", u"bar")
	assert candidate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
	assert candidate(u"foo".encode("utf-8")) == u"foo"
	assert candidate({"a": b"foo", "b": b"bar"}) == {"a": "foo", "b": "bar"}
	assert candidate(b"foo") == "foo"
	assert candidate([b"hello", u"world"]) == [u"hello", u"world"]
	assert candidate({"abc": b"def"}) == {"abc": "def"}
	assert candidate([b"foo", u"bar", b"baz"]) == [u"foo", u"bar", u"baz"]
	assert candidate(u'abc'.encode('utf-8')) == u'abc'
	assert candidate({"foo": 1, b"bar": 2}) == {"foo": 1, "bar": 2}
	assert candidate({u"foo": u"bar"}) == {u"foo": u"bar"}
	assert candidate([b"foo", b"bar"]) == ["foo", "bar"]
	assert candidate({b"foo": u"bar"}) == {u"foo": u"bar"}
	assert candidate([{"foo": "bar"}]) == [{"foo": "bar"}]
	assert candidate(u"abc".encode("ascii")) == u"abc"
	assert candidate([u"foo", u"bar"]) == [u"foo", u"bar"]
	assert candidate({b'foo': b'bar'}) == {u'foo': u'bar'}
	assert candidate({b'foo': {b'bar': b'baz'}}) == {u'foo': {u'bar': u'baz'}}
	assert candidate(u"abc\xff") == u"abc\xff"
	assert candidate(["abc", b"def"]) == ["abc", "def"]
	assert candidate(u"foo".encode("utf-8").decode("utf-8").encode("utf-8")) == u"foo"
	assert candidate({u"foo": {u"bar": u"baz"}}) == {u"foo": {u"bar": u"baz"}}
	assert candidate((b"foo", b"bar")) == (u"foo", u"bar")
	assert candidate(u"foo\xe9") == u"fooé"
	assert candidate({'foo': 1, 'bar': 2}) == {'foo': 1, 'bar': 2}
	assert candidate((b"abc", u"def")) == (u"abc", u"def")
	assert candidate(u"foo".encode("utf-8").decode("utf-8").encode("utf-8").decode("utf-8")) == u"foo"
	assert candidate(u"hello") == u"hello"
	assert candidate(u'abc'.encode('latin1')) == u'abc'
	assert candidate(u"foo\xe9".encode("utf-8")) == u"fooé"
	assert candidate(u"foo".encode("utf-8").decode("utf-8")) == u"foo"
	assert candidate([b"foo"]) == [u"foo"]
	assert candidate((b'foo', u'bar')) == (u'foo', u'bar')
	assert candidate([b"hello", 1]) == [u"hello", 1]
	assert candidate({"foo": [1, 2, 3]}) == {"foo": [1, 2, 3]}
	assert candidate('foo') == u'foo'
	assert candidate({u"foo": [u"bar", u"baz"]}) == {u"foo": [u"bar", u"baz"]}
	assert candidate((1, u"foo", b"bar")) == (1, u"foo", u"bar")
	assert candidate(u'foo'.encode('utf-8')) == u'foo'
	assert candidate((b"foo", u"bar")) == (u"foo", u"bar")
	assert candidate(b'foo') == u'foo'
	assert candidate({"foo": b"bar"}) == {"foo": u"bar"}
	assert candidate([b"foo", b"bar"]) == [u"foo", u"bar"]
	assert candidate(b"abc") == u"abc"
	assert candidate([1, u"foo", b"bar"]) == [1, u"foo", u"bar"]
	assert candidate(u'foo') == u'foo'
	assert candidate("abc") == "abc"
	assert candidate("ascii") == u"ascii"
	assert candidate([u'foo', b'bar']) == [u'foo', u'bar']
	assert candidate({"foo": "bar"}) == {"foo": "bar"}
	assert candidate((u"abc", b"def")) == (u"abc", u"def")
	assert candidate((1, 2, 3)) == (1, 2, 3)
	assert candidate(b"abc") == "abc"
	assert candidate(123) == 123
	assert candidate(u"unicode") == u"unicode"
	assert candidate({b"foo": b"bar", u"baz": u"quux"}) == {u"foo": u"bar", u"baz": u"quux"}
	assert candidate({u"foo".encode("utf-8"): u"bar".encode("utf-8")}) == {u"foo": u"bar"}
	assert candidate(
    {'a': [u'a', 1, {u'b': u'c'}], 'd': u'd'}).get('a')[2] == {u'b': u'c'}
	assert candidate([b"foo", 42, {b"bar": 123}]) == [u"foo", 42, {u"bar": 123}]
	assert candidate(42) == 42
	assert candidate([b'abc', u'abc'.encode('latin1')]) == ['abc', 'abc']
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate({1: u"foo", b"bar": 2}) == {1: u"foo", u"bar": 2}
	assert candidate([b"abc"]) == ["abc"]
	assert candidate({u"foo": b"bar"}) == {u"foo": u"bar"}
	assert candidate(
    {'a': [u'a', 1, {u'b': u'c'}], 'd': u'd'}).get('a') == [u'a', 1, {u'b': u'c'}]
	assert candidate(u'foo') == 'foo'
	assert candidate([b'foo', b'bar']) == [u'foo', u'bar']
	assert candidate(u"abc") == u"abc"
	assert candidate(b"foo") == u"foo"
	assert candidate([1, (2, 3)]) == [1, (2, 3)]
	assert candidate(u"foo") == u"foo"
	assert candidate({b"hello": b"world"}) == {u"hello": u"world"}
	assert candidate({"a": u"b"}) == {u"a": u"b"}
	assert candidate(b'abc') == 'abc'
	assert candidate(b'foo'.decode('utf-8')) == u'foo'
	assert candidate({u'foo': b'bar', b'baz': u'quux'}) == {u'foo': u'bar', u'baz': u'quux'}
	assert candidate({b"abc": u"def"}) == {u"abc": u"def"}
	assert candidate(u"abc".encode("utf-7")) == u"abc"
	assert candidate({b"hello": [b"world", b"universe"]}) == {u"hello": [u"world", u"universe"]}
	assert candidate({"foo": 1, b"bar": (2, 3)}) == {"foo": 1, "bar": (2, 3)}
	assert candidate({"foo": 1, b"bar": (2, 3), "baz": b"quux"}) == {"foo": 1, "bar": (2, 3), "baz": "quux"}
	assert candidate([u"abc", b"def"]) == [u"abc", u"def"]
	assert candidate(u"abc".encode("latin1")) == u"abc"
	assert candidate({"a": b"abc"}) == {"a": "abc"}
	assert candidate({u"foo": [u"bar"]}) == {u"foo": [u"bar"]}
	assert candidate(
    {'a': b'foo',
     'b': [b'bar', (b'baz', b'qux')],
     'c': {'d': b'zap', 'e': [b'zip', b'zot']}}) == \
    {'a': 'foo',
     'b': ['bar', ('baz', 'qux')],
     'c': {'d': 'zap', 'e': ['zip', 'zot']}}
	assert candidate((b'foo', b'bar')) == (u'foo', u'bar')
	assert candidate({u'abc'.encode('latin1'): u'abc'.encode('latin1')}) == {'abc': 'abc'}
	assert candidate({u"abc": b"def"}) == {u"abc": u"def"}
	assert candidate([b"foo", u"bar"]) == [u"foo", u"bar"]
	assert candidate([u"a", "b"]) == [u"a", u"b"]
def test_check():
	check(recursive_unicode)
