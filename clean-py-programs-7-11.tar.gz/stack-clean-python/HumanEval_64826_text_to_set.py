def text_to_set(text):
    """ 
     Split string by new line, save the elements to a set
     :param text: String
     :return: Set with lines as elements
     """
	### Canonical solution below ###    
    set_w_items = set()
    list_w_items = text.split("\n")
    for i in list_w_items:
        if len(i) > 0:
            set_w_items.add(i)
    return set_w_items

### Unit tests below ###
def check(candidate):
	assert candidate(text="apple\nbanana\norange\napple\nbanana") == {"apple", "banana", "orange"}
	assert candidate(text="apple\nbanana\norange\n\n") == {"apple", "banana", "orange"}
	assert candidate(text="I\nlike\nPython") == {"I", "like", "Python"}
	assert candidate("One element") == {"One element"}
	assert candidate(text="apple\nbanana\norange\n\n\n\n") == {"apple", "banana", "orange"}
	assert candidate(text="""

a
""") == {"a"}
	assert candidate(text="1.1.1.1\n172.16.58.3") == {"1.1.1.1", "172.16.58.3"}
	assert candidate(text="apple\nbanana\norange\n\n\n") == {"apple", "banana", "orange"}
	assert candidate("first line\n\n\n\n\n\n\n\n") == {"first line"}
	assert candidate(text="""

a

b

c

d

e

f
""") == {'a', 'b', 'c', 'd', 'e', 'f'}
	assert candidate(text="apple\nbanana\norange\n") == {"apple", "banana", "orange"}
	assert candidate("a\nb\nc") == {"a", "b", "c"}
	assert candidate(text="""

a
b
c
""") == {'a', 'b', 'c'}
	assert candidate(text="apple\nbanana\norange\napple\nbanana\norange") == {"apple", "banana", "orange"}
	assert candidate(text="123\n456\n123\n456\n") == {"123", "456"}
	assert candidate(text="123\n456\n123\n456") == {"123", "456"}
	assert candidate(text="123\n456\n123\n456\n123\n") == {"123", "456"}
	assert candidate(text="""

a

b

c

d

e

""") == {'a', 'b', 'c', 'd', 'e'}
	assert candidate("1.1.1.1\n1.1.1.2") == {"1.1.1.1", "1.1.1.2"}
	assert candidate(text="apple\n\nbanana\norange\n") == {"apple", "banana", "orange"}
	assert candidate(text="123\n456\n123\n") == {"123", "456"}
	assert candidate(
    "first line\nsecond line\nthird line\n") == {"first line", "second line", "third line"}
	assert candidate(text="123\n456\n123\n456\n123") == {"123", "456"}
	assert candidate(text="123\n456\n123\n456\n123\n456\n") == {"123", "456"}
	assert candidate(text="""
abc
123
""") == {'abc', '123'}
	assert candidate(text="""
abc
""") == {'abc'}
	assert candidate(text="a") == {"a"}
	assert candidate(text="123\n456\n") == {"123", "456"}
	assert candidate(text="apple\n\nbanana\norange\n\n") == {"apple", "banana", "orange"}
	assert candidate("1.1.1.1\n\n1.1.1.2") == {"1.1.1.1", "1.1.1.2"}
	assert candidate(text="a\nb\nc\n") == {"a", "b", "c"}
	assert candidate(text="123\n456\n123") == {"123", "456"}
	assert candidate(text="123\n456\n123\n456\n123\n456") == {"123", "456"}
	assert candidate(text="apple\nbanana\norange") == {"apple", "banana", "orange"}
	assert candidate("first line") == {"first line"}
	assert candidate("\n\n\n\n\n\n\n") == set()
	assert candidate(text="apple\nbanana\norange\napple\nbanana\norange\n") == {"apple", "banana", "orange"}
	assert candidate(text="first\nfirst\nsecond\nsecond\nthird\nthird") == {"first", "second", "third"}
	assert candidate(text="a\nb\nc") == {"a", "b", "c"}
	assert candidate(text="apple\npear\norange") == {"apple", "pear", "orange"}
	assert candidate(text="""

a

b

c

d

e

f

""") == {'a', 'b', 'c', 'd', 'e', 'f'}
	assert candidate(text="""

a

b

c

d
""") == {'a', 'b', 'c', 'd'}
	assert candidate("one\ntwo\nthree\n") == {"one", "two", "three"}
	assert candidate(text="""
a
b
c
""") == {"a", "b", "c"}
	assert candidate(text="""

a

b

c
""") == {'a', 'b', 'c'}
	assert candidate(text="""

a

b

c

""") == {'a', 'b', 'c'}
	assert candidate(text="") == set()
	assert candidate(text="""
a
b
c
""") == {'a', 'b', 'c'}
	assert candidate(text="""
123
abc
123
""") == {'abc', '123'}
	assert candidate(text="""
a

b

c
""") == {"a", "b", "c"}
	assert candidate(text="1.1.1.1\n") == {"1.1.1.1"}
	assert candidate(text="apple\npear\norange\napple") == {"apple", "pear", "orange"}
	assert candidate(
    "I have a cat.\nHis name is Bruno.\nI have a dog.\nHis name is Sasha.\n") == {
    "I have a cat.", "His name is Bruno.", "I have a dog.", "His name is Sasha."}
	assert candidate(text="""

a

b

c

d

""") == {'a', 'b', 'c', 'd'}
	assert candidate(text="""
a

""") == {"a"}
	assert candidate(text="""

a
b
c

""") == {"a", "b", "c"}
	assert candidate(text="""

a

b

c

d

e
""") == {'a', 'b', 'c', 'd', 'e'}
	assert candidate("a\n\nc") == {"a", "c"}
	assert candidate(text="a\nb\nc\n\n\n") == {"a", "b", "c"}
	assert candidate(text="\n\n\n\n") == set()
	assert candidate("one\ntwo\nthree") == {"one", "two", "three"}
	assert candidate("\n") == set()
	assert candidate(text="""
""") == set()
	assert candidate(text="I\nlike\nPython\n\n\n\n") == {"I", "like", "Python"}
	assert candidate(text="\napple\npear\norange\napple\npear\n") == {"apple", "pear", "orange"}
	assert candidate(text="a\nb\nc\nd\n\n") == {"a", "b", "c", "d"}
	assert candidate(text="apple\nbanana\norange\napple") == {"apple", "banana", "orange"}
	assert candidate(text="apple\npear\norange\napple\npear") == {"apple", "pear", "orange"}
	assert candidate(text="I\nlike\nPython\n\n") == {"I", "like", "Python"}
	assert candidate(text="first\nsecond\nthird") == {"first", "second", "third"}
	assert candidate(text="I\nlike\nPython\n\n\n") == {"I", "like", "Python"}
	assert candidate("") == set()
	assert candidate(text="1\n2\n\n\n") == {"1", "2"}
	assert candidate(text="1\n2\n3") == {"1", "2", "3"}
	assert candidate(text="""

""") == set()
	assert candidate(text="a\nb\nc\n\n") == {"a", "b", "c"}
	assert candidate("first line\nsecond line") == {"first line", "second line"}
	assert candidate(text="first") == {"first"}
	assert candidate(text="1.1.1.1") == {"1.1.1.1"}
	assert candidate(
    "first line\n"
    "second line\n"
    "third line\n"
    "fourth line\n"
    "fifth line\n"
) == {"first line", "second line", "third line", "fourth line", "fifth line"}
	assert candidate(text="I\nlike\nPython\n") == {"I", "like", "Python"}
	assert candidate(text="1\n\n\n\n") == {"1"}
	assert candidate(text="""

a

b

c

""") == {"a", "b", "c"}
def test_check():
	check(text_to_set)
