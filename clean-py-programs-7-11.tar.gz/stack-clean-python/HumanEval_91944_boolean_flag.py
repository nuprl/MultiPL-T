def boolean_flag(name, configurable, set_help='', unset_help=''):
    """ Helper for building basic --trait, --no-trait flags.
     
     Parameters
     ----------
     name : str
     The name of the flag.
     configurable : str
     The 'Class.trait' string of the trait to be set/unset with the flag
     set_help : unicode
     help string for --name flag
     unset_help : unicode
     help string for --no-name flag
     
     Returns
     -------
     cfg : dict
     A dict with two keys: 'name', and 'no-name', for setting and unsetting
     the trait, respectively.
     """
	### Canonical solution below ###    
    # default helpstrings
    set_help = set_help or "set %s=True"%configurable
    unset_help = unset_help or "set %s=False"%configurable

    cls,trait = configurable.split('.')

    setter = {cls : {trait : True}}
    unsetter = {cls : {trait : False}}
    return {name : (setter, set_help), 'no-'+name : (unsetter, unset_help)}

### Unit tests below ###
def check(candidate):
	assert candidate(name='foo', configurable='A.foo') == {'foo' : ({'A' : {'foo' : True}}, "set A.foo=True"), 'no-foo' : ({'A' : {'foo' : False}}, "set A.foo=False")}
	assert candidate(
    'foo', 'MyClass.my_trait', set_help='set my_trait=True',
    unset_help='set my_trait=False')['foo'] == (
        {'MyClass': {'my_trait': True}},'set my_trait=True')
	assert candidate(name='foo', configurable='MyClass.my_trait',
                    set_help='set foo=True', unset_help='set foo=False') == \
       {'foo' : ({'MyClass' : {'my_trait' : True}},'set foo=True'),
        'no-foo' : ({'MyClass' : {'my_trait' : False}},'set foo=False')}
	assert candidate(name='foo', configurable='MyClass.foo', set_help='bar', unset_help='baz') == \
    {'foo' : ({'MyClass' : {'foo' : True}}, 'bar'), 'no-foo' : ({'MyClass' : {'foo' : False}}, 'baz')}
	assert candidate(
   'mytrait', 'MyClass.trait',
    set_help="set MyClass.trait=True",
    unset_help="set MyClass.trait=False") == \
    {'mytrait': ({'MyClass' : {'trait' : True}},
                 "set MyClass.trait=True"),
     'no-mytrait': ({'MyClass' : {'trait' : False}},
                    "set MyClass.trait=False")}
	assert candidate(
    "foo", "Class.trait", "set class.trait=True", "set class.trait=False")[
    "foo"][0]["Class"]["trait"]
	assert candidate(
    'foo', 'Foo.bar', set_help='set Foo.bar=True', unset_help='set Foo.bar=False')[
    'foo'][0]['Foo']['bar'] is True
	assert candidate(
    'foo', 'Foo.bar', set_help='set Foo.bar=True', unset_help='set Foo.bar=False')[
    'no-foo'][0]['Foo']['bar'] is False
	assert not candidate(
    "foo", "Class.trait", "set class.trait=True", "set class.trait=False")[
    "no-foo"][0]["Class"]["trait"]
	assert candidate(
    'foo', 'Base.foo', set_help='enable foo', unset_help='disable foo')[
    'no-foo'][0] == {'Base' : {'foo' : False}}
	assert candidate(
    'foo', 'MyClass.my_trait', set_help='set MyClass.my_trait=True',
    unset_help='set MyClass.my_trait=False')['no-foo'] == ({'MyClass' : {'my_trait' : False}},'set MyClass.my_trait=False')
	assert candidate(name='testflag', configurable='A.a', set_help='set A.a=True', unset_help='set A.a=False') == {'testflag': ({'A': {'a': True}},'set A.a=True'), 'no-testflag': ({'A': {'a': False}},'set A.a=False')}
	assert candidate(
    'trait', 'MyClass.trait', set_help='help string', unset_help='help string') == {
        'trait' : ({'MyClass' : {'trait' : True}}, 'help string'),
        'no-trait' : ({'MyClass' : {'trait' : False}}, 'help string')}
	assert candidate(name='foo', configurable='A.trait', set_help='help1', unset_help='help2') == \
    {'foo' : ({'A' : {'trait' : True}}, 'help1'), 'no-foo' : ({'A' : {'trait' : False}}, 'help2')}
	assert candidate(
    'foo', 'Foo.bar', 'help for --foo', 'help for --no-foo') == {
        'foo' : ({'Foo' : {'bar' : True}}, 'help for --foo'),
        'no-foo' : ({'Foo' : {'bar' : False}}, 'help for --no-foo')}
	assert candidate(
    'test', 'Class.trait', set_help='help string for --test',
    unset_help='help string for --no-test') == {'test' : ({'Class' : {'trait' : True}}, 'help string for --test'), 'no-test' : ({'Class' : {'trait' : False}}, 'help string for --no-test')}
	assert candidate(
    'flag', 'Class.trait', set_help='help', unset_help='help') == {
        'flag' : ({'Class': {'trait' : True}}, 'help'),
        'no-flag' : ({'Class': {'trait' : False}}, 'help')}
	assert candidate(
    'flagname', 'MyClass.my_trait', 'help string for --flagname',
    'help string for --no-flagname') == {
        'flagname': ({'MyClass': {'my_trait': True}}, 'help string for --flagname'),
        'no-flagname': ({'MyClass': {'my_trait': False}}, 'help string for --no-flagname')}
	assert candidate(
    'trait',
    'Class.trait',
    set_help='help for --trait',
    unset_help='help for --no-trait'
) == {
    'trait': ({'Class': {'trait': True}}, 'help for --trait'),
    'no-trait': ({'Class': {'trait': False}}, 'help for --no-trait'),
}
	assert candidate(
    'foo', 'Foo.bar', set_help='set Foo.bar=True',
    unset_help='set Foo.bar=False')['foo'][0] == {'Foo': {'bar': True}}
	assert candidate(
    'foo', 'Base.foo', set_help='enable foo', unset_help='disable foo')[
    'foo'][0] == {'Base' : {'foo' : True}}
	assert candidate(
    'foo', 'A.b', set_help="helpstring for --foo",
    unset_help="helpstring for --no-foo") == {
        'foo' : ({'A' : {'b' : True}}, "helpstring for --foo"),
        'no-foo' : ({'A' : {'b' : False}}, "helpstring for --no-foo")}
	assert candidate(
    'foo', 'MyClass.my_trait', set_help='set my_trait=True',
    unset_help='set my_trait=False')['no-foo'] == (
        {'MyClass': {'my_trait': False}},'set my_trait=False')
	assert candidate(
    'foo', 'Class.trait','set Class.trait=True','set Class.trait=False'
    ) == {'foo': ({'Class' : {'trait': True}},'set Class.trait=True'),
          'no-foo': ({'Class' : {'trait': False}},'set Class.trait=False')}
	assert candidate(
    'foo', 'MyClass.my_trait', set_help='set MyClass.my_trait=True',
    unset_help='set MyClass.my_trait=False')['foo'] == ({'MyClass' : {'my_trait' : True}},'set MyClass.my_trait=True')
	assert candidate(
    'foo', 'Class.trait', set_help='help for --foo', unset_help='help for --no-foo'
) == {
    'foo': ({'Class': {'trait': True}}, 'help for --foo'),
    'no-foo': ({'Class': {'trait': False}}, 'help for --no-foo')
}
	assert candidate(name='foo', configurable='bar.trait') == \
    {'foo' : ({'bar' : {'trait' : True}},'set bar.trait=True'),
     'no-foo' : ({'bar' : {'trait' : False}},'set bar.trait=False')}
	assert candidate(
    'foo', 'A.trait','set A.trait=True','set A.trait=False') == {
        'foo': ({'A': {'trait': True}},'set A.trait=True'),
        'no-foo': ({'A': {'trait': False}},'set A.trait=False')
    }
	assert candidate(
    'foo', 'Foo.bar', 'help string for --foo', 'help string for --no-foo'
) == {
    'foo': ({'Foo': {'bar': True}}, 'help string for --foo'),
    'no-foo': ({'Foo': {'bar': False}}, 'help string for --no-foo')
}
	assert candidate(
    'foo', 'Foo.bar', set_help='set Foo.bar=True',
    unset_help='set Foo.bar=False')['no-foo'][0] == {'Foo': {'bar': False}}
	assert candidate(
    'foo', 'MyClass.foo',
    set_help="set MyClass.foo=True",
    unset_help="set MyClass.foo=False"
) == {
    'foo' : ({'MyClass' : {'foo' : True}}, "set MyClass.foo=True"),
    'no-foo' : ({'MyClass' : {'foo' : False}}, "set MyClass.foo=False")
}
	assert candidate(name='foo', configurable='Bar.baz',
                    set_help='set Bar.baz=True', unset_help='set Bar.baz=False') == \
    {'foo': ({'Bar' : {'baz' : True}},'set Bar.baz=True'),
     'no-foo': ({'Bar' : {'baz' : False}},'set Bar.baz=False')}
def test_check():
	check(boolean_flag)
