def get_cfn_param(params, key_name):
    """ 
     Get parameter value from Cloudformation Stack Parameters.
     
     :param params: Cloudformation Stack Parameters
     :param key_name: Parameter Key
     :return: ParameterValue if that parameter exists, otherwise None
     """
	### Canonical solution below ###    
    param_value = next((i.get("ParameterValue") for i in params if i.get("ParameterKey") == key_name), "NONE")
    return param_value.strip()

### Unit tests below ###
def check(candidate):
	assert candidate(
    [
        {"ParameterKey": "key1", "ParameterValue": "value1"},
        {"ParameterKey": "key2", "ParameterValue": "value2"},
    ],
    "key1",
) == "value1"
	assert candidate([], "NoneExistingKey") == "NONE"
	assert candidate(
    [
        {
            "ParameterKey": "key1",
            "ParameterValue": "value1",
        },
        {
            "ParameterKey": "key2",
            "ParameterValue": "value2",
        },
        {
            "ParameterKey": "key3",
            "ParameterValue": "value3",
        },
    ],
    "key2",
) == "value2"
	assert candidate([], "AWS_REGION") == "NONE"
	assert candidate(
    [
        {"ParameterKey": "key1", "ParameterValue": "value1"},
        {"ParameterKey": "key2", "ParameterValue": "value2"},
    ],
    "key2",
) == "value2"
	assert candidate([{"ParameterKey": "OTHER", "ParameterValue": "NONE"}], "NONE") == "NONE", "candidate - Key does not exists"
	assert candidate(
    [
        {
            "ParameterKey": "key1",
            "ParameterValue": "value1",
        },
        {
            "ParameterKey": "key2",
            "ParameterValue": "value2",
        },
        {
            "ParameterKey": "key3",
            "ParameterValue": "value3",
        },
    ],
    "key4",
) == "NONE"
	assert candidate(params=[], key_name="test") == "NONE", "Should return 'NONE'"
	assert candidate([], "KeyName") == "NONE"
	assert candidate(
    [
        {"ParameterKey": "key1", "ParameterValue": "value1"},
        {"ParameterKey": "key2", "ParameterValue": "value2"},
        {"ParameterKey": "key3", "ParameterValue": "value3"},
        {"ParameterKey": "key4", "ParameterValue": "value4"},
    ],
    "key5",
) == "NONE"
	assert candidate(params=[{"ParameterKey": "test", "ParameterValue": "value"}], key_name="test") == "value", "Should return 'value'"
	assert candidate([{"ParameterKey": "NONE", "ParameterValue": "NONE"}], "NONE") == "NONE", "candidate - Key exists"
	assert candidate(params=[{"ParameterKey": "key1", "ParameterValue": "val1"}], key_name="key2") == "NONE"
	assert candidate(
    [
        {"ParameterKey": "key1", "ParameterValue": "value1"},
        {"ParameterKey": "key2", "ParameterValue": "value2"},
        {"ParameterKey": "key3", "ParameterValue": "value3"},
        {"ParameterKey": "key4", "ParameterValue": "value4"},
    ],
    "key3",
) == "value3"
	assert candidate(
    [
        {"ParameterKey": "key1", "ParameterValue": "value1"},
        {"ParameterKey": "key2", "ParameterValue": "value2"},
    ],
    "key3",
) == "NONE"
	assert candidate(params=[{"ParameterKey": "test", "ParameterValue": "value"}, {"ParameterKey": "test2", "ParameterValue": "value2"}], key_name="test") == "value", "Should return 'value'"
	assert candidate(params=[{"ParameterKey": "key1", "ParameterValue": "val1"}], key_name="key1") == "val1"
	assert candidate([], "AWS::Region") == "NONE"
	assert candidate([], "NONE") == "NONE", "candidate - Empty list input"
def test_check():
	check(get_cfn_param)
