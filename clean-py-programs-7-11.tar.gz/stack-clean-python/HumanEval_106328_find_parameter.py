def find_parameter(params, key, index=None):
    """ 
     
     This is the hearth of the plotting structure, this functions allows one to simply set multiple characteristics
     for only one figure
     
     The priority for parameter search is plots => figures => global, with plot overriding others and so on
     
     If a parameter is defined globally it will be applied to all figures, if it defined inside a figure element
     it will only apply to that figure, if it is defined in a plot element it will only apply to that curve
     
     Check the readme or the tutorials for more details on the plotting structure. It is simple and versatile
     
     Parameters:
     params (dict) = Plot parameters from python dictionary (after json conversion)
     key (str) = Key necessary to access the parameters
     index (int) = None for global search, one index for figure search, and two for figure curve search
     
     Returns:
     The parameter if found, and None if nothing is found
     """
	### Canonical solution below ###    

    # No index is given, look global
    if index is None:
        try:
            return params[key]
        except (KeyError, IndexError):
            return None
    # Search a parameter
    # If local return local, otherwise return global
    # If not found return nothing
    elif type(index) == int:

        try:
            return params['figures'][index][key]
        except (KeyError, IndexError):

            try:
                return params[key]
            except (KeyError, IndexError):
                return None
    # If two indexes are given
    # Look inside the plot
    # Than figure
    # Than global
    elif type(index) == tuple:

        try:
            return params['figures'][index[0]]['plots'][index[1]][key]

        except (KeyError, IndexError):

            try:
                return params['figures'][index[0]][key]

            except (KeyError, IndexError):

                try:
                    return params[key]
                except (KeyError, IndexError):
                    return None

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'a': 1, 'figures': [{'b': 2}, {'plots': [{'c': 3}]}]}, 'd', 0) is None
	assert candidate({'figures': [{'plots': [{'test': 1}]}]}, 'test', (1, 0)) == None
	assert candidate({'figures': [{'other': 'value'}]}, 'key', 0) is None
	assert candidate({}, None) == None
	assert candidate({'a': 1}, 'a', None) == 1
	assert candidate({'figures': [{'a': 1}, {'a': 2}]}, 'a', None) == None
	assert candidate({'key': 'value'}, 'key') == 'value'
	assert candidate({'figures': [{'plots': [{'key': 10}]}, {'key': 10}]}, 'key', 2) is None
	assert candidate({'figures': [{'plots': [{'test': 1}]}]}, 'test', (0, 1)) == None
	assert candidate({"test": {"test2": "test3"}}, "test2", (1,)) is None
	assert candidate({'figures': [{'a': 1}]}, 'a', (1, 1)) == None
	assert candidate({'figures': [{'a': 1}, {'a': 2}]}, 'a', (2, 2)) == None
	assert candidate({'test': 1}, 'test', 0) == 1
	assert candidate({'figures': [{'plots': [{'test': 1}]}]}, 'test', (1, 1)) == None
	assert candidate({'figures': [{'test': 0}, {'test': 1}]}, 'test', 0) == 0
	assert candidate({'figures': [{'plots': [{'test': 1}]}]}, 'test', (0, 0)) == 1
	assert candidate({'figures': [{'plots': [{'test': 'test'}]}, {'test': 'test'}]}, 'test', (0, 0)) == 'test'
	assert candidate({'figures': [{'test': 0}, {'test': 1}]}, 'test') is None
	assert candidate({'key': 10}, 'key') == 10
	assert candidate({"test": "test"}, "test2") is None
	assert candidate(dict(a=1, b=2), 'c') == None
	assert candidate({"test": {"test2": "test3"}}, "test2", (1, 2)) is None
	assert candidate({'key': 'value'}, 'other') is None
	assert candidate({"test": "test"}, "test") == "test"
	assert candidate(dict(figures=[dict(plots=[dict(key='value1')]), dict(plots=[dict(key='value2')])]), 'key', (1, 1)) is None
	assert candidate(dict(figures=[dict(key='value1'), dict(key='value2')]), 'key', 1) == 'value2'
	assert candidate({'figures': [{'plots': [{'test': 'test'}]}, {'plots': [{'test': 'test'}]}]}, 'test', (0, 0)) == 'test'
	assert candidate({'figures': [{'test': 0}, {'test': 1}]}, 'test', 1) == 1
	assert candidate({'figures': [{'key': 'value'}]}, 'key', 1) is None
	assert candidate({'figures': [{'test': 'test'}, {'test': 'test'}]}, 'test', 0) == 'test'
	assert candidate({'figures': [{'plots': [{'key': 10}]}, {'key': 10}]}, 'key', 1) == 10
	assert candidate(dict(a=1, b=2), 'b', (0, 0)) == 2
	assert candidate({'figures': [{'other': 'value'}]}, 'other') is None
	assert candidate(
    {'a': 1, 'figures': [{'b': 2}, {'plots': [{'c': 3}]}]}, 'd', 1) is None
	assert candidate({'figures': [{'test': 1}]}, 'test', (0, 0)) == 1
	assert candidate({'figures': [{'plots': [{'test': 1}]}]}, 'test', (1, 2)) == None
	assert candidate({'test': 0}, 'test') == 0
	assert candidate({"test": {"test2": "test3"}}, "test2", (1, 2, 3)) is None
	assert candidate({'figures': [{'test': 'test'}]}, 'test', 1) is None
	assert candidate({'figures': [{'plots': [{'test': 'test'}]}, {'plots': [{'test': 'test'}]}]}, 'test', (1, 0)) == 'test'
	assert candidate(dict(key='value', figures=[dict(key='value', plots=[dict(key='value')])]), 'key') == 'value'
	assert candidate({'figures': [{'test': 1}]}, 'test', (1, 0)) == None
	assert candidate(
    {'a': 1, 'figures': [{'b': 2}, {'plots': [{'c': 3}]}]}, 'd', 2) is None
	assert candidate({'test': 'test'}, 'test', 0) == 'test'
	assert candidate({'figures': [{'plots': [{'test': 1}]}]}, 'test', (0, 2)) == None
	assert candidate({'figures': [{'test': 1}]}, 'test', 0) == 1
	assert candidate(dict(), 'key') is None
	assert candidate({'figures': [{'plots': [{'a': 1}]}]}, 'a', None) == None
	assert candidate(dict(key='value', figures=[dict(key='value')]), 'key') == 'value'
	assert candidate({'figures': [{'key': 'value'}]}, 'key') is None
	assert candidate(dict(), 'a', 1) == None
	assert candidate({}, 'test') == None
	assert candidate({'key': 'value'}, 'other', 0) is None
	assert candidate(dict(key='value', figures=[dict(key='value', plots=[dict(key='value')])]), 'key', 0) == 'value'
	assert candidate(dict(figures=[dict(plots=[dict(key='value1')]), dict(plots=[dict(key='value2')])]), 'key', (0, 1, 1)) is None
	assert candidate({'figures': [{'key': 'value'}]}, 'other', 0) is None
	assert candidate({'figures': [{'plots': [{'test': 'test'}]}]}, 'test', (0, 0)) == 'test'
	assert candidate({'figures': [{'test': 'test'}, {'test': 'test'}]}, 'test', 1) == 'test'
	assert candidate({'figures': [{'other': 'value'}]}, 'other', 1) is None
	assert candidate({'figures': [{'key': 'value'}]}, 'key', (0, 0)) == 'value'
	assert candidate({'figures': [{'key': 'value'}]}, 'other', 1) is None
	assert candidate(dict(a=1, b=2), 'b') == 2
	assert candidate({"test": {"test2": "test3"}}, "test2", 1) is None
	assert candidate({'figures': [{'a': 1}]}, 'a', None) == None
	assert candidate({'figures': [{'plots': [{'test': 'test'}]}]}, 'test', (1, 0)) is None
	assert candidate({'figures': [{'key': 'value'}]}, 'key', 0) == 'value'
	assert candidate({'figures': [{'test': 0}]}, 'test', 0) == 0
	assert candidate({'test': 1}, 'test') == 1
	assert candidate(dict(key='value'), 'key') == 'value'
	assert candidate({'test': 'test'}, 'test', None) == 'test'
	assert candidate(
    {'a': 1, 'figures': [{'b': 2}, {'plots': [{'c': 3}]}]}, 'a') == 1
	assert candidate({'figures': [{'test': 'test'}]}, 'test', 0) == 'test'
	assert candidate(dict(), "test") is None
	assert candidate({'figures': [{'test': 1}]}, 'test', 1) == None
	assert candidate({'figures': [{'test': 0}]}, 'test') is None
	assert candidate(dict(figures=[dict(plots=[dict(key='value1')]), dict(plots=[dict(key='value2')])]), 'key', (1, 0)) == 'value2'
	assert candidate(dict(figures=[dict(plots=[dict(key='value1')]), dict(plots=[dict(key='value2')])]), 'key', (0, 1)) is None
	assert candidate(dict(figures=[dict(plots=[dict(key='value1')]), dict(plots=[dict(key='value2')])]), 'key', (0, 0)) == 'value1'
	assert candidate(dict(), 'a', (1, 1)) == None
	assert candidate({'figures': [{'test': 'test'}, {'plots': [{'test': 'test'}]}]}, 'test', (1, 0)) == 'test'
	assert candidate(dict(a=1, b=2), 'c', 0) == None
	assert candidate(
    {'a': 1, 'figures': [{'b': 2}, {'plots': [{'c': 3}]}]}, 'd') is None
	assert candidate(dict(a=1, b=2), 'c', (0, 0)) == None
	assert candidate(dict(), 'a', None) == None
def test_check():
	check(find_parameter)
