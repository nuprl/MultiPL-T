def get_backend_url(config, hub, group, project):
    """ 
     Util method to get backend url
     """
	### Canonical solution below ###    
    if ((config is not None) and ('hub' in config) and (hub is None)):
        hub = config["hub"]
    if ((config is not None) and ('group' in config) and (group is None)):
        group = config["group"]
    if ((config is not None) and ('project' in config) and (project is None)):
        project = config["project"]
    if ((hub is not None) and (group is not None) and (project is not None)):
        return '/Network/{}/Groups/{}/Projects/{}/devices'.format(hub, group, project)
    return '/Backends'

### Unit tests below ###
def check(candidate):
	assert candidate({'hub': 'hub'}, 'hub', 'group', 'project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'testHub', 'group': 'testGroup', 'project': 'testProject'}, None, None, None) == '/Network/testHub/Groups/testGroup/Projects/testProject/devices'
	assert candidate(None, 'hub', None, 'project') == '/Backends'
	assert candidate(None, 'hub', None, None) == '/Backends'
	assert candidate({'hub': 'Hub'}, None, 'Group', 'Project') == '/Network/Hub/Groups/Group/Projects/Project/devices'
	assert candidate(None, None, 'group', 'project') == '/Backends'
	assert candidate({}, None, None, None) == '/Backends'
	assert candidate({"hub": "h", "group": "g", "project": "p"}, None, None, None) == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, None, None, None) == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({"hub": "hub1", "group": "group1", "project": "project1"}, "hub2", None, None) == '/Network/hub2/Groups/group1/Projects/project1/devices'
	assert candidate({'hub': 'h', 'group': 'g', 'project': 'p'}, None, 'g', None) == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate(None, "hub", "group", "project") == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub':'hub', 'group':'group', 'project':'project'}, 'hub', None, None) == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, None, None, 'project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({"hub":"hub","group":"group","project":"project"}, "hub", "group", "project") == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'h', 'group': 'g', 'project': 'p'}, 'h', 'g', 'p') == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate(None, 'Hub', 'Group', 'Project') == '/Network/Hub/Groups/Group/Projects/Project/devices'
	assert candidate(None, "hub1", "group1", "project1") == '/Network/hub1/Groups/group1/Projects/project1/devices'
	assert candidate({'hub':'hub'}, 'hub', 'group', 'project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate(None, None, 'testGroup', None) == '/Backends'
	assert candidate(None, 'testHub', 'testGroup', 'testProject') == '/Network/testHub/Groups/testGroup/Projects/testProject/devices'
	assert candidate({"hub": "hub"}, None, "group", "project") == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, 'hub', None, None) == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, None, 'group', None) == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({"hub": "hub1", "group": "group1", "project": "project1"}, None, None, None) == '/Network/hub1/Groups/group1/Projects/project1/devices'
	assert candidate({"hub": "hub1", "group": "group1", "project": "project1"}, "hub2", "group2", "project2") == '/Network/hub2/Groups/group2/Projects/project2/devices'
	assert candidate({'hub': 'h1', 'group': 'g1', 'project': 'p1'}, 'h2', 'g2', None) == '/Network/h2/Groups/g2/Projects/p1/devices'
	assert candidate({"hub": "h", "group": "g", "project": "p"}, "h", None, "p") == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({"hub": "hub", "group": "group"}, None, None, "project") == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'hub', 'group': 'group'}, 'hub', 'group', 'project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'h', 'group': 'g', 'project': 'p'}, None, 'g', 'p') == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({'hub': 'h', 'group': 'g', 'project': 'p'}, None, None, 'p') == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, None, None, None) == candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, None, None, None)
	assert candidate({'hub': 'h1', 'group': 'g1', 'project': 'p1'}, None, None, None) == '/Network/h1/Groups/g1/Projects/p1/devices'
	assert candidate(config=None, hub='hub', group='group', project='project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate(None, None, None, None) == '/Backends'
	assert candidate(None, None, 'group', None) == '/Backends', 'candidate(None, None, group, None) failed'
	assert candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, 'hub', 'group', 'project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate(None, None, None, 'project') == '/Backends', 'candidate(None, None, None, project) failed'
	assert candidate({"hub": "h", "group": "g", "project": "p"}, "h", "g", None) == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate(None, 'hub', 'group', 'project') == candidate({'hub': 'hub', 'group': 'group', 'project': 'project'}, None, None, None)
	assert candidate(None, None, 'group', 'project') == '/Backends', 'candidate(None, None, group, project) failed'
	assert candidate({"hub": "hub1", "group": "group1"}, "hub2", "group2", "project2") == '/Network/hub2/Groups/group2/Projects/project2/devices'
	assert candidate(None, None, None, 'project') == '/Backends'
	assert candidate({"hub": "hub1", "group": "group1", "project": "project1"}, "hub1", "group1", "project1") == '/Network/hub1/Groups/group1/Projects/project1/devices'
	assert candidate({"hub": "h", "group": "g", "project": "p"}, "h", "g", "p") == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({"hub": "h", "group": "g", "project": "p"}, "h", None, None) == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate(None, 'hub', 'group', 'project') == '/Network/hub/Groups/group/Projects/project/devices', 'candidate(None, hub, group, project) failed'
	assert candidate(None, 'h1', 'g1', 'p1') == '/Network/h1/Groups/g1/Projects/p1/devices'
	assert candidate({'hub': 'h', 'group': 'g', 'project': 'p'}, 'h', 'g', None) == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({'hub': 'h', 'group': 'g', 'project': 'p'}, None, None, None) == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({'hub': 'h1', 'group': 'g1', 'project': 'p1'}, 'h2', None, None) == '/Network/h2/Groups/g1/Projects/p1/devices'
	assert candidate(config={'hub':'hub'}, hub='hub', group='group', project='project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate(None, None, 'group', None) == '/Backends'
	assert candidate({"hub":"hub","group":"group","project":"project"}, None, None, None) == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub':'hub'}, None, 'group', 'project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({"hub": "hub", "group": "group", "project": "project"}, "hub", "group", "project") == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub':'hub', 'group':'group', 'project':'project'}, None, None, None) == '/Network/hub/Groups/group/Projects/project/devices', 'candidate failed'
	assert candidate(None, 'test_hub', 'test_group', 'test_project') == '/Network/test_hub/Groups/test_group/Projects/test_project/devices'
	assert candidate(None,'myhub','mygroup','myproject') == '/Network/myhub/Groups/mygroup/Projects/myproject/devices'
	assert candidate({'hub': 'h1', 'group': 'g1', 'project': 'p1'}, 'h2', 'g2', 'p2') == '/Network/h2/Groups/g2/Projects/p2/devices'
	assert candidate(None, 'hub', 'group', None) == '/Backends'
	assert candidate({'hub':'myhub'},'myhub','mygroup','myproject') == '/Network/myhub/Groups/mygroup/Projects/myproject/devices'
	assert candidate(None, None, None, 'testProject') == '/Backends'
	assert candidate({'hub': 'hub'}, "hub2", "group", "project") == '/Network/hub2/Groups/group/Projects/project/devices'
	assert candidate({"hub": "h", "group": "g", "project": "p"}, None, "g", None) == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({'hub': 'h', 'group': 'g', 'project': 'p'}, 'h', None, 'p') == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate(None, None, None, None) == '/Backends', 'candidate failed'
	assert candidate(None, 'hub', 'group', 'project') == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({"hub": "h", "group": "g", "project": "p"}, None, "g", "p") == '/Network/h/Groups/g/Projects/p/devices'
	assert candidate({'hub':'hub', 'group':'group', 'project':'project'}, None, None, None) == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub': 'Hub'}, 'Hub2', 'Group', 'Project') == '/Network/Hub2/Groups/Group/Projects/Project/devices'
	assert candidate({"hub": "hub1", "group": "group1", "project": "project1"}, "hub2", "group2", None) == '/Network/hub2/Groups/group2/Projects/project1/devices'
	assert candidate(None, None, 'testGroup', 'testProject') == '/Backends'
	assert candidate(None, None, None, None) == '/Backends', 'candidate(None, None, None, None) failed'
	assert candidate({"hub": "hub", "group": "group", "project": "project"}, None, None, None) == '/Network/hub/Groups/group/Projects/project/devices'
	assert candidate({'hub':'hub', 'group':'group', 'project':'project'}, 'hub', 'group', None) == '/Network/hub/Groups/group/Projects/project/devices'
def test_check():
	check(get_backend_url)
