def get_available_commands():
    """
    Returns all available commands
    """
    ### Canonical solution below ###

    return {
        "IMG": "Take a picture (requires -s)"
    }


### Unit tests below ###
def check(candidate):
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate returns wrong result"
	assert candidate(
) == {
    "IMG": "Take a picture (requires -s)"
}, "candidate() returns wrong values"
	assert candidate(
) == {
        "IMG": "Take a picture (requires -s)"
    }, "candidate does not match"
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate test failed"
	assert candidate(
) == {'IMG': 'Take a picture (requires -s)'}, "candidate() returns wrong commands"
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate is not working"
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate is broken"
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate() does not work as expected"
	assert candidate(
) == {'IMG': 'Take a picture (requires -s)'}, "candidate failed"
	assert candidate(
) == {
    "IMG": "Take a picture (requires -s)"
}, "candidate function does not work as expected"
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate is not correct"
	assert candidate(
) == {
    "IMG": "Take a picture (requires -s)"
}, "candidate() does not work"
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate not implemented"
	assert candidate(
) == {
    "IMG": "Take a picture (requires -s)"
}, "candidate does not return the correct value"
	assert candidate(
    ) == {"IMG": "Take a picture (requires -s)"}
	assert candidate(
) == {"IMG": "Take a picture (requires -s)"}, "candidate failed"
	assert candidate(
) == {
    "IMG": "Take a picture (requires -s)"
}, "candidate does not work"
	assert candidate(
) == {
    "IMG": "Take a picture (requires -s)"
}
def test_check():
	check(get_available_commands)
