def get_system_total_memory_gb():
    """ 
     Function to get the total RAM of the running system in GB
     """
	### Canonical solution below ###    

    # Import packages
    import os
    import sys

    # Get memory
    if "linux" in sys.platform:
        with open("/proc/meminfo", "r") as f_in:
            meminfo_lines = f_in.readlines()
            mem_total_line = [line for line in meminfo_lines if "MemTotal" in line][0]
            mem_total = float(mem_total_line.split()[1])
            memory_gb = mem_total / (1024.0 ** 2)
    elif "darwin" in sys.platform:
        mem_str = os.popen("sysctl hw.memsize").read().strip().split(" ")[-1]
        memory_gb = float(mem_str) / (1024.0 ** 3)
    else:
        err_msg = "System platform: %s is not supported"
        raise Exception(err_msg)

    # Return memory
    return memory_gb

### Unit tests below ###
def check(candidate):
	assert candidate(
) > 1.0, "candidate() is not returning a number greater than 1 GB"
	assert candidate(
) >= 0, "candidate() failed for some reason"
	assert candidate(
) > 0, "candidate() is not returning a positive value"
	assert isinstance(candidate(
), float), "candidate() does not return a float"
	assert candidate(
) <= candidate(), "candidate() is incorrect"
	assert candidate(
) <= candidate() + 1e-6, "Memory check failed"
	assert candidate(
) is not None, "candidate() is not defined"
	assert candidate(
) > 0.0, "candidate() is not working"
	assert candidate(
) > 0, "candidate() is broken. " \
       "It returns 0 GB on this machine."
	assert candidate(
) > 0, "candidate() is not returning a positive number"
	assert candidate(
) >= 0, "candidate returns a negative value!"
	assert candidate(
) >= 0.0, "candidate() is incorrect"
	assert candidate(
) == candidate()
	assert candidate(
) >= 0, "candidate() returned %s" % candidate()
	assert candidate(
) is not None, "Test failed: function returned None"
	assert isinstance(candidate(
), float), "candidate() is not returning a float"
	assert candidate(
) >= 1.0, "Error: candidate() is not returning a value greater than 1.0 GB"
	assert candidate(
) > 0, "candidate() is not implemented properly"
	assert candidate(
) <= candidate(), "Total memory is not less than available memory"
	assert candidate(
) > 0.0, "The total system memory should be larger than 0.0"
	assert candidate(
) > 0, "Expected result of candidate() to be greater than 0"
	assert candidate(
) > 0.0
	assert candidate(
) >= 1.0, "Test failed: candidate"
	assert candidate(
) >= 0, "candidate() is not returning a positive number"
	assert candidate(
) > 0.0, "candidate() should return a positive number"
def test_check():
	check(get_system_total_memory_gb)
