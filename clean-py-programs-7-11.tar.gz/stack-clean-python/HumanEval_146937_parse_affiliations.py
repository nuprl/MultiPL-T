def parse_affiliations(response):
    """ Parse the author affiliations from a MAG API response.
     
     Args:
     response (json): Response from MAG API in JSON format. Contains all paper information.
     
     Returns:
     affiliations (:obj:`list` of :obj:`dict`): List of dictionaries with affiliation information.
     There's one dictionary per field of study.
     author_with_aff (:obj:`list` of :obj:`dict`): Matching affiliation and author IDs.
     
     """
	### Canonical solution below ###    
    affiliations = []
    author_with_aff = []
    for aff in response["AA"]:
        if aff["AfId"]:
            # mag_author_affiliation
            author_with_aff.append(
                {"affiliation_id": aff["AfId"], "author_id": aff["AuId"]}
            )
            # mag_affiliation
            affiliations.append({"id": aff["AfId"], "affiliation": aff["AfN"]})
        else:
            continue
    return affiliations, author_with_aff

### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        "AA": [
            {
                "AfId": "123",
                "AfN": "affiliation_name",
                "AuId": "author_id",
                "DAuN": "author_name",
            },
            {
                "AfId": "",
                "AfN": "affiliation_name",
                "AuId": "author_id",
                "DAuN": "author_name",
            },
            {
                "AfId": None,
                "AfN": "affiliation_name",
                "AuId": "author_id",
                "DAuN": "author_name",
            },
        ]
    }
) == ([{"id": "123", "affiliation": "affiliation_name"}], [{"affiliation_id": "123", "author_id": "author_id"}])
	assert candidate({"AA": [{"AfId": "123", "AuId": "456", "AfN": "affiliation"}]}) == (
    [{"id": "123", "affiliation": "affiliation"}],
    [{"affiliation_id": "123", "author_id": "456"}],
)
	assert candidate(
    {
        "AA": [
            {
                "AfId": 1,
                "AuId": 1,
                "AfN": "Stanford University",
                "AfUrl": "https://www.stanford.edu/",
            },
            {
                "AfId": 2,
                "AuId": 2,
                "AfN": "Stanford University",
                "AfUrl": "https://www.stanford.edu/",
            },
        ]
    }
) == (
    [
        {"id": 1, "affiliation": "Stanford University"},
        {"id": 2, "affiliation": "Stanford University"},
    ],
    [
        {"affiliation_id": 1, "author_id": 1},
        {"affiliation_id": 2, "author_id": 2},
    ],
)
	assert candidate(
    {"AA": [{"AfId": "687284", "AuId": "687284", "AfN": "Universidade Federal de Santa Catarina"}]}
) == (
    [
        {"id": "687284", "affiliation": "Universidade Federal de Santa Catarina"}
    ],
    [{"affiliation_id": "687284", "author_id": "687284"}],
)
	assert candidate(
    {
        "AA": [
            {"AfId": 123456789, "AuId": 1, "AfN": "Affiliation 1"},
            {"AfId": None, "AuId": 1, "AfN": "Affiliation 2"},
            {"AfId": 987654321, "AuId": 2, "AfN": "Affiliation 3"},
            {"AfId": 987654321, "AuId": 3, "AfN": "Affiliation 4"},
        ]
    }
) == (
    [
        {"id": 123456789, "affiliation": "Affiliation 1"},
        {"id": 987654321, "affiliation": "Affiliation 3"},
        {"id": 987654321, "affiliation": "Affiliation 4"},
    ],
    [
        {"affiliation_id": 123456789, "author_id": 1},
        {"affiliation_id": 987654321, "author_id": 2},
        {"affiliation_id": 987654321, "author_id": 3},
    ],
)
	assert candidate(
    {
        "AA": [
            {
                "AfId": "607941",
                "AuId": "2184312414",
                "AfN": "The University of Tokyo",
            },
            {
                "AfId": "607941",
                "AuId": "2184312414",
                "AfN": "The University of Tokyo",
            },
        ]
    }
) == (
    [
        {"id": "607941", "affiliation": "The University of Tokyo"},
        {"id": "607941", "affiliation": "The University of Tokyo"},
    ],
    [
        {"affiliation_id": "607941", "author_id": "2184312414"},
        {"affiliation_id": "607941", "author_id": "2184312414"},
    ],
)
	assert candidate(
    {
        "AA": [
            {"AfId": "687284", "AuId": "687284", "AfN": "Universidade Federal de Santa Catarina"},
            {"AfId": None, "AuId": "687284", "AfN": ""},
        ]
    }
) == (
    [
        {"id": "687284", "affiliation": "Universidade Federal de Santa Catarina"}
    ],
    [{"affiliation_id": "687284", "author_id": "687284"}],
)
	assert candidate(
    {
        "AA": [
            {"AfId": "123", "AuId": "456", "AfN": "affiliation 1"},
            {"AfId": "789", "AuId": "456", "AfN": "affiliation 2"},
            {"AfId": None, "AuId": "456", "AfN": "affiliation 3"},
        ]
    }
) == (
    [
        {"id": "123", "affiliation": "affiliation 1"},
        {"id": "789", "affiliation": "affiliation 2"},
    ],
    [
        {"affiliation_id": "123", "author_id": "456"},
        {"affiliation_id": "789", "author_id": "456"},
    ],
)
	assert candidate({"AA": [{"AfId": "123", "AuId": "456", "AfN": "affiliation"}, {"AfId": None, "AuId": "456", "AfN": "affiliation"}]}) == (
    [{"id": "123", "affiliation": "affiliation"}],
    [{"affiliation_id": "123", "author_id": "456"}],
)
	assert candidate({"AA": []}) == ([], [])
def test_check():
	check(parse_affiliations)
