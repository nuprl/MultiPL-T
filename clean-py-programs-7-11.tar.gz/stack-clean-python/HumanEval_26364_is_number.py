def is_number(s):
    """Check if a string is a number or not."""
    ### Canonical solution below ###

    try:
        float(s)
        return True
    except ValueError:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate('3.1415') == True
	assert candidate(10) == True
	assert candidate("abc") == False
	assert candidate('three') == False
	assert candidate("42.42") == True
	assert candidate(42) == True
	assert candidate(2)
	assert candidate(10)
	assert candidate('') == False
	assert candidate(str(float('3.14'))) == True
	assert candidate("42,42") == False
	assert candidate(2.0)
	assert candidate("123.45") == True
	assert candidate(' ') == False
	assert candidate("10") == True
	assert candidate(0) == True
	assert candidate('4') == True
	assert not candidate('a')
	assert candidate('1.0') == True
	assert candidate(-1) == True
	assert candidate('four') == False
	assert candidate("42.0") == True
	assert candidate(3) == True
	assert candidate("1") == True
	assert candidate(1.0) == True
	assert candidate(-1.0) == True
	assert candidate("42") == True
	assert candidate(3.) == True
	assert candidate("a") == False
	assert candidate('3.0') == True
	assert candidate(10.5) == True
	assert candidate('-1') == True
	assert candidate("forty-two") == False
	assert candidate(1) == True
	assert candidate('0.0') == True
	assert candidate("42.0a") == False
	assert candidate("42,0") == False
	assert candidate(float('3.14')) == True
	assert candidate("10.5") == True
	assert candidate("42a") == False
	assert candidate(3.0) == True
	assert candidate('a') == False
	assert candidate("one") == False
	assert candidate("None") == False
	assert candidate(3.1415) == True
	assert candidate('1.3') == True
	assert candidate('-1.0') == True
	assert candidate('3') == True
	assert candidate(4) == True
	assert candidate(1.0)
	assert candidate(10.0)
	assert candidate('hello') == False
	assert candidate("10a") == False
	assert candidate("1.0") == True
	assert not candidate("two")
	assert candidate(123.45) == True
	assert candidate(1)
	assert candidate('1') == True
	assert candidate("1 000") == False
def test_check():
	check(is_number)
