def _strip_external_workspace_prefix(path):
    """ Either 'external/workspace_name/' or '../workspace_name/'."""
	### Canonical solution below ###    

    # Label.EXTERNAL_PATH_PREFIX is due to change from 'external' to '..' in Bazel 0.4.5.
    # This code is for forwards and backwards compatibility.
    # Remove the 'external/' check when Bazel 0.4.4 and earlier no longer need to be supported.
    if path.startswith("../") or path.startswith("external/"):
        return "/".join(path.split("/")[2:])
    return path

### Unit tests below ###
def check(candidate):
	assert candidate(
    "../workspace_name/") == ""
	assert candidate(
    "external/workspace_name/some/package/file.txt") == "some/package/file.txt"
	assert candidate("some/file.txt") == "some/file.txt"
	assert candidate("foo/bar") == "foo/bar"
	assert candidate(
    "../workspace_name/path/to/file") == "path/to/file"
	assert candidate(
    "external/workspace_name/path/to/file") == "path/to/file"
	assert candidate(
    "../workspace_name/some/package/file.txt") == "some/package/file.txt"
	assert candidate(
    "external_workspace_name/") == "external_workspace_name/"
	assert candidate(
    "external/workspace_name/") == ""
	assert candidate("workspace_name/src/main/java/com/foo/bar") == "workspace_name/src/main/java/com/foo/bar"
def test_check():
	check(_strip_external_workspace_prefix)
