def technique(attackID, mapped_controls):
    """create a technique for a layer"""
    ### Canonical solution below ###
    return {
        "techniqueID": attackID,
        "score": len(mapped_controls), # count of mapped controls
        "comment": "Mitigated by " + ", ".join(sorted(mapped_controls)) # list of mapped controls
    }


### Unit tests below ###
def check(candidate):
	assert candidate(
    "T1003",
    {"C1", "C2"}
) == {
    "candidateID": "T1003",
    "score": 2,
    "comment": "Mitigated by C1, C2"
}
	assert candidate(
    "T1003",
    ["C0001", "C0002"]
) == {
    "candidateID": "T1003",
    "score": 2,
    "comment": "Mitigated by C0001, C0002"
}
	assert candidate(attackID="T1033", mapped_controls=[]) == {
    "candidateID": "T1033",
    "score": 0,
    "comment": "Mitigated by "
}
	assert candidate(attackID="T1003", mapped_controls=["C1", "C2", "C3"]) == {
    "candidateID": "T1003",
    "score": 3,
    "comment": "Mitigated by C1, C2, C3"
}
	assert candidate(123, ["1", "2", "3"]) == {
    "candidateID": 123,
    "score": 3,
    "comment": "Mitigated by 1, 2, 3"
}
	assert candidate(1, ["a", "b"]) == {
    "candidateID": 1,
    "score": 2,
    "comment": "Mitigated by a, b"
}
	assert candidate(attackID="T1001", mapped_controls=["C1", "C2", "C3"]) == {
    "candidateID": "T1001",
    "score": 3,
    "comment": "Mitigated by C1, C2, C3"
}
	assert candidate(1, ["a", "b", "c"]) == {
    "candidateID": 1,
    "score": 3,
    "comment": "Mitigated by a, b, c"
}
	assert candidate(
    "T1530",
    ["C1", "C2", "C3", "C4", "C5"]
) == {
    "candidateID": "T1530",
    "score": 5,
    "comment": "Mitigated by C1, C2, C3, C4, C5"
}
	assert candidate(attackID="T1001", mapped_controls=["c1", "c2", "c3"]) == {
    "candidateID": "T1001",
    "score": 3,
    "comment": "Mitigated by c1, c2, c3"
}
	assert candidate(attackID = "T1001", mapped_controls = ["C1", "C2"]) == {
    "candidateID": "T1001",
    "score": 2,
    "comment": "Mitigated by C1, C2"
}
	assert candidate(attackID="T1001", mapped_controls=["c1", "c2"]) == {
    "candidateID": "T1001",
    "score": 2,
    "comment": "Mitigated by c1, c2"
}
	assert candidate(attackID="T1098", mapped_controls=["a", "b"]) == {
    "candidateID": "T1098",
    "score": 2,
    "comment": "Mitigated by a, b"
}
	assert candidate(attackID="T1033", mapped_controls=["C1", "C2", "C3"]) == {
    "candidateID": "T1033",
    "score": 3,
    "comment": "Mitigated by C1, C2, C3"
}
	assert candidate(
    "T1106",
    ["C1", "C2", "C3"]
) == {
    "candidateID": "T1106",
    "score": 3,
    "comment": "Mitigated by C1, C2, C3"
}
	assert candidate(
    "T1136",
    {
        "C1111": 1,
        "C2222": 1
    }
) == {
    "candidateID": "T1136",
    "score": 2,
    "comment": "Mitigated by C1111, C2222"
}
	assert candidate(
    "T1003.003",
    ["C2", "C3", "C4"]
) == {
    "candidateID": "T1003.003",
    "score": 3,
    "comment": "Mitigated by C2, C3, C4"
}
	assert candidate("T1000", ["C1", "C2"]) == {
    "candidateID": "T1000",
    "score": 2,
    "comment": "Mitigated by C1, C2"
}
	assert candidate(attackID="T1566.001", mapped_controls=["G0035"]) == {
    "candidateID": "T1566.001",
    "score": 1,
    "comment": "Mitigated by G0035"
}
def test_check():
	check(technique)
