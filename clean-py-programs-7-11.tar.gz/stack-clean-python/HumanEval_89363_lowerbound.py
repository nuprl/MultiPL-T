def lowerbound(sorted_arr, val):
    """ Finds the SMALLEST index to insert the value `val` so that the elements in `sorted_arr` remain sorted."""
	### Canonical solution below ###    
    # Get the length of the array
    n = len(sorted_arr)

    # Perform binary search
    left = 0
    right = n - 1

    while left < right:
        middle = (left + right) // 2

        if sorted_arr[middle] < val:
            left = middle + 1  # Can ignore middle
        else:
            right = middle  # May be on the middle value

    # Return left pointer
    return left

### Unit tests below ###
def check(candidate):
	assert candidate(sorted([1, 2, 3, 4, 5, 6]), 6) == 5
	assert candidate(list(range(10)), 5) == 5
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 6) == 5
	assert candidate(sorted([1, 2]), 0) == 0
	assert candidate(list(range(100)), 30) == 30
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 3) == 2
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 7) == 7
	assert candidate(sorted([1, 3, 5]), 4) == 2
	assert candidate(sorted([1, 3, 5]), 1) == 0
	assert candidate(sorted([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), 0) == 0
	assert candidate(list(range(10)), -100) == 0
	assert candidate(sorted([1,2,3,4,5,6]), 1) == 0
	assert candidate(sorted([1, 2, 3]), 2) == 1
	assert candidate(sorted([1, 2, 3]), 3) == 2
	assert candidate(list(range(10)), 9) == 9
	assert candidate(list(range(10)), 3) == 3
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 2) == 1
	assert candidate(sorted([1, 2, 3]), 0) == 0
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 3) == 2
	assert candidate(sorted([1, 3, 5]), 3) == 1
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 5) == 4
	assert candidate(sorted([1, 3, 5, 6]), 6) == 3
	assert candidate(sorted([1, 3, 5, 7, 9]), 1) == 0
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), 3) == 2
	assert candidate(sorted([1, 3, 5, 7, 9]), 6) == 3
	assert candidate(sorted([1, 3, 5, 7, 9]), 9) == 4
	assert candidate(list(range(100)), 50) == 50
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 9) == 7
	assert candidate(sorted([1, 3, 5, 7, 9]), 0) == 0
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), 4) == 3
	assert candidate(sorted([1, 2, 3, 4, 5]), 5) == 4
	assert candidate(sorted([1, 3, 5, 7, 9]), 7) == 3
	assert candidate(list(range(100)), 70) == 70
	assert candidate(list(range(100)), 60) == 60
	assert candidate(sorted([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), 2) == 2
	assert candidate(sorted([1, 2, 3, 4, 5]), 0) == 0
	assert candidate(sorted([1, 2, 3]), 1) == 0
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), 1) == 0
	assert candidate(list(range(100)), 90) == 90
	assert candidate(sorted([1,2,3,4,5,6]), 6) == 5
	assert candidate(sorted([1, 3, 5, 6]), 2) == 1
	assert candidate(list(range(10)), 0) == 0
	assert candidate(sorted([1, 2, 3, 4, 5, 6]), 1) == 0
	assert candidate(sorted([1, 3, 5]), 0) == 0
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 8) == 7
	assert candidate(sorted([1]), 1) == 0
	assert candidate(list(range(100)), 10) == 10
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 7) == 6
	assert candidate(sorted([1,2,3,4,5,6]), 5) == 4
	assert candidate(list(range(10)), -1) == 0
	assert candidate(sorted([1]), 0) == 0
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), -1) == 0
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 1) == 0
	assert candidate(sorted([1,2,3,4,5,6]), 0) == 0
	assert candidate(list(range(10)), 4) == 4
	assert candidate(sorted([1, 2, 4, 5, 6, 7]), 3) == 2
	assert candidate(sorted([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), 8) == 8
	assert candidate(list(range(100)), 40) == 40
	assert candidate(sorted([1, 3, 5, 7, 9]), 8) == 4
	assert candidate(sorted([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), 5) == 5
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 2) == 1
	assert candidate(sorted([1, 3, 5, 6]), 3) == 1
	assert candidate(sorted([1, 3, 5, 6]), 0) == 0
	assert candidate(sorted([1, 3, 5, 6]), 5) == 2
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 0) == 0
	assert candidate(sorted([1, 3, 5, 7, 9]), 3) == 1
	assert candidate(sorted([1, 3, 5, 7, 9]), 2) == 1
	assert candidate(sorted([1, 3, 5, 6]), 4) == 2
	assert candidate(sorted([1, 2, 3, 4, 5]), 3) == 2
	assert candidate(sorted([1, 3, 5, 7, 9]), 5) == 2
	assert candidate(sorted([1, 3, 5]), 5) == 2
	assert candidate(list(range(100)), 80) == 80
	assert candidate(sorted([1, 3, 5, 7, 9]), 4) == 2
	assert candidate(sorted([1, 2, 3, 4, 5, 6]), 0) == 0
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 5) == 7
	assert candidate(sorted([1, 2, 3, 4, 5, 6]), 5) == 4
	assert candidate(sorted([1, 2, 3, 3, 3, 3, 4, 5]), 6) == 7
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 4) == 3
	assert candidate(sorted([1, 2, 3, 4, 5]), 1) == 0
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7]), 1) == 0
	assert candidate(list(range(100)), 20) == 20
	assert candidate(sorted([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), 10) == 9
	assert candidate(sorted([1, 3, 5]), 2) == 1
def test_check():
	check(lowerbound)
