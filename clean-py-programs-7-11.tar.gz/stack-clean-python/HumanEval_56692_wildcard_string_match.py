def wildcard_string_match(val,pattern,wildcard='?',wildcard_exclude=''):
    """Generate a TRUE / FALSE for matching the given value against a pattern. Enables wildcard searching & excludable characters from wildcard.

    Args:
        val (string): Value to check if matches.
        pattern (string): Pattern to check the val against.
        wildcard (str, optional): Wildcard character used in pattern. Defaults to '?'.
        wildcard_exclude (str, optional): Characters to exclude from wildcard. Defaults to ''.

    Returns:
        bool : TRUE == match, FALSE == no match
    """
    ### Canonical solution below ###
    
    if len(val) == 0 or len(pattern) == 0:
        return True
    
    if val[0] in wildcard_exclude:
        return False
    elif pattern[0] == wildcard or pattern[0] == val[0]:
        return wildcard_string_match(val[1:],pattern[1:],wildcard,wildcard_exclude)
    else:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate("","") == True
	assert candidate(val='test',pattern='?*?',wildcard_exclude='*') == False
	assert candidate(val='test',pattern='??*') == False
	assert candidate(
    'Hello, World!',
    'Hello, W?rld!'), "Matching with? wildcard"
	assert candidate(val="a",pattern="b",wildcard='?',wildcard_exclude='') == False
	assert candidate(val="test",pattern="t???t",wildcard_exclude='est') == False
	assert candidate(val='test',pattern='????')
	assert candidate(val="test",pattern="t???t",wildcard_exclude='?e?') == False
	assert candidate(
    '12345',
    '12345?',
    wildcard='?'
)
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='ac') == False
	assert candidate(val='abc',pattern='?b?*?*') == True
	assert candidate(val='test',pattern='tes',wildcard_exclude='st') == False
	assert candidate(val='test',pattern='?es?')
	assert candidate(val='abcd',pattern='a?cd',wildcard='?',wildcard_exclude='') == True
	assert candidate(
    'test',
    'test',
    '?',
    'ts') == False
	assert candidate(val='test',pattern='t??t')
	assert candidate(val='test',pattern='???t')
	assert candidate(val="abc",pattern="?b?c?",wildcard_exclude='?')
	assert candidate(val="test",pattern="t???t",wildcard_exclude='?t?') == False
	assert candidate(val="abc",pattern="abc")
	assert candidate(val='test',pattern='te??')
	assert candidate(val="a",pattern="?",wildcard='?',wildcard_exclude='') == True
	assert candidate(val='test',pattern='???')
	assert candidate(val="a",pattern="?") == True
	assert candidate(val="test",pattern="t?t",wildcard_exclude="?") == False
	assert candidate(val="a",pattern="a") == True
	assert candidate(val="a",pattern="a",wildcard='?',wildcard_exclude='') == True
	assert candidate(val = 'test', pattern = 'tes?') == True
	assert candidate(val='',pattern='?') == True
	assert candidate(val="ab",pattern="a?") == True
	assert candidate(
    'abc','?bc') == True
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='a?c') == False
	assert candidate(val = 'test', pattern = 'tes', wildcard='?', wildcard_exclude='') == True
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='abc') == False
	assert candidate("A","?A") == True
	assert candidate(val='abc',pattern='?b?c?d?e*?*') == True
	assert candidate(val='test',pattern='tes',wildcard_exclude='est') == False
	assert candidate(
    'abc','??') == True
	assert candidate(val='',pattern='') == True
	assert candidate(val="a",pattern="b") == False
	assert candidate(val='test',pattern='tes?') == True
	assert candidate(val="ab",pattern="?b",wildcard='?',wildcard_exclude='a') == False
	assert candidate(val="ab",pattern="?b",wildcard='?',wildcard_exclude='a,b') == False
	assert candidate(val='abc',pattern='*?*?',wildcard_exclude='?') == False
	assert candidate(
    'test',
    'test',
    '?',
    'e') == False
	assert candidate(val="hello", pattern="he??o") == True
	assert candidate(val='abcd',pattern='abc?',wildcard='?',wildcard_exclude='') == True
	assert candidate(val='test',pattern='test?',wildcard='?') == True
	assert candidate( 'this is a test', 'this is a test') == True
	assert candidate(val = 'test', pattern = '?es?', wildcard='?', wildcard_exclude='') == True
	assert candidate(val='test',pattern='??st')
	assert candidate(val="test",pattern="?*t*?",wildcard_exclude="?") == False
	assert candidate(val='test',pattern='test??') == True
	assert candidate(val='abc',pattern='a?c') == True
	assert candidate(val = 'test', pattern = 'tes*?',wildcard_exclude='?') == False
	assert candidate(val="",pattern="") == True
	assert not candidate(val="abc",pattern="?b?c?",wildcard_exclude='a')
	assert candidate("A","B") == False
	assert candidate(val="abc",pattern="?")
	assert candidate(
    'abc','a?c') == True
	assert candidate(
    'abc','??c') == True
	assert candidate(val='test',pattern='test')
	assert candidate(
    '12345',
    '?2345',
    wildcard='?'
)
	assert candidate(val='',pattern='???') == True
	assert candidate(val='test',pattern='test',wildcard_exclude='?') == True
	assert candidate(val='abc',pattern='??*??',wildcard_exclude='?') == False
	assert candidate(val='abcd',pattern='ab?d',wildcard='?',wildcard_exclude='') == True
	assert candidate(val='test',pattern='t??t?t?') == True
	assert candidate("AB","?B?A?C?D") == True
	assert candidate(val='test',pattern='t??t?t?t?t?') == True
	assert not candidate(val='test',pattern='t?t',wildcard_exclude='t')
	assert candidate(val='abc',pattern='ab') == True
	assert candidate(val="ab",pattern="?b",wildcard='?',wildcard_exclude='') == True
	assert candidate(val='abcd',pattern='abcd',wildcard='?',wildcard_exclude='') == True
	assert candidate(val="hello", pattern="he?lo",wildcard_exclude="helo") == False
	assert candidate(val='abc',pattern='b') == False
	assert candidate(val="abc",pattern="?b?c")
	assert candidate(val="test",pattern="t???t",wildcard_exclude='?est?') == False
	assert candidate(val='test',pattern='??') == True
	assert candidate(
    'abc','abc') == True
	assert candidate(
    '12345',
    '12345?',
    wildcard='?',
    wildcard_exclude='?'
)
	assert candidate(val='test',pattern='test?') == True
	assert candidate(val='abc',pattern='?b?*') == True
	assert candidate(val='test',pattern='tes',wildcard_exclude='es') == False
	assert candidate(
    'Hello, World!',
    'Hello, Wo?ld!'), "Matching with multiple? wildcards"
	assert candidate(
    '12345',
    '12??5',
    wildcard='?',
    wildcard_exclude='?'
)
	assert candidate(
    'test',
    'test',
    '?',
    'est') == False
	assert candidate(val='test',pattern='tes',wildcard_exclude='t?*') == False
	assert candidate(val='abc',pattern='c') == False
	assert candidate(val='test',pattern='?') == True
	assert candidate(val='',pattern='????') == True
	assert candidate( 'this is a test', '?his? is a test') == False
	assert candidate( 'abc', 'a?c' ) == True
	assert candidate(val="test",pattern="t???t",wildcard_exclude='t?st') == False
	assert candidate(val='test',pattern='te?t',wildcard='?') == True
	assert candidate(val="test",pattern="test?") == True
	assert candidate(val='test',pattern='tes',wildcard_exclude='tes') == False
	assert not candidate(val="abc",pattern="?b?c?",wildcard_exclude='b')
	assert candidate(val="test",pattern="t???t",wildcard_exclude='e') == False
	assert candidate(val = 'test', pattern = '?est', wildcard='?', wildcard_exclude='') == True
	assert candidate(val="a",pattern="?")
	assert candidate(val = 'test', pattern = 'test', wildcard='?', wildcard_exclude='') == True
	assert candidate(val="test",pattern="tes*",wildcard_exclude="?") == False
	assert not candidate(val='test',pattern='t?t',wildcard_exclude='tes')
	assert candidate(
    '12345',
    '12345'
)
	assert candidate( 'this is a test', 'this? is a test') == False
	assert candidate(
    'test',
    'test',
    '?',
    'testest') == False
	assert candidate(val="test",pattern="?*",wildcard_exclude="?") == False
	assert candidate(val='test',pattern='te*t',wildcard='*') == True
	assert not candidate(val='test',pattern='t?t',wildcard_exclude='s')
	assert candidate(val='abc',pattern='??') == True
	assert candidate(val='test',pattern='?*') == False
	assert candidate(val='test',pattern='tes',wildcard_exclude='s') == False
	assert candidate(val='test',pattern='tes',wildcard_exclude='t?s') == False
	assert candidate(val="a",pattern="a*")
	assert not candidate(val='test',pattern='t?t',wildcard_exclude='test')
	assert candidate(
    '12345',
    '1?345',
    wildcard='?'
)
	assert candidate(val='test',pattern='test*',wildcard='*') == True
	assert candidate(val='test',pattern='t??t?') == True
	assert candidate(val="hello", pattern="he?lo",wildcard_exclude="hello") == False
	assert candidate(val='abc',pattern='?b?c') == True
	assert candidate(val="test",pattern="t*?",wildcard_exclude="?") == False
	assert candidate(val="hello", pattern="he?lo",wildcard_exclude="l") == False
	assert candidate(val = 'test', pattern = '?es?') == True
	assert candidate(
    'test',
    'test',
    '?',
    'test') == False
	assert candidate(val='abc',pattern='???c???') == True
	assert candidate(val='abc',pattern='???') == True
	assert candidate(val="test",pattern="?est?") == True
	assert candidate(val="hello", pattern="he?lo",wildcard_exclude="hel") == False
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='c') == False
	assert candidate(
    'test',
    'test',
    '?',
    'teste') == False
	assert candidate(val="hello", pattern="he?lo") == True
	assert candidate(val='abc',pattern='?bc') == True
	assert not candidate(val='test',pattern='t?t',wildcard_exclude='e')
	assert candidate(val='abc',pattern='ab?c') == True
	assert candidate(val="test",pattern="t*t",wildcard_exclude="?") == False
	assert candidate(val='test',pattern='t??') == True
	assert not candidate(val='test',pattern='t?t',wildcard_exclude='st')
	assert candidate(val="test",pattern="test*") == True
	assert candidate(val="test",pattern="test") == True
	assert candidate(val="abc",pattern="??")
	assert candidate("A","?A?B") == True
	assert candidate(val='test',pattern='te?t') == True
	assert candidate(val='abc',pattern='*?',wildcard_exclude='?') == False
	assert candidate(val='test',pattern='tes',wildcard_exclude='te') == False
	assert candidate(val='test',pattern='t???')
	assert candidate(val='abc',pattern='?b?c?d?*?*') == True
	assert candidate(val='abc',pattern='*c',wildcard_exclude='?') == False
	assert candidate(val='',pattern='?????') == True
	assert candidate(
    '12345',
    '12??5',
    wildcard='?'
)
	assert candidate("A","?B?A") == True
	assert candidate(
    'test',
    'test',
    '?',
    'tes') == False
	assert candidate(val='test',pattern='tes',wildcard_exclude='t*s') == False
	assert candidate(val='test',pattern='test') == True
	assert not candidate(val='test',pattern='t?t',wildcard_exclude='est')
	assert candidate(
    '12345',
    '12345',
    wildcard='?',
    wildcard_exclude='?'
)
	assert candidate(val='test',pattern='t??t?t?t?t?t?') == True
	assert candidate(val="test",pattern="t*?") == False
	assert candidate("A","?") == True
	assert candidate(val='test',pattern='t??t?t?t?') == True
	assert candidate(val='test',pattern='?e?t')
	assert candidate(
    'test',
    'test',
    '?',
    'es') == False
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='b') == False
	assert candidate(val='test',pattern='tes',wildcard_exclude='e') == False
	assert candidate(
    'Hello, World!',
    'Hello, W?rld!'), "Matching with multiple? wildcards"
	assert candidate(val = 'test', pattern = '?es?', wildcard='?', wildcard_exclude='e') == False
	assert candidate(val='abcd',pattern='a?d',wildcard='?',wildcard_exclude='?') == False
	assert candidate(val='abc',pattern='a*c',wildcard_exclude='?') == False
	assert candidate(val='abc',pattern='?b?c?d*?*') == True
	assert candidate(val="a",pattern="a?")
	assert candidate(val='abc',pattern='?b?c*?*') == True
	assert candidate(val='abc',pattern='?*?*?',wildcard_exclude='?') == False
	assert candidate(
    'test',
    'test',
    '?',
   's') == False
	assert candidate(
    'test',
    'test',
    '?',
    't') == False
	assert candidate("A","A") == True
	assert candidate(val='test',pattern='t?st') == True
	assert candidate(val="hello", pattern="he?lo",wildcard_exclude="lo") == False
	assert candidate(val='test',pattern='tes',wildcard_exclude='t') == False
	assert candidate(val="ab",pattern="?b",wildcard='?',wildcard_exclude='b') == False
	assert candidate(val="test",pattern="t???t") == True
	assert candidate(val="test",pattern="tes?") == True
	assert candidate(val = 'test', pattern = 'tes*?',wildcard_exclude='*') == False
	assert candidate(val="test",pattern="t???t",wildcard_exclude='?t?t?') == False
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='a') == False
	assert candidate(val='abc',pattern='?b?c?*?*') == True
	assert candidate(
    'abc','?b?') == True
	assert candidate(val="hello", pattern="hello") == True
	assert candidate(val="abc",pattern="a?c")
	assert candidate(val="",pattern="",wildcard='?',wildcard_exclude='') == True
	assert candidate(
    'abc','ab?c') == True
	assert candidate(
    'test',
    'test',
    '?',
    '') == True
	assert candidate(val='abcd',pattern='ab?cd',wildcard='?',wildcard_exclude='?') == False
	assert candidate(val='test',pattern='?est')
	assert candidate(val="hello", pattern="he?lo",wildcard_exclude="llo") == False
	assert candidate(
    '12345',
    '12?45',
    wildcard='?'
)
	assert candidate(val="test",pattern="t???t",wildcard_exclude='?es?') == False
	assert candidate(val='abc',pattern='?b?c?d?e?*?*') == True
	assert candidate( 'this is a test', 'this is a?',wildcard='*',wildcard_exclude=' ') == False
	assert candidate(val='test',pattern='test',wildcard_exclude='*') == True
	assert candidate(val = 'test', pattern = 'tes?', wildcard='?', wildcard_exclude='') == True
	assert candidate(val='abc',pattern='abc') == True
	assert candidate(
    '12345',
    '1?3?5',
    wildcard='?',
    wildcard_exclude='?'
)
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='ab') == False
	assert candidate(val = 'test', pattern = 'te?t', wildcard='?', wildcard_exclude='') == True
	assert candidate(
    '12345',
    '1?3?5',
    wildcard='?'
)
	assert candidate(val="",pattern="")
	assert not candidate(
    'abcdefghijklmnopqrstuvwxyz',
    'abc?xyz',
    wildcard_exclude='abc?'
    )
	assert candidate(val="a",pattern="a")
	assert candidate(val="ab",pattern="a?b") == True
	assert candidate(val="a",pattern="?a")
	assert candidate(val='abc',pattern='?') == True
	assert candidate(val='abc',pattern='a?c',wildcard_exclude='bc') == False
	assert candidate(val="hello", pattern="he?lo",wildcard_exclude="he") == False
def test_check():
	check(wildcard_string_match)
