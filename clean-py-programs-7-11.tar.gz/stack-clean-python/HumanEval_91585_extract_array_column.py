def extract_array_column(a, col):
    """ Extracts a column from a tabular structure
     
     @type a:  list/tuple
     @param a: an array of equal-sized arrays, representing
     a table as a list of rows.
     @type col:  usually int or str
     @param col: the column key of the column to extract
     
     @rtype:  list
     @return: the values of column col from each row in a
     
     """
	### Canonical solution below ###    
    column = []
    
    for r in a:
        column.append( r[col] )
    
    return column

### Unit tests below ###
def check(candidate):
	assert candidate( [(1,2,3), (4,5,6)], 1 ) == [2, 5]
	assert candidate( [(1,2,3),(4,5,6)], 1 ) == [2,5]
	assert candidate( [ [ 1, 2 ], [ 3, 4 ] ], 0 ) == [ 1, 3 ]
	assert candidate(
    [
        (1,2,3),
        (4,5,6),
        (7,8,9)
    ],
    2
) == [3, 6, 9]
	assert candidate( [['a', 'b', 'c'], ['1', '2', '3']], 1) == ['b', '2']
	assert candidate(
    [ (1,2,3), (4,5,6), (7,8,9) ],
    1 ) == [ 2, 5, 8 ]
	assert candidate( [ [1,2,3], [4,5,6] ], 2 ) == [3,6]
	assert candidate( [[1,2,3], [4,5,6]], 2 ) == [3, 6]
	assert candidate(
    [
        ['a', 'b', 'c'],
        ['d', 'e', 'f'],
        ['g', 'h', 'i'],
    ],
    0,
) == ['a', 'd', 'g']
	assert candidate(
    [ [1,2,3], [4,5,6] ], 1) == [2,5]
	assert candidate( [[1,2,3],[4,5,6],[7,8,9]], 1 ) == [2,5,8]
	assert candidate( [ [1,2,3], [4,5,6], [7,8,9] ], -2 ) == [2,5,8]
	assert candidate( [ [ 0, 1 ], [ 2, 3 ] ], 0 ) == [ 0, 2 ]
	assert candidate(
    [
        (1,2,3),
        (4,5,6),
        (7,8,9)
    ],
    1
) == [2, 5, 8]
	assert candidate( [[1,2,3], [4,5,6]], 1) == [2,5]
	assert candidate( [ [1,2,3], [4,5,6] ], 1 ) == [2,5]
	assert candidate( [ [1, 2, 3], [4, 5, 6], [7, 8, 9] ], 1 ) == [2, 5, 8]
	assert candidate( [ [1,2,3], [4,5,6] ], 0 ) == [ 1, 4 ]
	assert candidate( [ ['1','2','3'], ['4','5','6'] ], 2 ) == ['3','6']
	assert candidate( [ [1,2,3], [4,5,6] ], 0 ) == [1,4]
	assert candidate( [['a', 'b', 'c'], ['1', '2', '3']], 0) == ['a', '1']
	assert candidate( [['a', 'b', 'c'], ['1', '2', '3']], 2) == ['c', '3']
	assert candidate( [[1,2,3],[4,5,6]], 1 ) == [2,5]
	assert candidate( [[1,2,3], [4,5,6]], 2) == [3,6]
	assert candidate( [[1,2,3],[4,5,6],[7,8,9]], 2 ) == [3,6,9]
	assert candidate( [ [1,2,3], [4,5,6], [7,8,9] ], -1 ) == [3,6,9]
	assert candidate( [[1,2,3],[4,5,6]], 2 ) == [3,6]
	assert candidate( [ [1,2,3], [4,5,6], [7,8,9] ], 0 ) == [1,4,7]
	assert candidate(
    [
        (1,2,3),
        (4,5,6),
        (7,8,9)
    ],
    0
) == [1, 4, 7]
	assert candidate( [[1,2,3],[4,5,6]], 0 ) == [1,4]
	assert candidate( [[1,2,3],[4,5,6],[7,8,9]], 0 ) == [1,4,7]
	assert candidate( [ {'a':1, 'b':2}, {'a':3, 'b':4} ], 'a' ) == [1,3]
	assert candidate( [ {'a':1, 'b':2}, {'a':3, 'b':4} ], 'b' ) == [2,4]
	assert candidate( [["a", "b", "c"], ["d", "e", "f"]], 0 ) == [ "a", "d" ]
	assert candidate( [[1,2,3], [4,5,6]], 1 ) == [2, 5]
	assert candidate( [ [1,2,3], [4,5,6] ], 2 ) == [ 3, 6 ]
	assert candidate( [ ['1','2','3'], ['4','5','6'] ], 0 ) == ['1','4']
	assert candidate( [ [1,2,3], [4,5,6] ], 1 ) == [ 2, 5 ]
	assert candidate( [ [ 1, 2 ], [ 3, 4 ] ], 1 ) == [ 2, 4 ]
	assert candidate( [ ['1','2','3'], ['4','5','6'] ], 1 ) == ['2','5']
def test_check():
	check(extract_array_column)
