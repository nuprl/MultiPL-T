def _are_values_different(old_value, new_value):
    """Checks if the two values are different whilst treating a blank string the same as a None."""
    ### Canonical solution below ###
    old_value = old_value if old_value != '' else None
    new_value = new_value if new_value != '' else None
    return old_value != new_value


### Unit tests below ###
def check(candidate):
	assert candidate('','') == False
	assert candidate('1', None)
	assert candidate('', 0) is True
	assert candidate(123.456, 654.321) == True
	assert candidate(1, 2)
	assert candidate(False, True) == True
	assert candidate(1.1, 1.1) == False
	assert candidate('', '1') == True
	assert candidate('Hello', 'Hello ') == True
	assert candidate(None, 1)
	assert candidate('1', '2') == True
	assert candidate(654.321, 123.456) == True
	assert not candidate(False, False)
	assert candidate('123', '') is True
	assert candidate(1.0, 2.0) is True
	assert candidate(321, 123) == True
	assert candidate(True, False) == True
	assert candidate(None, '123') is True
	assert candidate('hello ', 'hello') is True
	assert not candidate(0.0, 0.0)
	assert candidate(None, 'test') == True
	assert candidate(1, None) is True
	assert candidate('Hello', 'Hello') == False
	assert candidate('', None) == False
	assert candidate(None, 1) is True
	assert candidate(1, None) == True
	assert candidate(True, True) == False
	assert candidate('1', '2')
	assert candidate(1.0, 1.0) == False
	assert candidate('hello', 'hello') is False
	assert candidate(1, 2) is True
	assert candidate(123, '123') == True
	assert candidate(123, 123) == False
	assert candidate(1, '') is True
	assert candidate(None, '') is False
	assert candidate(1, 1) == False
	assert candidate(None, 'a')
	assert candidate(' ', 'Hello') == True
	assert candidate(None, '1')
	assert candidate('b', 'a') is True
	assert candidate('a', 'b') is True
	assert candidate('', '') == False
	assert candidate(123.456, 123.456) == False
	assert candidate(True, False) is True
	assert not candidate('', '')
	assert candidate(None, None) is False
	assert not candidate(None, '')
	assert candidate('123', 123) == True
	assert candidate('123', '456') is True
	assert candidate('', '1')
	assert candidate('hello', 'hello ') is True
	assert candidate('Hello ', 'Hello') == True
	assert candidate('a', None) is True
	assert candidate('', 'a') == True
	assert candidate('a', '') == True
	assert candidate(None, 'foo') == True
	assert candidate('a', 'b') == True
	assert candidate(None, 1) == True
	assert candidate('a', None)
	assert candidate('', 1) is True
	assert candidate(1, None)
	assert candidate('a', 'b')
	assert candidate(123, 321) == True
	assert candidate(True, True) is False
	assert candidate(1.0, None) == True
	assert candidate('test', None) == True
	assert candidate(1.0, 1.0) is False
	assert candidate('', '') is False
	assert candidate(1.0, 1.1) == True
	assert candidate(123.456, '123.456') == True
	assert candidate(None, 'a') is True
	assert candidate('foo', None) == True
	assert not candidate('a', 'a')
	assert candidate(None, '1') == True
	assert candidate('b', 'a') == True
	assert candidate('1', '') == True
	assert candidate('a', 'a') == False
	assert candidate('', None) is False
	assert candidate(' ', None) == True
	assert candidate('foo', 'foo') == False
	assert candidate('', 'test') == True
	assert candidate(None, None) == False
	assert candidate('', '123') is True
	assert candidate(1, 1) is False
	assert candidate('hello', None) is True
	assert candidate('1', '1') == False
	assert candidate('a', 'a') is False
	assert candidate('123', None) is True
	assert candidate('', 'a') is True
	assert candidate('a', None) == True
	assert candidate(None, 'hello') is True
	assert candidate(None, 'test')
	assert candidate('1', '')
	assert candidate('True', True) == True
	assert candidate('test', 'test') == False
	assert candidate('1', None) == True
	assert candidate('test', None)
	assert candidate('456', '123') is True
	assert candidate('foo', '') == True
	assert candidate(1, 2) == True
	assert not candidate('', None)
	assert candidate(0, '') is True
	assert candidate(None, '') == False
	assert candidate('a', '') is True
	assert candidate('', 'foo') == True
	assert not candidate(None, None)
	assert candidate('123', '123') is False
	assert candidate('123.456', 123.456) == True
	assert candidate('Hello','') == True
	assert not candidate(0, 0)
	assert candidate(1.1, 2.2) == True
	assert not candidate('1', '1')
	assert not candidate(1, 1)
	assert candidate(None, 'a') == True
	assert candidate('test', '') == True
def test_check():
	check(_are_values_different)
