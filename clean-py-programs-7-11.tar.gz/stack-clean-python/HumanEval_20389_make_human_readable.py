def make_human_readable(nbytes):
    """ 
     Given a number of bytes, return a string of the form "12.2 MB" or "3.44 GB"
     which makes the number more digestible by a human reader. Everything less
     than 500 MB will be displayed in units of MB, everything above in units of GB.
     """
	### Canonical solution below ###    
    if nbytes < 500 * 1024 ** 2:
        res = '{:.2f} MB'.format(nbytes / 1024 ** 2)
    else:
        res = '{:.2f} GB'.format(nbytes / 1024 ** 3)
    return res

### Unit tests below ###
def check(candidate):
	assert candidate(1024 * 1024 * 10) == '10.00 MB'
	assert candidate(1024 ** 3 + 1024 ** 3 + 1024 ** 3) == '3.00 GB'
	assert candidate(1024 ** 3) == '1.00 GB'
	assert candidate(1000000000000) == '931.32 GB'
	assert candidate(1024 ** 2 + 1024 ** 2) == '2.00 MB'
	assert candidate(1024 ** 2 + 1) == '1.00 MB'
	assert candidate(0) == '0.00 MB'
	assert candidate(1024**3) == '1.00 GB'
	assert candidate(501 * 1024 ** 3) == '501.00 GB'
	assert candidate(1) == '0.00 MB'
	assert candidate(1024**3 * 1.2345) == '1.23 GB'
	assert candidate(1024**3 * 1.2) == '1.20 GB'
	assert candidate(500 * 1024 ** 3) == '500.00 GB'
	assert candidate(1024 * 1024) == '1.00 MB'
	assert candidate(1024 ** 5) == '1048576.00 GB'
	assert candidate(1024 * 1024 * 1024) == '1.00 GB'
	assert candidate(1024 ** 3 + 1024 ** 3) == '2.00 GB'
	assert candidate(1024 * 1024 * 1024 * 10) == '10.00 GB'
	assert candidate(1023) == '0.00 MB'
	assert candidate(1024 ** 6) == '1073741824.00 GB'
	assert candidate(1024 ** 4) == '1024.00 GB'
	assert candidate(1024**3 * 1.23) == '1.23 GB'
	assert candidate(1024**3 * 1.234) == '1.23 GB'
	assert candidate(1024 ** 2) == '1.00 MB'
	assert candidate(1024 ** 3 * 2) == '2.00 GB'
	assert candidate(1024 ** 2 * 1024) == '1.00 GB'
	assert candidate(2 * 1024 ** 3) == '2.00 GB'
	assert candidate(1000) == '0.00 MB'
def test_check():
	check(make_human_readable)
