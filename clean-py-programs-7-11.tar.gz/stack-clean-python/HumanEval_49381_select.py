def select(subject, result_if_one, result_if_zero):
    # type: (int, int, int) -> int
    """Perform a constant time(-ish) branch operation"""
    ### Canonical solution below ###
    return (~(subject - 1) & result_if_one) | ((subject - 1) & result_if_zero)


### Unit tests below ###
def check(candidate):
	assert candidate(3, 1, 0) == 1
	assert candidate(22, 0, 0) == 0
	assert candidate(10, 0, 0) == 0
	assert candidate(0, 10, 20) == 20
	assert candidate(21, 0, 0) == 0
	assert candidate(9, 0, 0) == 0
	assert candidate(-2, 1, 0) == 0
	assert candidate(23, 0, 0) == 0
	assert candidate(7, 0, 0) == 0
	assert candidate(0, 10, 100) == 100
	assert candidate(1, 1, 2) == 1
	assert candidate(1, 2, 3) == 2
	assert candidate(19, 0, 0) == 0
	assert candidate(0, 0, 0) == 0
	assert candidate(11, 0, 0) == 0
	assert candidate(1, 100, 200) == 100
	assert candidate(0, 42, 43) == 43
	assert candidate(0, 2, 3) == 3
	assert candidate(3, 0, 1) == 0
	assert candidate(24, 0, 0) == 0
	assert candidate(0, 1, 0) == 0
	assert candidate(1, 1, 0) == 1
	assert candidate(1, 10, 20) == 10
	assert candidate(20, 0, 0) == 0
	assert candidate(15, 0, 0) == 0
	assert candidate(16, 0, 0) == 0
	assert candidate(1, 0, 1) == 0
	assert candidate(2**256 - 1, 1, 0) == 1
	assert candidate(0, 100, 200) == 200
	assert candidate(6, 0, 0) == 0
	assert candidate(2, 0, 0) == 0
	assert candidate(3, 0, 0) == 0
	assert candidate(5, 0, 0) == 0
	assert candidate(17, 0, 0) == 0
	assert candidate(0, 0, 1) == 1
	assert candidate(12, 0, 0) == 0
	assert candidate(14, 0, 0) == 0
	assert candidate(1, 0, 0) == 0
	assert candidate(-1, 1, 0) == 1
	assert candidate(1, 10, 100) == 10
	assert candidate(2, 0, 1) == 1
	assert candidate(2, 1, 0) == 0
	assert candidate(18, 0, 0) == 0
	assert candidate(4, 0, 0) == 0
	assert candidate(1, 42, 43) == 42
	assert candidate(0, 1, 2) == 2
	assert candidate(13, 0, 0) == 0
	assert candidate(8, 0, 0) == 0
def test_check():
	check(select)
