def find_fragmented_packet(results):
    """
    This function searches Tcpdump's standard output and looks for packets
    that have a length larger than the MTU(hardcoded to 1500) of the device.
    """
    ### Canonical solution below ###
    for line in results.decode('utf-8').split('\n'):
        pieces = line.split(' ')
        if len(pieces) < 2:
            continue

        if pieces[-2] == 'length':
            if int(pieces[-1]) > 1500:
                return True

    return False


### Unit tests below ###
def check(candidate):
	assert not candidate(b'length 1400')
	assert candidate(b' length 1495 ') == False
	assert candidate(b'1 2 length 1500') is False
	assert candidate(b'1 2 length 1507') is True
	assert candidate(b'1 2 length 1503') is True
	assert candidate(b'1234 length 2000') == True
	assert candidate(b' length 1486 ') == False
	assert candidate(b'length 1501') == True
	assert candidate(b' length 1497 ') == False
	assert candidate(b'Length 1492') is False
	assert candidate(b' length 1496 ') == False
	assert candidate(b'Length 1491') is False
	assert candidate(b' length 1492 ') == False
	assert candidate(b'') is False
	assert candidate(b'1\n') == False
	assert candidate(b'Length 1500') is False
	assert candidate(b'123  length 512') == False
	assert candidate(b'Length 1499') is False
	assert candidate(b'Length 1485') is False
	assert candidate(b'a') == False
	assert candidate(b'length 1500 length 1500') == False
	assert candidate(b' length 1500 ') == False
	assert candidate(b'Length 1498') is False
	assert candidate(b'length 1501 length 1501')
	assert candidate(b'') == False
	assert candidate(b'Length 1483') is False
	assert candidate(b'Length 1490') is False
	assert candidate(b'1 2 length 1000\n') == False
	assert candidate(b' length 1489 ') == False
	assert candidate(b' length 1493 ') == False
	assert candidate(b' length 1485 ') == False
	assert candidate(b'1234 length 1500') == False
	assert candidate(b'1 2 3 4 length 1500') == False
	assert candidate(b' length 1234 ') == False
	assert candidate(b'1 2 length 1515') is True
	assert candidate(b'1 2 length 1504') is True
	assert candidate(b'1 2 length 1514') is True
	assert candidate(b' length 1488 ') == False
	assert candidate(b'123  length 1501') == True
	assert candidate(b'1 2 length 1512') is True
	assert candidate(b' length 1498 ') == False
	assert candidate(b'1 2 length 1509') is True
	assert candidate(b' length 1494 ') == False
	assert candidate(b' length 1490 ') == False
	assert candidate(b' length 1487 ') == False
	assert candidate(b'length 1500') == False
	assert candidate(b'1 2 length 1506') is True
	assert candidate(b'1 2 length 1511') is True
	assert candidate(b'1 2 length 1000\n1 2 length 1000\n') == False
	assert candidate(b'length 1500 length 1501') == True
	assert candidate(b'1 2 3 4 length 1501') == True
	assert candidate(b' length 1499 ') == False
	assert not candidate(b'length 1400 length 1400')
	assert candidate(b'Length 1489') is False
	assert candidate(b'Length 1495') is False
	assert candidate(b'1 2 length 1505') is True
	assert candidate(b'Length 1487') is False
	assert candidate(b'Length 1486') is False
	assert candidate(b'1 2 length 1513') is True
	assert candidate(b' length 1491 ') == False
	assert candidate(b'1 2 length 1516') is True
	assert candidate(b'Length 1497') is False
	assert candidate(b'Length 1493') is False
	assert candidate(b'Length 1484') is False
	assert candidate(b' 1234 ') == False
	assert candidate(b'1 2 3 4') == False
	assert candidate(b'1 2 length 1510') is True
	assert candidate(b'12345 length 1501') == True
	assert candidate(b'123 456 789') == False
	assert candidate(b'1 2 length 1508') is True
	assert candidate(b'Length 1496') is False
	assert candidate(b'1 2\n') == False
	assert candidate(b'12345 length 1500') == False
	assert candidate(b'Length 1494') is False
	assert candidate(b'1234 length 1501') == True
	assert candidate(b'1 2 length 1502') is True
	assert candidate(b'a b') == False
	assert candidate(b'length 1501')
	assert candidate(b'1 2 length 1501') is True
	assert candidate(b'Length 1488') is False
def test_check():
	check(find_fragmented_packet)
