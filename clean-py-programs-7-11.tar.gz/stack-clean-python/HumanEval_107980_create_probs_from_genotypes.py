def create_probs_from_genotypes(genotype):
    """ Creates probabilities from an additive genotype."""
	### Canonical solution below ###    
    if genotype == 0:
        return (1, 0, 0)

    if genotype == 1:
        return (0, 1, 0)

    if genotype == 2:
        return (0, 0, 1)

    if genotype == -1:
        # Lower than normal probabilities
        return (0.8, 0.1, 0.1)

### Unit tests below ###
def check(candidate):
	assert candidate(0) == (1, 0, 0)
	assert candidate(-1) == (0.8, 0.1, 0.1)
	assert candidate(2) == (0, 0, 1)
	assert candidate(1) == (0, 1, 0)
def test_check():
	check(create_probs_from_genotypes)
