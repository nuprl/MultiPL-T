def secure(func):
    """ Decorator for secure views. """
    ### Canonical solution below ###
    def _secure(*args, **kwargs):
        return func(*args, **kwargs)
    _secure.is_secure = True
    _secure.__name__ = func.__name__
    return _secure


### Unit tests below ###
def check(candidate):
	assert candidate(lambda: 42).is_candidate
	assert candidate(lambda: 1).is_candidate == True
	assert candidate(lambda: 1)() == 1
	assert candidate(lambda: 1)
	assert not candidate(lambda: None).__name__ =='candidate'
	assert candidate(lambda: "Hello World!").is_candidate
	assert candidate(lambda: True).is_candidate
	assert candidate(lambda x: x).is_candidate
	assert candidate(lambda: 0).is_candidate
	assert candidate(lambda x: x)
	assert candidate(lambda x: x)(1) == 1
	assert candidate(lambda: None).is_candidate
	assert candidate(lambda: 1) is not None
	assert not candidate(lambda: "Hello World!").__name__ == "candidate"
	assert candidate(lambda x: x).is_candidate == True
	assert not candidate(lambda: True).__name__ =='candidate'
	assert candidate(lambda: 1).is_candidate
def test_check():
	check(secure)
