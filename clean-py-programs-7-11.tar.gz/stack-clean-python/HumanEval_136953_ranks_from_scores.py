def ranks_from_scores(scores):
    """Return the ordering of the scores"""
    ### Canonical solution below ###
    return sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)


### Unit tests below ###
def check(candidate):
	assert candidate([100, 91, 92, 93, 94, 95, 96, 97, 98, 99]) == [0, 9, 8, 7, 6, 5, 4, 3, 2, 1]
	assert candidate(list(range(5))) == [4, 3, 2, 1, 0]
	assert candidate([5, 4, 3, 2, 1]) == [0, 1, 2, 3, 4]
	assert candidate([0.75, 0.25, 0.5]) == [0, 2, 1]
	assert candidate(list(range(10))) == [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
	assert candidate([100, 100, 100, 100, 100, 100, 100, 100, 100, 100]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(list(reversed(range(100)))) == list(range(100))
	assert candidate([100, 90, 80, 70, 60, 50, 40, 30, 20, 10]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(list(range(100))) == list(range(100))[::-1]
	assert candidate([0, 1, 2, 3]) == [3, 2, 1, 0]
	assert candidate(list(reversed(range(10)))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([100, 99, 98, 97, 96, 95, 94, 93, 92, 91]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 2, 3, 4, 5]) == [4, 3, 2, 1, 0]
	assert candidate([3, 2, 1, 0]) == [0, 1, 2, 3]
def test_check():
	check(ranks_from_scores)
