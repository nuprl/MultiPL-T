def gen_rowkey(
    """ Generate a row key based on the following format with ```` as the seperator.
     
     <sport_id><league_id><match_id><market><seq><period><vendor><timestamp>,
     
     Args:
     sport_id (int): The sport ID.
     league_id (int): The league ID.
     match_id (int): The match ID.
     market (str): The abbriviated market name, e.g., `1x2`, `ah`, `ou`, `ah_1st`, `ou_1st`, etc.
     seq (int): The sequence of the odd pair if more than 1 odd pairs exist in a market.
     period (str): The abbriviated current period, e.g., 1st half (`1h`)/2nd half (`2h`) in soccer, 1st quarter/2nd quarter/... etc. in basketball.
     vendor (str): The vendor from which the odd messages originate.
     timestamp (int): The epoch timestamp of the creation time included in the original odd message.
     
     Returns:
     str: The row key corresponds to the given input prarmeters.
     """
	### Canonical solution below ###        sport_id: int,
        league_id: int,
        match_id: int,
        market: str,
        seq: int,
        period: str,
        vendor: str,
        timestamp: int) -> str:
    
    rowkey_list = [str(sport_id), str(league_id), str(match_id), market,
                   str(seq), period, vendor, str(timestamp)]
    return ":".join(rowkey_list)

### Unit tests below ###
def check(candidate):
	assert candidate(1, 2, 3, "1x2", 1, "1h", "betdaq", 1612345678) == "1:2:3:1x2:1:1h:betdaq:1612345678"
	assert candidate(1, 2, 3, "1x2", 1, "1h", "betdaq", 1614692860) == "1:2:3:1x2:1:1h:betdaq:1614692860"
	assert candidate(1, 2, 3, "1x2", 1, "1h", "odds_monkey", 1584865660) == "1:2:3:1x2:1:1h:odds_monkey:1584865660"
	assert candidate(1, 2, 3, "1x2", 4, "1h", "betdaq", 5) == "1:2:3:1x2:4:1h:betdaq:5"
	assert candidate(1, 2, 3, '1x2', 1, '1h', 'oddschecker', 1640995200) == '1:2:3:1x2:1:1h:oddschecker:1640995200'
	assert candidate(1, 2, 3, '1x2', 1, '1h', 'betdaq', 1637416823) == '1:2:3:1x2:1:1h:betdaq:1637416823'
	assert candidate(1, 2, 3, '1x2', 4, '1h', 'betdaq', 1637323612) == '1:2:3:1x2:4:1h:betdaq:1637323612'
	assert candidate(1, 1, 1, 'ah', 1, '1h', '1x2', 1) == '1:1:1:ah:1:1h:1x2:1'
	assert candidate(1, 2, 3, "1x2", 4, "1h", "abc", 5) == "1:2:3:1x2:4:1h:abc:5"
	assert candidate(1, 2, 3, '1x2', 1, '1h', 'pinnacle', 12345678) == '1:2:3:1x2:1:1h:pinnacle:12345678'
	assert candidate(1, 2, 3, '1x2', 1, '1h', 'bet365', 12345678) == '1:2:3:1x2:1:1h:bet365:12345678'
	assert candidate(1, 1, 1, 'ah', 1, '1h', '1x2', 1000000000) == '1:1:1:ah:1:1h:1x2:1000000000'
	assert candidate(1, 2, 3, "1x2", 4, "1h", "test", 1629080454) == "1:2:3:1x2:4:1h:test:1629080454"
	assert candidate(1, 2, 3, '1x2', 4, '1h', 'bet365', 1609459200) == '1:2:3:1x2:4:1h:bet365:1609459200'
	assert candidate(sport_id=8, league_id=341, match_id=2013800111, market='1x2',
                  seq=0, period='1h', vendor='pinnacle', timestamp=1620836589)!= '8:341:2013800111:1x2:0:2h:pinnacle:1620836589'
	assert candidate(1, 2, 3, "ah_2nd", 1, "1h", "betdaq", 1612345678) == "1:2:3:ah_2nd:1:1h:betdaq:1612345678"
	assert candidate(1, 1, 1, '1x2', 1, '1h', 'SportsBet', 1640995200) == '1:1:1:1x2:1:1h:SportsBet:1640995200'
	assert candidate(sport_id=1, league_id=2, match_id=3, market='ah_1st', seq=1,
                  period='1h', vendor='test', timestamp=1628306633) == '1:2:3:ah_1st:1:1h:test:1628306633'
	assert candidate(1, 2, 3, "ah", 1, "1h", "betdaq", 1612345678) == "1:2:3:ah:1:1h:betdaq:1612345678"
	assert candidate(sport_id=1, league_id=2, match_id=3, market='ah', seq=1,
                  period='1h', vendor='test', timestamp=1628306633) == '1:2:3:ah:1:1h:test:1628306633'
	assert candidate(1, 2, 3, '1x2', 1, '1h', 'test_vendor', 4567) == '1:2:3:1x2:1:1h:test_vendor:4567'
	assert candidate(1, 1, 1, 'ah', 1, '1h', '1x2', 1000000000000) == '1:1:1:ah:1:1h:1x2:1000000000000'
	assert candidate(1, 2, 3, "1x2", 1, "1h", "test_vendor", 1611120846) == "1:2:3:1x2:1:1h:test_vendor:1611120846"
	assert candidate(sport_id=8, league_id=341, match_id=2013800111, market='1x2',
                  seq=0, period='1h', vendor='pinnacle', timestamp=1620836589)!= '8:341:2013800111:1x2:0:1h:pinnacle:1620836588'
	assert candidate(100, 100, 100, "1x2", 1, "1h", "betclic", 100000000) == "100:100:100:1x2:1:1h:betclic:100000000"
	assert candidate(sport_id=8, league_id=341, match_id=2013800111, market='1x2',
                  seq=0, period='1h', vendor='pinnacle', timestamp=1620836589) == '8:341:2013800111:1x2:0:1h:pinnacle:1620836589'
	assert candidate(1, 2, 3, '1x2', 4, '1h', 'betdaq', 5) == '1:2:3:1x2:4:1h:betdaq:5'
	assert candidate(1, 1, 1, '1x2', 1, '1h', 'fake_vendor', 123) == '1:1:1:1x2:1:1h:fake_vendor:123'
	assert candidate(1, 2, 3, '1x2', 4, '1h', 'oddschecker', 5) == '1:2:3:1x2:4:1h:oddschecker:5'
	assert candidate(1, 2, 3, '1x2', 1, '1h', 'odds_portal', 12345678) == '1:2:3:1x2:1:1h:odds_portal:12345678'
	assert candidate(1, 2, 3, "ah_1st", 1, "1h", "betdaq", 1612345678) == "1:2:3:ah_1st:1:1h:betdaq:1612345678"
def test_check():
	check(gen_rowkey)
