def RPL_REHASHING(sender, receipient, message):
    """ Reply Code 382 """
    ### Canonical solution below ###
    return "<" + sender + ">: " + message


### Unit tests below ###
def check(candidate):
	assert candidate("tester", "test", "Rehashing NICKs") == "<tester>: Rehashing NICKs"
	assert candidate("Foo", "Bar", "Baz") == "<Foo>: Baz"
	assert candidate(
    "server", "test", "Rehashing") == "<server>: Rehashing"
	assert candidate("tester", None, "Rehashing NICKs") == "<tester>: Rehashing NICKs"
	assert candidate(
    "user",
    "user",
    ":REHASHING",
) == "<user>: :REHASHING"
	assert candidate("foo", "bar", "baz") == "<foo>: baz"
	assert candidate(
    "someone", "somewhere", "is rehashing") == "<someone>: is rehashing"
	assert candidate(sender='nick!user@host', receipient='nick', message='REHASHING') == '<nick!user@host>: REHASHING'
	assert candidate(sender="Foo", receipient="Foo", message="Foo") == "<Foo>: Foo"
	assert candidate(u"foo!bar@baz", u"foo", u"bar") == u"<foo!bar@baz>: bar"
	assert candidate("a", "b", "c") == "<a>: c"
	assert candidate(
    "nick!user@host",
    "nick",
    "REHASHING") == "<nick!user@host>: REHASHING"
	assert candidate(sender="test", receipient="test", message="test") == "<test>: test"
	assert candidate(sender="foo", receipient="bar", message="baz") == "<foo>: baz"
	assert candidate(sender="Foo", receipient="Bar", message="test") == "<Foo>: test"
	assert candidate(sender="Nick!<EMAIL>", receipient="NickServ", message="Rehashing") == "<Nick!<EMAIL>>: Rehashing"
	assert candidate(sender='nick', receipient='nick', message='REHASHING') == '<nick>: REHASHING'
def test_check():
	check(RPL_REHASHING)
