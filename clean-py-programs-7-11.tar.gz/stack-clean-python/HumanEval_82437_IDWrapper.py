def IDWrapper(freer):
    """
    Classes create with IDWrapper return an ID and then free it upon exit of the
    context.
    """
    ### Canonical solution below ###
    class Wrapper:
        def __init__(self, conn):
            self.conn = conn
            self.id = None

        def __enter__(self):
            self.id = self.conn.generate_id()
            return self.id

        def __exit__(self, exception_type, exception_value, traceback):
            getattr(self.conn.core, freer)(self.id)

    return Wrapper


### Unit tests below ###
def check(candidate):
	assert candidate(freer='free_bond_list')
	assert candidate(freer='free_float') is not None
	assert candidate(freer='free_atom_bond_list')
	assert candidate(freer='free_id')(None)
	assert candidate(freer='free_ring_list')
	assert candidate(freer='free_bond_valence_list')
	assert candidate(freer='free_dict') is not None
	assert candidate(freer='free_node')(None) is not None
	assert candidate(freer='free_int') is not None
	assert candidate(None).__name__ == "Wrapper", "candidate(None) has no name"
	assert candidate(lambda x: None).__name__ == 'Wrapper', 'candidate class name'
	assert candidate(freer='free_handle') is not None
	assert candidate(freer='free_object')(None).conn is None
	assert candidate(freer='free_object')
	assert candidate(freer='free_set') is not None
	assert candidate(freer='free_bond')
	assert candidate(freer='free_list') is not None
	assert candidate(freer='free_ring_bond_list')
	assert candidate(freer='free_vertex')
	assert candidate(freer="free_id")
	assert candidate(freer='free_object') is not None
	assert candidate(freer='free_id')(None).id is None
	assert candidate(freer='free_ring')
	assert candidate(freer='free_volume')
	assert candidate('free_object').__name__ == 'Wrapper'
	assert candidate(freer='free_str') is not None
	assert candidate(freer='free_object_list')
	assert candidate(freer='free_edge')
	assert candidate(freer='free_valence_list')
	assert candidate(None).__name__ == "Wrapper"
	assert candidate(freer='free_atom')
	assert candidate(freer='free_tuple') is not None
	assert candidate(freer='free_object')(None).id is None
	assert candidate(freer='free_bool') is not None
	assert candidate(freer='free_object')(None) is not None
	assert candidate(None).__name__ == 'Wrapper'
	assert candidate(freer='free_face')
	assert candidate(freer='free_atom_list')
	assert candidate(freer='free_ids')(None).id is None
def test_check():
	check(IDWrapper)
