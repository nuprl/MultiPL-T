def double_factorial(n):
    """
    Calculate n!!

    :param n: an integer
    :return: n!!
    """
    ### Canonical solution below ###
    if not isinstance(n,int): raise TypeError('n must be an int')
    product = 1
    if n%2 == 1: stop=1
    else: stop=0
    for i in range(n,stop,-2): product *= i
    return product


### Unit tests below ###
def check(candidate):
	assert candidate(-5) == 1
	assert candidate(0)==1
	assert candidate(10) == 3840
	assert candidate(3) == 3
	assert candidate(9) == 945
	assert candidate(6) == 48
	assert candidate(21)
	assert candidate(2)==2
	assert candidate(5) == 15
	assert candidate(1) == 1
	assert candidate(2) == 2
	assert candidate(-1) == 1
	assert candidate(1)==1
	assert candidate(8) == 384
	assert candidate(0) == 1
	assert candidate(4) == 8
	assert candidate(7) == 105
def test_check():
	check(double_factorial)
