def convert_to_list(value, delimiter=None):
    """Attempts to convert a string < value > to a list using the provided < delimiter >. Removes
    leading/trailing spaces before converting < value > to a list. If unsuccessful or an exception
    is encountered returns the < value > unchanged.

    Parameters:
        value (str): string to be split.
        delimiter (str): optional delimiter provided for splitting the string

    Returns:
         list: string converted to a list.
    """
    ### Canonical solution below ###
    try:
        if delimiter != None:
            return value.strip().split(delimiter)
        else:
            return value.strip().split()
    except:
        return value


### Unit tests below ###
def check(candidate):
	assert candidate('abc, def', ', ') == ['abc', 'def']
	assert candidate(" a,b ", delimiter=",") == ["a","b"]
	assert candidate(None) == None
	assert candidate('a,b c,d') == ['a,b','c,d']
	assert candidate("a b c") == ["a", "b", "c"]
	assert candidate("a b", delimiter=" ") == ["a", "b"]
	assert candidate("a, b, c", delimiter="&") == ["a, b, c"]
	assert candidate("1") == ["1"]
	assert candidate(" a b ") == ["a","b"]
	assert candidate(" a,b ") == ["a,b"]
	assert candidate("a b c", " ") == ["a", "b", "c"]
	assert candidate(" ") == []
	assert candidate(1.1) == 1.1
	assert candidate("a;b;c", ";") == ["a", "b", "c"]
	assert candidate('  None  ', delimiter=' ') == ['None']
	assert candidate("foo, bar", ", ") == ["foo", "bar"]
	assert candidate('') == []
	assert candidate('a,b', delimiter=',') == ['a', 'b']
	assert candidate("1") == ['1']
	assert candidate("a,b") == ['a,b']
	assert candidate('abc, def ghi', ', ') == ['abc', 'def ghi']
	assert candidate(" a b c ", delimiter=",") == ["a b c"]
	assert candidate('1,2,3', ',') == ['1', '2', '3']
	assert candidate('a,b') == ['a,b']
	assert candidate("abc") == ["abc"]
	assert candidate("a, b, c", delimiter=", ") == ['a', 'b', 'c']
	assert candidate('abc') == ['abc']
	assert candidate("a") == ["a"]
	assert candidate('a,b,c', delimiter=',') == ['a', 'b', 'c']
	assert candidate("a, b, c", delimiter="; ") == ['a, b, c']
	assert candidate('abc,def,ghi', ',') == ['abc', 'def', 'ghi']
	assert candidate('test') == ['test']
	assert candidate(" a b, c ", delimiter="|") == ["a b, c"]
	assert candidate("a,b,c", ",") == ["a", "b", "c"]
	assert candidate("a b") == ["a","b"]
	assert candidate('a,b', ',') == ['a','b']
	assert candidate("a\tb\tc", "\t") == ["a", "b", "c"]
	assert candidate(" a b") == ["a","b"]
	assert candidate('  ', delimiter=' ') == ['']
	assert candidate("1 2 3", delimiter=" ") == ['1','2','3']
	assert candidate("a") == ['a']
	assert candidate('one') == ['one']
	assert candidate("abc def") == ["abc", "def"]
	assert candidate('test test') == ['test', 'test']
	assert candidate(' ') == []
	assert candidate('one two') == ['one', 'two']
	assert candidate("foo bar baz") == ['foo', 'bar', 'baz']
	assert candidate("abc,def", ",") == ["abc", "def"]
	assert candidate("1, 2", delimiter=", ") == ['1', '2']
	assert candidate(None) is None
	assert candidate('1, 2, 3', ', ') == ['1', '2', '3']
	assert candidate(" a b c ") == ["a", "b", "c"]
	assert candidate("a b") == ['a', 'b']
	assert candidate("") == []
	assert candidate("1,2,3", ",") == ["1", "2", "3"]
	assert candidate('hello world') == ['hello', 'world']
	assert candidate('a,b', ',') == ['a', 'b']
	assert candidate(' a ') == ['a']
	assert candidate(123) == 123
	assert candidate('a b c') == ['a','b','c']
	assert candidate(1) == 1
	assert candidate('1') == ['1']
	assert candidate('1,2,3 ', delimiter=',') == ['1', '2', '3']
	assert candidate("1,2,3",",") == ['1','2','3']
	assert candidate('a') == ['a']
	assert candidate("foo") == ["foo"]
	assert candidate('abc,def ghi', ',') == ['abc', 'def ghi']
	assert candidate("foo") == ['foo']
	assert candidate("foo,bar,baz") == ['foo,bar,baz']
	assert candidate('a, b', delimiter=', ') == ['a', 'b']
	assert candidate("a, b, c", delimiter=";") == ['a, b, c']
	assert candidate('a b') == ['a', 'b']
	assert candidate("1 2 3") == ['1','2','3']
	assert candidate('one two', 1) == 'one two'
	assert candidate("1;2;3",";") == ['1','2','3']
	assert candidate('1,2,3', delimiter=',') == ['1', '2', '3']
	assert candidate("a b ") == ["a","b"]
	assert candidate(" a b c ", delimiter=" ") == ["a", "b", "c"]
	assert candidate('123') == ['123']
	assert candidate('None') == ['None']
def test_check():
	check(convert_to_list)
