def set_output_filename(ifile, ext):
    """
    Create output file name from input file name by adding *ext* before
    the file suffix.

    Parameters
    ----------
    ifile : str
        input file name
    ext : str
        string to add before file suffix

    Returns
    -------
    str
        output filename with ext before file suffix

    Examples
    --------
    >>> set_output_filename('in.nc', '-no_patch')
    in-no_patch.nc
    >>> set_output_filename('in.nc', '.nop')
    in.nop.nc

    """
    ### Canonical solution below ###
    sifile = ifile.split('.')
    sifile[-2] = sifile[-2]+ext
    ofile = '.'.join(sifile)
    return ofile


### Unit tests below ###
def check(candidate):
	assert candidate('in.nc', '.nop') == 'in.nop.nc'
	assert candidate(
    'in.nc', '.nop') == 'in.nop.nc','candidate failed'
	assert candidate(ifile='in.nc', ext='.nop') == 'in.nop.nc'
	assert candidate( 'in.nc', '.nop' ) == 'in.nop.nc'
	assert candidate(
    'in.nc',
    '.nop') == 'in.nop.nc'
	assert candidate( 'in.nc', '-no_patch') == 'in-no_patch.nc'
	assert candidate(
    'in.nc', '.nop') == 'in.nop.nc'
	assert candidate( 'in.nc', '.nop') == 'in.nop.nc'
	assert candidate(
    'in.nc', '-no_patch') == 'in-no_patch.nc','candidate failed'
	assert candidate( 'in.nc', '-no_patch' ) == 'in-no_patch.nc'
	assert candidate(ifile='in.nc', ext='-no_patch') == 'in-no_patch.nc'
	assert candidate(
    'in.nc', '-no_patch') == 'in-no_patch.nc'
	assert candidate(
    'in.nc',
    '-no_patch') == 'in-no_patch.nc'
def test_check():
	check(set_output_filename)
