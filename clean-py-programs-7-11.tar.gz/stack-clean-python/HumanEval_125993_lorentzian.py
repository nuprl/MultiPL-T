def lorentzian(x_value, amplitude, center, width):
    """ 
     Evaluate a lorentzian function with the given parameters at x_value.
     """
	### Canonical solution below ###    

    numerator = (width**2)
    denominator = (x_value - center)**2 + width**2
    return amplitude * (numerator / denominator)

### Unit tests below ###
def check(candidate):
	assert candidate(0.0, 1.0, 0.0, 1.0) == 1.0
	assert candidate(1.0, 0.0, 0.0, 1.0) == 0.0
	assert candidate(0.5, 1, 0, 0.5) == 0.5
	assert candidate(1, 1, 0, 1) == 1/2
	assert candidate(1, 1, 0, 1)!= candidate(1, 1, 1, 2)
	assert candidate(0, 0.5, 0, 1) == 0.5
	assert candidate(2, 1, 0, 0) == 0
	assert candidate(0, 1, 0, 1) == 1
	assert candidate(1, 1, 0.5, 0.5) == 0.5
	assert candidate(0, 1, 1, 0) == 0
	assert candidate(1, 1, 0, 1)!= candidate(1, 1, 0, 2)
	assert candidate(1, 1, 0, 0.5)!= 0.5
	assert candidate(10, 1, 10, 1) == 1
	assert candidate(0, 1, 0, 1) == 1.0, "Lorentzian is wrong"
	assert candidate(1, 1, 0, 0) == 0
	assert candidate(1, 1, 1, 1) == 1
	assert candidate(1.5, 0, 0, 1) == 0.0
	assert candidate(0, 1, 0, 1) == 1.0
def test_check():
	check(lorentzian)
