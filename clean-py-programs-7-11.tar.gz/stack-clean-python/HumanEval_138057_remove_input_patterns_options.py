def remove_input_patterns_options(input_pattern: str) -> str:
  """Remove options from the input pattern."""
    ### Canonical solution below ###
  no_options_pattern = input_pattern.replace('{options_}', '')
  no_options_pattern = no_options_pattern.replace('{options_str}', '').strip()
  return no_options_pattern


### Unit tests below ###
def check(candidate):
	assert candidate(
    '{input_pattern}') == '{input_pattern}'
	assert candidate(
    'test.cc{options_str}') == 'test.cc'
	assert candidate(r'a {options_} b {options_} c') == r'a  b  c'
	assert candidate(
    'path/to/file_{options_str}.txt') == 'path/to/file_.txt'
	assert candidate(
   'my_folder/my_file{options_str}_suffix{options_str}') =='my_folder/my_file_suffix'
	assert candidate('input_pattern{options_str}') == 'input_pattern'
	assert candidate(
    '$(location //path/to/dir:target{options_})') == '$(location //path/to/dir:target)'
	assert candidate(
    '/path/to/file{options_str}.txt') == '/path/to/file.txt'
	assert candidate(
    '/path/to/file{options_str}_suffix.txt') == '/path/to/file_suffix.txt'
	assert candidate(
    'input_pattern{options_}') == 'input_pattern'
	assert candidate(
    'data/wikitext-2/wikitext-2-train-all.tokens') == \
    'data/wikitext-2/wikitext-2-train-all.tokens'
	assert candidate(
    'gs://bucket/path/to/file_{options_str}{options_}') == 'gs://bucket/path/to/file_'
	assert candidate(
    'test.cc{options_str}_') == 'test.cc_'
	assert candidate(
    'inputs/abc.c{options_str} ') == 'inputs/abc.c'
	assert candidate(
    input_pattern='{options_str} {input_str} {options_str}') == '{input_str}'
	assert candidate(r'a {options_} b') == r'a  b'
	assert candidate(
    'input_pattern{options_}{options_str}') == 'input_pattern'
	assert candidate(
    'dir1/dir2/file{options_}.txt{options_str}') == 'dir1/dir2/file.txt'
	assert candidate(
  input_pattern='{options_str} {input_pattern} {options_}') == '{input_pattern}'
	assert candidate(
    'a/b/c/{options_}') == 'a/b/c/'
	assert candidate(
    'input/{options_str}') == 'input/'
	assert candidate(
  input_pattern='{options_str} {input_pattern}') == '{input_pattern}'
	assert candidate(
    '{input_pattern}{options_}') == '{input_pattern}'
	assert candidate(r'a {options_str} b {options_str} c') == r'a  b  c'
	assert candidate(
    'inputs/abc.c{options_str}  ') == 'inputs/abc.c'
	assert candidate(
    input_pattern='{input_str} {options_str}') == '{input_str}'
	assert candidate(
    'inputs/abc.c{options_str}   ') == 'inputs/abc.c'
	assert candidate(
    input_pattern='{options_str} {options_str} {input_str}') == '{input_str}'
	assert candidate(
    'dir1/dir2/file{options_}.txt') == 'dir1/dir2/file.txt'
	assert candidate('input_pattern{options_}') == 'input_pattern'
	assert candidate(
   'my_folder/my_file{options_str}_suffix{options_}') =='my_folder/my_file_suffix'
	assert candidate(
    'inputs/abc.c {options_} {options_str}') == 'inputs/abc.c'
	assert candidate(
    'gs://bucket/path/to/file_{options_str}.ext') == 'gs://bucket/path/to/file_.ext'
	assert candidate(
    'test.py {options_} {options_str}') == 'test.py'
	assert candidate(
    '{input_pattern}{options_str}{options_}') == '{input_pattern}'
	assert candidate(
    '/mnt/nfs/userspace/yzhang/projects/fairseq/data-bin/iwslt14.tokenized.de-en/valid.de') == '/mnt/nfs/userspace/yzhang/projects/fairseq/data-bin/iwslt14.tokenized.de-en/valid.de'
	assert candidate(
    '$(location //path/to/dir:target{options_str}{options_str}){options_str}') == '$(location //path/to/dir:target)'
	assert candidate(
    'gs://bucket/path/to/file_{options_str}.ext{options_str}') == 'gs://bucket/path/to/file_.ext'
	assert candidate(
    '/mnt/nfs/userspace/yzhang/projects/fairseq/data-bin/iwslt14.tokenized.de-en/valid.de{options_str}') == '/mnt/nfs/userspace/yzhang/projects/fairseq/data-bin/iwslt14.tokenized.de-en/valid.de'
	assert candidate(
    'gs://bucket/path/to/file_{options_}.ext{options_str}') == 'gs://bucket/path/to/file_.ext'
	assert candidate(
    'input/{options_}') == 'input/'
	assert candidate(
    '$(location //third_party/java_src/jgit/org.eclipse.jgit:org.eclipse.jgit.archive)') == \
    '$(location //third_party/java_src/jgit/org.eclipse.jgit:org.eclipse.jgit.archive)'
	assert candidate(
    '{options_str}{options_}') == ''
	assert candidate(
    'foo/{options_str}_bar/{options_}_baz/{options_}') == 'foo/_bar/_baz/'
	assert candidate(
    'input/input.txt') == 'input/input.txt'
	assert candidate(
   'my_folder/my_file{options_str}') =='my_folder/my_file'
	assert candidate(
    '{options_}') == ''
	assert candidate(
    'gs://bucket/path/to/file_{options_str}.ext{options_}') == 'gs://bucket/path/to/file_.ext'
	assert candidate(
    'test.py {options_str} {options_}') == 'test.py'
	assert candidate(
    'data/wikitext-2/wikitext-2-train-all.tokens{options_str}') == \
    'data/wikitext-2/wikitext-2-train-all.tokens'
	assert candidate(
    '{input_pattern}{options_str}') == '{input_pattern}'
	assert candidate(
    '/mnt/nfs/userspace/yzhang/projects/fairseq/data-bin/iwslt14.tokenized.de-en/valid.de{options_}') == '/mnt/nfs/userspace/yzhang/projects/fairseq/data-bin/iwslt14.tokenized.de-en/valid.de'
	assert candidate(
    '$(location //path/to/dir:target{options_str})') == '$(location //path/to/dir:target)'
	assert candidate(
    'path/to/file_{options_str}{options_str}.txt') == 'path/to/file_.txt'
	assert candidate(
  input_pattern='{input_pattern} {options_}') == '{input_pattern}'
	assert candidate(
    '{options_str}') == ''
	assert candidate('input_pattern') == 'input_pattern'
	assert candidate(
    '/path/to/file{options_}.txt') == '/path/to/file.txt'
	assert candidate(
    'data/wikitext-2/wikitext-2-train-all.tokens{options_}') == \
    'data/wikitext-2/wikitext-2-train-all.tokens'
	assert candidate(
    '$(location //path/to/dir:target{options_str}{options_str}){options_str}$(location //path/to/dir:target{options_str}{options_str}){options_str}') == '$(location //path/to/dir:target)$(location //path/to/dir:target)'
	assert candidate(
    'input/{options_}_input.txt') == 'input/_input.txt'
	assert candidate(
    'test.cc{options_str}_.') == 'test.cc_.'
	assert candidate(
    input_pattern='{options_str} {input_str}') == '{input_str}'
	assert candidate(
    'dir1/dir2/file.txt') == 'dir1/dir2/file.txt'
	assert candidate(r'a {options_str} b {options_} c') == r'a  b  c'
	assert candidate(
   'my_folder/my_file{options_}') =='my_folder/my_file'
	assert candidate(
    'a/b/c/{options_str}') == 'a/b/c/'
	assert candidate(
    '$(location //path/to/dir:target{options_str}{options_str}){options_}') == '$(location //path/to/dir:target)'
	assert candidate(
    '') == ''
	assert candidate(
    'input_pattern {options_str} input_pattern_2') == 'input_pattern  input_pattern_2'
	assert candidate(
    'inputs/abc.c{options_str}') == 'inputs/abc.c'
	assert candidate(
    'gs://bucket/path/to/file_{options_str}{options_str}') == 'gs://bucket/path/to/file_'
	assert candidate(
    'test.py {options_str} {options_str} {options_str}') == 'test.py'
	assert candidate(
    'foo/{options_str}_bar/{options_}_baz') == 'foo/_bar/_baz'
	assert candidate(
  input_pattern='{options_str}') == ''
	assert candidate(
  input_pattern='{input_pattern}') == '{input_pattern}'
	assert candidate(
    'inputs/abc.c{options_} {options_str}') == 'inputs/abc.c'
	assert candidate(
    'data/wikitext-2/wikitext-2-train-all.tokens{options_str} ') == \
    'data/wikitext-2/wikitext-2-train-all.tokens'
	assert candidate(r'a {options_str} b') == r'a  b'
	assert candidate(
   'my_folder/my_file{options_str}_suffix') =='my_folder/my_file_suffix'
	assert candidate(
    '{options_str}{options_}{input_pattern}') == '{input_pattern}'
	assert candidate(
    'test.cc{options_}') == 'test.cc'
	assert candidate(
    'test.py {options_} {options_str} {options_str}') == 'test.py'
	assert candidate(
    'gs://bucket/path/to/file_{options_}.ext') == 'gs://bucket/path/to/file_.ext'
	assert candidate(
    'dir1/dir2/file{options_str}.txt') == 'dir1/dir2/file.txt'
	assert candidate(r'a {options_} b {options_str} c') == r'a  b  c'
	assert candidate(
    'path/to/file.txt{options_str}') == 'path/to/file.txt'
	assert candidate(
    'test.cc') == 'test.cc'
	assert candidate(
    'a/b/c') == 'a/b/c'
	assert candidate(
    'input/{options_str}_input.txt') == 'input/_input.txt'
	assert candidate(
    'path/to/file.txt{options_}') == 'path/to/file.txt'
	assert candidate(
    'path/to/file_{options_}.txt') == 'path/to/file_.txt'
	assert candidate(
    'a') == 'a'
	assert candidate(
    'input_pattern{options_str}') == 'input_pattern'
def test_check():
	check(remove_input_patterns_options)
