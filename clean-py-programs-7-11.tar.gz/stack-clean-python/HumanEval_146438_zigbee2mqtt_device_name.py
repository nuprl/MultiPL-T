def zigbee2mqtt_device_name(topic, data, srv=None):
    """ Return the last part of the MQTT topic name."""
	### Canonical solution below ###    
    return dict(name=topic.split("/")[-1])

### Unit tests below ###
def check(candidate):
	assert candidate(
    "zigbee2mqtt/0x00158d000452311a",
    {"state": "ON", "linkquality": 12, "brightness": 100, "color": {"x": 0.412, "y": 0.414}, "color_temp": 320}) == \
    {"name": "0x00158d000452311a"}
	assert candidate(
    "zigbee2mqtt/0x00158d0001f157a2",
    {"friendly_name": "0x00158d0001f157a2"}
) == dict(name="0x00158d0001f157a2")
	assert candidate(topic="zigbee2mqtt/0x00158d00022e3a1f/temperature", data=None) == dict(name="temperature")
	assert candidate(
    "zigbee2mqtt/0x00158d0001f47168",
    {"friendly_name": "My Switch"}
)["name"] == "0x00158d0001f47168"
	assert candidate(
    "zigbee2mqtt/0x00158d0003337563", {}, "cover") == {'name': '0x00158d0003337563'}
	assert candidate(
    'zigbee2mqtt/0x00158d00025d61c4',
    {
        'friendly_name': '0x00158d00025d61c4'
    }
) == {
    'name': '0x00158d00025d61c4'
}
	assert candidate(
    "zigbee2mqtt/0x00158d0001f157a2",
    {"friendly_name": "0x00158d0001f157a2", "force_update": False}
) == dict(name="0x00158d0001f157a2")
	assert candidate(
    "zigbee2mqtt/0x00158d0001ca4182",
    None
) == dict(name="0x00158d0001ca4182")
	assert candidate(
    "homeassistant/sensor/0x00158d000207a3e5/temperature",
    {"temperature": 23.4},
) == {"name": "temperature"}
	assert candidate("zigbee2mqtt/0x00158d000273a052", None) == {
    "name": "0x00158d000273a052"
}
	assert candidate(
    "zigbee2mqtt/0x00158d0003337563", {}, "switch") == {'name': '0x00158d0003337563'}
	assert candidate(
    "zigbee2mqtt/0x00158d0001bd9699",
    {
        "state": "ON",
        "brightness": 255,
        "linkquality": 75,
        "color": {"r": 255, "g": 128, "b": 0},
    },
) == {"name": "0x00158d0001bd9699"}
	assert candidate(
    "zigbee2mqtt/0x00158d0001f157a2",
    {"friendly_name": "0x00158d0001f157a2", "force_update": True}
) == dict(name="0x00158d0001f157a2")
	assert candidate(topic="zigbee2mqtt/0x00158d00022e3a1f", data=None) == dict(name="0x00158d00022e3a1f")
	assert candidate(
    "zigbee2mqtt/0x00158d0004cf2448", None) == {
    "name": "0x00158d0004cf2448"}
	assert candidate(
    "zigbee2mqtt/0x00158d0001f47168",
    {"device": {"friendly_name": "My Switch"}}
)["name"] == "0x00158d0001f47168"
	assert candidate(
    "zigbee2mqtt/0x00158d000288d2c2",
    {"type": "device_announce", "message": {"ieeeAddr": "0x00158d000288d2c2", "friendly_name": "0x00158d000288d2c2"}}
) == {"name": "0x00158d000288d2c2"}
	assert candidate(
    "zigbee2mqtt/0x00158d0004066f80",
    {"state": "ON", "linkquality": 53, "last_seen": "2019-02-16T20:47:50+00:00"},
) == dict(name="0x00158d0004066f80")
	assert candidate(
    "zigbee2mqtt/0x00158d0002874506", {"state": "OFF"}) == {"name": "0x00158d0002874506"}
	assert candidate(
    "zigbee2mqtt/0x00158d0001f157a2",
    {"friendly_name": "0x00158d0001f157a2", "force_update": "false"}
) == dict(name="0x00158d0001f157a2")
	assert candidate(
    "zigbee2mqtt/0x00158d0003337563", {}, "sensor") == {'name': '0x00158d0003337563'}
	assert candidate(
    "zigbee2mqtt/0x00158d000302f2f0", None) == {"name": "0x00158d000302f2f0"}
	assert candidate(
    "zigbee2mqtt/0x00158d000285f00e",
    {}) == dict(name="0x00158d000285f00e")
	assert candidate(
    "zigbee2mqtt/0x00158d0001819498", {}) == {"name": "0x00158d0001819498"}
	assert candidate(
    "zigbee2mqtt/0x00158d0003337563", {}, "light") == {'name': '0x00158d0003337563'}
	assert candidate(
    "zigbee2mqtt/0x00158d00029615c9", {"state": "ON", "linkquality": 100}) == \
    {"name": "0x00158d00029615c9"}
	assert candidate(
    "zigbee2mqtt/0x00158d00023b80a6", None) == {"name": "0x00158d00023b80a6"}
	assert candidate(
    "zigbee2mqtt/0x00158d00029762e3",
    {"state": "ON", "brightness": 255}
) == {
    "name": "0x00158d00029762e3"
}
	assert candidate(
    "zigbee2mqtt/0x00158d00033f321b",
    {
        "friendly_name": "0x00158d00033f321b",
        "model": "WXKG01LM",
        "power_source": "Battery",
        "type": "zigbee.switch",
        "zha_quirks": "TS011F,WXKG01LM",
    },
) == {"name": "0x00158d00033f321b"}
	assert candidate(
    "zigbee2mqtt/0x00158d00022740e4",
    {}
) == dict(name="0x00158d00022740e4")
	assert candidate(
    "homeassistant/light/0x001788010490776d", None) == {"name": "0x001788010490776d"}
	assert candidate(
    "zigbee2mqtt/0x00158d00033f321b",
    {
        "friendly_name": "0x00158d00033f321b",
        "model": "WXKG01LM",
        "power_source": "Battery",
        "type": "zigbee.switch",
        "zha_quirks": "TS011F,WXKG01LM",
        "device": {"identifiers": ["0x00158d00033f321b"]},
    },
) == {"name": "0x00158d00033f321b"}
	assert candidate(
    "zigbee2mqtt/0x00158d0003337563", {}) == {'name': '0x00158d0003337563'}
	assert candidate(
    "zigbee2mqtt/0x00158d0003337563", {}, "climate") == {'name': '0x00158d0003337563'}
	assert candidate(
    "zigbee2mqtt/0x00158d0001a86d44",
    {"state": "ON", "linkquality": 39, "last_seen": "2019-02-15T20:01:59+00:00"}
) == {
    "name": "0x00158d0001a86d44"
}
def test_check():
	check(zigbee2mqtt_device_name)
