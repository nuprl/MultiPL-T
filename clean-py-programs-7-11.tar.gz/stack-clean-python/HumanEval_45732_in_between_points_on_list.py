def in_between_points_on_list(points_list, divisions):
    """
    This takes a list of numerical values (floats or ints) and a list of divisions of ints of (points_list) - 1. This
    method will then uses the number of sub divisions within the list of divisions to add new points to the points list
    where you have request them

    Example
    ----------
    points_list = [5, 10, 12.5]
    divisions = [1, 0]
    values = in_between_points_on_list(points_list, divisions) = [5, 7.5, 10, 12.5]

    :param points_list: List of points to be in-between
    :param divisions: list of ints that shows the number of divisions to apply between a given pair of points. Needs to
        be of length points_list - 1
    :return: List of points with added points
    """
    ### Canonical solution below ###
    points_out = []
    for index, point in enumerate(points_list):
        if index > 0 and divisions[index - 1] > 0:
            # Get the value to multiple by an index to get the subdivisions
            sub_points = (points_list[index] - points_list[index - 1]) / (divisions[index - 1] + 1)

            # multiple the sub_points values by 1, 2, N etc and add it to the previous entry into the list of points
            for ii in range(1, divisions[index - 1] + 2):
                points_out.append(points_list[index - 1] + (sub_points * ii))

        else:
            points_out.append(point)
    return points_out


### Unit tests below ###
def check(candidate):
	assert candidate(points_list=[5, 10, 12.5], divisions=[0, 1, 0]) == [5, 10, 11.25, 12.5]
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0]) == [5, 7.5, 10, 12.5], \
    "The function is not behaving as expected"
	assert candidate(points_list=[5, 10, 12.5], divisions=[0, 1]) == [5, 10, 11.25, 12.5]
	assert candidate(points_list=[1, 2, 3], divisions=[0, 0]) == [1, 2, 3]
	assert candidate(points_list=[5, 10, 12.5], divisions=[0, 0]) == [5, 10, 12.5], "Failed unit test"
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0]) == [5, 7.5, 10, 12.5], "Failed unit test"
	assert candidate(points_list=[10], divisions=[1, 0]) == [10]
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0, 0]) == [5, 7.5, 10, 12.5]
	assert candidate(points_list=[5, 10, 12.5], divisions=[0, 0]) == [5, 10, 12.5], \
    "The function is not behaving as expected"
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 1]) == [5, 7.5, 10, 11.25, 12.5], \
    "Failed unit test"
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 1]) == [5, 7.5, 10, 11.25, 12.5]
	assert candidate(points_list=[1, 5, 10], divisions=[1, 0]) == [1, 3, 5, 10]
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0, 1]) == [5, 7.5, 10, 12.5]
	assert candidate(points_list=[1, 2, 3, 4], divisions=[0, 0, 0]) == [1, 2, 3, 4]
	assert candidate(points_list=[10, 12.5], divisions=[1, 0]) == [10, 11.25, 12.5]
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0]) == [5, 7.5, 10, 12.5], \
    'candidate failed'
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0]) == [5, 7.5, 10, 12.5]
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0]) == [5, 7.5, 10, 12.5], "Test 1 Failed"
	assert candidate(points_list=[5, 10, 12.5], divisions=[0, 0]) == [5, 10, 12.5]
	assert candidate(points_list=[5, 10, 12.5], divisions=[0, 0, 0]) == [5, 10, 12.5]
	assert candidate(points_list=[5, 10, 12.5], divisions=[1, 0]) == [5, 7.5, 10, 12.5], \
    "candidate(points_list=[5, 10, 12.5], divisions=[1, 0]) failed"
def test_check():
	check(in_between_points_on_list)
