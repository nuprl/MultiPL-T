def linear_search(array, val):
    """ 
     Time Complexity: O(n)
     Space Complexity: O(1)
     
     :param array: List[int]
     :param val: int
     :return: bool
     """
	### Canonical solution below ###    
    for i in array:
        if i == val:
            return True

    return False

### Unit tests below ###
def check(candidate):
	assert candidate(array=[1, 2, 3, 4], val=5) is False
	assert candidate(array=[1, 2, 3, 4, 5], val=3) is True
	assert candidate(array=[1, 2, 3, 4, 5], val=2)
	assert candidate(list(range(10)), 9) is True
	assert not candidate(array=[1, 3, 5, 7], val=2)
	assert not candidate(array=[1, 2, 3], val=4)
	assert candidate(array=[1, 3, 5, 7], val=1)
	assert candidate(array=['a', 'b', 'c', 'd'], val='b')
	assert candidate(array=[1, 2, 3, 4, 5], val=3)
	assert not candidate(array=['a', 'b', 'c', 'd'], val='e')
	assert not candidate(array=[1, 2, 3, 4, 5], val=6)
	assert candidate([1, 2, 3], 4) is False
	assert candidate(array=[2, 4, 6, 8], val=4) is True
	assert candidate(array=[2, 1, 3], val=2)
	assert candidate(array=[1, 2, 3, 4, 5], val=1) is True
	assert candidate(list(range(10)), 5) is True
	assert not candidate(array=[1, 2, 3, 4, 5, 6], val=7)
	assert candidate(array=[], val=10) is False
	assert not candidate(array=[1, 3, 5, 7], val=8)
	assert candidate(array=[1, 2, 3, 4, 5], val=5) is True
	assert candidate(array=[1, 2, 3], val=2)
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=6) is True
	assert candidate(array=[], val=5) == False
	assert candidate(array=[], val=7) is False
	assert candidate(array=[1, 2, 3], val=4) == False
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=4)
	assert candidate(array=[1, 2, 3, 4, 5], val=5)
	assert not candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], val=0)
	assert candidate(list(range(10)), -1) is False
	assert candidate(array=[2, 3, 4, 5], val=4)
	assert candidate(array=[1, 2, 3, 4, 5], val=2) is True
	assert candidate(array=[1, 3, 5, 7], val=5)
	assert not candidate(array=[1, 3, 5, 7], val=4)
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=1)
	assert not candidate(array=[2, 1, 3], val=4)
	assert candidate(array=[1, 3, 5, 7, 9], val=5) is True
	assert candidate(array=[1, 2, 3], val=3) == True
	assert candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9], val=1)
	assert not candidate(array=[3, 1, 2], val=4)
	assert not candidate(array=[], val=4)
	assert candidate(array=[], val=0) is False
	assert candidate(array=[1, 2, 3, 4], val=2)
	assert candidate([], 1) is False
	assert not candidate(array=[1, 2, 3, 4, 5], val=10)
	assert not candidate(array=[1, 3, 5, 7], val=0)
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=3) is True
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=6)
	assert not candidate(array=[1, 2, 3, 4, 5], val=0)
	assert candidate(array=[1, 2, 3, 4], val=3)
	assert candidate(array=[2, 4, 6, 8], val=10) is False
	assert candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9], val=9)
	assert candidate(array=['a', 'b', 'c', 'd'], val='d')
	assert candidate(array=[1, 2, 3, 4, 5], val=7) is False
	assert candidate([1], 1) is True
	assert candidate(array=[1, 2, 3, 4, 5], val=6) is False
	assert candidate(array=[1, 2, 3, 4], val=2) is True
	assert candidate(array=[3, 1, 2], val=2)
	assert not candidate(array=[1, 2, 3, 4], val=5)
	assert candidate(array=[1, 3, 5, 7, 9], val=1) is True
	assert not candidate(array=[], val=0)
	assert not candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9], val=0)
	assert candidate(array=[1, 2, 3, 4, 5], val=2) == True
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=0) is False
	assert candidate(list(range(10)), 11) is False
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=1) is True
	assert candidate(array=[1, 2, 3, 4], val=3) == True
	assert candidate(array=[1, 3, 5, 7, 9], val=10) is False
	assert candidate(array=[1, 2, 3, 4, 5], val=1) == True
	assert candidate(array=[1, 2, 3, 4], val=5) == False
	assert candidate(array=[1, 3, 5, 7], val=7)
	assert candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9], val=5)
	assert candidate(array=[1, 2, 3], val=3)
	assert candidate(list(range(10)), 1) is True
	assert not candidate(array=[], val=1)
	assert candidate(array=[1, 3, 5, 7], val=3)
	assert not candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9], val=10)
	assert candidate(array=[1, 2, 3, 4], val=4)
	assert candidate(array=[1, 2, 3, 4, 5], val=1)
	assert not candidate(array=[1, 2, 3, 4, 5, 6], val=0)
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=7) is False
	assert candidate(array=[1, 2, 3, 4, 5, 6], val=3)
	assert candidate([1, 2, 3], 2) is True
	assert candidate(array=[1, 2, 3, 4, 5], val=3) == True
	assert candidate(list(range(10)), 10) is False
	assert candidate(list(), 1) is False
	assert candidate(array=[1, 2, 3, 4, 5], val=6) == False
	assert candidate(array=[1, 2, 3, 4, 5], val=4)
	assert candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], val=5)
def test_check():
	check(linear_search)
