def make_bold(text: str) -> str:
    """ Wrap input string in HTML bold tag."""
	### Canonical solution below ###    
    return f'<b>{text}</b>'

### Unit tests below ###
def check(candidate):
	assert candidate(text='hello') == '<b>hello</b>'
	assert candidate(text='quux') == '<b>quux</b>'
	assert candidate(text='strange') == '<b>strange</b>'
	assert candidate(text="a third test") == "<b>a third test</b>"
	assert candidate(text='test') == '<b>test</b>'
	assert candidate(text='foo') == '<b>foo</b>'
	assert candidate(text='qux') == '<b>qux</b>'
	assert candidate(text='baz') == '<b>baz</b>'
	assert candidate(text='my string') == '<b>my string</b>'
	assert candidate(text='another string') == '<b>another string</b>'
	assert candidate(text='candidate test') == '<b>candidate test</b>'
	assert candidate(text="Hello World") == "<b>Hello World</b>"
	assert candidate(text='') == '<b></b>'
	assert candidate(text='hello world') == '<b>hello world</b>'
	assert candidate(text='Make this bold!') == '<b>Make this bold!</b>'
	assert candidate(text='Hello World!') == '<b>Hello World!</b>'
	assert candidate(text='bolded text') == '<b>bolded text</b>'
	assert candidate(text="Hello") == "<b>Hello</b>"
	assert candidate(text='bolded') == '<b>bolded</b>'
	assert candidate(text="eggs") == "<b>eggs</b>"
	assert candidate(text="spam") == "<b>spam</b>"
	assert candidate(text='goodbye')!= '<b>hello</b>'
	assert candidate(text='make me bold') == '<b>make me bold</b>'
	assert candidate(text='world') == '<b>world</b>'
	assert candidate(text="World") == "<b>World</b>"
	assert candidate(text="test") == "<b>test</b>"
	assert candidate(text='123') == '<b>123</b>'
	assert candidate(text='another test') == '<b>another test</b>'
	assert candidate(text='xyz') == '<b>xyz</b>'
	assert candidate(text='not bolded')!= '<b>bolded</b>'
	assert candidate(text='candidate works!') == '<b>candidate works!</b>'
	assert candidate(text='test')!= '<b>text</b>'
	assert candidate(text='foo bar') == '<b>foo bar</b>'
	assert candidate(text="testing") == "<b>testing</b>"
	assert candidate(text='more bold') == '<b>more bold</b>'
	assert candidate(text='bar') == '<b>bar</b>'
	assert candidate(text='abc') == '<b>abc</b>'
	assert candidate(text="another test") == "<b>another test</b>"
def test_check():
	check(make_bold)
