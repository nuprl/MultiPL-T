def is_not_zero_divisor(var1):
	""" Check if the given input is zero."""
    ### Canonical solution below ###
	tmp = list(var1) # Is it neended?
	if tmp == ['0']:
		print("\t##Zero cannot be a divisor!")
		return False
	return True


### Unit tests below ###
def check(candidate):
	assert candidate(list("1234567"))
	assert candidate(list("1234"))
	assert candidate('-1.2') == True
	assert candidate(var1='2') == True
	assert candidate(var1= ['1']) == True
	assert candidate(var1='6') == True
	assert candidate(list('0')) == False
	assert candidate(var1='0') == False
	assert candidate('-1') == True
	assert candidate(list("123456789012345678"))
	assert candidate(var1='7') == True
	assert candidate(var1='16') == True
	assert candidate('-5.0') == True
	assert candidate(var1='15') == True
	assert candidate(var1= ['1', '0', '0', '0']) == True
	assert candidate(list("123456789012345"))
	assert candidate(list("1234567890123456"))
	assert candidate(var1= ['1', '0']) == True
	assert candidate(var1='20') == True
	assert candidate('1.2e-10') == True
	assert candidate(var1 = ['1', '2', '3']) == True
	assert candidate(var1 = ['2']) == True
	assert candidate(var1='17') == True
	assert candidate(var1='11') == True
	assert candidate('1234') == True
	assert candidate('0') == False
	assert candidate(var1='3') == True
	assert candidate(list("12345678901234"))
	assert candidate(list("1234567890123"))
	assert candidate(list("123456"))
	assert candidate(var1='13') == True
	assert candidate(list("1234567890"))
	assert candidate('1') == True
	assert candidate(var1='12') == True
	assert candidate(var1='1') == True
	assert candidate('1.2') == True
	assert candidate(list("12345678901234567"))
	assert candidate(var1='19') == True
	assert candidate(list('123')) == True
	assert candidate(var1='9') == True
	assert candidate(var1 = ['0']) == False
	assert candidate(var1= ['5', '4', '3']) == True
	assert candidate(var1= ['0']) == False
	assert candidate(var1='8') == True
	assert candidate(list("12345678901"))
	assert candidate('-1.0') == True
	assert candidate(var1='4') == True
	assert candidate(list("123456789012"))
	assert candidate(list("123"))
	assert candidate('1.0') == True
	assert candidate(var1='5') == True
	assert candidate('-5') == True
	assert candidate(var1= ['1', '0', '0']) == True
	assert candidate(list("123456789"))
	assert candidate(list("12345"))
	assert candidate(var1='18') == True
	assert candidate(list("12345678"))
	assert candidate(var1='10') == True
	assert candidate(var1='21') == True
	assert candidate(var1='14') == True
def test_check():
	check(is_not_zero_divisor)
