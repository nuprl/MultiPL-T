def check_bounds(position, limit, buffer):
    """ Check whether a co-ordinate is within a limit (including a buffer).
     
     One dimensional, and assumes the lower limit is 0 (less the buffer)."""
	### Canonical solution below ###    

    if position < 0 - buffer:
        return limit + buffer
    elif position > limit + buffer:
        return -buffer
    else:
        return position

### Unit tests below ###
def check(candidate):
	assert candidate(-25, 20, 5) == 25
	assert candidate(1, 5, 0) == 1
	assert candidate(-1, 3, 0) == 3
	assert candidate(1.0, 1, 0.1) == 1
	assert candidate(1, 2, 1) == 1
	assert candidate(1, 5, 5) == 1
	assert candidate(1, 5, 1) == 1
	assert candidate(0, 2, 2) == 0
	assert candidate(1, 5, 3) == 1
	assert candidate(110, 100, 5) == -5
	assert candidate(3, 5, 2) == 3
	assert candidate(2, 5, 0) == 2
	assert candidate(0.2, 1, 0.1) == 0.2
	assert candidate(2, 3, 0) == 2
	assert candidate(10, 10, 0) == 10
	assert candidate(10, 10, 1) == 10
	assert candidate(0.5, 1, 0.1) == 0.5
	assert candidate(10, 100, 15) == 10
	assert candidate(0, 5, 5) == 0
	assert candidate(1, 10, 1) == 1
	assert candidate(5, 10, 1) == 5
	assert candidate(1, 5, 6) == 1
	assert candidate(10, 20, 0) == 10
	assert candidate(10, 100, 5) == 10
	assert candidate(-1, 2, 0) == 2
	assert candidate(1, 1, 2) == 1
	assert candidate(0, 1, 2) == 0
	assert candidate(0, 4, 0) == 0
	assert candidate(-5, 100, 5) == -5
	assert candidate(0, 5, 2) == 0
	assert candidate(1, 2, 0) == 1
	assert candidate(5, 10, 0) == 5
	assert candidate(0, 10, 0) == 0
	assert candidate(1, 5, 4) == 1
	assert candidate(200, 100, 50) == -50
	assert candidate(5, 10, 10) == 5
	assert candidate(0, 5, 1) == 0
	assert candidate(1, 2, 2) == 1
	assert candidate(15, 10, 1) == -1
	assert candidate(0, 5, 3) == 0
	assert candidate(0, 2, 1) == 0
	assert candidate(2, 4, 0) == 2
	assert candidate(0, 5, 6) == 0
	assert candidate(50, 100, 5) == 50
	assert candidate(1, 1, 0) == 1
	assert candidate(1, 5, 2) == 1
	assert candidate(0, 1, 0.1) == 0
	assert candidate(50, 100, 50) == 50
	assert candidate(-1, 2, 2) == -1
	assert candidate(10, 20, 5) == 10
	assert candidate(0, 5, 0) == 0
	assert candidate(3, 5, 3) == 3
	assert candidate(-4, 3, 1) == 4
	assert candidate(2, 3, 1) == 2
	assert candidate(-100, 100, 50) == 150
	assert candidate(3, 5, 1) == 3
	assert candidate(1, 1, 1) == 1
	assert candidate(0, 10, 1) == 0
	assert candidate(5, 10, 5) == 5
	assert candidate(-11, 10, 0) == 10
	assert candidate(0, 5, 4) == 0
	assert candidate(0, 1, 0) == 0
	assert candidate(0, 100, 50) == 0
	assert candidate(2, 5, 2) == 2
	assert candidate(10, 100, 10) == 10
	assert candidate(30, 20, 5) == -5
	assert candidate(0, 1, 1) == 0
	assert candidate(3, 5, 0) == 3
	assert candidate(6, 4, 1) == -1
	assert candidate(-1, 1, 2) == -1
def test_check():
	check(check_bounds)
