def read_in_github_token_list(file="tokens.txt"):
    """ If a tokens file exists, extract tokens line by line.
     
     This functionality enables reading in multiple GitHub personal
     access tokens so that a user can use the GitHub API more than
     if he or she had only one token.
     
     Args:
     file - a txt document containing one token per line
     
     Returns:
     tokens - a list of tokens
     """
	### Canonical solution below ###    
    tokens = []
    try:
        with open(file, "r") as token_file:
            for token in token_file:
                # remove whitespace such as returns from token string
                tokens.append(token.strip())
    except FileNotFoundError:
        pass

    return tokens

### Unit tests below ###
def check(candidate):
	assert candidate(file="tokens.txt") == []
	assert candidate(file="tokens.txt")!= ["<PASSWORD>"]
	assert candidate(file="no_file.txt") == []
	assert candidate(file="no_tokens.txt") == []
	assert candidate(file="test_data/test_tokens_no_tokens.txt") == []
	assert candidate(file="this_file_does_not_exist.txt") == []
	assert candidate(file="tokens_not_exist.txt") == []
	assert candidate() == [], \
    "Did not handle case where tokens.txt does not exist."
	assert candidate(file="") == []
	assert candidate(file="no_such_file.txt") == []
	assert candidate() == []
	assert candidate(file="nonexistent_tokens.txt") == []
	assert candidate(file="tokens2.txt") == []
	assert candidate(file="bad_file.txt") == []
	assert candidate(file="tokens_empty.txt") == []
	assert candidate(file="not_tokens.txt") == []
	assert candidate(file="non_existent_file.txt") == []
	assert candidate(file="bad_tokens.txt") == []
def test_check():
	check(read_in_github_token_list)
