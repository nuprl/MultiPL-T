def calc_tanimoto(Na, Nb):
    """Calculates the Tanimoto similarity coefficient between two sets NA and NB."""
    ### Canonical solution below ###
    Nab = len(set(Na).intersection((set(Nb))))
    return float(Nab) / (len(Na) + len(Nb) - Nab)


### Unit tests below ###
def check(candidate):
	assert candidate(set([1, 2, 3, 4]), set([1, 2, 3, 4])) == 1
	assert candidate(set(['A']), set(['A'])) == 1
	assert candidate(set([1, 2]), set([1, 2])) == 1
	assert candidate(set(['a']), set(['a'])) == 1.0
	assert candidate(set([1,2,3]), set([1,2,3,4,5])) == 0.6
	assert candidate(set([1]), set()) == 0
	assert candidate(set([1]), set([2])) == 0
	assert candidate(set(['a']), set(['a'])) == 1
	assert candidate(set([1, 2]), set([1, 2])) == 1.0
	assert candidate(set([1, 2, 3]), set([1, 2, 3, 4])) == 0.75
	assert candidate(set(['a', 'b']), set(['b'])) == 0.5
	assert candidate(set([1, 2, 3]), set([1, 2, 3, 4, 5])) == 0.6
	assert candidate(set([1]), set([1])) == 1
	assert candidate(set([1, 2, 3]), set([1, 2])) == 0.6666666666666666
	assert candidate(set(['a', 'b', 'c']), set([])) == 0.0
	assert candidate(set([1,2,3]), set([4,5,6])) == 0
	assert candidate(set([1, 2, 3]), set([4, 5, 6])) == 0
	assert candidate(set(['a', 'b', 'c']), set(['a', 'b', 'c'])) == 1.0
	assert candidate(set([1, 2, 3]), set([])) == 0.0
	assert candidate(set([1, 2, 3]), set([2, 3, 4])) == 0.5
	assert candidate(set(['A', 'B']), set(['A', 'B'])) == 1
	assert candidate(set([1, 2, 3]), set([4, 5, 6])) == 0.0
	assert candidate(set([1, 2]), set([1])) == 0.5
	assert candidate(set(['A', 'B', 'C', 'D']), set(['A', 'B', 'C', 'D'])) == 1
	assert candidate(set([1,2,3,4]), set([1,2,3,4])) == 1.0
	assert candidate(set(['a']), set(['b'])) == 0.0
	assert candidate(set([1]), set([1, 2])) == 0.5
	assert candidate(set([1, 2, 3]), set([4, 5])) == 0
	assert candidate(set(['a']), set([])) == 0.0
	assert candidate(set(['A', 'B', 'C']), set(['A', 'B', 'C'])) == 1
	assert candidate(set(['a', 'b']), set(['c'])) == 0.0
	assert candidate({'a', 'b'}, {'a', 'b'}) == 1.0
	assert candidate(set(), set(['A'])) == 0
	assert candidate(set(['A', 'B', 'C']), set(['A', 'B', 'D'])) == 1/2
	assert candidate(set(['a', 'b', 'c']), set([])) == 0
	assert candidate(set(['a', 'b']), set(['a'])) == 0.5
	assert candidate(set([1, 2, 3]), set([4, 5])) == 0.0
	assert candidate(set([1,2,3]), set([1,2,3])) == 1
	assert candidate(set(['A']), set()) == 0
	assert candidate(set(['a', 'b', 'c']), set(['a', 'b'])) == 0.6666666666666666
	assert candidate(set(['a', 'b']), set(['a', 'b'])) == 1.0
	assert candidate(set([1, 2, 3]), set([1, 2, 3])) == 1.0
	assert candidate(set([1, 2, 3, 4, 5]), set([1, 2, 3, 4, 5])) == 1
	assert candidate(set(['a', 'b', 'c']), set(['d'])) == 0
	assert candidate(set([1, 2, 3]), set([1, 2, 3])) == 1
	assert candidate(set([1, 2, 3]), set([])) == 0
	assert candidate(set(['a', 'b', 'c']), set(['a', 'b', 'd'])) == 0.5
	assert candidate({'a', 'b'}, {'a'}) == 0.5
	assert candidate(set([1, 2, 3, 4]), set([1, 2, 3, 4, 5])) == 0.8
	assert candidate(set([1, 2]), set([3, 4])) == 0
	assert candidate(set(), set([1])) == 0
	assert candidate(set(['a', 'b', 'c']), set(['a', 'b', 'c'])) == 1
	assert candidate(set(['a', 'b', 'c']), set(['a', 'c'])) == 0.6666666666666666
	assert candidate(set([1,2,3,4,5]), set([1,2,3,4,5])) == 1
	assert candidate(set(['a', 'b', 'c']), set(['a', 'c', 'd'])) == 0.5
	assert candidate(set([1, 2]), set([1, 2, 3])) == 0.6666666666666666
	assert candidate(set(['A']), set(['B'])) == 0
	assert candidate(set(['A', 'B', 'C']), set(['B', 'C', 'D'])) == 1/2
	assert candidate(set([1,2,3,4]), set([1,2,3,4,5])) == 0.8
	assert candidate(set(['a', 'b', 'c']), set(['b', 'c', 'd'])) == 0.5
	assert candidate({'a', 'b'}, {'b'}) == 0.5
	assert candidate(set(['a', 'b', 'c']), set(['d'])) == 0.0
def test_check():
	check(calc_tanimoto)
