def get_nr_bits(ring_size: int) -> int:
    """ Get number of bits.
     
     Args:
     ring_size (int): Ring Size.
     
     Returns:
     int: Bit length.
     """
	### Canonical solution below ###    
    return (ring_size - 1).bit_length()

### Unit tests below ###
def check(candidate):
	assert candidate(12) == 4
	assert candidate(1048576) == 20
	assert candidate(16777215) == 24
	assert candidate(262143) == 18
	assert candidate(23) == 5
	assert candidate(21) == 5
	assert candidate(20) == 5
	assert candidate(4096) == 12
	assert candidate(65535) == 16
	assert candidate(2) == 1
	assert candidate(2048) == 11
	assert candidate(64) == 6
	assert candidate(17) == 5
	assert candidate(511) == 9
	assert candidate(4194303) == 22
	assert candidate(25) == 5
	assert candidate(10) == 4
	assert candidate(1024) == 10
	assert candidate(32767) == 15
	assert candidate(19) == 5
	assert candidate(131071) == 17
	assert candidate(65536) == 16
	assert candidate(5) == 3
	assert candidate(4095) == 12
	assert candidate(30) == 5
	assert candidate(9) == 4
	assert candidate(255) == 8
	assert candidate(8) == 3
	assert candidate(33) == 6
	assert candidate(29) == 5
	assert candidate(13) == 4
	assert candidate(16) == 4
	assert candidate(27) == 5
	assert candidate(7) == 3
	assert candidate(4) == 2
	assert candidate(26) == 5
	assert candidate(18) == 5
	assert candidate(8191) == 13
	assert candidate(127) == 7
	assert candidate(1) == 0
	assert candidate(63) == 6
	assert candidate(1048575) == 20
	assert candidate(14) == 4
	assert candidate(31) == 5
	assert candidate(11) == 4
	assert candidate(24) == 5
	assert candidate(28) == 5
	assert candidate(524287) == 19
	assert candidate(3) == 2
	assert candidate(32) == 5
	assert candidate(8388607) == 23
	assert candidate(1023) == 10
	assert candidate(6) == 3
	assert candidate(22) == 5
	assert candidate(100) == 7
	assert candidate(1000) == 10
	assert candidate(8192) == 13
	assert candidate(2097151) == 21
	assert candidate(16383) == 14
	assert candidate(256) == 8
	assert candidate(30)
	assert candidate(128) == 7
	assert candidate(1024*1024) == 20
	assert candidate(15) == 4
	assert candidate(2047) == 11
def test_check():
	check(get_nr_bits)
