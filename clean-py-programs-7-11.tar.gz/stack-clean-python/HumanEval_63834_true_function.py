def true_function(x):
    """$t = 5x+x^2-0.5x^3$"""
    ### Canonical solution below ###
    return (5 * x) + x**2 - (0.5 * x**3)


### Unit tests below ###
def check(candidate):
	assert candidate(0.0) == 0.0
	assert candidate(2) == 10.0
	assert candidate(0) == 0
	assert candidate(0) == 0.0
	assert candidate(2) == 10
def test_check():
	check(true_function)
