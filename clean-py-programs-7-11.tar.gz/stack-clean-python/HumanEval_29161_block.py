def block(content, lang=''):
    """ Returns a codeblock"""
	### Canonical solution below ###    
    return f"```{lang}\n{content}```"

### Unit tests below ###
def check(candidate):
	assert candidate('a', 'b') == '```b\na```'
	assert candidate('foo', 'python') == candidate('foo', 'python')
	assert candidate(1, 'python') == "```python\n1```"
	assert candidate(1) == candidate('1')
	assert candidate('foo') == candidate('foo', '')
	assert candidate('a') == candidate('a', '')
	assert candidate(1) == candidate("1")
	assert candidate('hello') == candidate('hello')
	assert candidate(content="hello", lang='c') == "```c\nhello```"
	assert candidate(None) == candidate(None, '')
	assert candidate('hello', 'py') == candidate('hello', 'py')
	assert candidate(123) == candidate("123")
	assert candidate('') == candidate('', '')
def test_check():
	check(block)
