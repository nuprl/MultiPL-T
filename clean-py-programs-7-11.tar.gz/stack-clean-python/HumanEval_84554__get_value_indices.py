def _get_value_indices(names1, names2, lookups):
    """
    >>> _get_value_indices(['foo', 'bar', 'baz'], ['foo', 'bar', 'baz'],
    ...                    ['bar', 'foo'])
    [1, 0]
    >>> _get_value_indices(['foo', 'bar', 'baz'], ['FOO', 'bar', 'baz'],
    ...                    ['bar', 'FOO'])
    [1, 0]
    >>> _get_value_indices(['foo', 'bar', 'BAZ'], ['foo', 'BAZ', 'baz'],
    ...                    ['BAZ', 'foo'])
    [2, 0]
    >>> _get_value_indices(['foo', 'bar', 'baz'], ['foo', 'bar', 'baz'],
    ...                    ['spam'])
    Traceback (most recent call last):
    ...
    KeyError: 'spam'
    """
    ### Canonical solution below ###
    positions = {name: idx for idx, name in enumerate(names2)}
    positions.update({name: idx for idx, name in enumerate(names1)})
    return [positions[name] for name in lookups]


### Unit tests below ###
def check(candidate):
	assert candidate(
    ['foo', 'bar', 'baz'],
    ['FOO', 'bar', 'baz'],
    ['bar', 'FOO']
) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'baz'],
    ['FOO', 'bar', 'baz'],
    ['bar', 'FOO'],
) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'baz'], ['foo', 'bar', 'baz'],
    ['bar', 'foo']
) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'baz'],
    ['foo', 'bar', 'baz'],
    ['bar', 'foo']) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'BAZ'],
    ['foo', 'BAZ', 'baz'],
    ['BAZ', 'foo']
) == [2, 0]
	assert candidate(
    ['foo', 'bar', 'baz'], ['FOO', 'bar', 'baz'], ['bar', 'FOO']) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'baz'],
    ['FOO', 'bar', 'baz'],
    ['bar', 'FOO']) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'BAZ'], ['foo', 'BAZ', 'baz'],
    ['BAZ', 'foo']
) == [2, 0]
	assert candidate(
    ['foo', 'bar', 'baz'], ['foo', 'bar', 'baz'], ['bar', 'foo']) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'baz'],
    ['foo', 'bar', 'baz'],
    ['bar', 'foo'],
) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'BAZ'],
    ['foo', 'BAZ', 'baz'],
    ['BAZ', 'foo'],
) == [2, 0]
	assert candidate(
    ['foo', 'bar', 'baz'], ['FOO', 'bar', 'baz'],
    ['bar', 'FOO']) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'BAZ'],
    ['foo', 'BAZ', 'baz'],
    ['BAZ', 'foo']) == [2, 0]
	assert candidate(
    ['foo', 'bar', 'BAZ'], ['foo', 'BAZ', 'baz'], ['BAZ', 'foo']) == [2, 0]
	assert candidate(
    ['foo', 'bar', 'baz'], ['FOO', 'bar', 'baz'],
    ['bar', 'FOO']
) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'baz'], ['foo', 'bar', 'baz'],
    ['bar', 'foo']) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'baz'],
    ['foo', 'bar', 'baz'],
    ['bar', 'foo']
) == [1, 0]
	assert candidate(
    ['foo', 'bar', 'BAZ'], ['foo', 'BAZ', 'baz'],
    ['BAZ', 'foo']) == [2, 0]
def test_check():
	check(_get_value_indices)
