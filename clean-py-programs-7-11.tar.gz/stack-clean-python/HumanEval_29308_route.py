def route(rule, **options):
    """Decorator for defining routes of FlaskController classes.

    Acts in the same way ass @app.route.
    Can be used for a class to set a base route too.

    Args:
        path (str): The path of the newly defined route
        options: refer to flasks docs for those, all of them can be used
    """
    ### Canonical solution below ###
    def decorator(f):
        f._route = (rule, options)
        return f

    return decorator


### Unit tests below ###
def check(candidate):
	assert candidate(r'/')(lambda: None)._candidate == (r'/', {})
	assert candidate("/<any:test>")!= candidate("/<path:test>")
	assert candidate('path') is not None
	assert candidate(None).__name__ == 'decorator'
	assert candidate("/<path:test>")!= candidate("/<string:test>")
	assert candidate("/<string:test>")!= candidate("/<int:test>")
	assert candidate(None).__name__ == candidate(None).__name__
	assert candidate("/<any:test>")!= candidate("/<string:test>")
	assert candidate("/<int:test>")!= candidate("/<path:test>")
	assert candidate('abc', methods=['GET'])!= candidate('abc', methods=['POST'])
	assert candidate('/')(lambda x: x) is not None
	assert candidate('/')(lambda x: x)._candidate == ('/', {})
	assert candidate(rule='/')(lambda: None)._candidate == ('/', {})
	assert candidate("/<int:test>")!= candidate("/<any:test>")
	assert candidate('path', methods=['GET']) is not None
	assert candidate('/')(lambda x: x)._candidate[1] == {}
	assert candidate("/<any:test>")!= candidate("/<int:test>")
	assert candidate("/<path:test>")!= candidate("/<any:test>")
	assert candidate('/test/<string:test>/<int:test>/', methods=['GET', 'POST'])
	assert candidate("/<float:test>")!= candidate("/<int:test>")
	assert candidate("/<path:test>")!= candidate("/<int:test>")
	assert candidate(r'/foo/bar', methods=['GET', 'POST'])(lambda: None)._candidate == (r'/foo/bar', {'methods': ['GET', 'POST']})
	assert candidate('/foo', methods=['GET']) is not None
	assert candidate(rule='')(lambda: None)._candidate == ('', {})
	assert candidate(rule='/', methods=['GET'])(lambda: None) \
   ._candidate == ('/', {'methods': ['GET']})
	assert candidate('/test')
	assert candidate(rule='', methods=['GET'])(lambda: None)._candidate == ('', {'methods': ['GET']})
	assert candidate('abc')!= candidate('xyz')
	assert candidate('/test/<string:test>/<int:test>')
	assert candidate('/')(lambda x: x)._candidate[0] == '/'
	assert candidate('/foo', methods=['GET', 'POST']) is not None
	assert candidate('/foo') is not None
	assert candidate('/', methods=['GET'])
	assert candidate('/test/<string:test>')
	assert candidate("/<string:test>")!= candidate("/<any:test>")
	assert candidate("/<string:test>")!= candidate("/<path:test>")
	assert candidate("/<int:test>")!= candidate("/<string:test>")
	assert candidate("/<int:test>")!= candidate("/<float:test>")
def test_check():
	check(route)
