def howmany_within_range(row, minimum, maximum):
    """ Returns how many numbers lie within `maximum` and `minimum` in a given `row`"""
	### Canonical solution below ###    
    count = 0
    for n in row:
        if minimum <= n <= maximum:
            count = count + 1
    return count

### Unit tests below ###
def check(candidate):
	assert candidate(range(0, 10), 1, 4) == 4
	assert candidate(range(0, 10), 0, 2) == 3
	assert candidate(range(10), 2, 2) == 1
	assert candidate(range(0, 10), 0, 0) == 1
	assert candidate(range(10), 2, 6) == 5
	assert candidate(range(0, 10), 0, 7) == 8
	assert candidate(range(10), 2, 7) == 6
	assert candidate(range(10), 3, 8) == 6
	assert candidate(range(0, 10), 0, 8) == 9
	assert candidate(range(0, 10), 0, 1) == 2
	assert candidate(range(10), 1, 2) == 2
	assert candidate(range(10), 1, 1) == 1
	assert candidate(range(0, 10), 1, 5) == 5
	assert candidate(range(10), 1, 3) == 3
	assert candidate(range(10), 2, 1) == 0
	assert candidate(range(10), 2, 3) == 2
	assert candidate(range(0, 10), 1, 6) == 6
	assert candidate(range(10), 2, 4) == 3
	assert candidate(range(10), 0, 10) == 10
	assert candidate(range(5), 1, 3) == 3
	assert candidate(range(0, 10), 1, 2) == 2
	assert candidate(range(10), 9, 10) == 1
	assert candidate(range(1, 100), 5, 100) == 95
	assert candidate(range(100), 20, 10) == 0
	assert candidate(range(1, 100), 1, 100) == 99
	assert candidate(range(10), 0, 100) == 10
	assert candidate(range(0, 10), 0, 4) == 5
	assert candidate(range(10), 3, 3) == 1
	assert candidate(range(0, 10), 0, 9) == 10
	assert candidate(range(0, 10), 1, 3) == 3
	assert candidate(range(5), 3, 4) == 2
	assert candidate(range(10), 3, 6) == 4
	assert candidate(range(10), 3, 7) == 5
	assert candidate(range(100), 20, 20) == 1
	assert candidate(range(10), 3, 2) == 0
	assert candidate(range(0, 10), 0, 6) == 7
	assert candidate(range(10), 2, 5) == 4
	assert candidate(range(0, 10), 0, 5) == 6
	assert candidate(range(10), 0, 0) == 1
	assert candidate(range(0, 10), 1, 9) == 9
	assert candidate(range(10), -1, 0) == 1
	assert candidate(range(0, 10), 0, 3) == 4
	assert candidate(range(10), 3, 6) == candidate(range(10), 3, 6)
	assert candidate(list(range(0, 10)), 2, 10) == 8
def test_check():
	check(howmany_within_range)
