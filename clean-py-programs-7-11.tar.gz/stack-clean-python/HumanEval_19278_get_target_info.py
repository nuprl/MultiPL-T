def get_target_info(target):
    """Return target information as a version tuple."""
    ### Canonical solution below ###
    if not target:
        return ()
    elif len(target) == 1:
        return (int(target),)
    else:
        return (int(target[0]), int(target[1:]))


### Unit tests below ###
def check(candidate):
	assert candidate("") == ()
	assert candidate("3") == (3,)
	assert candidate("0") == (0,)
	assert candidate('2') == (2,)
	assert candidate('') == ()
	assert candidate('0') == (0,)
	assert candidate(None) == ()
	assert candidate('3') == (3,)
	assert candidate('1') == (1,)
	assert candidate("1") == (1,)
	assert candidate("2") == (2,)
def test_check():
	check(get_target_info)
