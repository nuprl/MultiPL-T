def rgb_to_hex(r, g=0, b=0, a=0, alpha=False):
    """
    Returns the hexadecimal string of a color
    :param r: red channel
    :param g: green channel
    :param b: blue channel
    :param a: alpha channel
    :param alpha: if True, alpha will be used
    :return: color in a string format such as #abcdef
    """
    ### Canonical solution below ###
    if type(r) is not list:
        color = [r, g, b, a]
    else:
        color = r
    hex = "#"
    for channel in color[:(4 if alpha else 3)]:
        temp = channel if type(channel) is int else int(round(channel * 255))
        hex += f'{temp:02x}'
    return hex


### Unit tests below ###
def check(candidate):
	assert candidate(255, 255, 255) == "#ffffff"
	assert candidate([148, 0, 211]) == "#9400d3"
	assert candidate(0, 0.5, 0, 1) == '#008000'
	assert candidate([10, 20, 30, 1], alpha=True) == "#0a141e01"
	assert candidate(1.0, 1.0, 1.0) == '#ffffff'
	assert candidate(148, 0, 211) == "#9400d3"
	assert candidate(0) == '#000000'
	assert candidate(0.75, 0.75, 0.75) == '#bfbfbf'
	assert candidate(0, 0, 0, 0, True) == '#00000000'
	assert candidate(100, 200, 255) == '#64c8ff'
	assert candidate([0.0, 0.0, 0.0]) == '#000000'
	assert candidate([100, 200, 255, 0.5], alpha=False) == '#64c8ff'
	assert candidate([0, 0, 0]) == '#000000'
	assert candidate(0, 0, 0, alpha=True) == "#00000000", "RGBA (0, 0, 0, 0) is black"
	assert candidate(148, 0, 211) == '#9400d3'
	assert candidate([1.0, 1.0, 0.0]) == '#ffff00'
	assert candidate(255, 255, 255, alpha=True) == '#ffffff00'
	assert candidate([255, 255, 255]) == '#ffffff'
	assert candidate(0.4, 0.4, 0.4) == '#666666'
	assert candidate([128, 128, 128]) == '#808080'
	assert candidate(0, 0.5, 0.5, 1) == '#008080'
	assert candidate([0, 0, 0]) == "#000000", "[0, 0, 0] should be #000000"
	assert candidate(0) == "#000000"
	assert candidate(0.5, 0.5, 0, 1) == '#808000'
	assert candidate(0.5, 0.5, 0.5) == '#808080'
	assert candidate(0.5, 0.5, 0.5) == "#808080", "RGB (0.5, 0.5, 0.5) is gray"
	assert candidate(255, 128, 0) == "#ff8000"
	assert candidate(0, 0, 0, 0) == "#000000"
	assert candidate([1, 2, 3]) == "#010203"
	assert candidate(1.0, 0.0, 0.0) == '#ff0000'
	assert candidate(0.0, 1.0, 0.0) == '#00ff00'
	assert candidate(255, 255, 255, 255, True) == '#ffffffff'
	assert candidate(0, 0, 0, alpha=True) == "#00000000", "0, 0, 0, 0 should be #00000000"
	assert candidate(128, 128, 128, 0.5, alpha=True) == '#80808080'
	assert candidate(0.5, 0, 0, 1) == '#800000'
	assert candidate([10, 20, 30, 0.5], alpha=True) == "#0a141e80"
	assert candidate(10, 20, 30) == "#0a141e"
	assert candidate(0, 0, 0) == '#000000'
	assert candidate(0.0, 0.0, 0.0) == '#000000'
	assert candidate(10, 20, 30, alpha=True) == "#0a141e00"
	assert candidate(0, 0, 0) == "#000000", "0, 0, 0 should be #000000"
	assert candidate(0, 0, 0, alpha=True) == "#00000000"
	assert candidate(0, 0, 0) == "#000000"
	assert candidate(0.1, 0.2, 0.3) == '#1a334c'
	assert candidate([100, 200, 255]) == '#64c8ff'
	assert candidate([255, 255, 255]) == "#ffffff"
	assert candidate([255, 128, 0]) == "#ff8000"
	assert candidate(1, 1, 1) == '#010101'
	assert candidate(1, 1, 1) == "#010101"
	assert candidate([1, 1, 1]) == '#010101'
	assert candidate(0, 0, 0, 0.5) == "#000000"
	assert candidate(0, 0, 0.5, 1) == '#000080'
	assert candidate([0.1, 0.2]) == '#1a33'
	assert candidate(0, 0.75, 0.75) == "#00bfbf"
	assert candidate(0, 0, 0, 1) == "#000000"
	assert candidate([10, 20, 30]) == "#0a141e"
	assert candidate(0.5, 0.5, 0) == '#808000'
	assert candidate([0.1, 0.2, 0.3]) == '#1a334c'
	assert candidate(255, 0, 0) == '#ff0000'
	assert candidate(0, 0, 0, alpha=True) == '#00000000'
	assert candidate(0, 0, 0) == "#000000", "RGB (0, 0, 0) is black"
	assert candidate([0.4, 0.4, 0.4, 1.0]) == '#666666'
	assert candidate(128, 128, 128) == '#808080'
	assert candidate(0, 0, 0, 0.5, alpha=True) == '#00000080'
	assert candidate(1, 2, 3) == "#010203"
	assert candidate(255, 255, 255) == '#ffffff'
	assert candidate([0.5, 0.5, 0.5]) == '#808080'
	assert candidate(1.0, 1.0, 0.0) == '#ffff00'
	assert candidate([0.4, 0.4, 0.4]) == '#666666'
	assert candidate([0, 0, 0]) == "#000000"
	assert candidate(0.0, 0.0, 1.0) == '#0000ff'
	assert candidate(0, 0) == '#000000'
	assert candidate([0.1]) == '#1a'
	assert candidate([255, 128, 0, 1.0], alpha=True) == "#ff8000ff"
def test_check():
	check(rgb_to_hex)
