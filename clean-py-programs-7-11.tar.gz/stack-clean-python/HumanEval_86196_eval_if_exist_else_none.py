def eval_if_exist_else_none(name, global_symbol_table):
    """ 
     Args:
     name([str]): Expression passed into `eval`.
     local_symbol_table(dict): Specified from `globals()`. DO NOT use `locals()`,
     because all STATIC_CONVERT_VAR_SHAPE_SUFFIX vars is
     declared with keyword `global`.
     
     Returns:
     Return the variable if found in global_symbol_table else None.
     """
	### Canonical solution below ###    
    try:
        return eval(name, global_symbol_table)
    except:
        return None

### Unit tests below ###
def check(candidate):
	assert candidate("1", {}) == 1
	assert candidate("a", {"b": 1}) == None
	assert candidate(
    "name", {"name1": 1}) is None, "candidate failed."
	assert candidate("not_exist", globals()) is None
	assert candidate(
    "a.b.c = 2",
    {"a": 1}
) == None
	assert candidate(
    "123",
    {"a": 123}
) == 123
	assert candidate(
    "TEST_VAR_NAME_2",
    {
        "TEST_VAR_NAME_1": 100,
    }
) is None
	assert candidate('b', {'a': 1, 'b': 2}) == 2
	assert candidate(
    "a",
    {"a": 123}
) == 123
	assert candidate(
    "var_3", {"var_1": 1, "var_2": 2}) is None
	assert candidate("a + b", {"a": 1, "b": 2, "c": 3, "d": 4}) == 3
	assert candidate('None', {}) is None
	assert candidate(
    "b",
    {"a": 123}
) == None
	assert candidate('a + b', {'a': 1, 'b': 2}) == 3
	assert candidate(
    'a',
    {'a': 1, 'b': 2}
) == 1
	assert candidate('len(STATIC_CONVERT_VAR_SHAPE_SUFFIX)', locals()) is None
	assert candidate(
    "var2", {"var1": 1, "var2": 2, "var3": 3, "var4": 4}) == 2
	assert candidate('a + b', {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}) == 3
	assert candidate('[]', {'None': None}) == []
	assert candidate("a+b", {"a": 1, "b": 2}) == 3
	assert candidate("a", {"a": 1, "b": 2}) == 1
	assert candidate('a + b', {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == 3
	assert candidate(
    "1 + 2",
    {
        "x": 1,
        "y": 2,
        "z": 3,
    }
) == 3
	assert candidate("a", {"a": 1}) == 1
	assert candidate(None, globals()) == None
	assert candidate(
    "1",
    {
        "x": 1,
        "y": 2,
        "z": 3,
    }
) == 1
	assert candidate(
    "x + y + z",
    {}
) is None
	assert candidate("not_exist_name", globals()) is None
	assert candidate(
    'tf.ones([1, 2])',
    locals()) is None
	assert candidate('1', {'a': 1}) == 1
	assert candidate('None', globals()) is None
	assert candidate(None, None) is None
	assert candidate("1+2+3", globals()) == 6
	assert candidate(
    'STATIC_CONVERT_VAR_SHAPE_SUFFIX_not_exist',
    globals()
) is None
	assert candidate(
    "STATIC_CONVERT_VAR_SHAPE_SUFFIX_1", globals()) is None
	assert candidate(
    'a = 10',
    {}
) == None
	assert candidate('a + b', {'a': 1, 'b': 2, 'c': 3}) == 3
	assert candidate(
    'a',
    {'a': 1}
) == 1
	assert candidate("a+b+c", {"a": 1, "b": 2}) == None
	assert candidate(
    "x + y + z",
    {
        "x": 1,
        "y": 2,
    }
) is None
	assert candidate("a + b", {"a": 1, "b": 2, "c": 3}) == 3
	assert candidate("1+2+3+4+5+6+7", globals()) == 28
	assert candidate("1+2+3+4+5+6+7+8+9+10+11", globals()) == 66
	assert candidate(
    "x + y",
    {
        "x": 1,
        "y": 2,
        "z": 3,
    }
) == 3
	assert candidate(
    "STATIC_CONVERT_VAR_SHAPE_SUFFIX_NOT_EXIST",
    {
        "STATIC_CONVERT_VAR_SHAPE_SUFFIX": "static_convert_var_shape_suffix",
        "STATIC_CONVERT_VAR_SHAPE_SUFFIX_NOT_EXIST": "static_convert_var_shape_suffix_not_exist"
    }
) == "static_convert_var_shape_suffix_not_exist"
	assert candidate(
    "name", {"name": 1}) == 1, "candidate failed."
	assert candidate(None, {}) is None
	assert candidate('a', {'a': 1}) == 1
	assert candidate(
    "TEST_VAR_NAME_1",
    {
        "TEST_VAR_NAME_1": 100,
    }
) == 100
	assert candidate("1", {"1": 1}) == 1
	assert candidate(
    "STATIC_CONVERT_VAR_SHAPE_SUFFIX",
    {
        "STATIC_CONVERT_VAR_SHAPE_SUFFIX": "static_convert_var_shape_suffix",
        "STATIC_CONVERT_VAR_SHAPE_SUFFIX_NOT_EXIST": "static_convert_var_shape_suffix_not_exist"
    }
) == "static_convert_var_shape_suffix"
	assert candidate(
    "conv1.weight_fake", globals()) is None
	assert candidate(
    "x + y + z",
    {
        "x": 1,
        "y": 2,
        "z": 3,
    }
) == 6
	assert candidate(
    "a",
    {"a": 1, "b": 2}
) == 1
	assert candidate(
    'torch.Size([2, 3])',
    {}
) is None
	assert candidate("1+2+3+4+5+6", globals()) == 21
	assert candidate(
    "var4", {"var1": 1, "var2": 2, "var3": 3, "var4": 4}) == 4
	assert candidate('a + b', {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == 3
	assert candidate(
    "conv1.weight_fake", locals()) is None
	assert candidate('None', locals()) is None
	assert candidate(
    "Static_convert_var_shape_suffix_not_exist", globals()) == None
	assert candidate("1+1", globals()) == 2
	assert candidate(
    'a',
    globals()
) == None
	assert candidate(None, None) == None
	assert candidate("a+b+c", {"a": 1, "b": 2, "c": 3}) == 6
	assert candidate("1+2+3+4+5", globals()) == 15
	assert candidate(
    "a.b.c",
    {"a": 1, "b": 2}
) is None
	assert candidate(
    "var_2", {"var_1": 1, "var_2": 2}) == 2
	assert candidate("1", globals()) == 1
	assert candidate("1+2+3+4+5+6+7+8+9", globals()) == 45
	assert candidate("1+2", globals()) == 3
	assert candidate(
    "var_1", {"var_1": 1, "var_2": 2}) == 1
	assert candidate("a + b", {"a": 1, "b": 2}) == 3
	assert candidate(
    "var1", {"var1": 1, "var2": 2, "var3": 3, "var4": 4}) == 1
	assert candidate("1+2+3+4", globals()) == 10
	assert candidate('[]', {'None': None, '[]': []}) == []
	assert candidate("1+2+3+4+5+6+7+8", globals()) == 36
	assert candidate(
    "var5", {"var1": 1, "var2": 2, "var3": 3, "var4": 4}) == None
	assert candidate(
    "STATIC_CONVERT_VAR_SHAPE_SUFFIX",
    {
        "STATIC_CONVERT_VAR_SHAPE_SUFFIX": "static_convert_var_shape_suffix"
    }
) == "static_convert_var_shape_suffix"
	assert candidate("1+2+3+4+5+6+7+8+9+10", globals()) == 55
	assert candidate(
    "var3", {"var1": 1, "var2": 2, "var3": 3, "var4": 4}) == 3
	assert candidate('a', {'a': 1, 'b': 2}) == 1
	assert candidate(None, {}) == None
def test_check():
	check(eval_if_exist_else_none)
