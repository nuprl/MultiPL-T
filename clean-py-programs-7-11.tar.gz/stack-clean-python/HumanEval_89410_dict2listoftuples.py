def dict2listoftuples(py_dict: dict) -> list:
    """ Convert a single python dictionary into a list of tuples.
     
     :param: py_dict: a single python dictionary
     """
	### Canonical solution below ###    
    return [(k, v) for k, v in py_dict.items()]

### Unit tests below ###
def check(candidate):
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3, "d": 4}) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate(py_dict={"a": 1}) == [("a", 1)]
	assert candidate(py_dict={}) == []
	assert candidate(py_dict = {'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
	assert candidate(py_dict = {'c': 3, 'd': 4}) == [('c', 3), ('d', 4)]
	assert candidate(
    {"a": 1, "b": 2, "c": 3}
) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(
    {"a": 1, "b": 2}
) == [('a', 1), ('b', 2)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3}) == [
    ("a", 1), ("b", 2), ("c", 3)]
	assert candidate(py_dict = {'e': 5, 'f': 6}) == [('e', 5), ('f', 6)]
	assert candidate(dict(a=1, b=2, c=3, d=4)) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate(
    {"a": 1}
) == [('a', 1)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}) == [("a", 1), ("b", 2), ("c", 3), ("d", 4), ("e", 5)]
	assert candidate(dict(c=3, d=4)) == [('c', 3), ('d', 4)]
	assert candidate(
    {'a': 1, 'b': 2}) == [('a', 1), ('b', 2)], "candidate() failed"
	assert candidate(py_dict = {"a": 1, "b": 2, "c": 3}) == [("a", 1), ("b", 2), ("c", 3)]
	assert candidate(py_dict={'x': '1', 'y': '2', 'z': '3'}) == [('x', '1'), ('y', '2'), ('z', '3')]
	assert candidate(py_dict={'a': 1, 'b': 2, 'c': 3}) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(py_dict={'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5), ('f', 6)]
	assert candidate(py_dict={'a':1,'b':2}) == [('a',1), ('b',2)]
	assert candidate(
    {}
) == []
	assert candidate(
    {"a": 1, "b": 2, "c": 3, "d": 4}
) == [("a", 1), ("b", 2), ("c", 3), ("d", 4)]
	assert candidate(
    {"a": 1, "b": 2, "c": 3}
) == [("a", 1), ("b", 2), ("c", 3)]
	assert candidate(py_dict={'a': 1, 'b': 2, 'c': 3, 'd': 4}) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3}) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(
    {'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
	assert candidate(py_dict={"a": 1, "b": 2}) == [('a', 1), ('b', 2)]
	assert candidate(py_dict=dict(a=1, b=2)) == [('a', 1), ('b', 2)]
	assert candidate(py_dict={"a": 1, "b": 2}) == [("a", 1), ("b", 2)]
	assert candidate(
    {'a': 1}) == [('a', 1)]
	assert candidate(py_dict={'a': 1}) == [('a', 1)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3, "d": 4}) == [
    ("a", 1), ("b", 2), ("c", 3), ("d", 4)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3, "d": 4}) == [("a", 1), ("b", 2), ("c", 3), ("d", 4)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5), ('f', 6)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3}) == [("a", 1), ("b", 2), ("c", 3)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5)]
	assert candidate(py_dict={'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(
    {
        "key1": 1,
        "key2": 2,
        "key3": 3,
    }
) == [("key1", 1), ("key2", 2), ("key3", 3)]
	assert candidate(dict(a=1, b=2, c=3)) == [("a", 1), ("b", 2), ("c", 3)]
	assert candidate(py_dict={"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7}) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5), ('f', 6), ('g', 7)]
	assert candidate(py_dict={'a':1,'b':2,'c':3}) == [('a',1), ('b',2), ('c',3)]
	assert candidate(py_dict={'a': '1', 'b': '2', 'c': '3'}) == [('a', '1'), ('b', '2'), ('c', '3')]
	assert candidate(py_dict={1: 2, 3: 4}) == [(1, 2), (3, 4)]
	assert candidate(dict(a=1, b=2, c=3)) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(py_dict={'a':1}) == [('a',1)]
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5)]
	assert candidate(py_dict={'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5)]
	assert candidate(py_dict={"c": 3, "d": 4}) == [("c", 3), ("d", 4)]
	assert candidate(dict(a=1, b=2)) == [('a', 1), ('b', 2)]
def test_check():
	check(dict2listoftuples)
