def _get_regular_G_name(starname):
    """Convert a G name to its regular form.

    Args:
        starname (str):
    """
    ### Canonical solution below ###

    starname = starname.strip()
    if starname[0]=='G' and not starname[1].isalpha():
        starname = 'G '+starname[1:].strip()
    else:
        return None

    if starname[-1].isalpha():
        comp = starname[-1]
        starname = starname[0:-1].strip()+' '+comp
    else:
        comp = None

    # parse 'G 064-012' to 'G 64-12'
    g = starname.split()
    k = g[1].split('-')
    s = str(int(k[0]))+'-'+str(int(k[1]))
    if comp==None:
        starname = 'G '+s
    else:
        starname = 'G '+s+' '+comp

    return starname


### Unit tests below ###
def check(candidate):
	assert candidate('G 064-012 I') == 'G 64-12 I'
	assert candidate('G 064-012 C') == 'G 64-12 C'
	assert candidate('G 64-12 A')=='G 64-12 A'
	assert candidate('G 0-0 a ') == 'G 0-0 a'
	assert candidate('G 064-012 D') == 'G 64-12 D'
	assert candidate('G 64-12b ') == 'G 64-12 b'
	assert candidate('G 1234-56 C ')=='G 1234-56 C'
	assert candidate('G 064-12 B') == 'G 64-12 B'
	assert candidate(starname='G 064-012a')=='G 64-12 a'
	assert candidate('G 64-012 b') == 'G 64-12 b'
	assert candidate('G 64-12 b')=='G 64-12 b'
	assert candidate('G 64-012 B') == 'G 64-12 B'
	assert candidate('G 64-12b')=='G 64-12 b'
	assert candidate('G 064-012 C')=='G 64-12 C'
	assert candidate('G 064-012 ')=='G 64-12'
	assert candidate('G 064-012b')=='G 64-12 b'
	assert candidate('G 64-012 A') == 'G 64-12 A'
	assert candidate('G 064-012B') == 'G 64-12 B'
	assert candidate('G 01-02') == 'G 1-2'
	assert candidate('G 1-2')=='G 1-2'
	assert candidate('G 1234-56 C')=='G 1234-56 C'
	assert candidate(starname='G 064-012 b')=='G 64-12 b'
	assert candidate('G 64-12b') == 'G 64-12 b'
	assert candidate('G 064-012 A')=='G 64-12 A'
	assert candidate('G 64-012  A') == 'G 64-12 A'
	assert candidate('G 64-12 C') == 'G 64-12 C'
	assert candidate('G064-012') == 'G 64-12'
	assert candidate('G 64-12 C ') == 'G 64-12 C'
	assert candidate('G 64-012') == 'G 64-12'
	assert candidate('G 64-12 ') == 'G 64-12'
	assert candidate('G 012-34 C')=='G 12-34 C'
	assert candidate('G 1-2 B')=='G 1-2 B'
	assert candidate('G 064-012A')=='G 64-12 A'
	assert candidate('G 064-012') == 'G 64-12'
	assert candidate('G 064-012A') == 'G 64-12 A'
	assert candidate('G 64-012 c ') == 'G 64-12 c'
	assert candidate('G 1-2-3') == 'G 1-2'
	assert candidate('G 64-12C') == 'G 64-12 C'
	assert candidate('G 1-2B') == 'G 1-2 B'
	assert candidate('G 64-12 A ')=='G 64-12 A'
	assert candidate('G 0-0 ') == 'G 0-0'
	assert candidate('G 0-1 ') == 'G 0-1'
	assert candidate('G 064-012 J') == 'G 64-12 J'
	assert candidate('G 064-012C') == 'G 64-12 C'
	assert candidate('G 64-12A ') == 'G 64-12 A'
	assert candidate(starname='G 64-12')=='G 64-12'
	assert candidate('G 012-34 C ')=='G 12-34 C'
	assert candidate('G064-012')=='G 64-12'
	assert candidate('G 64-12') == 'G 64-12'
	assert candidate('G 064-012 F') == 'G 64-12 F'
	assert candidate('G 0-1 A') == 'G 0-1 A'
	assert candidate('G 64-12B') == 'G 64-12 B'
	assert candidate('G 64-12-A')=='G 64-12 A'
	assert candidate('G 064-012')=='G 64-12'
	assert candidate('G 0-0') == 'G 0-0'
	assert candidate('G 64-12 B') == 'G 64-12 B'
	assert candidate('G 64-12 a') == 'G 64-12 a'
	assert candidate('G 0-1') == 'G 0-1'
	assert candidate('G 064-0121')=='G 64-121'
	assert candidate('G 064-12 A ') == 'G 64-12 A'
	assert candidate('G 0-0 a') == 'G 0-0 a'
	assert candidate('G 064-12 ') == 'G 64-12'
	assert candidate(starname='G 64-12a')=='G 64-12 a'
	assert candidate('G 64-12 b ') == 'G 64-12 b'
	assert candidate('G 064-12 A') == 'G 64-12 A'
	assert candidate('G 64-012 C') == 'G 64-12 C'
	assert candidate('G 064-12') == 'G 64-12'
	assert candidate('G 064-012  A') == 'G 64-12 A'
	assert candidate('G 64-12 b') == 'G 64-12 b'
	assert candidate('G 064-012 B') == 'G 64-12 B'
	assert candidate('G 064-012 b')=='G 64-12 b'
	assert candidate('G 064-012 E') == 'G 64-12 E'
	assert candidate('G 64-12  A') == 'G 64-12 A'
	assert candidate(starname='G 064-012c')=='G 64-12 c'
	assert candidate('G 1-2B ')=='G 1-2 B'
	assert candidate('G 064-012 H') == 'G 64-12 H'
	assert candidate(starname='G 64-12 b')=='G 64-12 b'
	assert candidate(starname='G 64-12c')=='G 64-12 c'
	assert candidate('G 64-12 A') == 'G 64-12 A'
	assert candidate(starname='G 064-012')=='G 64-12'
	assert candidate('G 64-12-A ')=='G 64-12 A'
	assert candidate('G 64-12 B')=='G 64-12 B'
	assert candidate('G 0-0 A') == 'G 0-0 A'
	assert candidate(starname='G 064-012b')=='G 64-12 b'
	assert candidate('G 064-012B ') == 'G 64-12 B'
	assert candidate(starname='G 64-12b')=='G 64-12 b'
	assert candidate('G 064-012 A') == 'G 64-12 A'
	assert candidate('G 064-012A ') == 'G 64-12 A'
	assert candidate('G 64-12 B ') == 'G 64-12 B'
	assert candidate('G 01-02-03') == 'G 1-2'
	assert candidate('G 064-012 B')=='G 64-12 B'
	assert candidate('G 64-12A') == 'G 64-12 A'
	assert candidate('G 64-12 B ')=='G 64-12 B'
	assert candidate('G064-012 ') == 'G 64-12'
	assert candidate('G 1234-56')=='G 1234-56'
	assert candidate('G 064-012 b') == 'G 64-12 b'
	assert candidate('G 64-012')=='G 64-12'
	assert candidate('G 064-012 G') == 'G 64-12 G'
	assert candidate('G 64-12A')=='G 64-12 A'
	assert candidate('G 064-012 K') == 'G 64-12 K'
	assert candidate('G 64-012 c') == 'G 64-12 c'
	assert candidate( 'G 064-012') == 'G 64-12'
	assert candidate('G 64-012 b ') == 'G 64-12 b'
	assert candidate( 'G 064-012 B') == 'G 64-12 B'
	assert candidate('G 64-12 a ') == 'G 64-12 a'
	assert candidate('G 064-012 a') == 'G 64-12 a'
	assert candidate('G 1-2 B ')=='G 1-2 B'
	assert candidate('G 12-34')=='G 12-34'
	assert candidate('G 1-2') == 'G 1-2'
	assert candidate('G 012-34')=='G 12-34'
	assert candidate('G 1-2B')=='G 1-2 B'
	assert candidate('G 64-12 A ') == 'G 64-12 A'
	assert candidate('G 1234-56 ')=='G 1234-56'
	assert candidate('G 64-12')=='G 64-12'
	assert candidate('G 064-012 ') == 'G 64-12'
	assert candidate('G 0-1 A ') == 'G 0-1 A'
	assert candidate('G 1-2 B') == 'G 1-2 B'
	assert candidate('G 064-12  A') == 'G 64-12 A'
def test_check():
	check(_get_regular_G_name)
