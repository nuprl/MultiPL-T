def crp_fractional_hierarchical_three(a, d, N, p0):
    """ Fractional approximate inference in a three-level
     hierarchy."""
	### Canonical solution below ###  
  cw2 = 0 # bottom
  tw2 = 0
  tw1 = 0 # middle
  tw0 = 0 # top
  for i in range(N):
    p1 = (tw1 - d*tw0 + (a + d*tw0)*p0)/(tw1 + a)
    p2 = (tw2 - d*tw1 + (a + d*tw1)*p1)/(tw2 + a)
    f2 = (a + d * tw2)*p2/((a + d*tw2)*p2 + cw2 - tw2*d)
    f1 = (a + d * tw1)*p1/((a + d*tw1)*p1 + tw2 - tw1*d) * f2
    f0 = (a + d * tw0)*p0/((a + d*tw0)*p0 + tw1 - tw0*d) * f1
    tw2 += f2
    tw1 += f1
    tw0 += f0
    cw2 += 1
  return tw2, tw1, tw0

### Unit tests below ###
def check(candidate):
	assert candidate(1, 1, 10000, 0.999) == (10000, 10000, 10000)
	assert candidate(1, 1, 10, 0.75) == (10, 10, 10)
	assert candidate(1, 1, 1, 0.9) == (1, 1, 1)
	assert candidate(1, 1, 1, 0.25) == (1, 1, 1)
	assert candidate(1, 1, 1, 0.75) == (1, 1, 1)
	assert candidate(1, 1, 10, 1) == (10, 10, 10)
	assert candidate(1, 1, 1, 0.1) == (1, 1, 1)
	assert candidate(1, 1, 10, 0.5) == (10, 10, 10)
	assert candidate(2, 1, 10, 0.5) == (10, 10, 10)
	assert candidate(1, 1, 1, 1) == (1, 1, 1)
	assert candidate(1, 1, 1, 0.5) == (1, 1, 1)
	assert candidate(1, 1, 100, 0.5) == (100, 100, 100)
def test_check():
	check(crp_fractional_hierarchical_three)
