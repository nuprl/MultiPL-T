def truncate_float(number, length):
    """ Truncate float numbers, up to the number specified
     in length that must be an integer"""
	### Canonical solution below ###    

    number = number * pow(10, length)
    number = int(number)
    number = float(number)
    number /= pow(10, length)
    return number

### Unit tests below ###
def check(candidate):
	assert candidate(12.345, 1) == 12.3
	assert candidate(12.3456789, 3) == 12.345
	assert candidate(2.1234567, 7) == 2.1234567
	assert candidate(2.123456789, 5) == 2.12345
	assert candidate(12345678.9012, 2) == 12345678.90
	assert candidate(123.456, -7) == 0.0
	assert candidate(1.2345678, 0) == 1.0
	assert candidate(3.141592653589793, 33) == 3.141592653589793
	assert candidate(0.1234, 7) == 0.1234000
	assert candidate(1.23456789, 3) == 1.234
	assert candidate(3.141592653589793, 32) == 3.141592653589793
	assert candidate(3.141592653589793, 34) == 3.141592653589793
	assert candidate(2.0, 1) == 2.0
	assert candidate(123.45678, 2) == 123.45
	assert candidate(123.456, -5) == 0.0
	assert candidate(1.1234, 2) == 1.12
	assert candidate(2.1234567, 1) == 2.1
	assert candidate(1.555555, 3) == 1.555
	assert candidate(0.123456789, 3) == 0.123
	assert candidate(1234567890.1234, 2) == 1234567890.12
	assert candidate(0, 3) == 0.000
	assert candidate(1.2345678, 2) == 1.23
	assert candidate(2.1234567, 2) == 2.12
	assert candidate(0.1234, 5) == 0.12340
	assert candidate(12.345, 2) == 12.34
	assert candidate(123.456, -6) == 0.0
	assert candidate(123.4567, 4) == 123.4567
	assert candidate(123456789.0123, 2) == 123456789.01
	assert candidate(3.141592653589793, 1) == 3.1
	assert candidate(3.141592653589793, 30) == 3.141592653589793
	assert candidate(0, 4) == 0.0000
	assert candidate(1234.5678, -3) == 1000.0
	assert candidate(1.555555, 6) == 1.555555
	assert candidate(2.123456789, 10) == 2.123456789
	assert candidate(3.14159, 0) == 3.0
	assert candidate(1.23456, 0) == 1, "candidate(1.23456, 0) should return 1"
	assert candidate(1.23456789012345, 12) == 1.234567890123
	assert candidate(12345678901.2345, 2) == 12345678901.23
	assert candidate(1.2345, 1) == 1.2
	assert candidate(1.234, 2) == 1.23
	assert candidate(0.1234, 3) == 0.123
	assert candidate(1.23456, 2) == 1.23, "candidate(1.23456, 2) should return 1.23"
	assert candidate(1.23456789, 1) == 1.2
	assert candidate(1234.5678, -4) == 0.0
	assert candidate(2.123456789, 6) == 2.123456
	assert candidate(1.555555, 2) == 1.55
	assert candidate(0.1234, 4) == 0.1234
	assert candidate(1.234, 1) == 1.2
	assert candidate(123.456, 0) == 123.0
	assert candidate(1.2345, 2) == 1.23
	assert candidate(123.456, 3) == 123.456
	assert candidate(123.4567, 0) == 123
	assert candidate(1.23456789012345, 2) == 1.23
	assert candidate(123.456, -3) == 0.0
	assert candidate(1.1234, 3) == 1.123
	assert candidate(3.141592653589793, 5) == 3.14159
	assert candidate(1.555555, 5) == 1.55555
	assert candidate(123.456, -1) == 120.0
	assert candidate(2.123456789, 9) == 2.123456789
	assert candidate(-1.555555, 2) == -1.55
	assert candidate(1.2345678, 3) == 1.234
	assert candidate(1234.5678, -2) == 1200.0
	assert candidate(1.23456789012345, 8) == 1.23456789
	assert candidate(3.141592653589793, 31) == 3.141592653589793
	assert candidate(1234567890, 2) == 1234567890
	assert candidate(2.1234567, 3) == 2.123
	assert candidate(12.345, 3) == 12.345
	assert candidate(123456.78, 2) == 123456.78
	assert candidate(1.234, 0) == 1.0
	assert candidate(1.2345, 4) == 1.2345
	assert candidate(1.23456, 3) == 1.234
	assert candidate(1.1234, 1) == 1.1
	assert candidate(0, 2) == 0.00
	assert candidate(-1.555555, 5) == -1.55555
	assert candidate(1234.5678, -1) == 1230.0
	assert candidate(123.456789, 3) == 123.456
	assert candidate(1.23456789012345, 10) == 1.2345678901
	assert candidate(1.23456789012345, 16) == 1.23456789012345
	assert candidate(0.1234567890123456789, 2) == 0.12
	assert candidate(123.456789, 0) == 123.0
	assert candidate(1.23456, 1) == 1.2
	assert candidate(2.123456789, 7) == 2.1234567
	assert candidate(-1.555555, 3) == -1.555
	assert candidate(1.2345678, 1) == 1.2
	assert candidate(0.1234, 2) == 0.12
	assert candidate(123.456789, 2) == 123.45
	assert candidate(123.456, 4) == 123.4560
	assert candidate(2.123456789, 11) == 2.123456789
	assert candidate(2.123456789, 4) == 2.1234
	assert candidate(1.2345, 3) == 1.234
	assert candidate(1234567.8, 2) == 1234567.8
	assert candidate(12.3456789, 2) == 12.34
	assert candidate(1234567.8901, 2) == 1234567.89
	assert candidate(12345678, 2) == 12345678
	assert candidate(-1.555555, 6) == -1.555555
	assert candidate(12.3456789, 1) == 12.3
	assert candidate(1.23456789, 0) == 1.0
	assert candidate(-1.555555, 4) == -1.5555
	assert candidate(12.345, 4) == 12.345
	assert candidate(123.123, 3) == 123.123
	assert candidate(12345.678, 2) == 12345.67
	assert candidate(123.456789, -5) == 0.0
	assert candidate(123.123, 2) == 123.12
	assert candidate(1.23456, 2) == 1.23
	assert candidate(123456789, 2) == 123456789
	assert candidate(1.555555, 4) == 1.5555
	assert candidate(0, 6) == 0.000000
	assert candidate(1.2345, 0) == 1.0
	assert candidate(123.456, 2) == 123.45
	assert candidate(0, 5) == 0.00000
	assert candidate(1.23456789, 2) == 1.23
	assert candidate(1.123, 2) == 1.12
	assert candidate(2.123456789, 8) == 2.12345678
	assert candidate(3.14159, 5) == 3.14159
	assert candidate(1.1234, 4) == 1.1234
	assert candidate(0.123456789, 2) == 0.12
	assert candidate(12.345678, 2) == 12.34
	assert candidate(2.123456789, 3) == 2.123
	assert candidate(123.456, -4) == 0.0
	assert candidate(123.456, -2) == 100.0
	assert candidate(1.23456, 0) == 1.
	assert candidate(0.1234, 6) == 0.123400
	assert candidate(3.14159, 1) == 3.1
	assert candidate(123.456, 1) == 123.4
	assert candidate(3.14159265359, 5) == 3.14159
	assert candidate(12.3456789, 0) == 12.0
	assert candidate(1234.5678, 2) == 1234.56
def test_check():
	check(truncate_float)
