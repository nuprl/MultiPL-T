def trianglePoints(x, z, h, w):
    """
    Takes the geometric parameters of the triangle and returns the position of the 3 points of the triagles. Format : [[x1, y1, z1], [x2, y2, z2], [x3, y3, z3]]
    """
    ### Canonical solution below ###
    P1 = [x, 0, z+h]
    P2 = [x, w/2, z]
    P3 = [x, -w/2, z]
    return [P1, P2, P3]


### Unit tests below ###
def check(candidate):
	assert candidate(1, 1, 1, 2) == [[1, 0, 2], [1, 1, 1], [1, -1, 1]], "candidate(1, 1, 1, 2) should be [[1, 0, 2], [1, 1, 1], [1, -1, 1]]"
	assert candidate(2, 1, 2, 1) == [[2.0, 0.0, 3.0], [2.0, 0.5, 1.0], [2.0, -0.5, 1.0]]
	assert candidate(10, 10, 10, 10) == [[10, 0, 20], [10, 5, 10], [10, -5, 10]]
	assert candidate(1, 1, 1, 1) == [[1.0, 0.0, 2.0], [1.0, 0.5, 1.0], [1.0, -0.5, 1.0]], "candidate(1, 1, 1, 1) doit retourner [[1.0, 0.0, 2.0], [1.0, 0.5, 1.0], [1.0, -0.5, 1.0]]"
	assert candidate(0, 0, 1, 2) == [[0, 0, 1], [0, 1, 0], [0, -1, 0]], "Error"
	assert candidate(1, 0, 1, 2) == [[1, 0, 1], [1, 1, 0], [1, -1, 0]]
	assert candidate(1, 2, 3, 4) == [[1, 0, 5], [1, 2, 2], [1, -2, 2]], "candidate(1, 2, 3, 4) should be [[1, 0, 5], [1, 2, 2], [1, -2, 2]]"
	assert candidate(1, 0, 1, 1) == [[1, 0, 1], [1, 0.5, 0], [1, -0.5, 0]], "Should be [[1, 0, 1], [1, 0.5, 0], [1, -0.5, 0]]"
	assert candidate(0, 0, 10, 5) == [[0, 0, 10], [0, 2.5, 0], [0, -2.5, 0]]
	assert candidate(2, 4, 0, 0) == [[2, 0, 4], [2, 0, 4], [2, 0, 4]]
	assert candidate(1, 1, 1, 1) == [[1, 0, 2], [1, 0.5, 1], [1, -0.5, 1]], "candidate(1, 1, 1, 1) should be [[1, 0, 2], [1, 0.5, 1], [1, -0.5, 1]]"
	assert candidate(0, 0, 1, 0) == [[0, 0, 1], [0, 0, 0], [0, 0, 0]]
	assert candidate(1, 1, 1, 2) == [[1.0, 0.0, 2.0], [1.0, 1.0, 1.0], [1.0, -1.0, 1.0]]
	assert candidate(0, 0, 10, 10) == [[0, 0, 10], [0, 5, 0], [0, -5, 0]]
	assert candidate(1, 1, 10, 20) == [[1, 0, 11], [1, 10, 1], [1, -10, 1]]
	assert candidate(0, 0, 1, 2) == [[0, 0, 1], [0, 1, 0], [0, -1, 0]]
	assert candidate(0, 0, 3, 1) == [[0, 0, 3], [0, 0.5, 0], [0, -0.5, 0]], "Error"
	assert candidate(0, 0, 10, 20) == [[0, 0, 10], [0, 10, 0], [0, -10, 0]]
	assert candidate(0, 0, 1, 0.5) == [[0, 0, 1], [0, 0.25, 0], [0, -0.25, 0]]
	assert candidate(0, 0, 2, 2) == [[0, 0, 2], [0, 1, 0], [0, -1, 0]]
	assert candidate(2, 4, 0, 1) == [[2, 0, 4], [2, 0.5, 4], [2, -0.5, 4]]
	assert candidate(0, 0, 1, 2) == [[0, 0, 1], [0, 1, 0], [0, -1, 0]], "candidate(0, 0, 1, 2) should be [[0, 0, 1], [0, 1, 0], [0, -1, 0]]"
	assert candidate(0, 0, 2, 2) == [[0, 0, 2], [0, 1, 0], [0, -1, 0]], "Error"
	assert candidate(-1, 0, 1, 1) == [[-1, 0, 1], [-1, 0.5, 0], [-1, -0.5, 0]]
	assert candidate(0, 0, 1, 1) == [[0, 0, 1], [0, 0.5, 0], [0, -0.5, 0]]
	assert candidate(0, 0, 2, 1) == [[0, 0, 2], [0, 0.5, 0], [0, -0.5, 0]], "Error"
	assert candidate(1, 1, 1, 1) == [[1.0, 0.0, 2.0], [1.0, 0.5, 1.0], [1.0, -0.5, 1.0]]
	assert candidate(0, 0, 1, 1) == [[0, 0, 1], [0, 0.5, 0], [0, -0.5, 0]], "Error"
	assert candidate(0, 0, 1, 2) == [[0, 0, 1], [0, 1, 0], [0, -1, 0]], "Should be [[0, 0, 1], [0, 1, 0], [0, -1, 0]]"
	assert candidate(0, 0, 1, 1) == [[0.0, 0.0, 1.0], [0.0, 0.5, 0.0], [0.0, -0.5, 0.0]], "candidate(0, 0, 1, 1) doit retourner [[0.0, 0.0, 1.0], [0.0, 0.5, 0.0], [0.0, -0.5, 0.0]]"
	assert candidate(1, 2, 3, 4) == [[1, 0, 5], [1, 2, 2], [1, -2, 2]]
	assert candidate(1, 1, 1, 1) == [[1, 0, 2], [1, 0.5, 1], [1, -0.5, 1]]
	assert candidate(0, 0, 1, 1) == [[0, 0, 1], [0, 0.5, 0], [0, -0.5, 0]], "Should be [[0, 0, 1], [0, 0.5, 0], [0, -0.5, 0]]"
	assert candidate(0, 0, 1, 1) == [[0, 0, 1], [0, 0.5, 0], [0, -0.5, 0]], "Function candidate is not working properly"
	assert candidate(2, 4, 1, 1) == [[2, 0, 5], [2, 0.5, 4], [2, -0.5, 4]]
	assert candidate(0, 0, 1, 1) == [[0, 0, 1], [0, 0.5, 0], [0, -0.5, 0]], "candidate(0, 0, 1, 1) should be [[0, 0, 1], [0, 0.5, 0], [0, -0.5, 0]]"
	assert candidate(1, 0, 1, 1) == [[1, 0, 1], [1, 0.5, 0], [1, -0.5, 0]]
def test_check():
	check(trianglePoints)
