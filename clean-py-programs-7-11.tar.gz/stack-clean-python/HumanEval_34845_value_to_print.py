def value_to_print(value, optype):
    """String of code that represents a value according to its type

    """
    ### Canonical solution below ###
    if (value is None):
        return "NULL"
    if (optype == 'numeric'):
        return value
    return u"'%s'" % value.replace("'", '\\\'')


### Unit tests below ###
def check(candidate):
	assert candidate("foo", 'geotrace') == "'foo'"
	assert candidate("123", 'numeric') == "123"
	assert candidate("a",'string') == u"'a'"
	assert candidate(u'Hello', 'text') == u"'Hello'"
	assert candidate("1''", 'text') == u"'1\\'\\''"
	assert candidate(None, "text") == "NULL"
	assert candidate('a','string') == u"'a'"
	assert candidate("1.23", 'numeric') == "1.23"
	assert candidate(None, 'numeric') == "NULL"
	assert candidate('abc', 'numeric') == 'abc'
	assert candidate('123', 'numeric') == '123'
	assert candidate("a'b",'string') == u"'a\\'b'"
	assert candidate("abc",'string') == "'abc'"
	assert candidate('123', 'text') == "'123'"
	assert candidate(u"a'b",'string') == u"'a\\'b'"
	assert candidate(None,'string') == "NULL"
	assert candidate("hello", 'text') == "'hello'"
	assert candidate("123.456", 'numeric') == "123.456"
	assert candidate("foo", 'geoshape') == "'foo'"
	assert candidate("123'", 'text') == "'123\\''"
	assert candidate("a'b", 'text') == u"'a\\'b'"
	assert candidate("some string",'string') == "'some string'"
	assert candidate('1', 'text') == u"'1'"
	assert candidate("123.456", None) == "'123.456'"
	assert candidate("foo", 'timeofday') == "'foo'"
	assert candidate("foo", 'text') == "'foo'"
	assert candidate("1'", 'text') == u"'1\\''"
	assert candidate("1.2", 'numeric') == "1.2"
	assert candidate('a\'bc','string') == "'a\\'bc'"
	assert candidate(None, 'text') == 'NULL'
	assert candidate('1', 'numeric') == "1"
	assert candidate(u"foo", "text") == u"'foo'"
	assert candidate(u"foo",'string') == "'foo'"
	assert candidate("123.4", 'numeric') == "123.4"
	assert candidate(None, 'date') == "NULL"
	assert candidate(u"a", 'numeric') == u"a"
	assert candidate('abc','string') == "'abc'"
	assert candidate(None, 'text') == "NULL"
	assert candidate('abc', 'text') == u"'abc'"
	assert candidate("123.456", 'text') == "'123.456'"
	assert candidate("foo", 'date') == "'foo'"
	assert candidate(u"foo", 'text') == "'foo'"
	assert candidate('123', 'text') == u"'123'"
	assert candidate(u"foo", 'date') == "'foo'"
	assert candidate("foo", 'json') == "'foo'"
	assert candidate(None, 'numeric') == 'NULL'
	assert candidate("a", 'numeric') == "a"
	assert candidate("foo", 'blob') == "'foo'"
	assert candidate("foo",'string') == "'foo'"
	assert candidate(u"foo", 'timeofday') == "'foo'"
	assert candidate("a", 'text') == u"'a'"
	assert candidate("foo", 'datetime') == "'foo'"
	assert candidate("a", 'text') == "'a'"
	assert candidate(u"foo", 'datetime') == "'foo'"
	assert candidate("1", 'numeric') == "1"
	assert candidate(123, 'numeric') == 123
	assert candidate("hello", 'date') == "'hello'"
	assert candidate("foo", 'geopoint') == "'foo'"
	assert candidate("foo", 'timestamp') == "'foo'"
	assert candidate(u"a", 'text') == u"'a'"
def test_check():
	check(value_to_print)
