def get_columns(filters):
    """ return columns based on filters"""
	### Canonical solution below ###	

	columns = ["Item:Link/Item:100", "Item Name::150", \
	"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]

	return columns

### Unit tests below ###
def check(candidate):
	assert candidate(None) == ["Item:Link/Item:100", "Item Name::150", "Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]
	assert candidate(filters={"docstatus": 0}) == \
	["Item:Link/Item:100", "Item Name::150", \
	"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"], \
	"candidate should return ['Item:Link/Item:100', 'Item Name::150', \
	'Description::140', 'Warehouse:Link/Warehouse:100', 'Balance Qty:Float:100']"
	assert candidate(filters={}) == ["Item:Link/Item:100", "Item Name::150", \
	"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]
	assert candidate(filters={}) == ["Item:Link/Item:100", "Item Name::150", "Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]
	assert candidate(filters={"item_code": "1"}) == ["Item:Link/Item:100", "Item Name::150", \
	"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]
	assert candidate(None) == ["Item:Link/Item:100", "Item Name::150", \
"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]
	assert candidate(None) == ["Item:Link/Item:100", "Item Name::150", \
	"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]
	assert candidate(None)
	assert candidate(filters={"warehouse": "Stores - TCP1"}) == \
	["Item:Link/Item:100", "Item Name::150", \
	"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"]
	assert candidate(filters={"docstatus": 1}) == ["Item:Link/Item:100", "Item Name::150", \
	"Description::140", "Warehouse:Link/Warehouse:100", "Balance Qty:Float:100"], "candidate failed"
	assert candidate({})
def test_check():
	check(get_columns)
