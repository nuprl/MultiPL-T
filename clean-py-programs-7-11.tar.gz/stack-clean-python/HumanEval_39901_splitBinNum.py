def splitBinNum(binNum):
    """ Split an alternate block number into latitude and longitude parts.
     
     Args:
     binNum (int): Alternative block number
     
     Returns:
     :tuple Tuple:
     
     1. (int) Latitude portion of the alternate block number.
     Example: ``614123`` => ``614`` 
     2. (int) Longitude portion of the alternate block number.
     Example: ``614123`` => ``123`` 
     """
	### Canonical solution below ###    
    latBin = int(binNum / 1000)
    longBin = binNum - (latBin * 1000)

    return (latBin, longBin)

### Unit tests below ###
def check(candidate):
	assert candidate(345678) == (345, 678)
	assert candidate(1000999) == (1000, 999)
	assert candidate(614300) == (614, 300)
	assert candidate(614750) == (614, 750)
	assert candidate(567890) == (567, 890)
	assert candidate(614250) == (614, 250)
	assert candidate(414123) == (414, 123)
	assert candidate(614400) == (614, 400)
	assert candidate(6141234) == (6141, 234)
	assert candidate(1001000) == (1001, 0)
	assert candidate(1005000) == (1005, 0)
	assert candidate(614650) == (614, 650)
	assert candidate(1003000) == (1003, 0)
	assert candidate(614850) == (614, 850)
	assert candidate(1001) == (1, 1)
	assert candidate(614700) == (614, 700)
	assert candidate(1005999) == (1005, 999)
	assert candidate(614550) == (614, 550)
	assert candidate(1004999) == (1004, 999)
	assert candidate(614350) == (614, 350)
	assert candidate(714123) == (714, 123)
	assert candidate(456789) == (456, 789)
	assert candidate(614123) == (614, 123), "candidate(614123) failed"
	assert candidate(123456) == (123, 456), "candidate(123456) failed"
	assert candidate(614123456) == (614123, 456)
	assert candidate(614123) == (614, 123)
	assert candidate(1002999) == (1002, 999)
	assert candidate(614200) == (614, 200)
	assert candidate(1234567) == (1234, 567)
	assert candidate(6141234567) == (6141234, 567)
	assert candidate(614123)!= (614, 124)
	assert candidate(614123)!= (123, 614)
	assert candidate(0) == (0, 0)
	assert candidate(512111) == (512, 111)
	assert candidate(114123) == (114, 123)
	assert candidate(1002000) == (1002, 0)
	assert candidate(1000) == (1, 0)
	assert candidate(123456) == (123, 456)
	assert candidate(101234) == (101, 234)
	assert candidate(614900) == (614, 900)
	assert candidate(1003999) == (1003, 999)
	assert candidate(12345) == (12, 345)
	assert candidate(1004000) == (1004, 0)
	assert candidate(614500) == (614, 500)
	assert candidate(1000010) == (1000, 10)
	assert candidate(614450) == (614, 450)
	assert candidate(614000) == (614, 0)
	assert candidate(1000001) == (1000, 1)
	assert candidate(890123) == (890, 123)
	assert candidate(234567) == (234, 567)
	assert candidate(614999) == (614, 999)
	assert candidate(1) == (0, 1)
	assert candidate(61412345) == (61412, 345)
	assert candidate(314123) == (314, 123)
	assert candidate(999999) == (999, 999)
	assert candidate(1000000) == (1000, 0)
	assert candidate(614600) == (614, 600)
	assert candidate(1001999) == (1001, 999)
	assert candidate(678901) == (678, 901)
	assert candidate(901234) == (901, 234)
	assert candidate(614800) == (614, 800)
def test_check():
	check(splitBinNum)
