def make2D_grid(rows, cols):
    """Returns a 2d grid filled with zeros"""
    ### Canonical solution below ###
    grid = []

    for x in range(0, cols):
        grid.append([])
        for y in range(0, rows):
            grid[x].append(0)

    return grid


### Unit tests below ###
def check(candidate):
	assert candidate(3, 3) == [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
	assert candidate(1, 0) == []
	assert candidate(1, 1) == [[0]], "candidate(1, 1) did not return the expected list"
	assert candidate(5, 5) == [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]
	assert candidate(2, 2) == [[0, 0], [0, 0]]
	assert candidate(3, 3) == [[0, 0, 0], [0, 0, 0], [0, 0, 0]], "candidate(3, 3) returns [[0, 0, 0], [0, 0, 0], [0, 0, 0]]"
	assert candidate(4, 4) == [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
	assert candidate(3, 3) == [[0, 0, 0], [0, 0, 0], [0, 0, 0]], "candidate(3, 3) returns a 3x3 grid of zeros"
	assert candidate(1, 1) == [[0]]
	assert candidate(3, 0) == []
	assert candidate(1, 1) == [[0]], "candidate(1, 1) returns [[0]]"
	assert candidate(0, 0) == []
	assert candidate(2, 2) == [[0, 0], [0, 0]], "candidate(2, 2) returns a 2x2 grid of zeros"
	assert candidate(2, -1) == []
	assert candidate(3, 3) == [[0, 0, 0],
                            [0, 0, 0],
                            [0, 0, 0]]
	assert candidate(1, 1) == [[0]], "candidate(1, 1) returns a 1x1 grid of zeros"
def test_check():
	check(make2D_grid)
