def smiles_from_folder_name(url_encoded_smiles):
    """ 
     Returns the URL encoded SMILES containing special characters as regular SMILES.
     
     Parameters
     ----------
     url_encoded_smiles : str
     A SMILES containing standard URL encoding symbols, such as %2F.
     
     Returns
     -------
     str :
     The SMILES with special characters as such.
     : <- %3A
     \\ <- %5C (here backslash)
     / <- %2F
     * <- %2A
     
     Notes
     -----
     https://www.degraeve.com/reference/urlencoding.php
     """
	### Canonical solution below ###    
    smiles = (
        url_encoded_smiles.replace("%3A", ":")
        .replace("%5C", "\\")
        .replace("%2F", "/")
        .replace("%2A", "*")
    )
    return smiles

### Unit tests below ###
def check(candidate):
	assert candidate(
    "InChI=1S/C7H8O3/c1-7(2)6-4-3-5-6/h3-5H,1-2H3%2A"
) == "InChI=1S/C7H8O3/c1-7(2)6-4-3-5-6/h3-5H,1-2H3*"
	assert candidate(
    "InChI=1S/C7H8O3/c1-7(2)6-4-3-5-6/h3-5H,1-2H3"
) == "InChI=1S/C7H8O3/c1-7(2)6-4-3-5-6/h3-5H,1-2H3"
	assert candidate(
    "C%3A%5CUsers%5Cusername%5CDocuments%5CGitHub%5C"
    "molSim%5CmolSim%5Cdatasets%5Csmiles_strings%5C"
    "zinc_250k%5Csmiles_strings_500"
) == "C:\\Users\\username\\Documents\\GitHub\\molSim\\molSim\\datasets\\smiles_strings\\zinc_250k\\smiles_strings_500"
	assert candidate(
    "COc1ccc(CC(=O)N(C)O)cc1/C(=O)N(C)O"
) == "COc1ccc(CC(=O)N(C)O)cc1/C(=O)N(C)O"
	assert candidate(
    "CC%3ACc1ccc(CC%2A)cc1"
) == "CC:Cc1ccc(CC*)cc1"
	assert candidate(
    "COc1ccc2nc(S(=O)(=O)N3CCC(O)(CC3)c3ccccc3)sc2c1"
) == "COc1ccc2nc(S(=O)(=O)N3CCC(O)(CC3)c3ccccc3)sc2c1"
def test_check():
	check(smiles_from_folder_name)
