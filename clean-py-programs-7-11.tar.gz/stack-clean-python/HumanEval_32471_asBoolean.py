def asBoolean(s):
    """ Convert a string value to a boolean value."""
	### Canonical solution below ###    
    ss = str(s).lower()
    if ss in ('yes', 'true', 'on'):
        return True
    elif ss in ('no', 'false', 'off'):
        return False
    else:
        raise ValueError("not a valid boolean value: " + repr(s))

### Unit tests below ###
def check(candidate):
	assert candidate('off') == False
	assert candidate('YES')
	assert candidate('yEs') == True
	assert candidate('TRUE') == True
	assert candidate(False) == False
	assert candidate('on')
	assert candidate('true') == True
	assert candidate('yes')
	assert candidate('false') is False
	assert candidate('True') == True
	assert candidate("TRUE")
	assert candidate('on') is True
	assert not candidate(False)
	assert candidate("FALSE") == False
	assert candidate("ON") == True
	assert candidate('True')
	assert candidate('nO') == False
	assert candidate('faLse') == False
	assert candidate("yes") == True
	assert candidate("on") == True
	assert candidate('TrUe') == True
	assert candidate("TrUe") == True
	assert candidate("true") == True
	assert candidate("no") == False
	assert candidate('Yes') == True
	assert candidate(True) == True
	assert not candidate('False')
	assert candidate("on")
	assert candidate("False") == False
	assert candidate('True') is True
	assert candidate("Yes") == True
	assert candidate("faLse") == False
	assert candidate('no') == False
	assert candidate('No') == False
	assert candidate('no') is False
	assert candidate("YES")
	assert not candidate("false")
	assert candidate('true')
	assert candidate("Yes")
	assert candidate("No") == False
	assert candidate('true') is True
	assert candidate('False') is False
	assert candidate("True")
	assert candidate('FALSE') == False
	assert candidate(False) is False
	assert candidate('yes') == True
	assert candidate('false') == False
	assert candidate("ON")
	assert candidate("YES") == True
	assert candidate(True)
	assert candidate('False') == False
	assert candidate("false") == False
	assert candidate("OFF") == False
	assert not candidate("OFF")
	assert not candidate("off")
	assert candidate("True") == True
	assert candidate('off') is False
	assert candidate("TRUE") == True
	assert candidate('yes') is True
	assert candidate('OFF') == False
	assert candidate("yes")
	assert candidate('ON') == True
	assert candidate('on') == True
	assert not candidate('no')
	assert candidate("true")
	assert candidate("off") == False
	assert candidate('TRUE')
	assert not candidate("no")
	assert candidate(True) is True
	assert not candidate("FALSE")
def test_check():
	check(asBoolean)
