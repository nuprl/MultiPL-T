def single_high_initializer(low_genome='LOW', high_genome='HIGH'):
    """ Generate a population that contains two types of genomes:
     all of the population will be 'LOW' except for one, which will
     be 'HIGH'."""
	### Canonical solution below ###    
    first = True

    def create():
        nonlocal first
        if first:
            first = False
            return high_genome
        else:
            return low_genome
    
    return create

### Unit tests below ###
def check(candidate):
	assert candidate(low_genome='LOW', high_genome='HIGH')() == 'HIGH'
	assert candidate(low_genome='a', high_genome='b')() == 'b'
	assert candidate(high_genome='H', low_genome='L')() == 'H'
	assert candidate(
    'LOW', 'HIGH')() == 'HIGH'
	assert candidate(high_genome='A')() == 'A'
	assert candidate(high_genome='HIGH')() == 'HIGH'
	assert candidate(low_genome='A', high_genome='B')() == 'B'
	assert candidate(low_genome='B', high_genome='A')() == 'A'
	assert candidate()() == 'HIGH'
	assert candidate(high_genome='A', low_genome='B')() == 'A'
	assert candidate(1, 2)() == 2
	assert candidate(low_genome='foo', high_genome='bar')() == 'bar'
	assert candidate(low_genome='LOW')() == 'HIGH'
def test_check():
	check(single_high_initializer)
