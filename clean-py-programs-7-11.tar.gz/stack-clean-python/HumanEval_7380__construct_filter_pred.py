def _construct_filter_pred(min_len, max_len=None):
    """
    Constructs a filter predicate
    Args:
        min_len (int): Min sentence length
        max_len (int): Max sentence length

    Returns:
        func
    """
    ### Canonical solution below ###
    filter_pred = lambda x: not (x[0] < min_len or x[1] < min_len)
    if max_len is not None:
        filter_pred = lambda x: not (
            x[0] < min_len or x[0] > max_len or x[1] < min_len or x[1] > max_len
        )

    return filter_pred


### Unit tests below ###
def check(candidate):
	assert not candidate(1, 100)([0, 100]), "Error in candidate(1, 100)"
	assert candidate(3)(
    (4, 5)
), "candidate(3) should return a filter for sentences of length 4 and 5"
	assert not candidate(1, 2)([2, 3])
	assert candidate(5, 10)(
    (1, 12)
) == False, "Should be False for (1, 12)"
	assert candidate(1, 2)(
    (1, 2)
)
	assert candidate(5)([10, 5])
	assert candidate(10, 20)(
    (10, 20)
) == True, "Min and Max length filter failed"
	assert not candidate(3, max_len=5)(
    (6, 4)
), "candidate(3, max_len=5) should return a filter for sentences of length 6 and 4"
	assert not candidate(1, 1)(
    (1, 2)
)
	assert not candidate(1, 1)(
    (3, 3)
), "candidate(1, 1) should return False"
	assert candidate(0)(
    (3, 4)
), "candidate(0) returns False when (3, 4) is passed"
	assert not candidate(3)(
    (1, 2)
)
	assert not candidate(1, 1)([2, 2]), "Error in candidate(1, 1)"
	assert not candidate(5)([4, 5])
	assert candidate(1, 2)(
    (1, 2)
), "candidate(1, 2) should return True"
	assert candidate(2, 4)(
    (
        5,
        5,
    )
) == False
	assert not candidate(3, 5)([6, 7])
	assert candidate(1, 2)(
    (1, 1)
)
	assert not candidate(3, 10)([10, 11])
	assert not candidate(1, 2)([3, 4])
	assert candidate(1, 1)(
    (1, 1)
)
	assert candidate(5, 10)(
    (6, 10)
), "5 <= 10 <= 10 should be True"
	assert candidate(3, 10)([3, 10])
	assert candidate(3, 5)(
    (3, 4)
), "Filter pred with min_len=3 and max_len=5 failed"
	assert not candidate(10, 20)(
    (5, 15)
)
	assert not candidate(2, 1)(
    (1, 1)
)
	assert not candidate(5, 10)([4, 4])
	assert candidate(2, 4)(
    (
        3,
        4,
    )
) == True
	assert candidate(0, 0)(
    [0, 0]
), "Filter pred should return true for any input with zero length"
	assert candidate(10, 20)(
    (10, 20)
)
	assert not candidate(10, 20)(
    (15, 25)
)
	assert candidate(5, 10)(
    (6, 1000)
) == False, "Should be False for (6, 1000)"
	assert candidate(0, 1)(
    [0, 1]
), "Filter pred should return true for any input with zero length"
	assert not candidate(0, 1)(
    (3, 4)
), "candidate(0, 1) returns True when (3, 4) is passed"
	assert candidate(1, 100)(
    [1, 100]
), "Error in candidate(1, 100)"
	assert not candidate(3, 10)([2, 3])
	assert candidate(10, 20)(
    (20, 30)
) == False, "Min and Max length filter failed"
	assert candidate(3, max_len=5)(
    (3, 3)
), "candidate(3, max_len=5) should return a filter for sentences of length 3 and 3"
	assert not candidate(1, 1)(
    [0, 1]
), "Filter pred should return false for any input with zero length"
	assert not candidate(1, 100)([101, 200]), "Error in candidate(1, 100)"
	assert candidate(5, 10)(
    (6, 10)
) == True, "Should be True for (6, 10)"
	assert not candidate(3, max_len=5)(
    (4, 6)
), "candidate(3, max_len=5) should return a filter for sentences of length 4 and 5"
	assert candidate(3, None)(
    (3, 5)
), "candidate is not working"
	assert not candidate(3, 10)([11, 12])
	assert not candidate(10)(
    (5, 5)
), "Min and max len should not be equal for a valid pair"
	assert candidate(3, 5)([4, 5])
	assert candidate(10, 20)(
    (15, 15)
)
	assert candidate(5)(
    (5, 5)
), "Min and max len should be equal for a valid pair"
	assert not candidate(10, 20)(
    (5, 5)
)
	assert candidate(1)([3, 1])
	assert not candidate(min_len=100, max_len=50)(
    (100, 150)
), "Min/max length filter is not working"
	assert not candidate(3)(
    (4, 2)
), "candidate(3) should return a filter for sentences of length 4 and 2"
	assert candidate(1)(
    [1, 2]
), "Error in candidate(1, 1)"
	assert not candidate(min_len=100, max_len=100)(
    (100, 150)
), "Min/max length filter is not working"
	assert not candidate(1, 0)(
    (1, 1)
)
	assert not candidate(4, 3)(
    (3, 5)
), "candidate is not working"
	assert not candidate(3, 5)([1, 6])
	assert candidate(5, 5)(
    (5, 5)
), "Min and max len should be equal for a valid pair"
	assert not candidate(2, 1)([1, 2])
	assert candidate(2)(
    (
        2,
        2,
    )
) == True
	assert candidate(10, 20)(
    (10, 15)
)
	assert candidate(min_len=100)(
    (100, 100)
), "Min length filter is not working"
	assert not candidate(3, 10)([1, 2])
	assert not candidate(4, None)(
    (3, 5)
), "candidate is not working"
	assert not candidate(2, 1)(
    (1, 2)
)
	assert not candidate(1, 2)([3, 3])
	assert candidate(3, max_len=5)(
    (4, 4)
), "candidate(3, max_len=5) should return a filter for sentences of length 4 and 4"
	assert not candidate(3, 5)(
    (3, 6)
), "Filter pred with min_len=3 and max_len=5 failed"
	assert candidate(10, 20)(
    (10, 20)
), "Filter predicate should return True for (10, 20)"
	assert candidate(min_len=100, max_len=150)(
    (100, 150)
), "Min/max length filter is not working"
	assert candidate(3, 10)([3, 4])
	assert candidate(3)([4, 5])
	assert candidate(5, 10)(
    (1, 2)
) == False, "Should be False for (1, 2)"
	assert candidate(3)(
    (4, 3)
), "candidate(3) should return a filter for sentences of length 4 and 3"
	assert candidate(1, 2)([1, 2])
	assert not candidate(2, 2)(
    (3, 3)
), "candidate(2, 2) should return False"
	assert not candidate(5, 10)([11, 11])
	assert not candidate(10, 20)(
    (5, 20)
), "Filter predicate should return False for (5, 20)"
	assert not candidate(1, 2)([3, 1])
	assert not candidate(1, 1)(
    (1, 2)
), "candidate(1, 1) should return False"
	assert not candidate(5, 10)([3, 11])
	assert not candidate(5, 10)([4, 5])
	assert candidate(1)(
    (1, 2)
)
	assert not candidate(6)([1, 2])
	assert not candidate(3, 5)([6, 1])
	assert not candidate(5)([4, 4])
	assert not candidate(10, 20)(
    (5, 25)
), "Filter predicate should return False for (5, 25)"
def test_check():
	check(_construct_filter_pred)
