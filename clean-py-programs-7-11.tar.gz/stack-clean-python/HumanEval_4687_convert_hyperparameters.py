def convert_hyperparameters(dict_hyperparams):
    """ Convert the hyperparameters to the format accepted by the library."""
	### Canonical solution below ###    
    hyperparams = []

    if not isinstance(dict_hyperparams, dict):
        raise TypeError('Hyperparams must be a dictionary.')

    for name, hyperparam in dict_hyperparams.items():
        hp_type = hyperparam['type']

        if hp_type == 'int':
            hp_range = hyperparam.get('range') or hyperparam.get('values')
            hp_min = int(min(hp_range))
            hp_max = int(max(hp_range))
            hyperparams.append({
                'name': name,
                'type': 'range',
                'bounds': [hp_min, hp_max]
            })

        elif hp_type == 'float':
            hp_range = hyperparam.get('range') or hyperparam.get('values')
            hp_min = float(min(hp_range))
            hp_max = float(max(hp_range))
            hyperparams.append({
                'name': name,
                'type': 'range',
                'bounds': [hp_min, hp_max]
            })

        elif hp_type == 'bool':
            hyperparams.append({
                'name': name,
                'type': 'choice',
                'bounds': [True, False]
            })

        elif hp_type == 'str':
            hp_range = hyperparam.get('range') or hyperparam.get('values')
            hyperparams.append({
                'name': name,
                'type': 'choice',
                'bounds': hp_range,
            })

    return hyperparams

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'a': {'type':'str', 'range': ['a', 'b']}
}) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b']}]
	assert candidate(
    {'activation': {'type':'str', 'values': ['relu','sigmoid']}}) == [{
        'name': 'activation',
        'type': 'choice',
        'bounds': ['relu','sigmoid']
    }]
	assert candidate({'a': {'type':'str', 'values': ['a', 'b', 'c']}}) == [{'bounds': ['a', 'b', 'c'], 'name': 'a', 'type': 'choice'}]
	assert candidate(
    {'a': {'type': 'float', 'range': [1.0, 2.0, 3.0]}
}) == [{'name': 'a', 'type': 'range', 'bounds': [1.0, 3.0]}]
	assert candidate(
    {
        'param_1': {'type': 'int', 'range': [1, 10]},
        'param_2': {'type': 'float', 'range': [0.1, 0.9]},
        'param_3': {'type': 'bool'},
        'param_4': {'type':'str', 'values': ['a', 'b', 'c']}
    }
) == [
    {'name': 'param_1', 'type': 'range', 'bounds': [1, 10]},
    {'name': 'param_2', 'type': 'range', 'bounds': [0.1, 0.9]},
    {'name': 'param_3', 'type': 'choice', 'bounds': [True, False]},
    {'name': 'param_4', 'type': 'choice', 'bounds': ['a', 'b', 'c']}
]
	assert candidate(
    {'hp_1': {'type':'str', 'values': ['a', 'b', 'c']}}
    ) == [{'name': 'hp_1', 'type': 'choice', 'bounds': ['a', 'b', 'c']}]
	assert candidate(
    {
        'a': {'type': 'int', 'range': [1, 100]},
        'b': {'type': 'float', 'range': [0, 100]},
        'c': {'type': 'bool'},
        'd': {'type':'str', 'values': ['a', 'b', 'c']}
    }
) == [
    {
        'name': 'a',
        'type': 'range',
        'bounds': [1, 100]
    },
    {
        'name': 'b',
        'type': 'range',
        'bounds': [0, 100]
    },
    {
        'name': 'c',
        'type': 'choice',
        'bounds': [True, False]
    },
    {
        'name': 'd',
        'type': 'choice',
        'bounds': ['a', 'b', 'c']
    }
]
	assert candidate(
    {'alpha': {'type': 'int', 'range': [0, 100]},
     'fit_intercept': {'type': 'bool'}}) == \
    [{'name': 'alpha', 'type': 'range', 'bounds': [0, 100]},
     {'name': 'fit_intercept', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {'hp_1': {'type': 'bool'}}) == [{'name': 'hp_1', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate({'a': {'type': 'float', 'values': [0.0, 0.5, 1.0]}}) == [{'bounds': [0.0, 1.0], 'name': 'a', 'type': 'range'}]
	assert candidate({'a': {'type': 'int', 'values': [0, 1, 2]}}) == [{'bounds': [0, 2], 'name': 'a', 'type': 'range'}]
	assert candidate(
    {'learning_rate': {'type': 'int', 'values': [0, 5]}}
) == [{'name': 'learning_rate', 'type': 'range', 'bounds': [0, 5]}]
	assert candidate({'a': {'type': 'bool'}}) == [{
    'name': 'a',
    'type': 'choice',
    'bounds': [True, False],
}]
	assert candidate(
    {'n_estimators': {'type': 'int', 'range': [1, 100]}
}) == [{'name': 'n_estimators', 'type': 'range', 'bounds': [1, 100]}]
	assert candidate(
    {'activation': {'type':'str', 'values': ['relu','sigmoid']}
}) == [{'name': 'activation', 'type': 'choice', 'bounds': ['relu','sigmoid']}]
	assert candidate(
    {
        'a': {
            'type': 'int',
            'range': [1, 100]
        },
        'b': {
            'type': 'float',
            'range': [0.1, 0.9]
        },
        'c': {
            'type': 'bool'
        },
        'd': {
            'type':'str',
            'values': ['foo', 'bar', 'baz']
        }
    }
) == [
    {
        'name': 'a',
        'type': 'range',
        'bounds': [1, 100]
    },
    {
        'name': 'b',
        'type': 'range',
        'bounds': [0.1, 0.9]
    },
    {
        'name': 'c',
        'type': 'choice',
        'bounds': [True, False]
    },
    {
        'name': 'd',
        'type': 'choice',
        'bounds': ['foo', 'bar', 'baz']
    }
]
	assert candidate(
    {'a': {'type': 'int', 'range': [1, 2, 3]}
}) == [{'name': 'a', 'type': 'range', 'bounds': [1, 3]}]
	assert candidate(
    {'hp_1': {'type': 'float', 'range': [0.1, 0.9]}
     }) == [{'name': 'hp_1', 'type': 'range', 'bounds': [0.1, 0.9]}]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b']}
}) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b']}]
	assert candidate({'a': {'type':'str', 'range': ['a', 'b']}}) == [{
    'name': 'a',
    'type': 'choice',
    'bounds': ['a', 'b'],
}]
	assert candidate(
    {'a': {'type': 'float', 'range': [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]}}
) == [
    {'name': 'a', 'type': 'range', 'bounds': [1.0, 10.0]}
]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b', 'c']}
    }) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']}]
	assert candidate(
    {'a': {'type': 'bool'}}) == [{'name': 'a', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate({'a': {'type': 'float', 'range': [1, 2]}}) == [{
    'name': 'a',
    'type': 'range',
    'bounds': [1, 2],
}]
	assert candidate(
    {
        'optimizer': {
            'type':'str',
            'values': ['sgd', 'adam']
        }
    }
) == [
    {
        'name': 'optimizer',
        'type': 'choice',
        'bounds': ['sgd', 'adam']
    }
]
	assert candidate(
    {'learning_rate': {'type': 'bool'}}
) == [{'name': 'learning_rate', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {
        'num_layers': {
            'type': 'int',
            'range': [1, 3]
        }
    }
) == [
    {
        'name': 'num_layers',
        'type': 'range',
        'bounds': [1, 3]
    }
]
	assert candidate(
    {'a': {'type': 'float', 'range': [0.0, 10.0]}}
) == [{'name': 'a', 'type': 'range', 'bounds': [0.0, 10.0]}]
	assert candidate(
    {
        'a': {'type': 'int', 'range': [1, 2, 3]},
        'b': {'type': 'float', 'range': [1.0, 2.0, 3.0]},
        'c': {'type': 'bool'},
        'd': {'type':'str', 'values': ['a', 'b', 'c']},
        'e': {'type':'str', 'range': ['a', 'b', 'c']},
    }
) == [
    {'name': 'a', 'type': 'range', 'bounds': [1, 3]},
    {'name': 'b', 'type': 'range', 'bounds': [1.0, 3.0]},
    {'name': 'c', 'type': 'choice', 'bounds': [True, False]},
    {'name': 'd', 'type': 'choice', 'bounds': ['a', 'b', 'c']},
    {'name': 'e', 'type': 'choice', 'bounds': ['a', 'b', 'c']},
]
	assert candidate(
    {'a': {'type': 'int', 'range': [0, 10]}}
) == [{'name': 'a', 'type': 'range', 'bounds': [0, 10]}]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b', 'c']}}
) == [
    {'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']}
]
	assert candidate(
    {'a': {'type': 'int', 'range': [0, 100]}
    }) == [{'name': 'a', 'type': 'range', 'bounds': [0, 100]}]
	assert candidate(
    {'a': {'type': 'float', 'range': [0.0, 1.0]}
    }) == [{'name': 'a', 'type': 'range', 'bounds': [0.0, 1.0]}]
	assert candidate({'a': {'type':'str', 'values': ['a', 'b']}}) == [{'bounds': ['a', 'b'], 'name': 'a', 'type': 'choice'}]
	assert candidate(
    {'a': {'type': 'bool'}}
) == [{'name': 'a', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {
        'foo': {
            'type': 'int',
            'range': [1, 2, 3]
        },
        'bar': {
            'type': 'float',
            'values': [1.0, 2.0, 3.0]
        },
        'baz': {
            'type': 'bool',
        },
        'qux': {
            'type':'str',
            'values': ['foo', 'bar', 'baz']
        }
    }
) == [
    {
        'name': 'foo',
        'type': 'range',
        'bounds': [1, 3]
    },
    {
        'name': 'bar',
        'type': 'range',
        'bounds': [1.0, 3.0]
    },
    {
        'name': 'baz',
        'type': 'choice',
        'bounds': [True, False]
    },
    {
        'name': 'qux',
        'type': 'choice',
        'bounds': ['foo', 'bar', 'baz']
    }
]
	assert candidate({'a': {'type': 'int', 'range': [1, 2, 3]}}) == [{
    'name': 'a',
    'type': 'range',
    'bounds': [1, 3],
}]
	assert candidate(
    {'a': {'type': 'bool'}}
) == [
    {'name': 'a', 'type': 'choice', 'bounds': [True, False]}
]
	assert candidate(
    {
        'a': {
            'type': 'int',
            'range': [1, 10]
        },
        'b': {
            'type': 'float',
            'range': [1.0, 10.0]
        },
        'c': {
            'type': 'bool'
        },
        'd': {
            'type':'str',
            'values': ['a', 'b', 'c']
        }
    }
) == [
    {
        'name': 'a',
        'type': 'range',
        'bounds': [1, 10]
    },
    {
        'name': 'b',
        'type': 'range',
        'bounds': [1.0, 10.0]
    },
    {
        'name': 'c',
        'type': 'choice',
        'bounds': [True, False]
    },
    {
        'name': 'd',
        'type': 'choice',
        'bounds': ['a', 'b', 'c']
    }
]
	assert candidate(
    {'a': {'type': 'bool', 'values': [True, False]}
}) == [{'name': 'a', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate({}) == []
	assert candidate(
    {'a': {'type': 'bool'}
    }) == [{'name': 'a', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {'alpha': {'type': 'float', 'range': [0.0, 100.0]},
     'fit_intercept': {'type': 'bool'}}) == \
    [{'name': 'alpha', 'type': 'range', 'bounds': [0.0, 100.0]},
     {'name': 'fit_intercept', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b']}}) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b']}]
	assert candidate(
    {'a': {'type': 'float', 'range': [0, 10]}
}) == [{'name': 'a', 'type': 'range', 'bounds': [0.0, 10.0]}]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b'], 'range': ['a', 'b']}
}) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b']}]
	assert candidate(
    dict_hyperparams={
        'a': {
            'type': 'int',
            'range': [0, 10]
        },
        'b': {
            'type': 'float',
            'range': [0, 1.0]
        },
        'c': {
            'type': 'bool'
        },
        'd': {
            'type':'str',
            'values': ['a', 'b']
        }
    }) == [
        {
            'name': 'a',
            'type': 'range',
            'bounds': [0, 10]
        },
        {
            'name': 'b',
            'type': 'range',
            'bounds': [0, 1.0]
        },
        {
            'name': 'c',
            'type': 'choice',
            'bounds': [True, False]
        },
        {
            'name': 'd',
            'type': 'choice',
            'bounds': ['a', 'b']
        }
    ]
	assert candidate(
    {'learning_rate': {'type': 'float', 'range': [0.0001, 0.1]}}
) == [{'name': 'learning_rate', 'type': 'range', 'bounds': [0.0001, 0.1]}]
	assert candidate(
    {'a': {'type': 'int', 'values': [1, 2, 3]}
}) == [{'name': 'a', 'type': 'range', 'bounds': [1, 3]}]
	assert candidate(
    {'learning_rate': {'type': 'float', 'range': [0.0001, 0.1]}}) == [{
        'name': 'learning_rate',
        'type': 'range',
        'bounds': [0.0001, 0.1]
    }]
	assert candidate(
    {
        'n_estimators': {
            'type': 'int',
            'range': [10, 100]
        },
       'max_depth': {
            'type': 'int',
            'range': [3, 15]
        },
       'min_samples_split': {
            'type': 'float',
            'range': [0.0001, 0.1]
        },
       'min_samples_leaf': {
            'type': 'float',
            'range': [0.0001, 0.1]
        },
        'criterion': {
            'type':'str',
            'values': ['gini', 'entropy']
        }
    }
) == [
    {
        'name': 'n_estimators',
        'type': 'range',
        'bounds': [10, 100]
    },
    {
        'name':'max_depth',
        'type': 'range',
        'bounds': [3, 15]
    },
    {
        'name':'min_samples_split',
        'type': 'range',
        'bounds': [0.0001, 0.1]
    },
    {
        'name':'min_samples_leaf',
        'type': 'range',
        'bounds': [0.0001, 0.1]
    },
    {
        'name': 'criterion',
        'type': 'choice',
        'bounds': ['gini', 'entropy']
    }
]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b', 'c']}}
) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']}]
	assert candidate(
    {'alpha': {'type': 'float', 'range': [0.0, 100.0]},
     'fit_intercept': {'type': 'bool'},
     'gamma': {'type':'str', 'range': ['auto','scale']}}) == \
    [{'name': 'alpha', 'type': 'range', 'bounds': [0.0, 100.0]},
     {'name': 'fit_intercept', 'type': 'choice', 'bounds': [True, False]},
     {'name': 'gamma', 'type': 'choice', 'bounds': ['auto','scale']}]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b', 'c']}
}) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']}]
	assert candidate(
    {'a': {'type':'str', 'values': ['a', 'b', 'c']},
     'b': {'type': 'int', 'range': [0, 100]}
    }) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']},
           {'name': 'b', 'type': 'range', 'bounds': [0, 100]}]
	assert candidate(
    {'a': {'type':'str', 'range': ['a', 'b', 'c']}}
) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']}]
	assert candidate(
    {'learning_rate': {'type': 'int', 'range': [0, 5]}}
) == [{'name': 'learning_rate', 'type': 'range', 'bounds': [0, 5]}]
	assert candidate(
    {'a': {'type': 'float', 'range': [1, 2, 3]}
}) == [{'name': 'a', 'type': 'range', 'bounds': [1.0, 3.0]}]
	assert candidate(
    {'a': {'type':'str', 'range': ['a', 'b', 'c']}
}) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']}]
	assert candidate({'a': {'type': 'float', 'range': [1, 2, 3]}}) == [{
    'name': 'a',
    'type': 'range',
    'bounds': [1, 3],
}]
	assert candidate(
    {'learning_rate': {'type':'str', 'values': ['sgd', 'adam']}}
) == [{'name': 'learning_rate', 'type': 'choice', 'bounds': ['sgd', 'adam']}]
	assert candidate(
    {'hp_1': {'type': 'int', 'range': [1, 10]}
     }) == [{'name': 'hp_1', 'type': 'range', 'bounds': [1, 10]}]
	assert candidate({'a': {'type': 'int', 'range': [1, 2]}}) == [{
    'name': 'a',
    'type': 'range',
    'bounds': [1, 2],
}]
	assert candidate(
    {'a': {'type': 'int', 'range': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}}
) == [
    {'name': 'a', 'type': 'range', 'bounds': [1, 10]}
]
	assert candidate(
    {'use_attention': {'type': 'bool'}
}) == [{'name': 'use_attention', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {'a': {'type':'str', 'values': []}}
) == [{'name': 'a', 'type': 'choice', 'bounds': []}]
	assert candidate(
    {'a': {'type': 'int', 'range': [1, 2]}}) == [{'name': 'a', 'type': 'range', 'bounds': [1, 2]}]
	assert candidate(
    {'a': {'type': 'int', 'range': [0, 10]}
}) == [{'name': 'a', 'type': 'range', 'bounds': [0, 10]}]
	assert candidate(
    {'a': {'type': 'float', 'values': [1.0, 2.0, 3.0]}
}) == [{'name': 'a', 'type': 'range', 'bounds': [1.0, 3.0]}]
	assert candidate(dict_hyperparams={'a': {'type': 'int', 'range': [1, 5]} }) == [{'name': 'a', 'type': 'range', 'bounds': [1, 5]}]
	assert candidate(dict_hyperparams={'a': {'type': 'float', 'range': [1.0, 5.0]} }) == [{'name': 'a', 'type': 'range', 'bounds': [1.0, 5.0]}]
	assert candidate(
    {'a': {'type': 'bool'}
}) == [{'name': 'a', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {'n_estimators': {'type': 'float', 'range': [0.01, 10.0]}
}) == [{'name': 'n_estimators', 'type': 'range', 'bounds': [0.01, 10.0]}]
	assert candidate(
    {'a': {'type': 'float', 'range': [1., 2.]}}) == [{'name': 'a', 'type': 'range', 'bounds': [1., 2.]}]
	assert candidate(
    {'batch_size': {'type': 'int', 'range': [32, 256]}}) == [{
        'name': 'batch_size',
        'type': 'range',
        'bounds': [32, 256]
    }]
	assert candidate(
    {
        'dropout_rate': {
            'type': 'float',
            'range': [0, 1]
        }
    }
) == [
    {
        'name': 'dropout_rate',
        'type': 'range',
        'bounds': [0, 1]
    }
]
	assert candidate({'a': {'type': 'bool'}}) == [{'bounds': [True, False], 'name': 'a', 'type': 'choice'}]
	assert candidate(dict_hyperparams={'a': {'type': 'bool'} }) == [{'name': 'a', 'type': 'choice', 'bounds': [True, False]}]
	assert candidate(
    {
        'param1': {
            'type': 'int',
            'range': [1, 10],
        },
        'param2': {
            'type': 'float',
            'range': [10.5, 11.5],
        },
        'param3': {
            'type':'str',
            'values': ['a', 'b', 'c'],
        },
        'param4': {
            'type': 'bool',
        },
    }
) == [
    {
        'name': 'param1',
        'type': 'range',
        'bounds': [1, 10],
    },
    {
        'name': 'param2',
        'type': 'range',
        'bounds': [10.5, 11.5],
    },
    {
        'name': 'param3',
        'type': 'choice',
        'bounds': ['a', 'b', 'c'],
    },
    {
        'name': 'param4',
        'type': 'choice',
        'bounds': [True, False],
    },
]
	assert candidate(
    {
        'learning_rate': {
            'type': 'float',
            'range': [0.01, 0.1]
        }
    }
) == [
    {
        'name': 'learning_rate',
        'type': 'range',
        'bounds': [0.01, 0.1]
    }
]
	assert candidate(
    {'learning_rate': {'type': 'float', 'values': [0.0001, 0.1]}}
) == [{'name': 'learning_rate', 'type': 'range', 'bounds': [0.0001, 0.1]}]
	assert candidate(
    {'dropout': {'type': 'bool'}}) == [{
        'name': 'dropout',
        'type': 'choice',
        'bounds': [True, False]
    }]
	assert candidate(dict_hyperparams={'a': {'type':'str', 'values': ['a', 'b', 'c']}}) == [{'name': 'a', 'type': 'choice', 'bounds': ['a', 'b', 'c']}]
def test_check():
	check(convert_hyperparameters)
