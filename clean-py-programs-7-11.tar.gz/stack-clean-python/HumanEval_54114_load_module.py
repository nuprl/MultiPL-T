def load_module(name):
    """ Load module in the format 'json.tool'"""
	### Canonical solution below ###    
    mod = __import__(name)
    for sub in name.split('.')[1:]:
        mod = getattr(mod, sub)
    return mod

### Unit tests below ###
def check(candidate):
	assert candidate('json') is not None
	assert candidate('json.tool').main == candidate('json.tool').main
	assert candidate('json.tool') is not None
	assert candidate( 'os' ).__name__ == 'os'
	assert candidate( 'json.tool' ).__name__ == 'json.tool'
	assert candidate('json.tool') == candidate('json.tool')
def test_check():
	check(load_module)
