def show_tw(TW_HANDL):
    """ 
     w = db.session.query(Wiki_summary).filter_by(uid=uid).first()
     if w.TW_HANDL != None:
     return('<a class="twitter-timeline" href="https://twitter.com/'+str(w.TW_HANDL)+'?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>')
     else:
     return("<h4>Sorry, we can't find the twitter feed...</h4>")
     """
	### Canonical solution below ###        
    if TW_HANDL != "":
        return('<a class="twitter-timeline" href="https://twitter.com/'+str(TW_HANDL)+'?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>')
    else:
        return("<h4>Sorry, we can't find the twitter feed...</h4>")

### Unit tests below ###
def check(candidate):
	assert candidate("test") == '<a class="twitter-timeline" href="https://twitter.com/test?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>', "Twitter handle"
	assert candidate("") == "<h4>Sorry, we can't find the twitter feed...</h4>"
	assert candidate("") == "<h4>Sorry, we can't find the twitter feed...</h4>", "TW_HANDL not equal"
	assert candidate("twitter") == '<a class="twitter-timeline" href="https://twitter.com/twitter?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("") == "<h4>Sorry, we can't find the twitter feed...</h4>", "Test 2 for candidate()"
	assert candidate(1234) == '<a class="twitter-timeline" href="https://twitter.com/1234?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate(1) == '<a class="twitter-timeline" href="https://twitter.com/1?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate('test') == '<a class="twitter-timeline" href="https://twitter.com/test?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("test") == '<a class="twitter-timeline" href="https://twitter.com/test?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>', "TW_HANDL is 'test'"
	assert candidate("jasonbateman") == '<a class="twitter-timeline" href="https://twitter.com/jasonbateman?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("jason_bateman") == '<a class="twitter-timeline" href="https://twitter.com/jason_bateman?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("thehandle") == '<a class="twitter-timeline" href="https://twitter.com/thehandle?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("foo") == '<a class="twitter-timeline" href="https://twitter.com/foo?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate('') == '<h4>Sorry, we can\'t find the twitter feed...</h4>'
	assert candidate("test") == '<a class="twitter-timeline" href="https://twitter.com/test?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("RickAndMorty")!= "<h4>Sorry, we can't find the twitter feed...</h4>"
	assert candidate('twitter_handle') == '<a class="twitter-timeline" href="https://twitter.com/twitter_handle?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("") == "<h4>Sorry, we can't find the twitter feed...</h4>", "Empty Twitter handle"
	assert candidate("1234567890") == '<a class="twitter-timeline" href="https://twitter.com/1234567890?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("my_name") == '<a class="twitter-timeline" href="https://twitter.com/my_name?ref_src=twsrc%5Etfw/">Tweets</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>'
	assert candidate("") == "<h4>Sorry, we can't find the twitter feed...</h4>", "Empty TW_HANDL failed"
def test_check():
	check(show_tw)
