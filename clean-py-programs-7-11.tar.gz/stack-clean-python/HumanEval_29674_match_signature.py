def match_signature(args, signatures, strict=False):
    """ 
     Dynamically match arguments to the corresponding types signature.
     
     Return matching types signature from `signatures` to the
     given types of arguments from `args` by inspecting their types
     dynamically, or None if no match.
     
     :param `args`: Sequence of function arguments.
     :type `args`: Sequence[object]
     
     :param `signatures`: Sequence of type signatures.
     :type `signatures`: Sequence[Sequence[type]]
     
     :param `strict`: If set to False, try to keep duck-typing support
     as much as possible.
     :type `strict`: bool
     
     :return: matched signature
     :rtype: type
     """
	### Canonical solution below ###    
    # check for duplicate signatures
    if len(set(signatures)) != len(signatures):
        raise TypeError("Duplicate signatures")

    matched_signatures = []
    # check number of arguments
    for sig in signatures:
        if len(sig) == len(args):
            matched_signatures.append(sig)

    if not matched_signatures:
        return

    if not strict and len(matched_signatures) == 1:
        return matched_signatures[0]

    signatures = matched_signatures
    # check types of arguments
    for sig in signatures:
        for arg, type_ in zip(args, sig):
            if not isinstance(arg, type_):
                break
        else:
            return sig

    if not strict:
        for sig in signatures:
            for arg, type_ in zip(args, sig):
                try:
                    type_(arg)
                except (ValueError, TypeError):
                    break
            else:
                return sig

### Unit tests below ###
def check(candidate):
	assert candidate(args=(1, 2.0), signatures=[(int, int), (float, float)], strict=True) is None
	assert candidate(
    (1, 2),
    ((int, int), (int, int, int)),
) == (int, int)
	assert candidate(
    (1, 'foo'),
    (
        (int, str),
        (str, int),
    )
) == (int, str)
	assert candidate((1, "2"), [(int, float, str)], strict=True) is None
	assert candidate(
    (1, "hello", 1.0),
    [(int, str), (str, int), (float, float)],
    strict=True
) == None
	assert candidate(args=(1, 2, 3.0), signatures=[(int, int, float), (int, int, int)]) == (int, int, float)
	assert candidate(args=(1, 2.0), signatures=[(int, float), (int, int)]) == (int, float)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (str, str),
        (object, object),
    ),
    strict=True
) == (int, int)
	assert candidate((1, 2), ((int, int, int, int, int),), strict=True) is None
	assert candidate(
    (1, 2),
    ((int, int), (float, float), (str, str))
) == (int, int)
	assert candidate((), ()) is None
	assert candidate(
    (1, 2),
    (
        (int, int),
        (int, float),
    ),
    strict=False,
) == (int, int)
	assert candidate(args=(1, 2.0), signatures=[(int, str), (float, int)], strict=True) is None
	assert candidate((1, 2), [(int, float, str)], strict=True) is None
	assert candidate(args=(1, 2.0), signatures=[(float, int)]) == (float, int)
	assert candidate(
    (1, 2, 3),
    [
        (int, float, int),
        (float, int, int),
        (int, int, float),
    ],
    strict=False,
) == (int, float, int)
	assert candidate(
    (1, 2, 3),
    ((int, int, int), (float, float, float))
) == (int, int, int)
	assert candidate(
    (1, 2.0),
    ((int, float), (float, int)),
    strict=True
) == (int, float)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (object, object),
        (str, str),
    ),
    strict=False
) == (int, int)
	assert candidate((), ((int,),)) is None
	assert candidate(
    (1, 2),
    (
        (int, int),
        (float, float),
        (int, int, int),
        (float, float, float),
    ),
) == (int, int)
	assert candidate((1,), ((int, int, int),), strict=True) is None
	assert candidate(
    (1, 2.0),
    (
        (int, int),
        (int, int, int),
    ),
) == (int, int)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (float, float),
    ),
) == (int, int)
	assert candidate((1,), ((int, int),), strict=True) is None
	assert candidate(
    (1, 2.0),
    (
        (int, int),
        (int, int, int),
    ),
    strict=True,
) == None
	assert candidate(
    (1, 2, 3, 4.0),
    ((int, int, int, int), (int, int, float), (int, int), (int,)),
    strict=False) == (int, int, int, int)
	assert candidate(
    (1, 2.0),
    (
        (int, int),
        (int, int, int),
    ),
    strict=False,
) == (int, int)
	assert candidate((1,), [(int,)])
	assert candidate((1,), [(object,)]) == (object,)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (object, object),
        (str, str),
    ),
    strict=True
) == (int, int)
	assert candidate(
    (1, 2.0),
    ((int, int), (float, float), (str, str)),
    strict=True
) is None
	assert candidate(args=(1, 2.0), signatures=[(int, float), (float, int)]) == (int, float)
	assert candidate(
    (1, 2, 3.14),
    ((int, int, int), (float, float, float)),
    strict=True
) is None
	assert candidate(
    (1, 2.0),
    ((int, float), (str, int)),
    strict=True
) == (int, float)
	assert candidate(
    (1, 2, 3, 4),
    ((int, int, int, int), (int, int, int), (int, int), (int,)),
    strict=True) == (int, int, int, int)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (str, str),
        (object, object),
    )
) == (int, int)
	assert candidate((1,), [(int,)]) == (int,)
	assert candidate(
    (1, 2, 3),
    ((int, int, int), (int, int, float)),
) == (int, int, int)
	assert candidate((1,), ((int,),), strict=False) == (int,)
	assert candidate(
    (1, 2),
    ((int, int), (int, float))
) == (int, int)
	assert candidate(
    (1, 'foo'),
    (
        (int, str),
        (str, int),
    ),
    strict=False
) == (int, str)
	assert candidate((1, ), ((str, int), (int, ), (int, str), ), True) == (int, )
	assert candidate(args=(1, 2, 3.0), signatures=[(int, int, float)], strict=False) == (int, int, float)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (object, object),
        (str, str),
    )
) == (int, int)
	assert candidate(
    (1, 2, 3, 4),
    [
        (int, int, int, int),
        (float, float, float, float)
    ]
) == (int, int, int, int)
	assert candidate((1,), [(object, int)]) is None
	assert candidate(
    (1, "hello"),
    [(int, str)]
) == (int, str)
	assert candidate(
    (1, 2.0),
    ((int, int), (int, float))
) == (int, float)
	assert candidate((1, 2), [(int, str)], strict=True) is None
	assert candidate(
    (1, 2),
    (
        (int, int),
        (int, int, int),
    ),
) == (int, int)
	assert candidate(
    (1, "hello"),
    [(int, str), (str, int)]
) == (int, str)
	assert candidate((1, 2), [(int, int)])
	assert candidate((1, 2), ((int, int, int, int),), strict=True) is None
	assert candidate((1, 2, 3), [(object, object, object), (object, int, object)]) == (object, object, object)
	assert candidate(
    (1, 2.0),
    ((int, float), (str, int)),
    strict=False
) == (int, float)
	assert candidate(
    (1, 2, 3.0),
    ((int, int, int), (int, int, float)),
    strict=False,
) == (int, int, float)
	assert candidate((), [()]) == ()
	assert candidate(
    (1, 2),
    (
        (int, int),
        (str, str),
        (object, object),
    ),
    strict=False
) == (int, int)
	assert candidate(
    (1, "hello"),
    [(int, str), (str, int), (float, float)]
) == (int, str)
	assert candidate((1, 2), ((int, int), (str, int))) == (int, int)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (int, float),
    ),
    strict=True,
) == (int, int)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (int, int, int),
    ),
    strict=False,
) == (int, int)
	assert candidate((1, 2), [(int, object), (object, object)]) == (int, object)
	assert candidate(args=(1, 2, 3.0), signatures=[(int, int, float)]) == (int, int, float)
	assert candidate(
    (1, 2),
    ((int, int), (float, int), (int, float)),
    strict=False
) == (int, int)
	assert candidate(
    (1, 2.0),
    ((int, float), (float, int)),
    strict=False
) == (int, float)
	assert candidate((1, ), ((str, int), (int, str), (int, ), )) == (int, )
	assert candidate((1,), ((int,),)) == (int,)
	assert candidate(args=(1, 2.0), signatures=[(int, float)]) == (int, float)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (float, float),
        (int, int, int),
    ),
) == (int, int)
	assert candidate((1.0,), [(int,)], strict=True) is None
	assert candidate((), ((),), strict=False) == ()
	assert candidate(
    (1, 1.0),
    [(int, str), (str, int), (float, float)],
    strict=True
) == None
	assert candidate(
    (1, 2),
    ((int, int), (int, float), (int, int, int)),
) == (int, int)
	assert candidate(
    (1, 2),
    ((int, int), (float, int), (int, float))
) == (int, int)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (int, int, int),
    ),
    strict=True,
) == (int, int)
	assert candidate(
    (1, 2),
    ((int, int), (int, int, int)),
    strict=False,
) == (int, int)
	assert candidate((1, 2), ((int, int),)) == (int, int)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (int, float),
    ),
) == (int, int)
	assert candidate(
    (1, 2, 3.0),
    ((int, int, int), (int, int, float)),
) == (int, int, float)
	assert candidate(
    (1, 2),
    (
        (int, int, int),
        (int, int),
    ),
    strict=False,
) == (int, int)
	assert candidate((), ((int,),), strict=True) is None
	assert candidate(
    (1, 2, 3),
    ((int, int), (int, float), (int, int, int)),
) == (int, int, int)
	assert candidate(
    (1, 2),
    ((int, int), (float, float), (str, str)),
    strict=False
) == (int, int)
	assert candidate(
    (1, 2),
    ((int, int), (int, int, int)),
    strict=True,
) == (int, int)
	assert candidate((), ((),), strict=True) == ()
	assert candidate((1, 2), ((int, int, int),), strict=True) is None
	assert candidate((1, 2), [(int, int)]) == (int, int)
	assert candidate(
    (1, 2, 3),
    [
        (int, float, int),
        (float, int, int),
        (int, int, float),
    ]
) == (int, float, int)
	assert candidate((1, 2), [(object, int), (int, object)]) == (object, int)
	assert candidate(args=(1, 2, 3), signatures=[(int, int, int)]) == (int, int, int)
	assert candidate(args=(1, 2.0), signatures=[(int, int), (float, int)]) == (int, int)
	assert candidate((1,), [()]) is None
	assert candidate((1, 2.0), [(int, int), (int, float)])
	assert candidate((1, ), ((int, ), )) == (int, )
	assert candidate((1, 2), ((int, int),), strict=False) == (int, int)
	assert candidate((1, 2, 3), [(object, object, object)]) == (object, object, object)
	assert candidate((1,), [(int, str)], strict=True) is None
	assert candidate((1, 2), [(int, object), (object, int)]) == (int, object)
	assert candidate(
    (1, 2, 3, 4.0),
    ((int, int, int, int), (int, int, int), (int, int), (int,)),
    strict=True) is None
	assert candidate(
    (1, 2, 3, 4.0),
    ((int, int, int, int), (int, int, int), (int, int), (int,)),
    strict=False) == (int, int, int, int)
	assert candidate((1, 2), [(object, object)]) == (object, object)
	assert candidate((1,), [(int, str)]) is None
	assert candidate((1, 2), [(int, int), (int,)])
	assert candidate((1, 2, 3), [(int, float, str)], strict=True) is None
	assert candidate(
    (1, 2.0),
    ((int, int), (float, int), (int, float)),
    strict=False
) == (int, float)
	assert candidate(
    (1, 2),
    (
        (int, int),
        (float, float),
        (int, float),
    ),
) == (int, int)
	assert candidate(
    (1, 2.0, 'hello'),
    ((int, int), (float, float), (str, str)),
    strict=True
) is None
def test_check():
	check(match_signature)
