def msg_color(msg_type):
    """Get the color to use for the msg type."""
    ### Canonical solution below ###
    return {
        "sent":     0x4caf50,
        "edited":   0xffc107,
        "deleted":  0xff5252,
    }.get(msg_type, 0x000000)


### Unit tests below ###
def check(candidate):
	assert candidate("foobar") == 0x000000
	assert candidate("fake") == 0x000000
	assert candidate("unknown") == 0x000000
	assert candidate("edited") == 0xffc107
	assert candidate("other") == 0x000000
	assert candidate(None) == 0x000000
	assert candidate("spam") == 0x000000
	assert candidate("not a type") == 0x000000
	assert candidate("not a real type") == 0x000000
	assert candidate("") == 0x000000
	assert candidate("somethingelse") == 0x000000
	assert candidate("foo") == 0x000000
	assert candidate("deleted") == 0xff5252
	assert candidate("bogus") == 0x000000
	assert candidate("sent") == 0x4caf50
	assert candidate("some other value") == 0x000000
	assert candidate("something") == 0x000000
	assert candidate("invalid") == 0x000000
def test_check():
	check(msg_color)
