def sort_io_dict(performance_utilization: dict):
    """ 
     Sorts io dict by max_io in descending order.
     """
	### Canonical solution below ###    
    sorted_io_dict = {
        'io_all': dict(sorted(performance_utilization['io'].items(), key=lambda x: x[1], reverse=True))
    }
    performance_utilization.update({**sorted_io_dict})
    del performance_utilization['io']
    return performance_utilization

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'io': {
        '1024': 100,
        '512': 50,
        '256': 20,
        '128': 10,
        '64': 5,
        '32': 2,
        '16': 1,
        '8': 0.5,
        '4': 0.2,
        '2': 0.1,
        '1': 0.01,
    }}
) == {
    'io_all': {
        '1024': 100,
        '512': 50,
        '256': 20,
        '128': 10,
        '64': 5,
        '32': 2,
        '16': 1,
        '8': 0.5,
        '4': 0.2,
        '2': 0.1,
        '1': 0.01,
    }
}
	assert candidate(
    {'io': {'1': 100, '2': 200, '3': 300, '4': 400}}
) == {'io_all': {'4': 400, '3': 300, '2': 200, '1': 100}}
	assert candidate(
    {
        'io': {'sda': 100,'sdb': 50,'sdc': 10},
        'cpu': 10,
       'mem': 20
    }
) == {
    'io_all': {'sdb': 50,'sdc': 10,'sda': 100},
    'cpu': 10,
   'mem': 20
}
	assert candidate(
    {
        'io': {
            '/dev/sda': 100,
            '/dev/sdb': 150,
            '/dev/sdc': 120,
            '/dev/sdd': 110,
            '/dev/sde': 140,
            '/dev/sdf': 130
        }
    }
) == {
    'io_all': {
        '/dev/sdd': 110,
        '/dev/sde': 140,
        '/dev/sdf': 130,
        '/dev/sda': 100,
        '/dev/sdb': 150,
        '/dev/sdc': 120
    }
}
	assert candidate(
    {
        'io': {'sda': 300,'sdb': 200,'sdc': 100}
    }
) == {
    'io_all': {'sda': 300,'sdb': 200,'sdc': 100}
}
	assert candidate(
    {'io': {'sda': 100,'sdb': 120,'sdc': 150,'sdd': 100}}) == {'io_all': {'sdb': 120,'sdc': 150,'sda': 100,'sdd': 100}}
	assert candidate(
    {'io': {'sda': 1,'sdb': 2,'sdc': 3}, 'io_all': {'sda': 1,'sdb': 2,'sdc': 3},
     'io_read': {'sda': 1,'sdb': 2,'sdc': 3}, 'io_write': {'sda': 1,'sdb': 2,'sdc': 3}}) == \
    {'io_all': {'sda': 1,'sdb': 2,'sdc': 3}, 'io_read': {'sda': 1,'sdb': 2,'sdc': 3},
     'io_write': {'sda': 1,'sdb': 2,'sdc': 3}}, "Test with duplicate keys failed"
	assert candidate(
    {
        'io': {'sda': 100,'sdb': 50,'sdc': 10},
        'io_all': {'sdb': 50,'sdc': 10,'sda': 100},
        'cpu': 10,
       'mem': 20
    }
) == {
    'io_all': {'sdb': 50,'sdc': 10,'sda': 100},
    'cpu': 10,
   'mem': 20
}
	assert candidate(
    {'io': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000}}) == \
    {'io_all': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000}}
	assert candidate(
    {
        'io': {'sda': 100,'sdb': 100,'sdc': 100}
    }
) == {
    'io_all': {'sda': 100,'sdb': 100,'sdc': 100}
}
	assert candidate(
    {
        'io': {
           'sda': 1,
           'sdb': 2
        }
    }
) == {
    'io_all': {
       'sdb': 2,
       'sda': 1
    }
}
	assert candidate(
    {
        'io': {
           'sdb': 10,
           'sdd': 20,
           'sde': 30
        }
    }
) == {
    'io_all': {'sdb': 10,'sdd': 20,'sde': 30}
}
	assert candidate(
    {'io': {'1': 100, '2': 200, '3': 300, '4': 400, '5': 500, '6': 600}}
) == {'io_all': {'6': 600, '5': 500, '4': 400, '3': 300, '2': 200, '1': 100}}
	assert candidate(
    {'io': {'sda': 1,'sdb': 2,'sdc': 3}}) == {'io_all': {'sda': 1,'sdb': 2,'sdc': 3}}, "Simple test failed"
	assert candidate(
    {'io': {'sda': 100,'sdb': 120,'sdc': 150}}) == {'io_all': {'sdb': 120,'sdc': 150,'sda': 100}}
	assert candidate(
    {
        'io': {
           'sda': 2,
           'sdb': 1
        }
    }
) == {
    'io_all': {
       'sda': 2,
       'sdb': 1
    }
}
	assert candidate(
    {
        'io': {
            '25000': 33.33,
            '40000': 100,
            '10000': 50,
        }
    }
) == {
    'io_all': {
        '25000': 33.33,
        '40000': 100,
        '10000': 50,
    }
}
	assert candidate(
    {'io': {'sda': 100,'sdb': 120,'sdc': 150,'sdd': 100,'sde': 100}}) == {'io_all': {'sdb': 120,'sdc': 150,'sda': 100,'sdd': 100,'sde': 100}}
	assert candidate(
    {
        'io': {
            '25000': 33.33,
            '40000': 100,
            '10000': 50,
        },
        'io_all': {
            '25000': 33.33,
            '40000': 100,
            '10000': 50,
        }
    }
) == {
    'io_all': {
        '25000': 33.33,
        '40000': 100,
        '10000': 50,
    }
}
	assert candidate(
    {
        'io': {
            '/dev/sda': 200,
            '/dev/sdb': 100,
            '/dev/sdc': 50,
        }
    }
) == {
    'io_all': {
        '/dev/sdb': 100,
        '/dev/sdc': 50,
        '/dev/sda': 200,
    }
}
	assert candidate(performance_utilization={'io': {'a': 1, 'b': 2, 'c': 3}}) == \
    {'io_all': {'a': 1, 'b': 2, 'c': 3}}
	assert candidate(
    {
        'io': {
           'sda': 2,
           'sdb': 2
        }
    }
) == {
    'io_all': {
       'sda': 2,
       'sdb': 2
    }
}
	assert candidate(
    {
        'io': {
            '/dev/sda': 200,
            '/dev/sdb': 100,
            '/dev/sdc': 50,
            '/dev/sdd': 50,
            '/dev/sde': 50,
        }
    }
) == {
    'io_all': {
        '/dev/sdb': 100,
        '/dev/sdc': 50,
        '/dev/sda': 200,
        '/dev/sdd': 50,
        '/dev/sde': 50,
    }
}
	assert candidate(
    {
        "io": {
            "/dev/sda": 10,
            "/dev/sdb": 30,
            "/dev/sdc": 20
        }
    }
) == {
    "io_all": {
        "/dev/sdb": 30,
        "/dev/sdc": 20,
        "/dev/sda": 10
    }
}
	assert candidate(
    {'io_all': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000},
     'io': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000}}) == \
    {'io_all': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000}}
	assert candidate(performance_utilization={'io': {'a': 3, 'b': 2, 'c': 1}}) == \
    {'io_all': {'c': 1, 'b': 2, 'a': 3}}
	assert candidate(dict(io={
    '/var/log/syslog': 100,
    '/var/log/messages': 200,
    '/var/log/secure': 300,
    '/var/log/auth.log': 400
})) == {
    'io_all': {'/var/log/syslog': 100, '/var/log/messages': 200, '/var/log/secure': 300, '/var/log/auth.log': 400}
}
	assert candidate(
    {'io': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000},
     'io_all': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000}}) == \
    {'io_all': {'sda1': 10000,'sda2': 1000,'sda3': 1000,'sda4': 1000}}
	assert candidate(
    {'io': {'sda': 1,'sdb': 2,'sdc': 3}, 'io_all': {'sda': 1,'sdb': 2,'sdc': 3}}) == \
    {'io_all': {'sda': 1,'sdb': 2,'sdc': 3}}, "Test with duplicate keys failed"
	assert candidate(
    {
        'io': {
            '/dev/sda': 200,
            '/dev/sdb': 100,
            '/dev/sdc': 50,
            '/dev/sdd': 50,
        }
    }
) == {
    'io_all': {
        '/dev/sdb': 100,
        '/dev/sdc': 50,
        '/dev/sda': 200,
        '/dev/sdd': 50,
    }
}
	assert candidate(
    {'io': {'11': 4, '10': 3, '9': 2, '8': 1}}
) == {'io_all': {'11': 4, '10': 3, '9': 2, '8': 1}}
	assert candidate(
    {'io': {'sda': 0,'sdb': 1,'sdc': 2,'sdd': 3,'sde': 4,'sdf': 5,'sdg': 6,'sdh': 7,'sdi': 8,'sdj': 9}}
) == {
    'io_all': {'sda': 0,'sdb': 1,'sdc': 2,'sdd': 3,'sde': 4,'sdf': 5,'sdg': 6,'sdh': 7,'sdi': 8,'sdj': 9}
}
	assert candidate(
    {
        'io': {
           'sda': 10,
           'sdb': 5,
           'sdc': 3
        }
    }
) == {
    'io_all': {
       'sda': 10,
       'sdb': 5,
       'sdc': 3
    }
}
def test_check():
	check(sort_io_dict)
