def obj_code(object_type, obj_id):
  """Generates default object code for `obj_type` and `obj_id`."""
    ### Canonical solution below ###
  return "{}-{}".format(object_type.upper(), obj_id)


### Unit tests below ###
def check(candidate):
	assert candidate(object_type="Objective", obj_id="2345") == "OBJECTIVE-2345"
	assert candidate(object_type="Object", obj_id=10000000) == "OBJECT-10000000"
	assert candidate(object_type="user", obj_id="789") == "USER-789"
	assert candidate(object_type="Object", obj_id=1000000) == "OBJECT-1000000"
	assert candidate(object_type="user", obj_id="123") == "USER-123"
	assert candidate(object_type="Issue", obj_id="5678") == "ISSUE-5678"
	assert candidate(object_type="Assessment", obj_id="3456") == "ASSESSMENT-3456"
	assert candidate(object_type="user", obj_id=789) == "USER-789"
	assert candidate(object_type="assessment", obj_id="2-2") == "ASSESSMENT-2-2"
	assert candidate(object_type="program", obj_id=123) == "PROGRAM-123"
	assert candidate(object_type="control", obj_id="123") == "CONTROL-123"
	assert candidate(object_type="Person", obj_id="P1") == "PERSON-P1"
	assert candidate(object_type="control", obj_id=789) == "CONTROL-789"
	assert candidate(object_type="control", obj_id="456") == "CONTROL-456"
	assert candidate(object_type="Object", obj_id=1000000000) == "OBJECT-1000000000"
	assert candidate(object_type="Object", obj_id=10000) == "OBJECT-10000"
	assert candidate(object_type="user", obj_id=123) == "USER-123"
	assert candidate(object_type="issue", obj_id="1") == "ISSUE-1"
	assert candidate(object_type="assessment", obj_id="2") == "ASSESSMENT-2"
	assert candidate(object_type="program", obj_id="123") == "PROGRAM-123"
	assert candidate(object_type="user", obj_id=456) == "USER-456"
	assert candidate(object_type="Object", obj_id=100000000) == "OBJECT-100000000"
	assert candidate(object_type="Object", obj_id=1) == "OBJECT-1"
	assert candidate(object_type="control", obj_id="789") == "CONTROL-789"
	assert candidate(object_type="Object", obj_id=100000) == "OBJECT-100000"
	assert candidate(object_type="control", obj_id=123) == "CONTROL-123"
	assert candidate(object_type="control", obj_id=456) == "CONTROL-456"
	assert candidate("OBJ", "2") == "OBJ-2"
	assert candidate(object_type="requirement", obj_id="R-001") == "REQUIREMENT-R-001"
	assert candidate(object_type="user", obj_id="456") == "USER-456"
	assert candidate(object_type="Object", obj_id=100) == "OBJECT-100"
	assert candidate(object_type="Control", obj_id="1234") == "CONTROL-1234"
	assert candidate(object_type="Object", obj_id=1000) == "OBJECT-1000"
	assert candidate(object_type="Control", obj_id=1) == "CONTROL-1"
	assert candidate("OBJ", 2) == "OBJ-2"
def test_check():
	check(obj_code)
