def fname_to_code(fname: str):
    """file name to stock code

    Parameters
    ----------
    fname: str
    """
    ### Canonical solution below ###

    prefix = "_qlib_"
    if fname.startswith(prefix):
        fname = fname.lstrip(prefix)
    return fname


### Unit tests below ###
def check(candidate):
	assert candidate(candidate("qlib_stock_data_bundle_test_v1_0_0")) == "qlib_stock_data_bundle_test_v1_0_0"
	assert candidate(candidate("qlib_data_cn_1min_test")) == "qlib_data_cn_1min_test"
	assert candidate(candidate("file_name")) == "file_name"
	assert candidate(candidate("000001.XSHE")) == "000001.XSHE"
	assert candidate("_qlib_file_name") == "file_name"
	assert candidate(candidate("SH600000")) == "SH600000"
	assert candidate("SH600000") == "SH600000"
	assert candidate(candidate("qlib_data_2021-01-01_15-00-00_ticker_data_bundle.pkl")) == "qlib_data_2021-01-01_15-00-00_ticker_data_bundle.pkl"
	assert candidate("000001.XSHE") == "000001.XSHE"
	assert candidate(candidate("_qlib_stock_data_bundle_test_v1_0_0")) == "stock_data_bundle_test_v1_0_0"
def test_check():
	check(fname_to_code)
