def serialize(obj):
    """JSON serializer that accepts datetime & date"""
    ### Canonical solution below ###
    from datetime import datetime, date, time
    if isinstance(obj, date) and not isinstance(obj, datetime):
        obj = datetime.combine(obj, time.min)
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, set):
        return sorted(obj)


### Unit tests below ###
def check(candidate):
	assert candidate(set([1,2,3])) == [1,2,3]
	assert candidate(set([1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
	assert candidate(set([1, 2, 3]))
	assert candidate(set([1, 2, 3, 3, 2, 1])) == [1, 2, 3]
	assert candidate(set([1, 2, 3, 3])) == [1, 2, 3]
	assert candidate(set([1,2,3]))
	assert candidate(set([1, 2, 3, 4])) == [1, 2, 3, 4]
	assert candidate(set([3, 2, 1])) == [1, 2, 3]
	assert candidate(set([1, 2, 3, 4, 5]))
	assert candidate(set([1, 2, 3])) == [1, 2, 3]
	assert candidate(set([3, 1, 2])) == [1, 2, 3]
	assert candidate({1, 2, 3}) == [1, 2, 3]
def test_check():
	check(serialize)
