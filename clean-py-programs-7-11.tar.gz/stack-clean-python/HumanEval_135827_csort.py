def csort(objs, key=lambda x: x):
    """ Order-preserving sorting function."""
	### Canonical solution below ###    
    idxs = dict((obj, i) for (i, obj) in enumerate(objs))
    return sorted(objs, key=lambda obj: (key(obj), idxs[obj]))

### Unit tests below ###
def check(candidate):
	assert candidate([3, 1, 2]) == [1, 2, 3]
	assert candidate(range(4), key=lambda x: -x) == [3, 2, 1, 0]
	assert candidate([1, 3, 1, 2, 2]) == [1, 1, 2, 2, 3]
	assert candidate([1, 3, 2], key=lambda x: -x) == [3, 2, 1]
	assert candidate([3, 1, 2], key=lambda x: -x) == [3, 2, 1]
	assert candidate(range(3), key=lambda x: x%4) == [0, 1, 2]
	assert candidate(range(3), key=lambda x: x%10) == [0, 1, 2]
	assert candidate(range(3), key=lambda x: x%6) == [0, 1, 2]
	assert candidate(['b', 'c', 'a']) == ['a', 'b', 'c']
	assert candidate(range(5), key=lambda x: x%2) == [0, 2, 4, 1, 3]
	assert candidate(range(100), lambda x: -x) == list(range(99, -1, -1))
	assert candidate(range(3), key=lambda x: 10 - x) == [2, 1, 0]
	assert candidate([1, 3, 2]) == [1, 2, 3]
	assert candidate(range(10), key=lambda x: x % 2) == [0, 2, 4, 6, 8, 1, 3, 5, 7, 9]
	assert candidate(range(3), key=lambda x: x) == [0, 1, 2]
	assert candidate(range(3), key=lambda x: x%5) == [0, 1, 2]
	assert candidate([1, 3, 1, 2, 2], key=lambda x: -x) == [3, 2, 2, 1, 1]
	assert candidate([1, 2, 3, 4], key=lambda x: -x) == [4, 3, 2, 1]
	assert candidate(range(5), lambda x: x % 2) == [0, 2, 4, 1, 3]
	assert candidate(range(5), key=lambda x: x) == [0, 1, 2, 3, 4]
	assert candidate(range(3), key=lambda x: x%7) == [0, 1, 2]
	assert candidate(range(5), key=lambda x: x % 2) == [0, 2, 4, 1, 3]
	assert candidate([3, 1, 2, 4, 0], key=lambda x: -x) == [4, 3, 2, 1, 0]
	assert candidate(range(3), key=lambda x: x%3) == [0, 1, 2]
	assert candidate(range(5), key=lambda x: -x) == [4, 3, 2, 1, 0]
	assert candidate([3, 1, 2], key=lambda x: x) == [1, 2, 3]
	assert candidate(range(3)) == [0, 1, 2]
	assert candidate([3, 1, 2, 4, 0]) == [0, 1, 2, 3, 4]
	assert candidate([5, 3, 2, 4, 1]) == [1, 2, 3, 4, 5]
	assert candidate(['b', 'a', 'c']) == ['a', 'b', 'c']
	assert candidate(range(3), key=lambda x: 2-x) == [2, 1, 0]
	assert candidate(range(5)) == [0, 1, 2, 3, 4]
	assert candidate(range(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(range(3), key=lambda x: x % 2) == [0, 2, 1]
	assert candidate(range(3), key=lambda x: x%9) == [0, 1, 2]
	assert candidate(range(3), key=lambda x: x % 3) == [0, 1, 2]
	assert candidate(range(3), key=lambda x: -x) == [2, 1, 0]
	assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
	assert candidate(range(3), key=lambda x: x%8) == [0, 1, 2]
	assert candidate(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(['z', 'y', 'x', 'w']) == ['w', 'x', 'y', 'z']
	assert candidate(range(5), key=lambda x: x % 3) == [0, 3, 1, 4, 2]
	assert candidate(range(4)) == [0, 1, 2, 3]
	assert candidate(range(100)) == list(range(100))
def test_check():
	check(csort)
