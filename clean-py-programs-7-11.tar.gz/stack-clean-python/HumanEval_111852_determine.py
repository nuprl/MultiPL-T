def determine(userChoice, computerChoice):
    """
        This function takes in two arguments userChoice and computerChoice,
        then determines and returns that who wins.
    """
    ### Canonical solution below ###
    if(userChoice == "Rock" and computerChoice == "Paper"):
        return "computer"
    elif(userChoice == "Rock" and computerChoice == "Scissors"):
        return "user"
    elif(userChoice == "Paper" and computerChoice == "Rock"):
        return "user"
    elif(userChoice == "Paper" and computerChoice == "Scissors"):
        return "computer"
    elif(userChoice == "Scissors" and computerChoice == "Paper"):
        return "user"
    elif(userChoice == "Scissors" and computerChoice == "Rock"):
        return "computer"
    else:
        return "tie"


### Unit tests below ###
def check(candidate):
	assert candidate(userChoice="Paper", computerChoice="Paper") == "tie"
	assert candidate(userChoice="Paper", computerChoice="Rock") == "user"
	assert candidate("Rock", "Paper") == "computer"
	assert candidate(userChoice="Paper", computerChoice="Paper") == "tie", "Tie"
	assert candidate(userChoice="Paper", computerChoice="Scissors") == "computer", "Scissors beats Paper"
	assert candidate(userChoice="Paper", computerChoice="Scissors") == "computer"
	assert candidate(userChoice="Rock", computerChoice="Paper") == "computer", "Should be computer"
	assert candidate("Scissors", "Paper") == "user", "Should be user"
	assert candidate(userChoice="Scissors", computerChoice="Rock") == "computer", "Rock beats Scissors"
	assert candidate("Paper", "Rock") == "user"
	assert candidate(userChoice="Rock", computerChoice="Rock") == "tie"
	assert candidate(candidate(2,2),"tie") == "tie"
	assert candidate(userChoice="Rock", computerChoice="Scissors") == "user", "Should be user"
	assert candidate("Rock", "Scissors") == "user"
	assert candidate(userChoice="Paper", computerChoice="Rock") == "user", "should return user"
	assert candidate(
    "Paper", "Rock") == "user"
	assert candidate(userChoice = "Scissors", computerChoice = "Paper") == "user"
	assert candidate(
    "Scissors", "Paper") == "user"
	assert candidate(candidate(3,3),"tie") == "tie"
	assert candidate(userChoice="Scissors", computerChoice="Scissors") == "tie", "Tie"
	assert candidate(userChoice="Paper", computerChoice="Scissors") == "computer", "should return computer"
	assert candidate(userChoice="Scissors", computerChoice="Rock") == "computer", "Should be computer"
	assert candidate(userChoice="Scissors", computerChoice="Rock") == "computer"
	assert candidate(userChoice="Scissors", computerChoice="Scissors") == "tie", "Should be tie"
	assert candidate( "Paper", "Rock") == "user", "Should return user"
	assert candidate("Rock", "Paper") == "computer", "Should be computer"
	assert candidate(
    "Rock", "Paper") == "computer"
	assert candidate(userChoice="Rock", computerChoice="Paper") == "computer", "Paper beats Rock"
	assert candidate(userChoice = "Paper", computerChoice = "Rock") == "user"
	assert candidate(userChoice="Scissors", computerChoice="Paper") == "user", "Should be user"
	assert candidate(userChoice="Scissors", computerChoice="Paper") == "user", "should return user"
	assert candidate("Rock", "Rock") == "tie", "Should be tie"
	assert candidate(
    "Scissors", "Rock") == "computer"
	assert candidate( "Scissors", "Scissors") == "tie", "Should return tie"
	assert candidate("Scissors", "Rock") == "computer", "Should be computer"
	assert candidate(userChoice="Scissors", computerChoice="Paper") == "user", "Scissors beats Paper"
	assert candidate( "Scissors", "Rock") == "computer", "Should return computer"
	assert candidate(userChoice = "Rock", computerChoice = "Rock") == "tie"
	assert candidate(userChoice="Rock", computerChoice="Scissors") == "user", "Rock beats Scissors"
	assert candidate(userChoice="Paper", computerChoice="Rock") == "user", "Should be user"
	assert candidate(candidate(1,1),"tie") == "tie"
	assert candidate( "Rock", "Rock") == "tie", "Should return tie"
	assert candidate(userChoice="Rock", computerChoice="Paper") == "computer", "should return computer"
	assert candidate(userChoice = "Scissors", computerChoice = "Rock") == "computer"
	assert candidate(userChoice="Scissors", computerChoice="Scissors") == "tie"
	assert candidate(userChoice="Paper", computerChoice="Rock") == "user", "Paper beats Rock"
	assert candidate(userChoice="Rock", computerChoice="Paper") == "computer"
	assert candidate(
    "Rock", "Scissors") == "user"
	assert candidate(userChoice="Rock", computerChoice="Rock") == "tie", "Should be tie"
	assert candidate(
    "Rock", "Rock") == "tie"
	assert candidate(userChoice="Scissors", computerChoice="Rock") == "computer", "should return computer"
	assert candidate( "Paper", "Paper") == "tie", "Should return tie"
	assert candidate( "Rock", "Paper") == "computer", "Should return computer"
	assert candidate(
    "Paper", "Scissors") == "computer"
	assert candidate(userChoice="Rock", computerChoice="Rock") == "tie", "should return tie"
	assert candidate(userChoice = "Paper", computerChoice = "Paper") == "tie"
	assert candidate(userChoice = "Scissors", computerChoice = "Scissors") == "tie"
	assert candidate(userChoice="Rock", computerChoice="Rock") == "tie", "Tie"
	assert candidate(userChoice = "Paper", computerChoice = "Scissors") == "computer"
	assert candidate( "Paper", "Scissors") == "computer", "Should return computer"
	assert candidate(userChoice = "Rock", computerChoice = "Scissors") == "user"
	assert candidate( "Rock", "Scissors") == "user", "Should return user"
	assert candidate(userChoice="Paper", computerChoice="Paper") == "tie", "Should be tie"
	assert candidate(userChoice="Rock", computerChoice="Scissors") == "user", "should return user"
	assert candidate(userChoice="Scissors", computerChoice="Paper") == "user"
	assert candidate("Paper", "Scissors") == "computer"
	assert candidate(userChoice="Rock", computerChoice="Scissors") == "user"
	assert candidate(userChoice="Paper", computerChoice="Scissors") == "computer", "Should be computer"
	assert candidate(userChoice = "Rock", computerChoice = "Paper") == "computer"
	assert candidate( "Scissors", "Paper") == "user", "Should return user"
def test_check():
	check(determine)
