def _is_inside(cp1, cp2, p):
    """ Returns true if inside"""
	### Canonical solution below ###    
    return (
        (cp2[0]-cp1[0])*(p[1]-cp1[1]) > (cp2[1]-cp1[1])*(p[0]-cp1[0])
    )

### Unit tests below ###
def check(candidate):
	assert candidate( (0,0), (1,0), (0.5, 0.1) ) == True
	assert candidate( (0,0), (10,0), (5,5) ) == True
	assert not candidate(
    (0, 0), (1, 0), (0.5, -0.5)
)
	assert candidate(
    (0, 0),
    (1, 0),
    (0, 1)
) == True
	assert candidate( (0,0), (1,0), (0.5,0.5) )
	assert candidate(
    (0, 0),
    (1, 1),
    (0.5, 1.5)
)
	assert candidate(cp1=(0, 0), cp2=(1, 1), p=(1.5, 1.5)) == False
	assert candidate(cp1=(0, 0), cp2=(0, 1), p=(0, 1)) == False
	assert candidate(
    [0, 0], [10, 0], [10, 1]
)
	assert candidate( (0,0), (1,0), (0.5, 0.5) )
	assert not candidate( (0,0), (1,0), (-0.5,0) )
	assert not candidate(
    (0, 0),
    (1, 1),
    (0.5, -0.5)
)
	assert candidate(cp1=(0, 0), cp2=(1, 1), p=(1, 1)) == False
	assert candidate(cp1=(0, 0), cp2=(0, 1), p=(0, 1.5)) == False
	assert candidate(
    (0, 0),
    (0, 1),
    (0, 1.5)
) == False
	assert not candidate( (0,0), (1,0), (-0.5,-0.5) )
	assert candidate(
    (0, 0),
    (0, 1),
    (1.5, 1.5)
) == False
	assert candidate(cp1=(0, 0), cp2=(1, 0), p=(1, 0)) == False
	assert candidate( (0,0), (1,0), (0.5, 0.5) ) == True
	assert candidate( (0,0), (1,0), (1.5, 0.5) ) == True
	assert candidate( (0,0), (0,1), (0,1.5) ) == False
	assert candidate(
    [0, 0], [10, 0], [5, 1]
)
	assert candidate(
    (0, 0),
    (0, 2),
    (2, 1)
) == False
	assert candidate(
    [0, 0], [10, 0], [0, 1]
)
	assert candidate( (0,0), (0.5,0.5), (0.75, 0.25)) == False
	assert candidate( (0,0), (1,0), (-0.5, 0.5) )
	assert not candidate( (0,0), (1,0), (-2, -2) )
	assert candidate( (0,0), (1,1), (1.5,1.5) ) == False
	assert not candidate(
    (0, 0),
    (1, 0),
    (0.5, -0.5)
)
	assert candidate(cp1=(0, 0), cp2=(1, 0), p=(1.5, 0)) == False
	assert candidate( (0,0), (2,2), (3,3) ) == False
	assert not candidate( (0,0), (1,1), (-1, -1) )
	assert not candidate( (0,0), (0,1), (1,1) )
	assert candidate(
    (0, 0),
    (1, 0),
    (1.5, 0)
) == False
	assert not candidate(
    (0, 0),
    (1, 1),
    (1.5, 0.5)
)
	assert not candidate(
    (0, 0),
    (1, 1),
    (2.0, 2.0)
)
	assert not candidate(
    (0, 0),
    (1, 1),
    (-0.5, -0.5)
)
	assert candidate( (0,0), (2,3), (3,2) ) == False
	assert candidate( (0,0), (1,0), (0, 1) )
	assert candidate(
    (1, 1),
    (3, 3),
    (4, 4)
) == False
	assert not candidate( (0, 0), (1, 0), (2, 0) )
	assert candidate(
    (0, 0), (1, 0), (1.5, 0)
) == False
	assert candidate( (0,0), (0,1), (0.1, 0.51) ) == False
	assert not candidate(
    (0,0),
    (1,1),
    (2,2)
)
	assert not candidate(
    (1,1), (1,2), (2,1)
)
	assert candidate(
    (0, 0),
    (0, 0),
    (0, 1)
) == False
	assert not candidate(
    [0, 0], [10, 0], [-1, -1]
)
	assert candidate( (0,0), (1,1), (1.5,0.5) ) == False
	assert not candidate(
    (0, 0),
    (1, 1),
    (2, 2)
)
	assert candidate(
    (0, 0), (1, 0), (0.5, -1)
) == False
	assert not candidate(
    (0, 0),
    (1, 1),
    (0.5, -1.5)
)
	assert candidate(
    (0, 0),
    (1, 1),
    (1, 1)
) == False
	assert candidate(
    (0,0), (1,0), (0.5, -0.5)
) == False
	assert not candidate( (0, 0), (1, 1), (2, 2) )
	assert not candidate(
    [0, 0], [10, 0], [5, -1]
)
	assert candidate(
    (0, 0),
    (1, 0),
    (0.5, 0.5)
)
	assert candidate(
    (1, 1),
    (1, 3),
    (1, 1)
) == False
	assert not candidate(
    (1,1), (1,2), (2,1.5)
)
	assert candidate(
    (0, 0),
    (2, 0),
    (3, 1)
) == True
	assert candidate( (0,0), (1,0), (-1, -1) ) == False
	assert candidate(
    (0,0),
    (1,1),
    (0.5,1.5)
)
	assert candidate( (0,0), (2,3), (3,4) ) == False
	assert candidate(
    (0, 0),
    (0, 1),
    (0.5, 0.5)
) == False
	assert not candidate(
    (1,1), (1,2), (1,2.5)
)
	assert candidate( (0,0), (1,0), (1.5,0) ) == False
	assert candidate(
    (0, 0),
    (1, 1),
    (1, 0)
) == False
	assert candidate(
    (1, 1),
    (1, 3),
    (1, 3)
) == False
	assert candidate(
    (0, 0),
    (2, 0),
    (1, 1)
)
	assert not candidate(
    [0, 0],
    [2, 2],
    [3, 3]
)
	assert candidate( (0,0), (0,1), (0.5, -0.5)) == False
	assert candidate(
    (0, 0), (1, 0), (0, -1)
) == False
	assert candidate(
    (0, 0),
    (1, 0),
    (0, 0)
) == False
	assert not candidate( (0,0), (1,1), (2, 2) )
	assert candidate(
    (0, 0),
    (1, 1),
    (-1, -1)
) == False
	assert candidate( (0,0), (0,1), (1.5, 0.5) ) == False
	assert candidate(
    (0, 0), (1, 0), (-1, 0)
) == False
	assert candidate(
    (0, 0),
    (1, 1),
    (1.5, 1.5)
) == False
	assert not candidate( (0,0), (1,0), (0,-0.5) )
	assert candidate( (0,0), (1,0), (0,0.5) )
	assert candidate( (0,0), (1,0), (0.5, -1) ) == False
	assert candidate(
    (0, 0), (1, 0), (0.5, 0.5)
)
	assert candidate( (0,0), (1,1), (0.51, 0.5) ) == False
	assert candidate(
    (0,0), (1,0), (0.5, 0.5)
) == True
	assert candidate(
    (0, 0),
    (0, 0),
    (1.5, 1.5)
) == False
	assert not candidate(
    [0, 0], [10, 0], [10, -1]
)
def test_check():
	check(_is_inside)
