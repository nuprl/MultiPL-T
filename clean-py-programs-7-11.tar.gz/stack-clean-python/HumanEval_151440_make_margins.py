def make_margins(width, height, left=0, right=0, top=0, bottom=0, margins=None):
    """ Create Matplotlib margins. Returns tuple that can be unpacked for subplots_adjust with *
     Args:
     width, height: figure size
     margins: equal margins all around
     left, right, top, bottom: set individual margins
     """
	### Canonical solution below ###    
    if margins: 
        left = margins
        right = margins
        top = margins
        bottom = margins

    LM = left/width
    BM = bottom/height
    RM = 1-right/width
    TM = 1-top/height
    return LM, BM, RM, TM

### Unit tests below ###
def check(candidate):
	assert candidate(100,100,margins=5) == (0.05,0.05,0.95,0.95)
	assert candidate(400, 400, margins=50) == (0.125, 0.125, 0.875, 0.875)
	assert candidate(20, 20) == (0, 0, 1, 1)
	assert candidate(100, 100, left=0, right=0, top=0, bottom=0, margins=0) == (0, 0, 1, 1)
	assert candidate(10, 10) == (0, 0, 1, 1)
	assert candidate(100, 100, right=50) == (0, 0, 0.5, 1)
	assert candidate(500, 500, 0, 0, 0, 0) == (0.0, 0.0, 1.0, 1.0)
	assert candidate(100, 100, margins=10) == (0.1, 0.1, 0.9, 0.9)
	assert candidate(100, 100) == (0, 0, 1, 1)
	assert candidate(100, 100, margins=50) == (0.5, 0.5, 0.5, 0.5)
def test_check():
	check(make_margins)
