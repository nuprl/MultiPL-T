def write_header(header):
    """ Write the header. Not implemented."""
	### Canonical solution below ###    
    return (header or [])

### Unit tests below ###
def check(candidate):
	assert candidate(["foo", "bar"]) == ["foo", "bar"]
	assert candidate(['A', 'B']) == ['A', 'B']
	assert candidate([('name', 'value')]) == [('name', 'value')]
	assert candidate(["foo"]) == ["foo"]
	assert candidate(['a']) == ['a']
	assert candidate(["a", "b", "c"]) == ["a", "b", "c"]
	assert candidate([1, 2]) == [1, 2]
	assert candidate([1,2,3]) == [1,2,3], "candidate should return list"
	assert candidate([
    'a', 'b', 'c', 'd', 'e'
]) == [
    'a', 'b', 'c', 'd', 'e'
]
	assert candidate(['A']) == ['A']
	assert candidate(["#A comment"]) == ["#A comment"]
	assert candidate([('foo', 42)]) == [('foo', 42)]
	assert candidate(["#1", "#2"]) == ["#1", "#2"]
	assert candidate(['foo']) == ['foo']
	assert candidate(['a', 'b']) == ['a', 'b']
	assert candidate(None) == []
	assert candidate(["A"]) == ["A"]
	assert candidate([['A', 'B'], ['1', '2']]) == [['A', 'B'], ['1', '2']]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(["#A comment", "A header"]) == ["#A comment", "A header"]
	assert candidate([1,2,3]) == [1,2,3]
	assert candidate([('a', 'b')]) == [('a', 'b')]
	assert candidate(['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']
	assert candidate(None) == [], "candidate should return empty list"
	assert candidate(['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate([]) == []
	assert candidate([1]) == [1]
	assert candidate(["A", "B"]) == ["A", "B"]
	assert candidate(["line1\n", "line2\n"]) == ["line1\n", "line2\n"]
	assert candidate(["A", "B", "C"]) == ["A", "B", "C"]
	assert candidate(['foo', 'bar']) == ['foo', 'bar']
def test_check():
	check(write_header)
