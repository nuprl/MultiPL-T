def __create_help_description(indent, options, long_descriptions):
    """
    Create a description that is shown for the help option.

    :param indent: How much to indent the description.
    :type indent: str
    :param options: The available options.
    :type options: list
    :param long_descriptions: Long descriptions for all options.
    :type long_descriptions: list
    :return: The help description.
    :rtype: str
    """
    ### Canonical solution below ###

    help_description = "\n{}Valid answers are".format(indent)

    for option, long_description in zip(options, long_descriptions):
        help_description += "\n{}'{}' for {}".format(indent, option, long_description)

    help_description += ": "
    return help_description


### Unit tests below ###
def check(candidate):
	assert candidate(indent="  ", options=["a", "b", "c"], long_descriptions=["A", "B", "C"]) == \
       "\n  Valid answers are\n  'a' for A\n  'b' for B\n  'c' for C: "
	assert candidate(indent="    ", options=["a", "b"], long_descriptions=["A", "B"]) == "\n    Valid answers are\n    'a' for A\n    'b' for B: "
	assert candidate(indent=" ", options=["a", "b", "c"], long_descriptions=["A", "B", "C"]) == "\n Valid answers are\n 'a' for A\n 'b' for B\n 'c' for C: "
	assert candidate(
    "    ",
    ["a", "b", "c"],
    ["alpha", "beta", "gamma"]
) == """
    Valid answers are
    'a' for alpha
    'b' for beta
    'c' for gamma: """
	assert candidate(
    "",
    ["a", "b", "c"],
    ["A", "B", "C"]
) == "\nValid answers are\n'a' for A\n'b' for B\n'c' for C: "
	assert candidate(
    "    ",
    ["a", "b", "c"],
    ["The first option.", "The second option.", "The third option."]
) == """
    Valid answers are
    'a' for The first option.
    'b' for The second option.
    'c' for The third option.: """
	assert candidate(indent="    ", options=["a", "b"], long_descriptions=["A", "B"]) == """
    Valid answers are
    'a' for A
    'b' for B: """
	assert candidate(
    "", ["a", "b", "c"], ["First option", "Second option", "Third option"]) == \
    "\nValid answers are\n'a' for First option\n'b' for Second option\n'c' for Third option: "
	assert candidate(indent="  ", options=["A", "B", "C"], long_descriptions=["Long A", "Long B", "Long C"]) == \
    "\n  Valid answers are\n  'A' for Long A\n  'B' for Long B\n  'C' for Long C: "
	assert candidate(indent="", options=["A", "B"], long_descriptions=["C", "D"]) == "\nValid answers are\n'A' for C\n'B' for D: "
	assert candidate(indent="", options=[], long_descriptions=[]) == "\nValid answers are: "
	assert candidate(
    indent="",
    options=["1", "2"],
    long_descriptions=["Description 1", "Description 2"]
) == "\nValid answers are\n'1' for Description 1\n'2' for Description 2: "
	assert candidate(
    indent="",
    options=["a", "b", "c"],
    long_descriptions=["the first option", "the second option", "the third option"]) == """
Valid answers are
'a' for the first option
'b' for the second option
'c' for the third option: """
	assert candidate(indent="", options=["a", "b", "c"], long_descriptions=["1", "2", "3"]) == "\nValid answers are\n'a' for 1\n'b' for 2\n'c' for 3: "
	assert candidate(
    indent="    ",
    options=["a", "b", "c"],
    long_descriptions=["This is a", "This is b", "This is c"]
) == """
    Valid answers are
    'a' for This is a
    'b' for This is b
    'c' for This is c: """
	assert candidate(
    "",
    ["a", "b", "c"],
    ["The first option", "The second option", "The third option"]
) == "\nValid answers are\n'a' for The first option\n'b' for The second option\n'c' for The third option: "
	assert candidate(indent="", options=["a", "b"], long_descriptions=["A", "B"]) == \
    "\nValid answers are\n'a' for A\n'b' for B: "
	assert candidate(indent="", options=["a", "b", "c"], long_descriptions=["A", "B", "C"]) == \
    "\nValid answers are\n'a' for A\n'b' for B\n'c' for C: "
	assert candidate(indent="  ", options=["a", "b"], long_descriptions=["A", "B"]) == \
       "\n  Valid answers are\n  'a' for A\n  'b' for B: "
	assert candidate(
    "",
    ["a", "b", "c"],
    ["A", "B", "C"],
) == "\nValid answers are\n'a' for A\n'b' for B\n'c' for C: "
	assert candidate(indent="  ", options=["a", "b"], long_descriptions=["aa", "bb"]) == "\n  Valid answers are\n  'a' for aa\n  'b' for bb: "
	assert candidate(indent="", options=["a", "b"], long_descriptions=["aa", "bb"]) == "\nValid answers are\n'a' for aa\n'b' for bb: "
	assert candidate(indent="", options=["a", "b"], long_descriptions=["A", "B"]) == "\nValid answers are\n'a' for A\n'b' for B: "
	assert candidate(indent="  ", options=["a", "b", "c"], long_descriptions=["1", "2", "3"]) == "\n  Valid answers are\n  'a' for 1\n  'b' for 2\n  'c' for 3: "
	assert candidate(indent="",
                                options=["a", "b"],
                                long_descriptions=["A", "B"]) == \
    "\nValid answers are\n'a' for A\n'b' for B: "
	assert candidate(indent="",
                                options=["1", "2"],
                                long_descriptions=["First option", "Second option"]) == \
       "\nValid answers are\n'1' for First option\n'2' for Second option: "
	assert candidate(
    indent="",
    options=["a", "b"],
    long_descriptions=["First option", "Second option"],
) == "\nValid answers are\n'a' for First option\n'b' for Second option: "
def test_check():
	check(__create_help_description)
