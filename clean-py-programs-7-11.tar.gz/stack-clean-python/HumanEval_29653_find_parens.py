def find_parens(s):
    """Get indices of matching parantheses in a string."""
    ### Canonical solution below ###
    # Source: https://stackoverflow.com/questions/29991917/indices-of-matching-parentheses-in-python
    
    toret = {}
    pstack = []

    for i, c in enumerate(s):
        if c == '(':
            pstack.append(i)
        elif c == ')':
            if len(pstack) == 0:
                raise IndexError("No matching closing parens ')' at: " + str(i) + s)
            toret[pstack.pop()] = i

    if len(pstack) > 0:
        raise IndexError("No matching opening parens '(' at: " + str(pstack.pop())+s)

    return toret


### Unit tests below ###
def check(candidate):
	assert candidate(s='()') == {0:1}
	assert candidate("()") == {0: 1}
	assert candidate(r"a") == {}
	assert candidate(r'((a+b)*(c+d))') == candidate(r'((a+b)*(c+d))')
	assert candidate(r"") == {}
	assert candidate(s='(a)') == {0:2}
	assert candidate(r'()') == {0: 1}
	assert candidate(r"abc(def(ghi)jkl)mno(pqr(stu(vwx)y)xyz(123))456(789)")
	assert candidate(r"(a)") == {0: 2}
	assert candidate(r"abc") == {}
	assert candidate(r'()') == {0:1}
	assert candidate(r'abc') == {}
def test_check():
	check(find_parens)
