def _compute_fans_stacked(shape):
    """Computes the number of input and output units for a weight shape.

    Args:
        shape: Integer shape tuple or TF tensor shape.

    Returns:
        A tuple of scalars (fan_in, fan_out).
    """
    ### Canonical solution below ###
    if len(shape) < 1:  # Just to avoid errors for constants.
        fan_in = fan_out = 1
    elif len(shape) == 1:
        fan_in = fan_out = shape[0]
    elif len(shape) == 2:
        # Assuming stacked NN.
        # kernel shape: (num_stack, fan_in)
        fan_in = shape[1]
        fan_out = 1
    else:
        # Assuming stacked NN.
        # kernel shape: (..., fan_in, fan_out)
        fan_in = shape[-2]
        fan_out = shape[-1]
    return fan_in, fan_out


### Unit tests below ###
def check(candidate):
	assert candidate(shape=(2, 3, 4)) == (3, 4)
	assert candidate(shape=(1, 1, 2)) == (1, 2)
	assert candidate(shape=(4, 5)) == (5, 1)
	assert candidate(shape=(2, 2, 2)) == (2, 2)
	assert candidate(shape=(2, 3)) == (3, 1)
	assert candidate((1, 2, 3)) == (2, 3)
	assert candidate(shape=(2, 2, 2, 2, 2)) == (2, 2)
	assert candidate((2, 3)) == (3, 1)
	assert candidate(shape=(3,)) == (3, 3)
	assert candidate(shape=(2, 2, 2, 2)) == (2, 2)
	assert candidate(shape=(1, 1, 1)) == (1, 1)
	assert candidate(shape=(6, 7)) == (7, 1)
	assert candidate((2, 3, 4)) == (3, 4)
	assert candidate(shape=(5, 5)) == (5, 1)
	assert candidate(shape=(2, 2, 1)) == (2, 1)
	assert candidate(shape=(2, 3, 4, 5, 6)) == (5, 6)
	assert candidate(shape=(3, 3)) == (3, 1)
	assert candidate(shape=(6, 6)) == (6, 1)
	assert candidate(shape=(9, 9)) == (9, 1)
	assert candidate(shape=(10,)) == (10, 10)
	assert candidate(shape=(7, 7)) == (7, 1)
	assert candidate(shape=(1, 2)) == (2, 1)
	assert candidate(shape=(7, 8)) == (8, 1)
	assert candidate((1, 1)) == (1, 1)
	assert candidate(shape=(1, 2, 3)) == (2, 3)
	assert candidate(shape=(5, 6)) == (6, 1)
	assert candidate(shape=(3, 4)) == (4, 1)
	assert candidate(shape=(4, 4)) == (4, 1)
	assert candidate(shape=(1, 2, 2)) == (2, 2)
	assert candidate(shape=(2, 3, 1)) == (3, 1)
	assert candidate(shape=(1, 1, 1, 1)) == (1, 1)
	assert candidate(shape=(1, 1)) == (1, 1)
	assert candidate(shape=(8, 8)) == (8, 1)
	assert candidate((1, 1, 1, 1, 1)) == (1, 1)
	assert candidate(shape=(3, 5, 10)) == (5, 10)
	assert candidate(shape=(2, 1)) == (1, 1)
	assert candidate(shape=(8, 9)) == (9, 1)
	assert candidate((1, 2)) == (2, 1)
	assert candidate(shape=(1,)) == (1, 1)
	assert candidate(shape=(1, 2, 1)) == (2, 1)
	assert candidate(shape=(2, 2)) == (2, 1)
	assert candidate(shape=(2, 3, 2)) == (3, 2)
def test_check():
	check(_compute_fans_stacked)
