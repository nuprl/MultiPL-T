def _firstResult(gen):
    """ 
     Return the first element of a generator and exhaust it.
     
     C{MethodicalMachine.upon}'s C{collector} argument takes a generator of
     output results. If the generator is exhausted, the later outputs aren't
     actually run.
     
     @param gen: Generator to extract values from
     
     @return: The first element of the generator.
     """
	### Canonical solution below ###    
    return list(gen)[0]

### Unit tests below ###
def check(candidate):
	assert candidate(iter(range(1, 3))) == 1
	assert candidate(iter([1,2,3])) == 1
	assert candidate(x for x in range(3)) == 0
	assert candidate(iter([1, 2, 3])) == 1
	assert candidate(iter(range(2, 5))) == 2
	assert candidate(iter(range(5))) == 0
	assert candidate(iter([0,1,2])) == 0
	assert candidate(iter([1])) == 1
	assert candidate(range(3)) == 0
	assert candidate(iter(range(3))) == 0
def test_check():
	check(_firstResult)
