def make_binary_operator_eval(oper, f, g):
    """ 
     Given a binary operator (as a callable of two arguments) ``oper`` and
     two callables ``f`` and ``g`` which accept the same arguments,
     returns a *new* function that takes the same arguments as ``f`` and ``g``,
     but passes the outputs of ``f`` and ``g`` in the given ``oper``.
     
     ``f`` and ``g`` are assumed to return tuples (which may be 1-tuples).  The
     given operator is applied element-wise to tuple outputs).
     
     Example
     -------
     
     >>> from operator import add
     >>> def prod(x, y):
     ...     return (x * y,)
     ...
     >>> sum_of_prod = make_binary_operator_eval(add, prod, prod)
     >>> sum_of_prod(3, 5)
     (30,)
     """
	### Canonical solution below ###    

    return lambda inputs, params: \
            tuple(oper(x, y) for x, y in zip(f(inputs, params),
                                             g(inputs, params)))

### Unit tests below ###
def check(candidate):
	assert candidate(lambda x, y: x + y,
                                 lambda x, y: (x,),
                                 lambda x, y: (y,))(1, 2) == (3,)
	assert candidate(pow, lambda x, y: (x,), lambda x, y: (y,))(3, 5) == (243,)
	assert candidate(lambda x, y: x + y,
                                 lambda x, y: (x,),
                                 lambda x, y: (y,))((), ()) == ((),)
	assert candidate(lambda x, y: x + y,
                                 lambda x, y: (x,),
                                 lambda x, y: (y,))(3, 5) == (8,)
def test_check():
	check(make_binary_operator_eval)
