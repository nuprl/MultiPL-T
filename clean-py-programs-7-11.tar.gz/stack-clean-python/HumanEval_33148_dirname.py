def dirname(path):
    """ Returns the directory's name.
     
     Args:
     path: The path to return the directory for
     
     Returns:
     The directory's name.
     """
	### Canonical solution below ###    
    last_sep = path.rfind("/")
    if last_sep == -1:
        return ""
    return path[:last_sep]

### Unit tests below ###
def check(candidate):
	assert candidate("/foo/bar/") == "/foo/bar"
	assert candidate("//foo/bar/baz") == "//foo/bar"
	assert candidate(r"Users/foo/bar") == r"Users/foo"
	assert candidate(r"foo") == r""
	assert candidate(r"foo") == ""
	assert candidate(r"/Users/foo/bar") == r"/Users/foo"
	assert candidate(r"a/b") == r"a"
	assert candidate("/a/b/c") == "/a/b"
	assert candidate("/foo/bar") == "/foo"
	assert candidate("http://foo/bar/baz") == "http://foo/bar"
	assert candidate("foo/bar") == "foo"
	assert candidate("a") == ""
	assert candidate("a/b/c") == "a/b"
	assert candidate("foo") == ""
	assert candidate(r"foo/bar/") == r"foo/bar"
	assert candidate(r"/a/") == r"/a"
	assert candidate("foo/bar/baz") == "foo/bar"
	assert candidate("a/b") == "a"
	assert candidate(r"a/") == r"a"
	assert candidate("foo/bar/") == "foo/bar"
	assert candidate(r"") == ""
	assert candidate(r"/foo/bar/") == r"/foo/bar"
	assert candidate("/foo/bar/baz") == "/foo/bar"
	assert candidate(r"/a/b/c") == r"/a/b"
	assert candidate(r"") == r""
	assert candidate(r"a/b/c") == r"a/b"
	assert candidate(r"/foo/bar") == r"/foo"
	assert candidate(r"a") == ""
	assert candidate(r"foo/bar") == r"foo"
	assert candidate("") == ""
	assert candidate("foo/") == "foo"
	assert candidate(r"/a/b") == r"/a"
def test_check():
	check(dirname)
