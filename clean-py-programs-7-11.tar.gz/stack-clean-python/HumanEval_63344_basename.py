def basename(addr):
    """
    input a full address\n
    return the base file name
    """
    ### Canonical solution below ###
    import os
    return os.path.basename(addr)


### Unit tests below ###
def check(candidate):
	assert candidate(r'Users/1/Desktop/test.py') == 'test.py'
	assert candidate(r'/test/test/test') == 'test'
	assert candidate(r"c:/users/a/b/c/d.txt") == "d.txt"
	assert candidate(r"c:\users\a\b/c/d.txt") == "d.txt"
	assert candidate(r"file.ext") == "file.ext"
	assert candidate(r'/test/test/test.txt') == 'test.txt'
	assert candidate(r'C:\Users\ZHA244\Desktop\123.txt')!= '.txt'
	assert candidate(r'Users/1/Desktop/test') == 'test'
	assert candidate(r"C:/file.ext") == "file.ext"
	assert candidate(r'C:\Users\ZHA244\Desktop\123.txt')!= '123'
	assert candidate(r'C:\Users\ZHA244\Desktop\123.txt')!= 'C:/Users/ZHA244/Desktop/123.txt'
	assert candidate(r'C:\Users\ZHA244\Desktop\123.txt')!= r'C:/Users/ZHA244/Desktop/123.txt'
	assert candidate('test') == 'test'
	assert candidate('test.txt') == 'test.txt'
	assert candidate(r'/Users/1/Desktop/test') == 'test'
	assert candidate(r'/Users/Allen/Desktop/test/') == ''
	assert candidate(r'C:\Users\ZHA244\Desktop\123.txt')!= '123.txt.py'
	assert candidate(r'C:\Users\ZHA244\Desktop\123.txt')!= '123.py'
	assert candidate("a/b/c") == "c"
	assert candidate(r"C:\Program Files\Python36\\a.txt")
	assert candidate(r"C:\Users\Todd.Hay\Desktop\test.txt")!= "test.doc"
	assert candidate("os.py") == "os.py"
	assert candidate(r'C:/Users/Allen/Desktop/test.py') == 'test.py'
	assert candidate('test/test.txt') == 'test.txt'
	assert candidate('test/test') == 'test'
	assert candidate(r'/test/test.txt') == 'test.txt'
	assert candidate(r'/test/test') == 'test'
	assert candidate(r'/Users/Allen/Desktop/test.py') == 'test.py'
	assert candidate(r"C:\Users\Todd.Hay\Desktop\test.txt")!= "test"
	assert candidate(r'/Users/1/Desktop/test.py') == 'test.py'
	assert candidate(r'/Users/Allen/Desktop/test') == 'test'
	assert candidate(r"/file.ext") == "file.ext"
def test_check():
	check(basename)
