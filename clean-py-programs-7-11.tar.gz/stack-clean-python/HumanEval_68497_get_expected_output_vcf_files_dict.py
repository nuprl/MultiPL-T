def get_expected_output_vcf_files_dict(base_out):
    """ 
     :param base_out: Base path structure for vcf files. For example, if the expected path for
     the log is 'work/step.path/log/step.vcf.gz', the argument should be
     'work/step.path/log/step'.
     :type base_out: str
     
     :return: Returns dictionary with expected path for vcf related files based on the
     provided input.
     """
	### Canonical solution below ###    
    # Define expected
    expected = {
        "vcf": base_out + ".vcf.gz",
        "vcf_md5": base_out + ".vcf.gz.md5",
        "tbi": base_out + ".vcf.gz.tbi",
        "tbi_md5": base_out + ".vcf.gz.tbi.md5",
    }
    # Return
    return expected

### Unit tests below ###
def check(candidate):
	assert candidate(base_out="work/test/path/step") == {
    "vcf": "work/test/path/step.vcf.gz",
    "vcf_md5": "work/test/path/step.vcf.gz.md5",
    "tbi": "work/test/path/step.vcf.gz.tbi",
    "tbi_md5": "work/test/path/step.vcf.gz.tbi.md5",
}
	assert candidate(base_out="work/foo/bar") == {
    "vcf": "work/foo/bar.vcf.gz",
    "vcf_md5": "work/foo/bar.vcf.gz.md5",
    "tbi": "work/foo/bar.vcf.gz.tbi",
    "tbi_md5": "work/foo/bar.vcf.gz.tbi.md5",
}
	assert candidate(base_out="work/test.path/log/test") == \
    {"vcf": "work/test.path/log/test.vcf.gz",
     "vcf_md5": "work/test.path/log/test.vcf.gz.md5",
     "tbi": "work/test.path/log/test.vcf.gz.tbi",
     "tbi_md5": "work/test.path/log/test.vcf.gz.tbi.md5"}
	assert candidate(base_out="work/test.path/log/test") == {
    "vcf": "work/test.path/log/test.vcf.gz",
    "vcf_md5": "work/test.path/log/test.vcf.gz.md5",
    "tbi": "work/test.path/log/test.vcf.gz.tbi",
    "tbi_md5": "work/test.path/log/test.vcf.gz.tbi.md5",
}
	assert candidate(base_out='work/bwa.mem/out') == {
    'vcf': 'work/bwa.mem/out.vcf.gz',
    'vcf_md5': 'work/bwa.mem/out.vcf.gz.md5',
    'tbi': 'work/bwa.mem/out.vcf.gz.tbi',
    'tbi_md5': 'work/bwa.mem/out.vcf.gz.tbi.md5'
}
	assert candidate(base_out="work/step.path/log/step") == \
       {'vcf': 'work/step.path/log/step.vcf.gz',
        'vcf_md5': 'work/step.path/log/step.vcf.gz.md5',
        'tbi': 'work/step.path/log/step.vcf.gz.tbi',
        'tbi_md5': 'work/step.path/log/step.vcf.gz.tbi.md5'}
	assert candidate(base_out="work/bwa.step") == {
    "vcf": "work/bwa.step.vcf.gz",
    "vcf_md5": "work/bwa.step.vcf.gz.md5",
    "tbi": "work/bwa.step.vcf.gz.tbi",
    "tbi_md5": "work/bwa.step.vcf.gz.tbi.md5",
}
	assert candidate(
    base_out="work/my_step/output/my_step"
) == {
    "vcf": "work/my_step/output/my_step.vcf.gz",
    "vcf_md5": "work/my_step/output/my_step.vcf.gz.md5",
    "tbi": "work/my_step/output/my_step.vcf.gz.tbi",
    "tbi_md5": "work/my_step/output/my_step.vcf.gz.tbi.md5",
}
	assert candidate(base_out="work/output/vcf") == {
    "vcf": "work/output/vcf.vcf.gz",
    "vcf_md5": "work/output/vcf.vcf.gz.md5",
    "tbi": "work/output/vcf.vcf.gz.tbi",
    "tbi_md5": "work/output/vcf.vcf.gz.tbi.md5",
}
	assert candidate(base_out="work/test/path") == {
    "vcf": "work/test/path.vcf.gz",
    "vcf_md5": "work/test/path.vcf.gz.md5",
    "tbi": "work/test/path.vcf.gz.tbi",
    "tbi_md5": "work/test/path.vcf.gz.tbi.md5",
}
	assert candidate(base_out="work/test/step") == {
    "vcf": "work/test/step.vcf.gz",
    "vcf_md5": "work/test/step.vcf.gz.md5",
    "tbi": "work/test/step.vcf.gz.tbi",
    "tbi_md5": "work/test/step.vcf.gz.tbi.md5",
}
	assert candidate(base_out="work/step.path/log/step") == {
    "vcf": "work/step.path/log/step.vcf.gz",
    "vcf_md5": "work/step.path/log/step.vcf.gz.md5",
    "tbi": "work/step.path/log/step.vcf.gz.tbi",
    "tbi_md5": "work/step.path/log/step.vcf.gz.tbi.md5",
}
	assert candidate(base_out="work/test.path/out") == {
    "vcf": "work/test.path/out.vcf.gz",
    "vcf_md5": "work/test.path/out.vcf.gz.md5",
    "tbi": "work/test.path/out.vcf.gz.tbi",
    "tbi_md5": "work/test.path/out.vcf.gz.tbi.md5",
}
def test_check():
	check(get_expected_output_vcf_files_dict)
