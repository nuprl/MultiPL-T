def calculate_discount(maximum: float, discount: float = 0.1):
    """ 
     Calculates at (1 - `discount`) * maximum
     :param maximum:
     :param discount:
     :return:
     """
	### Canonical solution below ###    
    assert 0. < discount <= 1., "Discount mus be in range ]0, 1]"
    return maximum * (1. - discount)

### Unit tests below ###
def check(candidate):
	assert candidate(10000, discount=0.01) == 9900
	assert candidate(100, 1.0) == 0, "candidate does not work correctly"
	assert candidate(100, 0.5) == 50
	assert candidate(100, 0.5) == 50, "candidate does not work correctly"
	assert candidate(1000, 0.25) == 750.
	assert candidate(1000) == 900.
	assert candidate(0, 1.0) == 0, "candidate does not work correctly"
	assert candidate(10., 0.05) == 9.5, "Expected 9.5"
	assert candidate(100, 0.6) == 40.
	assert candidate(10000, discount=0.5) == 5000
	assert candidate(100) == 90.0, "Test 1"
	assert candidate(1000, 0.4) == 600.
	assert candidate(1000, 0.5) == 500, "candidate(1000, 0.5) should be 500"
	assert candidate(1000, 1.) == 0
	assert candidate(100000., 0.1) == 90000.
	assert candidate(1000, 0.3) == 700
	assert candidate(1000, 0.2) == 800, "candidate(1000, 0.2) should be 800"
	assert candidate(100.) == 90.
	assert candidate(100, 0.4) == 60
	assert candidate(100, 0.1) == 90, "candidate does not work correctly"
	assert candidate(1000, 0.1) == 900
	assert candidate(100, discount=0.1) == 90, "100 -> 90"
	assert candidate(100, 0.3) == 70.
	assert candidate(10., 0.1) == 9., "Expected 9"
	assert candidate(0.5) == 0.45
	assert candidate(100, 0.2) == 80.
	assert candidate(0, 0.1) == 0, "candidate does not work correctly"
	assert candidate(1000, 0.3) == 700.
	assert candidate(100., 0.15) == 85.
	assert candidate(100, discount=1.0) == 0.
	assert candidate(100) == 90
	assert candidate(1000, 0.01) == 990
	assert candidate(1000, 0.6) == 400.
	assert candidate(1000, 0.5) == 500
	assert candidate(1000, 0.2) == 800.
	assert candidate(100., 0.1) == 90.
	assert candidate(1000, 0.1) == 900, "candidate(1000, 0.1) should be 900"
	assert candidate(100., 1.0) == 0.
	assert candidate(100., 0.5) == 50., "50% discount should be 50"
	assert candidate(100000., 0.00001) == 99999.
	assert candidate(100, discount=0.1) == 90.
	assert candidate(100, discount=0.5) == 50, "100 -> 50"
	assert candidate(100., discount=1.) == 0.
	assert candidate(1000, 1) == 0, "candidate(1000, 1) should be 0"
	assert candidate(100000., 0.01) == 99000.
	assert candidate(100, 1.) == 0
	assert candidate(100) == 90, "100 -> 90"
	assert candidate(10., 0.5) == 5., "Expected 5"
	assert candidate(1000, 0.6) == 400
	assert candidate(100, 0.5) == 50.
	assert candidate(100., 0.5) == 50.
	assert candidate(100, 1.) == 0.
	assert candidate(100, 0.2) == 80.0, "Test 2"
	assert candidate(100, 0.3) == 70
	assert candidate(10., 1.0) == 0., "Expected 0"
	assert candidate(10., 0.2) == 8
	assert candidate(1.0) == 0.9
	assert candidate(1000, 0.1) == 900.
	assert candidate(1000, 0.5) == 500.
	assert candidate(100, discount=0.5) == 50.
	assert candidate(1000, 0.4) == 600
	assert candidate(100, 1) == 0
	assert candidate(100, 0.1) == 90
	assert candidate(100000., 1.) == 0.
	assert candidate(100000., 0.001) == 99900.
	assert candidate(10000, discount=1.) == 0
	assert candidate(100, 0.4) == 60.
	assert candidate(100., 0.2) == 80.
	assert candidate(10000) == 9000
	assert candidate(1000) == 900
	assert candidate(0, 0.5) == 0, "candidate does not work correctly"
	assert candidate(1000, 0.2) == 800
	assert candidate(100, 0.2) == 80
	assert candidate(100) == 90.
	assert candidate(100, 1.0) == 0
	assert candidate(100, 0.6) == 40
	assert candidate(100., 0.1) == 90., "10% discount should be 90"
	assert candidate(100000., 0.5) == 50000.
	assert candidate(100, 1.0) == 0.0, "Test 4"
	assert candidate(100000., 0.0001) == 99990.
	assert candidate(100, 0.1) == 90.
	assert candidate(100, discount=1.0) == 0, "100 -> 0"
	assert candidate(100., 1.0) == 0., "100% discount should be 0"
	assert candidate(1000, 1.0) == 0
def test_check():
	check(calculate_discount)
