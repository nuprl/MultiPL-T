def sort_by_value(d):
    """ Returns the keys of dictionary d sorted by their values """
	### Canonical solution below ###    
    items=d.items()
    backitems=[ [v[1],v[0]] for v in items]
    backitems.sort()
    return [ backitems[i][1] for i in range(0,len(backitems))]

### Unit tests below ###
def check(candidate):
	assert candidate( { 'a':4, 'b':3 } ) == ['b','a']
	assert candidate( {1:10, 2:10, 3:10} ) == [1,2,3]
	assert candidate( {1:30, 2:30, 3:30} ) == [1,2,3]
	assert candidate( {'a':1,'b':1,'c':1,'d':1} ) == ['a','b','c','d']
	assert candidate( {'a':4, 'b':3, 'c':2, 'd':1 } ) == ['d', 'c', 'b', 'a']
	assert candidate( {'a':1, 'b':1, 'c':1, 'd':1 } ) == ['a', 'b', 'c', 'd']
	assert candidate( {'a':1,'b':1,'c':1} ) == ['a','b','c']
	assert candidate( {'a':4, 'b':3, 'c':2, 'd':1} ) == ['d','c','b','a']
	assert candidate(dict(a=4, b=3, c=2, d=1, e=0, f=-1, g=-2)) == ['g', 'f', 'e', 'd', 'c', 'b', 'a']
	assert candidate( {'a':3, 'b':4, 'c':2} ) == ['c', 'a', 'b']
	assert candidate( {'a':2,'b':2,'c':2,'d':2}) == ['a','b','c','d']
	assert candidate( {'a':3,'b':4,'c':2}) == ['c','a','b']
	assert candidate(dict(x=4,y=3,z=2)) == ['z','y','x']
	assert candidate(dict(x=4,y=3,z=2,t=1,u=0)) == ['u','t','z','y','x']
	assert candidate(dict(a=1, b=2, c=3, d=4)) == ['a', 'b', 'c', 'd']
	assert candidate(dict(a=4, b=3, c=2, d=1, e=0, f=-1, g=-2, h=-3)) == ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a']
	assert candidate(dict(a=4, b=3, c=2, d=1, e=0, f=-1)) == ['f', 'e', 'd', 'c', 'b', 'a']
	assert candidate( {'a':1, 'b':1, 'c':1, 'd':1} ) == ['a','b','c','d']
	assert candidate( {1:10, 2:20, 3:30} ) == [1, 2, 3]
	assert candidate( {'a':1, 'b':1, 'c':1, 'd':1} ) == ['a', 'b', 'c', 'd']
	assert candidate( {'a':3, 'b':4, 'c':2, 'd':1, 'e':5} ) == ['d', 'c', 'a', 'b', 'e']
	assert candidate( {'a':3, 'b':4, 'c':2, 'd':1} ) == ['d', 'c', 'a', 'b']
	assert candidate(dict(a=3, b=3, c=3)) == ['a', 'b', 'c']
	assert candidate(dict(a=3, b=2, c=1)) == ['c', 'b', 'a']
	assert candidate( {'a':3,'b':3,'c':3}) == ['a','b','c']
	assert candidate( {'a':3,'b':2,'c':1} ) == ['c','b','a']
	assert candidate(dict(a=4, b=3, c=2, d=1)) == ['d', 'c', 'b', 'a']
	assert candidate( {1:2, 2:1, 3:2} ) == [2,1,3]
	assert candidate(dict())==[]
	assert candidate( {} ) == []
	assert candidate({1:10,2:1,3:100})==[2,1,3]
	assert candidate(dict(a=4, b=3, c=2, d=1, e=0)) == ['e', 'd', 'c', 'b', 'a']
	assert candidate(dict(x=4,y=3,z=2,t=1)) == ['t','z','y','x']
	assert candidate(dict(a=1, b=1, c=1, d=1)) == ['a', 'b', 'c', 'd']
	assert candidate( {'a':4, 'b':3, 'c':2, 'd':1, 'e':0} ) == ['e','d','c','b','a']
	assert candidate({1:100, 2:1}) == [2,1]
	assert candidate( {'a':3, 'b':4, 'c':2, 'd':1, 'e':5, 'f':0} ) == ['f', 'd', 'c', 'a', 'b', 'e']
	assert candidate( {} ) == [], "candidate 5"
	assert candidate( {'a':3,'b':3,'c':3} ) == ['a','b','c']
	assert candidate(dict()) == []
def test_check():
	check(sort_by_value)
