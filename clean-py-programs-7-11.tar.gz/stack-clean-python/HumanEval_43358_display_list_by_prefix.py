def display_list_by_prefix(names_list, starting_spaces=0):
  """Creates a help string for names_list grouped by prefix."""
    ### Canonical solution below ###
  cur_prefix, result_lines = None, []
  space = " " * starting_spaces
  for name in sorted(names_list):
    split = name.split("_", 1)
    prefix = split[0]
    if cur_prefix != prefix:
      result_lines.append(space + prefix + ":")
      cur_prefix = prefix
    result_lines.append(space + "  * " + name)
  return "\n".join(result_lines)


### Unit tests below ###
def check(candidate):
	assert candidate(
    ["aaa_bbb", "aaa_ccc", "bbb_ccc"], 0) == """aaa:
  * aaa_bbb
  * aaa_ccc
bbb:
  * bbb_ccc"""
	assert candidate([]) == ""
	assert candidate(
    ["foo", "foo_bar", "foo_bar_baz", "foo_quux", "quux"], starting_spaces=2) == """  foo:
    * foo
    * foo_bar
    * foo_bar_baz
    * foo_quux
  quux:
    * quux"""
	assert candidate(
    ["aaa_bbb", "aaa_ccc", "bbb_ccc"], 2) == """  aaa:
    * aaa_bbb
    * aaa_ccc
  bbb:
    * bbb_ccc"""
	assert candidate(
  ["foo_bar", "foo_baz", "foo_quux"]) == """\
foo:
  * foo_bar
  * foo_baz
  * foo_quux"""
	assert candidate(
    ["foo", "foo_bar", "foo_bar_baz", "foo_quux", "quux"]) == """foo:
  * foo
  * foo_bar
  * foo_bar_baz
  * foo_quux
quux:
  * quux"""
	assert candidate(
  ["foo_bar", "foo_baz", "foo_quux"], starting_spaces=2) == """\
  foo:
    * foo_bar
    * foo_baz
    * foo_quux"""
	assert candidate(
    ["aaa_1", "aaa_2", "bbb_1", "bbb_2"], 0) == """aaa:
  * aaa_1
  * aaa_2
bbb:
  * bbb_1
  * bbb_2"""
	assert candidate(
    ["aaa_1", "aaa_2", "bbb_1", "bbb_2"], 2) == """  aaa:
    * aaa_1
    * aaa_2
  bbb:
    * bbb_1
    * bbb_2"""
def test_check():
	check(display_list_by_prefix)
