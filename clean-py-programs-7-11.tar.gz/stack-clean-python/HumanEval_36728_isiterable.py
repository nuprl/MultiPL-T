def isiterable(obj):
    """ Return True iff an object is iterable."""
	### Canonical solution below ###    
    try:
        iter(obj)
    except Exception:
        return False
    else:
        return True

### Unit tests below ###
def check(candidate):
	assert candidate([1,2,3]) == True
	assert candidate(dict(a=1)) == True
	assert candidate(False) == False
	assert candidate(iter([1])) == True
	assert not candidate(3.14)
	assert candidate(range(10))
	assert candidate({1, 2, 3}) == True
	assert candidate([1, 2, 3]) is True
	assert candidate((1,2)) == True
	assert candidate(range(5)) == True
	assert candidate(range(1,4)) == True
	assert candidate({}) == True
	assert candidate(iter(list()))
	assert not candidate(type)
	assert not candidate(1)
	assert candidate(1) == False
	assert not candidate(1.0)
	assert not candidate(False)
	assert not candidate(object())
	assert candidate(True) == False
	assert candidate(iter(set()))
	assert candidate(iter([1, 2]))
	assert not candidate(10)
	assert candidate(dict())
	assert candidate(iter([]))
	assert candidate(iter([1, 2])) == True
	assert not candidate(True)
	assert candidate("abc") == True
	assert candidate([1, 2])
	assert candidate(iter(frozenset()))
	assert not candidate(complex(1, 2))
	assert candidate(iter(range(10))) == True
	assert candidate(iter(range(10)))
	assert candidate(1.0) == False
	assert candidate(iter(dict()))
	assert candidate(iter((1,))) == True
	assert candidate(frozenset())
	assert candidate(u"abc") == True
	assert candidate(range(3)) == True
	assert candidate(iter([1, 2, 3])) == True
	assert candidate((1, 2)) == True
	assert not candidate(3)
	assert candidate({1: 2}) == True
	assert candidate(set([1,2,3])) == True
	assert candidate({1:2,3:4}) == True
	assert not candidate(iter)
	assert candidate(1) is False
	assert candidate(iter(tuple()))
	assert candidate(set()) == True
	assert candidate([1, 2, 3]) == True
	assert candidate(set([1, 2])) == True
	assert candidate(()) == True
	assert candidate(range(3))
	assert candidate(tuple())
	assert candidate([]) == True
	assert candidate((1,2,3)) == True
	assert not candidate(None)
	assert candidate(frozenset([1,2,3])) == True
	assert candidate([1, 2]) == True
	assert candidate("abc") is True
	assert candidate(range(10)) == True
	assert candidate(iter([1, 2, 3]))
	assert candidate([1, 2, 3])
	assert candidate((1, 2, 3)) == True
	assert candidate(iter([1,2,3])) == True
	assert candidate(set())
	assert candidate(iter([1,2])) == True
	assert candidate(list())
	assert not candidate(candidate)
	assert candidate(x for x in range(3)) == True
	assert candidate((1,)) == True
	assert candidate(range(1, 4))
	assert candidate([1,2]) == True
	assert candidate([1]) == True
	assert candidate(None) == False
	assert not candidate(1.)
def test_check():
	check(isiterable)
