def get_highest_single_digit_integer_from_string(in_string):
    """Get the highest single digit integer from a string """
    ### Canonical solution below ###
    items = set(in_string)
    ints = set("1234567890")
    items &= ints
    max_i = -1
    if len(items) == 0:
        return None
    else:
        for i in items:
            if int(i) > max_i:
                max_i = int(i)
        return max_i


### Unit tests below ###
def check(candidate):
	assert candidate("12345678901234567890") == 9
	assert candidate(
    "asdf 12345 1234") == 5
	assert candidate(
    "12345678901234567890123456789012345678901234567890") == 9, "Highest digit is 9"
	assert candidate(
    "9 Hello 9 World!") == 9
	assert candidate(
    "1234567890a") == 9, "Test 2 failed"
	assert candidate(
    "Hello 9 World!") == 9
	assert candidate(
    "a1b2c3d") == 3
	assert candidate("123456789012345678901234567890") == 9
	assert candidate("293847239874") == 9
	assert candidate(
    "0") == 0, "2nd example"
	assert candidate(
    "") == None
	assert candidate(
    "12345678901234567890") == 9, "Test 3 failed"
	assert candidate("1234") == 4
	assert candidate(
    "0123456789") == 9, "4th example"
	assert candidate(
    "a1b2c3d4") == 4
	assert candidate("1234567890") == 9
	assert candidate(
    "99 Hello 99 9 9 9 9 World!") == 9
	assert candidate(
    "aaaa1234567890aaaa") == 9, "Testing with a string of numbers and letters"
	assert candidate(
    "aaaa1234567890") == 9, "Testing with a string of letters and numbers"
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz0123456789") == 9, "Highest single digit integer"
	assert candidate("12") == 2
	assert candidate(
    "00000000000") == 0
	assert candidate(
    "1234567890aaaa1234567890") == 9, "Testing with a string of numbers and letters"
	assert candidate(
    "a1b2c3d4e5") == 5
	assert candidate(
    "12345678909") == 9
	assert candidate(
    "abc123xyz") == 3
	assert candidate("a") is None
	assert candidate(
    "12345 1234") == 5
	assert candidate(
    "2019-12-12 00:00:00.000009") == 9
	assert candidate(
    "a1b2c3d4e") == 4
	assert candidate(
    "123456789012345678901234567890") == 9, "123456789012345678901234567890"
	assert candidate("123456789") == 9, "Wrong answer"
	assert candidate(
    "this is a test") == None
	assert candidate(
    "0000000000") == 0
	assert candidate(
    "123456789") == 9, "3rd example"
	assert candidate("abc") == None
	assert candidate("a1234567890b") == 9
	assert candidate("99 12345") == 9
	assert candidate(
    "a1b2c3d4e5f") == 5, "Highest single digit integer"
	assert candidate(
    "a1b2c") == 2
	assert candidate(
    "hello world") == None
	assert candidate(
    "1234567890") == 9, "Highest single digit integer not found"
	assert candidate(
    "aaaa1234567890.") == 9, "Testing with a string of letters, numbers and a period"
	assert candidate(
    "0") == 0, "Highest single digit integer not found"
	assert candidate("1a234567890") == 9
	assert candidate("abc123xyz") == 3
	assert candidate(
    "abc123xyz") == 3, "abc123xyz"
	assert candidate(
    "1234567890") == 9
	assert candidate(
    "12345") == 5
	assert candidate(
    "I have a dog") == None
	assert candidate("123") == 3
	assert candidate(
    "abcd") == None, "Wrong answer"
	assert candidate(
    "1111222233334444555566667777888899990000") == 9, "Highest single digit integer not found"
	assert candidate(
    "123456789012345678901234567890") == 9
	assert candidate(
    "a1b2c3d4e5f") == 5
	assert candidate("") == None
	assert candidate(
    "a1b2c3") == 3
	assert candidate(
    "99 Hello 9 World!") == 9
	assert candidate("123abc456") == 6
	assert candidate(
    "0123456789") == 9
	assert candidate("1234567890a") == 9
	assert candidate("1234567890ab") == 9
	assert candidate(
    "99 Hello 9 9 World!") == 9
	assert candidate("a b c d") is None
	assert candidate(
    "12345678901234567890") == 9
	assert candidate(
    "1234567890") == 9, "Wrong answer"
	assert candidate(
    "2019-12-12 00:00:00.000009123") == 9
	assert candidate("a1234567890") == 9
	assert candidate(
    "1234567890") == 9, "Testing with a string of numbers"
	assert candidate(
    "1234567890a") == 9
	assert candidate(
    "99 Hello 99 World!") == 9
	assert candidate(
    "a1b2c3d4e5f6g7") == 7
	assert candidate(
    "1234567890aaaa") == 9, "Testing with a string of numbers and letters"
	assert candidate("") is None
	assert candidate("0") == 0
	assert candidate(
    "11223344556677889900") == 9, "Highest single digit integer not found"
	assert candidate(
    "a1b2c3d4e5f6g7h") == 7
	assert candidate("1a234567890b") == 9
	assert candidate(
    "1111222233334444555566667777888899990000000000") == 9, "Highest single digit integer not found"
	assert candidate(
    "This is a test string") == None
	assert candidate(
    "000000000") == 0
	assert candidate(
    "11112222333344445555666677778888999900000000001111222233334444555566667777888899990000000000") == 9, "Highest single digit integer not found"
	assert candidate("abcdefghijklmnopqrstuvwxyz") == None
	assert candidate("1a234") == 4, "Wrong answer"
	assert candidate("12345") == 5
	assert candidate("123456") == 6
	assert candidate("123456789") == 9
	assert candidate(
    "a1b2c3d4e5f6g7h8i9j") == 9, "Highest single digit integer"
	assert candidate("9") == 9
	assert candidate(
    "a1") == 1
	assert candidate("123456789a") == 9, "Wrong answer"
	assert candidate(
    "a") == None
	assert candidate(
    "1234567890") == 9, "Highest digit is 9"
	assert candidate(
    "1234567890aaaa1234567890aaaa") == 9
	assert candidate(
    "99 Hello 99 9 9 World!") == 9
	assert candidate(
    "a1b2c3d4e5f6g") == 6
	assert candidate(
    "a1b3c5d7e9f") == 9
	assert candidate(
    "1234567890aaaa1234567890.") == 9, "Testing with a string of numbers and letters"
	assert candidate("99 12345 33") == 9
	assert candidate(
    "12345678901") == 9, "Highest digit is 9"
	assert candidate(
    "A23b903089307812389173") == 9
	assert candidate(
    "21234567890") == 9
	assert candidate(
    "12345678901234567890a") == 9, "Test 4 failed"
	assert candidate(
    "1111111111") == 1
	assert candidate(
    "abc") == None, "abc"
	assert candidate("1111111111") == 1
	assert candidate(
    "a1b") == 1
	assert candidate("0123456789") == 9
	assert candidate(
    "123") == 3
	assert candidate("982374982374982374982374") == 9
	assert candidate(
    "a1b2") == 2
	assert candidate(
    "a1b2c3d4e5f6") == 6
	assert candidate(
    "abc123") == 3, "abc123"
	assert candidate(
    "asdf") == None
	assert candidate(
    "99 Hello 99 9 9 9 World!") == 9
	assert candidate(
    "987xyz") == 9, "987xyz"
	assert candidate(
    "12345xyz1234567890") == 9
	assert candidate("99 12345 33 5") == 9
	assert candidate(
    "1234567890") == 9, "Test 1 failed"
	assert candidate(
    "2019-12-12 00:00:00.000009123123123") == 9
	assert candidate("123456789")
	assert candidate("xyz1234567890") == 9
	assert candidate("1234567") == 7
	assert candidate(
    "99 Hello 99 9 World!") == 9
	assert candidate(
    "123456789a") == 9, "Testing with a string of numbers and letters"
	assert candidate(
    "99 Hello 99 9 9 9 9 9 9 World!") == 9
	assert candidate(
    "99 Hello 99 9 9 9 9 9 World!") == 9
	assert candidate("12345678") == 8
	assert candidate("10") == 1
	assert candidate(
    "1234567890") == 9, "1st example"
	assert candidate(
    "2019-12-12 00:00:00.000009123123") == 9
	assert candidate("1") == 1
	assert candidate("12345xyz67890") == 9
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz0123456789a") == 9, "Highest single digit integer"
	assert candidate(
    "Hello World!") == None
	assert candidate(
    "asdf 12345") == 5
def test_check():
	check(get_highest_single_digit_integer_from_string)
