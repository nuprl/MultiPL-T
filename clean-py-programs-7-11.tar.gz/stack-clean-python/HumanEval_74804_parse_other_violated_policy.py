def parse_other_violated_policy(raw_other_violated_policy_list: list) -> list:
    """
    Parses a list of policies to context paths
    :param raw_other_violated_policy_list: the raw policies list
    :return: the parsed policies list
    """
    ### Canonical solution below ###
    other_violated_policy_list: list = []
    for raw_other_violated_policy in raw_other_violated_policy_list:
        other_violated_policy: dict = {
            'Name': raw_other_violated_policy.get('name'),
            'Version': raw_other_violated_policy.get('version'),
            'Label': raw_other_violated_policy.get('label'),
            'ID': raw_other_violated_policy.get('policyId')
        }
        other_violated_policy_list.append({key: val for key, val in other_violated_policy.items() if val})
    return other_violated_policy_list


### Unit tests below ###
def check(candidate):
	assert candidate(
    [
        {
            'name': 'Other Violated Policy',
           'version': '1.0.0',
            'label': 'Other Violated Policy',
            'policyId': '59616575-6f59-4265-95b5-98c5279933c4'
        }
    ]
) == [
    {
        'Name': 'Other Violated Policy',
        'Version': '1.0.0',
        'Label': 'Other Violated Policy',
        'ID': '59616575-6f59-4265-95b5-98c5279933c4'
    }
]
	assert candidate(
    [
        {
            'name': 'Other Violated Policy 1',
           'version': '1.1',
            'label': 'label1',
            'policyId': 123
        },
        {
            'name': 'Other Violated Policy 2',
           'version': '1.2',
            'label': 'label2',
            'policyId': 456
        }
    ]
) == [
    {
        'Name': 'Other Violated Policy 1',
        'Version': '1.1',
        'Label': 'label1',
        'ID': 123
    },
    {
        'Name': 'Other Violated Policy 2',
        'Version': '1.2',
        'Label': 'label2',
        'ID': 456
    }
]
	assert candidate(raw_other_violated_policy_list=[{'name': 'Policy1','version': '1.0', 'label': 'label1', 'policyId': 'id1'}, {'name': 'Policy2','version': '2.0', 'label': 'label2', 'policyId': 'id2'}]) == [{'Name': 'Policy1', 'Version': '1.0', 'Label': 'label1', 'ID': 'id1'}, {'Name': 'Policy2', 'Version': '2.0', 'Label': 'label2', 'ID': 'id2'}]
	assert candidate(raw_other_violated_policy_list=[
    {
        'name': 'Other policy 1',
       'version': '1',
        'label': 'Other policy 1 label',
        'policyId': 'Other policy 1 ID'
    },
    {
        'name': 'Other policy 2',
       'version': '2',
        'label': 'Other policy 2 label',
        'policyId': 'Other policy 2 ID'
    }
]) == [
    {
        'Name': 'Other policy 1',
        'Version': '1',
        'Label': 'Other policy 1 label',
        'ID': 'Other policy 1 ID'
    },
    {
        'Name': 'Other policy 2',
        'Version': '2',
        'Label': 'Other policy 2 label',
        'ID': 'Other policy 2 ID'
    }
]
	assert candidate(raw_other_violated_policy_list=[
    {'name': 'Other Violated Policy 1','version': '1.0', 'label': 'Other Violated Policy 1', 'policyId': '12345678'},
    {'name': 'Other Violated Policy 2','version': '2.0', 'label': 'Other Violated Policy 2', 'policyId': '23456789'}
]) == [
    {'Name': 'Other Violated Policy 1', 'Version': '1.0', 'Label': 'Other Violated Policy 1', 'ID': '12345678'},
    {'Name': 'Other Violated Policy 2', 'Version': '2.0', 'Label': 'Other Violated Policy 2', 'ID': '23456789'}
]
	assert candidate(raw_other_violated_policy_list=[
    {
        'name': 'AWS-CloudFront-Signed-URL-Required',
       'version': '1.0.0',
        'label': 'CloudFront Signed URL Required',
        'policyId': '123456789012345678901234'
    }
]) == [
    {
        'Name': 'AWS-CloudFront-Signed-URL-Required',
        'Version': '1.0.0',
        'Label': 'CloudFront Signed URL Required',
        'ID': '123456789012345678901234'
    }
]
	assert candidate(
    [
        {
            'name': 'MyOtherViolatedPolicy',
           'version': '1',
            'label': 'MyOtherViolatedPolicyLabel',
            'policyId': '1'
        },
        {
            'name': 'MyOtherViolatedPolicy2',
           'version': '2',
            'label': 'MyOtherViolatedPolicyLabel2',
            'policyId': '2'
        }
    ]
) == [
    {
        'Name': 'MyOtherViolatedPolicy',
        'Version': '1',
        'Label': 'MyOtherViolatedPolicyLabel',
        'ID': '1'
    },
    {
        'Name': 'MyOtherViolatedPolicy2',
        'Version': '2',
        'Label': 'MyOtherViolatedPolicyLabel2',
        'ID': '2'
    }
]
	assert candidate(raw_other_violated_policy_list=[]) == []
	assert candidate(
    [
        {
            'name': 'Other Violated Policy 1',
           'version': '1.0',
            'label': 'Other Violated Policy 1',
            'policyId': '12345678-1234-1234-1234-1234567890ab'
        },
        {
            'name': 'Other Violated Policy 2',
           'version': '1.0',
            'label': 'Other Violated Policy 2',
            'policyId': '12345678-1234-1234-1234-1234567890ab'
        }
    ]
) == [
    {
        'Name': 'Other Violated Policy 1',
        'Version': '1.0',
        'Label': 'Other Violated Policy 1',
        'ID': '12345678-1234-1234-1234-1234567890ab'
    },
    {
        'Name': 'Other Violated Policy 2',
        'Version': '1.0',
        'Label': 'Other Violated Policy 2',
        'ID': '12345678-1234-1234-1234-1234567890ab'
    }
]
	assert candidate(raw_other_violated_policy_list=[{'name': 'Policy1','version': '1.0', 'label': 'label1', 'policyId': 'id1'}]) == [{'Name': 'Policy1', 'Version': '1.0', 'Label': 'label1', 'ID': 'id1'}]
	assert candidate(raw_other_violated_policy_list=[
    {'name': 'Other Violated Policy 1','version': '1.0', 'label': 'Other Violated Policy 1', 'policyId': '12345678'}
]) == [
    {'Name': 'Other Violated Policy 1', 'Version': '1.0', 'Label': 'Other Violated Policy 1', 'ID': '12345678'}
]
	assert candidate(
    [
        {
            'name': 'MyOtherViolatedPolicy',
           'version': '1',
            'label': 'MyOtherViolatedPolicyLabel',
            'policyId': '1'
        }
    ]
) == [
    {
        'Name': 'MyOtherViolatedPolicy',
        'Version': '1',
        'Label': 'MyOtherViolatedPolicyLabel',
        'ID': '1'
    }
]
	assert candidate(
    raw_other_violated_policy_list=[{
        'name': 'foo',
       'version': 'bar',
        'label': 'baz',
        'policyId': 'qux'
    }]) == [{
        'Name': 'foo',
        'Version': 'bar',
        'Label': 'baz',
        'ID': 'qux'
    }]
	assert candidate(
    raw_other_violated_policy_list=[
        {'name': 'AWS:IAMUser:ConsolePassword','version': 'v1.0.0', 'label': 'ConsolePassword', 'policyId': 'p-asdfghjkl'},
        {'name': 'AWS:IAMUser:ConsolePassword','version': 'v1.0.0', 'label': 'ConsolePassword', 'policyId': 'p-qwertyuiop'},
        {'name': 'AWS:IAMUser:ConsolePassword','version': 'v1.0.0', 'label': 'ConsolePassword', 'policyId': 'p-zxcvbnm'},
    ]
) == [
    {'Name': 'AWS:IAMUser:ConsolePassword', 'Version': 'v1.0.0', 'Label': 'ConsolePassword', 'ID': 'p-asdfghjkl'},
    {'Name': 'AWS:IAMUser:ConsolePassword', 'Version': 'v1.0.0', 'Label': 'ConsolePassword', 'ID': 'p-qwertyuiop'},
    {'Name': 'AWS:IAMUser:ConsolePassword', 'Version': 'v1.0.0', 'Label': 'ConsolePassword', 'ID': 'p-zxcvbnm'},
]
	assert candidate(raw_other_violated_policy_list=[
    {'name': 'test_name1','version': 'test_version1', 'label': 'test_label1', 'policyId': 'test_policy_id1'},
    {'name': 'test_name2','version': 'test_version2', 'label': 'test_label2', 'policyId': 'test_policy_id2'},
]) == [
    {'Name': 'test_name1', 'Version': 'test_version1', 'Label': 'test_label1', 'ID': 'test_policy_id1'},
    {'Name': 'test_name2', 'Version': 'test_version2', 'Label': 'test_label2', 'ID': 'test_policy_id2'},
]
	assert candidate(raw_other_violated_policy_list=[{
    'name': 'Test policy 1',
   'version': '1.0',
    'label': 'Test',
    'policyId': '1'
}]) == [{
    'Name': 'Test policy 1',
    'Version': '1.0',
    'Label': 'Test',
    'ID': '1'
}]
	assert candidate(raw_other_violated_policy_list=[{'name': 'aws:iam:policy',
                                                                  'version': 'v1.0',
                                                                   'label': 'aws:iam:policy',
                                                                   'policyId': 'aws:iam:policy'}]) == \
       [{'Name': 'aws:iam:policy', 'Version': 'v1.0', 'Label': 'aws:iam:policy', 'ID': 'aws:iam:policy'}]
	assert candidate(raw_other_violated_policy_list=[
    {'name': 'name1','version':'version1', 'label': 'label1', 'policyId': 'id1'},
    {'name': 'name2','version':'version2', 'label': 'label2', 'policyId': 'id2'}
]) == [
    {'Name': 'name1', 'Version':'version1', 'Label': 'label1', 'ID': 'id1'},
    {'Name': 'name2', 'Version':'version2', 'Label': 'label2', 'ID': 'id2'}
]
	assert candidate(
    [
        {'name': 'policy_1','version': '1', 'label': 'label_1', 'policyId': '1'},
        {'name': 'policy_2','version': '2', 'label': 'label_2', 'policyId': '2'},
        {'name': 'policy_3','version': '3', 'label': 'label_3', 'policyId': '3'}
    ]
) == [
    {'Name': 'policy_1', 'Version': '1', 'Label': 'label_1', 'ID': '1'},
    {'Name': 'policy_2', 'Version': '2', 'Label': 'label_2', 'ID': '2'},
    {'Name': 'policy_3', 'Version': '3', 'Label': 'label_3', 'ID': '3'}
]
	assert candidate(
    [{'name': 'CloudTrail.1','version': 'v1.0.0', 'label': 'CloudTrail.1', 'policyId': '12345'}]
) == [{'Name': 'CloudTrail.1', 'Version': 'v1.0.0', 'Label': 'CloudTrail.1', 'ID': '12345'}]
def test_check():
	check(parse_other_violated_policy)
