def rh_from_avp_svp(avp, svp):
    """
    Calculate relative humidity as the ratio of actual vapour pressure
    to saturation vapour pressure at the same temperature.
    See Allen et al (1998), page 67 for details.
    :param avp: Actual vapour pressure [units do not matter so long as they
        are the same as for *svp*]. Can be estimated using functions whose
        name begins with 'avp_from'.
    :param svp: Saturated vapour pressure [units do not matter so long as they
        are the same as for *avp*]. Can be estimated using ``svp_from_t()``.
    :return: Relative humidity [%].
    :rtype: float
    """
    ### Canonical solution below ###
    return 100.0 * avp / svp


### Unit tests below ###
def check(candidate):
	assert candidate(1.0, 5.0) == 20.0
	assert candidate(100, 1000000) == 0.01
	assert candidate(1000.0, 1000.0) == 100.0
	assert candidate(0.0, 2.0) == 0.0
	assert candidate(1.0, 1.0) == 100.0
	assert candidate(25.8, 25.8) == 100.0
	assert candidate(10, 10) == 100.0
	assert candidate(100, 100000000) == 0.0001
	assert candidate(1.0, 8.0) == 12.5
	assert candidate(1.0, 10.0) == 10.0
	assert candidate(2.0, 1.0) == 200.0
	assert candidate(0.5, 1.0) == 50.0
	assert candidate(1.0, 0.5) == 200.0
	assert candidate(0.0, 1.0) == 0.0
	assert candidate(100, 10000000) == 0.001
	assert candidate(2.0, 0.5) == 400.0
	assert candidate(10, 20) == 50.0
	assert candidate(20, 10) == 200.0
	assert candidate(100, 100) == 100.0
	assert candidate(10000, 10000) == 100
	assert candidate(100, 10000) == 1
	assert candidate(10.0, 10.0) == 100.0
	assert candidate(100000, 10000) == 1000
	assert candidate(1.0, 9.0) == 11.11111111111111
	assert candidate(100, 1000) == 10
	assert candidate(1.0, 2.0) == 50.0
	assert candidate(10, 30) == 33.333333333333336
	assert candidate(100, 1000) == 10.0
	assert candidate(100, 100) == 100
	assert candidate(100, 100000) == 0.1
	assert candidate(100, 1000000000) == 0.00001
	assert candidate(2.0, 2.0) == 100.0
	assert candidate(0.5, 0.5) == 100.0
	assert candidate(1.0, 6.0) == 16.666666666666668
	assert candidate(100, 10000) == 1.0
	assert candidate(1.0, 4.0) == 25.0
	assert candidate(1000000, 10000) == 10000
	assert candidate(1000, 10000) == 10
	assert candidate(100, 10000000000) == 0.000001
def test_check():
	check(rh_from_avp_svp)
