def _get_resource_name(resource):
    """ Return the name identifier of the `resource` as stored in the db"""
	### Canonical solution below ###    
    return (getattr(resource, 'name', '') or
            getattr(resource, 'title', '') or
            getattr(resource, 'domain', '') or '')

### Unit tests below ###
def check(candidate):
	assert candidate(type('A', (), {'name': 'name', 'domain': 'domain'})) == 'name'
	assert candidate(type('A', (), {'name': 'name'})) == 'name'
	assert candidate(type('A', (), {})) == ''
	assert candidate(1) == ''
	assert candidate(None) == ''
	assert candidate(type('A', (), {'title': 'title'})) == 'title'
	assert candidate(type('A', (), {'domain': 'domain'})) == 'domain'
	assert candidate(type('A', (), {'name': 'name', 'title': 'title'})) == 'name'
	assert candidate(type('A', (), {'title': 'title', 'domain': 'domain'})) == 'title'
def test_check():
	check(_get_resource_name)
