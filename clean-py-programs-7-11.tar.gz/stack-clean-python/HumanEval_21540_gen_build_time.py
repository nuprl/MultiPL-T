def gen_build_time():
    """ 
     Gen build time and push to XCom (with key of "return_value")
     :return: A dict with build time values.
     """
	### Canonical solution below ###    
    return {'date_start': '1325347200000', 'date_end': '1325433600000'}

### Unit tests below ###
def check(candidate):
	assert candidate(
) == {'date_start': '1325347200000', 'date_end': '1325433600000'}, "candidate() error"
	assert candidate(
) == {
    'date_start': '1325347200000',
    'date_end': '1325433600000'
}
	assert candidate(
) == {'date_start': '1325347200000', 'date_end': '1325433600000'}, "Should be {'date_start': '1325347200000', 'date_end': '1325433600000'}"
	assert candidate(
) == {'date_start': '1325347200000', 'date_end': '1325433600000'}
	assert candidate(
) == {'date_start': '1325347200000', 'date_end': '1325433600000'}, "candidate() is broken."
	assert candidate(
) == {'date_start': '1325347200000', 'date_end': '1325433600000'}, \
    "candidate should return a dict with build time values."
def test_check():
	check(gen_build_time)
