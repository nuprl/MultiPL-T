def is_python_file(filename: str) -> bool:
    """Return whether a file is a Python file or not
    """
    ### Canonical solution below ###
    return filename.endswith('.py')


### Unit tests below ###
def check(candidate):
	assert candidate(filename="a.c") == False
	assert candidate(filename='test.py')
	assert candidate(filename="test.py") == True
	assert candidate(filename="test.txt") == False
	assert not candidate(filename='test.txt')
	assert candidate(filename="a.py") == True
	assert candidate(filename='foo') == False
	assert not candidate('/path/to/a/non/python/file')
	assert candidate(filename='foo.py') == True
	assert not candidate(filename='test.pyc')
def test_check():
	check(is_python_file)
