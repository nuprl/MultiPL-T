def enums2html(enums):
    """
    Given a list of enumerated value / name pairs, create an HTML output
    to represent legal combinations
    """
    ### Canonical solution below ###
    s = "\n"
    #s += "<br><u>Legal Settings</u><br>\n<table>\n"
    s += '<table class="enum">\n'
    s += "  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n"
    for e in enums:
        s += "  <tr><td align=center>%s</td><td align=left>%s</td></tr>\n" % (e[0], e[1])
    s += "</table>\n"
    return s


### Unit tests below ###
def check(candidate):
	assert candidate( [ ("A", "B") ] ) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>A</td><td align=left>B</td></tr>
</table>
"""
	assert candidate(
    [
        ["0x0", "Disable"],
        ["0x1", "Enable"]
    ]
) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>0x0</td><td align=left>Disable</td></tr>
  <tr><td align=center>0x1</td><td align=left>Enable</td></tr>
</table>
"""
	assert candidate( [ (1, 'Foo'), (2, 'Bar') ] ) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>1</td><td align=left>Foo</td></tr>
  <tr><td align=center>2</td><td align=left>Bar</td></tr>
</table>
"""
	assert candidate( [ (1, "one"), (2, "two") ] ) == \
"""
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>1</td><td align=left>one</td></tr>
  <tr><td align=center>2</td><td align=left>two</td></tr>
</table>
"""
	assert candidate([("a", "foo"), ("b", "bar")]) == \
    """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>a</td><td align=left>foo</td></tr>
  <tr><td align=center>b</td><td align=left>bar</td></tr>
</table>
"""
	assert candidate([('foo', 'bar')]) == "\n<table class=\"enum\">\n  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n  <tr><td align=center>foo</td><td align=left>bar</td></tr>\n</table>\n"
	assert candidate( [ ('0', "None"), ('1', "One") ] ) == \
    "\n<table class=\"enum\">\n  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n  <tr><td align=center>0</td><td align=left>None</td></tr>\n  <tr><td align=center>1</td><td align=left>One</td></tr>\n</table>\n"
	assert candidate( [("0", "Zero"), ("1", "One")] ) == "\n<table class=\"enum\">\n  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n  <tr><td align=center>0</td><td align=left>Zero</td></tr>\n  <tr><td align=center>1</td><td align=left>One</td></tr>\n</table>\n"
	assert candidate(
    [
        ("0", "No data"),
        ("1", "Data OK"),
        ("2", "Data too old"),
        ("3", "Data too new"),
    ]
) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>0</td><td align=left>No data</td></tr>
  <tr><td align=center>1</td><td align=left>Data OK</td></tr>
  <tr><td align=center>2</td><td align=left>Data too old</td></tr>
  <tr><td align=center>3</td><td align=left>Data too new</td></tr>
</table>
"""
	assert candidate( [ ('1', 'first value'), ('2','second value') ] ) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>1</td><td align=left>first value</td></tr>
  <tr><td align=center>2</td><td align=left>second value</td></tr>
</table>
"""
	assert candidate( [("0", "Zero")] ) == "\n<table class=\"enum\">\n  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n  <tr><td align=center>0</td><td align=left>Zero</td></tr>\n</table>\n"
	assert candidate( [(1, "One"), (2, "Two"), (3, "Three")] ) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>1</td><td align=left>One</td></tr>
  <tr><td align=center>2</td><td align=left>Two</td></tr>
  <tr><td align=center>3</td><td align=left>Three</td></tr>
</table>
"""
	assert candidate( [("0", "zero"), ("1", "one")] ) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>0</td><td align=left>zero</td></tr>
  <tr><td align=center>1</td><td align=left>one</td></tr>
</table>
"""
	assert candidate( [("0", "off"), ("1", "on")] ) == \
    '\n<table class="enum">\n  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n  <tr><td align=center>0</td><td align=left>off</td></tr>\n  <tr><td align=center>1</td><td align=left>on</td></tr>\n</table>\n'
	assert candidate( [ ('0', 'zero'), ('1', 'one') ] ) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>0</td><td align=left>zero</td></tr>
  <tr><td align=center>1</td><td align=left>one</td></tr>
</table>
"""
	assert candidate(
    [(1, "one"), (2, "two"), (3, "three"), (4, "four"), (5, "five")]
) == "\n<table class=\"enum\">\n  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n  <tr><td align=center>1</td><td align=left>one</td></tr>\n  <tr><td align=center>2</td><td align=left>two</td></tr>\n  <tr><td align=center>3</td><td align=left>three</td></tr>\n  <tr><td align=center>4</td><td align=left>four</td></tr>\n  <tr><td align=center>5</td><td align=left>five</td></tr>\n</table>\n"
	assert candidate( [(1, "One"), (2, "Two"), (3, "Three"), (4, "Four")] ) == """
<table class="enum">
  <thead><tr><th>Value</th><th>Definition</th></tr></thead>
  <tr><td align=center>1</td><td align=left>One</td></tr>
  <tr><td align=center>2</td><td align=left>Two</td></tr>
  <tr><td align=center>3</td><td align=left>Three</td></tr>
  <tr><td align=center>4</td><td align=left>Four</td></tr>
</table>
"""
	assert candidate( [("0", "Zero"), ("1", "One"), ("2", "Two")] ) == "\n<table class=\"enum\">\n  <thead><tr><th>Value</th><th>Definition</th></tr></thead>\n  <tr><td align=center>0</td><td align=left>Zero</td></tr>\n  <tr><td align=center>1</td><td align=left>One</td></tr>\n  <tr><td align=center>2</td><td align=left>Two</td></tr>\n</table>\n"
def test_check():
	check(enums2html)
