def clean_output(text):
    """ 
     This takes the text-generated output of the model and cleans it up for printing purposes
     @param text: The text-generated output of the model
     @return: The cleaned up text-generated output
     """
	### Canonical solution below ###    
    punctuations = ['!', '.', '?', ']']
    text_split = text.split(':')

    for i in range(len(text_split)):
        quote = text_split[i]
        last_idxs = []
        for punctuation in punctuations:
            try:
                last_idxs.append(quote.rindex(punctuation))
            except ValueError:
                continue

        if len(last_idxs) > 0:
            if i == len(text_split)-1:
                last_puncation = max(last_idxs)
                quote = quote[:last_puncation+1]
            else:
                last_puncation = max(last_idxs)
                # This checks if Mr. Krabs is the last word in the quote
                if quote[last_puncation-2:last_puncation+1] == 'Mr.':
                    quote = quote[:last_puncation-2] + '\n' + quote[last_puncation-2:]
                else:
                    quote = quote[:last_puncation+1] + '\n' + quote[last_puncation+1:]
        text_split[i] = quote

    return ':'.join(text_split)

### Unit tests below ###
def check(candidate):
	assert candidate(
    'The secret of getting ahead is getting started. – <NAME>') == 'The secret of getting ahead is getting started.'
	assert candidate(
    'The 13-year-old, who is a former bounty hunter, was found dead in a pool of blood 5 miles from the scene. He had been drinking and smoking and had been acting like he was in a bad mood.') == \
    'The 13-year-old, who is a former bounty hunter, was found dead in a pool of blood 5 miles from the scene. He had been drinking and smoking and had been acting like he was in a bad mood.'
	assert candidate(
    'The one who has never made a mistake never tried anything new.') == 'The one who has never made a mistake never tried anything new.'
	assert candidate(
    'Mr. Krabs: "I\'m sorry, I didn\'t mean to hurt you."')
def test_check():
	check(clean_output)
