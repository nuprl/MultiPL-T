def partition_at_level(dendrogram, level):
    """Return the partition of the nodes at the given level

    A dendrogram is a tree and each level is a partition of the graph nodes.
    Level 0 is the first partition, which contains the smallest communities,
    and the best is len(dendrogram) - 1.
    The higher the level is, the bigger are the communities

    Parameters
    ----------
    dendrogram : list of dict
       a list of partitions, ie dictionaries where keys of the i+1 are the
       values of the i.
    level : int
       the level which belongs to [0..len(dendrogram)-1]

    Returns
    -------
    partition : dictionary
       A dictionary where keys are the nodes and the values are the set it
       belongs to

    Raises
    ------
    KeyError
       If the dendrogram is not well formed or the level is too high

    See Also
    --------
    best_partition : which directly combines partition_at_level and
    generate_dendrogram : to obtain the partition of highest modularity

    Examples
    --------
    >>> G=nx.erdos_renyi_graph(100, 0.01)
    >>> dendrogram = generate_dendrogram(G)
    >>> for level in range(len(dendrogram) - 1) :
    >>>     print("partition at level", level, "is", partition_at_level(dendrogram, level))  # NOQA
    """
    ### Canonical solution below ###
    partition = dendrogram[0].copy()
    for index in range(1, level + 1):
        for node, community in partition.items():
            partition[node] = dendrogram[index][community]
    return partition


### Unit tests below ###
def check(candidate):
	assert candidate(
    [{0: 0, 1: 0, 2: 0}, {0: 1, 1: 1, 2: 1}, {0: 2, 1: 2, 2: 2}, {0: 3, 1: 3, 2: 3}, {0: 4, 1: 4, 2: 4}, {0: 5, 1: 5, 2: 5}, {0: 6, 1: 6, 2: 6}, {0: 7, 1: 7, 2: 7}], 1) == {0: 1, 1: 1, 2: 1}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 1, 4: 1, 5: 1},
     {0: 2, 1: 2, 2: 2, 3: 0, 4: 0, 5: 0},
     {0: 1, 1: 1, 2: 1, 3: 2, 4: 2, 5: 2}], 0) == {0: 0, 1: 0, 2: 0, 3: 1, 4: 1, 5: 1}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0},
     {0: 1, 1: 1, 2: 1, 3: 1},
     {0: 1, 1: 2, 2: 2, 3: 2},
     {0: 2, 1: 2, 2: 3, 3: 3}], 0) == {0: 0, 1: 0, 2: 0, 3: 0}
	assert candidate(
    [
        {0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 1, 6: 1, 7: 1},
        {0: 0, 1: 0, 2: 0, 3: 1, 4: 1, 5: 1, 6: 2, 7: 2},
        {0: 0, 1: 0, 2: 1, 3: 1, 4: 1, 5: 2, 6: 2, 7: 2},
        {0: 0, 1: 1, 2: 1, 3: 1, 4: 2, 5: 2, 6: 2, 7: 2},
        {0: 1, 1: 1, 2: 1, 3: 2, 4: 2, 5: 2, 6: 2, 7: 2},
    ],
    0,
) == {0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 1, 6: 1, 7: 1}
	assert candidate(
    [{'a': 'a', 'b': 'a', 'c': 'a', 'd': 'b', 'e': 'b', 'f': 'b'},
     {'a': 'a', 'b': 'b', 'c': 'b', 'd': 'a', 'e': 'a', 'f': 'a'},
     {'a': 'b', 'b': 'a', 'c': 'a', 'd': 'a', 'e': 'b', 'f': 'b'},
     {'a': 'b', 'b': 'b', 'c': 'b', 'd': 'b', 'e': 'a', 'f': 'a'},
     {'a': 'a', 'b': 'a', 'c': 'b', 'd': 'a', 'e': 'a', 'f': 'b'},
     {'a': 'a', 'b': 'b', 'c': 'a', 'd': 'b', 'e': 'b', 'f': 'a'},
     {'a': 'b', 'b': 'a', 'c': 'b', 'd': 'b', 'e': 'a', 'f': 'a'},
     {'a': 'b', 'b': 'b', 'c': 'a', 'd': 'a', 'e': 'b', 'f': 'b'}], 0) == {'a': 'a', 'b': 'a', 'c': 'a', 'd': 'b', 'e': 'b', 'f': 'b'}
	assert candidate(
    [{0: 0, 1: 0, 2: 0}, {0: 1, 1: 1, 2: 1}, {0: 2, 1: 2, 2: 2}, {0: 3, 1: 3, 2: 3}, {0: 4, 1: 4, 2: 4}, {0: 5, 1: 5, 2: 5}, {0: 6, 1: 6, 2: 6}, {0: 7, 1: 7, 2: 7}], 0) == {0: 0, 1: 0, 2: 0}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0},
     {0: 1, 1: 1, 2: 1, 3: 1},
     {0: 2, 1: 2, 2: 2, 3: 2}], 0) == {0: 0, 1: 0, 2: 0, 3: 0}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0},
     {0: 1, 1: 1, 2: 1, 3: 1},
     {0: 1, 1: 1, 2: 1, 3: 2},
     {0: 1, 1: 1, 2: 1, 3: 3},
     {0: 2, 1: 2, 2: 2, 3: 4}], 0) == {0: 0, 1: 0, 2: 0, 3: 0}
	assert candidate(
    [{'a': 'a', 'b': 'a'}, {'a': 'b', 'b': 'b'}], 0) == {'a': 'a', 'b': 'a'}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0},
     {0: 1, 1: 1, 2: 1, 3: 1},
     {0: 2, 1: 2, 2: 2, 3: 2}], 1) == {0: 1, 1: 1, 2: 1, 3: 1}
	assert candidate(
    [{0: 0, 1: 0, 2: 0}, {0: 1, 1: 1, 2: 1}, {0: 2, 1: 2, 2: 2}], 1) == {0: 1, 1: 1, 2: 1}
	assert candidate(
    [{'a': 'a', 'b': 'a', 'c': 'a'},
     {'a': 'b', 'b': 'b', 'c': 'b'},
     {'a': 'c', 'b': 'c', 'c': 'c'}], 2) == {'a': 'c', 'b': 'c', 'c': 'c'}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0}, {0: 1, 1: 1, 2: 1, 3: 1}, {0: 2, 1: 2, 2: 2, 3: 2}],  # NOQA
    2) == {0: 2, 1: 2, 2: 2, 3: 2}
	assert candidate(
    [{0: 0, 1: 0, 2: 0},
     {0: 1, 1: 1, 2: 1},
     {0: 1, 1: 1, 2: 2},
     {0: 2, 1: 2, 2: 2}], 1) == {0: 1, 1: 1, 2: 1}
	assert candidate(
    [
        {0: 0, 1: 0, 2: 0, 3: 0},
        {0: 1, 1: 1, 2: 1, 3: 1},
        {0: 2, 1: 2, 2: 2, 3: 2},
        {0: 3, 1: 3, 2: 3, 3: 3},
    ],
    1,
) == {0: 1, 1: 1, 2: 1, 3: 1}
	assert candidate(
    [{0: 0, 1: 0, 2: 0},
     {0: 1, 1: 1, 2: 1},
     {0: 1, 1: 1, 2: 2},
     {0: 2, 1: 2, 2: 2}], 0) == {0: 0, 1: 0, 2: 0}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0},
     {0: 1, 1: 1, 2: 1, 3: 1},
     {0: 1, 1: 2, 2: 2, 3: 2},
     {0: 2, 1: 2, 2: 3, 3: 3}], 1) == {0: 1, 1: 1, 2: 1, 3: 1}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0}, {0: 1, 1: 1, 2: 1, 3: 1}, {0: 2, 1: 2, 2: 2, 3: 2}],  # NOQA
    1) == {0: 1, 1: 1, 2: 1, 3: 1}
	assert candidate(
    [{0: 0, 1: 0, 2: 0}, {0: 1, 1: 1, 2: 1}, {0: 2, 1: 2, 2: 2}], 2) == {0: 2, 1: 2, 2: 2}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0}, {0: 1, 1: 1, 2: 1, 3: 1}, {0: 2, 1: 2, 2: 2, 3: 2}],  # NOQA
    0) == {0: 0, 1: 0, 2: 0, 3: 0}
	assert candidate(
    [{'a': 'a', 'b': 'a'}, {'a': 'b', 'b': 'b'}], 1) == {'a': 'b', 'b': 'b'}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0},
     {0: 1, 1: 1, 2: 1, 3: 1},
     {0: 2, 1: 2, 2: 2, 3: 2}], 2) == {0: 2, 1: 2, 2: 2, 3: 2}
	assert candidate(
    [{'a': 'a', 'b': 'a', 'c': 'a'},
     {'a': 'b', 'b': 'b', 'c': 'b'},
     {'a': 'c', 'b': 'c', 'c': 'c'}], 1) == {'a': 'b', 'b': 'b', 'c': 'b'}
	assert candidate(
    [{0: 0, 1: 0, 2: 0}, {0: 1, 1: 1, 2: 1}, {0: 2, 1: 2, 2: 2}], 0) == {0: 0, 1: 0, 2: 0}
	assert candidate(
    [{'a': 'a', 'b': 'a', 'c': 'a'},
     {'a': 'b', 'b': 'b', 'c': 'b'},
     {'a': 'c', 'b': 'c', 'c': 'c'}], 0) == {'a': 'a', 'b': 'a', 'c': 'a'}
	assert candidate(
    [
        {0: 0, 1: 0, 2: 0, 3: 0},
        {0: 1, 1: 1, 2: 1, 3: 1},
        {0: 2, 1: 2, 2: 2, 3: 2},
        {0: 3, 1: 3, 2: 3, 3: 3},
    ],
    0,
) == {0: 0, 1: 0, 2: 0, 3: 0}
	assert candidate(
    [{0: 0, 1: 0, 2: 0, 3: 0},
     {0: 1, 1: 1, 2: 1, 3: 1},
     {0: 1, 1: 1, 2: 1, 3: 2},
     {0: 1, 1: 1, 2: 1, 3: 3},
     {0: 2, 1: 2, 2: 2, 3: 4}], 1) == {0: 1, 1: 1, 2: 1, 3: 1}
def test_check():
	check(partition_at_level)
