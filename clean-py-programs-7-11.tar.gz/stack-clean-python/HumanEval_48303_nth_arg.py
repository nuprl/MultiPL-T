def nth_arg(n):
    """Returns a function which returns its nth argument"""
    ### Canonical solution below ###
    return lambda *args: args[n]


### Unit tests below ###
def check(candidate):
	assert candidate(0)('first','second', 'third') == 'first'
	assert candidate(1)('foo', 'bar', 'baz') == 'bar'
	assert candidate(2)('apple', 'pear', 'banana') == 'banana'
	assert candidate(1)('first','second', 'third') =='second'
	assert candidate(2)('first','second', 'third') == 'third'
	assert candidate(1)(*range(10)) == 1
	assert candidate(1)(1, 2, 3) == 2
	assert candidate(0)('foo', 'bar') == 'foo'
	assert candidate(1)(1,2) == 2
	assert candidate(0)(1,2,3) == 1
	assert candidate(2)('a', 'b', 'c', 'd') == 'c'
	assert candidate(0)(1) == 1
	assert candidate(1)('a', 'b', 'c') == 'b'
	assert candidate(2)(1, 2, 3) == 3
	assert candidate(3)('a', 'b', 'c', 'd') == 'd'
	assert candidate(0)('a', 'b', 'c') == 'a'
	assert candidate(2)('a', 'b', 'c') == 'c'
	assert candidate(1)('apple', 'pear', 'banana') == 'pear'
	assert candidate(2)(1,2,3) == 3
	assert candidate(0)('apple', 'pear', 'banana') == 'apple'
	assert candidate(1)('a', 'b', 'c', 'd') == 'b'
	assert candidate(0)('foo', 'bar', 'baz') == 'foo'
	assert candidate(2)('foo', 'bar', 'baz') == 'baz'
	assert candidate(0)(1,2) == 1
	assert candidate(0)('a', 'b', 'c', 'd') == 'a'
	assert candidate(1)('foo', 'bar') == 'bar'
	assert candidate(1)(1,2,3) == 2
	assert candidate(0)(1, 2, 3) == 1
def test_check():
	check(nth_arg)
