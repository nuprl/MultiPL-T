def get_where_clause(columns_to_query_lst):
    """
    get_where_clause returns the where clause from the given query list.
    :param columns_to_query_lst: columns for where clause.
    :return:
    """
    ### Canonical solution below ###
    where_str = "where "
    equals_str =[]
    for row in columns_to_query_lst:
        temp_str =  "c." + row + " = t." + row
        equals_str.append(temp_str)
    joined_str = " AND ".join(equals_str)
    where_str = where_str + joined_str
    return where_str


### Unit tests below ###
def check(candidate):
	assert candidate(columns_to_query_lst=["a"]) == "where c.a = t.a", "Error: candidate does not work properly"
	assert candidate(columns_to_query_lst = ['a', 'b', 'c', 'd']) == "where c.a = t.a AND c.b = t.b AND c.c = t.c AND c.d = t.d"
	assert candidate(columns_to_query_lst = ['a', 'b', 'c']) == "where c.a = t.a AND c.b = t.b AND c.c = t.c"
	assert candidate(columns_to_query_lst=["a"]) == "where c.a = t.a"
	assert candidate(columns_to_query_lst=["a","b","c"]) == "where c.a = t.a AND c.b = t.b AND c.c = t.c"
	assert candidate(columns_to_query_lst = ['column1']) == "where c.column1 = t.column1"
	assert candidate(columns_to_query_lst = ['a', 'b']) == "where c.a = t.a AND c.b = t.b"
	assert candidate(columns_to_query_lst = ["col_1"]) == "where c.col_1 = t.col_1", "Incorrect output for candidate"
	assert candidate(columns_to_query_lst = ['column1', 'column2']) == "where c.column1 = t.column1 AND c.column2 = t.column2"
	assert candidate(columns_to_query_lst=['a', 'b']) == "where c.a = t.a AND c.b = t.b"
	assert candidate(columns_to_query_lst=["id"]) == "where c.id = t.id"
	assert candidate(columns_to_query_lst=['a']) == "where c.a = t.a"
	assert candidate(columns_to_query_lst=["col1"]) == "where c.col1 = t.col1"
	assert candidate(
    ["id", "name", "description"]) == "where c.id = t.id AND c.name = t.name AND c.description = t.description"
	assert candidate(columns_to_query_lst=['a', 'b', 'c']) == "where c.a = t.a AND c.b = t.b AND c.c = t.c"
	assert candidate(columns_to_query_lst=["id"]) == "where c.id = t.id", "incorrect output"
	assert candidate(columns_to_query_lst = ['a', 'b', 'c', 'd', 'e']) == "where c.a = t.a AND c.b = t.b AND c.c = t.c AND c.d = t.d AND c.e = t.e"
	assert candidate(
    ["id", "name", "description", "location"]) == "where c.id = t.id AND c.name = t.name AND c.description = t.description AND c.location = t.location"
	assert candidate(columns_to_query_lst=["a","b"]) == "where c.a = t.a AND c.b = t.b"
	assert candidate(columns_to_query_lst=[]) == "where "
	assert candidate(columns_to_query_lst=[]) == "where ", "Error: candidate does not work properly"
	assert candidate([]) == "where ", "candidate function does not work as expected"
	assert candidate(columns_to_query_lst = ["col_1", "col_2"]) == "where c.col_1 = t.col_1 AND c.col_2 = t.col_2", "Incorrect output for candidate"
	assert candidate(columns_to_query_lst=["a", "b", "c"]) == "where c.a = t.a AND c.b = t.b AND c.c = t.c"
	assert candidate(columns_to_query_lst=["id", "name", "date"]) == "where c.id = t.id AND c.name = t.name AND c.date = t.date", "incorrect output"
	assert candidate(columns_to_query_lst=["a", "b", "c"]) == "where c.a = t.a AND c.b = t.b AND c.c = t.c", "Error: where clause is incorrect."
	assert candidate(columns_to_query_lst = ['column1', 'column2', 'column3']) == "where c.column1 = t.column1 AND c.column2 = t.column2 AND c.column3 = t.column3"
	assert candidate(columns_to_query_lst=["id","user_id","name"]) == "where c.id = t.id AND c.user_id = t.user_id AND c.name = t.name"
	assert candidate(columns_to_query_lst=["a", "b", "c", "d"]) == "where c.a = t.a AND c.b = t.b AND c.c = t.c AND c.d = t.d", "Error: candidate does not work properly"
	assert candidate(columns_to_query_lst=["name"]) == "where c.name = t.name"
	assert candidate(["A", "B", "C"]) == "where c.A = t.A AND c.B = t.B AND c.C = t.C"
	assert candidate(["A"]) == "where c.A = t.A"
	assert candidate(columns_to_query_lst=["col1", "col2"]) == "where c.col1 = t.col1 AND c.col2 = t.col2"
	assert candidate(columns_to_query_lst=["id","name"]) == "where c.id = t.id AND c.name = t.name"
	assert candidate(columns_to_query_lst = ["col_1", "col_2", "col_3", "col_4", "col_5"]) == "where c.col_1 = t.col_1 AND c.col_2 = t.col_2 AND c.col_3 = t.col_3 AND c.col_4 = t.col_4 AND c.col_5 = t.col_5", "Incorrect output for candidate"
	assert candidate(columns_to_query_lst=["id", "name", "age"]) == "where c.id = t.id AND c.name = t.name AND c.age = t.age", "The function candidate is not working as expected"
	assert candidate(columns_to_query_lst=["a", "b"]) == "where c.a = t.a AND c.b = t.b", "Error: candidate does not work properly"
	assert candidate(columns_to_query_lst=["col1", "col2", "col3"]) == "where c.col1 = t.col1 AND c.col2 = t.col2 AND c.col3 = t.col3"
	assert candidate(columns_to_query_lst=["id", "name"]) == "where c.id = t.id AND c.name = t.name", "incorrect output"
	assert candidate(columns_to_query_lst = ["col_1", "col_2", "col_3", "col_4"]) == "where c.col_1 = t.col_1 AND c.col_2 = t.col_2 AND c.col_3 = t.col_3 AND c.col_4 = t.col_4", "Incorrect output for candidate"
	assert candidate(columns_to_query_lst=["a"]) == "where c.a = t.a", "Error: where clause is incorrect."
	assert candidate(columns_to_query_lst=["a", "b", "c", "d"]) == "where c.a = t.a AND c.b = t.b AND c.c = t.c AND c.d = t.d"
	assert candidate(columns_to_query_lst=["name", "age"]) == "where c.name = t.name AND c.age = t.age"
	assert candidate(["A", "B", "C", "D"]) == "where c.A = t.A AND c.B = t.B AND c.C = t.C AND c.D = t.D"
	assert candidate(columns_to_query_lst = ['a', 'b', 'c', 'd', 'e', 'f']) == "where c.a = t.a AND c.b = t.b AND c.c = t.c AND c.d = t.d AND c.e = t.e AND c.f = t.f"
	assert candidate(columns_to_query_lst = ["col_1", "col_2", "col_3"]) == "where c.col_1 = t.col_1 AND c.col_2 = t.col_2 AND c.col_3 = t.col_3", "Incorrect output for candidate"
	assert candidate(columns_to_query_lst=["a", "b"]) == "where c.a = t.a AND c.b = t.b"
	assert candidate(columns_to_query_lst=["id", "name"]) == "where c.id = t.id AND c.name = t.name", "The function candidate is not working as expected"
	assert candidate(columns_to_query_lst=["a", "b"]) == "where c.a = t.a AND c.b = t.b", "Error: where clause is incorrect."
def test_check():
	check(get_where_clause)
