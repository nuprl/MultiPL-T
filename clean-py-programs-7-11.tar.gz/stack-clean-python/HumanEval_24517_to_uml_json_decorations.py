def to_uml_json_decorations(**kwargs):
    """ 
     Create dict to be converted to JSON for consumption by Player Piano.
     
     See Also
     --------
     VertexReporterMixin
     """
	### Canonical solution below ###    
    return {
        "id": kwargs["id"],
        "ops": [
            {
                "op": kwargs["op"],
                "path": "/m2/" + kwargs["path"],
                "value": kwargs["value"],
            }
        ],
    }

### Unit tests below ###
def check(candidate):
	assert candidate(id=1, op="add", path="foo/bar", value="baz") == {
    "id": 1,
    "ops": [{"op": "add", "path": "/m2/foo/bar", "value": "baz"}],
}
	assert candidate(id="id", op="op", path="path", value="value") == {
    "id": "id",
    "ops": [
        {
            "op": "op",
            "path": "/m2/path",
            "value": "value",
        }
    ],
}
	assert candidate(
    id="my-id",
    op="add",
    path="my-path",
    value="my-value",
) == {
    "id": "my-id",
    "ops": [
        {
            "op": "add",
            "path": "/m2/my-path",
            "value": "my-value",
        }
    ],
}
	assert candidate(id="0", op="add", path="foo/bar", value="baz") == {
    "id": "0",
    "ops": [
        {
            "op": "add",
            "path": "/m2/foo/bar",
            "value": "baz",
        }
    ],
}
	assert candidate(id="2", op="add", path="d", value="20") == {
    "id": "2",
    "ops": [{"op": "add", "path": "/m2/d", "value": "20"}],
}
	assert candidate(
    id="foo", op="add", path="bar", value="baz"
) == {
    "id": "foo",
    "ops": [
        {"op": "add", "path": "/m2/bar", "value": "baz"}
    ]
}
	assert candidate(id="test", op="add", path="a", value=1) == {
    "id": "test",
    "ops": [{"op": "add", "path": "/m2/a", "value": 1}],
}
	assert candidate(id=1, op="add", path="b", value="c") == {
    "id": 1,
    "ops": [
        {
            "op": "add",
            "path": "/m2/b",
            "value": "c",
        }
    ],
}
	assert candidate(
    id="a", op="add", path="a", value=1
) == {
    "id": "a",
    "ops": [
        {
            "op": "add",
            "path": "/m2/a",
            "value": 1,
        }
    ],
}
	assert candidate(
    id="test_id",
    op="test_op",
    path="test_path",
    value="test_value"
) == {
    "id": "test_id",
    "ops": [
        {
            "op": "test_op",
            "path": "/m2/test_path",
            "value": "test_value",
        }
    ],
}
	assert candidate(
    id="c609763f-8333-4676-b73e-1133d7089c61",
    op="replace",
    path="a",
    value={"b": {"c": "d"}},
) == {
    "id": "c609763f-8333-4676-b73e-1133d7089c61",
    "ops": [
        {
            "op": "replace",
            "path": "/m2/a",
            "value": {"b": {"c": "d"}},
        }
    ],
}
	assert candidate(id=1, op="add", path="a", value=2) == {
    "id": 1,
    "ops": [
        {"op": "add", "path": "/m2/a", "value": 2}
    ]
}
	assert candidate(
    id="1", op="add", path="a", value="b"
) == {
    "id": "1",
    "ops": [
        {
            "op": "add",
            "path": "/m2/a",
            "value": "b",
        }
    ],
}
	assert candidate(
    id="id0",
    op="set",
    path="properties/name",
    value="name0",
) == {
    "id": "id0",
    "ops": [
        {
            "op": "set",
            "path": "/m2/properties/name",
            "value": "name0",
        }
    ],
}
	assert candidate(id="id", op="op", path="path", value="value") == {
    "id": "id",
    "ops": [{"op": "op", "path": "/m2/path", "value": "value"}],
}
	assert candidate(id="m1", op="add", path="a", value=1) == {
    "id": "m1",
    "ops": [
        {
            "op": "add",
            "path": "/m2/a",
            "value": 1,
        }
    ],
}
	assert candidate(
    id="c609763f-8333-4676-b73e-1133d7089c61",
    op="add",
    path="a",
    value={"b": {"c": "d"}},
) == {
    "id": "c609763f-8333-4676-b73e-1133d7089c61",
    "ops": [
        {
            "op": "add",
            "path": "/m2/a",
            "value": {"b": {"c": "d"}},
        }
    ],
}
	assert candidate(
    id="0",
    op="add",
    path="properties/decorations/0",
    value={"type": "text", "text": "hello", "x": 10, "y": 20, "width": 100, "height": 100},
) == {
    "id": "0",
    "ops": [
        {
            "op": "add",
            "path": "/m2/properties/decorations/0",
            "value": {
                "type": "text",
                "text": "hello",
                "x": 10,
                "y": 20,
                "width": 100,
                "height": 100,
            },
        }
    ],
}
	assert candidate(
    id="1",
    op="add",
    path="1",
    value="2",
) == {
    "id": "1",
    "ops": [
        {
            "op": "add",
            "path": "/m2/1",
            "value": "2",
        }
    ],
}
	assert candidate(id="1", op="add", path="2", value="3") == {
    "id": "1",
    "ops": [
        {
            "op": "add",
            "path": "/m2/2",
            "value": "3",
        }
    ],
}
	assert candidate(
    id="123",
    op="replace",
    path="1/2/3",
    value="abc",
) == {
    "id": "123",
    "ops": [
        {
            "op": "replace",
            "path": "/m2/1/2/3",
            "value": "abc",
        }
    ],
}
	assert candidate(id="1", op="add", path="foo", value="bar") == {
    "id": "1",
    "ops": [{"op": "add", "path": "/m2/foo", "value": "bar"}],
}
	assert candidate(id=1, op="add", path="foo", value="bar") == {
    "id": 1,
    "ops": [{"op": "add", "path": "/m2/foo", "value": "bar"}],
}
	assert candidate(id="a", op="add", path="b", value="c") == {
    "id": "a",
    "ops": [
        {
            "op": "add",
            "path": "/m2/b",
            "value": "c",
        }
    ],
}
	assert candidate(
    id=1, op="add", path="x", value=2
) == {
    "id": 1,
    "ops": [
        {
            "op": "add",
            "path": "/m2/x",
            "value": 2,
        }
    ],
}
	assert candidate(
    id="1",
    op="add",
    path="1.0/0",
    value={"type": "int", "value": 5}
) == {
    "id": "1",
    "ops": [
        {
            "op": "add",
            "path": "/m2/1.0/0",
            "value": {"type": "int", "value": 5}
        }
    ]
}
	assert candidate(id="id", path="path", op="op", value="value") == {
    "id": "id",
    "ops": [
        {
            "op": "op",
            "path": "/m2/path",
            "value": "value",
        }
    ],
}
	assert candidate(
    id="id", op="op", path="path", value="value"
) == {
    "id": "id",
    "ops": [
        {
            "op": "op",
            "path": "/m2/path",
            "value": "value",
        }
    ],
}
	assert candidate(id="300", path="300", value="300", op="add") == {
    "id": "300",
    "ops": [
        {
            "op": "add",
            "path": "/m2/300",
            "value": "300",
        }
    ],
}
	assert candidate(
    id="123", op="add", path="path/to/attribute", value="new value"
) == {
    "id": "123",
    "ops": [{"op": "add", "path": "/m2/path/to/attribute", "value": "new value"}],
}
def test_check():
	check(to_uml_json_decorations)
