def harmonize_entities(default_ents, requested_ents):
    """ Harmonizes two dictionaries representing default_ents and requested requested_ents.
     
     Given two dictionaries of entity: boolean key: value pairs, returns a
     dictionary where the values of entities specified in `requested_ents` override those specified
     in `default_ents`. Entities present in `default_ents` but not in `requested_ents` will be set to
     False by default.
     
     Args:
     default_ents (dict): contains entity (str): boolean key: value pairs representing which
     entities should be annotated in a given text.
     requested_ents (dict): contains entity (str): boolean key: value pairs representing which
     entities should be predicted in a given text.
     
     Returns: a dictionary containing all key, value pairs in `default_ents`, where values in
     `requested_ents` override those in default_ents. Any key in `default_ents` but not in
     `requested_ents` will have its value set to False by default.
     """
	### Canonical solution below ###    
    entities = {}
    for ent in default_ents:
        entities[ent] = False
    for ent, value in requested_ents.items():
        if ent in entities:
            entities[ent] = value

    return entities

### Unit tests below ###
def check(candidate):
	assert candidate(default_ents={}, requested_ents={}) == {}
	assert candidate(default_ents={'entity': False}, requested_ents={}) == {'entity': False}
	assert candidate(default_ents={"a": False}, requested_ents={"a": True}) == {"a": True}
	assert candidate(default_ents={'entity1': True, 'entity2': False}, requested_ents={'entity1': True, 'entity2': True}) == {'entity1': True, 'entity2': True}
	assert candidate(default_ents={"ent1": False}, requested_ents={"ent1": True}) == \
    {"ent1": True}
	assert candidate(default_ents={'entity1': True, 'entity2': False}, requested_ents={'entity1': True}) == {'entity1': True, 'entity2': False}
	assert candidate(default_ents = {
    "GPE": True,
    "PERSON": True,
    "ORG": True
}, requested_ents = {
    "GPE": False,
    "PERSON": False,
    "ORG": False
}) == {
    "GPE": False,
    "PERSON": False,
    "ORG": False
}
	assert candidate(default_ents={"PERSON": True}, requested_ents={"PERSON": False}) == {"PERSON": False}
	assert candidate(default_ents={'entity1': True, 'entity2': False}, requested_ents={'entity1': True, 'entity2': False}) == {'entity1': True, 'entity2': False}
	assert candidate(default_ents={"A": False}, requested_ents={"A": True}) == {"A": True}
	assert candidate(
    default_ents={'B-PER': False, 'I-PER': False, 'B-LOC': False, 'I-LOC': False},
    requested_ents={'B-PER': True, 'I-PER': True, 'B-LOC': False, 'I-LOC': False}
) == {
    'B-PER': True,
    'I-PER': True,
    'B-LOC': False,
    'I-LOC': False
}
	assert candidate(default_ents={'entity': True}, requested_ents={'entity': True}) == {'entity': True}
	assert candidate(
    default_ents={'person': False, 'location': False, 'organization': False,'misc': False},
    requested_ents={'person': False, 'location': True, 'organization': False,'misc': False}
) == {'person': False, 'location': True, 'organization': False,'misc': False}
	assert candidate(default_ents={"a": True}, requested_ents={"a": False}) == {"a": False}
	assert candidate(default_ents = {'B-PER': False, 'I-PER': False, 'B-LOC': False, 'I-LOC': False, 'B-ORG': False, 'I-ORG': False}, requested_ents = {'B-PER': True, 'I-PER': True}) == {'B-PER': True, 'I-PER': True, 'B-LOC': False, 'I-LOC': False, 'B-ORG': False, 'I-ORG': False}
	assert candidate(
    default_ents={'PERSON': True}, requested_ents={'PERSON': True}) == {'PERSON': True}
	assert candidate(
    default_ents={
        "ORG": True,
        "GPE": False,
    },
    requested_ents={
        "ORG": False,
    },
) == {
    "ORG": False,
    "GPE": False,
}
	assert candidate(
    {"PERSON": True, "GPE": False, "ORG": True}, {"PERSON": True, "ORG": True}
) == {"PERSON": True, "GPE": False, "ORG": True}
	assert candidate(
    default_ents={"PERSON": True, "ORG": False}, requested_ents={"PERSON": True}
) == {"PERSON": True, "ORG": False}
	assert candidate(default_ents={'PERSON': False}, requested_ents={'PERSON': True}) == {'PERSON': True}
	assert candidate(default_ents={"A": True}, requested_ents={"A": False}) == {"A": False}
	assert candidate({"PERSON": True}, {"PERSON": True}) == {"PERSON": True}
	assert candidate(default_ents={'PERSON': True}, requested_ents={'PERSON': True}) == {'PERSON': True}
	assert candidate(default_ents={'entity1': True, 'entity2': False}, requested_ents={'entity1': False}) == {'entity1': False, 'entity2': False}
	assert candidate(
    default_ents={'person': False, 'location': False, 'organization': False,'misc': False},
    requested_ents={'person': True, 'location': False, 'organization': True,'misc': True}
) == {'person': True, 'location': False, 'organization': True,'misc': True}
	assert candidate(default_ents = {'B-PER': False, 'I-PER': False, 'B-LOC': False, 'I-LOC': False, 'B-ORG': False, 'I-ORG': False}, requested_ents = {'B-PER': True}) == {'B-PER': True, 'I-PER': False, 'B-LOC': False, 'I-LOC': False, 'B-ORG': False, 'I-ORG': False}
	assert candidate(default_ents={"A": True}, requested_ents={"A": True}) == {"A": True}
	assert candidate(default_ents={"ent1": True}, requested_ents={"ent1": True}) == \
    {"ent1": True}
	assert candidate(
    default_ents={'PERSON': True}, requested_ents={'PERSON': False}) == {'PERSON': False}
	assert candidate({"PERSON": True, "GPE": False}, {"PERSON": True}) == {
    "PERSON": True,
    "GPE": False,
}
	assert candidate(default_ents={"ent": True}, requested_ents={"ent": True}) == {"ent": True}
	assert candidate(
    default_ents={
        "ORG": True,
        "GPE": False,
    },
    requested_ents={
        "ORG": True,
    },
) == {
    "ORG": True,
    "GPE": False,
}
	assert candidate(default_ents={'entity': True}, requested_ents={'entity': False}) == {'entity': False}
	assert candidate(default_ents={'PERSON': True}, requested_ents={'PERSON': False}) == {'PERSON': False}
	assert candidate(default_ents={"ent": True}, requested_ents={"ent": False}) == {"ent": False}
	assert candidate(default_ents = {
    "GPE": True,
    "PERSON": True,
    "ORG": True
}, requested_ents = {
    "GPE": False,
    "PERSON": True,
    "ORG": True
}) == {
    "GPE": False,
    "PERSON": True,
    "ORG": True
}
	assert candidate(default_ents = {'B-PER': False, 'I-PER': False, 'B-LOC': False, 'I-LOC': False, 'B-ORG': False, 'I-ORG': False}, requested_ents = {}) == {'B-PER': False, 'I-PER': False, 'B-LOC': False, 'I-LOC': False, 'B-ORG': False, 'I-ORG': False}
	assert candidate(default_ents={'PERSON': False}, requested_ents={'PERSON': False}) == {'PERSON': False}
	assert candidate(default_ents={"ORG": True}, requested_ents={"ORG": False}) == {"ORG": False}
	assert candidate(
    {"PERSON": True, "LOC": True, "ORG": True}, {"PERSON": True, "LOC": False, "ORG": False}
) == {"PERSON": True, "LOC": False, "ORG": False}
	assert candidate(default_ents={'foo': True}, requested_ents={'foo': True}) == {'foo': True}
	assert candidate(
    default_ents={'B-PER': False, 'I-PER': False, 'B-LOC': False, 'I-LOC': False},
    requested_ents={'B-PER': False, 'I-PER': False, 'B-LOC': True, 'I-LOC': True}
) == {
    'B-PER': False,
    'I-PER': False,
    'B-LOC': True,
    'I-LOC': True
}
def test_check():
	check(harmonize_entities)
