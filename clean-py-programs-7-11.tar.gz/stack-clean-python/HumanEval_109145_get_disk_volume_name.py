def get_disk_volume_name(instance_name, diskNumber):
    """ Return persistent volume name based on instance name and disk number
     """
	### Canonical solution below ###    

    return '%s-disk-%02d' % (instance_name, diskNumber)

### Unit tests below ###
def check(candidate):
	assert candidate(
    'instance-name', 99) == 'instance-name-disk-99'
	assert candidate( 'instance1', 2 ) == 'instance1-disk-02'
	assert candidate( 'instance1', 26 ) == 'instance1-disk-26'
	assert candidate(instance_name='bar', diskNumber=2) == 'bar-disk-02'
	assert candidate(instance_name="test", diskNumber=2) == "test-disk-02"
	assert candidate(
    'foo-bar-123', 9) == 'foo-bar-123-disk-09'
	assert candidate(instance_name='foo', diskNumber=11) == 'foo-disk-11'
	assert candidate(
    'foo-bar-123', 5) == 'foo-bar-123-disk-05'
	assert candidate(
    'foo-bar-123', 2) == 'foo-bar-123-disk-02'
	assert candidate(
    'instance-1', 1) == 'instance-1-disk-01'
	assert candidate(
    'instance-1', 0) == 'instance-1-disk-00', "disk name"
	assert candidate(instance_name='my-instance', diskNumber=10) =='my-instance-disk-10'
	assert candidate(instance_name='my-vm', diskNumber=11) =='my-vm-disk-11'
	assert candidate(u'instance-1', 10) == u'instance-1-disk-10'
	assert candidate(instance_name='test-instance', diskNumber=8) == 'test-instance-disk-08'
	assert candidate(
   'myinstance',
    21) =='myinstance-disk-21'
	assert candidate(
    'foo-bar-123', 8) == 'foo-bar-123-disk-08'
	assert candidate(instance_name='foo', diskNumber=2) == 'foo-disk-02'
	assert candidate(
    'test-instance',
    8
) == 'test-instance-disk-08'
	assert candidate(instance_name='test', diskNumber=0) == 'test-disk-00'
	assert candidate(
    'instance-1', 999) == 'instance-1-disk-999', "disk name"
	assert candidate(instance_name='my-instance', diskNumber=0) =='my-instance-disk-00'
	assert candidate(
   'myinstance',
    9) =='myinstance-disk-09'
	assert candidate(
   'myinstance',
    12) =='myinstance-disk-12'
	assert candidate(instance_name='my-instance', diskNumber=99) =='my-instance-disk-99'
	assert candidate(
    'instance-1', 0) == 'instance-1-disk-00'
	assert candidate('my-instance', 1 ) =='my-instance-disk-01'
	assert candidate( 'instance1', 12 ) == 'instance1-disk-12'
	assert candidate(
    'instance-name', 2) == 'instance-name-disk-02'
	assert candidate(instance_name='myinstance', diskNumber=1) =='myinstance-disk-01'
	assert candidate(
   'my-instance',
    1) =='my-instance-disk-01'
	assert candidate(instance_name='foo-bar-baz', diskNumber=0) == 'foo-bar-baz-disk-00'
	assert candidate(
    'foo-bar-123', 4) == 'foo-bar-123-disk-04'
	assert candidate(
    'test-instance',
    6
) == 'test-instance-disk-06'
	assert candidate(instance_name='my-instance', diskNumber=4) =='my-instance-disk-04'
	assert candidate(instance_name='my-vm', diskNumber=3) =='my-vm-disk-03'
	assert candidate(
    'instance-1', 99) == 'instance-1-disk-99', "disk name"
	assert candidate(
    'instance-1', 9) == 'instance-1-disk-09'
	assert candidate(
    'foo-bar-123', 0) == 'foo-bar-123-disk-00'
	assert candidate(
    'instance-123', 1) == 'instance-123-disk-01', 'candidate test failed'
	assert candidate(
    'instance-1', 10) == 'instance-1-disk-10'
	assert candidate(instance_name='foo', diskNumber=99) == 'foo-disk-99'
	assert candidate(instance_name='my-vm', diskNumber=7) =='my-vm-disk-07'
	assert candidate(instance_name='test-vm-1', diskNumber=11) == 'test-vm-1-disk-11'
	assert candidate(u'instance-1', 9) == u'instance-1-disk-09'
	assert candidate('my-instance', 9999 ) =='my-instance-disk-9999'
	assert candidate(
    instance_name='test-instance',
    diskNumber=1
) == 'test-instance-disk-01'
	assert candidate(
   'myinstance',
    20) =='myinstance-disk-20'
	assert candidate(instance_name='my-instance', diskNumber=2) =='my-instance-disk-02'
	assert candidate('my-instance', 101 ) =='my-instance-disk-101'
	assert candidate(instance_name='my-instance', diskNumber=1) =='my-instance-disk-01'
	assert candidate('my-instance', 11 ) =='my-instance-disk-11'
	assert candidate(instance_name='test-instance', diskNumber=100) == 'test-instance-disk-100'
	assert candidate(
    'test-instance',
    9
) == 'test-instance-disk-09'
	assert candidate(instance_name='foo-bar', diskNumber=0) == 'foo-bar-disk-00'
	assert candidate(
    'instance-1', 100) == 'instance-1-disk-100', "disk name"
	assert candidate( 'instance1', 513 ) == 'instance1-disk-513'
	assert candidate(
   'myinstance',
    17) =='myinstance-disk-17'
	assert candidate(instance_name='my-instance', diskNumber=9) =='my-instance-disk-09'
	assert candidate(instance_name='my-vm', diskNumber=6) =='my-vm-disk-06'
	assert candidate(
    'test-instance',
    5
) == 'test-instance-disk-05'
	assert candidate(instance_name='my-vm', diskNumber=9) =='my-vm-disk-09'
	assert candidate(instance_name='test-vm-1', diskNumber=2) == 'test-vm-1-disk-02'
	assert candidate(
    'test-instance',
    3
) == 'test-instance-disk-03'
	assert candidate(
    'test-instance',
    1
) == 'test-instance-disk-01'
	assert candidate(instance_name='test-instance', diskNumber=201) == 'test-instance-disk-201'
	assert candidate(instance_name='test-vm-1', diskNumber=1) == 'test-vm-1-disk-01'
	assert candidate( 'instance1', 0 ) == 'instance1-disk-00'
	assert candidate(instance_name='test', diskNumber=99) == 'test-disk-99'
	assert candidate(instance_name='test-instance', diskNumber=7) == 'test-instance-disk-07'
	assert candidate(u'instance-1', 1) == u'instance-1-disk-01'
	assert candidate('my-instance', 1000 ) =='my-instance-disk-1000'
	assert candidate('my-instance', 9 ) =='my-instance-disk-09'
	assert candidate(
    'instance-1', 9999) == 'instance-1-disk-9999', "disk name"
	assert candidate(instance_name='foo-bar', diskNumber=1) == 'foo-bar-disk-01'
	assert candidate(u'instance-1', 100) == u'instance-1-disk-100'
	assert candidate(
   'my-instance',
    10) =='my-instance-disk-10'
	assert candidate(instance_name='myinstance', diskNumber=9) =='myinstance-disk-09'
	assert candidate('my-instance', 99 ) =='my-instance-disk-99'
	assert candidate('my-instance', 2 ) =='my-instance-disk-02'
	assert candidate('my-instance', 1001 ) =='my-instance-disk-1001'
	assert candidate(
    'instance-1', 1) == 'instance-1-disk-01', "disk name"
	assert candidate(instance_name='my-instance', diskNumber=5) =='my-instance-disk-05'
	assert candidate(instance_name='my-instance', diskNumber=8) =='my-instance-disk-08'
	assert candidate(instance_name='test-instance', diskNumber=200) == 'test-instance-disk-200'
	assert candidate(instance_name='foo', diskNumber=1) == 'foo-disk-01'
	assert candidate(instance_name='test-instance', diskNumber=9) == 'test-instance-disk-09'
	assert candidate(instance_name='test-instance', diskNumber=99) == 'test-instance-disk-99'
	assert candidate(instance_name='test', diskNumber=9) == 'test-disk-09'
	assert candidate(instance_name='foo', diskNumber=1001) == 'foo-disk-1001'
	assert candidate(
   'myinstance',
    13) =='myinstance-disk-13'
	assert candidate(instance_name='my-instance', diskNumber=15) =='my-instance-disk-15'
	assert candidate(instance_name='myinstance', diskNumber=2) =='myinstance-disk-02'
	assert candidate(
   'myinstance',
    10) =='myinstance-disk-10'
	assert candidate(
    'instance-name', 1) == 'instance-name-disk-01'
	assert candidate(
    'instance-name', 100) == 'instance-name-disk-100'
	assert candidate(u'instance-1', 999) == u'instance-1-disk-999'
	assert candidate(instance_name='my-instance', diskNumber=3) =='my-instance-disk-03'
	assert candidate(instance_name='my-instance', diskNumber=6) =='my-instance-disk-06'
	assert candidate(instance_name='test-instance', diskNumber=3) == 'test-instance-disk-03'
	assert candidate(
    'foo-bar-123', 6) == 'foo-bar-123-disk-06'
	assert candidate( 'instance1', 512 ) == 'instance1-disk-512'
	assert candidate(
    'test-instance',
    11
) == 'test-instance-disk-11'
	assert candidate( 'instance1', 1 ) == 'instance1-disk-01'
	assert candidate( 'instance1', 25 ) == 'instance1-disk-25'
	assert candidate(instance_name='my-vm', diskNumber=4) =='my-vm-disk-04'
	assert candidate(u'instance-1', 99999) == u'instance-1-disk-99999'
	assert candidate(
    'foo-bar-123', 1) == 'foo-bar-123-disk-01'
	assert candidate(
   'myinstance',
    15) =='myinstance-disk-15'
	assert candidate(instance_name='foo-bar', diskNumber=99) == 'foo-bar-disk-99'
	assert candidate(instance_name='test-instance', diskNumber=2) == 'test-instance-disk-02'
	assert candidate(instance_name='baz', diskNumber=3) == 'baz-disk-03'
	assert candidate('my-instance', 999 ) =='my-instance-disk-999'
	assert candidate(instance_name='test-instance', diskNumber=5) == 'test-instance-disk-05'
	assert candidate(
   'my-instance',
    99) =='my-instance-disk-99'
	assert candidate(instance_name='foo', diskNumber=999) == 'foo-disk-999'
	assert candidate(u'instance-1', 1000) == u'instance-1-disk-1000'
	assert candidate(instance_name='test-instance', diskNumber=101) == 'test-instance-disk-101'
	assert candidate(
    'instance-1', 10) == 'instance-1-disk-10', "disk name"
	assert candidate(instance_name='test-instance', diskNumber=1) == 'test-instance-disk-01'
	assert candidate(instance_name='my-vm', diskNumber=5) =='my-vm-disk-05'
	assert candidate(instance_name='my-vm', diskNumber=2) =='my-vm-disk-02'
	assert candidate(
    'test-instance',
    7
) == 'test-instance-disk-07'
	assert candidate(
    'instance-1', 100) == 'instance-1-disk-100'
	assert candidate(instance_name='my-vm', diskNumber=8) =='my-vm-disk-08'
	assert candidate(instance_name='test-instance', diskNumber=10) == 'test-instance-disk-10'
	assert candidate(
   'myinstance',
    16) =='myinstance-disk-16'
	assert candidate(instance_name='test-instance', diskNumber=199) == 'test-instance-disk-199'
	assert candidate(
    'test-instance',
    0
) == 'test-instance-disk-00'
	assert candidate('my-instance', 0 ) =='my-instance-disk-00'
	assert candidate(instance_name='test', diskNumber=1) == 'test-disk-01'
	assert candidate(
    'instance-1', 1000) == 'instance-1-disk-1000', "disk name"
	assert candidate(
    'instance-1', 9) == 'instance-1-disk-09', "disk name"
	assert candidate(instance_name='foo', diskNumber=9) == 'foo-disk-09'
	assert candidate(
    'test-instance',
    4
) == 'test-instance-disk-04'
	assert candidate(instance_name='my-instance', diskNumber=7) =='my-instance-disk-07'
	assert candidate(u'instance-1', 10000) == u'instance-1-disk-10000'
	assert candidate( 'instance1', 123 ) == 'instance1-disk-123'
	assert candidate(
   'my-instance',
    20) =='my-instance-disk-20'
	assert candidate(
   'myinstance',
    19) =='myinstance-disk-19'
	assert candidate(
   'myinstance',
    14) =='myinstance-disk-14'
	assert candidate(instance_name='test-instance', diskNumber=4) == 'test-instance-disk-04'
	assert candidate(instance_name='foo', diskNumber=100) == 'foo-disk-100'
	assert candidate( 'instance1', 11 ) == 'instance1-disk-11'
	assert candidate(
    'test-instance',
    10
) == 'test-instance-disk-10'
	assert candidate(instance_name='my-vm', diskNumber=1) =='my-vm-disk-01'
	assert candidate(instance_name='foo', diskNumber=1000) == 'foo-disk-1000'
	assert candidate(instance_name='my-vm', diskNumber=10) =='my-vm-disk-10'
	assert candidate(
    'instance-name', 999) == 'instance-name-disk-999'
	assert candidate(instance_name='foo-bar', diskNumber=10) == 'foo-bar-disk-10'
	assert candidate(instance_name='foo-bar', diskNumber=9) == 'foo-bar-disk-09'
	assert candidate(instance_name='foo', diskNumber=0) == 'foo-disk-00'
	assert candidate(
    'instance-name', 9) == 'instance-name-disk-09'
	assert candidate('my-instance', 10 ) =='my-instance-disk-10'
	assert candidate(
    'foo-bar-123', 3) == 'foo-bar-123-disk-03'
	assert candidate(u'instance-1', 9999) == u'instance-1-disk-9999'
	assert candidate(instance_name='my-instance', diskNumber=11) =='my-instance-disk-11'
	assert candidate(instance_name='foo', diskNumber=101) == 'foo-disk-101'
	assert candidate(u'instance-1', 0) == u'instance-1-disk-00'
	assert candidate(u'instance-1', 99) == u'instance-1-disk-99'
	assert candidate(
    'instance-name', 10) == 'instance-name-disk-10'
	assert candidate( 'instance1', 124 ) == 'instance1-disk-124'
	assert candidate(
    'instance-1', 99) == 'instance-1-disk-99'
	assert candidate(instance_name='my-instance', diskNumber=25) =='my-instance-disk-25'
	assert candidate(
   'myinstance',
    1) =='myinstance-disk-01'
	assert candidate(instance_name='test-instance', diskNumber=11) == 'test-instance-disk-11'
	assert candidate(
   'myinstance',
    18) =='myinstance-disk-18'
	assert candidate(instance_name='myinstance', diskNumber=0) =='myinstance-disk-00'
	assert candidate(
    'instance-name', 0) == 'instance-name-disk-00'
	assert candidate(
   'myinstance',
    11) =='myinstance-disk-11'
	assert candidate(
    'test-instance',
    2
) == 'test-instance-disk-02'
	assert candidate(instance_name='foo', diskNumber=10) == 'foo-disk-10'
	assert candidate(
    'foo-bar-123', 7) == 'foo-bar-123-disk-07'
	assert candidate( 'instance1', 27 ) == 'instance1-disk-27'
	assert candidate( 'instance1', 13 ) == 'instance1-disk-13'
	assert candidate(instance_name='test', diskNumber=10) == 'test-disk-10'
	assert candidate('my-instance', 100 ) =='my-instance-disk-100'
	assert candidate(instance_name='test-instance', diskNumber=0) == 'test-instance-disk-00'
	assert candidate( 'instance1', 122 ) == 'instance1-disk-122'
	assert candidate(instance_name='test-instance', diskNumber=6) == 'test-instance-disk-06'
	assert candidate(instance_name='my-vm', diskNumber=0) =='my-vm-disk-00'
def test_check():
	check(get_disk_volume_name)
