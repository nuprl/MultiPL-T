def key_by_license_plate_month(element):
    """ 
     here we will construct a multi ((keys), (values)) tuple row
     
     we're preparing to aggregate by license plate and month and we would aggregated fields:
     count(1), sum(total), sum(cornsilk), sum(slate_gray), sum(navajo_white), mean(total)
     
     multi-aggregation on a tuple of values is accomplished by
     beam.CombineByKey and beam.combiners.TupleCombineFn
     """
	### Canonical solution below ###    
    return (
        (element['license_plate'], element['month']),
        (1, element['total'], element['cornsilk'], element['slate_gray'], element['navajo_white'], element['total'])
    )

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'license_plate': 'AAA124','month': '2016-05', 'total': 50, 'cornsilk': 6,'slate_gray': 7, 'navajo_white': 8}
) == (
    ('AAA124', '2016-05'),
    (1, 50, 6, 7, 8, 50.0)
)
	assert candidate(
    {
        'license_plate': 'abc',
       'month': '2019-02',
        'total': 100,
        'cornsilk': 20,
       'slate_gray': 10,
        'navajo_white': 15
    }
) == (
    ('abc', '2019-02'),
    (1, 100, 20, 10, 15, 100)
)
	assert candidate(
    {'license_plate': 'ABC-123','month': '2021-01', 'total': 1000, 'cornsilk': 0,'slate_gray': 0, 'navajo_white': 0}) == (
    ('ABC-123', '2021-01'),
    (1, 1000, 0, 0, 0, 1000)
)
	assert candidate(
    {'license_plate': 'ABC123','month': '2015-01', 'total': 100, 'cornsilk': 50,'slate_gray': 20, 'navajo_white': 30}) == (
    ('ABC123', '2015-01'),
    (1, 100, 50, 20, 30, 100)
)
	assert candidate(
    {'license_plate': '1', 'total': 100, 'cornsilk': 10,'slate_gray': 10, 'navajo_white': 10,'month': 1}
) == (('1', 1), (1, 100, 10, 10, 10, 100))
	assert candidate(
    {
        'license_plate': 'abc123',
       'month': '2019-01',
        'total': 30,
        'cornsilk': 20,
       'slate_gray': 10,
        'navajo_white': 10,
    }) == (
    ('abc123', '2019-01'),
    (1, 30, 20, 10, 10, 30)
)
	assert candidate(
    {'month': '2016-01', 'license_plate': 'abc123', 'total': 1000, 'cornsilk': 10,'slate_gray': 100, 'navajo_white': 200}) == (
    ('abc123', '2016-01'), (1, 1000, 10, 100, 200, 1000))
	assert candidate(
    {'license_plate': '111','month': '2020-12', 'total': 200, 'cornsilk': 100,'slate_gray': 200, 'navajo_white': 500}) == \
    (('111', '2020-12'), (1, 200, 100, 200, 500, 200))
	assert candidate(
    {'license_plate': 'A01234','month': '2020-01', 'total': 120, 'cornsilk': 10,'slate_gray': 20, 'navajo_white': 30}) == (
    ('A01234', '2020-01'), (1, 120, 10, 20, 30, 120))
	assert candidate(
    {'license_plate': 'def456','month': 1, 'total': 100, 'cornsilk': 20,'slate_gray': 15, 'navajo_white': 10}) == (
    ('def456', 1), (1, 100, 20, 15, 10, 100))
	assert candidate(
    {'license_plate': 'A123', 'total': 10.0, 'cornsilk': 3.0,'slate_gray': 4.0, 'navajo_white': 5.0,'month': 1}) == (
    ('A123', 1), (1, 10.0, 3.0, 4.0, 5.0, 10.0)
)
	assert candidate(dict(license_plate='abc123', month=2, total=2, cornsilk=2, slate_gray=2, navajo_white=2)) == (('abc123', 2), (1, 2, 2, 2, 2, 2))
	assert candidate(
    {
        'license_plate': 'A1234',
       'month': 1,
        'total': 30.0,
        'cornsilk': 10.0,
       'slate_gray': 10.0,
        'navajo_white': 10.0
    }
) == (
    ('A1234', 1),
    (1, 30.0, 10.0, 10.0, 10.0, 30.0)
)
	assert candidate(
    {
        'license_plate': 'abc',
       'month': '2019-01',
        'total': 100,
        'cornsilk': 10,
       'slate_gray': 5,
        'navajo_white': 10
    }
) == (
    ('abc', '2019-01'),
    (1, 100, 10, 5, 10, 100)
)
	assert candidate(
    {'license_plate': 'ABC-123','month': '2021-02', 'total': 30.0, 'cornsilk': 40.0,'slate_gray': 50.0, 'navajo_white': 60.0}) == (
    ('ABC-123', '2021-02'), (1, 30.0, 40.0, 50.0, 60.0, 30.0))
	assert candidate(
    { 'license_plate': 'ABC123','month': 2, 'total': 15, 'cornsilk': 0,'slate_gray': 0, 'navajo_white': 0 }
) == (('ABC123', 2), (1, 15, 0, 0, 0, 15))
	assert candidate(
    { 'license_plate': 'ABC123','month': 3, 'total': 16, 'cornsilk': 0,'slate_gray': 0, 'navajo_white': 0 }
) == (('ABC123', 3), (1, 16, 0, 0, 0, 16))
	assert candidate(
    {'license_plate': 'ABC-123','month': '2021-01', 'total': 10.0, 'cornsilk': 20.0,'slate_gray': 30.0, 'navajo_white': 40.0}) == (
    ('ABC-123', '2021-01'), (1, 10.0, 20.0, 30.0, 40.0, 10.0))
	assert candidate(
    {
        'license_plate': 'B5555',
       'month': 2,
        'total': 15.0,
        'cornsilk': 5.0,
       'slate_gray': 5.0,
        'navajo_white': 5.0
    }
) == (
    ('B5555', 2),
    (1, 15.0, 5.0, 5.0, 5.0, 15.0)
)
	assert candidate(
    {'license_plate': 'AAA-000','month': 201801, 'total': 100, 'cornsilk': 50,'slate_gray': 20, 'navajo_white': 15}
) == (('AAA-000', 201801), (1, 100, 50, 20, 15, 100))
	assert candidate(
    {'license_plate': 'abc123','month': 1, 'total': 100, 'cornsilk': 20,'slate_gray': 15, 'navajo_white': 10}) == (
    ('abc123', 1), (1, 100, 20, 15, 10, 100))
	assert candidate(
    {'license_plate': 'AAA123','month': '2016-05', 'total': 50, 'cornsilk': 6,'slate_gray': 7, 'navajo_white': 8}
) == (
    ('AAA123', '2016-05'),
    (1, 50, 6, 7, 8, 50.0)
)
	assert candidate(
    {'license_plate': 'ABC-123','month': '2021-01', 'total': 20.0, 'cornsilk': 30.0,'slate_gray': 40.0, 'navajo_white': 50.0}) == (
    ('ABC-123', '2021-01'), (1, 20.0, 30.0, 40.0, 50.0, 20.0))
	assert candidate(
    {'license_plate': 'AAA1111','month': '2016-01-01', 'total': 100, 'cornsilk': 50,'slate_gray': 0, 'navajo_white': 50}
) == (
    ('AAA1111', '2016-01-01'),
    (1, 100, 50, 0, 50, 100)
)
	assert candidate(
    {'license_plate': 'LP-123','month': '2019-02', 'total': 300, 'cornsilk': 30,'slate_gray': 90, 'navajo_white': 120}) == (
    ('LP-123', '2019-02'),
    (1, 300, 30, 90, 120, 300)
)
	assert candidate(
    {'license_plate': 'A123','month': '2017-01', 'total': 100, 'cornsilk': 10,'slate_gray': 20, 'navajo_white': 30}) == (
    ('A123', '2017-01'), (1, 100, 10, 20, 30, 100))
	assert candidate(
    { 'license_plate': 'ABC123','month': 4, 'total': 17, 'cornsilk': 0,'slate_gray': 0, 'navajo_white': 0 }
) == (('ABC123', 4), (1, 17, 0, 0, 0, 17))
	assert candidate(
    {
        "license_plate": "1234",
        "month": 1,
        "total": 2000,
        "cornsilk": 200,
        "slate_gray": 20,
        "navajo_white": 40,
    }
) == (
    ("1234", 1),
    (1, 2000, 200, 20, 40, 2000)
)
	assert candidate(
    {'license_plate': 'abc-123','month': 5, 'total': 100, 'cornsilk': 1,'slate_gray': 0, 'navajo_white': 0}) == (
    ('abc-123', 5),
    (1, 100, 1, 0, 0, 100)
)
	assert candidate(
    {'license_plate': '123','month': '2019-03', 'total': 1000, 'cornsilk': 100,'slate_gray': 200, 'navajo_white': 300}) == \
    (('123', '2019-03'), (1, 1000, 100, 200, 300, 1000))
	assert candidate(
    {
        'license_plate': 'K12345',
       'month': '2019-03',
        'total': 100,
        'cornsilk': 200,
       'slate_gray': 300,
        'navajo_white': 400
    }) == (
    ('K12345', '2019-03'),
    (1, 100, 200, 300, 400, 100.0)
)
	assert candidate(
    {'license_plate': '123-456','month': '2019-01', 'total': 100, 'cornsilk': 20,'slate_gray': 30, 'navajo_white': 40}) == (
        ('123-456', '2019-01'), (1, 100, 20, 30, 40, 100))
	assert candidate(
    {'license_plate': 'LP-123','month': '2019-01', 'total': 100, 'cornsilk': 10,'slate_gray': 30, 'navajo_white': 40}) == (
    ('LP-123', '2019-01'),
    (1, 100, 10, 30, 40, 100)
)
	assert candidate(
    {'license_plate': 'A1234','month': 202001, 'total': 100, 'cornsilk': 20,'slate_gray': 30, 'navajo_white': 40}) == (
    ('A1234', 202001),
    (1, 100, 20, 30, 40, 100)
)
	assert candidate(
    {
        'license_plate': '123',
       'month': 1,
        'total': 10,
        'cornsilk': 1,
       'slate_gray': 2,
        'navajo_white': 3
    }
) == (('123', 1), (1, 10, 1, 2, 3, 10))
	assert candidate(
    {'license_plate': 'ABC123','month': '2021-01', 'total': 123.0, 'cornsilk': 100.0,'slate_gray': 50.0, 'navajo_white': 10.0}) == (
    ('ABC123', '2021-01'), (1, 123.0, 100.0, 50.0, 10.0, 123.0))
	assert candidate(
    {'license_plate': 'L0001','month': '2019-01-01', 'total': 100, 'cornsilk': 30,'slate_gray': 10, 'navajo_white': 10}
) == (('L0001', '2019-01-01'), (1, 100, 30, 10, 10, 100))
	assert candidate(
    {'license_plate': '1234','month': '2018-01', 'total': 100, 'cornsilk': 20,'slate_gray': 30, 'navajo_white': 40}
) == (('1234', '2018-01'), (1, 100, 20, 30, 40, 100))
	assert candidate(
    {'license_plate': 'LP-123','month': '2019-01', 'total': 200, 'cornsilk': 20,'slate_gray': 60, 'navajo_white': 80}) == (
    ('LP-123', '2019-01'),
    (1, 200, 20, 60, 80, 200)
)
	assert candidate(
    {
        'license_plate': 'a',
        'total': 1,
        'cornsilk': 2,
       'slate_gray': 3,
        'navajo_white': 4,
       'month': '1'
    }
) == (
    ('a', '1'),
    (1, 1, 2, 3, 4, 1)
)
	assert candidate(
    {
        'license_plate': 'abc123',
       'month': '2019-02',
        'total': 40,
        'cornsilk': 30,
       'slate_gray': 20,
        'navajo_white': 20,
    }) == (
    ('abc123', '2019-02'),
    (1, 40, 30, 20, 20, 40)
)
	assert candidate(
    {'license_plate': 'abc','month': '2021-01', 'total': 1, 'cornsilk': 0,'slate_gray': 0, 'navajo_white': 0}) == \
    (('abc', '2021-01'), (1, 1, 0, 0, 0, 1))
	assert candidate(
    {'license_plate': 'AAA','month': 1, 'total': 200, 'cornsilk': 100,'slate_gray': 10, 'navajo_white': 5}
) == (
    ('AAA', 1),
    (1, 200, 100, 10, 5, 200)
)
	assert candidate(
    {'license_plate': '123','month': '2019-01', 'total': 10, 'cornsilk': 1,'slate_gray': 2, 'navajo_white': 3}) == \
    (('123', '2019-01'), (1, 10, 1, 2, 3, 10))
	assert candidate(
    {'license_plate': '123','month': '2019-02', 'total': 100, 'cornsilk': 10,'slate_gray': 20, 'navajo_white': 30}) == \
    (('123', '2019-02'), (1, 100, 10, 20, 30, 100))
	assert candidate(
    {'license_plate': 'AAA','month': 2, 'total': 150, 'cornsilk': 80,'slate_gray': 5, 'navajo_white': 20}
) == (
    ('AAA', 2),
    (1, 150, 80, 5, 20, 150)
)
	assert candidate(
    {'license_plate': 'plate1','month': '2020-01', 'total': 1, 'cornsilk': 2,'slate_gray': 3, 'navajo_white': 4}
) == (
    ('plate1', '2020-01'),
    (1, 1, 2, 3, 4, 1)
)
	assert candidate(
    {'license_plate': 'abc123','month': '2019-01-01', 'total': 1000, 'cornsilk': 100,'slate_gray': 10, 'navajo_white': 1}) == \
    (("abc123", "2019-01-01"), (1, 1000, 100, 10, 1, 1000))
	assert candidate(
    {'license_plate': 'abc','month': '2021-02', 'total': 2, 'cornsilk': 2,'slate_gray': 0, 'navajo_white': 0}) == \
    (('abc', '2021-02'), (1, 2, 2, 0, 0, 2))
	assert candidate(
    {
        'license_plate': 'abc',
       'month': '2021-12',
        'total': 100,
        'cornsilk': 10,
       'slate_gray': 20,
        'navajo_white': 30
    }
) == (
    ('abc', '2021-12'),
    (1, 100, 10, 20, 30, 100)
)
	assert candidate(
    { 'license_plate': 'ABC123','month': 5, 'total': 18, 'cornsilk': 0,'slate_gray': 0, 'navajo_white': 0 }
) == (('ABC123', 5), (1, 18, 0, 0, 0, 18))
	assert candidate(
    {
        "license_plate": "1234",
        "month": 1,
        "total": 1000,
        "cornsilk": 100,
        "slate_gray": 10,
        "navajo_white": 20,
    }
) == (
    ("1234", 1),
    (1, 1000, 100, 10, 20, 1000)
)
	assert candidate(
    {'license_plate': 'abc123','month': '2019-01-02', 'total': 2000, 'cornsilk': 200,'slate_gray': 20, 'navajo_white': 2}) == \
    (("abc123", "2019-01-02"), (1, 2000, 200, 20, 2, 2000))
	assert candidate(
    {'license_plate': 'AAA123','month': '2016-04', 'total': 10, 'cornsilk': 2,'slate_gray': 3, 'navajo_white': 4}
) == (
    ('AAA123', '2016-04'),
    (1, 10, 2, 3, 4, 10.0)
)
	assert candidate(
    {
        'license_plate': 'xyz',
       'month': '2019-01',
        'total': 100,
        'cornsilk': 30,
       'slate_gray': 20,
        'navajo_white': 25
    }
) == (
    ('xyz', '2019-01'),
    (1, 100, 30, 20, 25, 100)
)
	assert candidate(
    {'license_plate': 'ABC123','month': '2021-02', 'total': 234.0, 'cornsilk': 200.0,'slate_gray': 150.0, 'navajo_white': 20.0}) == (
    ('ABC123', '2021-02'), (1, 234.0, 200.0, 150.0, 20.0, 234.0))
	assert candidate(
    {'license_plate': 'A1234','month': '2021-01-01', 'total': 100, 'cornsilk': 10,'slate_gray': 10, 'navajo_white': 10}
) == (('A1234', '2021-01-01'), (1, 100, 10, 10, 10, 100))
	assert candidate(
    {'license_plate': 'AA-0000','month': 1, 'total': 12345, 'cornsilk': 1234,'slate_gray': 123, 'navajo_white': 12}
) == (('AA-0000', 1), (1, 12345, 1234, 123, 12, 12345))
	assert candidate(
    {
        "license_plate": "1234",
        "month": 2,
        "total": 1000,
        "cornsilk": 100,
        "slate_gray": 10,
        "navajo_white": 20,
    }
) == (
    ("1234", 2),
    (1, 1000, 100, 10, 20, 1000)
)
	assert candidate(
    {'license_plate': 'ABC-123','month': '2020-01', 'total': 10, 'cornsilk': 5,'slate_gray': 3, 'navajo_white': 2}) == \
    (('ABC-123', '2020-01'), (1, 10, 5, 3, 2, 10))
	assert candidate(dict(license_plate='abc123', month=1, total=1, cornsilk=1, slate_gray=1, navajo_white=1)) == (('abc123', 1), (1, 1, 1, 1, 1, 1))
	assert candidate(
    {
        'license_plate': 'A1234',
       'month': 2,
        'total': 40.0,
        'cornsilk': 10.0,
       'slate_gray': 10.0,
        'navajo_white': 10.0
    }
) == (
    ('A1234', 2),
    (1, 40.0, 10.0, 10.0, 10.0, 40.0)
)
def test_check():
	check(key_by_license_plate_month)
