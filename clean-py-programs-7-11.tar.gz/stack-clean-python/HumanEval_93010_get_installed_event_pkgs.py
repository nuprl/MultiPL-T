def get_installed_event_pkgs(event_pkgs, installed_pkgs):
    """
    Get those event's "in" or "out" packages which are already installed.

    Even though we don't want to install the already installed pkgs, to be able to upgrade them to their RHEL 8 version
    we need to know in which repos they are and enable such repos.
    """
    ### Canonical solution below ###
    return {k: v for k, v in event_pkgs.items() if k in installed_pkgs}


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'a': 'pkg1', 'b': 'pkg2'},
    {'a': 'pkg1', 'b': 'pkg2', 'c': 'pkg3'}
) == {'a': 'pkg1', 'b': 'pkg2'}
	assert candidate(event_pkgs={"in": ["a", "b"], "out": ["c"]}, installed_pkgs={"d"}) == {}
	assert candidate(
    {
        "kernel-core": ["kernel-core-4.18.0-193.28.1.el8_2.x86_64"],
        "kernel-modules": ["kernel-modules-4.18.0-193.28.1.el8_2.x86_64"],
        "kernel": ["kernel-4.18.0-193.28.1.el8_2.x86_64"],
    },
    {
        "kernel-core": ["kernel-core-4.18.0-193.28.1.el8_2.x86_64"],
        "kernel-modules": ["kernel-modules-4.18.0-193.28.1.el8_2.x86_64"],
        "kernel": ["kernel-4.18.0-193.28.1.el8_2.x86_64"],
    },
) == {
    "kernel-core": ["kernel-core-4.18.0-193.28.1.el8_2.x86_64"],
    "kernel-modules": ["kernel-modules-4.18.0-193.28.1.el8_2.x86_64"],
    "kernel": ["kernel-4.18.0-193.28.1.el8_2.x86_64"],
}
	assert candidate(event_pkgs={"in": ["pkg1"], "out": ["pkg2"]}, installed_pkgs=["pkg3", "pkg4"]) == {}
	assert candidate(event_pkgs={"in": ["a", "b"], "out": ["c"]}, installed_pkgs={}) == {}
	assert candidate(event_pkgs={"a": "1"}, installed_pkgs={"a": "1", "b": "2"}) == {"a": "1"}
	assert candidate(
    {'x86_64': {'in': ['a', 'b'], 'out': ['c', 'd']}},
    {'x86_64': ['a', 'b', 'c', 'd']},
) == {'x86_64': {'in': ['a', 'b'], 'out': ['c', 'd']}}
	assert candidate(
    {"1": "1", "2": "2"},
    {"1": "1", "2": "2", "3": "3"}
) == {"1": "1", "2": "2"}
	assert candidate(
    {"1": "1", "2": "2"},
    {"1": "1", "3": "3"}
) == {"1": "1"}
	assert candidate(
    {"a": {"in": {"pkgs": ["foo-1.0-1.el7.noarch", "bar-1.1-1.el7.noarch"]}, "out": {"pkgs": ["baz-1.2-1.el7.noarch"]}}},
    ["foo-1.0-1.el7.noarch", "bar-1.1-1.el7.noarch", "baz-1.2-1.el7.noarch"]
) == {}
	assert candidate(
    {'x86_64': {'in': ['a', 'b'], 'out': ['c', 'd']}},
    {'x86_64': ['a', 'b', 'c', 'd', 'e']},
) == {'x86_64': {'in': ['a', 'b'], 'out': ['c', 'd']}}
	assert candidate(
    {"1": "1", "2": "2"},
    {"3": "3"}
) == {}
	assert candidate(event_pkgs={"a": "1", "b": "2"}, installed_pkgs={"a": "1"}) == {"a": "1"}
	assert candidate(event_pkgs={"a": "1", "b": "2"}, installed_pkgs={"c": "3"}) == {}
	assert candidate(event_pkgs={"a": "1", "b": "2"}, installed_pkgs={"a": "1", "b": "2"}) == {"a": "1", "b": "2"}
def test_check():
	check(get_installed_event_pkgs)
