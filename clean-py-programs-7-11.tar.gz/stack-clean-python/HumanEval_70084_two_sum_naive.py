def two_sum_naive(arr, target):
    """ 
     time: O(n^2)
     space: O(1)
     """
	### Canonical solution below ###    
    for i, val1 in enumerate(arr):
        for j, val2 in enumerate(arr):
            if val1 + val2 == target and i != j:
                return i, j
    return None

### Unit tests below ###
def check(candidate):
	assert candidate(arr=[2, 7, 11, 15], target=9) == (0, 1)
	assert candidate(arr=[3, 2, 4], target=6) == (1, 2)
	assert candidate([1, 2, 3, 4], 6) == (1, 3)
	assert candidate(arr=[3, 2, 3], target=6) == (0, 2)
	assert candidate(arr=[0, 0, 0, 0], target=0) == (0, 1)
	assert candidate([2, 7, 11, 15], 9) == (0, 1)
	assert candidate(arr=[3, 3, 3], target=6) == (0, 1)
	assert candidate([1, 2, 3], 4) == (0, 2)
	assert candidate(arr=[-1, 0], target=-1) == (0, 1)
	assert candidate([1,2,3,4], 4) == (0,2)
	assert candidate(arr=[3, 3], target=6) == (0, 1)
	assert candidate([1,2,3,4,5], 12) is None
	assert candidate([1, 2, 3], 10) is None
	assert candidate([1,2,3,4,5], 8) == (2,4)
	assert candidate([1,2,3,4,5], 9) == (3,4)
	assert candidate([1,2,3,4], 5) == (0,3)
	assert candidate([], 10) is None
	assert candidate(arr=[1, 2, 3, 4, 5], target=11) is None
	assert candidate(arr=[1, 3, 5, 7, 9], target=13) is None
	assert candidate(arr=[1, 3, 5, 7, 9], target=10) == (0, 4)
	assert candidate([3, 3], 6) == (0, 1)
	assert candidate([1], 0) is None
	assert candidate([], 0) is None
	assert candidate([3, 2, 4], 6) == (1, 2)
	assert candidate(arr=[0, 4, 3, 0], target=0) == (0, 3)
	assert candidate([1,2,3], 4) == (0,2)
	assert candidate(arr=[1, 3, 5, 7, 9], target=11) is None
def test_check():
	check(two_sum_naive)
