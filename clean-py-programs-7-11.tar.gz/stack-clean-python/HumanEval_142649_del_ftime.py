def del_ftime(file_label):
    """file_label is either a str or a tuple of strings"""
    ### Canonical solution below ###
    if isinstance(file_label, tuple):
        return tuple(del_ftime(s) for s in file_label)
    else:
        file_label_new = file_label.strip()
        if file_label_new != "." and file_label_new != "..":
            file_label_new = file_label_new.split("|")[0].rstrip()
    return (file_label_new)


### Unit tests below ###
def check(candidate):
	assert candidate("..") == ".."
	assert candidate(r"..|\..") == ".."
	assert candidate(r"C:\test\test.txt") == r"C:\test\test.txt"
	assert candidate(r"..") == r".."
	assert candidate(r"C:\test\test.txt|1234567890.987654321|") == r"C:\test\test.txt"
	assert candidate("..|.") == ".."
	assert candidate(r".") == r"."
	assert candidate(r".") == "."
	assert candidate("..|") == ".."
	assert candidate("12345") == ("12345")
	assert candidate("a") == ("a")
	assert candidate("a") == "a"
	assert candidate("") == ""
	assert candidate( "2015-01-01 12:34:56.789012|foo" ) == "2015-01-01 12:34:56.789012"
	assert candidate(".|") == "."
	assert candidate(("a")) == ("a")
	assert candidate(r"C:\test\test.txt|1234567890") == r"C:\test\test.txt"
	assert candidate(".|.") == "."
	assert candidate(r"C:\Users\username\Downloads\test.txt|2019-08-09 16:20:02|") == r"C:\Users\username\Downloads\test.txt"
	assert candidate(r"C:\Users\username\Downloads\test.txt") == r"C:\Users\username\Downloads\test.txt"
	assert candidate( "2015-01-01 12:34:56.789012|foo|bar" ) == "2015-01-01 12:34:56.789012"
	assert candidate("a|..|") == ("a")
	assert candidate(u"filename.txt|2015-01-01 00:00:00") == u"filename.txt"
	assert candidate(r"file.txt") == r"file.txt"
	assert candidate(r"..|\..|") == ".."
	assert candidate( "19991231.120000" ) == "19991231.120000"
	assert candidate(r"file.txt|123") == r"file.txt"
	assert candidate("hello") == "hello"
	assert candidate("..|..|..") == ".."
	assert candidate("12345|") == "12345"
	assert candidate(
    "2018-07-01 12:49:09.904146+00:00|2018-07-01 12:49:09.904146+00:00") == "2018-07-01 12:49:09.904146+00:00"
	assert candidate(r"C:\Users\username\Downloads\test.txt|") == r"C:\Users\username\Downloads\test.txt"
	assert candidate(r"..|\..|\..|") == ".."
	assert candidate( "2015-01-01 12:34:56.789012" ) == "2015-01-01 12:34:56.789012"
	assert candidate("foo|2001-01-01T01:01:01") == "foo"
	assert candidate("file_label|time|") == "file_label"
	assert candidate( "2015-01-01 12:34:56|foo|bar" ) == "2015-01-01 12:34:56"
	assert candidate( "2015-01-01 12:34:56" ) == "2015-01-01 12:34:56"
	assert candidate(u"..") == u".."
	assert candidate("a|..") == ("a")
	assert candidate("..|..|.") == ".."
	assert candidate(" ") == ""
	assert candidate(r"..|\..|\..|\..|\..|\..") == ".."
	assert candidate(r"..|\..|\..|\..|") == ".."
	assert candidate(r"C:\test\test.txt|") == r"C:\test\test.txt"
	assert candidate(r"..|\..|\..|\..|\..") == ".."
	assert candidate(".|.|.") == "."
	assert candidate( "2015-01-01 12:34:56|foo" ) == "2015-01-01 12:34:56"
	assert candidate(r"..|") == ".."
	assert candidate(r"..|\..|\..|\..") == ".."
	assert candidate("") == ("")
	assert candidate("test1.txt") == "test1.txt"
	assert candidate("a|.") == ("a")
	assert candidate("test1.txt|123") == "test1.txt"
	assert candidate(r"C:\test\test.txt|1234567890|") == r"C:\test\test.txt"
	assert candidate("test1.txt|123|456") == "test1.txt"
	assert candidate(".") == "."
	assert candidate(("..")) == ("..")
	assert candidate(r"C:\Users\username\Downloads\test.txt|2019-08-09 16:20:02") == r"C:\Users\username\Downloads\test.txt"
	assert candidate(r"file.txt|123|") == r"file.txt"
	assert candidate("file_label|") == "file_label"
	assert candidate(r"C:\test\test.txt|1234567890.987654321") == r"C:\test\test.txt"
	assert candidate(r"..|\..|\..|\..|\..|") == ".."
	assert candidate(r"..") == ".."
	assert candidate("file_label|time|size") == "file_label"
	assert candidate("file_label|time|size|name") == "file_label"
	assert candidate("..") == ("..")
	assert candidate("foo") == "foo"
	assert candidate((".")) == (".")
	assert candidate("test1.txt|123|456|") == "test1.txt"
	assert candidate(u"filename.txt") == u"filename.txt"
	assert candidate("12345") == "12345"
	assert candidate(r"file.txt|") == r"file.txt"
	assert candidate("test1.txt|123|") == "test1.txt"
	assert candidate("file_label|time|size|name|") == "file_label"
	assert candidate(u".") == u"."
	assert candidate(r"01") == r"01"
	assert candidate("a|.|") == ("a")
	assert candidate("file_label|time|size|") == "file_label"
	assert candidate("hello|") == "hello"
	assert candidate( "19991231.120000|20000101.120000" ) == "19991231.120000"
	assert candidate("12345|") == ("12345")
	assert candidate("None") == "None"
	assert candidate("file_label|time") == "file_label"
	assert candidate(r"..|\..|\..") == ".."
	assert candidate("  ") == ("")
def test_check():
	check(del_ftime)
