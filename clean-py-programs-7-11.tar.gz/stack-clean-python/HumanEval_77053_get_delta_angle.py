def get_delta_angle(a1: float,
                    a2: float,
                    ) -> float:
    """
    Get the difference between two (dihedral or regular) angles.

    Examples::
        3 - 1 = 2
        1 - 3 = 2
        1- 359 = 2

    Args:
        a1 (float): Angle 1 in degrees.
        a2 (float): Angle 2 in degrees.

    Returns: float
        The difference between the angles in degrees.
    """
    ### Canonical solution below ###
    a1 %= 360
    a2 %= 360
    return min(abs(a1 - a2), abs(a1 + 360 - a2), abs(a1 - a2 - 360))


### Unit tests below ###
def check(candidate):
	assert candidate(-1, -359) == 2
	assert candidate(359, 899) == 180
	assert candidate(1, 359) == candidate(359, 1)
	assert candidate(1, 1) == 0
	assert candidate(1, 363) == 2
	assert candidate(1, 181) == 180
	assert candidate(-359, -1) == 2
	assert candidate(0, 359) == 1
	assert candidate(1, -361) == 2
	assert candidate(3, 1) == 2
	assert candidate(3, 1) == candidate(1, 359)
	assert candidate(1, 723) == 2
	assert candidate(1, 359.5) == 1.5
	assert candidate(1, 180.5) == 179.5
	assert candidate(359, 0) == 1
	assert candidate(359, 1) == 2
	assert candidate(3, 1) == candidate(1, 3)
	assert candidate(359, 359) == 0
	assert candidate(361, -1) == 2
	assert candidate(0, 1) == 1
	assert candidate(1, -1) == 2
	assert candidate(0, 0) == 0
	assert candidate(358, 359) == 1
	assert candidate(-1, 1) == 2
	assert candidate(1, 0) == 1
	assert candidate(1, 359) == 2
	assert candidate(899, 359) == 180
	assert candidate(-361, 1) == 2
	assert candidate(181, 1) == 180
	assert candidate(1, 3) == 2
	assert candidate(359, 358) == 1
def test_check():
	check(get_delta_angle)
