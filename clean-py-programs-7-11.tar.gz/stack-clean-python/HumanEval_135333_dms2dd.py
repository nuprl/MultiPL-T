def dms2dd(dms):
    """ 
     DMS to decimal degrees.
     
     Args:
     dms (list). d must be negative for S and W.
     
     Return:
     float.
     """
	### Canonical solution below ###    
    d, m, s = dms
    return d + m/60. + s/3600.

### Unit tests below ###
def check(candidate):
	assert candidate(dms=[-180, 0, 0]) == -180
	assert candidate(dms=[-1, 1, 1]) == -1 + 1/60. + 1/3600.
	assert candidate(dms=[0, 1, 0]) == 1/60.
	assert candidate(dms=[-1, -1, -1]) == -1 - 1/60. - 1/3600.
	assert candidate( [10,0,0] ) == 10
	assert candidate(dms=[0, 0, 0]) == 0
	assert candidate(dms=[0, 30, 0]) == 0.5
	assert candidate(dms=[1, 1, 1]) == 1 + 1/60. + 1/3600.
	assert candidate( [0, 0, 0] ) == 0.
	assert candidate(dms=[1, 1, 0]) == 1.0166666666666666
	assert candidate(dms=[0, 0, 1]) == 1/3600.
	assert candidate(dms=[-1, -1, 1]) == -1 - 1/60. + 1/3600.
	assert candidate(dms=[5, 30, 0]) == 5.5
	assert candidate( [-10,0,0] ) == -10
	assert candidate( [0,0,0] ) == 0
	assert candidate(dms=[1, 0, 0]) == 1
	assert candidate(dms=[1, 1, -1]) == 1 + 1/60. - 1/3600.
	assert candidate( [10, 30, 0] ) == 10.5
	assert candidate(dms=[180, 0, 0]) == 180
def test_check():
	check(dms2dd)
