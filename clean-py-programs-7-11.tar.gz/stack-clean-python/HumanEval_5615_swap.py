def swap(items, a, b):
    """ swap between list/dict items values"""
	### Canonical solution below ###    
    items[a], items[b] = items[b], items[a]
    return items

### Unit tests below ###
def check(candidate):
	assert candidate(list("abc"), 1, 2) == ["a", "c", "b"]
	assert candidate(list('abc'), 1, 0) == list('bac')
	assert candidate(dict(a=1, b=2, c=3), 'b', 'c') == {'a': 1, 'b': 3, 'c': 2}
	assert candidate(dict(a=1, b=2, c=3), 'b', 'a') == dict(a=2, b=1, c=3)
	assert candidate(list(range(5)), 4, 4) == [0, 1, 2, 3, 4]
	assert candidate(dict(a=1, b=2, c=3), 'b', 'c') == dict(a=1, b=3, c=2)
	assert candidate(list(range(5)), 3, 4) == [0, 1, 2, 4, 3]
	assert candidate(dict(enumerate(list(range(5)))), 0, 1) == {0: 1, 1: 0, 2: 2, 3: 3, 4: 4}
	assert candidate(dict(zip(range(10), range(10))), 0, 1) == {0: 1, 1: 0, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate(dict(a=1, b=2, c=3), 'a', 'b') == {'a': 2, 'b': 1, 'c': 3}
	assert candidate(dict(a=1, b=2, c=3), "a", "b") == {"a": 2, "b": 1, "c": 3}
	assert candidate(list(range(10)), 9, 9) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate({0: 'a', 1: 'b', 2: 'c'}, 0, 1) == {0: 'b', 1: 'a', 2: 'c'}
	assert candidate([1, 2, 3], 0, 1) == [2, 1, 3]
	assert candidate(dict(a=1, b=2, c=3), 'a', 'c') == dict(a=3, b=2, c=1)
	assert candidate(dict(a=1, b=2), 'a', 'a') == dict(a=1, b=2)
	assert candidate(dict(a=1, b=2, c=3), 'c', 'a') == dict(a=3, b=2, c=1)
	assert candidate({0: 'a', 1: 'b', 2: 'c'}, 2, 1) == {0: 'a', 1: 'c', 2: 'b'}
	assert candidate(dict(zip(list(range(10)), list(range(10)))), 0, 9) == {0: 9, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 0}
	assert candidate(dict(a=1, b=2, c=3), 'b', 'b') == dict(a=1, b=2, c=3)
	assert candidate({'a': 1, 'b': 2, 'c': 3}, 'a', 'c') == {'a': 3, 'b': 2, 'c': 1}
	assert candidate(dict(a=1, b=2, c=3, d=4), 'a', 'd') == {'a': 4, 'b': 2, 'c': 3, 'd': 1}
	assert candidate(list('abc'), 0, 0) == list('abc')
	assert candidate(list(range(10)), 0, 9) == [9, 1, 2, 3, 4, 5, 6, 7, 8, 0]
	assert candidate(dict(a=1, b=2), 'a', 'b') == {'a': 2, 'b': 1}
	assert candidate(list('abc'), 0, 0) == ['a', 'b', 'c']
	assert candidate({0: 'a', 1: 'b', 2: 'c'}, 2, 0) == {0: 'c', 1: 'b', 2: 'a'}
	assert candidate(dict(a=1, b=2, c=3, d=4), 'a', 'b') == {'a': 2, 'b': 1, 'c': 3, 'd': 4}
	assert candidate(list(range(10)), 0, 1) == [1, 0, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(list('abc'), 2, 1) == ['a', 'c', 'b']
	assert candidate(list(range(3)), 0, 1) == [1, 0, 2]
	assert candidate(list('abc'), 2, 0) == ['c', 'b', 'a']
	assert candidate(list(range(3)), 1, 2) == [0, 2, 1]
	assert candidate(list('abcd'), 2, 1) == ['a', 'c', 'b', 'd']
	assert candidate(list('abcd'), 0, 1) == ['b', 'a', 'c', 'd']
	assert candidate(dict(a=1, b=2, c=3), 'a', 'b') == dict(a=2, b=1, c=3)
	assert candidate({1: 10, 2: 20, 3: 30, 4: 40, 5: 50}, 1, 2) == {1: 20, 2: 10, 3: 30, 4: 40, 5: 50}
	assert candidate(dict(a=1, b=2, c=3), "a", "c") == {"a": 3, "b": 2, "c": 1}
	assert candidate(list(range(5)), 0, 1) == [1, 0, 2, 3, 4]
	assert candidate(list(range(5)), 4, 0) == [4, 1, 2, 3, 0]
	assert candidate(dict(a=1, b=2, c=3, d=4), 'b', 'c') == {'a': 1, 'b': 3, 'c': 2, 'd': 4}
	assert candidate(dict(zip(list(range(10)), list(range(10)))), 1, 2) == {0: 0, 2: 1, 1: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate(list(range(5)), 1, 1) == [0, 1, 2, 3, 4]
	assert candidate(dict(a=1, b=2, c=3), "b", "c") == {"a": 1, "b": 3, "c": 2}
	assert candidate(dict(a=1, b=2), 'a', 'b') == dict(a=2, b=1)
	assert candidate(list(range(5)), 0, 4) == [4, 1, 2, 3, 0]
	assert candidate(list('abc'), 0, 1) == ['b', 'a', 'c']
	assert candidate(list(range(5)), 0, 0) == [0, 1, 2, 3, 4]
	assert candidate({0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four'}, 1, 3) == {0: 'zero', 1: 'three', 2: 'two', 3: 'one', 4: 'four'}
	assert candidate(list(range(5)), 0, 2) == [2, 1, 0, 3, 4]
	assert candidate(list('abc'), 0, 1) == list('bac')
	assert candidate(list(range(5)), 1, 2) == [0, 2, 1, 3, 4]
	assert candidate(dict(a=1, b=2, c=3), 'a', 'c') == {'a': 3, 'b': 2, 'c': 1}
	assert candidate(list('abc'), 1, 0) == ['b', 'a', 'c']
	assert candidate({0: 'a', 1: 'b', 2: 'c'}, 1, 1) == {0: 'a', 1: 'b', 2: 'c'}
	assert candidate(dict(enumerate(range(5))), 0, 4) == {0: 4, 1: 1, 2: 2, 3: 3, 4: 0}
	assert candidate({0: 'a', 1: 'b', 2: 'c'}, 0, 2) == {0: 'c', 1: 'b', 2: 'a'}
	assert candidate(list("abc"), 0, 1) == ["b", "a", "c"]
	assert candidate(dict(enumerate(range(5))), 1, 2) == {0: 0, 2: 1, 1: 2, 3: 3, 4: 4}
	assert candidate(dict(zip(list(range(10)), list(range(10)))), 0, 1) == {0: 1, 1: 0, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate(list(range(10)), 1, 2) == [0, 2, 1, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(list('abc'), 1, 1) == ['a', 'b', 'c']
	assert candidate({0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four'}, 1, 1) == {0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four'}
	assert candidate(dict(enumerate(list(range(10)))), 0, 9) == {0: 9, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 0}
	assert candidate(dict(a=1, b=2, c=3), 'a', 'a') == dict(a=1, b=2, c=3)
def test_check():
	check(swap)
