def binary_search(alist, item):
    """ list -> bool
     binary search using a while loop
     """
	### Canonical solution below ###    

    first = 0 
    last = len(alist) - 1
    found = False

    while first<=last and not found:
        midpoint = (first + last) // 2
        if alist[midpoint] == item:
            found = True 
        else:
            if item < alist[midpoint]:
                last = midpoint-1
            else:
                first = midpoint+1 
    return found

### Unit tests below ###
def check(candidate):
	assert candidate(list(range(10)), 0) == True
	assert candidate(list(range(10)), 0)
	assert not candidate(list(range(10)), 15)
	assert candidate(alist=[1,2,3,4,5,6], item=3) == True
	assert candidate(alist = [1,2,3,4,5,6,7], item = 2) == True
	assert candidate(sorted([1, 3, 5, 7, 9]), 3)
	assert candidate(alist = [1,2,3,4,5,6,7], item = 8) == False
	assert candidate(alist = [1,2,3,4,5,6,7], item = 5) == True
	assert candidate(list(range(10)), 1) == True
	assert candidate(alist = [1,2,3,4,5,6,7], item = 6) == True
	assert candidate(list(range(10)), 10) == False
	assert not candidate(list(range(1, 50)), 100)
	assert candidate(list(range(1, 50)), 1)
	assert candidate(list(range(10)), -1) == False
	assert candidate(list(range(10)), 3) == True
	assert not candidate(sorted([1, 3, 5, 7, 9]), 4)
	assert candidate(list(range(10)), 5) == True
	assert candidate(list(range(10)), 6) == True
	assert candidate(alist=[1,2,3,4,5,6], item=7) == False
	assert candidate(list(range(10)), 1000) == False
	assert candidate(alist = [1,2,3,4,5,6,7], item = 0) == False
	assert candidate(list(range(10)), 5)
	assert candidate(alist = [1,2,3,4,5,6,7], item = 7) == True
	assert candidate(list(range(10)), 2) == True
	assert candidate(list(range(10)), -1000) == False
	assert candidate(list(range(10)), 7) == True
	assert candidate(alist = [1,2,3,4,5,6,7], item = 4) == True
	assert candidate(alist=[1,2,3,4,5,6], item=10) == False
	assert candidate(list(range(10)), 8) == True
	assert candidate(list(range(10)), 11) == False
	assert candidate(list(range(10)), 12) == False
	assert candidate(list(range(10)), 9)
	assert candidate(list(range(10)), 4) == True
	assert candidate(alist = [1,2,3,4,5,6,7], item = 1) == True
	assert candidate(list(range(1, 50)), 3)
	assert candidate(alist = [1,2,3,4,5,6,7], item = 3) == True
	assert candidate(list(range(10)), 9) == True
def test_check():
	check(binary_search)
