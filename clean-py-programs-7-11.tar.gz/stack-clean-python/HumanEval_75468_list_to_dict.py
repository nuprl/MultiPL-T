def list_to_dict(dict_list: list) -> dict:
    """ 
     Return a dictionary from a list `[key, value, key_2, value_2...]`
     
     .. code-block:: python
     
     >>> lst = ["A","T", "R", 3]
     >>> list_to_dict(lst)
     {"A": "T", "R": 3}
     
     Args:
     dict_list (list[str]): Dictionary as a list
     
     Returns:
     dict: Dictionary
     """
	### Canonical solution below ###    
    dictionary = {dict_list[i]: dict_list[i + 1] for i in range(0, len(dict_list), 2)}
    return dictionary

### Unit tests below ###
def check(candidate):
	assert candidate(
    ["A", "T", "R", 3, "G", 8, "C", 2, "N", 0, "Q", 1]) == {'A': 'T', 'R': 3, 'G': 8, 'C': 2, 'N': 0, 'Q': 1}, \
    "candidate failed"
	assert candidate(
    ["A", "T"]) == {"A": "T"}, "candidate function is not correct"
	assert candidate(
    ["A", "T", "R", 3]) == {"A": "T", "R": 3}
	assert candidate(
    ["A", "T", "R", 3, "C", 5]
) == {"A": "T", "R": 3, "C": 5}, "candidate test failed"
	assert candidate(
    ["A", "T", "R", 3]
) == {"A": "T", "R": 3}, "candidate works"
	assert candidate(
    ["A", "T", "R", 3]
) == {"A": "T", "R": 3}, "candidate test 1"
	assert candidate(
    ["A", "T"]
) == {"A": "T"}, "candidate works"
	assert candidate(
    ["A", "T", "R", "3"]) == {"A": "T", "R": "3"}, "candidate function is not correct"
	assert candidate(
    ["A", "T", "R", 3, "C", 5, "G", 9]) == {"A": "T", "R": 3, "C": 5, "G": 9}, "candidate([A,T,R,3,C,5,G,9])"
	assert candidate(list("ABCD"))!= {"A": "B", "C": "D", "A": "E"}
	assert candidate(
    ["A", "T", "R", 3]
) == {"A": "T", "R": 3}, "candidate test failed"
	assert candidate(
    ["A", "T", "R", 3]
) == {"A": "T", "R": 3}
	assert candidate(
    ["A", "T", "R", 3, "A", "T", "R", 3]) == {"A": "T", "R": 3}, "candidate function is not correct"
	assert candidate(["A", "T"]) == {"A": "T"}
	assert candidate(list("ABCD")) == {"A": "B", "C": "D"}
	assert candidate(
    ["A", "T", "R", 3, "G", 5]) == {"A": "T", "R": 3, "G": 5}, "candidate returns wrong result"
	assert candidate(
    ["A", "T", "R", 3]) == {"A": "T", "R": 3}, "candidate function is not correct"
	assert candidate(
    ["A", "T", "R", 3, "C", 1, "G", 2, "N", 4]
) == {"A": "T", "R": 3, "C": 1, "G": 2, "N": 4}
	assert candidate(
    ["A", "T", "R", 3, "G", 5, "C", 7, "T", 11, "G", 13, "A", 17, "T", 19, "C", 23]) == {
        "A": 17,
        "C": 23,
        "G": 13,
        "R": 3,
        "T": 19,
    }
	assert candidate(
    ["A", "T", "R", "R"]) == {"A": "T", "R": "R"}, "candidate function is not correct"
	assert candidate(
    ["A", "T", "R", 3, "G", "C", "N", "N", "N", "N", "N", "N"]
) == {"A": "T", "R": 3, "G": "C", "N": "N"}, "candidate test 5"
	assert candidate(
    ["A", "T", "R", 3, "G", 5, "C", 7, "U", 9, "N", 11]) == {"A": "T", "R": 3, "G": 5, "C": 7, "U": 9, "N": 11}
	assert candidate(
    ["A", "T", "R", 3, "G", 6]) == {"A": "T", "R": 3, "G": 6}
	assert candidate(
    ["A", "T", "R", 3]) == {"A": "T", "R": 3}, "candidate([A,T,R,3])"
	assert candidate(
    ["A", "T", "R", 3, "G", 8, "C", 2, "N", 0, "Q", 1, "A", "T", "R", 3]) == {'A': 'T', 'R': 3, 'G': 8, 'C': 2, 'N': 0, 'Q': 1}, \
    "candidate failed"
	assert candidate(
    ["A", "T", "R", 3, "A", "T", "R", 3, "A", "T", "R", 3]) == {"A": "T", "R": 3}, "candidate function is not correct"
	assert candidate(
    ["A", "T", "R", "3", "A", "T", "R", "3"]) == {"A": "T", "R": "3"}, "candidate does not work properly"
	assert candidate(
    ["A", "T", "R", 3]) == {"A": "T", "R": 3}, "candidate returns wrong result"
	assert candidate(
    ["A", "T", "R", 3, "C", 5]) == {"A": "T", "R": 3, "C": 5}, "candidate([A,T,R,3,C,5])"
	assert candidate(
    ["A", "T", "R", 3, "G", "C"]
) == {"A": "T", "R": 3, "G": "C"}, "candidate test 2"
	assert candidate(list("ABCD"))!= {"A": "B", "C": "D", "E": "F"}
	assert candidate(
    ["A", "T", "R", "3"]) == {"A": "T", "R": "3"}, "candidate does not work properly"
	assert candidate([]) == {}, "candidate function is not correct"
	assert candidate(
    ["A", "T", "R", 3, "C", "G", "N", 5, "X", "Y", "M", 5, "K", "B", "D", 2]) == {"A": "T", "R": 3, "C": "G", "N": 5, "X": "Y", "M": 5, "K": "B", "D": 2}
	assert candidate(
    ["A", "T", "R", 3, "C", 5, "G", 7]
) == {"A": "T", "R": 3, "C": 5, "G": 7}, "candidate test failed"
	assert candidate([]) == {}
	assert candidate(
    ["A", "T", "R", 3, "G", "C", "N", "N", "N", "N"]
) == {"A": "T", "R": 3, "G": "C", "N": "N"}, "candidate test 4"
	assert candidate(
    ["A", "T", "R", 3, "G", "C", "N", "N"]
) == {"A": "T", "R": 3, "G": "C", "N": "N"}, "candidate test 3"
	assert candidate(["A", "T", "R", 3]) == {"A": "T", "R": 3}
	assert candidate(
    ["A", "T", "R", 3]
) == {"A": "T", "R": 3}, "candidate() error"
	assert candidate(
    ["A", "T", "R", 3, "G", 8, "C", 2, "N", 0, "Q", 1, "A", "T"]) == {'A': 'T', 'R': 3, 'G': 8, 'C': 2, 'N': 0, 'Q': 1}, \
    "candidate failed"
	assert candidate(
    ["A", "T", "R", 3]) == {"A": "T", "R": 3}, "candidate does not work properly"
	assert candidate(
    ["A", "T"]) == {"A": "T"}, "candidate returns wrong result"
def test_check():
	check(list_to_dict)
