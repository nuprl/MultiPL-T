def mini2peutetre(x, y):
    """
    Take the max between two numbers

    **Parameters**

    > **x:** `float` -- Description of parameter `x`.

    > **y:** `float` -- Description of parameter `y`.

    **Returns**

    > `float` -- Description of returned object.
    """
    ### Canonical solution below ###
    #return np.min(x, y)
    return y


### Unit tests below ###
def check(candidate):
	assert candidate(3, 3) == 3
	assert candidate(5, 3) == 3
	assert candidate(4, 4) == 4
	assert candidate(1, 0.5) == 0.5
	assert candidate(0, -1) == -1
	assert candidate(0, 1) == 1, "Erreur : candidate(0, 1) doit retourner 1"
	assert candidate(0, 0.1) == 0.1
	assert candidate(0.0, -1.0) == -1.0
	assert candidate(1, 1) == 1
	assert candidate(1, -0.1) == -0.1
	assert candidate(1, 1) == 1, "Erreur : candidate(1, 1) doit retourner 1"
	assert candidate(1.5, 1.0) == 1.0
	assert candidate(3, 5) == 5
	assert candidate(1.0, 0.0) == 0.0
	assert candidate(2, 5) == 5
	assert candidate(5, 6) == 6
	assert candidate(3, 2) == 2
	assert candidate(2, 1) == 1, "Erreur : candidate(2, 1) doit retourner 1"
	assert candidate(-3, -5) == -5
	assert candidate(4, 2) == 2
	assert candidate(0, 1) == 1
	assert candidate(3, -5) == -5
	assert candidate(1, 0) == 0
	assert candidate(0.0, 0.0) == 0.0
	assert candidate(2, 1) == 1
	assert candidate(2, 2) == 2
	assert candidate(1, -1) == -1
	assert candidate(1, 0) == 0, "Erreur : candidate(1, 0) doit retourner 0"
	assert candidate(0, 0) == 0, "Erreur : candidate(0, 0) doit retourner 0"
	assert candidate(0.1, 0.1) == 0.1
	assert candidate(3, 4) == 4
	assert candidate(2, 3) == 3
	assert candidate(5, 10) == 10
	assert candidate(1.2, 1.2) == 1.2
	assert candidate(0.5, 0.1) == 0.1
	assert candidate(6, 5) == 5
	assert candidate(4, 3) == 3
	assert candidate(1.5, 0.5) == 0.5
	assert candidate(0, 0) == 0
	assert candidate(0, -0.1) == -0.1
	assert candidate(0.5, 0.5) == 0.5
	assert candidate(1, 2) == 2
	assert candidate(5, 5) == 5
	assert candidate(1.2, 3.4) == 3.4
	assert candidate(3.4, 1.2) == 1.2
def test_check():
	check(mini2peutetre)
