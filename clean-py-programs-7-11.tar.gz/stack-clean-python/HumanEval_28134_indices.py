def indices(lst, element):
    """ 
     Pulled from http://stackoverflow.com/questions/6294179/how-to-find-all-occurrences-of-an-element-in-a-list
     Scans an entire array and returns all the locations a value appears in it
     """
	### Canonical solution below ###    
    result = []
    offset = -1
    while True:
        try:
            offset = lst.index(element, offset+1)
        except ValueError:
            return result
        result.append(offset)

### Unit tests below ###
def check(candidate):
	assert candidate([1, 2, 2, 2, 3], 4) == []
	assert candidate(list(range(10)), -1) == []
	assert candidate([1,2,3,4,5,2], 4) == [3]
	assert candidate( [1, 2, 3, 1, 2, 3], 4 ) == []
	assert candidate(list(range(10)), 5) == [5]
	assert candidate(list(range(10)), 3) == [3]
	assert candidate(list(range(10)), 100) == []
	assert candidate( [1, 2, 3, 1, 2, 3], 1 ) == [0, 3]
	assert candidate(list(range(5)), 2) == [2]
	assert candidate([], 10) == []
	assert candidate(list(range(10)), -2) == []
	assert candidate(list(range(10)), -10) == []
	assert candidate( [1,1,1,1,1,1,1,1,1,1], 1 ) == [0,1,2,3,4,5,6,7,8,9]
	assert candidate([1,1,1,1,1,1,1,1,1,1], 1) == [0,1,2,3,4,5,6,7,8,9]
	assert candidate( [1, 2, 3, 1, 2, 3], 0 ) == []
	assert candidate([1, 2, 2, 3, 2, 2, 1], 2) == [1, 2, 4, 5]
	assert candidate([], 0) == []
	assert candidate( [1, 2, 3, 1, 2, 3], 3 ) == [2, 5]
	assert candidate([0, 0, 0, 1, 2, 2, 3], 0) == [0, 1, 2]
	assert candidate(list(range(10)), 2) == [2]
	assert candidate(list(range(5)), 1) == [1]
	assert candidate([0, 0, 0, 1, 2, 2, 3], 1) == [3]
	assert candidate(list(range(5)), 4) == [4]
	assert candidate([0, 0, 0, 1, 2, 2, 3], 4) == []
	assert candidate([0, 2, 2, 3, 0], 2) == [1, 2]
	assert candidate( [1,1,1,1,1,1,1,1,1,1], 2 ) == []
	assert candidate([1,2,3,4,5,2], 5) == [4]
	assert candidate([1, 2, 3, 2, 1, 1, 3, 4, 1], 5) == []
	assert candidate([0, 0, 0, 1, 2, 2, 3], 5) == []
	assert candidate(list(range(10)), 8) == [8]
	assert candidate([1,2,3,4,5,2], 2) == [1,5]
	assert candidate(list(range(10)), 1) == [1]
	assert candidate([1, 2, 3], 4) == []
	assert candidate(list(range(10)), 10) == []
	assert candidate(list(range(5)), 5) == []
	assert candidate(list(range(5)), 0) == [0]
	assert candidate([1,2,3,4,5,2], 6) == []
	assert candidate(list(range(10)), 6) == [6]
	assert candidate([1,2,3,4,5,2], 3) == [2]
	assert candidate([1, 2, 3, 2, 1, 1, 3, 4, 1], 4) == [7]
	assert candidate([0, 0, 0, 1, 2, 2, 3], 6) == []
	assert candidate(list(range(10)), 0) == [0]
	assert candidate(list(range(5)), 3) == [3]
	assert candidate([1, 2, 2, 2, 3], 2) == [1, 2, 3]
	assert candidate(list(range(10)), 7) == [7]
	assert candidate(list(range(10)), 4) == [4]
	assert candidate(list(range(10)), 9) == [9]
	assert candidate(list(range(10)), 11) == []
	assert candidate([1,2,3,4,5,2], 1) == [0]
	assert candidate( [1, 2, 3, 1, 2, 3], 2 ) == [1, 4]
def test_check():
	check(indices)
