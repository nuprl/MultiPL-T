def to_int(value, keep_null=False, raise_exception=False):
    """ 
     convert value to int where possible
     NOTE: pass keep_null=True to return None values
     NOTE: pass raise_exception to raise exceptions or it will just convert to 0 by default
     NOTE: python uses int for both ints and longs
     """
	### Canonical solution below ###    
    if value is None and keep_null:
        return value
    if raise_exception:
        return int(value)
    try:
        return int(value)
    except:
        return 0

### Unit tests below ###
def check(candidate):
	assert candidate(1, keep_null=True) == 1
	assert candidate(None, True) is None
	assert candidate(1.9, raise_exception=True) == 1
	assert candidate(None) == 0
	assert candidate(1.23) == 1
	assert candidate(123.0) == 123
	assert candidate(1.99999999) == 1
	assert candidate('a') == 0
	assert candidate(1.999999) == 1
	assert candidate(10, raise_exception=True) == 10
	assert candidate(1.9999999) == 1
	assert candidate('abc') == 0
	assert candidate(1, raise_exception=True) == 1
	assert candidate(1.5, raise_exception=True) == 1
	assert candidate(1.9999999999) == 1
	assert candidate(1.0, raise_exception=True) == 1
	assert candidate("foo") == 0
	assert candidate('0.9', True) == 0
	assert candidate(1.999999999999) == 1
	assert candidate(0) == 0
	assert candidate(1.000001) == 1
	assert candidate(None, keep_null=True) is None
	assert candidate(123.456) == 123
	assert candidate(1.5) == 1
	assert candidate(1.1) == 1
	assert candidate(None, keep_null=True, raise_exception=True) is None
	assert candidate('0', True) == 0
	assert candidate(0.0) == 0
	assert candidate(1.99999999999999) == 1
	assert candidate(10, keep_null=True, raise_exception=True) == 10
	assert candidate(1.1, raise_exception=True) == 1
	assert candidate(1.999999999999999) == 1
	assert candidate("0") == 0
	assert candidate('1', raise_exception=True) == 1
	assert candidate("a") == 0
	assert candidate('0.9') == 0
	assert candidate(None, keep_null=True) == None
	assert candidate(1.0) == 1
	assert candidate(1.9) == 1
	assert candidate('0.1', True) == 0
	assert candidate(1.9999) == 1
	assert candidate(None, True) == None
	assert candidate('0.1') == 0
	assert candidate("1") == 1
	assert candidate(123) == 123
	assert candidate('123') == 123
	assert candidate(10.1) == 10
	assert candidate(10, keep_null=True) == 10
	assert candidate('0') == 0
	assert candidate(None, keep_null=False) == 0
	assert candidate('10') == 10
	assert candidate('10', raise_exception=True) == 10
	assert candidate('1', True) == 1
	assert candidate(1.9999999999999) == 1
	assert candidate(1.99999) == 1
	assert candidate(10.1, raise_exception=True) == 10
	assert candidate(1.99999999999) == 1
	assert candidate('1') == 1
	assert candidate(1.999999999) == 1
	assert candidate(1) == 1
def test_check():
	check(to_int)
