def eeff(e_1, nu_1, e_2, nu_2):
    """ 
     
     Calculate the effective (Young's) modulus of two contact bodies according
     to Hertzian contact theory.
     
     Parameters
     ----------
     e_1: ndarray, scalar
     The Young's modulus of contact body 1.
     nu_1: ndarray, scalar
     The Poisson ratio of contact body 1.
     e_2: ndarray, scalar
     The Young's modulus of contact body 2.
     nu_2: ndarray, scalar
     The Poisson ratio of contact body 1.
     
     Returns
     -------
     e_eff: scalar
     The effective modulus.
     
     """
	### Canonical solution below ###    
    e_eff = 1 / ((1 - nu_1 ** 2) / (2 * e_1) + (1 - nu_2 ** 2) / (2 * e_2))
    return e_eff

### Unit tests below ###
def check(candidate):
	assert candidate(10, 0.3, 10, 0.3) == candidate(10, 0.3, 10, 0.3)
	assert candidate(1, 0.3, 1, 0.3)!= candidate(1, 0.3, 1, 0.1)
	assert candidate(1, 0, 1, 0) == 1.0
	assert candidate(1, 0, 1, -1) == 2
	assert candidate(1, 0, 1, 1) == 2
	assert candidate(100, 0.3, 100, 0.3) == candidate(100, 0.3, 100, 0.3)
	assert candidate(1, 0, 1, 0) == 1
	assert candidate(1, 0.3, 1, 0.3) == candidate(1, 0.3, 1, 0.3)
	assert candidate(2, 0.3, 2, 0.3) == candidate(2, 0.3, 2, 0.3)
def test_check():
	check(eeff)
