def lowerall(sentence: str):
    """to lower case"""
    ### Canonical solution below ###
    sentence = sentence.lower()
    return sentence


### Unit tests below ###
def check(candidate):
	assert candidate(
    'Have a great day!') == 'have a great day!'
	assert candidate(
    "HeLLo WoRLD") == "hello world", "String should be lower case"
	assert candidate("HELLO") == "hello", "Lower case failed"
	assert candidate(u"Hello World!") == u"hello world!"
	assert candidate("!@#$%^&*()") == "!@#$%^&*()", "Lower case failed"
	assert candidate(sentence='Hello World!') == 'hello world!'
	assert candidate(
    "Hello World") == "hello world", "String should be lower case"
	assert candidate(sentence="Hello World") == "hello world"
	assert candidate(
    "i Want to fly to SFO") == "i want to fly to sfo"
	assert candidate("Hello World! Hello World!") == "hello world! hello world!", "Lower case failed"
	assert candidate("1234567890") == "1234567890", "Lower case failed"
	assert candidate("I LOVE you") == "i love you"
	assert candidate(sentence="This is a sentence") == "this is a sentence"
	assert candidate(
    "This is an example of lowering text.") == "this is an example of lowering text."
	assert candidate("THIS IS AN EXAMPLE OF LOWERING TEXT.") == "this is an example of lowering text."
	assert candidate("HELLO WORLD") == "hello world", "Lower case failed"
	assert candidate(
    "I AM a string") == "i am a string"
	assert candidate(
    "12345") == "12345", "String should be unchanged"
	assert candidate(
    "Hello World!"
) == "hello world!"
	assert candidate(
    "ANOTHER one.") == "another one."
	assert candidate(sentence="This is a test") == "this is a test"
	assert candidate(
    "This is a test sentence.") == "this is a test sentence."
	assert candidate(
    "I want to fly to SFO. I want to fly to SFO.") == "i want to fly to sfo. i want to fly to sfo."
	assert candidate(sentence="The Quick Brown Fox Jumps Over The Lazy Dog.") == "the quick brown fox jumps over the lazy dog."
	assert candidate(
    "This is a sentence."
) == "this is a sentence."
	assert candidate(
    "The quick brown fox jumps over the lazy dog."
) == "the quick brown fox jumps over the lazy dog."
	assert candidate(
    "Hello, how are you today?") == "hello, how are you today?"
	assert candidate(sentence="The quick brown fox jumps over the lazy dog.") == "the quick brown fox jumps over the lazy dog."
	assert candidate(
    "THIS IS ALL LOWERCASE") == "this is all lowercase"
	assert candidate(
    "I'll be home by 9") == "i'll be home by 9", "Second"
	assert candidate(
    "The quick brown fox jumps over the lazy dog.") == "the quick brown fox jumps over the lazy dog."
	assert candidate(
    "hello WORLD") == "hello world", "String should be lower case"
	assert candidate(
    "This is a sentence.") == "this is a sentence."
	assert candidate(
    "I want to fly to SFO") == "i want to fly to sfo"
	assert candidate(
    "I want to fly to SFO? ") == "i want to fly to sfo? "
	assert candidate(
    "I want to fly to SFO. I want to fly to SFO. I want to fly to SFO.") == "i want to fly to sfo. i want to fly to sfo. i want to fly to sfo."
	assert candidate(
    "I want to fly to SFO. ") == "i want to fly to sfo. "
	assert candidate(
    "i'LL be home by 9") == "i'll be home by 9", "Fourth"
	assert candidate(sentence="The 123 Quick Brown Fox Jumps Over The 789 Lazy Dog.") == "the 123 quick brown fox jumps over the 789 lazy dog."
	assert candidate(
    "This is a string with some UPPER CASE letters") == "this is a string with some upper case letters"
	assert candidate( "This is a sentence.") == "this is a sentence."
	assert candidate(
    "Hello World!") == "hello world!", "Lower case failed"
	assert candidate(
    "I want to fly to SFO, ") == "i want to fly to sfo, "
	assert candidate(
    "It's the end of the world, I want to know why") == "it's the end of the world, i want to know why"
	assert candidate(
    "HELLO WORLD") == "hello world", "String should be lower case"
	assert candidate(
    "I want to fly to SFO! ") == "i want to fly to sfo! "
	assert candidate(sentence="This IS a sentence") == "this is a sentence"
	assert candidate(
    "He was late to work") == "he was late to work", "First"
	assert candidate(
    "The Quick Brown Fox Jumps Over The Lazy Dog") == "the quick brown fox jumps over the lazy dog"
	assert candidate(
    "This is a string") == "this is a string"
	assert candidate(
    "I'M HOME") == "i'm home", "Third"
	assert candidate(
    "I want to fly to SFO... ") == "i want to fly to sfo... "
	assert candidate("hello world") == "hello world", "Lower case failed"
	assert candidate(sentence="The Quick Brown Fox Jumps Over The Lazy Dog. The Quick Brown Fox Jumps Over The Lazy Dog.") == "the quick brown fox jumps over the lazy dog. the quick brown fox jumps over the lazy dog."
	assert candidate("hello") == "hello", "Lower case failed"
	assert candidate(
    "The quick brown fox jumps over the lazy dog") == "the quick brown fox jumps over the lazy dog"
	assert candidate(
    "I am a string") == "i am a string"
	assert candidate(
    'Hello, how are you doing today?') == 'hello, how are you doing today?'
	assert candidate(sentence="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG.") == "the quick brown fox jumps over the lazy dog."
	assert candidate("12345") == "12345", "Lower case failed"
	assert candidate(
    'How have you been?') == 'how have you been?'
	assert candidate(
    "I want to fly to SFO,") == "i want to fly to sfo,"
	assert candidate(
    "The last one.") == "the last one."
	assert candidate(
    "I want to fly to SFO.") == "i want to fly to sfo."
def test_check():
	check(lowerall)
