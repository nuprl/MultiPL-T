def pop_n(seq, n):
    """
    Pops first n elements from a mutable bytearray
    :param seq: Input bytearray
    :param n: The number of elements to pop
    :return: First n elements of the input bytearray
    """
    ### Canonical solution below ###
    tmp = seq[:n]
    del seq[:n]
    return bytes(tmp)


### Unit tests below ###
def check(candidate):
	assert candidate(bytearray(b"1234567890"), 3) == b"123"
	assert candidate(bytearray(b"abc"), 1) == b"a"
	assert candidate(bytearray(b'hello'), 3) == b'hel'
	assert candidate(bytearray(b'\x01\x02\x03\x04\x05\x06\x07\x08'), 4) == b'\x01\x02\x03\x04'
	assert candidate(bytearray(b'hello'), 5) == b'hello'
	assert candidate(bytearray(b'abcdefg'), 3) == b'abc'
	assert candidate(bytearray(b"test"), 1) == b't'
	assert candidate(bytearray(b'abcde'), 3) == b'abc'
	assert candidate(bytearray(b"1234567890"), 5) == b"12345"
	assert candidate(bytearray(b'ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 2) == b'AB'
	assert candidate(bytearray([1,2,3,4]), 2) == bytearray([1,2])
	assert candidate(bytearray(b'\x01\x02\x03\x04\x05\x06\x07\x08'), 0) == b''
	assert candidate(bytearray(b'abcdefg'), 10) == b'abcdefg'
	assert candidate(bytearray(b"abcdefgh"), 0) == b""
	assert candidate(bytearray([1, 2, 3, 4, 5]), 3) == bytearray([1, 2, 3])
	assert candidate(bytearray(b'\x01\x02\x03\x04'), 2) == b'\x01\x02'
	assert candidate(bytearray(b"abcdef"), 7) == b"abcdef"
	assert candidate(bytearray([1, 2, 3, 4]), 3) == bytearray([1, 2, 3])
	assert candidate(bytearray(b"abcdefgh"), 8) == b"abcdefgh"
	assert candidate(bytearray(b"abcdef"), 2) == b"ab"
	assert candidate(bytearray([1, 2, 3, 4, 5]), 5) == bytearray([1, 2, 3, 4, 5])
	assert candidate(bytearray(b'0123456789'), 5) == b'01234'
	assert candidate(bytearray([1, 2, 3, 4, 5]), 0) == bytearray()
	assert candidate(bytearray(b"abcdef"), 1) == b"a"
	assert candidate(bytearray(b'abc'), 2) == b'ab'
	assert candidate(bytearray(b"abc"), 3) == b"abc"
	assert candidate(bytearray(b'hello'), 6) == b'hello'
	assert candidate(bytearray(b'abc'), 0) == b''
	assert candidate(bytearray([1, 2, 3, 4, 5]), 6) == bytearray([1, 2, 3, 4, 5])
	assert candidate(bytearray(b"ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 5) == b"ABCDE"
	assert candidate(bytearray(b"test"), 0) == b''
	assert candidate(bytearray(b'abc'), 3) == b'abc'
	assert candidate(bytearray(b"abcdef"), 4) == b"abcd"
	assert candidate(bytearray(b'12345'), 2) == bytearray(b'12')
	assert candidate(bytearray(b"abcdef"), 6) == b"abcdef"
	assert candidate(bytearray([1, 2, 3, 4]), 4) == bytearray([1, 2, 3, 4])
	assert candidate(bytearray(), 0) == b""
	assert candidate(bytearray([1, 2, 3, 4]), 0) == bytearray([])
	assert candidate(bytearray([1, 2, 3, 4, 5]), 0) == bytearray([])
	assert candidate(bytearray(b"ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 26) == b"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	assert candidate(bytearray(b"abc"), 2) == b"ab"
	assert candidate(bytearray(b"abcdef"), 3) == b"abc"
	assert candidate(bytearray(b'abcde'), 0) == b''
	assert candidate(bytearray(b'hello'), 2) == b'he'
	assert candidate(bytearray(b"abcdef"), 5) == b"abcde"
	assert candidate(bytearray([1,2,3,4]), 1) == bytearray([1])
	assert candidate(bytearray([1, 2, 3, 4, 5]), 1) == bytearray([1])
	assert candidate(bytearray([1, 2, 3, 4]), 0) == bytearray()
	assert candidate(bytearray(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09'), 3) == b'\x00\x01\x02'
	assert candidate(bytearray(b"abcdefgh"), 3) == b"abc"
	assert candidate(bytearray(b'hello'), 4) == b'hell'
	assert candidate(bytearray([1, 2, 3, 4]), 2) == bytearray([1, 2])
	assert candidate(bytearray(b"abcdef"), 0) == b""
	assert candidate(bytearray(b'ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 26) == b'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	assert candidate(bytearray(b'0123456789'), 0) == b''
	assert candidate(bytearray([1, 2, 3, 4, 5]), 10) == bytearray([1, 2, 3, 4, 5])
	assert candidate(bytearray(b"abcdefgh"), 9) == b"abcdefgh"
	assert candidate(bytearray([1, 2, 3, 4]), 10) == bytearray([1, 2, 3, 4])
	assert candidate(bytearray(b"abc"), 4) == b"abc"
	assert candidate(bytearray(b'hello'), 0) == b''
def test_check():
	check(pop_n)
