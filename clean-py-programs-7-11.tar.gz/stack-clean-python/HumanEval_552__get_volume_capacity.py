def _get_volume_capacity(val):
    """
    Return the capacith with unit 'M'
    """
    ### Canonical solution below ###
    if val.lower().endswith("gi"):
        return int(val[:-2]) * 1024
    elif val.lower().endswith("mi"):
        return int(val[:-2]) * 1024
    else:
        raise Exception("Parse storage capacity({}) failed".format(val))


### Unit tests below ###
def check(candidate):
	assert candidate("1024Mi")!= 1024 * 1024 * 1024
	assert candidate("12Gi") == 12 * 1024
	assert candidate("1024gi") == 1024 * 1024
	assert candidate("1000Gi") == 1024000
	assert candidate("100Mi") == 100 * 1024
	assert candidate("1000Gi") == 1000 * 1024
	assert candidate("1000Mi") == 1000 * 1024
	assert candidate("20Gi") == 20 * 1024
	assert candidate("1234567890Gi") == 1234567890 * 1024
	assert candidate("1Gi") == 1024
	assert candidate("1234Mi") == 1234 * 1024
	assert candidate("1024Mi") == 1024 * 1024
	assert candidate("12345Mi") == 12345 * 1024
	assert candidate("10Gi") == 10240
	assert candidate("12345Gi") == 12345 * 1024
	assert candidate("1Mi") == 1024
	assert candidate("20Mi") == 20 * 1024
	assert candidate("100Mi") == 102400
	assert candidate("100Gi") == 102400
	assert candidate("10Mi") == 10240
	assert candidate("10Gi") == 10 * 1024
def test_check():
	check(_get_volume_capacity)
