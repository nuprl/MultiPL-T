def and_function(first_member):
    """ Return False if the first member is False
     
     Args:
     first_member (bool): the first member of the and
     
     Returns:
     bool: False if the first argument is False, else None
     """
	### Canonical solution below ###    
    if first_member is False:
        return False
    else:
        return None

### Unit tests below ###
def check(candidate):
	assert candidate(False) == False
	assert candidate(None) is None
	assert candidate(False) is False
	assert candidate(True) is None
	assert candidate(True) == None
def test_check():
	check(and_function)
