def ValueErrorOnFalse(ok, *args):
  """Returns None / arg / (args,...) if ok."""
    ### Canonical solution below ###
  if not isinstance(ok, bool):
    raise TypeError('Use ValueErrorOnFalse only on bool return value')
  if not ok:
    raise ValueError('CLIF wrapped call returned False')
  # Plain return args will turn 1 into (1,)  and None into () which is unwanted.
  if args:
    return args if len(args) > 1 else args[0]
  return None


### Unit tests below ###
def check(candidate):
	assert candidate(True, 1, 2) == (1, 2)
	assert candidate(True, 'hello') == 'hello'
	assert candidate(True, None) == None
	assert candidate(True, 'a') == 'a'
	assert candidate(True, 1) == 1
	assert candidate(True) is None
	assert candidate(True, 'hello', 'world') == ('hello', 'world')
	assert candidate(True, 'a', 'b') == ('a', 'b')
	assert candidate(True, 1, 2, 3) == (1, 2, 3)
def test_check():
	check(ValueErrorOnFalse)
