def camelize(snake_case: str) -> str:
    """ this_case_word -> ThisCaseWord"""
	### Canonical solution below ###    
    parts = snake_case.split("_")
    if not parts:
        return snake_case
    if any(x == "" for x in parts):
        raise ValueError(
            f"Can't camelize {snake_case}."
            " It probably contains several consecutive underscores."
        )
    return "".join(x.capitalize() for x in parts)

### Unit tests below ###
def check(candidate):
	assert candidate(
    "already_candidated"
) == "AlreadyCamelized"
	assert candidate(
    "this_is_a_test"
) == "ThisIsATest"
	assert candidate(
    "this_is_a_test_case"
) == "ThisIsATestCase"
	assert candidate(
    "The_Stealth_Warrior"
) == "TheStealthWarrior"
	assert candidate(
    "This_Is_A_Snake_Case_String"
) == "ThisIsASnakeCaseString", "Camelize snake case string"
	assert candidate(
    "http_response_code"
) == "HttpResponseCode", candidate("http_response_code")
	assert candidate(
    "this_is_my_snake_case"
) == "ThisIsMySnakeCase"
	assert candidate(
    "this is a test"
) == "This is a test"
	assert candidate(
    "this_case_word"
) == "ThisCaseWord", "Camelize snake case string"
	assert candidate(
    "this_is_a_long_word"
) == "ThisIsALongWord"
	assert candidate(
    "this_is_a_test_of_the_candidate_function"
) == "ThisIsATestOfTheCamelizeFunction"
	assert candidate(
    "the_stealth_warrior"
) == "TheStealthWarrior"
	assert candidate(
    "This_is_my_snake_case"
) == "ThisIsMySnakeCase"
	assert candidate(
    "This is a test"
) == "This is a test"
	assert candidate(
    "A_B"
) == "AB"
	assert candidate(
    "this_case_word"
) == "ThisCaseWord"
	assert candidate(
    "http_response_code_header_body"
) == "HttpResponseCodeHeaderBody", candidate("http_response_code_header_body")
	assert candidate(
    "this_case_has_underscores"
) == "ThisCaseHasUnderscores"
	assert candidate(
    "this_01_is_a_test_case"
) == "This01IsATestCase"
	assert candidate(
    "http_response_header"
) == "HttpResponseHeader", candidate("http_response_header")
	assert candidate(
    "http_response_code_header"
) == "HttpResponseCodeHeader", candidate("http_response_code_header")
def test_check():
	check(camelize)
