def reverse( sequence ):
    """ Return the reverse of any sequence
     """
	### Canonical solution below ###    
    return sequence[::-1]

### Unit tests below ###
def check(candidate):
	assert candidate( [1, 2, 3, [4, 5]] ) == [[4, 5], 3, 2, 1]
	assert candidate( [1, 2, 3] ) == [3, 2, 1]
	assert candidate( (1,2,3) ) == (3,2,1)
	assert candidate( [ 1, 2, 3, 4, 5 ] ) == [ 5, 4, 3, 2, 1 ]
	assert candidate( (1,2,3,4,5,6,7,8,9,10) ) == (10,9,8,7,6,5,4,3,2,1)
	assert candidate( (1,2,3,4,5) ) == (5,4,3,2,1)
	assert candidate( range(5) ) == range(4, -1, -1)
	assert candidate( [ 1, 2, 3, 4 ] ) == [ 4, 3, 2, 1 ]
	assert candidate( [1,2,3,4,5,6] ) == [6,5,4,3,2,1]
	assert candidate( "Hello!" ) == "!olleH"
	assert candidate( (1, 2, 3) ) == (3, 2, 1)
	assert candidate( "a" ) == "a"
	assert candidate( range(10) ) == range(9, -1, -1)
	assert candidate( "abc" ) == "cba"
	assert candidate( "abcde" ) == "edcba"
	assert candidate( ( 1, 2, 3 ) ) == ( 3, 2, 1 )
	assert candidate( (1,2,3,4,5,6) ) == (6,5,4,3,2,1)
	assert candidate( ( 1, 2 ) ) == ( 2, 1 )
	assert candidate( [1,2,3,4] ) == [4,3,2,1]
	assert candidate( [ 1 ] ) == [ 1 ]
	assert candidate( (4, 5, 6) ) == (6, 5, 4)
	assert candidate( [ 1, 2, 3 ] ) == [ 3, 2, 1 ]
	assert candidate( () ) == ()
	assert candidate( 'hello' ) == 'olleh'
	assert candidate( [1, 2, 3, 4] ) == [4, 3, 2, 1]
	assert candidate( (1,) ) == (1,)
	assert candidate( "hello" ) == "olleh"
	assert candidate( [1] ) == [1]
	assert candidate( (1,2,3,4) ) == (4,3,2,1)
	assert candidate( (1, 2) ) == (2, 1)
	assert candidate( [1, 2, 3, 4, 5] ) == [5, 4, 3, 2, 1]
	assert candidate( 'abc' ) == 'cba'
	assert candidate( 'abracadabra' ) == 'arbadacarba'
	assert candidate( [ 1, 2 ] ) == [ 2, 1 ]
	assert candidate( (1,2,3,4,) ) == (4,3,2,1)
	assert candidate( [1,2,3,4,5] ) == [5,4,3,2,1]
	assert candidate( [] ) == []
	assert candidate( 'abcde' ) == 'edcba'
	assert candidate( (1, 2, 3, 4, 5) ) == (5, 4, 3, 2, 1)
	assert candidate( [4, 5, 6] ) == [6, 5, 4]
	assert candidate( (1, 2, 3, 4, 5, 6) ) == (6, 5, 4, 3, 2, 1)
	assert candidate( "Hello" ) == "olleH"
	assert candidate( (1, 2, 3, 4) ) == (4, 3, 2, 1)
	assert candidate( [1,2,3] ) == [3,2,1]
def test_check():
	check(reverse)
