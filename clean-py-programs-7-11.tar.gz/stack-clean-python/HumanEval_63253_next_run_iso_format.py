def next_run_iso_format(next_run):
    """ 
     Convert next run timestamp object to the ISO format
     """
	### Canonical solution below ###    
    if isinstance(next_run, bool):
        next_run = None
    else:
        next_run = next_run.isoformat()

    return next_run

### Unit tests below ###
def check(candidate):
	assert candidate(True) is None
	assert candidate(True) == None
	assert candidate(False) == None
	assert candidate(False) is None
def test_check():
	check(next_run_iso_format)
