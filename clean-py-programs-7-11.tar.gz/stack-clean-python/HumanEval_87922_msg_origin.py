def msg_origin(msg):
    """ Mensagem privada ou mensagem de grupo"""
	### Canonical solution below ###    
    return msg["chat"]["type"]

### Unit tests below ###
def check(candidate):
	assert candidate(
    {"chat": {"type": "group", "id": 123456789, "title": "Test"}}) == "group"
	assert candidate(
    {"chat": {"type": "private", "id": 123456789}}
) == "private"
	assert candidate(
    {"chat": {"type": "group"}}) == "group"
	assert candidate(
    {"chat": {"type": "private", "id": 123456789, "first_name": "Test"}}) == "private"
	assert candidate(
    {"chat": {"type": "group", "id": 123456789}}
) == "group"
	assert candidate(
    {"chat": {"type": "private"}}) == "private"
def test_check():
	check(msg_origin)
