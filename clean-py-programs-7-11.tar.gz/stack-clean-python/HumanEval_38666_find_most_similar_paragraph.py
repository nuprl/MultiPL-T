def find_most_similar_paragraph(similar_paragraphs):
    """ Some paragraphs in the C++ started are worded very similarly.
    Sometimes, multiple paragraphs may be marked as similar. This function
    picks the paragraph with the highest similarity ratio.
    """
    ### Canonical solution below ###
    max_i = 0
    max_ratio = 0
    for i in range(len(similar_paragraphs)):
        if similar_paragraphs[i][2] > max_ratio:
            max_i = i
            max_ratio = similar_paragraphs[i][2]

    return similar_paragraphs[max_i]


### Unit tests below ###
def check(candidate):
	assert candidate(
    [("text", "text", 0.2), ("text", "text", 0.2), ("text", "text", 0.2)]
) == ("text", "text", 0.2)
	assert candidate(
    [[0, 1, 0.5], [1, 2, 0.6], [2, 3, 0.7], [0, 2, 0.8], [1, 3, 0.9]]) == [1, 3, 0.9]
	assert candidate(
    [[0, 1, 0.5], [0, 2, 0.5], [0, 3, 0.5], [1, 2, 0.5], [1, 3, 0.5], [2, 3, 0.5], [3, 4, 0.5]]) == [0, 1, 0.5]
	assert candidate(
    [[1, 2, 0.5], [2, 4, 0.3], [3, 5, 0.2]]) == [1, 2, 0.5]
	assert candidate(
    [("text", "text", 0.2), ("text", "text", 0.3), ("text", "text", 0.4), ("text", "text", 0.5), ("text", "text", 0.6)]
) == ("text", "text", 0.6)
	assert candidate(
    [(0, 1, 0.1), (1, 2, 0.2), (2, 3, 0.3), (0, 3, 0.4)]
) == (0, 3, 0.4)
	assert candidate(
    [(0, 1, 0.1), (1, 2, 0.2), (2, 3, 0.3), (0, 3, 0.4), (1, 3, 0.5)]
) == (1, 3, 0.5)
	assert candidate(
    [(0, 1, 0.7), (0, 2, 0.7), (0, 3, 0.6), (0, 4, 0.8), (0, 5, 0.7)]
) == (0, 4, 0.8)
	assert candidate(
    [(0, 1, 0.7), (0, 2, 0.7), (0, 3, 0.6), (0, 4, 0.8)]
) == (0, 4, 0.8)
	assert candidate(similar_paragraphs=[(1, 2, 1), (3, 4, 1), (5, 6, 2)]) == (5, 6, 2)
	assert candidate(
    [(0, 0, 99), (0, 0, 99.9), (0, 0, 99.8), (0, 0, 99.7), (0, 0, 99.6)]
) == (0, 0, 99.9)
	assert candidate(
    [("text", "text", 0.2), ("text", "text", 0.3), ("text", "text", 0.4)]
) == ("text", "text", 0.4)
	assert candidate(
    [("This is a test", "This is a test", 1.0),
     ("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 0.8)]) == \
    ("This is a test", "This is a test", 1.0)
	assert candidate(
    [[1, 2, 0.9], [3, 4, 0.75], [5, 6, 0.5]]) == [1, 2, 0.9]
	assert candidate(
    [[0, 0, 0.8], [1, 0, 0.9], [2, 0, 0.7]]) == [1, 0, 0.9]
	assert candidate([[1, 2, 0.8]]) == [1, 2, 0.8]
	assert candidate(
    [["<NAME> is a nice person. He likes to swim. He is a swimmer.",
      "<NAME> is a nice person. He likes to swim. He is a swimmer.",
      1.0],
     ["<NAME> is a nice person. He likes to swim. He is a swimmer.",
      "<NAME> is a nice person. He likes to swim. He is a swimmer.",
      1.0],
     ["<NAME> is a nice person. He likes to swim. He is a swimmer.",
      "<NAME> is a nice person. He likes to swim. He is a swimmer.",
      1.0],
     ["<NAME> is a nice person. He likes to swim. He is a swimmer.",
      "<NAME> is a nice person. He likes to swim. He is a swimmer.",
      1.0]]) == ["<NAME> is a nice person. He likes to swim. He is a swimmer.",
               "<NAME> is a nice person. He likes to swim. He is a swimmer.",
               1.0]
	assert candidate(
    [("text", "text", 0.1), ("text", "text", 0.2), ("text", "text", 0.3)]
) == ("text", "text", 0.3)
	assert candidate(
    [("a", "b", 0.5), ("a", "c", 0.5), ("a", "b", 0.5)]) == ("a", "b", 0.5)
	assert candidate(
    [(0, 0, 100), (0, 0, 99), (0, 0, 99.9), (0, 0, 99.8)]
) == (0, 0, 100)
	assert candidate(similar_paragraphs=[(0, 1, 0.7), (1, 2, 0.8)]) == (1, 2, 0.8)
	assert candidate(
    [(0, 1, 0.9), (1, 2, 0.8), (2, 3, 0.7), (3, 4, 0.6)]
) == (0, 1, 0.9)
	assert candidate(
    [(0, 1, 0.9), (1, 2, 0.8), (2, 3, 0.7), (3, 4, 0.6), (4, 5, 0.5)]
) == (0, 1, 0.9)
	assert candidate(
    [[0, 1, 0.5], [0, 2, 0.4], [0, 3, 0.7], [1, 2, 0.3]]) == [0, 3, 0.7]
	assert candidate(
    [[0, 1, 0.5], [1, 2, 0.6], [2, 3, 0.7], [0, 2, 0.8]]) == [0, 2, 0.8]
	assert candidate(
    [[1, 2, 0.8], [3, 4, 0.7], [5, 6, 0.6], [7, 8, 0.5]]) == [1, 2, 0.8]
	assert candidate(
    [(0, 1, 0.8), (1, 2, 0.8), (2, 3, 0.7), (3, 4, 0.6), (4, 5, 0.6)]
) == (0, 1, 0.8)
	assert candidate(
    [[1, 2, 0.5], [3, 4, 0.75], [5, 6, 0.75], [7, 8, 0.75], [9, 10, 0.75]]) == [3, 4, 0.75]
	assert candidate(
    [("a", "b", 0.5), ("a", "c", 0.5), ("a", "d", 0.5)]) == ("a", "b", 0.5)
	assert candidate(
    [[0, 1, 0.9], [1, 2, 0.8], [2, 3, 0.7]]) == [0, 1, 0.9]
	assert candidate(
    [[0, 1, 0.95], [1, 2, 0.90], [2, 3, 0.85], [0, 3, 0.99]]
) == [0, 3, 0.99]
	assert candidate(
    [[1, 2, 0.9], [3, 4, 0.9], [5, 6, 0.9]]) == [1, 2, 0.9]
	assert candidate(
    [("text", "text", 0.1), ("text", "text", 0.2), ("text", "text", 0.3), ("text", "text", 0.4), ("text", "text", 0.5)]
) == ("text", "text", 0.5)
	assert candidate(
    [("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 0.7)]) == \
    ("This is a test", "This is a test", 0.8)
	assert candidate(
    [[0, 0, 0.8], [1, 0, 0.9], [2, 0, 0.7], [3, 0, 0.6], [4, 0, 0.5]]) == [1, 0, 0.9]
	assert candidate(
    [[1, 2, 0.8], [3, 4, 0.9], [5, 6, 0.8]]
) == [3, 4, 0.9]
	assert candidate(
    [(1, 2, 0.5), (2, 3, 0.7), (3, 4, 0.9), (5, 6, 0.1)]
) == (3, 4, 0.9)
	assert candidate(similar_paragraphs=[(0, 1, 0.7)]) == (0, 1, 0.7)
	assert candidate(
    [(0, 0, 99), (0, 0, 99.9), (0, 0, 99.8), (0, 0, 99.7)]
) == (0, 0, 99.9)
	assert candidate(
    [
        (0, 1, 0.2),
        (0, 2, 0.3),
        (0, 3, 0.1),
        (1, 2, 0.5),
        (1, 3, 0.1),
        (2, 3, 0.5),
        (0, 4, 0.7),
        (0, 5, 0.1),
        (4, 5, 0.1),
    ]
) == (0, 4, 0.7)
	assert candidate(
    [[0, 1, 0.5], [0, 2, 0.4], [0, 3, 0.7], [1, 2, 0.3], [1, 3, 0.6]]) == [0, 3, 0.7]
	assert candidate(
    [[0, 0, 0.8], [1, 0, 0.9], [2, 0, 0.7], [3, 0, 0.6]]) == [1, 0, 0.9]
	assert candidate(
    [("text", "text", 0.2), ("text", "text", 0.3), ("text", "text", 0.4), ("text", "text", 0.5)]
) == ("text", "text", 0.5)
	assert candidate(
    [("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 0.8),
     ("This is a test", "This is a test", 1.0)]) == \
    ("This is a test", "This is a test", 1.0)
def test_check():
	check(find_most_similar_paragraph)
