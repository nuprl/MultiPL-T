def lower_dict_keys(origin_dict):
    """ convert keys in dict to lower case
     e.g.
     Name => name, Request => request
     URL => url, METHOD => method, Headers => headers, Data => data
     """
	### Canonical solution below ###    
    if not origin_dict or not isinstance(origin_dict, dict):
        return origin_dict

    return {
        key.lower(): value
        for key, value in origin_dict.items()
    }

### Unit tests below ###
def check(candidate):
	assert candidate({"Request": "GET"}) == {"request": "GET"}
	assert candidate({'Name': 'Tom'}) == {'name': 'Tom'}
	assert candidate(None) is None
	assert candidate({"url": "URL"}) == {"url": "URL"}
	assert candidate({"headers": "Headers"}) == {"headers": "Headers"}
	assert candidate({"Name": "name", "Request": "request"}) == {
    "name": "name", "request": "request"
}
	assert candidate({"URL": "value", "Request": "value"}) == {"url": "value", "request": "value"}
	assert candidate({'URL': 'http://example.com'}) == {'url': 'http://example.com'}
	assert candidate({'Name': 'Bob'}) == {'name': 'Bob'}
	assert candidate({"Name": "Test"}) == {"name": "Test"}
	assert candidate({"Headers": "value"}) == {"headers": "value"}
	assert candidate({'URL': 'abc'}) == {'url': 'abc'}
	assert candidate({'Name': 'bob'}) == {'name': 'bob'}
	assert candidate({'Name': 'abc', 'Request': 123}) == {'name': 'abc','request': 123}
	assert candidate({"Data": "data"}) == {"data": "data"}
	assert candidate({"Name": "Alice"}) == {"name": "Alice"}
	assert candidate({"Request": "value"}) == {"request": "value"}
	assert candidate({"Name": "name"}) == {"name": "name"}
	assert candidate({"Headers": "test", "Data": "test"}) == {"headers": "test", "data": "test"}
	assert candidate({'METHOD': 'abc'}) == {'method': 'abc'}
	assert candidate({"Name": "test"}) == {"name": "test"}
	assert candidate({'Request': 'GET'}) == {'request': 'GET'}
	assert candidate({"method": "value"}) == {"method": "value"}
	assert candidate({
    "Name": "request1",
    "URL": "http://127.0.0.1:5000/api/v1/hello",
    "METHOD": "GET",
    "Headers": {},
    "Data": {},
}) == {
    "name": "request1",
    "url": "http://127.0.0.1:5000/api/v1/hello",
    "method": "GET",
    "headers": {},
    "data": {},
}
	assert candidate({'Name': 'name', 'Request':'request'}) == {
    'name': 'name','request':'request'
}
	assert candidate({"method": "METHOD"}) == {"method": "METHOD"}
	assert candidate(123) == 123
	assert candidate({"data": "Data"}) == {"data": "Data"}
	assert candidate({'URL': 'https://www.example.com'}) == {'url': 'https://www.example.com'}
	assert candidate({'Name':'request'}) == {'name':'request'}
	assert candidate({"Data": "value"}) == {"data": "value"}
	assert candidate({'Request': 'abc'}) == {'request': 'abc'}
	assert candidate({'Name': 'bob', 'URL': 'http://example.com'}) == {
    'name': 'bob',
    'url': 'http://example.com'
}
	assert candidate({"METHOD": "POST"}) == {"method": "POST"}
	assert candidate({'Name': 'name', 'Request':'request', 'URL': 'url', 'METHOD':'method', 'Headers': 'headers', 'Data': 'data'}) == {
    'name': 'name',
   'request':'request',
    'url': 'url',
   'method':'method',
    'headers': 'headers',
    'data': 'data'
}
	assert candidate({'Headers': {'name': 'Alice'}}) == {'headers': {'name': 'Alice'}}
	assert candidate({"Name": "name", "Request": "request", "URL": "url", "METHOD": "method"}) == {"name": "name", "request": "request", "url": "url", "method": "method"}
	assert candidate({"headers": "value"}) == {"headers": "value"}
	assert candidate({'Headers': 'abc'}) == {'headers': 'abc'}
	assert candidate({"name": "Name"}) == {"name": "Name"}
	assert candidate({'Name':'request', 'URL': 'url', 'METHOD':'method', 'Headers': 'headers', 'Data': 'data'}) == {
    'name':'request', 'url': 'url','method':'method', 'headers': 'headers', 'data': 'data'}
	assert candidate({"Headers": "headers"}) == {"headers": "headers"}
	assert candidate({"Name": "python", "Request": "http"}) == {
    "name": "python", "request": "http"
}
	assert candidate({"Headers": "test"}) == {"headers": "test"}
	assert candidate({"Name": "test", "Request": "test"}) == {"name": "test", "request": "test"}
	assert candidate(None) == None
	assert candidate({}) == {}
	assert candidate({"URL": "test"}) == {"url": "test"}
	assert candidate({"URL": "url"}) == {"url": "url"}
	assert candidate({"Name": "Mike", "Request": "POST", "URL": "http://www.baidu.com"}) == {"name": "Mike", "request": "POST", "url": "http://www.baidu.com"}
	assert candidate('abc') == 'abc'
	assert candidate({"Name": "name", "Request": "request"}) == {"name": "name", "request": "request"}
	assert candidate({"Name": "value"}) == {"name": "value"}
	assert candidate("string") == "string"
	assert candidate({"METHOD": "value"}) == {"method": "value"}
	assert candidate({"URL": "value"}) == {"url": "value"}
	assert candidate({"url": "value"}) == {"url": "value"}
	assert candidate({'URL': 'abc', 'METHOD': 'def', 'Headers': 'ghi', 'Data': 'jkl'}) == {
    'url': 'abc','method': 'def', 'headers': 'ghi', 'data': 'jkl'}
	assert candidate({"URL": "https://www.google.com"}) == {"url": "https://www.google.com"}
	assert candidate({"data": "value"}) == {"data": "value"}
	assert candidate({'Name': 'Alice'}) == {'name': 'Alice'}
	assert candidate({"METHOD": "method"}) == {"method": "method"}
	assert candidate({"Request": "request"}) == {"request": "request"}
	assert candidate({"request": "Request"}) == {"request": "Request"}
	assert candidate({'Data': 'abc'}) == {'data': 'abc'}
	assert candidate({
    'Name': 'test',
    'Request': 'test',
    'URL': 'test',
    'METHOD': 'test',
    'Headers': 'test',
    'Data': 'test',
}) == {
    'name': 'test',
   'request': 'test',
    'url': 'test',
   'method': 'test',
    'headers': 'test',
    'data': 'test',
}
	assert candidate({
    'Name': 'foo',
    'Request': 'bar',
    'URL': 'http://www.baidu.com',
    'METHOD': 'GET',
    'Headers': {'key1': 'value1'},
    'Data': 'hello world',
}) == {
    'name': 'foo',
   'request': 'bar',
    'url': 'http://www.baidu.com',
   'method': 'GET',
    'headers': {'key1': 'value1'},
    'data': 'hello world',
}
	assert candidate({"Name": "name", "Request": "request", "URL": "url"}) == {"name": "name", "request": "request", "url": "url"}
	assert candidate({"Name": "Mike"}) == {"name": "Mike"}
	assert candidate({"Data": "Mike"}) == {"data": "Mike"}
	assert candidate({'URL': 'url', 'METHOD':'method', 'Headers': 'headers', 'Data': 'data'}) == {
    'url': 'url','method':'method', 'headers': 'headers', 'data': 'data'
}
	assert candidate({"Name": "name", "Request": "request"}) == {
    "name": "name", "request": "request"}
	assert candidate({"Name": "name", "Request": "request", "URL": "url", "METHOD": "method", "Headers": "headers"}) == {"name": "name", "request": "request", "url": "url", "method": "method", "headers": "headers"}
	assert candidate({'name': 'bob'}) == {'name': 'bob'}
	assert candidate({"Name": "Name", "Request": "Request"}) == {"name": "Name", "request": "Request"}
	assert candidate({"URL": "http://test.com"}) == {"url": "http://test.com"}
	assert candidate({"URL": "test", "METHOD": "test"}) == {"url": "test", "method": "test"}
	assert candidate({'METHOD': 'POST'}) == {'method': 'POST'}
	assert candidate({"Name": "Tom", "Age": 18}) == {"name": "Tom", "age": 18}
	assert candidate({'Data': {'name': 'Alice'}}) == {'data': {'name': 'Alice'}}
	assert candidate({'Name': 'abc'}) == {'name': 'abc'}
	assert candidate({'Name': 'abc', 'Request': 'def'}) == {'name': 'abc','request': 'def'}
def test_check():
	check(lower_dict_keys)
