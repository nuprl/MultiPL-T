def indentation(line):
  """Returns the number of leading whitespace characters."""
    ### Canonical solution below ###
  return len(line) - len(line.lstrip())


### Unit tests below ###
def check(candidate):
	assert candidate(
  "def foo(self):") == 0
	assert candidate('   a ') == 3
	assert candidate(r"a \t \t ") == 0
	assert candidate(r'    # foo') == 4
	assert candidate(r" a\n ") == 1
	assert candidate('  a') == 2
	assert candidate(r'  foo\t') == 2
	assert candidate('  a ') == 2
	assert candidate('foo') == 0
	assert candidate(
  "  if (a == b):") == 2
	assert candidate('a') == 0
	assert candidate(r'foo\t') == 0
	assert candidate(u'hello') == 0
	assert candidate(u'  a') == 2
	assert candidate(' ') == 1
	assert candidate(u'  foo  ') == 2
	assert candidate(r'foo') == 0
	assert candidate(u'foo') == 0
	assert candidate(r"  hello\n  world") == 2
	assert candidate(r'  foo bar baz    ') == 2
	assert candidate(r'  ') == 2
	assert candidate(
"   a") == 3
	assert candidate( '\t\t' ) == 2
	assert candidate(r"a \t \t") == 0
	assert candidate(u'  ') == 2
	assert candidate(r"a") == 0
	assert candidate(r"a\n") == 0
	assert candidate(u'a') == 0
	assert candidate(r'foo bar baz\t') == 0
	assert candidate(r'  foo bar') == 2
	assert candidate(u'  a\nb') == 2
	assert candidate(r"a \t") == 0
	assert candidate(r"  hello\n  ") == 2
	assert candidate(u'hello\tworld') == 0
	assert candidate(r'  foo bar baz  \t') == 2
	assert candidate(u'  foo') == 2
	assert candidate('  a   b') == 2
	assert candidate(r'    foo') == 4
	assert candidate(r'\tx') == 0
	assert candidate(u'    a\n') == 4
	assert candidate(u'foo  ') == 0
	assert candidate(
"") == 0
	assert candidate(r'    foo  ') == 4
	assert candidate(u'  a\nb\n') == 2
	assert candidate(
" a") == 1
	assert candidate(r"        \t") == 8
	assert candidate(u' ') == 1
	assert candidate(r'    def f():') == 4
	assert candidate(' a ') == 1
	assert candidate(
  "  def foo(self):") == 2
	assert candidate(r'  def f():') == 2
	assert candidate(r'foo    ') == 0
	assert candidate('   a') == 3
	assert candidate('   foo' ) == 3
	assert candidate(r"\t") == 0
	assert candidate(u'  hello world') == 2
	assert candidate(u'    ') == 4
	assert candidate(r'foo bar baz  \t') == 0
	assert candidate(r" a\n \t") == 1
	assert candidate(r"a ") == 0
	assert candidate(r'  # foo  ') == 2
	assert candidate(r'  foo bar baz  ') == 2
	assert candidate( 'a' ) == 0
	assert candidate(u'hello world') == 0
	assert candidate(
"  a") == 2
	assert candidate(r'\t') == 0
	assert candidate('    a ') == 4
	assert candidate(u'   foo') == 3
	assert candidate('foo' ) == 0
	assert candidate( '' ) == 0
	assert candidate(r'  foo bar baz    \t') == 2
	assert candidate(r"  hello") == 2
	assert candidate(r'  foo bar baz') == 2
	assert candidate('a   b') == 0
	assert candidate(r'    ') == 4
	assert candidate(r'  # foo') == 2
	assert candidate(u'    a') == 4
	assert candidate(r'  foo bar baz\t') == 2
	assert candidate(u'a\nb\n') == 0
	assert candidate(u'    a\nb\n') == 4
	assert candidate(r"    ") == 4
	assert candidate('') == 0
	assert candidate('  ') == 2
	assert candidate('a   ') == 0
	assert candidate(r"  ") == 2
	assert candidate(u'a\n') == 0
	assert candidate(r'foo ') == 0
	assert candidate(r'foo bar') == 0
	assert candidate(r'    x') == 4
	assert candidate(r'    # foo  ') == 4
	assert candidate(u'  a\n') == 2
	assert candidate('   a \t\t ') == 3
	assert candidate(r"   ") == 3
	assert candidate(r'  foo') == 2
	assert candidate(r"a \t ") == 0
	assert candidate(r" ") == 1
	assert candidate('    def foo():\n'
                 '     pass\n'
                 '   pass\n') == 4
	assert candidate(r'  foo bar  ') == 2
	assert candidate(r"  hello  ") == 2
	assert candidate(r'  \t  ') == 2
	assert candidate(u'    a\nb') == 4
	assert candidate(r' foo') == 1
	assert candidate(r'foo  \t') == 0
	assert candidate(r'foo bar baz') == 0
	assert candidate(r"  hello\n  world  ") == 2
	assert candidate(r'  foo  ') == 2
	assert candidate(r"  hello\n") == 2
	assert candidate(r"        ") == 8
	assert candidate( '\t' ) == 1
	assert candidate('  a \t ') == 2
	assert candidate(r'  x') == 2
	assert candidate(r'foo bar  ') == 0
	assert candidate(u'a\nb') == 0
	assert candidate(' foo' ) == 1
	assert candidate(r'\t  ') == 0
	assert candidate(r'') == 0
	assert candidate(r"") == 0
	assert candidate(u'') == 0
	assert candidate(r'foo  ') == 0
	assert candidate(r'foo bar baz  ') == 0
	assert candidate(r'x') == 0
	assert candidate(' foo') == 1
	assert candidate(u'  hello') == 2
	assert candidate('  foo' ) == 2
	assert candidate(r'  \t') == 2
def test_check():
	check(indentation)
