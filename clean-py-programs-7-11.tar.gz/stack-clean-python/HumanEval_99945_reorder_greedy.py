def reorder_greedy(gs, index=0):
    """ 
     Greedy sorting: pick a starting glyph, then find the glyph which starts
     nearest to the previous ending point.
     
     This is O(n^2). Pretty sure it can't be optimized into a sort.
     """
	### Canonical solution below ###    
    from operator import itemgetter
    gs = list(gs)
    ordered = [gs.pop(index)]
    prev = ordered[0]

    def dist_reverse_iterator(gs):
        for g in gs:
            yield (prev.distance_to(g), False, g)
            yield (prev.distance_to_if_other_reversed(g), True, g)

    while len(gs) > 0:
        (dist, reverse, nearest) = min(dist_reverse_iterator(gs),
                                       key=itemgetter(0, 1))
        gs.remove(nearest)

        if reverse:
            prev = nearest.reversed_copy()
        else:
            prev = nearest

        ordered.append(prev)

    return ordered

### Unit tests below ###
def check(candidate):
	assert candidate(list(u"a"), index=0) == list(u"a")
	assert candidate(list(u"a")) == list(u"a")
	assert candidate(list("a")) == list("a")
def test_check():
	check(reorder_greedy)
