def mapif(predicate, function, list):
    """ 
     
     """
	### Canonical solution below ###    
    result = list.copy()

    for i, x in enumerate(list):

        if predicate(x):
            result[i] = function(x)

    return result

### Unit tests below ###
def check(candidate):
	assert candidate(lambda x: x == 1, lambda x: x ** 2, [2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6]
	assert candidate(lambda x: x > 0, lambda x: x * 2, [1, -1, 2])!= [2, -2, 4]
	assert candidate(lambda x: x > 0, lambda x: x ** 2, [1, 2, -3, 4]) == [1, 4, -3, 16]
	assert candidate(lambda x: x > 0, lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
	assert candidate(lambda x: x > 0, lambda x: x * x, [1, 2, 3]) == [1, 4, 9]
	assert candidate(lambda x: x > 5, lambda x: x + 2, []) == []
	assert candidate(lambda x: x % 2 == 0, lambda x: x + 1, []) == []
	assert candidate(lambda x: x % 2 == 0, lambda x: x + 1, [2, 4]) == [3, 5]
	assert candidate(lambda x: x > 5, lambda x: x + 2, [1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate(lambda x: x > 0, lambda x: x + 1, []) == []
	assert candidate(lambda x: x > 0, lambda x: x * 2, [1, -1, 2])!= [4, -2, 4]
	assert candidate(lambda x: x % 2 == 0, lambda x: x * 2, [1, 3, 5, 7]) == [1, 3, 5, 7]
	assert candidate(lambda x: x > 0, lambda x: x**2, [1, 2, 3]) == [1, 4, 9]
	assert candidate(lambda x: x % 2 == 0, lambda x: x * x, [1, 2, 3]) == [1, 4, 3]
	assert candidate(lambda x: x == 0, lambda x: x + 1, [0, 0, 0, 0]) == [1, 1, 1, 1]
	assert candidate(lambda x: x == 0, lambda x: x + 1, []) == []
	assert candidate(lambda x: x == 0, lambda x: x + 1, [1, 2, 3, -4]) == [1, 2, 3, -4]
def test_check():
	check(mapif)
