def str_replace(string, value, new_value, occurences = -1):
    """
    Replaces the value of `value` to `new_value` in `string`. 
    If occurences is defined, will only replace the first n occurences. A negative value replaces all values. 
    """
    ### Canonical solution below ###

    return string.replace(value, new_value, occurences)


### Unit tests below ###
def check(candidate):
	assert candidate(
    "I like apples", 
    "apples", 
    "bananas", 
    2) == "I like bananas"
	assert candidate(string = "this is a string", value = "is", new_value = "was", occurences = 0) == "this is a string"
	assert candidate(
    "this is a test string",
    "is",
    "was"
) == "thwas was a test string"
	assert candidate(
    "I like bananas", "apples", "bananas") == "I like bananas"
	assert candidate(string = "this is a string", value = "is", new_value = "was", occurences = 4) == "thwas was a string"
	assert candidate(
    "I like bananas", "bananas", "apples") == "I like apples"
	assert candidate(
    'To be, or not to be, that is the question.',
    'not to be',
    'to be'
) == 'To be, or to be, that is the question.'
	assert candidate(
    "This, is a test", "test", "example", -1
) == "This, is a example"
	assert candidate(
    "I love apples, apple are my favorite fruit", "apple", "banana", 0) == "I love apples, apple are my favorite fruit"
	assert candidate("Hello world!", "world", "worlds", 1000) == "Hello worlds!"
	assert candidate(
    "This, is a test", "test", "example", 0
) == "This, is a test"
	assert candidate("I like bananas", "bananas", "apples", -1) == "I like apples"
	assert candidate(
    "I like bananas", "bananas", "apples", 0) == "I like bananas"
	assert candidate(
    "hello", "l", "r", 0
) == "hello", "Occurences: Doesn't replace if occurences is 0"
	assert candidate(
    "I like apples", "apple", "banana") == "I like bananas"
	assert candidate(
    "I like cheese", 
    "cheese", 
    "butter"
) == "I like butter"
	assert candidate(
    "", 
    "apples", 
    "bananas", 
    1) == ""
	assert candidate(
    "I like apples", 
    "apple", 
    "banana", 
    -1) == "I like bananas"
	assert candidate(
    'The quick brown fox jumps over the lazy dog',
    'fox',
    'cat'
) == 'The quick brown cat jumps over the lazy dog'
	assert candidate("Hello world!", "world", "worlds") == "Hello worlds!"
	assert candidate(
    'The quick brown fox jumps over the lazy dog',
    'fox',
    'cat',
    0
) == 'The quick brown fox jumps over the lazy dog'
	assert candidate(
    "The sky is blue", "blue", "red", 0) == "The sky is blue"
	assert candidate( "apples, pears # and bananas", "#", "oranges" ) == "apples, pears oranges and bananas", "candidate #1"
	assert candidate( "apples, pears # and bananas", "#", "oranges", 2 ) == "apples, pears oranges and bananas", "candidate #4"
	assert candidate(
    "I like to eat cereal", "cereal", "candy", 100
) == "I like to eat candy"
	assert candidate(
    "I like apples", "apple", "banana", 0) == "I like apples"
	assert candidate(
    "The sky is blue", "blue", "red") == "The sky is red"
	assert candidate('abcabc', 'a', 'z', -3) == 'zbczbc'
	assert candidate(
    "I love apples, apple are my favorite fruit", "apple", "pineapple"
) == "I love pineapples, pineapple are my favorite fruit"
	assert candidate(
    'This is a string with a value to replace', 'value', 'new_value', 0
) == 'This is a string with a value to replace'
	assert candidate(
    'This is a string with a value to replace', 'value', 'new_value', 1
) == 'This is a string with a new_value to replace'
	assert candidate(
    "", 
    "apples", 
    "bananas", 
    0) == ""
	assert candidate("hello", "l", "a", 2) == "heaao"
	assert candidate( "apples, pears # and bananas", "#", "oranges", -1 ) == "apples, pears oranges and bananas", "candidate #6"
	assert candidate(
    "I like apples", 
    "apple", 
    "banana") == "I like bananas"
	assert candidate(string="I am a string", value="am", new_value="was", occurences=3) == "I was a string"
	assert candidate(string="I am a string", value="am", new_value="was", occurences=6) == "I was a string"
	assert candidate(
    "", 
    "apples", 
    "bananas", 
    -1) == ""
	assert candidate(string="I am a string", value="am", new_value="was", occurences=4) == "I was a string"
	assert candidate(
    "I like apples", "apples", "bananas") == "I like bananas"
	assert candidate("hello", "l", "a", 3) == "heaao"
	assert candidate(
    "The sky is blue", "blue", "red", -1) == "The sky is red"
	assert candidate(
    'This is a string with a value to replace', 'value', 'new_value', 10
) == 'This is a string with a new_value to replace'
	assert candidate("This, is a test", "test", "example") == "This, is a example"
	assert candidate('abcdef', 'abc', 'def', 0) == 'abcdef'
	assert candidate(string="I am a string", value="am", new_value="was", occurences=2) == "I was a string"
	assert candidate("Take my protein pills and put my helmet on", "my", "your", 1) == "Take your protein pills and put my helmet on"
	assert candidate(string = "this is a string", value = "is", new_value = "was", occurences = 6) == "thwas was a string"
	assert candidate("Take my protein pills and put my helmet on", "my", "your", 0) == "Take my protein pills and put my helmet on"
	assert candidate(string = "hello world hello", value = "hello", new_value = "hola", occurences = -2) == "hola world hola"
	assert candidate(
    'The quick brown fox jumps over the lazy dog',
    'fox',
    'cat',
    2
) == 'The quick brown cat jumps over the lazy dog'
	assert candidate(
    "Take my protein pills and put my helmet on", "my", "your"
) == "Take your protein pills and put your helmet on"
	assert candidate(
    "I like apples", "apple", "banana", -1) == "I like bananas"
	assert candidate(
    "I love apples, apple are my favorite fruit", "apple", "pineapple", 1
) == "I love pineapples, apple are my favorite fruit"
	assert candidate(
    'This is a string with a value to replace', 'value', 'new_value'
) == 'This is a string with a new_value to replace'
	assert candidate(string = "this is a string", value = "is", new_value = "was", occurences = 5) == "thwas was a string"
	assert candidate(string = "hello world hello", value = "hello", new_value = "hola", occurences = 2) == "hola world hola"
	assert candidate(
    "I like cheese", 
    "cheese", 
    "butter", 
    0
) == "I like cheese"
	assert candidate("Take my protein pills and put my helmet on", "my", "your", -1) == "Take your protein pills and put your helmet on"
	assert candidate(
    'The quick brown fox jumps over the lazy dog',
    'fox',
    'cat',
    1
) == 'The quick brown cat jumps over the lazy dog'
	assert candidate(string="I am a string", value="am", new_value="was", occurences=0) == "I am a string"
	assert candidate(string = "this is a string", value = "is", new_value = "was", occurences = 3) == "thwas was a string"
	assert candidate(
    "I like bananas", "bananas", "apples", -1) == "I like apples"
	assert candidate(string="I am a string", value="am", new_value="was", occurences=5) == "I was a string"
	assert candidate(string = "Hello, World!", value = "Hello", new_value = "Goodbye", occurences = 0) == "Hello, World!"
	assert candidate(string = "this is a string", value = "is", new_value = "was", occurences = 1) == "thwas is a string"
	assert candidate(string="I am a string", value="am", new_value="was", occurences=-2) == "I was a string"
	assert candidate(string = "hello world hello", value = "hello", new_value = "hola", occurences = -1) == "hola world hola"
	assert candidate("Hello world!", "world", "worlds", -1) == "Hello worlds!"
	assert candidate(
    "I like apples", 
    "apples", 
    "bananas", 
    0) == "I like apples"
	assert candidate(
    "This, is a test", "test", "example", 1
) == "This, is a example"
	assert candidate(
    "this is a test string",
    "is",
    "was",
    1
) == "thwas is a test string"
	assert candidate(string = "this is a string", value = "is", new_value = "was") == "thwas was a string"
	assert candidate(
    "I like to eat cereal", "cereal", "candy"
) == "I like to eat candy"
	assert candidate('', '', '') == ''
	assert candidate('abc', 'a', 'z', -1) == 'zbc'
	assert candidate('abcdef', 'abc', 'def') == 'defdef'
	assert candidate(string="I am a string", value="am", new_value="was", occurences=1) == "I was a string"
	assert candidate(
    "The sky is blue", "blue", "red", 2) == "The sky is red"
	assert candidate(
    "I like cheese", 
    "cheese", 
    "butter", 
    -1
) == "I like butter"
	assert candidate(
    "The sky is blue", "blue", "red", 1) == "The sky is red"
	assert candidate(string = "I like apples, apple are my favorite fruit", value = "apple", new_value = "banana", occurences = 0) == "I like apples, apple are my favorite fruit"
	assert candidate('abcabc', 'a', 'z', -4) == 'zbczbc'
	assert candidate(
    "I love apples, apple are my favorite fruit", "apple", "pineapple", 2
) == "I love pineapples, pineapple are my favorite fruit"
	assert candidate(string = "hello world hello", value = "hello", new_value = "hola", occurences = 1) == "hola world hello"
	assert candidate('abc', 'a', 'z', 2) == 'zbc'
	assert candidate(
    "I like apples", 
    "apples", 
    "bananas", 
    -1) == "I like bananas"
	assert candidate("I like bananas", "bananas", "apples") == "I like apples"
	assert candidate(
    "I love apples, apple are my favorite fruit", "banana", "apple", -1) == "I love apples, apple are my favorite fruit"
	assert candidate(
    "I like to eat cereal", "cereal", "candy", -1
) == "I like to eat candy"
	assert candidate(
    "I like to eat cereal", "cereal", "candy", 2
) == "I like to eat candy"
	assert candidate('abcabc', 'a', 'z', 2) == 'zbczbc'
	assert candidate(string = "hello world", value = "hello", new_value = "hola") == "hola world"
	assert candidate(
    "This, is a test", "test", "example", 2
) == "This, is a example"
	assert candidate(string = "I like apples, apple are my favorite fruit", value = "pineapple", new_value = "banana") == "I like apples, apple are my favorite fruit"
	assert candidate("Hello world!", "world", "worlds", 0) == "Hello world!"
	assert candidate(string="I am a string", value="am", new_value="was", occurences=-1) == "I was a string"
	assert candidate(string = "abcabcabc", value = "abc", new_value = "def", occurences = -1) == "defdefdef"
	assert candidate(
    "I like bananas", "bananas", "apples", 2) == "I like apples"
	assert candidate(string = "Hello, World!", value = "Hello", new_value = "Goodbye") == "Goodbye, World!"
	assert candidate(
    "I will not buy this record, it is scratched.", "scratched", "destroyed"
) == "I will not buy this record, it is destroyed."
	assert candidate(string = "Hello, World!", value = "Hello", new_value = "Goodbye", occurences = 1) == "Goodbye, World!"
	assert candidate(string = "this is a string", value = "is", new_value = "was", occurences = 2) == "thwas was a string"
	assert candidate(
    "I love apples, apple are my favorite fruit", "apple", "pineapple", -1
) == "I love pineapples, pineapple are my favorite fruit"
	assert candidate(
    "I like bananas", "bananas", "apples", 1) == "I like apples"
	assert candidate( "apples, pears # and bananas", "#", "oranges", 0 ) == "apples, pears # and bananas", "candidate #5"
	assert candidate(
    "I love apples, apple are my favorite fruit", "apple", "pineapple", 0
) == "I love apples, apple are my favorite fruit"
	assert candidate('abc', 'a', 'z', 1) == 'zbc'
	assert candidate(string = "abcabcabc", value = "abc", new_value = "def", occurences = 100) == "defdefdef"
	assert candidate("Hello world!", "world", "worlds", 1) == "Hello worlds!"
	assert candidate(
    "I like to eat cereal", "cereal", "candy", 0
) == "I like to eat cereal"
	assert candidate(string = "hello world hello", value = "hello", new_value = "hola", occurences = 3) == "hola world hola"
	assert candidate('abcdef', 'abc', 'def', 2) == 'defdef'
	assert candidate(
    "I like apples", 
    "apple", 
    "banana", 
    2) == "I like bananas"
	assert candidate( "apples, pears # and bananas", "#", "oranges", 1 ) == "apples, pears oranges and bananas", "candidate #3"
	assert candidate('abc', 'a', 'z') == 'zbc'
	assert candidate(string = "abcabcabc", value = "abc", new_value = "def", occurences = 0) == "abcabcabc"
	assert candidate('abcabc', 'a', 'z', 4) == 'zbczbc'
	assert candidate(string="I am a string", value="am", new_value="was") == "I was a string"
	assert candidate("Take my protein pills and put my helmet on", "my", "your", 2) == "Take your protein pills and put your helmet on"
def test_check():
	check(str_replace)
