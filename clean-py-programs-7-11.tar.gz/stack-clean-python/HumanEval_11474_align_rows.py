def align_rows(rows, bbox):
    """
    For every row, align the left and right boundaries to the final
    table bounding box.
    """
    ### Canonical solution below ###
    try:
        for row in rows:
            row['bbox'][0] = bbox[0]
            row['bbox'][2] = bbox[2]
    except Exception as err:
        print("Could not align rows: {}".format(err))
        pass

    return rows


### Unit tests below ###
def check(candidate):
	assert candidate(
    [{
        'bbox': []
    }],
    [0, 0, 100, 100]
) == [{
    'bbox': []
}]
	assert candidate(
    [{
        'bbox': [10, 10, 20, 20]
    }],
    [0, 0, 100, 100]
) == [{
    'bbox': [0, 10, 100, 20]
}]
	assert candidate(
    [
        {'bbox': [10, 10, 20, 20]},
        {'bbox': [10, 10, 20, 20]},
        {'bbox': [10, 10, 20, 20]},
    ],
    [10, 10, 20, 20]
) == [
    {'bbox': [10, 10, 20, 20]},
    {'bbox': [10, 10, 20, 20]},
    {'bbox': [10, 10, 20, 20]},
]
	assert candidate(
    [
        {'bbox': [0, 0, 200, 100]},
        {'bbox': [0, 100, 200, 200]}
    ],
    [0, 0, 200, 200]
) == [
    {'bbox': [0, 0, 200, 100]},
    {'bbox': [0, 100, 200, 200]}
]
	assert candidate(
    [
        {'bbox': [0, 0, 200, 100]},
        {'bbox': [0, 100, 200, 200]}
    ],
    [0, 0, 200, 100]
) == [
    {'bbox': [0, 0, 200, 100]},
    {'bbox': [0, 100, 200, 200]}
]
	assert candidate(
    [{
        'bbox': [1, 2, 3, 4]
    }, {
        'bbox': [5, 6, 7, 8]
    }],
    [1, 2, 3, 4]
)[0]['bbox'] == [1, 2, 3, 4]
	assert candidate(
    [
        {
            'bbox': [1, 2, 3, 4]
        },
        {
            'bbox': [5, 6, 7, 8]
        },
        {
            'bbox': [9, 10, 11, 12]
        }
    ],
    [0, 0, 10, 6]
)
	assert candidate(
    [
        {'bbox': [50, 200, 250, 300]},
        {'bbox': [50, 300, 250, 400]},
        {'bbox': [50, 400, 250, 500]},
        {'bbox': [50, 500, 250, 600]},
        {'bbox': [50, 600, 250, 700]},
    ],
    [0, 0, 1000, 700],
) == [
    {'bbox': [0, 200, 1000, 300]},
    {'bbox': [0, 300, 1000, 400]},
    {'bbox': [0, 400, 1000, 500]},
    {'bbox': [0, 500, 1000, 600]},
    {'bbox': [0, 600, 1000, 700]},
]
	assert candidate(
    [
        {'bbox': [100, 100, 200, 200]},
        {'bbox': [100, 200, 200, 300]},
        {'bbox': [100, 300, 200, 400]},
    ],
    [0, 0, 1000, 1000]
) == [
    {'bbox': [0, 100, 1000, 200]},
    {'bbox': [0, 200, 1000, 300]},
    {'bbox': [0, 300, 1000, 400]},
]
	assert candidate(
    [
        {
            'bbox': [1, 2, 3, 4]
        },
        {
            'bbox': [5, 6, 7, 8]
        },
        {
            'bbox': [9, 10, 11, 12]
        }
    ],
    [0, 0, 10, 10]
) == [
    {
        'bbox': [0, 2, 10, 4]
    },
    {
        'bbox': [0, 6, 10, 8]
    },
    {
        'bbox': [0, 10, 10, 12]
    }
]
	assert candidate(
    [
        {
            'bbox': [10, 10, 20, 20],
            'text': "a"
        },
        {
            'bbox': [30, 10, 40, 20],
            'text': "b"
        }
    ],
    [10, 10, 50, 20]
) == [
    {
        'bbox': [10, 10, 50, 20],
        'text': "a"
    },
    {
        'bbox': [10, 10, 50, 20],
        'text': "b"
    }
]
	assert candidate(
    [{'bbox': [0, 0, 100, 200]}, {'bbox': [0, 0, 100, 200]}],
    [0, 0, 100, 200]
)[0]['bbox'] == [0, 0, 100, 200]
	assert candidate(
    [{
        'bbox': [1, 2, 3, 4]
    }, {
        'bbox': [5, 6, 7, 8]
    }],
    [1, 2, 7, 4]
)[0]['bbox'] == [1, 2, 7, 4]
	assert candidate(
    [
        {
            'bbox': [1, 2, 3, 4]
        },
        {
            'bbox': [5, 6, 7, 8]
        },
        {
            'bbox': [9, 10, 11, 12]
        }
    ],
    [0, 0, 10, 2]
) == [
    {
        'bbox': [0, 2, 10, 4]
    },
    {
        'bbox': [0, 6, 10, 8]
    },
    {
        'bbox': [0, 10, 10, 12]
    }
]
	assert candidate(
    [{
        'bbox': [1, 2, 3, 4]
    }],
    [1, 2, 3, 4]
)[0]['bbox'] == [1, 2, 3, 4]
	assert candidate(
    rows=[{'bbox': [1, 2, 3, 4]}],
    bbox=[0, 0, 5, 6]
) == [{'bbox': [0, 2, 5, 4]}]
	assert candidate(
    [{
        'bbox': [1, 2, 3, 4]
    }, {
        'bbox': [5, 6, 7, 8]
    }],
    [1, 2, 7, 4]
)[1]['bbox'] == [1, 6, 7, 8]
def test_check():
	check(align_rows)
