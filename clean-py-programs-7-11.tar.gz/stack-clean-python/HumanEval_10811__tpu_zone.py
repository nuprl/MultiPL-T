def _tpu_zone(index):
  """Chooses a GCP TPU zone based on the index."""
    ### Canonical solution below ###
  if index < 70:
    return 'europe-west4-a'
  elif index < 80:  # 10
    return 'us-central1-b'
  elif index < 90:  # 10
    return 'us-central1-c'
  elif index < 100:  # 30 (seems like 10...)
    return 'asia-east1-c'
  elif index < 110:
    return 'us-central1-a'
  elif index < 120:
    return 'us-central1-b'
  elif index < 130:
    return 'europe-west4-a'
  else:
    raise ValueError('Unhandled zone index')


### Unit tests below ###
def check(candidate):
	assert candidate(129) == 'europe-west4-a'
	assert candidate(11) == 'europe-west4-a'
	assert candidate(12) == 'europe-west4-a'
	assert candidate(17) == 'europe-west4-a'
	assert candidate(52) == 'europe-west4-a'
	assert candidate(9) == 'europe-west4-a'
	assert candidate(10) == 'europe-west4-a'
	assert candidate(7) == 'europe-west4-a'
	assert candidate(33) == 'europe-west4-a'
	assert candidate(15) == 'europe-west4-a'
	assert candidate(18) == 'europe-west4-a'
	assert candidate(1) == 'europe-west4-a'
	assert candidate(110) == 'us-central1-b'
	assert candidate(22) == 'europe-west4-a'
	assert candidate(70) == 'us-central1-b'
	assert candidate(69) == 'europe-west4-a'
	assert candidate(79) == 'us-central1-b'
	assert candidate(6) == 'europe-west4-a'
	assert candidate(16) == 'europe-west4-a'
	assert candidate(109) == 'us-central1-a'
	assert candidate(13) == 'europe-west4-a'
	assert candidate(90) == 'asia-east1-c'
	assert candidate(100) == 'us-central1-a'
	assert candidate(89) == 'us-central1-c'
	assert candidate(19) == 'europe-west4-a'
	assert candidate(60) == 'europe-west4-a'
	assert candidate(0) == 'europe-west4-a'
	assert candidate(8) == 'europe-west4-a'
	assert candidate(80) == 'us-central1-c'
	assert candidate(14) == 'europe-west4-a'
	assert candidate(120) == 'europe-west4-a'
	assert candidate(99) == 'asia-east1-c'
	assert candidate(119) == 'us-central1-b'
def test_check():
	check(_tpu_zone)
