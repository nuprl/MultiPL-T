def placeShipV(row: int, col: int, lg: int , grid: list, symbol: str) -> bool:
    """
    Place the ship vertically if possible.

    Parameters
    ----------
    row : int
        Row number.
    col : int
        Column number.
    lg : int
        Number of cells occupied by the ship that is tried to be placed.
    grid : list
        Battleship grid.
    symbol : str
        Character that represents the ship.

    Returns
    -------
    bool
        True if the ship is placed, False otherwise.

    """
    ### Canonical solution below ###
    shipInPlace = True
    if row+lg>10:
            shipInPlace = False
    else:
        for count in range(lg):
            if grid[row+count][col]!="E":
                shipInPlace = False
    if shipInPlace:
        for count in range(lg):
            grid[row+count][col] = symbol
    return shipInPlace


### Unit tests below ###
def check(candidate):
	assert candidate(0, 0, 3, [['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E']], 'S') == True
	assert candidate(0, 0, 1, [["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"],\
                            ["E","E","E","E","E","E","E","E","E","E"]], "S") == True
	assert candidate(0, 0, 1, [['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'], ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E']], 'A') == True
	assert candidate(5, 4, 2, [["E"]*10]*10, "S")==True
	assert candidate(0, 0, 3, [['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E'],
                            ['E','E','E','E','E','E','E','E','E','E']], "V") == True
	assert candidate(0, 0, 3, [['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E'],
                            ['E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E']], "S") == True
	assert candidate(2, 5, 2, [['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'], ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X']], 'A') == False
def test_check():
	check(placeShipV)
