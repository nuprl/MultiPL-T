def capitalize_string(s):
    """ 
     Write a function that accepts a string. The function should
     capitalize the first letter of each word in the string then
     return the capitalized string.
     self.assertEqual(func('a short sentence'), 'A Short Sentence'))
     self.assertEqual(func('a lazy fox'), 'A Lazy Fox'))
     self.assertEqual(func('look, it is working!'), 'Look, It Is Working!'))
     """
	### Canonical solution below ###    
    word_list = []
    for word in s.split(' '):
        cap_word = word

        if word[0].isalnum():
            cap_word = word[0].upper() + word[1:]

        word_list.append(cap_word)
    
    new_s = ' '.join(word_list)

    return new_s

### Unit tests below ###
def check(candidate):
	assert candidate(s='look, it is working!') == 'Look, It Is Working!'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Testing capitalize first letter'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Third'
	assert candidate(
    'a short sentence'
) == 'A Short Sentence'
	assert candidate(
    'a lazy fox') == 'A Lazy Fox', 'Should capitalize first letters of words'
	assert candidate(
    'The lord of the rings') == 'The Lord Of The Rings', "Fourth"
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!'
	assert candidate(
    'Wait there is not much more to learn') == 'Wait There Is Not Much More To Learn', "Fifth"
	assert candidate('a lazy fox') == 'A Lazy Fox', 'Should capitalize first letters of words'
	assert candidate(
    'a lazy fox'
) == 'A Lazy Fox'
	assert candidate(
    'a lazy fox') == 'A Lazy Fox'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Testing capitalize last letter'
	assert candidate('a lazy fox') == 'A Lazy Fox'
	assert candidate(
    'capitalize this, then that') == 'Capitalize This, Then That'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Should capitalize first letters of each word'
	assert candidate(s='a lazy fox') == 'A Lazy Fox'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Testing punctuation'
	assert candidate('look, it is working!') == 'Look, It Is Working!', 'Third'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Testing capitalize middle letter'
	assert candidate(
    'a lazy fox') == 'A Lazy Fox', "Should be 'A Lazy Fox'"
	assert candidate(
    'a lazy fox') == 'A Lazy Fox', 'Second'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', "Should be 'Look, It Is Working!'"
	assert candidate('a lazy fox') == 'A Lazy Fox', "Second"
	assert candidate(s='a short sentence') == 'A Short Sentence'
	assert candidate(
    'look, it is working!'
) == 'Look, It Is Working!'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Should capitalize first letters of words'
	assert candidate(
    'a short sentence') == 'A Short Sentence'
	assert candidate(
    'a short sentence') == 'A Short Sentence', 'First'
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', "Third"
	assert candidate(
    'a lazy fox') == 'A Lazy Fox', 'Should capitalize first letters of each word'
	assert candidate('a lazy fox') == 'A Lazy Fox', 'Second'
	assert candidate('look, it is working!') == 'Look, It Is Working!'
	assert candidate(
    'a lazy fox') == 'A Lazy Fox', 'Testing a lazy fox'
	assert candidate(
    'a short sentence') == 'A Short Sentence', "First"
	assert candidate(
    'look, it is working!') == 'Look, It Is Working!', 'Testing capitalize multiple letters'
	assert candidate(
    'a short sentence') == 'A Short Sentence', 'Should capitalize first letters of words'
	assert candidate(
    'a short sentence') == 'A Short Sentence', "Should be 'A Short Sentence'"
	assert candidate(
    'a short sentence') == 'A Short Sentence', 'Should capitalize first letters of each word'
	assert candidate(
    'a lazy fox') == 'A Lazy Fox', "Second"
	assert candidate(
    'a short sentence') == 'A Short Sentence', 'Testing short sentence'
def test_check():
	check(capitalize_string)
