def findCameraInArchive(camArchives, cameraID):
    """ Find the entries in the camera archive directories for the given camera
     
     Args:
     camArchives (list): Result of getHpwrenCameraArchives() above
     cameraID (str): ID of camera to fetch images from
     
     Returns:
     List of archive dirs that matching camera
     """
	### Canonical solution below ###    
    matchingCams = list(filter(lambda x: cameraID == x['id'], camArchives))
    # logging.warning('Found %d match(es): %s', len(matchingCams), matchingCams)
    if matchingCams:
        return matchingCams[0]['dirs']
    else:
        return []

### Unit tests below ###
def check(candidate):
	assert candidate(
    [{'id': '2018-03-27T11:02:27.236670', 'dirs': ['/var/hpwren/2018-03-27T11:02:27.236670/00000001']}],
    '2018-03-27T11:02:27.236671'
) == []
	assert candidate(
    [
        {
            'id': 'camera-1',
            'dirs': ['/path/to/archive/camera-1/20190718', '/path/to/archive/camera-1/20190719']
        },
        {
            'id': 'camera-2',
            'dirs': ['/path/to/archive/camera-2/20190718']
        }
    ],
    'camera-1'
) == ['/path/to/archive/camera-1/20190718', '/path/to/archive/camera-1/20190719']
	assert candidate(
    [{'id': '1234', 'dirs': ['foo', 'bar']}, {'id': '2345', 'dirs': ['baz']}],
    '2345') == ['baz']
	assert candidate(
    [
        {
            'id': 'camera-1',
            'dirs': ['/path/to/archive/camera-1/20190718', '/path/to/archive/camera-1/20190719']
        },
        {
            'id': 'camera-2',
            'dirs': ['/path/to/archive/camera-2/20190718']
        }
    ],
    'camera-2'
) == ['/path/to/archive/camera-2/20190718']
	assert candidate(
    [{'id': '1234', 'dirs': ['foo', 'bar']}, {'id': '2345', 'dirs': ['baz']}],
    '9999') == []
	assert candidate(
    [{'id': '2018-03-27T11:02:27.236670', 'dirs': ['/var/hpwren/2018-03-27T11:02:27.236670/00000001']}],
    '2018-03-27T11:02:27.236670'
) == ['/var/hpwren/2018-03-27T11:02:27.236670/00000001']
	assert candidate(
    [{'id': '1234', 'dirs': ['foo', 'bar']}, {'id': '2345', 'dirs': ['baz']}],
    '1234') == ['foo', 'bar']
def test_check():
	check(findCameraInArchive)
