def _process_create_group(event: dict) -> list:
    """ Process CreateGroup event. This function doesn't set tags. """
    ### Canonical solution below ###

    return [event['responseElements']['group']['groupName']]


### Unit tests below ###
def check(candidate):
	assert candidate(
    {"responseElements": {
        "group": {"groupName": "MyGroup", "tags": [{"key": "MyKey", "value": "MyValue"}]}}}
) == ["MyGroup"]
	assert candidate(
    {"responseElements": {
        "group": {"groupName": "MyGroup", "tags": [{"key": "MyKey", "value": "MyValue"}, {"key": "MyKey2", "value": "MyValue2"}, {"key": "MyKey3", "value": "MyValue3"}]}}}
) == ["MyGroup"]
	assert candidate(
    {"responseElements": {
        "group": {"groupName": "MyGroup", "tags": [{"key": "MyKey", "value": "MyValue"}, {"key": "MyKey2", "value": "MyValue2"}]}}}
) == ["MyGroup"]
	assert candidate(
    {'responseElements': {'group': {'groupName':'my_group'}}}
) == ['my_group']
	assert candidate(
    {"responseElements": {
        "group": {"groupName": "MyGroup"}}}
) == ["MyGroup"]
	assert candidate(
    {
       'responseElements': {
            'group': {
                'groupName': 'GroupName'
            }
        }
    }
) == ['GroupName']
	assert candidate(
    {"responseElements": {
        "group": {"groupName": "MyGroup", "tags": [{"key": "MyKey", "value": "MyValue"}, {"key": "MyKey2", "value": "MyValue2"}, {"key": "MyKey3", "value": "MyValue3"}, {"key": "MyKey4", "value": "MyValue4"}]}}}
) == ["MyGroup"]
def test_check():
	check(_process_create_group)
