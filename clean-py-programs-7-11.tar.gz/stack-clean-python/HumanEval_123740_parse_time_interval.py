def parse_time_interval(time_arg):
    """Parse a simple string representing a time interval and return an integer number of seconds"""
    ### Canonical solution below ###
    try:
        return int(time_arg)
    except ValueError:
        pass
    if time_arg.endswith('s'):
        seconds = int(time_arg[:-1])
    elif time_arg.endswith('m'):
        seconds = int(time_arg[:-1]) * 60
    elif time_arg.endswith('h'):
        seconds = int(time_arg[:-1]) * 3600
    else:
        raise ValueError('Unknown time units')
    return seconds


### Unit tests below ###
def check(candidate):
	assert candidate('1000000h') == 3600000000
	assert candidate('123') == 123
	assert candidate('30') == 30
	assert candidate('123h') == 123 * 3600
	assert candidate('100s') == 100
	assert candidate(10) == 10
	assert candidate(1000000) == 1000000
	assert candidate(1000) == 1000
	assert candidate('123 h') == 123 * 3600
	assert candidate('30m') == 30 * 60
	assert candidate(100) == 100
	assert candidate('1000h') == 3600000
	assert candidate('123 m') == 123 * 60
	assert candidate('5') == 5
	assert candidate('123m') == 123 * 60
	assert candidate(5) == 5
	assert candidate('30h') == 30 * 3600
	assert candidate('1000000s') == 1000000
	assert candidate(100000) == 100000
	assert candidate(1) == 1
	assert candidate('1000m') == 60000
	assert candidate('100m') == 100*60
	assert candidate('10 h') == 36000
	assert candidate('10s') == 10
	assert candidate('30s') == 30
	assert candidate(123) == 123
	assert candidate('123s') == 123
	assert candidate('10000000m') == 10000000 * 60
	assert candidate('10h') == 36000
	assert candidate('123 s') == 123
	assert candidate('10m') == 10 * 60
	assert candidate('100h') == 100*3600
	assert candidate('10m') == 600
	assert candidate('2m') == 120
	assert candidate('10') == 10
	assert candidate('10000000h') == 10000000 * 3600
	assert candidate('10000m') == 10000 * 60
	assert candidate('1h') == 3600
	assert candidate('100m') == 6000
	assert candidate('5h') == 18000
	assert candidate('1000000m') == 60000000
	assert candidate('1') == 1
	assert candidate('30m') == 1800
	assert candidate('5m') == 300
	assert candidate(10000) == 10000
	assert candidate('30h') == 108000
	assert candidate('1s') == 1
	assert candidate('1m') == 60
	assert candidate('10000s') == 10000
	assert candidate('10h') == 10 * 3600
	assert candidate(30) == 30
	assert candidate('10000h') == 10000 * 3600
	assert candidate('5s') == 5
	assert candidate('100') == 100
	assert candidate('1000s') == 1000
	assert candidate(10000000) == 10000000
	assert candidate('100h') == 360000
def test_check():
	check(parse_time_interval)
