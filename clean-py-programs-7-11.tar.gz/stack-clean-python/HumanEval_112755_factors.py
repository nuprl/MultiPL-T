def factors(n):
    """ Return a sequence of (a, b) tuples where a < b giving factors of n.
     
     Based on https://stackoverflow.com/a/6909532/916373
     """
	### Canonical solution below ###    
    return [(i, n//i)  for i in range(1, int(n**0.5) + 1) if n % i == 0]

### Unit tests below ###
def check(candidate):
	assert candidate(1237) == [(1, 1237)]
	assert candidate(13) == [(1, 13)]
	assert candidate(9) == [(1, 9), (3, 3)]
	assert candidate(10) == [(1, 10), (2, 5)]
	assert candidate(4) == [(1, 4), (2, 2)]
	assert candidate(14) == [(1,14), (2,7)]
	assert candidate(11) == [(1,11)]
	assert candidate(5) == [(1, 5)]
	assert candidate(3) == [(1,3)]
	assert candidate(1) == [(1, 1)]
	assert candidate(12) == [(1, 12), (2, 6), (3, 4)]
	assert candidate(2) == [(1,2)]
	assert candidate(25) == [(1,25), (5,5)]
	assert candidate(17) == [(1, 17)]
	assert candidate(21) == [(1, 21), (3, 7)]
	assert candidate(1247)
	assert candidate(15) == [(1, 15), (3, 5)]
	assert candidate(101) == [(1, 101)]
	assert candidate(7) == [(1, 7)]
	assert candidate(15) == [(1,15), (3,5)]
	assert candidate(17) == [(1,17)]
	assert candidate(18) == [(1, 18), (2, 9), (3, 6)]
	assert candidate(0) == []
	assert candidate(19) == [(1,19)]
	assert candidate(19) == [(1, 19)]
	assert candidate(14) == [(1, 14), (2, 7)]
	assert candidate(22) == [(1,22), (2,11)]
	assert candidate(7) == [(1,7)]
	assert candidate(11) == [(1, 11)]
	assert candidate(21) == [(1,21), (3,7)]
	assert candidate(8) == [(1, 8), (2, 4)]
	assert candidate(13) == [(1,13)]
	assert candidate(6) == [(1, 6), (2, 3)]
	assert candidate(3) == [(1, 3)]
	assert candidate(5) == [(1,5)]
	assert candidate(2) == [(1, 2)]
def test_check():
	check(factors)
