def load_properties(multiline, separator='=', comment_char='#', keys=None):
    """
    Read a multiline string of properties (key/value pair separated by *separator*) into a dict

    :param multiline:    input string of properties
    :param separator:    separator between key and value
    :param comment_char: lines starting with this char are considered comments, not key/value pairs
    :param keys:         list to append the keys to
    :return:
    """
    ### Canonical solution below ###
    props = {}
    for line in multiline.splitlines():
        stripped_line = line.strip()
        if stripped_line and not stripped_line.startswith(comment_char):
            key_value = stripped_line.split(separator)
            key = key_value[0].strip()
            value = separator.join(key_value[1:]).strip().strip('"')
            props[key] = value
            if keys != None:
                keys.append(key)
    return props


### Unit tests below ###
def check(candidate):
	assert candidate(
    """
    # comment
    key1=value1
    key2 = value2
    key3 = "value3"
    key4 = value4
    key5 = "value5"
    key6 = value6
    """) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
    'key5': 'value5',
    'key6': 'value6'}
	assert candidate(
    """
    a = 1
    b = 2
    c = 3
    """
) == {
    'a': '1',
    'b': '2',
    'c': '3'
}
	assert candidate(
    """
# comment
key1 = value1
# comment
key2=value2
    """
) == {'key1': 'value1', 'key2': 'value2'}
	assert candidate('a=b\nc=d\ne=\n', keys=['a','c','e']) == {'a':'b', 'c':'d', 'e':''}
	assert candidate(u'a="b\\nc"') == {'a': 'b\\nc'}
	assert candidate(
    'key1 = value1\n'
    'key2 = value2\n'
    'key3 = value3\n'
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
}
	assert candidate(
   '# Comment\n'
    'a = 1\n'
    'b = 2\n'
    'c = 3', keys=['a', 'b', 'c']) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(u'a=b\nc=d\n#e=f') == {'a': 'b', 'c': 'd'}
	assert candidate(r"""
#comment
key1=value1
key2=value2
key3=value3
key4=value4
""") == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
}
	assert candidate(
    'key1 = value1\n'
    'key2 = value2\n'
    '# This is a comment\n'
    'key3 = value3\n'
    'key4=value4\n'
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4'
}
	assert candidate(
    """
    a = 1
    b = 2
    c = 3
    """
, comment_char='%') == {
    'a': '1',
    'b': '2',
    'c': '3'
}
	assert candidate(
    """
    # Comment
    key1=value1
    key2=value2
    key3=value3
    """,
    keys=['key1', 'key2', 'key3']
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
	assert candidate(
    """
    # Comment
    key1=value1
    key2=value2
    key3=value3
    """,
    keys=['key1', 'key2']
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
	assert candidate(
    '''
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6
    g = 7
    h = 8
    # comment
    ''') == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5', 'f': '6', 'g': '7', 'h': '8'}
	assert candidate(
    '''
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6
    g = 7
    h = 8
    ''') == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5', 'f': '6', 'g': '7', 'h': '8'}
	assert candidate(
   '# Comment\n'
    'a = 1\n'
    'b = 2\n'
    'c = 3', keys=['a', 'b']) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(
    """
    key1=value1
    key2=value2
    key3 = value3
    key4 = value4
    """) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
}
	assert candidate(
    """
    # comment
    key = value
    # comment 2
    another_key = value
    """) == {
    "key": "value",
    "another_key": "value"
}
	assert candidate(
    """
    # comment
    key1 = value1
    key2 = value2
    # comment
    key3 = value3
    # comment
    key4 = value4
    """
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
	assert candidate(
    'key1=value1\n'
    'key2=value2\n'
    '\n'
    '# comment\n'
    'key3=value3\n'
    'key4=value4'
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4'
}
	assert candidate(
    """
    # comment
    key1 = value1
    key2 = value2
    key3 = value3
    """
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
	assert candidate(
    """
    key1=value1
    key2 = value2
    key3=value3
    key4=value4
    """, keys=['key1', 'key2', 'key3', 'key4']) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
	assert candidate(u"""
a = 1
b = "2"
#c = 3
#d = "4"
""") == {'a': '1', 'b': '2'}
	assert candidate(u"""
a = 1
b = "2"
#c = 3
#d = "4"
""", keys=['a', 'b']) == {'a': '1', 'b': '2'}
	assert candidate(
    """
    a = 1
    b = 2
    """
) == {
    'a': '1',
    'b': '2'
}
	assert candidate(
   '# Comment\n'
    'a = 1\n'
    'b = 2\n'
    'c = 3', keys=[]) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(
    """
    # Comment
    key1=value1
    key2=value2
    key3=value3
    """,
    keys=[]
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
	assert candidate(
    """
    # comment
    a=1
    # comment
    b=2
    c=3
    """, keys=[]
) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(r"""
# this is a comment

# and another one

key1 = value1
key2 = value2
key3 = "value3 with spaces"
""") == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3 with spaces'}
	assert candidate(
    """
    # comment
    key1=value1
    key2 = value2
    key3 = "value3"
    key4=value4,value5,value6
    key5 = value7,value8,value9
    key6 = "value10,value11,value12"
    key7 = value13,value14,value15
    """
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4,value5,value6',
    'key5': 'value7,value8,value9',
    'key6': 'value10,value11,value12',
    'key7': 'value13,value14,value15'
}
	assert candidate(u'a=b') == {'a': 'b'}
	assert candidate(
    """
    a=1
    b=2
    c=3
    """, keys=[]
) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(r"""
# this is a comment

# and another one

key1=value1
key2 = value2
key3 = "value3 with spaces"
""") == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3 with spaces'}
	assert candidate(
    '''
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6
    g = 7
    h = 8
    # comment
    # comment
    ''') == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5', 'f': '6', 'g': '7', 'h': '8'}
	assert candidate(u'a=b\nc=d\ne=f', keys=['a', 'c', 'e']) == {'a': 'b', 'c': 'd', 'e': 'f'}
	assert candidate('a=b\nc=d\ne=\n') == {'a':'b', 'c':'d', 'e':''}
	assert candidate(
    """
    key1=value1
    key2=value2
    key3 = value3
    key4 = value4
    """, keys=list()) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
}
	assert candidate(
    'key1=value1\n' +
    'key2 = value2\n' +
    'key3 = value3\n' +
    '\n' +
    'key4=value4\n' +
    'key5 = value5\n' +
    '#comment\n' +
    'key6 = value6\n'
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
    'key5': 'value5',
    'key6': 'value6',
}
	assert candidate('a=b\nc=d\ne=\n', keys=[]) == {'a':'b', 'c':'d', 'e':''}
	assert candidate(
    'key1 = value1\n'
    'key2 = value2\n'
    'key3 = value3\n'
    'key4 = value4\n'
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
}
	assert candidate(r"""
# this is a comment

# and another one

key1=value1
key2=value2
key3 = "value3 with spaces"
""") == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3 with spaces'}
	assert candidate(u'a=b\nc=d') == {'a': 'b', 'c': 'd'}
	assert candidate(u'a=b\nc=d\ne=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
	assert candidate(
    """
    a=1
    b=2
    c=3
    """
) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(
    """
    # Comment
    key1=value1
    key2=value2
    key3=value3
    """,
    keys=['key1', 'key2', 'key3', 'key4']
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
	assert candidate('a=b\nc=d\ne=') == {'a':'b', 'c':'d', 'e':''}
	assert candidate(u'a="b c"') == {'a': 'b c'}
	assert candidate(
    'key1 = value1\n'
    'key2 = value2\n'
    'key3 = value3\n'
    'key4 = value4\n'
    'key5 = value5\n'
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
    'key5': 'value5',
}
	assert candidate(u'a=b\nc=d\ne=f', keys=['a']) == {'a': 'b', 'c': 'd', 'e': 'f'}
	assert candidate(
    """
    key1=value1
    key2=value2
    key3 = value3
    key4 = value4
    """, keys=['a', 'b', 'c']) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
}
	assert candidate(
   '# Comment\n'
    'a = 1\n'
    'b = 2\n'
    'c = 3') == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(u'a=b\n#c=d') == {'a': 'b'}
	assert candidate(
    """
    # Comment
    key1=value1
    key2=value2
    key3=value3
    """
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
	assert candidate(
    """
    key1=value1
    key2 = value2
    key3 = "value3"
    key4 = value4
    key5 = "value5"
    key6 = value6
    """) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
    'key5': 'value5',
    'key6': 'value6'}
	assert candidate(
    """
    key1=value1
    key2 = value2
    key3=value3
    key4=value4
    """) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
	assert candidate(
   '# Comment\n'
    'a = 1\n'
    'b = 2\n'
    'c = 3', keys=['a', 'b', 'c', 'd']) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(
    """
    # comment
    a=1
    # comment
    b=2
    c=3
    """, keys=['a', 'b', 'c']
) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(u'a=b\nc=d\ne=f', keys=['a', 'c']) == {'a': 'b', 'c': 'd', 'e': 'f'}
	assert candidate(
    'key1=value1\n'
    'key2 = value2\n'
    'key3 = "value3"\n'
    'key4=value4\n'
    'key5 = "value5"\n'
    'key6 = "value6"\n'
    'key7 = "value7"\n'
    'key8 = "value8"\n'
    'key9 = "value9"\n'
    'key10 = "value10"\n'
) == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
    'key5': 'value5',
    'key6': 'value6',
    'key7': 'value7',
    'key8': 'value8',
    'key9': 'value9',
    'key10': 'value10'
}
	assert candidate(u'a=b\nc=d\ne=f', keys=[]) == {'a': 'b', 'c': 'd', 'e': 'f'}
	assert candidate('a=b\nc=d') == {'a':'b', 'c':'d'}
	assert candidate(u'a = 1\nb = 2') == {'a': '1', 'b': '2'}
	assert candidate(
    """
    # comment
    key1 = value1
    key2 = value2
    """
) == {'key1': 'value1', 'key2': 'value2'}
	assert candidate(
    """
    a=1
    b=2
    c=3
    """, keys=['a', 'b', 'c']
) == {'a': '1', 'b': '2', 'c': '3'}
	assert candidate(
    """
    # comment
    key1 = value1
    key2 = value2
    # comment
    key3 = value3
    """
) == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
	assert candidate(
"""
key1 = value1
key2 = value2
# This is a comment
key3 = value3
key4 = value4
# Another comment
key5 = value5
""") == {
    'key1': 'value1',
    'key2': 'value2',
    'key3': 'value3',
    'key4': 'value4',
    'key5': 'value5',
}
def test_check():
	check(load_properties)
