def get_expected_python_full_config_object() -> dict:
    """ expected python object"""
	### Canonical solution below ###    
    return {
        "safety": {"REQUIREMENTS_FILES": ["default-requirements.txt"]},
        "safety_quick": {"REQUIREMENTS_FILES": ["small-requirements.txt"]},
        "safety_slow": {"REQUIREMENTS_FILES": ["big-requirements.txt"]},
        "scan": {
            "ci": {"reporters": ["console"], "tools": ["safety:slow"]},
            "ci-prod": {
                "reporters": ["console"],
                "safety_slow": {"REQUIREMENTS_FILES": ["prod-big-requirements.txt"]},
                "tools": ["safety:slow"],
            },
            "dev": {"reporters": ["console"], "tools": ["safety:fast"]},
            "reporters": ["console", "json", "junit", "quality"],
            "tools": ["safety"],
        },
    }

### Unit tests below ###
def check(candidate):
	assert candidate(
) == {
    "safety": {"REQUIREMENTS_FILES": ["default-requirements.txt"]},
    "safety_quick": {"REQUIREMENTS_FILES": ["small-requirements.txt"]},
    "safety_slow": {"REQUIREMENTS_FILES": ["big-requirements.txt"]},
    "scan": {
        "ci": {"reporters": ["console"], "tools": ["safety:slow"]},
        "ci-prod": {
            "reporters": ["console"],
            "safety_slow": {
                "REQUIREMENTS_FILES": ["prod-big-requirements.txt"]
            },
            "tools": ["safety:slow"],
        },
        "dev": {"reporters": ["console"], "tools": ["safety:fast"]},
        "reporters": ["console", "json", "junit", "quality"],
        "tools": ["safety"],
    },
}
	assert candidate() == {
    "safety": {"REQUIREMENTS_FILES": ["default-requirements.txt"]},
    "safety_quick": {"REQUIREMENTS_FILES": ["small-requirements.txt"]},
    "safety_slow": {"REQUIREMENTS_FILES": ["big-requirements.txt"]},
    "scan": {
        "ci": {"reporters": ["console"], "tools": ["safety:slow"]},
        "ci-prod": {
            "reporters": ["console"],
            "safety_slow": {"REQUIREMENTS_FILES": ["prod-big-requirements.txt"]},
            "tools": ["safety:slow"],
        },
        "dev": {"reporters": ["console"], "tools": ["safety:fast"]},
        "reporters": ["console", "json", "junit", "quality"],
        "tools": ["safety"],
    },
}
	assert candidate(
) == candidate()
	assert candidate(
    ) == {
        "safety": {"REQUIREMENTS_FILES": ["default-requirements.txt"]},
        "safety_quick": {"REQUIREMENTS_FILES": ["small-requirements.txt"]},
        "safety_slow": {"REQUIREMENTS_FILES": ["big-requirements.txt"]},
        "scan": {
            "ci": {"reporters": ["console"], "tools": ["safety:slow"]},
            "ci-prod": {
                "reporters": ["console"],
                "safety_slow": {"REQUIREMENTS_FILES": ["prod-big-requirements.txt"]},
                "tools": ["safety:slow"],
            },
            "dev": {"reporters": ["console"], "tools": ["safety:fast"]},
            "reporters": ["console", "json", "junit", "quality"],
            "tools": ["safety"],
        },
    }
	assert candidate(
) == {
    "safety": {"REQUIREMENTS_FILES": ["default-requirements.txt"]},
    "safety_quick": {"REQUIREMENTS_FILES": ["small-requirements.txt"]},
    "safety_slow": {"REQUIREMENTS_FILES": ["big-requirements.txt"]},
    "scan": {
        "ci": {"reporters": ["console"], "tools": ["safety:slow"]},
        "ci-prod": {
            "reporters": ["console"],
            "safety_slow": {"REQUIREMENTS_FILES": ["prod-big-requirements.txt"]},
            "tools": ["safety:slow"],
        },
        "dev": {"reporters": ["console"], "tools": ["safety:fast"]},
        "reporters": ["console", "json", "junit", "quality"],
        "tools": ["safety"],
    },
}
	assert candidate(
) == {
        "safety": {"REQUIREMENTS_FILES": ["default-requirements.txt"]},
        "safety_quick": {"REQUIREMENTS_FILES": ["small-requirements.txt"]},
        "safety_slow": {"REQUIREMENTS_FILES": ["big-requirements.txt"]},
        "scan": {
            "ci": {"reporters": ["console"], "tools": ["safety:slow"]},
            "ci-prod": {
                "reporters": ["console"],
                "safety_slow": {"REQUIREMENTS_FILES": ["prod-big-requirements.txt"]},
                "tools": ["safety:slow"],
            },
            "dev": {"reporters": ["console"], "tools": ["safety:fast"]},
            "reporters": ["console", "json", "junit", "quality"],
            "tools": ["safety"],
        },
    }
def test_check():
	check(get_expected_python_full_config_object)
