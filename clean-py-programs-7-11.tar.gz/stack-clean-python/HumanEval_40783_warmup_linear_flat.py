def warmup_linear_flat(x, warmup=0.002):
    """ Specifies a triangular learning rate schedule where peak is reached at `warmup`*`t_total`-th (as provided to BertAdam) training step.
     After `t_total`-th training step, learning rate is fixed. """
	### Canonical solution below ###    
    if x < warmup:
        return x/warmup
    return 1.0

### Unit tests below ###
def check(candidate):
	assert candidate(10000, warmup=0.000001) == 1.0
	assert candidate(2.0, 0.002) == 1.0
	assert candidate(10000, 0.1) == 1.0
	assert candidate(100, warmup=0.1) == 1.0
	assert candidate(10000, warmup=0.01) == 1.0
	assert candidate(1.0, 0.002) == 1.0
	assert candidate(1, 1) == 1
	assert candidate(100) == 1
	assert candidate(0, warmup=0.002) == 0
	assert candidate(1.1, 0.1) == 1.0
	assert candidate(0, 0.1) == 0.0
	assert candidate(1, warmup=0.002) == 1.0
	assert candidate(1, 0.1) == 1.0
	assert candidate(10, warmup=0.1) == 1.0
	assert candidate(1, warmup=0.5) == 1.0
	assert candidate(0, warmup=0.1) == 0.0
	assert candidate(1) == 1
	assert candidate(50, 100) == 0.5
	assert candidate(10000, warmup=0.00001) == 1.0
	assert candidate(1000, 0.002) == 1
	assert candidate(2.0) == 1.0
	assert candidate(1.0) == 1.0
	assert candidate(1, 0.5) == 1
	assert candidate(0, 0.1) == 0
	assert candidate(0, warmup=0.002) == 0.0
	assert round(candidate(0.9, warmup=0.1), 3) == 1.0
	assert candidate(100000, 0.1) == 1.0
	assert candidate(2) == 1.0
	assert candidate(1) == 1.0
	assert candidate(0, 0.002) == 0
	assert candidate(10000, warmup=0.1) == 1.0
	assert candidate(0.0) == 0.0
	assert candidate(50000, warmup=0.002) == 1.0
	assert candidate(1.5) == 1.0
	assert candidate(0, warmup=0.1) == 0
	assert candidate(3.0) == 1.0
	assert candidate(1.2, 0.1) == 1.0
	assert candidate(1000, warmup=0.002) == 1.0
	assert candidate(0, 100) == 0
	assert candidate(0.5, 1) == 0.5
	assert candidate(0, 0.002) == 0.0
	assert candidate(100, 100) == 1
	assert candidate(0) == 0
	assert candidate(2.5) == 1.0
	assert candidate(10000, warmup=0.0001) == 1.0
	assert candidate(1, 0.002) == 1
	assert candidate(10, warmup=0.1) == 1
	assert candidate(0.999, 0.002) == 1.0
	assert candidate(10000, warmup=0.001) == 1.0
	assert candidate(1.0, warmup=0.1) == 1.0
	assert candidate(1.0, 0.1) == 1.0
	assert candidate(20, warmup=0.1) == 1
	assert candidate(10000) == 1
	assert candidate(10000, 0.002) == 1
	assert candidate(1.0, warmup=0.002) == 1.0
	assert candidate(0, 0.5) == 0
	assert candidate(0, 1) == 0
	assert candidate(150, 100) == 1
	assert candidate(10) == 1
	assert candidate(5000, 0.002) == 1
def test_check():
	check(warmup_linear_flat)
