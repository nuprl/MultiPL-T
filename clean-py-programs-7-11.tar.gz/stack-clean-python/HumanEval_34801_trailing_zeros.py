def trailing_zeros(bin_num):
    """
    Return the number of trailing zeros of a binary number.
    
    :param bin_num: Binary number
    :type bin_num: str
    """
    ### Canonical solution below ###
    num_trailing_zeros = 0
    for ele in bin_num[::-1]:
        if ele != '0':
            break
        num_trailing_zeros += 1
    return num_trailing_zeros


### Unit tests below ###
def check(candidate):
	assert candidate(bin_num="00000000000000000000000000000001") == 0
	assert candidate(bin_num='11111111111') == 0
	assert candidate(bin_num='00100') == 2
	assert candidate(bin_num='0001000') == 3
	assert candidate(bin_num='0000000') == 7
	assert candidate(bin(0b00010000)) == 4
	assert candidate(bin_num='00000000') == 8
	assert candidate(bin_num='00000000001') == 0
	assert candidate(bin_num='00000000000000000000000000001010') == 1
	assert candidate(bin(12)) == 2
	assert candidate(bin(321)) == 0
	assert candidate(bin_num='1110000') == 4
	assert candidate(bin_num='0001111') == 0
	assert candidate(bin(0b11111111)) == 0
	assert candidate(bin_num='1000000') == 6
	assert candidate(bin(255)) == 0
	assert candidate(bin_num='100100') == 2
def test_check():
	check(trailing_zeros)
