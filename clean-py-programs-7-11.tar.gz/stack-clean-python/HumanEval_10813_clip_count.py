def clip_count(cand_d, ref_ds):
    """ Count the clip count for each ngram considering all references"""
	### Canonical solution below ###    
    count = 0
    for m in list(cand_d.keys()):
        m_w = cand_d[m]
        m_max = 0
        for ref in ref_ds:
            if m in ref:
                m_max = max(m_max, ref[m])
        m_w = min(m_w, m_max)
        count += m_w
    return count

### Unit tests below ###
def check(candidate):
	assert candidate(dict(a=1), [dict(a=2)]) == 1
	assert candidate(dict(a=1, b=2, c=3), [dict(a=3, b=1, c=1), dict(a=2, b=1, c=1)]) == 3
	assert candidate(cand_d={'a': 3, 'b': 4}, ref_ds=[]) == 0
	assert candidate(dict(a=1, b=1), [dict(a=1), dict(b=1)]) == 2
	assert candidate(dict(), []) == 0
	assert candidate(cand_d={'a': 3, 'b': 4}, ref_ds=[{'a': 3, 'b': 5}, {'a': 4, 'b': 4}]) == 7
	assert candidate(dict(a=1, b=2, c=3), [dict(a=3, b=1, c=1), dict(a=2, b=1, c=1), dict(a=3, b=2, c=1)]) == 4
	assert candidate(cand_d = {0: 0, 1: 1, 2: 0, 3: 0, 4: 0}, ref_ds = [
    {0: 0, 1: 1, 2: 0, 3: 0, 4: 0},
    {0: 0, 1: 1, 2: 0, 3: 0, 4: 0},
    {0: 0, 1: 1, 2: 0, 3: 0, 4: 0}
]) == 1
	assert candidate(dict(a=1, b=1), [dict(a=1, b=1)]) == 2
	assert candidate(dict(a=1, b=1), [dict(a=1, b=2)]) == 2
	assert candidate(dict(a=1), [dict(a=1)]) == 1
	assert candidate(dict(), [dict()]) == 0
def test_check():
	check(clip_count)
