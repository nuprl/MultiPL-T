def get_cover_url(video_json):
    """
    parse cover url from video_json
    :param video_json:
    :return:
    """
    ### Canonical solution below ###
    return video_json.get('origin_cover') or video_json.get('cover')


### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        "origin_cover": "http://i2.hdslb.com/bfs/archive/69616c3769b9e0d8a11a566c463185e8f226d21a.jpg",
        "cover": "http://i2.hdslb.com/bfs/archive/69616c3769b9e0d8a11a566c463185e8f226d21a.jpg"
    }
) == "http://i2.hdslb.com/bfs/archive/69616c3769b9e0d8a11a566c463185e8f226d21a.jpg"
	assert candidate(
    {
        "origin_cover": "http://i2.hdslb.com/bfs/archive/69616c3769b9e0d8a11a566c463185e8f226d21a.jpg"
    }
) == "http://i2.hdslb.com/bfs/archive/69616c3769b9e0d8a11a566c463185e8f226d21a.jpg"
	assert candidate({'origin_cover': 'http://test.com/test.jpg'}) == 'http://test.com/test.jpg'
	assert candidate(
    {
        'origin_cover': 'http://xxx.com/xxx.jpg',
        'cover': 'http://yyy.com/yyy.jpg',
    }
) == 'http://xxx.com/xxx.jpg'
	assert candidate({'cover': 'http://test.com/test.jpg'}) == 'http://test.com/test.jpg'
	assert candidate({'origin_cover': 'abc'}) == 'abc'
	assert candidate({'cover': 'def'}) == 'def'
	assert candidate({'origin_cover': 'abc', 'cover': 'def'}) == 'abc'
	assert candidate(
    {
        'cover': 'http://yyy.com/yyy.jpg',
    }
) == 'http://yyy.com/yyy.jpg'
	assert candidate({'cover': None}) is None
	assert candidate({}) is None
	assert candidate({'origin_cover': 'a', 'cover': 'b'}) == 'a'
	assert candidate({}) == None
	assert candidate({'origin_cover': None}) is None
	assert candidate({'origin_cover': 'http://test.com/test.jpg', 'cover': 'http://test.com/test2.jpg'}) == 'http://test.com/test.jpg'
def test_check():
	check(get_cover_url)
