def try_conversion(value):
    """called when encountering a string in the xml
    
    Arguments:
        value {str} -- value to be converted, if possible
    
    Returns:
        [str, float, int] -- converted value
    """
    ### Canonical solution below ###
    try:
        return int(value)
    except (ValueError, TypeError):
        pass
    try:
        return float(value)
    except (ValueError, TypeError):
        pass
    return value


### Unit tests below ###
def check(candidate):
	assert candidate('1.1') == 1.1
	assert candidate('10.000') == 10.0
	assert candidate('100.0g') == '100.0g'
	assert candidate('100.0s') == '100.0s'
	assert candidate('10.1') == 10.1
	assert candidate('100.0n') == '100.0n'
	assert candidate('10.5') == 10.5
	assert candidate('4') == 4
	assert candidate("2.0") == 2.0
	assert candidate('10.00000000000000') == 10.0
	assert candidate('42.0') == 42.0
	assert candidate('100.0p') == '100.0p'
	assert candidate("foo") == "foo"
	assert candidate('foo') == 'foo'
	assert candidate('10.0000000000000000') == 10.0
	assert candidate('10.00000000') == 10.0
	assert candidate('123.45') == 123.45
	assert candidate('100') == 100
	assert candidate('10.000000') == 10.0
	assert candidate("text") == "text"
	assert candidate("5") == 5
	assert candidate('10.0000000000000') == 10.0
	assert candidate('hello') == 'hello'
	assert candidate("10.1") == 10.1
	assert candidate('100.0a') == '100.0a'
	assert candidate("1.0e+1") == 1.0e+1
	assert candidate('10') == 10
	assert candidate(5) == 5
	assert candidate('1.0') == 1.0
	assert candidate('10.00000') == 10.0
	assert candidate("hello") == "hello"
	assert candidate(None) is None
	assert candidate(4) == 4
	assert candidate('42.0000000000000000') == 42.0
	assert candidate(10) == 10
	assert candidate('10.000000000000') == 10.0
	assert candidate("3.14") == 3.14
	assert candidate("5.0000") == 5.0
	assert candidate("a") == "a"
	assert candidate('123.456') == 123.456
	assert candidate(None) == None
	assert candidate('42.0000') == 42.0
	assert candidate('1.5') == 1.5
	assert candidate(10.0) == 10.0
	assert candidate("1") == 1
	assert candidate('123') == 123
	assert candidate(3.0) == 3.0
	assert candidate('42.00000000') == 42.0
	assert candidate(1) == 1
	assert candidate("abc") == "abc"
	assert candidate(2.0) == 2.0
	assert candidate("1.0") == 1.0
	assert candidate('100.0') == 100.0
	assert candidate("10") == 10
	assert candidate("3.0") == 3.0
	assert candidate('42') == 42
	assert candidate("2") == 2
	assert candidate("twenty") == "twenty"
	assert candidate('10.0000000000') == 10.0
	assert candidate('') == ''
	assert candidate(4.0) == 4.0
	assert candidate('10.000000000000000') == 10.0
	assert candidate("10.0") == 10.0
	assert candidate('1.5.6') == '1.5.6'
	assert candidate(42) == 42
	assert candidate('100.0m') == '100.0m'
	assert candidate("3") == 3
	assert candidate('4.2') == 4.2
	assert candidate("1.0e-1") == 1.0e-1
	assert candidate(1.0) == 1.0
	assert candidate(100) == 100
	assert candidate("1.000000000") == 1.0
	assert candidate("5.0") == 5.0
	assert candidate('4.0') == 4.0
	assert candidate(123) == 123
	assert candidate("5,000.0000") == "5,000.0000"
	assert candidate('1') == 1
	assert candidate('abc') == 'abc'
	assert candidate(100.0) == 100.0
	assert candidate('10.00000000000') == 10.0
	assert candidate(2) == 2
	assert candidate('10.0000000') == 10.0
	assert candidate('10.0') == 10.0
	assert candidate('10.000000000') == 10.0
	assert candidate(3) == 3
	assert candidate('a') == 'a'
def test_check():
	check(try_conversion)
