def camel(s):
    """Convert string to CamelCase."""
    ### Canonical solution below ###
    return ''.join(x[0].upper() + x[1:].lower() for x in s.split())


### Unit tests below ###
def check(candidate):
	assert candidate('word123') == 'Word123'
	assert candidate('word!123?') == 'Word!123?'
	assert candidate('Camel Case Word') == 'CamelCaseWord'
	assert candidate('foo') == 'Foo'
	assert candidate(s="__123_") == "__123_"
	assert candidate('already candidate case') == 'AlreadyCamelCase'
	assert candidate('candidate   case word') == 'CamelCaseWord'
	assert candidate(candidate('test')) == 'Test'
	assert candidate('_') == '_'
	assert candidate(s='word') == 'Word'
	assert candidate(s='this') == 'This'
	assert candidate(s='word word word') == 'WordWordWord'
	assert candidate(s='foo_') == 'Foo_'
	assert candidate('   candidate case word') == 'CamelCaseWord'
	assert candidate('number 2word') == 'Number2word'
	assert candidate(s="_") == "_"
	assert candidate('test') == 'Test'
	assert candidate(s='foo') == 'Foo'
	assert candidate('a') == 'A'
	assert candidate(s="_123_") == "_123_"
	assert candidate(s='candidate case') == 'CamelCase'
	assert candidate('test case') == 'TestCase'
	assert candidate('has 2 spaces') == 'Has2Spaces'
	assert candidate('candidate  case word') == 'CamelCaseWord'
	assert candidate('word   ') == 'Word'
	assert candidate('number 2  word') == 'Number2Word'
	assert candidate('foo bar') == 'FooBar'
	assert candidate('candidate case word   ') == 'CamelCaseWord'
	assert candidate(s='this is awesome') == 'ThisIsAwesome'
	assert candidate('candidate case') == 'CamelCase'
	assert candidate('   word   ') == 'Word'
	assert candidate(s="__123") == "__123"
	assert candidate('word') == 'Word'
	assert candidate('   ') == ''
	assert candidate(s="_123") == "_123"
	assert candidate('200') == '200'
	assert candidate(s='') == ''
	assert candidate('candidate case   word') == 'CamelCaseWord'
	assert candidate('') == ''
	assert candidate(s="") == ""
	assert candidate('candidate      case word') == 'CamelCaseWord'
	assert candidate(s='Camel case word') == 'CamelCaseWord'
	assert candidate('word123!') == 'Word123!'
	assert candidate(s='this is awesome and so is this') == 'ThisIsAwesomeAndSoIsThis'
	assert candidate('candidate case word') == 'CamelCaseWord'
	assert candidate(s="__") == "__"
	assert candidate('FOO BAR') == 'FooBar'
	assert candidate(s='w') == 'W'
	assert candidate('word!123') == 'Word!123'
	assert candidate('   word') == 'Word'
	assert candidate(s="__foo__bar__baz__") == "__foo__bar__baz__"
	assert candidate(s='word word') == 'WordWord'
def test_check():
	check(camel)
