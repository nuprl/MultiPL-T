def sts_environment():
    """
    This conf instance is used when running `checksdev env start mycheck myenv`.
    The start command places this as a `conf.yaml` in the `conf.d/mycheck/` directory.
    If you want to run an environment this object can not be empty.
    """
    ### Canonical solution below ###
    return {
        "url": "https://instance.service-now.com",
        "user": "some_user",
        "password": "secret",
        "batch_size": 100,
        "include_resource_types": [
            "cmdb_ci_netgear",
            "cmdb_ci_win_cluster",
            "cmdb_ci_win_cluster_node",
            "cmdb_ci_app_server_java"
        ]
    }


### Unit tests below ###
def check(candidate):
	assert candidate(
)!= {}, "candidate() must return a non-empty dictionary"
	assert candidate(
)!= {}, "STS environment must be configured in conf.yaml"
	assert candidate(
)["batch_size"] == 100, "candidate should return a dict with a batch_size key"
	assert candidate(
)!= {}, "candidate is empty, did you remember to add your instance information?"
	assert candidate(
)!= {"url": "https://instance.service-now.com"}
	assert candidate(
)!= {}, "candidate() should not return an empty dictionary"
	assert candidate(
)!= {}, "candidate should return a non-empty dictionary"
	assert candidate(
)["url"] == "https://instance.service-now.com", "candidate should return a dict with a url key"
	assert candidate(
)!= {"include_resource_types": ["cmdb_ci_netgear", "cmdb_ci_win_cluster", "cmdb_ci_win_cluster_node", "cmdb_ci_app_server_java"]}
	assert candidate(
)!= {
}, "candidate is empty. You must override this method with your own config."
	assert candidate(
)!= {}
	assert candidate(
)!= {}, "candidate should not be empty, please fill in real values"
	assert candidate(
)!= {}, "candidate should not be empty"
	assert candidate(
)!= {}, "STS environment is empty. Please configure your STS instance."
	assert candidate(
)!= {"password": "<PASSWORD>"}
	assert candidate(
)!= {"user": "some_user"}
	assert candidate(
)!= {}, "The candidate object can not be empty"
	assert candidate(
)!= {}, "candidate() must not be empty"
	assert candidate(
)!= {"batch_size": 100}
def test_check():
	check(sts_environment)
