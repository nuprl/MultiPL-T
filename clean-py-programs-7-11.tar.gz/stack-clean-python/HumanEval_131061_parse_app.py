def parse_app(app):
    """

    >>> parse_app(None)
    ''

    >>> parse_app({})
    ''

    >>> parse_app({'name': 'esteem'})
    'esteem'

    >>> parse_app({'version': 2})
    ''

    >>> parse_app({'name': 'esteem', 'version': 2})
    'esteem 2'

    >>> parse_app('esteem 1.1.1')
    'esteem 1.1.1'

    """
    ### Canonical solution below ###

    if app is None:
        return ''

    if isinstance(app, dict):
        if 'name' in app:
            ver = app['version'] if 'version' in app else ''
            return '{} {}'.format(app['name'], ver).strip()
        else:
            return ''

    return str(app)


### Unit tests below ###
def check(candidate):
	assert candidate('esteem 1.1.1') == 'esteem 1.1.1'
	assert candidate({'version': 2}) == ''
	assert candidate({}) == ''
	assert candidate({'name': 'esteem'}) == 'esteem'
	assert candidate(None) == ''
	assert candidate({'name': 'esteem','version': 2}) == 'esteem 2'
def test_check():
	check(parse_app)
