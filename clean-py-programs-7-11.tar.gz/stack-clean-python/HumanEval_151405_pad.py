def pad(tab, val, n):
    """Add a number of values at the end of a list.

    :param list tab: the list to add data in.
    :param int val: the value to add.
    :param int n: the number of values to add.

    :returns: the padded list.

    """
    ### Canonical solution below ###
    for i in range(n):
        tab.append(val)
    return tab


### Unit tests below ###
def check(candidate):
	assert candidate(list(), 2, 3) == [2, 2, 2]
	assert candidate(tab=[1, 2], val=3, n=0) == [1, 2]
	assert candidate(list(), 0, 6) == [0, 0, 0, 0, 0, 0]
	assert candidate([1], 1, 0) == [1]
	assert candidate(tab=[], val=1, n=0) == []
	assert candidate(list(), 5, 2) == [5, 5]
	assert candidate([1], 0, 0) == [1]
	assert candidate([1, 2, 3], 0, 5) == [1, 2, 3, 0, 0, 0, 0, 0]
	assert candidate(list(), 2, 5) == [2, 2, 2, 2, 2]
	assert candidate([1, 2, 3], 0, 2) == [1, 2, 3, 0, 0], "candidate([1, 2, 3], 0, 2) = [1, 2, 3, 0, 0]"
	assert candidate(tab=[0, 0, 0], val=1, n=0) == [0, 0, 0]
	assert candidate(list(), 0, 0) == list(), "candidate(list(), 0, 0) = list()"
	assert candidate(list(), 1, 5) == [1, 1, 1, 1, 1]
	assert candidate(list(), 0, 2) == [0, 0]
	assert candidate([1, 2, 3], 0, 3) == [1, 2, 3, 0, 0, 0]
	assert candidate(tab=[1, 2, 3], val=4, n=1) == [1, 2, 3, 4]
	assert candidate(list(), 1, -10) == []
	assert candidate([1, 2], 3, 2) == [1, 2, 3, 3]
	assert candidate(list(), 1, -2) == list()
	assert candidate(list(), 1, 1) == [1]
	assert candidate(tab=[1, 2, 3], val=4, n=2) == [1, 2, 3, 4, 4]
	assert candidate(list(range(5)), 10, -1) == [0, 1, 2, 3, 4]
	assert candidate(list(), 1, 0) == list()
	assert candidate([1, 2], 3, 0) == [1, 2]
	assert candidate(list(), 1, 2) == [1, 1]
	assert candidate(list(), 0, 4) == [0, 0, 0, 0]
	assert candidate(list(), 0, 3) == [0, 0, 0]
	assert candidate([1, 2, 3], 4, 1) == [1, 2, 3, 4]
	assert candidate(list(), 1, -1) == list()
	assert candidate(tab=[1, 2], val=0, n=3) == [1, 2, 0, 0, 0]
	assert candidate(list(), 0, 8) == [0, 0, 0, 0, 0, 0, 0, 0]
	assert candidate(list(), 0, 0) == list()
	assert candidate(tab=[], val=1, n=1) == [1]
	assert candidate(list(range(5)), 10, -2) == [0, 1, 2, 3, 4]
	assert candidate([1, 2, 3], 0, 2) == [1, 2, 3, 0, 0]
	assert candidate([1, 2, 3], 0, 1) == [1, 2, 3, 0]
	assert candidate(tab=[1, 2, 3], val=4, n=0) == [1, 2, 3]
	assert candidate(list(), 0, 2) == [0, 0], "candidate(list(), 0, 2) = [0, 0]"
	assert candidate(list(), 1, -5) == list()
	assert candidate([1], 1, 1) == [1, 1]
	assert candidate(tab=[1, 2, 3], val=4, n=3) == [1, 2, 3, 4, 4, 4]
	assert candidate([1, 2, 3], 1, 2) == [1, 2, 3, 1, 1]
	assert candidate(tab=[1, 2], val=3, n=2) == [1, 2, 3, 3]
	assert candidate(list(range(10)), 0, 0) == list(range(10))
	assert candidate(list(), 1, 10) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
	assert candidate([1, 2, 3], 0, 0) == [1, 2, 3], "candidate([1, 2, 3], 0, 0) = [1, 2, 3]"
	assert candidate(list(range(5)), 10, 0) == [0, 1, 2, 3, 4]
	assert candidate(list(), 0, 5) == [0, 0, 0, 0, 0]
	assert candidate([1, 2, 3], 5, 2) == [1, 2, 3, 5, 5]
	assert candidate(list(), 0, 5) == [0, 0, 0, 0, 0], "candidate(list(), 0, 5) = [0, 0, 0, 0, 0]"
	assert candidate([1, 2, 3], 1, 0) == [1, 2, 3]
	assert candidate(tab=[1, 2], val=3, n=1) == [1, 2, 3]
	assert candidate([1], 0, 1) == [1, 0]
	assert candidate([1, 2, 3], 0, 1) == [1, 2, 3, 0], "candidate([1, 2, 3], 0, 1) = [1, 2, 3, 0]"
	assert candidate([1, 2, 3], 0, 0) == [1, 2, 3]
	assert candidate(list(), 0, 7) == [0, 0, 0, 0, 0, 0, 0]
	assert candidate(list(range(5)), 10, -3) == [0, 1, 2, 3, 4]
	assert candidate(tab=[1, 2], val=3, n=3) == [1, 2, 3, 3, 3]
	assert candidate(list(), 0, 0) == []
	assert candidate(list(), 1, 0) == []
	assert candidate([1, 2, 3], 1, 1) == [1, 2, 3, 1]
	assert candidate(list(), 0, 1) == [0]
	assert candidate(list(), 1, -10) == list()
	assert candidate([1, 2], 5, 2) == [1, 2, 5, 5]
	assert candidate([1, 2], 3, 1) == [1, 2, 3]
	assert candidate(tab=[], val=1, n=2) == [1, 1]
	assert candidate(list(), 1, 3) == [1, 1, 1]
	assert candidate(list(), 0, 1) == [0], "candidate(list(), 0, 1) = [0]"
	assert candidate(list(range(5)), 10, 5) == [0, 1, 2, 3, 4, 10, 10, 10, 10, 10]
def test_check():
	check(pad)
