def _hround(n: float, r: int = 2) -> float:
    """ Implements half round up."""
	### Canonical solution below ###    
    diff = round((round(n, r+1) - round(n, r)) * 10 ** (r+1))
    if diff >= 5:
        return n + (10 - diff) * 10 ** -(r+1)
    else:
        return round(n, r)

### Unit tests below ###
def check(candidate):
	assert candidate(1.234567, 5) == 1.23457
	assert candidate(0) == 0
	assert candidate(1.2355, 2) == 1.24
	assert candidate(2.5) == 2.5
	assert candidate(0.000000001, -5) == 0.0
	assert candidate(0.000000001, 1) == 0.0
	assert candidate(0.2567, 1) == 0.3
	assert candidate(0.0025, -1) == 0.00
	assert candidate(123.456, 1) == 123.5
	assert candidate(123.456, 2) == 123.46
	assert candidate(2.567, 5) == 2.567
	assert candidate(1234.56789, 7) == 1234.5678900
	assert candidate(2.567, 3) == 2.567
	assert candidate(0.123456789, 2) == 0.12
	assert candidate(0.123456789, 6) == 0.123457
	assert candidate(3.14159, 4) == 3.1416
	assert candidate(4.9) == 4.9
	assert candidate(1.000000001, 1) == 1.0
	assert candidate(1.9) == 1.9
	assert candidate(1.234567, 4) == 1.2346
	assert candidate(1.2355, 3) == 1.236
	assert candidate(1.23456, 6) == 1.23456
	assert candidate(1.56, 1) == 1.6
	assert candidate(1.51, 3) == 1.51
	assert candidate(3.14159, 2) == 3.14
	assert candidate(3.6) == 3.6
	assert candidate(1.234567, 10) == 1.234567
	assert candidate(2.0044449, 6) == 2.004445
	assert candidate(0.123, 1) == 0.1
	assert candidate(0.000000001, -2) == 0.0
	assert candidate(0.9) == 0.9
	assert candidate(4.5) == 4.5
	assert candidate(1.2355) == 1.24
	assert candidate(12.349) == 12.35
	assert candidate(3.5) == 3.5
	assert candidate(1.23456789, 4) == 1.2346
	assert candidate(0.000000001, -3) == 0.0
	assert candidate(123.456789) == 123.46
	assert candidate(123.456789, 3) == 123.457
	assert candidate(0.015) == 0.02
	assert candidate(2.0044, 2) == 2.00
	assert candidate(3.14159, 3) == 3.142
	assert candidate(1.23456, 3) == 1.235
	assert candidate(4.6) == 4.6
	assert candidate(123.456, 4) == 123.4560
	assert candidate(1234.56789, 1) == 1234.6
	assert candidate(0.0025, -2) == 0.0
	assert candidate(123.456, 3) == 123.456
	assert candidate(1.234567, 6) == 1.234567
	assert candidate(0.123, 2) == 0.12
	assert candidate(0.128, 2) == 0.13
	assert candidate(2.005, 2) == 2.01
	assert candidate(0.123456789) == 0.12
	assert candidate(123.456, 5) == 123.45600
	assert candidate(1234.56789, 4) == 1234.5679
	assert candidate(0.011) == 0.01
	assert candidate(1.23456, 10) == 1.23456
	assert candidate(1.23456, 9) == 1.23456
	assert candidate(1.23456, 8) == 1.23456
	assert candidate(0.125, 3) == 0.125
	assert candidate(1.51, 2) == 1.51
	assert candidate(1.234567, 9) == 1.234567
	assert candidate(0.000000001, -1) == 0.0
	assert candidate(123.456789, 7) == 123.456789
	assert candidate(2.555, 2) == 2.56
	assert candidate(1.234567, 3) == 1.235
	assert candidate(1.000000001, 0) == 1.0
	assert candidate(1.234567, 12) == 1.234567
	assert candidate(1.2345) == 1.23
	assert candidate(1.23456, 6) == 1.234560
	assert candidate(12.344) == 12.34
	assert candidate(1.23456, 4) == 1.2346
	assert candidate(0.123, 3) == 0.123
	assert candidate(1.234567, 14) == 1.234567
	assert candidate(0.6) == 0.6
	assert candidate(1.234567, 15) == 1.234567
	assert candidate(2.0044449, 4) == 2.0044
	assert candidate(1234.56789, 3) == 1234.568
	assert candidate(2.0044999, 2) == 2.00
	assert candidate(2.00449, 2) == 2.00
	assert candidate(123.456789, 6) == 123.456789
	assert candidate(1.56, 0) == 2.0
	assert candidate(2.9) == 2.9
	assert candidate(1.23456, 5) == 1.23456
	assert candidate(0.0) == 0
	assert candidate(0.123456789, 5) == 0.12346
	assert candidate(1234.56789, 5) == 1234.56789
	assert candidate(0.128, 1) == 0.1
	assert candidate(0.000000001, -4) == 0.0
	assert candidate(1.23456789, 3) == 1.235
	assert candidate(1234.56789, 2) == 1234.57
	assert candidate(1.234567, 13) == 1.234567
	assert candidate(0.2567, 2) == 0.26
	assert candidate(2.0044449, 2) == 2.00
	assert candidate(1.55, 3) == 1.55
	assert candidate(1.56, 2) == 1.56
	assert candidate(0.002) == 0.0
	assert candidate(1.45, 3) == 1.45
	assert candidate(0.004) == 0.0
	assert candidate(123.456789, 8) == 123.4567890
	assert candidate(3.14159, 5) == 3.14159
	assert candidate(1.23456789, 5) == 1.23457
	assert candidate(1.5) == 1.5
	assert candidate(1.95, 3) == 1.95
	assert candidate(2.554, 2) == 2.55
	assert candidate(2.6) == 2.6
	assert candidate(0.2567, 0) == 0.0
	assert candidate(0.012) == 0.01
	assert candidate(2.0044449, 3) == 2.004
	assert candidate(123.456789, 4) == 123.4568
	assert candidate(1.000000001, 2) == 1.00
	assert candidate(1234.56789, 6) == 1234.567890
	assert candidate(0.005) == 0.01
	assert candidate(3.9) == 3.9
	assert candidate(2.567, 4) == 2.567
	assert candidate(1.234567, 7) == 1.234567
	assert candidate(0.123456789, 4) == 0.1235
	assert candidate(12.345) == 12.35
	assert candidate(1.23456, 7) == 1.23456
	assert candidate(1.234567, 8) == 1.234567
	assert candidate(0.000000001, 2) == 0.00
	assert candidate(2.567, 2) == 2.57
	assert candidate(1.23456789, 6) == 1.234568
	assert candidate(123.456789, 5) == 123.45679
	assert candidate(0.5) == 0.5
	assert candidate(0.000000001, 0) == 0.0
	assert candidate(1.6) == 1.6
	assert candidate(0.001) == 0.0
	assert candidate(0.2567, 3) == 0.257
	assert candidate(0.0025, 0) == 0.0
	assert candidate(1.234567, 11) == 1.234567
def test_check():
	check(_hround)
