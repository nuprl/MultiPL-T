def compact_line(line_dict):
    """Remove unneeded white space from a lexc entry."""
    ### Canonical solution below ###
    string_buffer = []

    if line_dict.get(u'exclam'):
        string_buffer.append(line_dict[u'exclam'])

    if line_dict.get(u'upper'):
        string_buffer.append(line_dict[u'upper'])

    if line_dict.get(u'divisor'):
        string_buffer.append(line_dict[u'divisor'])

    if line_dict.get(u'lower'):
        string_buffer.append(line_dict[u'lower'])

    if string_buffer:
        string_buffer.append(' ')

    string_buffer.append(line_dict[u'contlex'])

    if line_dict.get(u'translation'):
        string_buffer.append(' ')
        string_buffer.append(line_dict[u'translation'])

    string_buffer.append(u' ;')

    if line_dict.get(u'comment'):
        string_buffer.append(u' ')
        string_buffer.append(line_dict[u'comment'])

    return ''.join(string_buffer)


### Unit tests below ###
def check(candidate):
	assert candidate(dict(upper=u'UPPER', divisor=u'/', contlex=u'contlex', translation=u'translation', comment=u'comment')) == u'UPPER/ contlex translation ; comment'
	assert candidate(
    {u'comment': u'',
     u'contlex': u'a',
     u'divisor': u'',
     u'exclam': u'',
     u'lower': u'',
     u'translation': u'c',
     u'upper': u''}) == u'a c ;'
	assert candidate(
    {
        u'exclam': u'!',
        u'upper': u'A',
        u'divisor': u'.',
        u'lower': u'a',
        u'contlex': u'a',
        u'translation': u'',
        u'comment': u'a'
    }
) == u'!A.a a ; a'
	assert candidate(
    {u'exclam': u'', u'upper': u'A', u'divisor': u'/', u'lower': u'a', u'contlex': u'A', u'translation': u'', u'comment': u''}) == u'A/a A ;'
	assert candidate(
    {u'exclam': None, u'upper': None, u'divisor': None, u'lower': None, u'contlex': u'c', u'translation': u'd', u'comment': u'e'}
) == u'c d ; e'
	assert candidate(dict(upper=u'UPPER', divisor=u'/', lower=u'lower', contlex=u'contlex', translation=u'translation', comment=u'comment')) == u'UPPER/lower contlex translation ; comment'
	assert candidate(
        {u'exclam': u'!',
         u'upper': u'A',
         u'divisor': u',',
         u'lower': u'a',
         u'contlex': u'a',
         u'translation': u'',
         u'comment': u'a'}) == u'!A,a a ; a'
	assert candidate(
    {u'comment': u'',
     u'contlex': u'a',
     u'divisor': u'',
     u'exclam': u'!',
     u'lower': u'',
     u'translation': u'',
     u'upper': u''}) == u'! a ;'
	assert candidate(
    {u'exclam': None,
     u'upper': None,
     u'divisor': None,
     u'lower': None,
     u'contlex': u'aa',
     u'translation': None,
     u'comment': None}) == u'aa ;'
	assert candidate(
    {u'exclam': None, u'upper': None, u'divisor': None, u'lower': None, u'contlex': u'c', u'translation': u'd', u'comment': None}
) == u'c d ;'
	assert candidate(dict(contlex=u'a')) == u'a ;'
	assert candidate(
    {u'upper': u'A',
     u'divisor': u'|',
     u'lower': u'a',
     u'contlex': u'b',
     u'translation': u'c',
     u'comment': u'd'}) == u'A|a b c ; d'
	assert candidate(
    {
        u'exclam': u'!',
        u'upper': u'A',
        u'divisor': u'.',
        u'lower': u'a',
        u'contlex': u'a',
        u'translation': u'',
        u'comment': u''
    }
) == u'!A.a a ;'
	assert candidate(dict(upper=u'A', divisor=u'/', lower=u'a', contlex=u'a')) == u'A/a a ;'
	assert candidate(
    {u'comment': u'',
     u'contlex': u'a',
     u'divisor': u'',
     u'exclam': u'',
     u'lower': u'',
     u'translation': u'',
     u'upper': u''}) == u'a ;'
def test_check():
	check(compact_line)
