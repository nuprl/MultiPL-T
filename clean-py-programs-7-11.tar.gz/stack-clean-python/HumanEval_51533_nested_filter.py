def nested_filter(path, filter_, *args, **kwargs):
    """ 
     Creates a nested query for use with nested documents
     
     Keyword arguments such as score_mode and others can be added.
     """
	### Canonical solution below ###    
    nested = {
        "path": path,
        "filter": filter_
    }
    nested.update(kwargs)
    return {
        "nested": nested
    }

### Unit tests below ###
def check(candidate):
	assert candidate(
    "foo",
    {
        "term": {
            "foo.bar": "baz"
        }
    },
    score_mode="avg"
) == {
    "nested": {
        "path": "foo",
        "filter": {
            "term": {
                "foo.bar": "baz"
            }
        },
        "score_mode": "avg"
    }
}
	assert candidate(
    "path",
    {"term": {"name": "Shay"}},
    score_mode="avg"
) == {
    "nested": {
        "path": "path",
        "filter": {
            "term": {"name": "Shay"}
        },
        "score_mode": "avg"
    }
}
	assert candidate(
    'path', {'term': {'field': 'value'}}, score_mode='avg') == {
        'nested': {
            'path': 'path',
            'filter': {'term': {'field': 'value'}},
           'score_mode': 'avg'
        }
    }
	assert candidate(
    "user", {"term": {"user": "kimchy"}}, score_mode="sum") == {
        "nested": {
            "path": "user",
            "filter": {"term": {"user": "kimchy"}},
            "score_mode": "sum"
        }
    }
	assert candidate(
    "path.to.field",
    {"term": {"field": "value"}}
) == {
    "nested": {
        "path": "path.to.field",
        "filter": {
            "term": {"field": "value"}
        }
    }
}
	assert candidate(path="path", filter_={"term": {"field": "value"}}) == \
    {
        "nested": {
            "path": "path",
            "filter": {"term": {"field": "value"}}
        }
    }
	assert candidate(
    "path.to.field",
    {"term": {"user": "kimchy"}}
) == {
    "nested": {
        "path": "path.to.field",
        "filter": {"term": {"user": "kimchy"}}
    }
}
	assert candidate(
    "path.to.field",
    {"term": {"user": "kimchy"}},
    score_mode="avg"
) == {
    "nested": {
        "path": "path.to.field",
        "filter": {"term": {"user": "kimchy"}},
        "score_mode": "avg"
    }
}
	assert candidate(
    "tags",
    {"term": {"tags.name": "blue"}}
) == {
    "nested": {
        "path": "tags",
        "filter": {
            "term": {"tags.name": "blue"}
        }
    }
}
	assert candidate(
    "foo", {"term": {"foo.bar": 1}}, score_mode="sum"
) == {
    "nested": {
        "path": "foo",
        "filter": {"term": {"foo.bar": 1}},
        "score_mode": "sum"
    }
}
	assert candidate(
    "comments",
    {"term": {"comments.author": "shay"}}
) == {
    "nested": {
        "path": "comments",
        "filter": {"term": {"comments.author": "shay"}}
    }
}
	assert candidate(
    "comments",
    {"term": {"comments.author": "Joe"}},
    score_mode="sum"
) == {
    "nested": {
        "path": "comments",
        "filter": {"term": {"comments.author": "Joe"}},
        "score_mode": "sum"
    }
}
	assert candidate(path="path", filter_={"term": {"field": "value"}}, score_mode="avg") == \
    {
        "nested": {
            "path": "path",
            "filter": {"term": {"field": "value"}},
            "score_mode": "avg"
        }
    }
	assert candidate(path='path', filter_={'match_all': {}}, score_mode='avg') == \
    {
        "nested": {
            "path": "path",
            "filter": {"match_all": {}},
            "score_mode": "avg"
        }
    }
	assert candidate(
    "comments",
    {"term": {"comments.author": "kimchy"}},
    score_mode="max"
) == {
    "nested": {
        "path": "comments",
        "filter": {"term": {"comments.author": "kimchy"}},
        "score_mode": "max"
    }
}
	assert candidate(path="foo", filter_={
    "term": {"bar": 1}
}, score_mode="sum") == {
    "nested": {
        "path": "foo",
        "filter": {
            "term": {"bar": 1}
        },
        "score_mode": "sum"
    }
}
	assert candidate(
    "a.b",
    {"match": {"a.b": 5}},
    score_mode="avg"
) == {
    "nested": {
        "path": "a.b",
        "filter": {"match": {"a.b": 5}},
        "score_mode": "avg"
    }
}
	assert candidate(
    "path",
    {"term": {"field": "value"}},
    score_mode="max"
) == {
    "nested": {
        "path": "path",
        "filter": {
            "term": {"field": "value"}
        },
        "score_mode": "max"
    }
}
	assert candidate(
    "comments",
    {"term": {"comments.author": "example"}}
) == {
    "nested": {
        "path": "comments",
        "filter": {"term": {"comments.author": "example"}}
    }
}
	assert candidate('path', {'term': {'field': 'value'}}) == {
    'nested': {
        'path': 'path',
        'filter': {'term': {'field': 'value'}}
    }
}
	assert candidate(
    "path",
    {"match": {"name": "value"}},
    score_mode="sum"
) == {
    "nested": {
        "path": "path",
        "filter": {"match": {"name": "value"}},
        "score_mode": "sum"
    }
}
	assert candidate(
    "path",
    {"match": {"field": "value"}}
) == {
    "nested": {
        "path": "path",
        "filter": {"match": {"field": "value"}}
    }
}
	assert candidate(
    "path",
    {"match": {"name": "value"}}
) == {
    "nested": {
        "path": "path",
        "filter": {"match": {"name": "value"}}
    }
}
	assert candidate(
    'path',
    {
        'term': {
            'field': 5
        }
    },
    score_mode='max'
) == {
    'nested': {
        'path': 'path',
        'filter': {
            'term': {
                'field': 5
            }
        },
       'score_mode':'max'
    }
}
	assert candidate(
    "path.to.field",
    {"term": {"field": "value"}},
    score_mode="sum"
) == {
    "nested": {
        "path": "path.to.field",
        "filter": {
            "term": {"field": "value"}
        },
        "score_mode": "sum"
    }
}
	assert candidate(
    "foo",
    {"term": {"foo.bar": 1}}
) == {"nested": {"path": "foo", "filter": {"term": {"foo.bar": 1}}}}
	assert candidate(
    "path.to.nested.doc", {"term": {"path.to.nested.doc.field": "value"}}) == {
        "nested": {
            "path": "path.to.nested.doc",
            "filter": {"term": {"path.to.nested.doc.field": "value"}}
        }
    }
	assert candidate(
    "path",
    {
        "term": {"field": "value"}
    },
    score_mode="avg"
) == {
    "nested": {
        "path": "path",
        "filter": {
            "term": {"field": "value"}
        },
        "score_mode": "avg"
    }
}
	assert candidate(path='path', filter_={'match_all': {}}) == \
    {
        "nested": {
            "path": "path",
            "filter": {"match_all": {}}
        }
    }
	assert candidate(
    "foo",
    {"term": {"foo.bar": 1}},
    score_mode="avg"
) == {"nested": {"path": "foo", "filter": {"term": {"foo.bar": 1}}, "score_mode": "avg"}}
	assert candidate(path="foo", filter_={
    "term": {"bar": 1}
}) == {
    "nested": {
        "path": "foo",
        "filter": {
            "term": {"bar": 1}
        }
    }
}
	assert candidate(
    "path",
    {"match": {"field": "value"}},
    score_mode="avg"
) == {
    "nested": {
        "path": "path",
        "filter": {"match": {"field": "value"}},
        "score_mode": "avg"
    }
}
	assert candidate(
    "path",
    {"match_all": {}},
    score_mode="avg"
) == {
    "nested": {
        "path": "path",
        "filter": {"match_all": {}},
        "score_mode": "avg"
    }
}
	assert candidate(
    "path",
    {"term": {"name": "Shay"}}
) == {
    "nested": {
        "path": "path",
        "filter": {
            "term": {"name": "Shay"}
        }
    }
}
	assert candidate(
    "path",
    {"term": {"field": "value"}},
    score_mode="avg"
) == {
    "nested": {
        "path": "path",
        "filter": {"term": {"field": "value"}},
        "score_mode": "avg"
    }
}
	assert candidate(path="foo", filter_={
    "term": {"bar": 1}
}, score_mode="max") == {
    "nested": {
        "path": "foo",
        "filter": {
            "term": {"bar": 1}
        },
        "score_mode": "max"
    }
}
	assert candidate(
    "comments",
    {"term": {"comments.author": "example"}},
    score_mode="avg"
) == {
    "nested": {
        "path": "comments",
        "filter": {"term": {"comments.author": "example"}},
        "score_mode": "avg"
    }
}
	assert candidate(
    "path",
    {"term": {"field": "value"}}
) == {
    "nested": {
        "path": "path",
        "filter": {
            "term": {"field": "value"}
        }
    }
}
def test_check():
	check(nested_filter)
