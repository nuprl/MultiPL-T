def check_guess(life_point, input_guess, current_guess):
    """ 
     Checking the new guess alphabet can be found in latest guess or not, and reduce 1 point if its not.
     :param life_point: int, the current number of guess left.
     :param input_guess: str, the new guess alphabet input.
     :param current_guess: str, the replaced hint of latest guess.
     :return: the latest number of guess left.
     """
	### Canonical solution below ###    
    if current_guess.find(input_guess) != -1:
        print("You are correct!")
        return life_point
    print("There is no " + input_guess + "'s in the word.")
    return life_point - 1

### Unit tests below ###
def check(candidate):
	assert candidate(3, 'a', 'a_a_') == 3
	assert candidate(10, "a", "r") == 9
	assert candidate(3, 'a', 'e') == 2
	assert candidate(5, 'r', 'a') == 4
	assert candidate(5, 'g', 'a') == 4
	assert candidate(10, "a", "n") == 9
	assert candidate(5, 'a', 'ab') == 5
	assert candidate(5, 'c', 'a') == 4
	assert candidate(3, 'o', 'o') == 3
	assert candidate(10, "a", "l") == 9
	assert candidate(3, 'l', 'a') == 2
	assert candidate(5, "b", "a") == 4
	assert candidate(2, "a", "_a") == 2
	assert candidate(10, "a", "m") == 9
	assert candidate(10, "a", "e") == 9
	assert candidate(10, "a", "f") == 9
	assert candidate(10, "a", "i") == 9
	assert candidate(3,'m', 'a') == 2
	assert candidate(3, 'a', 'o') == 2
	assert candidate(1, "a", "_a") == 1
	assert candidate(5, 'l', 'a') == 4
	assert candidate(3, 'u', 'e') == 2
	assert candidate(4, "a", "a") == 4
	assert candidate(2, 'b', 'a_a_') == 1
	assert candidate(5, 'q', 'a') == 4
	assert candidate(2, 'e', 'ee') == 2
	assert candidate(4, "b", "b") == 4
	assert candidate(3, 'e', 'f') == 2
	assert candidate(5, "a", "e_e_e_e_") == 4
	assert candidate(2, "b", "a") == 1
	assert candidate(3, "b", "b") == 3
	assert candidate(10, "a", "t") == 9
	assert candidate(10, "a", "k") == 9
	assert candidate(5, "a", "b") == 4
	assert candidate(5,'s', 'a') == 4
	assert candidate(5, 't', 'a') == 4
	assert candidate(3, 'c', 'a') == 2
	assert candidate(1, 'e', 'e') == 1
	assert candidate(3, 'y', 'y') == 3
	assert candidate(5, 'f', 'a') == 4
	assert candidate(1, 'c', 'a_b_c_d') == 1
	assert candidate(5, 'b', 'h_e_r_e') == 4
	assert candidate(10, "a", "b") == 9
	assert candidate(3, 'i', 'u') == 2
	assert candidate(3, 'o', 'u') == 2
	assert candidate(5, "e", "_a_") == 4
	assert candidate(10, "a", "q") == 9
	assert candidate(1, "a", "_ _") == 0
	assert candidate(3, 'b', 'a') == 2
	assert candidate(2, 'e', 'b') == 1
	assert candidate(5, 'w', 'a') == 4
	assert candidate(10, "a", "c") == 9
	assert candidate(10, "e", "a") == 9
	assert candidate(3, 'u', 'q') == 2
	assert candidate(3, 'i', 'j') == 2
	assert candidate(5, 'c', 'h_e_r_e') == 4
	assert candidate(3, 'h', 'a') == 2
	assert candidate(3, "a", "b") == 2
	assert candidate(0, 'e', 'e______') == 0
	assert candidate(3, 'a', 'a') == 3
	assert candidate(3, "a", "_ _") == 2
	assert candidate(5, 'v', 'a') == 4
	assert candidate(5, "a", "a") == 5
	assert candidate(2, 'z', 'a') == 1
	assert candidate(10, "a", "d") == 9
	assert candidate(4, "a", "_a") == 4
	assert candidate(5, 'a', 'a') == 5
	assert candidate(10, "a", "o") == 9
	assert candidate(5, 'z', 'h_e_r_e') == 4
	assert candidate(4, "c", "ab") == 3
	assert candidate(2, 'b', 'a') == 1
	assert candidate(5, "u", "____") == 4
	assert candidate(3, "a", "abc") == 3
	assert candidate(3, 'e', 'o') == 2
	assert candidate(3, 'i', 'a') == 2
	assert candidate(5, 'x', 'h_e_r_e') == 4
	assert candidate(5, 'o', 'a') == 4
	assert candidate(5, 'p', 'a') == 4
	assert candidate(1, 'a', '_a__') == 1
	assert candidate(3, 'f', 'a') == 2
	assert candidate(5, 'k', 'a') == 4
	assert candidate(5, 'b', 'a') == 4
	assert candidate(1, "b", "a") == 0, "Second"
	assert candidate(3, 'o', 'a') == 2
	assert candidate(3, 'p', 'a') == 2
	assert candidate(1, 'e', 'a_b_c_d') == 0
	assert candidate(5, 'h', 'a') == 4
	assert candidate(1, 'z', 'a') == 0
	assert candidate(3, 'k', 'a') == 2
	assert candidate(3, 'j', 'a') == 2
	assert candidate(5, 'e', 'a') == 4
	assert candidate(5, 'e', 'e______') == 5
	assert candidate(3, "a", "abcd") == 3
	assert candidate(10, "a", "s") == 9
	assert candidate(2, 'a', 'a') == 2
	assert candidate(10, "a", "a") == 10
	assert candidate(5, 'a', 'b') == 4
	assert candidate(4, "b", "a") == 3
	assert candidate(1, 'b', '_a__') == 0
	assert candidate(5, "e", "e_e_e_e_") == 5
	assert candidate(5, 'j', 'a') == 4
	assert candidate(5, "a", "_a_") == 5
	assert candidate(5, 'i', 'a') == 4
	assert candidate(3, 'g', 'a') == 2
	assert candidate(1, "a", "a") == 1
	assert candidate(5, 'u', 'a') == 4
	assert candidate(5, 'x', 'e______') == 4
	assert candidate(10, "a", "h") == 9
	assert candidate(3, 'a', 'b') == 2
	assert candidate(3, 'o', 'p') == 2
	assert candidate(4, "a", "ab") == 4
	assert candidate(3, 'i', 'o') == 2
	assert candidate(3, "b", "a") == 2
	assert candidate(2, 'e', 'e') == 2
	assert candidate(2, "a", "a") == 2
	assert candidate(3, 'e', 'i') == 2
	assert candidate(3, 'o', 'e') == 2
	assert candidate(3, 'u', 'u') == 3
	assert candidate(1, "a", "a") == 1, "First"
	assert candidate(5, 'a', 'e______') == 4
	assert candidate(3, 'n', 'a') == 2
	assert candidate(10, "e", "e") == 10
	assert candidate(3, "a", "a") == 3
	assert candidate(10, "a", "g") == 9
	assert candidate(5, "t", "_a_") == 4
	assert candidate(5, 'n', 'a') == 4
	assert candidate(3, 'i', 'i') == 3
	assert candidate(3, "a", "_a") == 3
	assert candidate(3, "a", "ab") == 3
	assert candidate(10, "a", "p") == 9
	assert candidate(5, 'y', 'h_e_r_e') == 4
	assert candidate(2, 'c', 'a') == 1
	assert candidate(1, 'a', 'e') == 0
	assert candidate(3, 'a', 'i') == 2
	assert candidate(10, "a", "j") == 9
	assert candidate(2, "a", "_ _") == 1
	assert candidate(3, 'e', 'e') == 3
	assert candidate(5, 'd', 'a') == 4
	assert candidate(3, "A", "A__") == 3
	assert candidate(3, 'd', 'a') == 2
	assert candidate(5,'m', 'a') == 4
	assert candidate(3, 'e', 'u') == 2
def test_check():
	check(check_guess)
