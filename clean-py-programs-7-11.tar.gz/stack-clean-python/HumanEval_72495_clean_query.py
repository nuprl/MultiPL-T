def clean_query(this_object):
    """ clean_query: remove `_version_` key"""
	### Canonical solution below ###    
    this_object.pop('_version_', None)
    return this_object

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'_version_': 1, 'query': {'match_all': {}}, 'extra': 42}
) == {'query': {'match_all': {}}, 'extra': 42}
	assert candidate(
    {'_version_': 1,
     'query': {
         'bool': {
            'must': [
                 {'match': {'name': 'Mary'}}
             ]
         }
     }
    }
) == {
    'query': {
        'bool': {
           'must': [
                {'match': {'name': 'Mary'}}
            ]
        }
    }
}
	assert candidate(
    {'_version_': '1.0', 'a': {'b': {'c': 1}, 'd': 2}}) == \
    {'a': {'b': {'c': 1}, 'd': 2}}
	assert candidate(
    {'_version_': 1, 'foo': 'bar', 'baz': 'qux'}
) == {'foo': 'bar', 'baz': 'qux'}
	assert candidate(dict(a=1, b=2)) == dict(a=1, b=2)
	assert candidate(
    {
        'query': {
           'match_all': {}
        },
        '_version_': 1,
        '_index': 'index1'
    }
) == {
    'query': {
       'match_all': {}
    },
    '_index': 'index1'
}
	assert candidate(dict(_version_=1, foo=1)) == dict(foo=1)
	assert candidate(dict(a=1, b=2, _version_=2)) == dict(a=1, b=2)
	assert candidate(
    {'_version_': '1', 'query': 'query', 'filters': 'filters','size': 100}) == {
        'query': 'query', 'filters': 'filters','size': 100}
	assert candidate( {'a':1, '_version_':1, 'b':2} ) == {'a':1, 'b':2}
	assert candidate(
    {'_version_': '1.1', 'query': {'match': {'name': 'Manny'}}}
) == {'query': {'match': {'name': 'Manny'}}}
	assert candidate(
    {
        'name': 'foo',
        '_version_': 2
    }
) == {
    'name': 'foo',
}
	assert candidate(dict(a=1, _version_='abc')) == dict(a=1)
	assert candidate(dict(a=1, _version_=1, b=1)) == dict(a=1, b=1)
	assert candidate(
    {"query": {"match_all": {}}, "_version_": 123}
) == {"query": {"match_all": {}}}
	assert candidate(dict(a=1, _version_=1, b=2)) == dict(a=1, b=2)
	assert candidate(
    {'_version_': 1,
     'query': {'match': {'title': 'python'}}}) == {'query': {'match': {'title': 'python'}}}
	assert candidate(
    {'query': {'match': {'name': 'Manny'}}, '_version_': '1.1'}
) == {'query': {'match': {'name': 'Manny'}}}
	assert candidate(dict(a=1)) == dict(a=1)
	assert candidate(dict(_version_=1)) == {}
	assert candidate(
    {'_version_': 1, 'query': {'match_all': {}}}
) == {'query': {'match_all': {}}}
	assert candidate(
    {
        'query': {
           'match_all': {}
        },
        '_version_': 1
    }
) == {
    'query': {
       'match_all': {}
    }
}
	assert candidate(dict(_version_=1, a=1)) == dict(a=1)
	assert candidate(
    {'_version_': 1, 'query': {'match_all': {}},'size': 10000}
) == {'query': {'match_all': {}},'size': 10000}
	assert candidate(dict(foo=1)) == dict(foo=1)
	assert candidate(
    {'query': {'match': {'name': 'Manny'}}, 'from': 0, '_version_': '1.1'}
) == {'query': {'match': {'name': 'Manny'}}, 'from': 0}
	assert candidate(
    {'a': 1, '_version_': 1}
) == {'a': 1}
	assert candidate(
    {
        'query': {
           'match_all': {}
        },
        '_version_': 1,
        '_index': 'index1',
        '_source': True
    }
) == {
    'query': {
       'match_all': {}
    },
    '_index': 'index1',
    '_source': True
}
	assert candidate(
    {
        '_version_': 1,
        'query': {
            'filtered': {
                'query': {
                   'match': {
                        'name':'shoe'
                    }
                }
            }
        }
    }
) == {
    'query': {
        'filtered': {
            'query': {
               'match': {
                    'name':'shoe'
                }
            }
        }
    }
}
	assert candidate(
    {
        'query': {
           'match_all': {}
        },
       'size': 10,
        '_version_': 1
    }
) == {
    'query': {
       'match_all': {}
    },
   'size': 10
}
	assert candidate(dict(a=1, b=2, _version_=1, c=3)) == dict(a=1, b=2, c=3)
	assert candidate( {'a':1, 'b':2} ) == {'a':1, 'b':2}
	assert candidate(dict(a=1, b=2, _version_=1, _id=1)) == dict(a=1, b=2, _id=1)
	assert candidate(dict(_version_=1)) == dict()
	assert candidate(
    {'_version_': 1, 'foo': 'bar'}) == {'foo': 'bar'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, '_version_': 1}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate( {'a':1, '_version_':1} ) == {'a':1}
	assert candidate(
    {
        'query': {
           'match_all': {}
        },
        '_version_': 1,
        '_index': 'index1',
        '_source': True,
        'from': 10
    }
) == {
    'query': {
       'match_all': {}
    },
    '_index': 'index1',
    '_source': True,
    'from': 10
}
	assert candidate(
    {
        '_version_': 1,
        'query': {
           'match_all': {}
        }
    }
) == {
    'query': {
       'match_all': {}
    }
}
	assert candidate(dict(a=1, b=2, _version_='2')) == dict(a=1, b=2)
	assert candidate(dict(a=1, b=2, _version_=1)) == dict(a=1, b=2)
	assert candidate(dict(a=1, _version_=1)) == dict(a=1)
def test_check():
	check(clean_query)
