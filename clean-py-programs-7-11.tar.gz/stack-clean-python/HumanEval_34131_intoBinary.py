def intoBinary(num):
    """ 
     bin() function converts decimal to binary but does not return value in 8 
     bits. So we need to add the remaining zeros in order to make it 8 bits, for
     which the 'switcher' dictionary is created. For instance if bin() returns 
     3 bits data, remaining 5 zeros are concatenated.
     
     Input:
     'num' as integer.
     
     Returns:
     Corresponding binary value of 'num'
     """
	### Canonical solution below ###	
	val = bin(num).replace('0b', "") 
	switcher = {
		1:"0000000",
		2:"000000",
		3:"00000",
		4:"0000",
		5:"000",
		6:"00",
		7:"0",
		8:""
	}
	#returns either number of zeros as per length or the value itself
	if len(val) > 8:
		final_value = val
	else:
		final_value = switcher.get(len(val), val)+val
		print("Binary value of {}: ".format(num),final_value)
	return final_value

### Unit tests below ###
def check(candidate):
	assert candidate(21) == "00010101"
	assert candidate(6) == "00000110", "6 should be 00000110"
	assert candidate(10) == '00001010'
	assert candidate(9) == '00001001'
	assert candidate(22) == "00010110"
	assert candidate(100) == "01100100"
	assert candidate(7) == "00000111"
	assert candidate(0) == "00000000"
	assert candidate(14) == '00001110', 'Binary value of 14 is incorrect'
	assert candidate(11) == "00001011"
	assert candidate(200) == "11001000", "200 should be 11001000"
	assert candidate(14) == '00001110'
	assert candidate(7) == '00000111', "Binary of 7 is incorrect"
	assert candidate(14) == "00001110"
	assert candidate(12) == "00001100"
	assert candidate(11) == '00001011'
	assert candidate(3) == '00000011', 'Binary value of 3 is incorrect'
	assert candidate(16) == '00010000', 'Binary value of 16 is incorrect'
	assert candidate(18) == '00010010', 'Binary value of 18 is incorrect'
	assert candidate(4) == '00000100'
	assert candidate(5) == '00000101', "Binary of 5 is incorrect"
	assert candidate(6) == "00000110"
	assert candidate(15) == '00001111', "Binary of 15 is incorrect"
	assert candidate(10) == "00001010", "10 should be 00001010"
	assert candidate(8) == "00001000", "8 should be 00001000"
	assert candidate(12) == '00001100', 'Binary value of 12 is incorrect'
	assert candidate(7) == '00000111'
	assert candidate(1) == "00000001"
	assert candidate(20) == "00010100"
	assert candidate(6) == '00000110', "Binary of 6 is incorrect"
	assert candidate(13) == "00001101"
	assert candidate(2) == "00000010"
	assert candidate(200) == "11001000"
	assert candidate(17) == '00010001'
	assert candidate(21) == '00010101'
	assert candidate(4) == '00000100', "Binary of 4 is incorrect"
	assert candidate(1000) == "1111101000"
	assert candidate(4) == "00000100"
	assert candidate(20) == '00010100'
	assert candidate(4) == "00000100", "4 should be 00000100"
	assert candidate(6) == '00000110'
	assert candidate(5) == '00000101'
	assert candidate(10) == "00001010"
	assert candidate(3) == "00000011", "3 should be 00000011"
	assert candidate(24) == '00011000', 'Binary value of 24 is incorrect'
	assert candidate(1) == '00000001'
	assert candidate(8) == '00001000', "Binary of 8 is incorrect"
	assert candidate(3) == "00000011"
	assert candidate(19) == "00010011"
	assert candidate(3) == '00000011', "Binary of 3 is incorrect"
	assert candidate(15) == '00001111'
	assert candidate(13) == '00001101', "Binary of 13 is incorrect"
	assert candidate(5) == "00000101"
	assert candidate(5) == '00000101', 'Binary value of 5 is incorrect'
	assert candidate(1001) == "1111101001"
	assert candidate(17) == "00010001"
	assert candidate(5) == "00000101", "5 should be 00000101"
	assert candidate(8) == '00001000', 'Binary value of 8 is incorrect'
	assert candidate(15) == '00001111', 'Binary value of 15 is incorrect'
	assert candidate(8) == '00001000'
	assert candidate(20) == '00010100', 'Binary value of 20 is incorrect'
	assert candidate(16) == '00010000'
	assert candidate(2) == "00000010", "2 should be 00000010"
	assert candidate(12) == '00001100', "Binary of 12 is incorrect"
	assert candidate(10) == '00001010', 'Binary value of 10 is incorrect'
	assert candidate(0) == "00000000", "0 should be 00000000"
	assert candidate(9) == "00001001"
	assert candidate(22) == '00010110', 'Binary value of 22 is incorrect'
	assert candidate(9) == "00001001", "9 should be 00001001"
	assert candidate(3) == '00000011'
	assert candidate(12) == '00001100'
	assert candidate(18) == "00010010"
	assert candidate(11) == '00001011', "Binary of 11 is incorrect"
	assert candidate(1) == "00000001", "1 should be 00000001"
	assert candidate(0) == '00000000'
	assert candidate(101) == "01100101"
	assert candidate(15) == "00001111"
	assert candidate(19) == '00010011'
	assert candidate(255) == "11111111"
	assert candidate(8) == "00001000"
	assert candidate(9) == '00001001', "Binary of 9 is incorrect"
	assert candidate(14) == '00001110', "Binary of 14 is incorrect"
	assert candidate(16) == "00010000"
	assert candidate(2) == '00000010', "Binary of 2 is incorrect"
	assert candidate(2) == '00000010'
	assert candidate(7) == '00000111', 'Binary value of 7 is incorrect'
	assert candidate(1) == '00000001', "Binary of 1 is incorrect"
	assert candidate(13) == '00001101'
	assert candidate(11) == "00001011", "11 should be 00001011"
	assert candidate(10) == '00001010', "Binary of 10 is incorrect"
	assert candidate(1) == '00000001', 'Binary value of 1 is incorrect'
	assert candidate(18) == '00010010'
	assert candidate(7) == "00000111", "7 should be 00000111"
def test_check():
	check(intoBinary)
