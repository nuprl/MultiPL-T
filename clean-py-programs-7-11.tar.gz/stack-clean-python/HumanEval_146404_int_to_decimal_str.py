def int_to_decimal_str(integer):
    """
    Helper to convert integers (representing cents) into decimal currency
    string. WARNING: DO NOT TRY TO DO THIS BY DIVISION, FLOATING POINT
    ERRORS ARE NO FUN IN FINANCIAL SYSTEMS.
    @param integer The amount in cents
    @return string The amount in currency with full stop decimal separator
    """
    ### Canonical solution below ###
    int_string = str(integer)
    if len(int_string) < 2:
        return "0." + int_string.zfill(2)
    else:
        return int_string[:-2] + "." + int_string[-2:]


### Unit tests below ###
def check(candidate):
	assert candidate(123456789012) == "1234567890.12"
	assert candidate(123456789) == "1234567.89"
	assert candidate(10000000) == '100000.00'
	assert candidate(1234567890) == "12345678.90"
	assert candidate(10000) == "100.00"
	assert candidate(12345678) == "123456.78"
	assert candidate(100000000000) == "1000000000.00"
	assert candidate(100) == '1.00'
	assert candidate(1234567890123) == "12345678901.23"
	assert candidate(12345) == "123.45"
	assert candidate(100000000) == "1000000.00"
	assert candidate(1000000000000) == "10000000000.00"
	assert candidate(1001) == "10.01"
	assert candidate(100) == "1.00"
	assert candidate(123456) == "1234.56"
	assert candidate(1234567) == "12345.67"
	assert candidate(1) == '0.01'
	assert candidate(101) == "1.01"
	assert candidate(0) == '0.00'
	assert candidate(100000) == "1000.00"
	assert candidate(12345678901) == "123456789.01"
	assert candidate(100000000) == '1000000.00'
	assert candidate(100001) == "1000.01"
	assert candidate(10000) == '100.00'
	assert candidate(1000001) == "10000.01"
	assert candidate(1000) == "10.00"
	assert candidate(100000) == '1000.00'
	assert candidate(1000000) == "10000.00"
	assert candidate(10000001) == "100000.01"
	assert candidate(1) == "0.01"
	assert candidate(10000000) == "100000.00"
	assert candidate(123) == "1.23"
	assert candidate(1000000) == '10000.00'
	assert candidate(10000000000) == '100000000.00'
	assert candidate(1000000000) == "10000000.00"
	assert candidate(10001) == "100.01"
	assert candidate(1000) == '10.00'
	assert candidate(1234) == "12.34"
	assert candidate(10000000000) == "100000000.00"
	assert candidate(999999) == "9999.99"
	assert candidate(1000000000) == '10000000.00'
	assert candidate(0) == "0.00"
def test_check():
	check(int_to_decimal_str)
