def number_of_frames_is_int(input):
    """
    Validate Number of Frame input.
    """
    ### Canonical solution below ###
    try:
        int(input)
        return True
    except ValueError:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate("5") is True
	assert candidate("100.1") == False
	assert candidate(123) is True
	assert candidate(1000000000) == True
	assert candidate(1)
	assert candidate('abc') is False
	assert candidate(0) is True
	assert candidate("3.0") == False
	assert candidate('10 10') == False
	assert candidate('1010') == True
	assert candidate('10.5') == False
	assert candidate(100000000000) == True
	assert candidate('10,10,10') == False
	assert candidate('abc') == False
	assert not candidate("3.14159")
	assert not candidate("1,000")
	assert candidate(123) == True
	assert not candidate('None')
	assert candidate("five") is False
	assert candidate(3) == True
	assert candidate(10000000) == True
	assert candidate('1.0') == False
	assert not candidate("1.2")
	assert candidate(10000000000000) == True
	assert candidate(1000000000000) == True
	assert candidate("5.0") == False
	assert candidate("a") == False
	assert candidate('10,5') == False
	assert candidate(5)
	assert candidate(1000) == True
	assert candidate(10)
	assert candidate("100.0") == False
	assert candidate(100000) == True
	assert candidate("none") == False
	assert candidate('3')
	assert candidate(100) == True
	assert not candidate("a")
	assert candidate(0) == True
	assert candidate("Hello") == False
	assert candidate('10,10') == False
	assert candidate(10000000000) == True
	assert candidate('32.0') == False
	assert candidate('cat') == False
	assert candidate("") == False
	assert candidate("10.1") == False
	assert candidate('1') == True
	assert candidate(10) is True
	assert candidate(1000000) == True
	assert candidate('123') is True
	assert candidate('a') == False
	assert candidate('12a') == False
	assert candidate(5) == True
	assert candidate(3)
	assert candidate(10000000000000000) == True
	assert candidate(100000000) == True
	assert candidate('10\n10') == False
	assert candidate(1) == True
	assert candidate(32) == True
	assert candidate("3a") == False
	assert candidate("10.0") == False
	assert candidate('32') == True
	assert candidate("10") == True
	assert not candidate("five")
	assert candidate('10abc') == False
	assert candidate('abc10') == False
	assert candidate("a3") == False
	assert candidate(100)
	assert not candidate('a')
	assert candidate("None") == False
	assert candidate("-100.0") == False
	assert candidate(10) == True
	assert candidate(1000000000000000) == True
	assert candidate('10\t10') == False
	assert not candidate("")
	assert candidate('12.3') == False
	assert candidate('10.0') == False
	assert candidate(100000000000000) == True
	assert candidate("ten") == False
	assert candidate(10000) == True
def test_check():
	check(number_of_frames_is_int)
