def run_plugin_action(path, block=False):
    """ Create an action that can be run with xbmc.executebuiltin in order
     to run a Kodi plugin specified by path. If block is True (default=False),
     the execution of code will block until the called plugin has finished
     running."""
	### Canonical solution below ###    
    return 'XBMC.RunPlugin({}, {})'.format(path, block)

### Unit tests below ###
def check(candidate):
	assert candidate('') == 'XBMC.RunPlugin(, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ') == 'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ, False)'
	assert candidate('plugin://plugin.video.plexodus', True) == 'XBMC.RunPlugin(plugin://plugin.video.plexodus, True)'
	assert candidate(path='plugin://plugin.video.example/?action=play', block=True) == 'XBMC.RunPlugin(plugin://plugin.video.example/?action=play, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=0B1s9r75D54F0Z3FYZl90dU94azA', True) == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=0B1s9r75D54F0Z3FYZl90dU94azA, True)'
	assert candidate(
    'plugin://plugin.video.youtube/playlist/PL6580D5514C3D0A65', block=True) == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/playlist/PL6580D5514C3D0A65, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=1234567') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=1234567, False)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=1234567', block=True) == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=1234567, True)'
	assert candidate(
    'plugin://plugin.video.example/?param=value') == \
    'XBMC.RunPlugin(plugin://plugin.video.example/?param=value, False)'
	assert candidate(None) == 'XBMC.RunPlugin(None, False)'
	assert candidate(
    'plugin://plugin.video.plexodusplayer/play/8521',
    True) == 'XBMC.RunPlugin(plugin://plugin.video.plexodusplayer/play/8521, True)'
	assert candidate(
    'plugin://plugin.video.example/?mode=123&foo=bar',
    block=True
) == 'XBMC.RunPlugin(plugin://plugin.video.example/?mode=123&foo=bar, True)'
	assert candidate(
    'plugin://plugin.video.example/?param=value', True) == \
    'XBMC.RunPlugin(plugin://plugin.video.example/?param=value, True)'
	assert candidate(
    '/path/to/plugin.py', True) == 'XBMC.RunPlugin(/path/to/plugin.py, True)'
	assert candidate(path='plugin://plugin.video.example/?action=play') == 'XBMC.RunPlugin(plugin://plugin.video.example/?action=play, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=aaaaaaaaa', block=True) == 'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=aaaaaaaaa, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=28596597',
    True) == 'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=28596597, True)'
	assert candidate(
    'plugin://plugin.video.youtube/playlist/PLi_s9u287nLsoIP1A94y57rMK1_H69_qX',
    True
) == 'XBMC.RunPlugin(plugin://plugin.video.youtube/playlist/PLi_s9u287nLsoIP1A94y57rMK1_H69_qX, True)'
	assert candidate(
    '/path/to/plugin.py', False) == 'XBMC.RunPlugin(/path/to/plugin.py, False)'
	assert candidate(
    'plugin://plugin.video.youtube/playlist/PL6580D5514C3D0A65') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/playlist/PL6580D5514C3D0A65, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=lG5h-i2_35I') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=lG5h-i2_35I, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=YOUTUBE_ID', block=True) == 'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=YOUTUBE_ID, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ, False)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=28596597') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=28596597, False)'
	assert candidate(
    'plugin://plugin.video.plexodusplayer/play/8521') == \
    'XBMC.RunPlugin(plugin://plugin.video.plexodusplayer/play/8521, False)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=Z0UISCEe5-U') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=Z0UISCEe5-U, False)'
	assert candidate(path='/path/to/plugin.py', block=True) == 'XBMC.RunPlugin(/path/to/plugin.py, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=123456',
    block=True) == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=123456, True)'
	assert candidate(
    'plugin://plugin.video.youtube/playlist/PLi_s9u287nLsoIP1A94y57rMK1_H69_qX'
) == 'XBMC.RunPlugin(plugin://plugin.video.youtube/playlist/PLi_s9u287nLsoIP1A94y57rMK1_H69_qX, False)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=123456') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=123456, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ', block=True) == 'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ, True)'
	assert candidate('plugin://plugin.video.plexodus') == 'XBMC.RunPlugin(plugin://plugin.video.plexodus, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=aaaaaaaaa') == 'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=aaaaaaaaa, False)'
	assert candidate(
    'plugin://plugin.video.example/?mode=123&foo=bar',
    block=False
) == 'XBMC.RunPlugin(plugin://plugin.video.example/?mode=123&foo=bar, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=lG5h-i2_35I', block=True) == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=lG5h-i2_35I, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=Z0UISCEe5-U', True) == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=Z0UISCEe5-U, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ', True) == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ, True)'
	assert candidate(
    'plugin://plugin.video.youtube/play/?video_id=0B1s9r75D54F0Z3FYZl90dU94azA') == \
    'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=0B1s9r75D54F0Z3FYZl90dU94azA, False)'
	assert candidate(path='plugin://plugin.video.youtube/play/?video_id=YOUTUBE_ID') == 'XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=YOUTUBE_ID, False)'
	assert candidate(path='/path/to/plugin.py', block=False) == 'XBMC.RunPlugin(/path/to/plugin.py, False)'
	assert candidate(path='/test/path', block=True) == 'XBMC.RunPlugin(/test/path, True)'
	assert candidate(path='/test/path') == 'XBMC.RunPlugin(/test/path, False)'
	assert candidate(path='/path/to/plugin.py') == 'XBMC.RunPlugin(/path/to/plugin.py, False)'
	assert candidate(
    path='plugin://plugin.video.example/?param1=1&param2=2',
    block=True) == \
    'XBMC.RunPlugin(plugin://plugin.video.example/?param1=1&param2=2, True)'
def test_check():
	check(run_plugin_action)
