def set_id(bibtex_entry, ID):
    """Given a (string) BibTeX entry, replace its identifier with @ID.
    """
    ### Canonical solution below ###
    first_bracket = bibtex_entry.index("{") + 1
    first_comma = bibtex_entry.index(",")
    return bibtex_entry[:first_bracket] + ID + bibtex_entry[first_comma:]


### Unit tests below ###
def check(candidate):
	assert candidate(
    "@article{key, author = {<NAME>}, title = {The Title}}", "ID123") == \
    "@article{ID123, author = {<NAME>}, title = {The Title}}"
	assert candidate(
    """@article{Klein:1993:ACF:164104.164107,
 author = {<NAME>},
 title = {A Compiler from {C} to {L}isp},
 journal = {ACM Trans. Program. Lang. Syst.},
 volume = {15},
 number = {1},
 year = {1993},
 pages = {90--127},
 numpages = {38},
}""",
    "abc") == """@article{abc,
 author = {<NAME>},
 title = {A Compiler from {C} to {L}isp},
 journal = {ACM Trans. Program. Lang. Syst.},
 volume = {15},
 number = {1},
 year = {1993},
 pages = {90--127},
 numpages = {38},
}"""
	assert candidate(
    "@article{key, author = {<NAME>}, title = {The Title}}", "ID123456") == \
    "@article{ID123456, author = {<NAME>}, title = {The Title}}"
	assert candidate(
    "@article{key, author = {<NAME>}, title = {The Title}}", "ID12345678") == \
    "@article{ID12345678, author = {<NAME>}, title = {The Title}}"
	assert candidate(
    "@book{HOPL3, title={History of Programming Languages: \n Lisp, \n \
Scheme, \n and Modula-3}, author={<NAME>}, \
publisher={MIT Press}, address={Cambridge, MA}, \
year={2006}}",
    "ID"
) == "@book{ID, title={History of Programming Languages: \n Lisp, \n \
Scheme, \n and Modula-3}, author={<NAME>}, \
publisher={MIT Press}, address={Cambridge, MA}, \
year={2006}}"
	assert candidate(
    "@article{key, author = {<NAME>}, title = {The Title}}", "ID") == \
    "@article{ID, author = {<NAME>}, title = {The Title}}"
	assert candidate(r"""@article{Hartshorne_1979,
  title = {A Theoretical Study of the {M}onte {C}arlo Method},
  volume = {51},
  doi = {10.1090/S0025-5718-1979-0166087-6},
  number = {10},
  journal = {Mathematics of Computation},
  publisher = {American Mathematical Society ({AMS})},
  author = {<NAME>.},
  year = {1979},
  pages = {773-802},
}""", "Hartshorne_1979") == r"""@article{Hartshorne_1979,
  title = {A Theoretical Study of the {M}onte {C}arlo Method},
  volume = {51},
  doi = {10.1090/S0025-5718-1979-0166087-6},
  number = {10},
  journal = {Mathematics of Computation},
  publisher = {American Mathematical Society ({AMS})},
  author = {<NAME>.},
  year = {1979},
  pages = {773-802},
}"""
	assert candidate(
    "@book{book1,\n    author = {<NAME>},\n    year = {2008}\n}",
    "my_id") == "@book{my_id,\n    author = {<NAME>},\n    year = {2008}\n}"
	assert candidate(
    "@article{key, author = {<NAME>}, title = {The Title}}", "ID1234567") == \
    "@article{ID1234567, author = {<NAME>}, title = {The Title}}"
	assert candidate(
    "@article{key, author = {<NAME>}, title = {The Title}}", "ID123456789") == \
    "@article{ID123456789, author = {<NAME>}, title = {The Title}}"
	assert candidate(
    """@article{Abrams:1991:LMI,
    author = {<NAME> and <NAME>},
    title = {Local Minima and Maxima in the Analysis of Data with Incomplete Observations},
    journal = {Journal of the American Statistical Association},
    year = {1991},
    volume = {86},
    pages = {109--117}
    }""",
    "ID") == """@article{ID,
    author = {<NAME> and <NAME>},
    title = {Local Minima and Maxima in the Analysis of Data with Incomplete Observations},
    journal = {Journal of the American Statistical Association},
    year = {1991},
    volume = {86},
    pages = {109--117}
    }"""
	assert candidate(r"""@article{,
  author = {<NAME>},
  title = {A test},
  journal = {Journal of Tests},
  year = {2013},
}""", "abc") == r"""@article{abc,
  author = {<NAME>},
  title = {A test},
  journal = {Journal of Tests},
  year = {2013},
}"""
	assert candidate(r"""@article{key,
    author = {Name},
    title = {Title}
}""", "ID") == r"""@article{ID,
    author = {Name},
    title = {Title}
}"""
def test_check():
	check(set_id)
