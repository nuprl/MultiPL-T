def unit_display_name(name: str) -> str:
    """ Display name
     
     Examples
     --------
     >>> unit_display_name("meter")
     m
     """
	### Canonical solution below ###    

    res = name.replace("meter", "m").replace("_per_", "/").replace("sec", "s")

    return res

### Unit tests below ###
def check(candidate):
	assert candidate("meter") == "m", "Unit display name does not work"
	assert candidate(
    "meter"
) == "m", "candidate('meter') should return'm'"
	assert candidate(
    "meter"
) == "m", "Unit display name for meter is incorrect"
	assert candidate(name="meter_per_sec") == "m/s"
	assert candidate(
    "meter") == "m", "candidate for meter is incorrect"
	assert candidate("meter") == "m", "Unit display name failed"
	assert candidate(
    "meter") == "m", "Problem with candidate"
	assert candidate(name="sec") == "s"
	assert candidate("meter") == "m"
	assert candidate(
    "meter"
) == "m", "candidate failed for meter"
	assert candidate("meter") == "m", "Unit display name does not work for meter"
	assert candidate(name="meter") == "m"
	assert candidate(
    "meter"
) == "m", "candidate should handle meter"
	assert candidate("") == "", "candidate should return empty string for empty string"
	assert candidate(
    "meter_per_sec"
) == "m/s", "candidate('meter_per_sec') should return'm/s'"
	assert candidate(
    "meter") == "m", "candidate('meter') should return'm'"
	assert candidate(
    "meter") == "m", "Should be m"
	assert candidate("sec") == "s", "candidate('sec') should return's'"
	assert candidate("meter") == "m", "candidate should return m for meter"
def test_check():
	check(unit_display_name)
