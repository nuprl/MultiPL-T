def spherical_index_k(degree: int, order: int = 0) -> int:
    """returns the mode `k` from the degree `degree` and order `order`

    Args:
        degree (int): Degree of the spherical harmonics
        order (int): Order of the spherical harmonics

    Raises:
        ValueError: if `order < -degree` or `order > degree`

    Returns:
        int: a combined index k
    """
    ### Canonical solution below ###
    if not -degree <= order <= degree:
        raise ValueError("order must lie between -degree and degree")
    return degree * (degree + 1) + order


### Unit tests below ###
def check(candidate):
	assert candidate(2, 1) == 7
	assert candidate(degree=0, order=0) == 0
	assert candidate(25)
	assert candidate(degree=0) == 0
	assert candidate(1, 1) == 3
	assert candidate(2) == 6
	assert candidate(0, 0) == 0
	assert candidate(degree=1, order=1) == 3
	assert candidate(1, -1) == 1
	assert candidate(1, 0) == 2
	assert candidate(0) == 0
def test_check():
	check(spherical_index_k)
