def iscloseinE(v1, v2):
    """ Method to determine if two spectral lines are very close in energy
     
     Parameters
     ----------
     v1 : float
     Energy of first transition.
     
     v2 : float
     Energy of second transition
     
     Returns
     -------
     True/False whether or not the energies are very close
     
     """
	### Canonical solution below ###    
    return (abs(v2 - v1) < 1.0) and (abs(((v2 + 0.0001) / (v1 + 0.0001)) - 1) < 0.01)

### Unit tests below ###
def check(candidate):
	assert candidate(100.0, 100.0)
	assert not candidate(1000.0, 1001.0)
	assert candidate(1000, 1000.00001)
	assert candidate(5.0, 6.0) == False
	assert candidate(10000.0, 10000.0001) == True
	assert candidate(1000.0, 1000.0001)
	assert candidate(10, 10.1), "candidate test failed"
	assert not candidate(3000.0, 3001.0)
	assert not candidate(3000.0, 3010.0)
	assert candidate(100, 99.9999)
	assert candidate(1.0, 0.9999) == True
	assert not candidate(3000.0, 3100.0)
	assert candidate(5.0, 5.001) == True
	assert candidate(1001, 1001) == True
	assert candidate(1000, 1000.0001) == True
	assert candidate(10000000, 10000000.0001) == True
	assert candidate(100, 100.00001)
	assert candidate(1.0, 1.011) == False
	assert candidate(42.0, 42.0), "42.0 and 42.0 should be close"
	assert candidate(1230.0000, 1230.0010) == True
	assert candidate(1.000000000000000001, 1.000000000000000000) == True
	assert candidate(5.0, 4.999) == True
	assert candidate(10000.0, 10010.0) == False
	assert candidate(1.001, 1.00001) == True
	assert candidate(5.0, 5.0) == True
	assert candidate(10, 9.9), "candidate test failed"
	assert candidate(1001, 1000.001) == True
	assert not candidate(0.001, 0.0012)
	assert candidate(1000, 1000) == True
	assert candidate(1234.567, 1234.568)
	assert candidate(42.0, 42.15), "42.0 and 42.15 should be close"
	assert not candidate(110.0, 111.0)
	assert candidate(100000.0, 100000.000000001)
	assert candidate(3000.0, 3000.01)
	assert candidate(1000.0, 999.9999)
	assert candidate(1230.0000, 1250.0000) == False
	assert not candidate(3000.0, 5000.0)
	assert candidate(110.0, 110.0)
	assert candidate(10000.0, 9999.9) == True
	assert candidate(100.001, 100.0009) == True
	assert candidate(10.0, 10.0001)
	assert candidate(1.000000000000000001, 1.000000000000000002) == True
	assert candidate(100.001, 100.001) == True
	assert not candidate(110.0, 112.0)
	assert not candidate(3000.0, 4000.0)
	assert candidate(5.0, 6.001) == False
	assert candidate(10000000, 10000001.0001) == False
	assert candidate(10, 10.0001), "candidate test failed"
	assert candidate(1.0, 1.0001) == True
	assert candidate(1216, 1215.999) == True
	assert candidate(1230.0000, 1230.0100) == True
	assert candidate(1.0, 1.0) == True
	assert candidate(1001, 1000.0001) == True
	assert candidate(10.0, 9.9999)
	assert candidate(3000.0, 3000.0)
	assert candidate(110.0, 109.999999999)
	assert candidate(1.0, 1.00001) == True
	assert candidate(1234.567, 1234.569)
	assert candidate(100.0, 99.9)
	assert candidate(10000.0, 10001.0001) == False
	assert candidate(1000.0, 1000.0)
	assert candidate(1230.0000, 1230.0000) == True
	assert candidate(1, 1.0001) is True
	assert candidate(1000, 1001) == False
	assert candidate(1000, 999.9999) == True
	assert candidate(1230.0000, 1232.0000) == False
	assert candidate(1234.567, 1234.567001)
	assert candidate(1230.0000, 1230.1000) == True
	assert candidate(10000.0, 10001.0) == False
	assert candidate(12.0, 12.001) == True
	assert candidate(1001, 1002) == False
	assert candidate(100, 100.0001)
	assert candidate(1.000000000000000001, 1.000000000000000001) == True
	assert candidate(10000.0, 10000.00009) == True
	assert candidate(3000.0, 3000.1)
	assert not candidate(10.0, 11.0)
	assert candidate(1000.0, 1000.0001) == True
	assert candidate(100000.0, 100000.001)
	assert candidate(1001, 1000.1) == True
	assert candidate(1.0001, 1.0002)
	assert candidate(10000.0, 10000.0) == True
def test_check():
	check(iscloseinE)
