def _unmask_idx(idx_mask, to_change):
    """ Return mask over all indices originally passed to _masked_idx, marked
     False where indices were originally masked out or where to_change parameter
     is False.
     
     Parameters:
     idx_mask: as returned by _masked_idx
     to_change: mask over True values in idx_mask
     """
	### Canonical solution below ###    
    if idx_mask is None:
        return to_change
    else:
        idx_mask[idx_mask] = to_change
        return idx_mask

### Unit tests below ###
def check(candidate):
	assert candidate(None, [True, False, True]) == [True, False, True]
	assert candidate(None, False) is False
	assert not candidate(None, False)
	assert candidate(None, True) == True
	assert candidate(None, None) is None
	assert candidate(None, [1,2,3]) == [1,2,3]
	assert candidate(None, True)
	assert candidate(None, [False, True, False]) == [False, True, False]
	assert candidate(None, [True, False, False]) == [True, False, False]
	assert candidate(None, False) == False
	assert candidate(None, [1, 0, 1]) == [1, 0, 1]
	assert candidate(None, [1, 0, 0, 0, 1]) == [1, 0, 0, 0, 1]
	assert candidate(None, True) is True
def test_check():
	check(_unmask_idx)
