def instance_builder(cls, data, *args, **kwargs):
    """ Build an object of a specific class. This function is scalable
     (if a list is set as argument, return a list of object; else just
     one object)
     """
	### Canonical solution below ###    
    if not data:
        return data
    elif isinstance(data, dict):
        return cls(data, *args, **kwargs)
    elif isinstance(data, list):
        return [cls(item, *args, **kwargs) for item in data]
    raise TypeError

### Unit tests below ###
def check(candidate):
	assert candidate(dict, [{"a": 1}], b=2, c=3) == [{"a": 1, "b": 2, "c": 3}]
	assert candidate(dict, []) == []
	assert candidate(dict, [{"a": 1}]) == [{"a": 1}]
	assert candidate(dict, {'a': 1}, b=2) == {'a': 1, 'b': 2}
	assert candidate(list, []) == []
	assert candidate(dict, [{'a': 1}, {'b': 2}]) == [{'a': 1}, {'b': 2}]
	assert candidate(dict, {"a": 1, "b": 2}) == {"a": 1, "b": 2}
	assert candidate(dict, None, c=3) == None
	assert candidate(None, None) is None
	assert candidate(dict, {}) == {}
	assert candidate(dict, [{'a': 1}, {'b': 2}], c=3) == [{'a': 1, 'c': 3}, {'b': 2, 'c': 3}]
	assert candidate(dict, {'a': 1}) == {'a': 1}
	assert candidate(dict, [{}, {}]) == [{}, {}]
	assert candidate(dict, None) == None
	assert candidate(dict, {"a": 1, "b": 2}, c=3) == {"a": 1, "b": 2, "c": 3}
	assert candidate(str, '') == ''
	assert candidate(dict, {"a": 1}, b=2, c=3) == {"a": 1, "b": 2, "c": 3}
	assert candidate(dict, {"a": 1}, b=2) == {"a": 1, "b": 2}
	assert candidate(dict, {"a": 1}) == {"a": 1}
	assert candidate(object, {}) == {}
	assert candidate(dict, [{"a": 1}], b=2) == [{"a": 1, "b": 2}]
	assert candidate(object, None) is None
	assert candidate(list, [])!= [1]
	assert candidate(dict, None) is None
	assert candidate(dict, [{'a': 1}, {'a': 2}]) == [{'a': 1}, {'a': 2}]
def test_check():
	check(instance_builder)
