def offsets_transform(row_offset, col_offset, transform):
    """ Calculating new geotransform for each segment boxboundary"""
	### Canonical solution below ###    
    new_geotransform = [
        transform[0] + (col_offset * transform[1]),
        transform[1],
        0.0,
        transform[3] + (row_offset * transform[5]),
        0.0,
        transform[5]]
    return new_geotransform

### Unit tests below ###
def check(candidate):
	assert candidate(0, 0, [1, 2, 3, 4, 5, 6]) == [1, 2, 0, 4, 0, 6]
	assert candidate(0, 0, [0,0,0,0,0,0]) == [0,0,0,0,0,0]
	assert candidate(0, 0, [0, 1, 0, 10, 0, 1]) == [0, 1, 0, 10, 0, 1]
	assert candidate(1, 1, [2, 1, 0, 1, 0, 1]) == [3, 1, 0, 2, 0, 1]
	assert candidate(0, 0, [1, 1, 1, 1, 1, 1]) == [1, 1, 0.0, 1, 0.0, 1]
	assert candidate(1, 1, [1, 1, 0, 1, 0, 1]) == [2, 1, 0, 2, 0, 1]
	assert candidate(1, 1, [0, 1, 0, 0, 0, 1]) == [1, 1, 0, 1, 0, 1]
	assert candidate(1, 1, [3, 1, 0, 1, 0, 1]) == [4, 1, 0, 2, 0, 1]
	assert candidate(0, 0, [-1, -1, 0, -1, 0, -1]) == [-1.0, -1.0, 0.0, -1.0, 0.0, -1.0]
	assert candidate(0, 0, [10, 1, 0, 10, 0, 1]) == [10, 1, 0, 10, 0, 1]
	assert candidate(1, 1, [4, 1, 0, 1, 0, 1]) == [5, 1, 0, 2, 0, 1]
	assert candidate(0, 0, [0,1,0,0,0,-1]) == [0,1,0,0,0,-1]
	assert candidate(1, 1, [0, 1, 0, 1, 0, 1]) == [1, 1, 0, 2, 0, 1]
	assert candidate(0, 1, [-1, -1, 0, -1, 0, -1]) == [-2.0, -1.0, 0.0, -1.0, 0.0, -1.0]
	assert candidate(1, 1, [0, 1, 0, 10, 0, 1]) == [1, 1, 0, 11, 0, 1]
	assert candidate(0, 0, [0, 1, 0, 1, 0, 1]) == [0, 1, 0, 1, 0, 1]
	assert candidate(1, 1, [10, 1, 0, 10, 0, -1]) == [11, 1, 0, 9, 0, -1]
	assert candidate(1, 1, [10, 1, 0, 10, 0, 1]) == [11, 1, 0, 11, 0, 1]
	assert candidate(0, 1, [1, 1, 0, 1, 0, 1]) == [2.0, 1.0, 0.0, 1.0, 0.0, 1.0]
	assert candidate(0, 0, [1, 1, 0, 1, 0, 1]) == [1.0, 1.0, 0.0, 1.0, 0.0, 1.0]
	assert candidate(0, 0, [0, 1, 0, 0, 0, 1]) == [0, 1, 0, 0, 0, 1]
def test_check():
	check(offsets_transform)
