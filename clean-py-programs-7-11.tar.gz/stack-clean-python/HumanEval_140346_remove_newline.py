def remove_newline(string, n=1):
    """Remove up to `n` trailing newlines from `string`."""
    ### Canonical solution below ###
    # Regex returns some weird results when dealing with only newlines,
    # so we do this manually.
    # >>> import re
    # >>> re.sub(r'(?:\r\n|\n\r|\n|\r){,1}$', '', '\n\n', 1)
    # ''
    for _ in range(n):
        if string.endswith("\r\n") or string.endswith("\n\r"):
            string = string[:-2]
        elif string.endswith("\n") or string.endswith("\r"):
            string = string[:-1]
        else:
            break
    return string


### Unit tests below ###
def check(candidate):
	assert candidate(u'1\n') == u'1'
	assert candidate(r'x\r\r\n\r')
	assert candidate(u'abc\n\n') == u'abc\n'
	assert candidate(u'abc\r\n') == u'abc'
	assert candidate("\n") == ""
	assert candidate(r'a') == r'a'
	assert candidate(u"abc\r\n") == u"abc"
	assert candidate(u'1\n\n') == u'1\n'
	assert candidate("foo\r") == "foo"
	assert candidate(r"a") == "a"
	assert candidate("abc") == "abc"
	assert candidate(u'1\r') == u'1'
	assert candidate(u"foo\r\n") == u"foo"
	assert candidate(r"abc") == r"abc"
	assert candidate(r"foo\nbar\r\nbaz") == r"foo\nbar\r\nbaz"
	assert candidate("foo\rfoo") == "foo\rfoo"
	assert candidate("foo") == "foo"
	assert candidate(u'1\n\n\n') == u'1\n\n'
	assert candidate(u"foo\r") == u"foo"
	assert candidate(r'\n\r\n\n\r\n', 4) == r'\n\r\n\n\r\n'
	assert candidate(u'abc\r') == u'abc'
	assert candidate("foo\n") == "foo"
	assert candidate(u'abc\n') == u'abc'
	assert candidate(u"abc\n\r") == u"abc"
	assert candidate("abc\n") == "abc"
	assert candidate(u"foo") == u"foo"
	assert candidate("foo\r\n") == "foo"
	assert candidate("foo\r\nfoo") == "foo\r\nfoo"
	assert candidate(u'1\r\n') == u'1'
	assert candidate(u'1\n\r\n') == u'1\n'
	assert candidate(r'\n\r\n\n\r\n', 6) == r'\n\r\n\n\r\n'
	assert candidate(u'1\n\n\n\n') == u'1\n\n\n'
	assert candidate(candidate("hello\n\n")) == "hello"
	assert candidate(r"foo") == r"foo"
	assert candidate(r"\n\na") == r"\n\na"
	assert candidate("foo\nfoo") == "foo\nfoo"
	assert candidate(u"abc\r") == u"abc"
	assert candidate(r'\n\r\n\n\r\n', 5) == r'\n\r\n\n\r\n'
	assert candidate(u"foo\n") == u"foo"
	assert candidate(r'\r\n\r\n\n\r\n', 4) == r'\r\n\r\n\n\r\n'
	assert candidate(r"") == r""
	assert candidate("") == ""
	assert candidate(u'') == u''
	assert candidate("\r") == ""
	assert candidate(u'abc\n\n\n') == u'abc\n\n'
	assert candidate("\r\n") == ""
	assert candidate(u'abc') == u'abc'
	assert candidate(u"") == u""
	assert candidate(r"a\r\nb\n\rc\rd") == r"a\r\nb\n\rc\rd"
	assert candidate(r"ab") == "ab"
	assert candidate(u"abc\n") == u"abc"
	assert candidate(r'\r\n\r\n\n\r\n', 5) == r'\r\n\r\n\n\r\n'
	assert candidate(r'') == r''
	assert candidate(u"abc") == u"abc"
	assert candidate(r"") == ""
	assert candidate("abc\r") == "abc"
def test_check():
	check(remove_newline)
