def _set_vce_type(vce_type, cluster, shac):
    """ Check for argument conflicts, then set `vce_type` if needed.  """
    ### Canonical solution below ###

    if vce_type not in (None, 'robust', 'hc1', 'hc2', 'hc3', 'cluster',
                        'shac'):
        raise ValueError("VCE type '{}' is not supported".format(vce_type))

    # Check for conflicts
    if cluster and shac:
        raise ValueError("Cannot use `cluster` and `shac` together.")
    elif cluster and vce_type != 'cluster' and vce_type is not None:
        raise ValueError("Cannot pass argument to `cluster` and set `vce_type`"
                         " to something other than 'cluster'")
    elif shac and vce_type != 'shac' and vce_type is not None:
        raise ValueError("Cannot pass argument to `shac` and set `vce_type`"
                         " to something other than 'shac'")

    # Set `vce_type`
    new_vce = 'cluster' if cluster else 'shac' if shac else vce_type

    return new_vce


### Unit tests below ###
def check(candidate):
	assert candidate(None, True, False) == 'cluster'
	assert candidate('cluster', cluster=False, shac=False) == 'cluster'
	assert candidate('robust', False, False) == 'robust'
	assert candidate('shac', False, True) =='shac'
	assert candidate(None, cluster=False, shac=False) is None
	assert candidate(None, False, False) == None
	assert candidate(None, False, True) =='shac'
	assert candidate('shac', False, False) =='shac'
	assert candidate('hc1', False, False) == 'hc1'
	assert candidate(None, cluster=False, shac=True) =='shac'
	assert candidate('cluster', False, False) == 'cluster'
	assert candidate('hc2', False, False) == 'hc2'
	assert candidate('cluster', True, False) == 'cluster'
	assert candidate(None, cluster=True, shac=False) == 'cluster'
	assert candidate('robust', cluster=False, shac=False) == 'robust'
	assert candidate(None, False, False) is None
	assert candidate('hc3', False, False) == 'hc3'
	assert candidate('shac', cluster=False, shac=False) =='shac'
def test_check():
	check(_set_vce_type)
