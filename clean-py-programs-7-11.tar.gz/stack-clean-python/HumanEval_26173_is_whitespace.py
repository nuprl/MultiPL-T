def is_whitespace(c):
    """ 
     static boolean isWhitespace(int codepoint)
     """
	### Canonical solution below ###    

    # try to hit the most common ASCII ones first, then the nonbreaking
    # spaces that Java brokenly leaves out of isWhitespace.

    # u202F is the BOM, see
    # http://www.unicode.org/faq/utf_bom.html#BOM
    # we just accept it as a zero-width nonbreaking space.

    return c in u' \n\u00A0\u2007\u202F\uFEFF' or c.isspace()

### Unit tests below ###
def check(candidate):
	assert candidate(u'xy') == False
	assert not candidate(u'x \n')
	assert candidate(u'\u205F')
	assert not candidate(u'\u0000')
	assert candidate(u'\u2008')
	assert not candidate(u'\nx')
	assert not candidate(u'\uFFFE')
	assert candidate(u'\u2000')
	assert candidate(u' \n')
	assert not candidate(u'\nx ')
	assert candidate(u'\uFEFF')
	assert not candidate(u'x\n')
	assert not candidate(u'A')
	assert candidate(u'\u2007') == True
	assert candidate(u'\u2004')
	assert not candidate(u'x\uFEFF')
	assert candidate(u'\u0020')
	assert candidate(u'a') == False
	assert candidate(u'\u2006')
	assert candidate(u'\u000C')
	assert candidate(u'\n') == True
	assert not candidate(u'\u202E')
	assert not candidate(u'x \nx')
	assert candidate(u'\u00A1') == False
	assert candidate(u'x') == False
	assert candidate(u'\u2003')
	assert not candidate(u'\u0008')
	assert candidate(u'\u202F')
	assert candidate(u'\u1680')
	assert not candidate(u'\u0019')
	assert not candidate(u'\uFFFF')
	assert not candidate(u'abc')
	assert candidate(u' ')
	assert not candidate(u'.')
	assert candidate(u'\uFEFF') == True
	assert candidate(u'\u202F') == True
	assert candidate(u'\u2009')
	assert candidate(u'\u2029')
	assert not candidate(u'ABC')
	assert not candidate(u'\u0010')
	assert candidate(u'\u3000')
	assert not candidate(u'\n x')
	assert candidate(u'\uFF00') == False
	assert candidate(u'\t') == True
	assert candidate(u'\u000B')
	assert not candidate(u'9')
	assert not candidate(u'-')
	assert candidate(u'\u00A0')
	assert candidate(u'\n')
	assert not candidate(u'x\u00A0')
	assert candidate(u'\u0009')
	assert candidate(u'\u2007')
	assert candidate(u'\n ')
	assert candidate(u'\u000D')
	assert not candidate(u'x\u2007')
	assert candidate(u'\u2028')
	assert candidate(u'\u2002')
	assert candidate(u'\t')
	assert candidate(u'\u000A')
	assert candidate(u'\u2001')
	assert not candidate(u'!')
	assert not candidate(u'x')
	assert candidate(u' \n\u00A0\u2007\u202F\uFEFF')
	assert not candidate(u'\u2661')
	assert candidate(u'\u00A0') == True
	assert not candidate(u'x\u202F')
	assert candidate(u'\u2005')
	assert candidate(u'\u200A')
	assert candidate(u'\u180E') == False
	assert not candidate(u'\u00A1')
	assert not candidate(u'0')
	assert candidate(u'\u202E') == False
	assert candidate(u'a') is False
	assert not candidate(u'a')
	assert not candidate(u'1')
	assert candidate(u' \n ')
	assert not candidate(u'_')
	assert not candidate(u'(')
	assert candidate(u' ') == True
def test_check():
	check(is_whitespace)
