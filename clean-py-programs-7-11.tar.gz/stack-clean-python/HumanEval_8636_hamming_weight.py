def hamming_weight(n: int) -> int:
    """Calculate the number of '1' bit in the given it.

    :param int n:
    :return: number of '1' bit in the int
    """
    ### Canonical solution below ###
    weight = 0
    while n != 0:
        weight += 1
        n &= n - 1
    return weight


### Unit tests below ###
def check(candidate):
	assert candidate(28) == 3
	assert candidate(512) == 1
	assert candidate(0xffffffff) == 32
	assert candidate(27) == 4
	assert candidate(2**32 - 1) == 32
	assert candidate(64) == 1
	assert candidate(21) == 3
	assert candidate(13) == 3
	assert candidate(128) == 1
	assert candidate(256) == 1
	assert candidate(2 ** 32) == 1
	assert candidate(0) == 0
	assert candidate(22) == 3
	assert candidate(16384) == 1
	assert candidate(0b11111111) == 8
	assert candidate(32) == 1
	assert candidate(2 ** 32 - 1) == 32
	assert candidate(20) == 2
	assert candidate(15) == 4
	assert candidate(25) == 3
	assert candidate(100) == 3
	assert candidate(26) == 3
	assert candidate(9) == 2
	assert candidate(1) == 1
	assert candidate(4) == 1
	assert candidate(0b0000000000000000000000000001011) == 3
	assert candidate(3) == 2
	assert candidate(24) == 2
	assert candidate(16) == 1
	assert candidate(14) == 3
	assert candidate(10) == 2
	assert candidate(18) == 2
	assert candidate(6) == 2
	assert candidate(7) == 3
	assert candidate(0b00000000) == 0
	assert candidate(0x80000000) == 1
	assert candidate(2048) == 1
	assert candidate(0b00000000000000000000000000001011) == 3
	assert candidate(5) == 2
	assert candidate(0b11111111111111111111111111111101) == 31
	assert candidate(0b00000000000000000000000010000000) == 1
	assert candidate(1024) == 1
	assert candidate(4096) == 1
	assert candidate(8192) == 1
	assert candidate(12) == 2
	assert candidate(19) == 3
	assert candidate(2) == 1
	assert candidate(8) == 1
	assert candidate(32768) == 1
	assert candidate(23) == 4
	assert candidate(17) == 2
	assert candidate(11) == 3
def test_check():
	check(hamming_weight)
