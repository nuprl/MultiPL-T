def check_type(value, allowed_types, var_name="variable", raise_exception=True):
    """
    Raises TypeError or returns False if value doesn't belong to the allowed types

    :param value: value to check
    :param allowed_types: list of allowed types, can be directly set to the type if only one is allowed
    :param var_name: name of the variable for the message
    :param raise_exception: indicates if an exception shall be raised in case of error

    :type value: any
    :type allowed_types: any
    :type var_name: str
    :type raise_exception: bool

    :returns: Check status depending on the requested mode (raise or bool)
    :rtype: bool

    :raises TypeError: if value doesn't belong to the allowed types
    """
    ### Canonical solution below ###

    # Convert single type to a list of one type
    if not isinstance(allowed_types, list):
        allowed_types = [allowed_types]

    value_type = type(value)

    if (value is None and None in allowed_types) or (value_type in allowed_types):
        return True
    if raise_exception:
        raise TypeError("Type of %s shall belong to %s, not %s" % (var_name, allowed_types, value_type))
    return False


### Unit tests below ###
def check(candidate):
	assert candidate(1.0, [str, int], raise_exception=False) == False
	assert candidate(1, int, raise_exception=False)
	assert candidate(1.0, int, raise_exception=False) == False
	assert candidate(1, [None, str, int])
	assert not candidate(1, (str, type(None)), raise_exception=False)
	assert candidate(None, [int, float], raise_exception=False) == False
	assert candidate("1", [str, int])
	assert not candidate(1, str, var_name="var", raise_exception=False)
	assert candidate(1, [int, str], "myVar") == True
	assert candidate(None, None) is True
	assert candidate(1, [str, int]) == True
	assert candidate(1, [int, float]) == True
	assert candidate("test", [str, None])
	assert candidate(1, [int, float]) is True
	assert candidate("1", [None, str, int])
	assert candidate(1, (int, str), "test", raise_exception=False) is False
	assert not candidate("1", int, raise_exception=False)
	assert candidate(None, None)
	assert candidate(1.0, [int, float])
	assert candidate("1", [str, int, float])
	assert not candidate(None, int, raise_exception=False)
	assert candidate(None, [str, None])
	assert candidate(None, [int, float, None]) is True
	assert candidate("test", [str])
	assert candidate(None, [str, None]) == True
	assert candidate(1.0, [int, float]) is True
	assert candidate(True, bool) == True
	assert candidate(None, [None])
	assert candidate(None, [str, type(None)])
	assert not candidate("1", (str, type(None)), raise_exception=False)
	assert candidate(1.0, float) == True
	assert candidate(1, [int]) is True
	assert candidate(1, int, "myVar") == True
	assert candidate(1.2, [int, float]) == True
	assert not candidate(1, (float, str), raise_exception=False)
	assert candidate("1", [str, int, float, None])
	assert candidate(1, [int, float, None])
	assert candidate(1, str, raise_exception=False) is False
	assert candidate(None, [int, None])
	assert candidate(None, [int, None], raise_exception=False)
	assert candidate(1, int) == True
	assert candidate(1, [int, float, str, None])
	assert candidate(1.0, [int, float]) == True
	assert not candidate("test", [int], raise_exception=False)
	assert candidate(1, [float, int])
	assert candidate(1.0, [int, float, None]) is True
	assert candidate("1", [str])
	assert candidate(1.0, float) is True
	assert candidate(1, [int, float, str])
	assert candidate(1.0, [int, float, None])
	assert candidate(1, [int])
	assert candidate(None, None) == True
	assert not candidate(1, str, raise_exception=False)
	assert candidate(0, int) == True
	assert candidate(1, [int, str]) == True
	assert candidate(None, [int, type(None)])
	assert candidate(None, [None]) == True
	assert candidate(None, [str, None]) is True
	assert candidate(1, [int]) == True
	assert candidate(None, [int, float, type(None)]) == True
	assert candidate(True, bool)
	assert not candidate(1, [str, float], raise_exception=False)
	assert candidate(1, (int, str), raise_exception=False) is False
	assert candidate(1, [float, int], raise_exception=False) is True
	assert candidate(None, [None, str, int])
	assert candidate(None, [None]) is True
	assert candidate(None, int, raise_exception=False) == False
	assert candidate("1", str)
	assert candidate(1, [str, None], raise_exception=False) == False
	assert candidate(None, [int, float, None]) == True
	assert candidate(1, int)
	assert candidate(None, [str, int, type(None)])
	assert candidate(1, [int, float])
	assert candidate(1, int) is True
	assert candidate(1, [int, str]) is True
	assert candidate(5, int)
	assert candidate(1, [int, float, type(None)]) == True
	assert candidate(1, [float], raise_exception=False) is False
	assert candidate(True, [bool]) == True
	assert not candidate(1, [str], raise_exception=False)
	assert candidate(1, [str, int])
	assert candidate(1, [float, int]) is True
	assert candidate(None, [str, None], raise_exception=False) == True
	assert candidate(None, [float, int, None]) is True
	assert candidate(1, [str], raise_exception=False) is False
	assert candidate(1, int, raise_exception=False) == True
	assert candidate(0, [int]) == True
def test_check():
	check(check_type)
