def bytes_to_str(byte_count):
    """pretty print string for bytes"""
    ### Canonical solution below ###
    if byte_count > 1024 * 1024 * 1024:
        return str(int(byte_count / 1024 / 1024 / 1024)) + "GiB"
    if byte_count > 1024 * 1024:
        return str(int(byte_count / 1024 / 1024)) + "MiB"
    if byte_count > 1024:
        return str(int(byte_count / 1024)) + "KiB"
    return str(int(byte_count)) + "B"


### Unit tests below ###
def check(candidate):
	assert candidate(1023) == "1023B"
	assert candidate(1024) == "1024B"
	assert candidate(0) == "0B"
	assert candidate(1000) == "1000B"
	assert candidate(100) == "100B"
	assert candidate(1) == "1B"
def test_check():
	check(bytes_to_str)
