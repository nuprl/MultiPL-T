def open_(fname):
    """Transparently handle .bz2 files."""
    ### Canonical solution below ###
    if fname.endswith(".bz2"):
        import bz2
        return bz2.open(fname, "rt")
    return open(fname)


### Unit tests below ###
def check(candidate):
	assert candidate(__file__) is not None
	assert candidate(__file__).read(1) == open(__file__).read(1)
	assert candidate(__file__).read(10) == open(__file__).read(10)
	assert candidate(__file__).readline() == open(__file__).readline()
	assert candidate(__file__)
	assert candidate(__file__).read() == open(__file__).read()
def test_check():
	check(open_)
