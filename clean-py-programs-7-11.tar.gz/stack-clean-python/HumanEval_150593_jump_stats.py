def jump_stats(previous_jumps, chute_altitude):
    """ Compare altitude when chute opened with previous successful jumps.
     
     Return the number of previous jumps and the number of times
     the current jump is better.
     """
	### Canonical solution below ###    
    n_previous_jumps = len(previous_jumps)
    n_better = sum(1 for pj in previous_jumps if chute_altitude < pj)
    return n_previous_jumps, n_better

### Unit tests below ###
def check(candidate):
	assert candidate( [1000, 1000, 1000, 1000], 100000000) == (4, 0)
	assert candidate(previous_jumps=[300, 200, 100], chute_altitude=350) == (3, 0)
	assert candidate(range(1), 2) == (1, 0)
	assert candidate((0,), 1) == (1, 0)
	assert candidate(
    [1, 2, 3, 4], 0) == (4, 4)
	assert candidate( [1000, 1000, 1000, 1000], 10000) == (4, 0)
	assert candidate(previous_jumps = [1000, 1000, 1000, 1000], chute_altitude = 1000) == (4, 0)
	assert candidate(previous_jumps=[0, 0, 45, 90], chute_altitude=50) == (4, 1)
	assert candidate(
    [1, 2, 3, 4], 2) == (4, 2)
	assert candidate(previous_jumps=[100, 99, 105], chute_altitude=105) == (3, 0)
	assert candidate(list(range(10)), 100) == (10, 0)
	assert candidate(previous_jumps=[], chute_altitude=0) == (0, 0)
	assert candidate(
    [1, 2, 3, 4], 5) == (4, 0)
	assert candidate( [1000, 1000, 1000, 1000], 100000) == (4, 0)
	assert candidate(previous_jumps=[0], chute_altitude=0) == (1, 0)
	assert candidate(previous_jumps=[2000, 1000, 1000],
                  chute_altitude=1050) == (3, 1)
	assert candidate( [1000, 1000, 1000, 1000], 10000000000) == (4, 0)
	assert candidate(range(100, 0, -1), 50) == (100, 50)
	assert candidate( [1000, 1000, 1000, 1000], 1000000) == (4, 0)
	assert candidate(previous_jumps=[200, 100, 50], chute_altitude=400) == (3, 0)
	assert candidate( [1000, 1000, 1000, 1000], 1000000000) == (4, 0)
	assert candidate( [1000, 1000, 1000, 1000], 10000000) == (4, 0)
	assert candidate(previous_jumps=[0, 0, 0], chute_altitude=1) == (3, 0)
	assert candidate(previous_jumps=[1000, 1000, 1000, 1000], chute_altitude=600) == (4, 4)
	assert candidate(previous_jumps=[0, 100], chute_altitude=50) == (2, 1)
	assert candidate(previous_jumps = [1000, 1000, 1000, 1000], chute_altitude = 998) == (4, 4)
	assert candidate([20, 20, 20], 50) == (3, 0)
	assert candidate(
    [1, 2, 3, 4], 1) == (4, 3)
	assert candidate(
    [1, 2, 3, 4], 3) == (4, 1)
	assert candidate(list(range(1, 6)), 5) == (5, 0)
	assert candidate(previous_jumps=[1000, 1000, 1000, 1000], chute_altitude=1000) == (4, 0)
	assert candidate((), 0) == (0, 0)
	assert candidate((), 10) == (0, 0)
	assert candidate(previous_jumps=[1, 5, 2], chute_altitude=0) == (3, 3)
def test_check():
	check(jump_stats)
