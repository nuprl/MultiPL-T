def real_units(bias, fb, mce_bias_r=467, dewar_bias_r=49, shunt_r=180E-6,
               dewar_fb_r=5280, butterworth_constant=1218,
               rel_fb_inductance=9, max_bias_voltage=5, max_fb_voltage=0.958,
               bias_dac_bits=16, fb_dac_bits=14):
    """
    Given an array of biases and corresponding array of feedbacks (all in DAC units)
    calculate the actual current and voltage going through the TES.
    Returns: (TES voltage array, TES current array) in Volts and Amps respectively.
    The default values are taken from Carl's script

    Modified from `zeustools/iv_tools
    <https://github.com/NanoExplorer/zeustools/blob/master/zeustools/iv_tools.py>`_

    :param bias: scalar or array, tes bias value(s) in adc unit
    :rtype bias: int or float or numpy.ndarray
    :param fb: scalar or array, sq1 feedback value(s) in adc unit, must have the
        shape such that bias * fb yields valid result
    :rtype fb: int or float or numpy.ndarray
    :param int or float mce_bias_r: scalar, MCE bias resistance in ohm, default
        467 ohm
    :param int or float dewar_bias_r: scalar, dewar bias resistance in ohm,
        default 49 ohm
    :param int or float shunt_r: scalar, shunt resistance in ohm, default 180
        uOhm
    :param int or float dewar_fb_r: scalar, dewar feedback resistance in ohm,
        default 5280 ohm
    :param int or float butterworth_constant: scalar, when running in data mode 2
        and the low pass filter is in the loop, all signals are multiplied by
        this factor
    :param int or float rel_fb_inductance: scalar, feedback inductance ratio,
        default 9 which means for a change of 1 uA in the TES, the squid will
        have to change 9 uA to keep up
    :param int or float max_bias_voltage: scalar, maximum bias voltage in V,
        default 5
    :param int or float max_fb_voltage: scalar, maximum feedback voltage in V,
        default 0.958
    :param int bias_dac_bits: int, bias DAC bit number, default 16
    :param int fb_dac_bits: int, feedback DAC bit number, default 14
    """
    ### Canonical solution below ###

    bias_raw_voltage = bias / 2 ** bias_dac_bits * max_bias_voltage * 2
    # last factor of 2 is because voltage is bipolar
    bias_current = bias_raw_voltage / (dewar_bias_r + mce_bias_r)
    fb_real_dac = fb / butterworth_constant
    fb_raw_voltage = fb_real_dac / 2 ** fb_dac_bits * max_fb_voltage * 2
    # again, last factor of 2 is because voltage is bipolar
    fb_current = fb_raw_voltage / dewar_fb_r
    tes_current = fb_current / rel_fb_inductance

    shunt_current = bias_current - tes_current

    tes_voltage = shunt_current * shunt_r

    return tes_voltage, tes_current


### Unit tests below ###
def check(candidate):
	assert candidate(1024, 0)[0]
	assert candidate(bias=0, fb=0) == (0.0, 0.0)
	assert candidate(0, 0) == (0, 0)
	assert candidate(1, 1000)[1] > 0
	assert candidate(0, 0, mce_bias_r=10, dewar_bias_r=20, shunt_r=100, dewar_fb_r=200, butterworth_constant=1000, rel_fb_inductance=10, max_bias_voltage=2, max_fb_voltage=1) == (0, 0)
	assert candidate(1, 1000)[0] > 0
	assert candidate(0, 0) == (0.0, 0.0)
	assert candidate(10000, 0)[1] == 0
	assert candidate(bias=0, fb=0) == (0, 0)
	assert candidate(512, 0)[1] == 0.0
def test_check():
	check(real_units)
