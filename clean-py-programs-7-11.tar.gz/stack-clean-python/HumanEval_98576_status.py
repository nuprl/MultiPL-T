def status():
    """ Provides a status of the API"""
	### Canonical solution below ###    
    return('GOOD', 200)

### Unit tests below ###
def check(candidate):
	assert isinstance(candidate(), tuple)
	assert candidate( ) == ('GOOD', 200)
	assert candidate( )!= ('BAD', 500)
	assert len(candidate()) == 2
	assert candidate( )[0] == 'GOOD'
	assert candidate( )[0] == 'GOOD', 'Status is not good'
	assert candidate()[0] == 'GOOD', 'Status is not GOOD'
	assert candidate( )[1] == 200
	assert candidate() == ('GOOD', 200)
	assert candidate(
) == ('GOOD', 200)
	assert candidate( )[1] == 200, 'Status code is not 200'
def test_check():
	check(status)
