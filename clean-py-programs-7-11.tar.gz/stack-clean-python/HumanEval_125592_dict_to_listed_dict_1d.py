def dict_to_listed_dict_1d(dict_in):
    """ Convert dict to listed dict where each value is a list containing one element.
     
     Args:
     dict_in (dict): input dict
     
     Returns:
     (dict): listed dict
     
     """
	### Canonical solution below ###    
    assert isinstance(dict_in, dict)
    dict_out = dict_in
    for key, value in dict_out.items():
        dict_out.update({key: [value]})
    return dict_out

### Unit tests below ###
def check(candidate):
	assert candidate(dict(a=1, b=2)) == dict(a=[1], b=[2])
	assert candidate(dict_in={'a': 1, 'b': {'c': 2}}) == {'a': [1], 'b': [{'c': 2}]}
	assert candidate(dict_in={'key1': 1, 'key2': 2}) == {'key1': [1], 'key2': [2]}
	assert candidate(dict_in={'a': 1, 'b': 2}) == {'a': [1], 'b': [2]}
	assert candidate(dict_in={"key1": 1, "key2": 2}) == {"key1": [1], "key2": [2]}
	assert candidate(dict_in=dict(a=1, b=2, c=3)) == dict(a=[1], b=[2], c=[3])
	assert candidate(dict_in=dict(a=1, b=2)) == dict(a=[1], b=[2])
	assert candidate(dict_in={0: 1, 1: 2}) == {0: [1], 1: [2]}
	assert candidate(dict_in=dict()) == dict()
	assert candidate(dict_in={1: 1, 2: 2}) == {1: [1], 2: [2]}
	assert candidate(dict_in={'a': 1}) == {'a': [1]}
	assert candidate(dict_in=dict(a=dict(a1=1, a2=2), b=dict(b1=1, b2=2))) == dict(a=[dict(a1=1, a2=2)], b=[dict(b1=1, b2=2)])
	assert candidate(dict_in={"key1": "value1", "key2": "value2"}) == {"key1": ["value1"], "key2": ["value2"]}
	assert candidate(dict_in={1: 1, 2: 2, 3: 3}) == {1: [1], 2: [2], 3: [3]}
	assert candidate(dict()) == dict()
	assert candidate(dict_in={1: 1}) == {1: [1]}
	assert candidate(dict_in={0: 1}) == {0: [1]}
	assert candidate(dict_in={"a": 1, "b": 2}) == {"a": [1], "b": [2]}
	assert candidate(dict_in={'a': {'b': 1}}) == {'a': [{'b': 1}]}
	assert candidate(dict_in={1: 2}) == {1: [2]}
	assert candidate(dict_in={}) == {}
	assert candidate(dict_in={'a': 1, 'b': [2, 3]}) == {'a': [1], 'b': [[2, 3]]}
	assert candidate(dict(a=1)) == dict(a=[1])
	assert candidate(dict_in={1: 2, 3: 4}) == {1: [2], 3: [4]}
	assert candidate(dict_in={'a': 1, 'b': 2, 'c': 3}) == {'a': [1], 'b': [2], 'c': [3]}
	assert candidate(dict_in={1: 10, 2: 20}) == {1: [10], 2: [20]}
	assert candidate(dict_in={"a": 1}) == {"a": [1]}
	assert candidate(dict_in={"key1": [1, 2, 3], "key2": 2}) == {"key1": [[1, 2, 3]], "key2": [2]}
def test_check():
	check(dict_to_listed_dict_1d)
