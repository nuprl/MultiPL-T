def _flatten_ingredients_tree(ingredients_tree: list) -> list:
    """ Returns a list of dicts"""
	### Canonical solution below ###    
    ingredients = {}
    ingredients_without_subs = []
    sub_ingredients = []

    for item_id, item_amount, item_ingredients in ingredients_tree:
        if item_id in ingredients.keys():
            ingredients[item_id] += item_amount
        else:
            ingredients[item_id] = item_amount

        if item_ingredients:
            sub_ingredients.extend(item_ingredients)
        else:
            ingredients_without_subs.append((item_id, item_amount, item_ingredients))

    result = [ingredients]

    if len(ingredients_without_subs) != len(ingredients_tree):
        sub_ingredients.extend(ingredients_without_subs)
        flattened_subs = _flatten_ingredients_tree(sub_ingredients)
        result.extend(flattened_subs)

    return result

### Unit tests below ###
def check(candidate):
	assert candidate(
    [(1, 1, [(2, 1, [(3, 1, [])])])]) == [
        {1: 1},
        {2: 1},
        {3: 1},
    ]
	assert candidate([(1, 1, [])]) == [{1: 1}]
	assert candidate(
    [(1, 1, [(2, 1, [])])]) == [
        {1: 1},
        {2: 1},
    ]
	assert candidate([(1, 1, [(2, 2, [(3, 3, [])])])]) == [
    {1: 1},
    {2: 2},
    {3: 3}
]
	assert candidate(
    [
        (1, 1, None),
        (2, 2, None),
        (3, 3, None),
    ]
) == [
    {1: 1, 2: 2, 3: 3},
]
	assert candidate(
    [(1, 2, [(3, 4, [(5, 6, None)])])]
) == [
    {1: 2},
    {3: 4},
    {5: 6}
]
	assert candidate(
    [(1, 2, [(3, 4, [(5, 6, [(7, 8, None)])])])]
) == [
    {1: 2},
    {3: 4},
    {5: 6},
    {7: 8}
]
	assert candidate(
    [(1, 2, []), (2, 1, []), (3, 1, [])]
) == [{1: 2, 2: 1, 3: 1}]
	assert candidate(
    [(1, 1, []), (2, 2, []), (3, 3, [])]
) == [{1: 1, 2: 2, 3: 3}]
	assert candidate(
    [(1, 2, [(3, 4, None), (5, 6, None)])]
) == [
    {1: 2},
    {3: 4, 5: 6},
]
	assert candidate(
    [(1, 2, [(3, 4, None)])]
) == [
    {1: 2},
    {3: 4}
]
	assert candidate(
    [(1, 1, [(2, 1, [(3, 1, [(4, 1, [(5, 1, [])])])])])]) == [
        {1: 1},
        {2: 1},
        {3: 1},
        {4: 1},
        {5: 1},
    ]
def test_check():
	check(_flatten_ingredients_tree)
