def expandValues(inputs, count, name):
    """Returns the input list with the length of `count`. If the
    list is [1] and the count is 3. [1,1,1] is returned. The list
    must be the count length or 1. Normally called from `expandParameters()`
    where `name` is the symbolic name of the input.
    """
    ### Canonical solution below ###
    if len(inputs) == count:
        expanded = inputs
    elif len(inputs) == 1:
        expanded = inputs * count
    else:
        raise ValueError('Incompatible number of values for ' + name)
    return expanded


### Unit tests below ###
def check(candidate):
	assert candidate(inputs=[1], count=3, name='inputs') == [1, 1, 1]
	assert candidate( [1,2,3], 3, 'test') == [1,2,3]
	assert candidate([1,2,3], 3, 'test') == [1,2,3]
	assert candidate([1], 3, 'test') == [1, 1, 1]
	assert candidate([1], 3, 'one') == [1, 1, 1]
	assert candidate([1], 3, '[1]') == [1,1,1]
	assert candidate([1], 3, 'b') == [1, 1, 1]
	assert candidate([1], 3, 'a') == [1, 1, 1]
	assert candidate([1,2,3], 3, 'c') == [1,2,3]
	assert candidate( [1], 3, 'x') == [1,1,1]
	assert candidate([1,2,3], 3, 'name') == [1, 2, 3]
	assert candidate([1], 3, 'a') == [1,1,1]
	assert candidate( [1], 3, 'test') == [1,1,1]
	assert candidate( [1,2,3], 3, 'test' ) == [1,2,3]
	assert candidate( [1,2], 2, 'test') == [1,2]
	assert candidate( [1], 3, 'test' ) == [1,1,1]
	assert candidate([1,2,3], 3, 'a') == [1,2,3]
	assert candidate([1, 2, 3], 3, 'test') == [1, 2, 3]
	assert candidate([1], 3, 'b') == [1,1,1]
	assert candidate(inputs=[1, 2], count=2, name='inputs') == [1, 2]
	assert candidate([1], 1, 'test') == [1]
	assert candidate([1], 3, 'name') == [1, 1, 1]
	assert candidate([1, 2, 3], 3, 'name') == [1, 2, 3]
	assert candidate([1], 3, 'test') == [1,1,1]
	assert candidate( [1,2,3], 3, 'x') == [1,2,3]
	assert candidate([1, 2, 3], 3, 'a') == [1, 2, 3]
def test_check():
	check(expandValues)
