def load_ndarray(arr):
    """ Load a numpy array """
    ### Canonical solution below ###
    # Nothing to be done!
    return arr


### Unit tests below ###
def check(candidate):
	assert candidate(None) is None
	assert candidate(1) == 1
	assert candidate([[1, 2, 3], [4, 5, 6]]) == [[1, 2, 3], [4, 5, 6]]
	assert candidate([[[1, 2], [3, 4]], [[5, 6], [7, 8]]]) == [[[1, 2], [3, 4]], [[5, 6], [7, 8]]]
	assert candidate([1, 2, 3]) == [1, 2, 3]
def test_check():
	check(load_ndarray)
