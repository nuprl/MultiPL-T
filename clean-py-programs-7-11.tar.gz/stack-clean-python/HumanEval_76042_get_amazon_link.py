def get_amazon_link(product_id: str, page: int) -> str:
    """ 
     Generates an amazon review link for the following parameters
     :param product_id: unique id of the product
     :param page: review page number
     :return: amazon review page without any filter
     """
	### Canonical solution below ###    
    result = (
        "https://www.amazon.com/-/de/product-reviews/"
        + product_id
        + "/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber="
        + str(page)
    )
    return result

### Unit tests below ###
def check(candidate):
	assert candidate(product_id="B01N9N237E", page=2) == "https://www.amazon.com/-/de/product-reviews/B01N9N237E/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B07Y4K25M9", page=1) == (
    "https://www.amazon.com/-/de/product-reviews/"
    + "B07Y4K25M9/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber="
    + str(1)
)
	assert candidate(product_id="B0756T54D5", page=10) == "https://www.amazon.com/-/de/product-reviews/B0756T54D5/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=10"
	assert candidate(product_id="B00005N570", page=2) == "https://www.amazon.com/-/de/product-reviews/B00005N570/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B076N4K16H", page=1) == "https://www.amazon.com/-/de/product-reviews/B076N4K16H/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B004V07K6Q", page=4) == "https://www.amazon.com/-/de/product-reviews/B004V07K6Q/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B07Y787K5Z", page=1) == "https://www.amazon.com/-/de/product-reviews/B07Y787K5Z/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B07Y444R18", page=100) == "https://www.amazon.com/-/de/product-reviews/B07Y444R18/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=100"
	assert candidate(product_id="B07Y787K5Z", page=3) == "https://www.amazon.com/-/de/product-reviews/B07Y787K5Z/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B001331218", page=10) == "https://www.amazon.com/-/de/product-reviews/B001331218/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=10"
	assert candidate(product_id="B000002N7A", page=2) == "https://www.amazon.com/-/de/product-reviews/B000002N7A/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B076N4K16H", page=3) == "https://www.amazon.com/-/de/product-reviews/B076N4K16H/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(
    "B006U49V78", 4
) == "https://www.amazon.com/-/de/product-reviews/B006U49V78/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B076Q5R92J", page=1) == "https://www.amazon.com/-/de/product-reviews/B076Q5R92J/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B07Y787K5Z", page=2) == "https://www.amazon.com/-/de/product-reviews/B07Y787K5Z/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(
    "B016R5H202", 1
) == "https://www.amazon.com/-/de/product-reviews/B016R5H202/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id='B00I89G2R8', page=2) == 'https://www.amazon.com/-/de/product-reviews/B00I89G2R8/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2'
	assert candidate(product_id='B01LXR9280', page=3) == 'https://www.amazon.com/-/de/product-reviews/B01LXR9280/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3'
	assert candidate(product_id='B073657690', page=10) == 'https://www.amazon.com/-/de/product-reviews/B073657690/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=10'
	assert candidate(product_id="B01N9N237E", page=3) == "https://www.amazon.com/-/de/product-reviews/B01N9N237E/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B000002N7A", page=1) == "https://www.amazon.com/-/de/product-reviews/B000002N7A/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B01N9N237E", page=1) == "https://www.amazon.com/-/de/product-reviews/B01N9N237E/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(
    "B07H12443N", 1
) == "https://www.amazon.com/-/de/product-reviews/B07H12443N/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(
    "B07H12443N", 4
) == "https://www.amazon.com/-/de/product-reviews/B07H12443N/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B077X45576", page=4) == "https://www.amazon.com/-/de/product-reviews/B077X45576/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B076Q5R92J", page=4) == "https://www.amazon.com/-/de/product-reviews/B076Q5R92J/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B07T7D82C9", page=1) == "https://www.amazon.com/-/de/product-reviews/B07T7D82C9/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B000002N7A", page=4) == "https://www.amazon.com/-/de/product-reviews/B000002N7A/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B0717Z432C", page=4) == "https://www.amazon.com/-/de/product-reviews/B0717Z432C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B00L810X8I", page=1) == "https://www.amazon.com/-/de/product-reviews/B00L810X8I/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id='B073657690', page=100) == 'https://www.amazon.com/-/de/product-reviews/B073657690/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=100'
	assert candidate(product_id="B07Y444R18", page=2) == "https://www.amazon.com/-/de/product-reviews/B07Y444R18/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B077X45576", page=3) == "https://www.amazon.com/-/de/product-reviews/B077X45576/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B004V07K6Q", page=2) == "https://www.amazon.com/-/de/product-reviews/B004V07K6Q/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B0756T54D5", page=1) == "https://www.amazon.com/-/de/product-reviews/B0756T54D5/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(
    "B006U49V78", 3
) == "https://www.amazon.com/-/de/product-reviews/B006U49V78/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B00005N570", page=3) == "https://www.amazon.com/-/de/product-reviews/B00005N570/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B004V07K6Q", page=1) == "https://www.amazon.com/-/de/product-reviews/B004V07K6Q/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id='B01LXR9280', page=4) == 'https://www.amazon.com/-/de/product-reviews/B01LXR9280/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4'
	assert candidate(product_id="B01N02Z00G", page=1) == "https://www.amazon.com/-/de/product-reviews/B01N02Z00G/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B001331218", page=2) == "https://www.amazon.com/-/de/product-reviews/B001331218/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B07Y787K5Z", page=4) == "https://www.amazon.com/-/de/product-reviews/B07Y787K5Z/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B079180T18", page=4) == "https://www.amazon.com/-/de/product-reviews/B079180T18/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B076N4K16H", page=4) == "https://www.amazon.com/-/de/product-reviews/B076N4K16H/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B07YV2874X", page=3) == "https://www.amazon.com/-/de/product-reviews/B07YV2874X/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B0717Z432C", page=2) == "https://www.amazon.com/-/de/product-reviews/B0717Z432C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B0717Z432C", page=1) == "https://www.amazon.com/-/de/product-reviews/B0717Z432C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id='B01LXR9280', page=2) == 'https://www.amazon.com/-/de/product-reviews/B01LXR9280/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2'
	assert candidate(product_id="B0018F4X7C", page=1000)
	assert candidate(product_id="B001331218", page=100) == "https://www.amazon.com/-/de/product-reviews/B001331218/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=100"
	assert candidate(
    "B006U49V78", 2
) == "https://www.amazon.com/-/de/product-reviews/B006U49V78/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B00L810X8I", page=3) == "https://www.amazon.com/-/de/product-reviews/B00L810X8I/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B07YV2874X", page=1) == "https://www.amazon.com/-/de/product-reviews/B07YV2874X/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B00005N570", page=1) == "https://www.amazon.com/-/de/product-reviews/B00005N570/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B000002N7A", page=3) == "https://www.amazon.com/-/de/product-reviews/B000002N7A/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B01N02Z00G", page=2) == "https://www.amazon.com/-/de/product-reviews/B01N02Z00G/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B077X45576", page=2) == "https://www.amazon.com/-/de/product-reviews/B077X45576/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B079180T18", page=2) == "https://www.amazon.com/-/de/product-reviews/B079180T18/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B079180T18", page=3) == "https://www.amazon.com/-/de/product-reviews/B079180T18/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B07YV2874X", page=10000) == "https://www.amazon.com/-/de/product-reviews/B07YV2874X/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=10000"
	assert candidate(product_id="B00L810X8I", page=4) == "https://www.amazon.com/-/de/product-reviews/B00L810X8I/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B076Q5R92J", page=2) == "https://www.amazon.com/-/de/product-reviews/B076Q5R92J/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B01N91K81P", page=1) == "https://www.amazon.com/-/de/product-reviews/B01N91K81P/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B0717Z432C", page=3) == "https://www.amazon.com/-/de/product-reviews/B0717Z432C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(
    "B07515K392", 1
) == "https://www.amazon.com/-/de/product-reviews/B07515K392/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(
    "B07H12443N", 2
) == "https://www.amazon.com/-/de/product-reviews/B07H12443N/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B0875KQ5JG", page=1) == "https://www.amazon.com/-/de/product-reviews/B0875KQ5JG/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B001331218", page=1000) == "https://www.amazon.com/-/de/product-reviews/B001331218/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1000"
	assert candidate(product_id='B01LXR9280', page=1) == 'https://www.amazon.com/-/de/product-reviews/B01LXR9280/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1'
	assert candidate(product_id="B0018F4X7C", page=100) == "https://www.amazon.com/-/de/product-reviews/B0018F4X7C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=100"
	assert candidate(product_id="B079180T18", page=1) == "https://www.amazon.com/-/de/product-reviews/B079180T18/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B0018F4X7C", page=1) == "https://www.amazon.com/-/de/product-reviews/B0018F4X7C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B07YV2874X", page=2) == "https://www.amazon.com/-/de/product-reviews/B07YV2874X/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id='B00I89G2R8', page=1) == 'https://www.amazon.com/-/de/product-reviews/B00I89G2R8/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1'
	assert candidate(
    "B0847ZJ1K7", 1
) == "https://www.amazon.com/-/de/product-reviews/B0847ZJ1K7/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B0018F4X7C", page=10) == "https://www.amazon.com/-/de/product-reviews/B0018F4X7C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=10"
	assert candidate(product_id="B0018F4X7C", page=2) == "https://www.amazon.com/-/de/product-reviews/B0018F4X7C/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(product_id="B076N4K16H", page=2) == "https://www.amazon.com/-/de/product-reviews/B076N4K16H/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(
    "B07515K392", 10
) == "https://www.amazon.com/-/de/product-reviews/B07515K392/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=10"
	assert candidate(product_id="B00K90D9QG", page=1) == "https://www.amazon.com/-/de/product-reviews/B00K90D9QG/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B00005N570", page=4) == "https://www.amazon.com/-/de/product-reviews/B00005N570/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=4"
	assert candidate(product_id="B077X45576", page=1) == "https://www.amazon.com/-/de/product-reviews/B077X45576/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(
    "B01N00I895", 1
) == "https://www.amazon.com/-/de/product-reviews/B01N00I895/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(product_id="B00L810X8I", page=2) == "https://www.amazon.com/-/de/product-reviews/B00L810X8I/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=2"
	assert candidate(
    "B006U49V78", 1
) == "https://www.amazon.com/-/de/product-reviews/B006U49V78/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1"
	assert candidate(
    "B07H12443N", 3
) == "https://www.amazon.com/-/de/product-reviews/B07H12443N/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B004V07K6Q", page=3) == "https://www.amazon.com/-/de/product-reviews/B004V07K6Q/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id="B076Q5R92J", page=3) == "https://www.amazon.com/-/de/product-reviews/B076Q5R92J/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3"
	assert candidate(product_id='B073657690', page=1) == 'https://www.amazon.com/-/de/product-reviews/B073657690/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=1'
	assert candidate(product_id='B00I89G2R8', page=3) == 'https://www.amazon.com/-/de/product-reviews/B00I89G2R8/ref=cm_cr_arp_d_viewopt_sr?ie=UTF8&filterByStar=all_stars&reviewerType=all_reviews&pageNumber=3'
def test_check():
	check(get_amazon_link)
