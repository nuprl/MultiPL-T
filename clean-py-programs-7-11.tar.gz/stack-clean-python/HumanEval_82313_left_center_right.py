def left_center_right(leftset, rightset):
    """ Return left only, center (common) and right only elements"""
	### Canonical solution below ###    
    left = leftset - rightset
    common = leftset & rightset
    right = rightset - leftset
    return left, common, right

### Unit tests below ###
def check(candidate):
	assert candidate(set([1, 2, 3]), set([3, 4, 5])) == \
        (set([1, 2]), set([3]), set([4, 5]))
	assert candidate(set([1,2,3,4]), set([4])) == \
    (set([1,2,3]), set([4]), set())
	assert candidate({1, 2, 3}, {2, 3, 4}) == ({1}, {2, 3}, {4})
	assert candidate(set([1,2]), set([3])) == (set([1,2]), set(), set([3]))
	assert candidate({1, 2, 3, 4, 5, 6}, {2, 3, 4}) == ({1, 5, 6}, {2, 3, 4}, set())
	assert candidate(set([1, 2, 3]), set([1, 2, 3])) == (set(), set([1, 2, 3]), set())
	assert candidate({1}, {2}) == ({1}, set(), {2})
	assert candidate(set([1]), set([2,3])) == (set([1]), set(), set([2,3]))
	assert candidate(set([1,2]), set([2,3])) == (set([1]), set([2]), set([3]))
	assert candidate(set('abc'), set('xyz')) == (set('abc'), set(), set('xyz'))
	assert candidate(set([1, 2, 3]), set([2, 3, 4])) == (set([1]), set([2, 3]), set([4]))
	assert candidate(set([1, 2, 3]), set([4, 5, 6])) == (set([1, 2, 3]), set(), set([4, 5, 6]))
	assert candidate({1, 2, 3}, set()) == ({1, 2, 3}, set(), set())
	assert candidate(set([1,2,3]), set([3,4,5])) == (set([1,2]), set([3]), set([4,5]))
	assert candidate(set([1,2,3]), set([2,3])) == (set([1]), set([2,3]), set())
	assert candidate(set(), {1, 2, 3}) == (set(), set(), {1, 2, 3})
	assert candidate({1, 2}, {2, 3}) == ({1}, {2}, {3})
	assert candidate(set([1, 2, 3, 4]), set([3, 4, 5, 6])) == ({1, 2}, {3, 4}, {5, 6})
	assert candidate(set([1]), set([1])) == (set(), set([1]), set())
	assert candidate(set([1,2,3,4]), set([4,6,8])) == \
    (set([1,2,3]), set([4]), set([6,8]))
	assert candidate(set([1, 2, 3]), set([3, 4, 5])) == (set([1, 2]), set([3]), set([4, 5]))
	assert candidate(set(), set()) == (set(), set(), set())
	assert candidate(set([1,2,3,4]), set([1,2,3,4])) == \
    (set(), set([1,2,3,4]), set())
	assert candidate(set([1]), set([2])) == (set([1]), set(), set([2]))
	assert candidate(set([1,2,3,4]), set([2,4,6,8])) == \
    (set([1,3]), set([2,4]), set([6,8]))
def test_check():
	check(left_center_right)
