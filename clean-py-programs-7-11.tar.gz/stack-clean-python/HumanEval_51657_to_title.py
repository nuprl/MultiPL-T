def to_title(text):
    """
    Description: Convert text to title type and remove underscores
    :param text: raw text
    :return: Converted text
    """
    ### Canonical solution below ###
    return str(text).title().replace('_', ' ')


### Unit tests below ###
def check(candidate):
	assert candidate('test test') == 'Test Test'
	assert candidate(1) == '1'
	assert candidate('hello_world') == 'Hello World', 'Underscores should be removed'
	assert candidate('CAPITALS') == 'Capitals'
	assert candidate('With_Underscore') == 'With Underscore'
	assert candidate("text") == "Text", "Error: Text should be Text"
	assert candidate(1) == "1", "Error: 1 should be 1"
	assert candidate('This_Is_A_Test') == 'This Is A Test'
	assert candidate('123hello456world789') == '123Hello456World789'
	assert candidate('lower') == 'Lower'
	assert candidate('1_2_3_4_5') == '1 2 3 4 5'
	assert candidate('abc_def') == 'Abc Def'
	assert candidate('foo_bar_baz') == 'Foo Bar Baz'
	assert candidate('HELLO_WORLD') == 'Hello World'
	assert candidate('this_is_a_test') == 'This Is A Test'
	assert candidate('1') == '1'
	assert candidate('SomeTitle') == 'Sometitle'
	assert candidate('abc') == 'Abc'
	assert candidate(None) == 'None', 'candidate failed'
	assert candidate('1_2') == '1 2'
	assert candidate(1) == '1', 'Error'
	assert candidate('') == ''
	assert candidate('None') == 'None'
	assert candidate('12345_abc_def') == '12345 Abc Def'
	assert candidate('test_test') == 'Test Test'
	assert candidate('12345') == '12345'
	assert candidate('a b c') == 'A B C'
	assert candidate('abc_def_ghi') == 'Abc Def Ghi'
	assert candidate('FOO_BAR_BAZ') == 'Foo Bar Baz'
	assert candidate('1_2_3') == '1 2 3'
	assert candidate('THIS IS A TEST') == 'This Is A Test'
	assert candidate('123') == '123'
	assert candidate('FOO_BAR') == 'Foo Bar'
	assert candidate('this is a test') == 'This Is A Test'
	assert candidate('text_here') == 'Text Here', 'Error'
	assert candidate('a_b_c') == 'A B C'
	assert candidate('HeLLo WoRLD') == 'Hello World'
	assert candidate('HELLO WORLD') == 'Hello World', 'Caps should be converted to lowercase'
	assert candidate('hello world') == 'Hello World', 'Spaces not converted to title'
	assert candidate('Hello') == 'Hello'
	assert candidate('hello') == 'Hello', 'Simple text not converted to title'
	assert candidate('some_title') == 'Some Title'
	assert candidate('some title') == 'Some Title'
	assert candidate('12345_abc') == '12345 Abc'
	assert candidate(123) == '123', 'Integer should not be accepted'
	assert candidate("tExt_1") == "Text 1", "Error: tExt_1 should be Text 1"
	assert candidate('hello world') == 'Hello World'
	assert candidate('123_456') == '123 456'
	assert candidate(123) == '123'
	assert candidate('test') == 'Test'
	assert candidate('1_2_3_4') == '1 2 3 4'
	assert candidate('Hello_World') == 'Hello World'
	assert candidate('my_name_is_aakash') == 'My Name Is Aakash'
	assert candidate('123_456_789') == '123 456 789'
	assert candidate('with_underscore') == 'With Underscore'
	assert candidate('hello') == 'Hello'
	assert candidate('hello_world_123') == 'Hello World 123'
	assert candidate('HELLO WORLD') == 'Hello World'
	assert candidate('hello_world') == 'Hello World', 'Underscores not removed'
	assert candidate('Hello World') == 'Hello World'
	assert candidate('123HELLO456WORLD789') == '123Hello456World789'
	assert candidate('text') == 'Text', 'Error'
	assert candidate('fooBar') == 'Foobar'
	assert candidate('a b_c') == 'A B C'
	assert candidate('text_here_more') == 'Text Here More', 'Error'
	assert candidate('a') == 'A'
	assert candidate('FooBar') == 'Foobar'
	assert candidate('a_b') == 'A B'
	assert candidate('hello world') == 'Hello World', 'Spaces should be replaced with dashes'
	assert candidate('fooBarBaz') == 'Foobarbaz'
	assert candidate('foo_bar') == 'Foo Bar'
	assert candidate('FooBarBaz') == 'Foobarbaz'
	assert candidate('This Is A Test With Underscores') == 'This Is A Test With Underscores'
	assert candidate('A_b_c') == 'A B C'
	assert candidate('hello_world') == 'Hello World'
def test_check():
	check(to_title)
