def regions():
    """

    Reurns a list of regions

    # Returns:
        list, str

    # Example:

        from datahub_core import data
        regions = data.regions

        print(regions)

        >> ['NAM', 'EMEA', 'LATAM', 'APAC' ]

    """
    ### Canonical solution below ###
    return ['NAM', 'EMEA', 'LATAM', 'APAC']


### Unit tests below ###
def check(candidate):
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "test failed"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "candidate() returned {0}, expected ['NAM', 'EMEA', 'LATAM', 'APAC']".format(candidate())
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC']
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], 'test failed'
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "Test Failed: candidate"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "Oops!  That wasn't supposed to happen."
	assert candidate( ) == ['NAM', 'EMEA', 'LATAM', 'APAC']
	assert candidate( ) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "Error: candidate() is not returning the correct values."
	assert candidate( ) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "The value returned by candidate( ) should be ['NAM', 'EMEA', 'LATAM', 'APAC']"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "candidate() failed"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'],'candidate() is not returning a list of candidate'
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "Test Failed: candidate()"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "Error in candidate()"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "candidate() is not returning the right values"
	assert candidate(
) == [
    'NAM',
    'EMEA',
    'LATAM',
    'APAC',
]
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "candidate() is not returning the correct candidate"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "candidate() is not returning the correct list"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "candidate test failed"
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "candidate() should return ['NAM', 'EMEA', 'LATAM', 'APAC']"
	assert candidate(
) == [
    'NAM',
    'EMEA',
    'LATAM',
    'APAC',
], "candidate() test failed"
	assert candidate(
) == [
    'NAM',
    'EMEA',
    'LATAM',
    'APAC',
],'candidate() failed'
	assert candidate(
) == ['NAM', 'EMEA', 'LATAM', 'APAC'], "The function is not working"
def test_check():
	check(regions)
