def sdp_del_LT(f):
    """ Removes the leading from `f`. """
	### Canonical solution below ###    
    return f[1:]

### Unit tests below ###
def check(candidate):
	assert candidate(list('abc')) == list('bc')
	assert candidate('aa') == 'a'
	assert candidate('a') == ''
	assert candidate('') == ''
def test_check():
	check(sdp_del_LT)
