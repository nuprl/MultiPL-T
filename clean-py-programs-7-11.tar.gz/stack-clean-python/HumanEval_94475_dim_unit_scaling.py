def dim_unit_scaling(in_unit, out_unit):
    """
    Calculate the scaling factor to convert from the input unit (in_unit) to
    the output unit (out_unit). in_unit and out_unit must be a string and one
    of ['nm', 'um', 'mm', 'cm', 'm', 'km']. 

    inputs
    ======
    in_unit : str
        Input unit
    out_unit :str
        Output unit

    returns
    =======
    scaling_factor : float
    """
    ### Canonical solution below ###

    unit_vals = {
        'nm': 1e-9,
        'um': 1e-6,
        'mm': 1e-3,
        'cm': 1e-2,
        'm': 1.0,
        'km': 1e3,
    }

    if in_unit not in unit_vals:
        raise ValueError(
            'Invalid input unit {}. Must be one of {}'.format(
                in_unit, list(unit_vals.keys())
            )
        )
    if out_unit not in unit_vals:
        raise ValueError(
            'Invalid input unit {}. Must be one of {}'.format(
                in_unit, list(unit_vals.keys())
            )
        )

    return unit_vals[in_unit] / unit_vals[out_unit]


### Unit tests below ###
def check(candidate):
	assert candidate(in_unit='m', out_unit='mm') == 1000.0
	assert candidate(in_unit='cm', out_unit='um') == 1e4
	assert candidate(in_unit='cm', out_unit='km') == 1e-5
	assert candidate(in_unit='cm', out_unit='mm') == 10.0
	assert candidate(in_unit='m', out_unit='cm') == 100.0
	assert candidate(in_unit='nm', out_unit='m') == 1e-9
	assert candidate(in_unit='mm', out_unit='m') == 1e-3
	assert candidate(in_unit='cm', out_unit='nm') == 1e7
	assert candidate(in_unit='km', out_unit='m') == 1e3
	assert candidate(in_unit='cm', out_unit='m') == 1e-2
	assert candidate(in_unit='cm', out_unit='cm') == 1.0
	assert candidate(in_unit='m', out_unit='cm') == 1e2
	assert candidate(in_unit='km', out_unit='cm') == 1e5
	assert candidate(in_unit='m', out_unit='um') == 1e6
	assert candidate(in_unit='um', out_unit='m') == 1e-6
	assert candidate(in_unit='mm', out_unit='cm') == 1e-1
	assert candidate(in_unit='nm', out_unit='nm') == 1.0
	assert candidate(in_unit='m', out_unit='cm') == 100
	assert candidate(in_unit='m', out_unit='m') == 1.0
	assert candidate(in_unit='nm', out_unit='km') == 1e-12
	assert candidate(in_unit='m', out_unit='km') == 0.001
	assert candidate(in_unit='cm', out_unit='mm') == 10
	assert candidate(in_unit='km', out_unit='mm') == 1e6
	assert candidate(in_unit='m', out_unit='km') == 1e-3
	assert candidate(in_unit='mm', out_unit='km') == 1e-6
	assert candidate(in_unit='km', out_unit='km') == 1.0
	assert candidate(in_unit='km', out_unit='m') == 1000.0
	assert candidate(in_unit='nm', out_unit='um') == 1.0 / 1000.0
def test_check():
	check(dim_unit_scaling)
