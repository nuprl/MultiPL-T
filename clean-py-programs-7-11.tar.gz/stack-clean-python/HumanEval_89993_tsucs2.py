def tsucs2(XYZ, t, a=40, b=1.833, c=55, d=0.16, e=0.65, dz=20):
    """ 
     The Three-Scroll Unified Chaotic System (TSUCS2) Attractor.
     x0 = (0.01,0,0)
     """
	### Canonical solution below ###    
    x, y, z = XYZ
    x_dt = a * (y - x) + d * x * z
    y_dt = dz * y - x * z + c * x
    z_dt = b * z + x * y - e * x**2
    return x_dt, y_dt, z_dt

### Unit tests below ###
def check(candidate):
	assert candidate(t=0, XYZ=(0,0,0)) == (0, 0, 0)
	assert candidate(candidate(candidate([1, 1, 1], 1), 1), 1)!= candidate([1, 1, 1], 3)
	assert candidate(candidate(candidate([1, 1, 1], 1), 1), 1)!= candidate([1, 1, 1], 1)
def test_check():
	check(tsucs2)
