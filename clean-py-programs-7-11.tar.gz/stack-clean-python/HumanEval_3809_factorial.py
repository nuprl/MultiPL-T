def factorial(num: int):
    """ 
     Calculates the factorial of a number.
     
     :param num: Number
     """
	### Canonical solution below ###    
    tot = 1
    for n in range(1, num + 1):
        tot *= n
    return tot

### Unit tests below ###
def check(candidate):
	assert candidate(8) == 40320
	assert candidate(18) == 6402373705728000
	assert candidate(-7) == 1
	assert candidate(-9) == 1
	assert candidate(-1) == 1
	assert candidate(10) == 3628800
	assert candidate(7) == 5040
	assert candidate(12) == 479001600
	assert candidate(11) == 39916800
	assert candidate(6) == 720, "Should be 720"
	assert candidate(22)
	assert candidate(21) == 51090942171709440000
	assert candidate(-6) == 1
	assert candidate(2) == 2
	assert candidate(17) == 355687428096000
	assert candidate(15) == 1307674368000
	assert candidate(-2) == 1
	assert candidate(3) == 6
	assert candidate(-8) == 1
	assert candidate(20) == 2432902008176640000
	assert candidate(19) == 121645100408832000
	assert candidate(13) == 6227020800
	assert candidate(-5) == 1
	assert candidate(5) == 120
	assert candidate(0) == 1
	assert candidate(4) == 24, "Should be 24"
	assert candidate(4) == 24
	assert candidate(14) == 87178291200
	assert candidate(1) == 1
	assert candidate(9) == 362880
	assert candidate(16) == 20922789888000
	assert candidate(5) == 120, "Should be 120"
	assert candidate(-3) == 1
	assert candidate(-4) == 1
	assert candidate(6) == 720
	assert candidate(-10) == 1
def test_check():
	check(factorial)
