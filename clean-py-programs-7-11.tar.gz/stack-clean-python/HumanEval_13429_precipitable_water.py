def precipitable_water(ta, ea):
    """
    Estimate the precipitable water from Prata (1996) :cite:`Prata:1996`
    """
    ### Canonical solution below ###
    return 4650*ea/ta


### Unit tests below ###
def check(candidate):
	assert candidate(10, 0) == 0
	assert candidate(20, 0) == 0
	assert candidate(10, 100) == 46500.
	assert candidate(291.15, 0.00) == 0.00
	assert candidate(280.0, 0.0) == 0.0, 'precipitable water calculation is incorrect'
def test_check():
	check(precipitable_water)
