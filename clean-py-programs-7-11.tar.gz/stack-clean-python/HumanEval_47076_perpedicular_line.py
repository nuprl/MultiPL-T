def perpedicular_line(line, p):
    """ 
     Returns a perpendicular line to a line at a point.
     
     Parameters
     ----------
     line : (1x3) array-like
     The a, b, and c coefficients (ax + by + c = 0) of a line.
     p : (1x2) array-like
     The coordinates of a point on the line.
     
     Returns
     -------
     line : (1x3) array-like
     The a, b, and c coefficients (ax + by + c = 0) of the line
     perpendicular to the input line at point p.
     """
	### Canonical solution below ###    
    a, b, c = line
    pa = b
    pb = -a
    pc = -(p[0] * b - p[1] * a)
    return [pa, pb, pc]

### Unit tests below ###
def check(candidate):
	assert candidate(line=[-1, -1, -3], p=[3, 2]) == [-1, 1, 1]
	assert candidate(line=[0, 0, 1], p=[0, 0]) == [0, 0, 0]
	assert candidate(line=[0, 1, 0], p=[0, 0]) == [1, 0, 0]
	assert candidate(
    [1, 0, 0], [0, 1]) == [0, -1, 1], "perpendicular_line test 2 failed"
	assert candidate(line=[1, 1, 0], p=[0, 0]) == [1, -1, 0]
	assert candidate(line=[1, 1, -2], p=[0, 0]) == [1, -1, 0]
def test_check():
	check(perpedicular_line)
