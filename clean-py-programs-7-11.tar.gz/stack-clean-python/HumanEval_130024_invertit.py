def invertit(score, doit=False):
    """ Inverts score if doit is True
     
     :param np.ndarray score: score to conditionally invert
     :param bool doit: invert the score or not (default: False)
     :return: inverted or original score
     :rtype: np.ndarray
     """
	### Canonical solution below ###    
    if doit:
        x = 1 / score
    else:
        x = score
    return x

### Unit tests below ###
def check(candidate):
	assert candidate(0.5) == 0.5
	assert candidate(10, doit=False) == 10
	assert candidate(0.5, doit=True) == 2
	assert candidate(1, True) == 1
	assert candidate(2, False) == 2.0
	assert candidate(2, True) == 0.5
	assert candidate(1, False) == 1
	assert candidate(10, doit=True) == 1/10
	assert candidate(0.5, False) == 0.5
	assert candidate(1, True) == 1.0
	assert candidate(0.5, True) == 2
	assert candidate(1, False) == 1.0
	assert candidate(0, False) == 0
	assert candidate(0.1) == 0.1
	assert candidate(10) == 10
	assert candidate(0) == 0
	assert candidate(1) == 1
	assert candidate([1, 2, 3], False) == [1.0, 2.0, 3.0]
	assert candidate(10, True) == 0.1
	assert candidate(0.1, doit=True) == 10
	assert candidate(1, doit=True) == 1
	assert candidate(0.1, True) == 10
def test_check():
	check(invertit)
