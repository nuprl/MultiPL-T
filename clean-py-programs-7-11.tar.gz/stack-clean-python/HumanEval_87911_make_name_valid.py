def make_name_valid(name):
    """"Make a string into a valid Python variable name.  Return None if
    the name contains parentheses."""
    ### Canonical solution below ###
    if not name or '(' in name or ')' in name:
        return None
    import string
    valid_chars = "_%s%s" % (string.ascii_letters, string.digits)
    name = str().join([c for c in name if c in valid_chars])
    if not name[0].isalpha():
        name = 'a' + name
    return name


### Unit tests below ###
def check(candidate):
	assert candidate('a') == 'a'
	assert candidate('abc(def)') is None
	assert candidate('(abc') == None
	assert candidate('1234567890') == 'a1234567890'
	assert candidate('abc/def') == 'abcdef'
	assert candidate("123") == "a123"
	assert candidate('12x+') == 'a12x'
	assert candidate('a1b') == 'a1b'
	assert candidate('a (1)') is None
	assert candidate('12x$') == 'a12x'
	assert candidate('(a1)') is None
	assert candidate("(a)") is None
	assert candidate('a(1)2') is None
	assert candidate("(") == None
	assert candidate('a(b)c') == None
	assert candidate(')') is None
	assert candidate('12x-') == 'a12x'
	assert candidate('123!@#') == 'a123'
	assert candidate('12') == 'a12'
	assert candidate(")") == None
	assert candidate('()') is None
	assert candidate('12x*') == 'a12x'
	assert candidate('12x#') == 'a12x'
	assert candidate('a(1) 2') is None
	assert candidate('a)b') == None
	assert candidate('a2(b3)') == None
	assert candidate('a(b') == None
	assert candidate('A1_') == 'A1_'
	assert candidate('a (1)2') is None
	assert candidate('') == None
	assert candidate("a(b)") is None
	assert candidate('(foo)bar') is None
	assert candidate("(a123)") is None
	assert candidate('a(b') is None
	assert candidate("a_b") == "a_b"
	assert candidate('a2') == 'a2'
	assert candidate('a1_b2_c3') == 'a1_b2_c3'
	assert candidate(None) == None
	assert candidate("Hello (world)") is None
	assert candidate('abc_123(def)') is None
	assert candidate('A1_2') == 'A1_2'
	assert candidate('a1 (b2)') is None
	assert candidate('a1bc') == 'a1bc'
	assert candidate('abc_123') == 'abc_123'
	assert candidate('123(abc') is None
	assert candidate(')') == None
	assert candidate('12x?') == 'a12x'
	assert candidate('12x^') == 'a12x'
	assert candidate('a1_') == 'a1_'
	assert candidate('(abc)') is None
	assert candidate('123 (foo) 456') == None
	assert candidate('a)') is None
	assert candidate('a01_23') == 'a01_23'
	assert candidate('a1_b2') == 'a1_b2'
	assert candidate('foo (bar)') == None
	assert candidate('a123!@#') == 'a123'
	assert candidate('foo)bar') is None
	assert candidate('A_') == 'A_'
	assert candidate('123abc_') == 'a123abc_'
	assert candidate('12x!') == 'a12x'
	assert candidate('123') == 'a123'
	assert candidate('123)abc') is None
	assert candidate('a123') == 'a123'
	assert candidate('a b)') is None
	assert candidate('foo (bar) baz') == None
	assert candidate("(x)") == None
	assert candidate('a(1)') is None
	assert candidate('abc)') == None
	assert candidate('a (1) 2') is None
	assert candidate('123abc') == 'a123abc'
	assert candidate('a2b') == 'a2b'
	assert candidate("(Hello) world") is None
	assert candidate('12x@') == 'a12x'
	assert candidate('a_12') == 'a_12'
	assert candidate("foo") == "foo"
	assert candidate('a1') == 'a1'
	assert candidate('a(b)') is None
	assert candidate('a_b') == 'a_b'
	assert candidate("") is None
	assert candidate("(a123)123") is None
	assert candidate("Hello(world)") is None
	assert candidate('(a)') is None
	assert candidate('A') == 'A'
	assert candidate('12x&') == 'a12x'
	assert candidate('a b(') is None
	assert candidate("a_1") == "a_1"
	assert candidate('') is None
	assert candidate('1x') == 'a1x'
	assert candidate("") == None
	assert candidate('a_') == 'a_'
	assert candidate('(a2b3)') == None
	assert candidate('(foo)') == None
	assert candidate(None) is None
	assert candidate('x') == 'x'
	assert candidate('12x%') == 'a12x'
	assert candidate('foo(bar') is None
	assert candidate('(a)b') is None
	assert candidate('(foo') is None
	assert candidate('A1') == 'A1'
	assert candidate('(') is None
	assert candidate('a_b_c') == 'a_b_c'
	assert candidate('foo') == 'foo'
	assert candidate('abc(def)(ghi)') is None
	assert candidate("a(123)") is None
	assert candidate('12x=') == 'a12x'
	assert candidate("a (b)") is None
	assert candidate("a0") == "a0"
	assert candidate('(foo) bar') == None
	assert candidate('12x') == 'a12x'
	assert candidate("a") == "a"
	assert candidate('(') == None
	assert candidate("a (b) c") is None
	assert candidate('a1_2') == 'a1_2'
	assert candidate("foo (bar)") is None
	assert candidate('abc (def)') is None
	assert candidate('1') == 'a1'
	assert candidate('foo (bar) (baz)') == None
	assert candidate('abc') == 'abc'
	assert candidate('a2b3') == 'a2b3'
	assert candidate("a1") == "a1"
	assert candidate('a1b2') == 'a1b2'
def test_check():
	check(make_name_valid)
