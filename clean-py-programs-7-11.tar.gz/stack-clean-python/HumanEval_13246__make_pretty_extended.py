def _make_pretty_extended(extended):
    """ 
     Makes the extended description pretty and returns a formatted string.
     Otherwise, returns None.
     """
	### Canonical solution below ###    

    if extended is not None and extended.strip() != "":
        extended = "\n".join(map(lambda u: u.strip(), extended.split("\n")))
        return "```%s```\n\n" % extended

### Unit tests below ###
def check(candidate):
	assert candidate("test\n\nmore") == "```test\n\nmore```\n\n"
	assert candidate("a\nb") == "```a\nb```\n\n"
	assert candidate("A\nB") == "```A\nB```\n\n"
	assert candidate("foo\nbar") == "```foo\nbar```\n\n"
	assert candidate("  ") == None
	assert candidate("Hello\nWorld") == "```Hello\nWorld```\n\n"
	assert candidate("foo") == "```foo```\n\n"
	assert candidate(" ") == None
	assert candidate("test\ntest") == "```test\ntest```\n\n"
	assert candidate("test\nmore") == "```test\nmore```\n\n"
	assert candidate("Hello\nworld!") == "```Hello\nworld!```\n\n"
	assert candidate("Hello world!") == "```Hello world!```\n\n"
	assert candidate("a\n\n\nb") == "```a\n\n\nb```\n\n"
	assert candidate("a\nb\nc") == "```a\nb\nc```\n\n"
	assert candidate("Hello") == "```Hello```\n\n"
	assert candidate(None) is None
	assert candidate("  \t  \n \n \n") is None
	assert candidate("a\nb\nc\nd") == "```a\nb\nc\nd```\n\n"
	assert candidate("a\n\nb") == "```a\n\nb```\n\n"
	assert candidate(None) == None
	assert candidate("test") == "```test```\n\n"
	assert candidate("a") == "```a```\n\n"
	assert candidate("test\ntest\n") == "```test\ntest\n```\n\n"
	assert candidate("test\n\ntest\n") == "```test\n\ntest\n```\n\n"
	assert candidate(" ") is None
	assert candidate("test\n\ntest") == "```test\n\ntest```\n\n"
	assert candidate("\n\n\n") == None
	assert candidate("test\n\nmore\n") == "```test\n\nmore\n```\n\n"
	assert candidate("\n ") == None
	assert candidate("   \n\n  \n") == None
	assert candidate("    ") == None
	assert candidate(" \n") == None
	assert candidate("\n") == None
	assert candidate("Hello\n\nWorld") == "```Hello\n\nWorld```\n\n"
	assert candidate("\t") == None
	assert candidate("") == None
	assert candidate("foo\n\nbar") == "```foo\n\nbar```\n\n"
def test_check():
	check(_make_pretty_extended)
