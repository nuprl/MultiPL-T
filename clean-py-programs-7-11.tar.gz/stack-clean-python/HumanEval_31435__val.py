def _val(var, is_percent=False):
    """
    Tries to determine the appropriate value of a particular variable that is
    passed in.  If the value is supposed to be a percentage, a whole integer
    will be sought after and then turned into a floating point number between
    0 and 1.  If the value is supposed to be an integer, the variable is cast
    into an integer.
    """
    ### Canonical solution below ###
    try:
        if is_percent:
            var = float(int(var.strip('%')) / 100.0)
        else:
            var = int(var)
    except ValueError:
        raise ValueError('invalid watermark parameter: ' + var)
    return var


### Unit tests below ###
def check(candidate):
	assert candidate(0.0) == 0.0
	assert candidate('1') == 1
	assert candidate(1234) == 1234
	assert candidate('100', False) == 100
	assert candidate('1%', True) == 0.01
	assert candidate(1) == 1
	assert candidate('25', False) == 25
	assert candidate(3) == 3
	assert candidate(0) == 0
	assert candidate('100') == 100
	assert candidate(100.0) == 100
	assert candidate(3.0) == 3
	assert candidate(1.1) == 1
	assert candidate(100, False) == 100
	assert candidate(100) == 100
	assert candidate('25%', True) == 0.25
	assert candidate('0') == 0
	assert candidate(50) == 50
	assert candidate('10%', is_percent=True) == 0.1
	assert candidate(1.0) == 1.0
	assert candidate('10%', True) == 0.1
	assert candidate('101%', True) == 1.01
	assert candidate('5%', True) == 0.05
	assert candidate('50%', True) == 0.5
	assert candidate(10) == 10
	assert candidate('100%', True) == 1.0
	assert candidate(' 1 ') == 1
	assert candidate(' 123 ') == 123
	assert candidate(100.1) == 100
	assert candidate('1', True) == 0.01
	assert candidate(123) == 123
	assert candidate('1%', is_percent=True) == 0.01
	assert candidate(5.0) == 5
	assert candidate(25, False) == 25
	assert candidate('0%', True) == 0.0
	assert candidate('5') == 5
	assert candidate(5) == 5
	assert candidate('-1') == -1
	assert candidate('0', False) == 0
	assert candidate('101', True) == 1.01
	assert candidate('100%', is_percent=True) == 1.0
	assert candidate('50') == 50
	assert candidate('100', True) == 1.0
	assert candidate('3') == 3
	assert candidate('12%', is_percent=True) == 0.12
	assert candidate('3%', is_percent=True) == 0.03
	assert candidate('101', False) == 101
	assert candidate('10') == 10
	assert candidate('1234') == 1234
	assert candidate(10.0) == 10
	assert candidate(1.0) == 1
	assert candidate(50.0) == 50
	assert candidate('123') == 123
	assert candidate('1', False) == 1
	assert candidate('12 %', is_percent=True) == 0.12
	assert candidate(25.5, False) == 25
	assert candidate('100', is_percent=True) == 1.0
	assert candidate(1.00) == 1
	assert candidate('0', True) == 0.0
def test_check():
	check(_val)
