def uniform_city():
    """ 2-way repartition """
    ### Canonical solution below ###
    city = {"A":{1:10, 2:10, 3:0},
            "B":{1:20, 2:20, 3:0},
            "C":{1:0, 2:0, 3:40}}
    return city


### Unit tests below ###
def check(candidate):
	assert candidate(
) == {"A":{1:10, 2:10, 3:0},
       "B":{1:20, 2:20, 3:0},
       "C":{1:0, 2:0, 3:40}}, "Uniform City"
	assert candidate( ) == {"A":{1:10, 2:10, 3:0},
                          "B":{1:20, 2:20, 3:0},
                          "C":{1:0, 2:0, 3:40}}
	assert candidate(
)=={'A': {1: 10, 2: 10, 3: 0}, 'B': {1: 20, 2: 20, 3: 0}, 'C': {1: 0, 2: 0, 3: 40}}, "candidate() failed"
	assert candidate( ) == {"A": {1: 10, 2: 10, 3: 0}, "B": {1: 20, 2: 20, 3: 0}, "C": {1: 0, 2: 0, 3: 40}}
def test_check():
	check(uniform_city)
