def foldline(line, limit=75, fold_sep='\r\n '):
    """
    Make a string folded as defined in RFC5545
    Lines of text SHOULD NOT be longer than 75 octets, excluding the line
    break.  Long content lines SHOULD be split into a multiple line
    representations using a line "folding" technique.  That is, a long
    line can be split between any two characters by inserting a CRLF
    immediately followed by a single linear white-space character (i.e.,
    SPACE or HTAB).
    https://github.com/collective/icalendar/blob/4.0.2/src/icalendar/parser.py#L65
    """
    ### Canonical solution below ###
    assert '\n' not in line

    # Use a fast and simple variant for the common case that line is all ASCII.
    try:
        line.encode('ascii')
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass
    else:
        return fold_sep.join(line[i : i + limit - 1] for i in range(0, len(line), limit - 1))

    ret_chars = []
    byte_count = 0
    for char in line:
        char_byte_len = len(char.encode('utf-8'))
        byte_count += char_byte_len
        if byte_count >= limit:
            ret_chars.append(fold_sep)
            byte_count = char_byte_len
        ret_chars.append(char)

    return ''.join(ret_chars)


### Unit tests below ###
def check(candidate):
	assert candidate(u'Long line that will be folded') == u'Long line that will be folded'
	assert candidate(u'This is a short line') == u'This is a short line'
	assert candidate(u'a' * 74) == u'a' * 74
	assert candidate(u'abc') == u'abc'
	assert candidate(u'This is a test.') == u'This is a test.'
	assert candidate(u'Hello world!', 24) == u'Hello world!'
	assert candidate(u'abc1234567890') == u'abc1234567890'
	assert candidate(u'Hello world!', 25) == u'Hello world!'
	assert candidate(u'Hello world!', 21) == u'Hello world!'
	assert candidate(u'This is a long line that will be folded') == \
    'This is a long line that will be folded'
	assert candidate(u'This is a very long line that should be folded into two lines\r\r\r') == u'This is a very long line that should be folded into two lines\r\r\r'
	assert candidate(u'abcd') == 'abcd'
	assert candidate(u'1234567890123456789012345678901234567890123456789012345678901234567890') == \
    '1234567890123456789012345678901234567890123456789012345678901234567890'
	assert candidate(u'Hello World') == u'Hello World'
	assert candidate(u'This is a very long line that should be folded into two lines\r') == u'This is a very long line that should be folded into two lines\r'
	assert candidate(u'cafe\u0301') == u'cafe\u0301'
	assert candidate(u'Hello world!', 17) == u'Hello world!'
	assert candidate(u'Hello world!', 20) == u'Hello world!'
	assert candidate(u'A very long line that will be folded.') == u'A very long line that will be folded.'
	assert candidate(u'a') == 'a'
	assert candidate(u'A very long line that will be folded.', limit=50) == u'A very long line that will be folded.'
	assert candidate(u"Hello, World!") == u"Hello, World!"
	assert candidate(u'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz') == u'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz'
	assert candidate(u'caf\xe9') == u'caf\xe9'
	assert candidate(u'A very long line that will be folded.', limit=40, fold_sep=' ') == u'A very long line that will be folded.'
	assert candidate(u'a' * 74) == 'a' * 74
	assert candidate(u'hello') == 'hello'
	assert candidate(u'x' * 74) == u'x' * 74
	assert candidate(u'This is a short line') == 'This is a short line'
	assert candidate(u'abc1234567890abc1234567890abc1234567890') == u'abc1234567890abc1234567890abc1234567890'
	assert candidate(u'Hello world!', 16) == u'Hello world!'
	assert candidate(u'abcdefghijklmnopqrstuvwxyz0123456789') == u'abcdefghijklmnopqrstuvwxyz0123456789'
	assert candidate(u'Short line') == 'Short line'
	assert candidate(u'This is a very long line that should be folded into two lines\r\r') == u'This is a very long line that should be folded into two lines\r\r'
	assert candidate(u'12345678901234567890123456789012345678901234567890') == (
    '12345678901234567890123456789012345678901234567890')
	assert candidate(u'caf\xe9\u0301') == u'caf\xe9\u0301'
	assert candidate(u'hello world') == u'hello world'
	assert candidate(u'This is a very long line that should be folded into two lines') == u'This is a very long line that should be folded into two lines'
	assert candidate(u'Test') == u'Test'
	assert candidate(u'Hello world!') == u'Hello world!'
	assert candidate(u'a' * 60) == 'a' * 60
	assert candidate(u'abcdefghijklmnopqrstuvwxyz') == u'abcdefghijklmnopqrstuvwxyz'
	assert candidate(u'hello world') == 'hello world'
	assert candidate(u"Hello World!") == u"Hello World!"
	assert candidate(u'abcde') == u'abcde'
	assert candidate(u'01234567890123456789012345678901234567890123456789') == u'01234567890123456789012345678901234567890123456789'
	assert candidate(u'Hello world!', 13) == u'Hello world!'
	assert candidate(u'Short line') == u'Short line'
	assert candidate(u'Hello world') == u'Hello world'
	assert candidate(u'abc\u2026') == 'abc\u2026'
def test_check():
	check(foldline)
