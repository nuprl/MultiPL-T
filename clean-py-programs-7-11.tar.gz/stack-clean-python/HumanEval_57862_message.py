def message(name, pval, alpha=0.01):
    """Write a message."""
    ### Canonical solution below ###
    if pval < alpha:
        return '{0} can be rejected (pval <= {1:.2g})'.format(name, pval)
    else:
        return '{0} cannot be rejected (pval = {1:.2g})'.format(name, pval)


### Unit tests below ###
def check(candidate):
	assert candidate(name='a', pval=0.01, alpha=0.01) == 'a cannot be rejected (pval = 0.01)'
	assert candidate(1, 0.05, 0.01) == '1 cannot be rejected (pval = 0.05)'
	assert candidate(name='X', pval=0.01) == 'X cannot be rejected (pval = 0.01)'
	assert candidate(name='A', pval=0.05) == 'A cannot be rejected (pval = 0.05)'
	assert candidate(name='test', pval=0.5) == 'test cannot be rejected (pval = 0.5)'
	assert candidate(name='t-test', pval=1) == 't-test cannot be rejected (pval = 1)'
	assert candidate(2, 0.05) == '2 cannot be rejected (pval = 0.05)'
	assert candidate(name='B', pval=0.01) == 'B cannot be rejected (pval = 0.01)'
	assert candidate(name='T-test', pval=0.01) == 'T-test cannot be rejected (pval = 0.01)'
	assert candidate(name='t-test', pval=0.1) == 't-test cannot be rejected (pval = 0.1)'
	assert candidate(name='beta', pval=0.005) == 'beta can be rejected (pval <= 0.005)'
	assert candidate(name='x', pval=0.05) == 'x cannot be rejected (pval = 0.05)'
	assert candidate(name='Test', pval=0.05) == 'Test cannot be rejected (pval = 0.05)'
	assert candidate(name='t-test', pval=0.05) == 't-test cannot be rejected (pval = 0.05)'
	assert candidate(name='x', pval=0.01, alpha=0.01) == 'x cannot be rejected (pval = 0.01)'
	assert candidate(name='alpha', pval=0.01) == 'alpha cannot be rejected (pval = 0.01)'
	assert candidate(name='b', pval=0.05) == 'b cannot be rejected (pval = 0.05)'
	assert candidate(name='a', pval=0.01, alpha=0.05) == 'a can be rejected (pval <= 0.01)'
	assert candidate(name='test', pval=0.0001, alpha=0.0001) == 'test cannot be rejected (pval = 0.0001)'
	assert candidate(name='B', pval=0.05) == 'B cannot be rejected (pval = 0.05)'
	assert candidate(name='a', pval=0.001, alpha=0.05) == 'a can be rejected (pval <= 0.001)'
	assert candidate(name='t-test', pval=0.5) == 't-test cannot be rejected (pval = 0.5)'
	assert candidate(1, 0.02) == '1 cannot be rejected (pval = 0.02)'
	assert candidate(name='t-test', pval=10) == 't-test cannot be rejected (pval = 10)'
	assert candidate(1, 0.01) == '1 cannot be rejected (pval = 0.01)'
	assert candidate(name='y', pval=0.00001) == 'y can be rejected (pval <= 1e-05)'
	assert candidate(name='x', pval=0.5) == 'x cannot be rejected (pval = 0.5)'
def test_check():
	check(message)
