def MAX(*expression):
    """
    Returns the maximum value.
    See https://docs.mongodb.com/manual/reference/operator/aggregation/max/
    for more details
    :param expression: expression/expressions or variables
    :return: Aggregation operator
    """
    ### Canonical solution below ###
    return {'$max': list(expression)} if len(expression) > 1 else {'$max': expression[0]} if expression else {}


### Unit tests below ###
def check(candidate):
	assert candidate(2, '$b') == {'$max': [2, '$b']}
	assert candidate(1, 2) == {'$max': [1, 2]}
	assert candidate(10) == {'$max': 10}
	assert candidate(3) == {'$max': 3}
	assert candidate([1, 2, 3]) == {'$max': [1, 2, 3]}
	assert candidate([3, 2, 1]) == {'$max': [3, 2, 1]}
	assert candidate(3, 4) == {'$max': [3, 4]}
	assert candidate([5, 2, 6]) == {'$max': [5, 2, 6]}
	assert candidate(1) == {'$max': 1}
	assert candidate('$a', '$b', '$c') == {'$max': ['$a', '$b', '$c']}
	assert candidate() == {}
	assert candidate(5, 2, 6) == {'$max': [5, 2, 6]}
	assert candidate(5, 10) == {'$max': [5, 10]}
	assert candidate(1, 2, 3, 4) == {'$max': [1, 2, 3, 4]}
	assert candidate('$a') == {'$max': '$a'}
	assert candidate(10, 20, 30) == {'$max': [10, 20, 30]}
	assert candidate(5, 10, 15, 20) == {'$max': [5, 10, 15, 20]}
	assert candidate([1, 2]) == {'$max': [1, 2]}
	assert candidate(1, 2, 3) == {'$max': [1, 2, 3]}
	assert candidate(10, 20) == {'$max': [10, 20]}
	assert candidate(5) == {'$max': 5}
	assert candidate(2) == {'$max': 2}
	assert candidate('$a', '$b') == {'$max': ['$a', '$b']}
	assert candidate(5, 2) == {'$max': [5, 2]}
	assert candidate(2, 4) == {'$max': [2, 4]}
	assert candidate(2, 3) == {'$max': [2, 3]}
	assert candidate(5, 6, 7, 8) == {'$max': [5, 6, 7, 8]}
	assert candidate(5, 6) == {'$max': [5, 6]}
	assert candidate(3, 2, 1) == {'$max': [3, 2, 1]}
	assert candidate('$a', 1, '$b') == {'$max': ['$a', 1, '$b']}
	assert candidate(5, 10, 15) == {'$max': [5, 10, 15]}
def test_check():
	check(MAX)
