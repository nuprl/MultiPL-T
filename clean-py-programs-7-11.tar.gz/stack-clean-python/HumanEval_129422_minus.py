def minus(x, y):
    """
    Elementwise substraction of two lists of numbers (vectors).
    """
    ### Canonical solution below ###
    c = []
    for a, b in zip(x, y):
        c.append(a - b)
    return c


### Unit tests below ###
def check(candidate):
	assert candidate(
    [1, 2, 3, 4, 5],
    [0, 0, 0, 0, 0]) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == [0, 0, 0, 0]
	assert candidate( [1, 2, 3], [4, 5, 6] ) == [-3, -3, -3]
	assert candidate(
    [1, 2, 3, 4, 5],
    [10, 20, 30, 40, 50]) == [-9, -18, -27, -36, -45]
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5]) == [0, 0, 0, 0, 0]
	assert candidate( [1,2,3], [0,0,0] ) == [1,2,3]
	assert candidate( [1,2,3], [-1,-2,-3] ) == [2,4,6]
	assert candidate([1, 2, 3, 4], [1, 1, 1, 1]) == [0, 1, 2, 3]
	assert candidate([10, 20, 30, 40], [1, 2, 3, 4]) == [9, 18, 27, 36]
	assert candidate(list(range(10)), list(range(10))) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
	assert candidate(range(5), range(5)) == [0, 0, 0, 0, 0]
	assert candidate( [1,2,3], [4,5,6] ) == [-3,-3,-3]
	assert candidate( [1,2,3,4], [4,3,2,1] ) == [-3,-1,1,3]
	assert candidate([10, 10, 10], [5, 5, 5]) == [5, 5, 5]
	assert candidate( [1, 2, 3], [1, 1, 1] ) == [0, 1, 2]
	assert candidate( [1, 2, 3], [0, 1, 2] ) == [1, 1, 1]
	assert candidate(list(range(5)), list(range(5))) == [0, 0, 0, 0, 0]
	assert candidate( [1,2,3], [1,2,3] ) == [0,0,0]
	assert candidate( [1, 2, 3], [1, 0, 0] ) == [0, 2, 3]
	assert candidate(
    [1, 2, 3],
    [4, 5, 6]) == [-3, -3, -3]
	assert candidate( [1,2,3], [4,5,6] )!= [-3,-3,-2]
	assert candidate(list(range(10)), list(range(1, 11))) == [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
	assert candidate( [1, 2, 3], [4, 5, 6] )!= [3, 3, 3]
	assert candidate( [1, 2, 3], [0, 0, 0] ) == [1, 2, 3]
def test_check():
	check(minus)
