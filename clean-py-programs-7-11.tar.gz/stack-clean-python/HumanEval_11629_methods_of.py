def methods_of(obj):
    """ Return non-private methods from an object.
     
     Get all callable methods of an object that don't start with underscore
     :return: a list of tuples of the form (method_name, method)
     """
	### Canonical solution below ###    
    result = []
    for i in dir(obj):
        if callable(getattr(obj, i)) and not i.startswith('_'):
            result.append((i, getattr(obj, i)))
    return result

### Unit tests below ###
def check(candidate):
	assert candidate(object) == []
	assert candidate(object) == candidate(object()) == []
	assert candidate(object) == candidate(candidate)
def test_check():
	check(methods_of)
