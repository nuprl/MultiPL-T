def get_suitable_int_type(upper: int, lower: int = 0) -> str:
    """ Returns the suitable integer type with the least bits.
     
     Returns the integer type that can hold all values between max_val and min_val
     (inclusive) and has the least bits.
     
     Args:
     max_val: Maximum value that needs to be valid.
     min_val: Minimum value that needs to be valid.
     
     Returns:
     The suitable type.
     """
	### Canonical solution below ###  
  assert upper >= lower
  upper = max(upper, 0)
  lower = min(lower, 0)
  if lower == 0:
    return 'uint%d' % upper.bit_length()
  return 'int%d' % (max(upper.bit_length(), (lower + 1).bit_length()) + 1)

### Unit tests below ###
def check(candidate):
	assert candidate(2**30 - 1) == 'uint30'
	assert candidate(3, -1) == 'int3'
	assert candidate(2**20 + 1) == 'uint21'
	assert candidate(2**31) == 'uint32'
	assert candidate(255) == 'uint8'
	assert candidate(1, 0) == 'uint1'
	assert candidate(-1, -2**100) == 'int101'
	assert candidate(3, 1) == 'uint2'
	assert candidate(3) == 'uint2'
	assert candidate(2**30 + 1) == 'uint31'
	assert candidate(-1, -2**4) == 'int5'
	assert candidate(4294967295) == 'uint32'
	assert candidate(1, -1) == 'int2'
	assert candidate(4, -3) == 'int4'
	assert candidate(2, 0) == 'uint2'
	assert candidate(3, -2) == 'int3'
	assert candidate(2**63) == 'uint64'
	assert candidate(255, 100) == 'uint8'
	assert candidate(18446744073709551615) == 'uint64'
	assert candidate(255, 0) == 'uint8'
	assert candidate(2**31 - 1) == 'uint31'
	assert candidate(4, -2) == 'int4'
	assert candidate(2**31 + 1) == 'uint32'
	assert candidate(2) == 'uint2'
	assert candidate(15) == 'uint4'
	assert candidate(10) == 'uint4'
	assert candidate(2**10 + 1) == 'uint11'
	assert candidate(2**10 - 1) == 'uint10'
	assert candidate(2, -2) == 'int3'
	assert candidate(65535) == 'uint16'
	assert candidate(2**32 - 1) == 'uint32'
	assert candidate(2**20 - 1) == 'uint20'
	assert candidate(2, -100) == 'int8'
	assert candidate(12) == 'uint4'
	assert candidate(0) == 'uint0'
	assert candidate(1) == 'uint1'
def test_check():
	check(get_suitable_int_type)
