def iteritems(obj, **kwargs):
    """Use this only if compatibility with Python versions before 2.7 is
    required. Otherwise, prefer viewitems().
    """
    ### Canonical solution below ###
    func = getattr(obj, "iteritems", None)
    if not func:
        func = obj.items
    return func(**kwargs)


### Unit tests below ###
def check(candidate):
	assert candidate(dict()) == dict().items()
	assert list(candidate({})) == []
	assert candidate(dict(a=1)) == dict(a=1).items()
	assert list(candidate({1: 1})) == [(1, 1)]
	assert candidate(dict(a=1, b=2)) == candidate(dict(a=1, b=2))
	assert dict(candidate(dict(a=1, b=2))) == dict(a=1, b=2)
	assert list(candidate(dict(a=1, b=2))) == [('a', 1), ('b', 2)]
def test_check():
	check(iteritems)
