def format_symbol(item):
    """ 
     items may be a list of strings, or a list of string lists.
     In the latter case, each entry in the quick panel will show multiple rows
     """
	### Canonical solution below ###    
    return [item.get("name")]

### Unit tests below ###
def check(candidate):
	assert candidate(dict(name="foo", type="enum")) == ["foo"]
	assert candidate(dict(name="foo", type="variable")) == ["foo"]
	assert candidate(dict(name="foo", type="struct")) == ["foo"]
	assert candidate(dict(name="foo", type="class")) == ["foo"]
	assert candidate(dict(name="test")) == ["test"]
	assert candidate(dict(name="foo", type="function")) == ["foo"]
	assert candidate(dict(name="foo", type="macro")) == ["foo"]
	assert candidate({"name": "foo", "type": "bar"}) == ["foo"]
	assert candidate({"name": "name"}) == ["name"]
	assert candidate(dict(name="foo")) == ["foo"]
	assert candidate({"name": "foo"}) == ["foo"]
	assert candidate({"name": "foo", "type": "bar", "location": {"uri": "file:///foo"}}) == ["foo"]
def test_check():
	check(format_symbol)
