def unify_common_space(memory_state):
    """ 
     Merges the common space for various devices.
     Each one may not have the same size in the shared space whereas they seem to all have access to the whole space.
     Input:
     - memory_state : the state in which the memory is with all its fragments.
     Output:
     The memory with common space merged.
     """
	### Canonical solution below ###    
    new_memory_state = [memory_state[0]]
    for i in range(1, len(memory_state)):
        if (
            memory_state[i]["devices_id"] == 0
            and new_memory_state[-1]["devices_id"] == 0
        ):
            new_memory_state[-1]["size"] += memory_state[i]["size"]
        else:
            new_memory_state.append(memory_state[i])
    return new_memory_state

### Unit tests below ###
def check(candidate):
	assert candidate(
    [
        {
            "devices_id": 0,
            "size": 1024,
        },
        {
            "devices_id": 0,
            "size": 1024,
        },
    ]
) == [
    {
        "devices_id": 0,
        "size": 2048,
    }
]
	assert candidate(
    [
        {
            "size": 100,
            "devices_id": 0,
            "fragment_id": 1,
            "fragment_size": 100,
        },
        {
            "size": 100,
            "devices_id": 0,
            "fragment_id": 1,
            "fragment_size": 100,
        },
        {
            "size": 100,
            "devices_id": 1,
            "fragment_id": 1,
            "fragment_size": 100,
        },
    ]
) == [
    {
        "size": 200,
        "devices_id": 0,
        "fragment_id": 1,
        "fragment_size": 100,
    },
    {
        "size": 100,
        "devices_id": 1,
        "fragment_id": 1,
        "fragment_size": 100,
    },
]
	assert candidate(
    [
        {
            "devices_id": 0,
            "size": 1024,
        },
        {
            "devices_id": 0,
            "size": 2048,
        },
    ]
) == [
    {
        "devices_id": 0,
        "size": 3072,
    }
]
	assert candidate(
    [
        {"devices_id": 0, "size": 4},
        {"devices_id": 1, "size": 4},
        {"devices_id": 2, "size": 4},
    ]
) == [
    {"devices_id": 0, "size": 4},
    {"devices_id": 1, "size": 4},
    {"devices_id": 2, "size": 4},
]
	assert candidate(
    [
        {"devices_id": 0, "size": 100},
        {"devices_id": 1, "size": 100},
        {"devices_id": 2, "size": 100},
        {"devices_id": 3, "size": 100},
    ]
) == [
    {"devices_id": 0, "size": 100},
    {"devices_id": 1, "size": 100},
    {"devices_id": 2, "size": 100},
    {"devices_id": 3, "size": 100},
]
	assert candidate(
    [
        {"devices_id": 0, "size": 20},
        {"devices_id": 0, "size": 10},
        {"devices_id": 0, "size": 30},
    ]
) == [
    {"devices_id": 0, "size": 60},
]
	assert candidate(
    [
        {
            "devices_id": 0,
            "size": 4,
        },
        {
            "devices_id": 1,
            "size": 4,
        },
        {
            "devices_id": 2,
            "size": 4,
        },
        {
            "devices_id": 3,
            "size": 4,
        },
    ]
) == [
    {
        "devices_id": 0,
        "size": 4,
    },
    {
        "devices_id": 1,
        "size": 4,
    },
    {
        "devices_id": 2,
        "size": 4,
    },
    {
        "devices_id": 3,
        "size": 4,
    },
]
	assert candidate(
    [
        {"devices_id": 0, "size": 10},
        {"devices_id": 1, "size": 20},
        {"devices_id": 2, "size": 30},
        {"devices_id": 3, "size": 40},
    ]
) == [
    {"devices_id": 0, "size": 10},
    {"devices_id": 1, "size": 20},
    {"devices_id": 2, "size": 30},
    {"devices_id": 3, "size": 40},
]
	assert candidate(
    [
        {"devices_id": 0, "size": 100},
        {"devices_id": 0, "size": 100},
    ]
) == [
    {"devices_id": 0, "size": 200},
]
	assert candidate(
    [
        {"devices_id": 0, "size": 100},
        {"devices_id": 1, "size": 100},
        {"devices_id": 2, "size": 100},
    ]
) == [
    {"devices_id": 0, "size": 100},
    {"devices_id": 1, "size": 100},
    {"devices_id": 2, "size": 100},
]
	assert candidate(
    [
        {
            "devices_id": 0,
            "size": 4,
        },
        {
            "devices_id": 0,
            "size": 4,
        },
        {
            "devices_id": 1,
            "size": 4,
        },
    ]
) == [
    {
        "devices_id": 0,
        "size": 8,
    },
    {
        "devices_id": 1,
        "size": 4,
    },
]
	assert candidate(
    [
        {
            "devices_id": 0,
            "size": 1024,
        },
        {
            "devices_id": 0,
            "size": 1024,
        },
        {
            "devices_id": 0,
            "size": 1024,
        },
        {
            "devices_id": 1,
            "size": 1024,
        },
    ]
) == [
    {
        "devices_id": 0,
        "size": 3072,
    },
    {
        "devices_id": 1,
        "size": 1024,
    },
]
	assert candidate(
    [
        {"devices_id": 0, "size": 1},
        {"devices_id": 0, "size": 2},
        {"devices_id": 1, "size": 1},
        {"devices_id": 2, "size": 1},
    ]
) == [
    {"devices_id": 0, "size": 3},
    {"devices_id": 1, "size": 1},
    {"devices_id": 2, "size": 1},
]
	assert candidate(
    [
        {
            "devices_id": 0,
            "size": 5,
        },
        {
            "devices_id": 0,
            "size": 5,
        },
    ]
) == [
    {
        "devices_id": 0,
        "size": 10,
    }
]
	assert candidate(
    [
        {
            "devices_id": 0,
            "size": 4,
        },
        {
            "devices_id": 0,
            "size": 4,
        },
    ]
) == [
    {
        "devices_id": 0,
        "size": 8,
    },
]
	assert candidate(
    [
        {"devices_id": 0, "size": 100},
        {"devices_id": 0, "size": 200},
        {"devices_id": 1, "size": 100},
    ]
) == [
    {"devices_id": 0, "size": 300},
    {"devices_id": 1, "size": 100},
]
def test_check():
	check(unify_common_space)
