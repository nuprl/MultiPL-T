def update_model_args(default_args=None, user_args=None):
    """ 
     Make arg dict with updated default values.
     Args:
     default_args (dict): Dictionary of default values.
     user_args (dict): Dictionary of args from.
     Returns:
     dict: Make new dict and update with first default and then user args.
     """
	### Canonical solution below ###    
    out = {}
    if default_args is None:
        default_args = {}
    if user_args is None:
        user_args = {}
    out.update(default_args)
    out.update(user_args)
    return out

### Unit tests below ###
def check(candidate):
	assert candidate(default_args={"a":1, "b":2}, user_args={}) == {"a":1, "b":2}
	assert candidate(default_args={"a": 1, "b": 2}, user_args={"c": 10}) == {"a": 1, "b": 2, "c": 10}
	assert candidate(default_args={"lr": 0.001}, user_args={"lr": None}) == {"lr": None}
	assert candidate(default_args={}, user_args=None) == {}
	assert candidate(default_args={"a": 1, "b": 2}, user_args={"a": 10, "c": 10}) == {"a": 10, "b": 2, "c": 10}
	assert candidate({'foo': 'bar'}, {'bar': 'baz'}) == {'foo': 'bar', 'bar': 'baz'}
	assert candidate(
    None, {"a": 3, "c": 4}
) == {"a": 3, "c": 4}, "Update model args failed"
	assert candidate(default_args={"lr": 0.001}, user_args={}) == {"lr": 0.001}
	assert candidate(default_args=None, user_args=None) == {}, "Empty dicts"
	assert candidate({'foo': 'bar'}, {'foo': 'baz'}) == {'foo': 'baz'}
	assert candidate({"a": 1}, None) == {"a": 1}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args=None) == {'a': 1, 'b': 2}
	assert candidate(default_args=None, user_args={"a": 1, "b": 2}) == {"a": 1, "b": 2}
	assert candidate(default_args={"lr": 0.001}, user_args={"lr": 0.1}) == {"lr": 0.1}
	assert candidate(
    {"a": 1, "b": 2}, {}
) == {"a": 1, "b": 2}, "Update model args failed"
	assert candidate(default_args={}, user_args={}) == {}
	assert candidate(default_args={'a': 1}, user_args=None) == {'a': 1}
	assert candidate(default_args=None, user_args={"a": 10}) == {"a": 10}
	assert candidate(default_args=None, user_args={'a': 3}) == {'a': 3}, "Update model args failed."
	assert candidate({'a': 1, 'b': 2}, {'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(
    None, None) == {}
	assert candidate(
    None, {'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
	assert candidate(
    {'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a': 2, 'b': 4, 'e': 5}) == {'a': 2, 'b': 4, 'c': 3, 'e': 5}
	assert candidate(default_args=None,
                         user_args=None) == {}
	assert candidate({'a': 1, 'b': 2}, {'a': 3}) == {'a': 3, 'b': 2}
	assert candidate({'a': 1}, None) == {'a': 1}
	assert candidate(None, {}) == {}
	assert candidate({'a': 1, 'b': 2}, {'a': 2, 'b': 3}) == {'a': 2, 'b': 3}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a': 2, 'd': 4, 'e': 5}) == {'a': 2, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
	assert candidate(default_args=None, user_args={"a": 2}) == {"a": 2}
	assert candidate(default_args=None, user_args={}) == {}
	assert candidate(default_args={"a": 1, "b": 2}, user_args={"a": 10}) == {"a": 10, "b": 2}
	assert candidate(
    {'a': 1, 'b': 2}, {'a': 3, 'c': 4}) == {'a': 3, 'b': 2, 'c': 4}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a': 2, 'b': 4}) == {'a': 2, 'b': 4, 'c': 3}
	assert candidate(default_args={}, user_args={"a":1, "b":2}) == {"a":1, "b":2}
	assert candidate(
    default_args=None, user_args=None
) == {}
	assert candidate({'foo': 'bar'}, None) == {'foo': 'bar'}
	assert candidate({}, None) == {}
	assert candidate({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
	assert candidate(default_args={"a": 1, "b": 2}, user_args=None) == {"a": 1, "b": 2}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a': 2, 'b': 4, 'd': 5}) == {'a': 2, 'b': 4, 'c': 3, 'd': 5}
	assert candidate(default_args={"a": 1, "b": 2}, user_args={"a": 2, "c": 3}) == {
    "a": 2,
    "b": 2,
    "c": 3,
}
	assert candidate(
    None, None
) == {}, "Update model args failed"
	assert candidate({"a": 1}, {}) == {"a": 1}
	assert candidate(None, {'foo': 'bar'}) == {'foo': 'bar'}
	assert candidate(default_args=None, user_args={"a": 2, "c": 3}) == {
    "a": 2,
    "c": 3,
}
	assert candidate({'a': 1}, {'a': 2, 'b': 3}) == {'a': 2, 'b': 3}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={}) == {'a': 1, 'b': 2}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
	assert candidate(
    default_args={"a": 1, "b": 2},
    user_args={"a": 11, "c": 3}
) == {"a": 11, "b": 2, "c": 3}
	assert candidate(default_args={"a":1, "b":2}, user_args=None) == {"a":1, "b":2}
	assert candidate({"a": 1}, {"a": 2}) == {"a": 2}
	assert candidate(None, {'a': 1}) == {'a': 1}
	assert candidate(
    default_args={"a": 1, "b": 2}, user_args={"b": 3, "c": 4}
) == {"a": 1, "b": 3, "c": 4}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args=None) == {'a': 1, 'b': 2}, "Update model args failed."
	assert candidate(default_args=None, user_args={"b": 3, "c": 4}) == {"b": 3, "c": 4}
	assert candidate(default_args={'a': 1}, user_args={'b': 2}) == {'a': 1, 'b': 2}
	assert candidate(
    {'a': 1, 'b': 2}, {}) == {'a': 1, 'b': 2}
	assert candidate({'a': 1, 'b': 2}, {'a': 2}) == {'a': 2, 'b': 2}
	assert candidate(default_args={"a": 1, "b": 2}, user_args=None) == {
    "a": 1,
    "b": 2,
}
	assert candidate(default_args=None, user_args={'a': 3, 'c': 4}) == {'a': 3, 'c': 4}
	assert candidate(None, None) == {}
	assert candidate(default_args={'foo': 1, 'bar': 2},
                         user_args={'bar': 3, 'baz': 4}) == {'foo': 1, 'bar': 3, 'baz': 4}
	assert candidate(
    {"a": 1, "b": 2}, {"b": 3}
) == {"a": 1, "b": 3}, "Update model args failed"
	assert candidate(default_args={'foo': 1, 'bar': 2},
                         user_args=None) == {'foo': 1, 'bar': 2}
	assert candidate(default_args={"a":1, "b":2}, user_args={"b":3, "c":4}) == {"a":1, "b":3, "c":4}
	assert candidate(None, {"a": 1}) == {"a": 1}
	assert candidate(default_args=None, user_args={'a': 1}) == {'a': 1}
	assert candidate({}, {}) == {}
	assert candidate(default_args=None,
                         user_args={'bar': 3, 'baz': 4}) == {'bar': 3, 'baz': 4}
	assert candidate({'a': 1}, {'a': 2}) == {'a': 2}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={'a': 3}) == {'a': 3, 'b': 2}, "Update model args failed."
	assert candidate(default_args=None, user_args={'b': 2}) == {'b': 2}
	assert candidate(default_args={"a": 1, "b": 2}, user_args={"b": 3, "c": 4}) == {"a": 1, "b": 3, "c": 4}
	assert candidate(
    {}, {"a": 3, "c": 4}
) == {"a": 3, "c": 4}, "Update model args failed"
	assert candidate(default_args=None, user_args=None) == {}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={'a': 2, 'c': 3}) == {'a': 2, 'b': 2, 'c': 3}
	assert candidate(
    {"a": 1, "b": 2}, None
) == {"a": 1, "b": 2}, "Update model args failed"
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={'a': 5}) == {'a': 5, 'b': 2}
	assert candidate(
    {"a": 1, "b": 2}, {"a": 3}
) == {"a": 3, "b": 2}, "Update model args failed"
	assert candidate(default_args=None, user_args={"a":1, "b":2}) == {"a":1, "b":2}
	assert candidate(default_args={"a": 1, "b": 2}, user_args={"a": 2}) == {
    "a": 2,
    "b": 2,
}
	assert candidate(
    default_args={"a": 1, "b": 2}, user_args=None
) == {"a": 1, "b": 2}
	assert candidate(
    {"a": 1, "b": 2}, {"a": 3, "c": 4}
) == {"a": 3, "b": 2, "c": 4}, "Update model args failed"
	assert candidate(default_args=None, user_args={'a': 2, 'c': 3}) == {'a': 2, 'c': 3}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}, "Simple case"
	assert candidate(default_args={"a": 1, "b": 2}, user_args={"a": 2}) == {"a": 2, "b": 2}
	assert candidate(default_args={'a': 1, 'c': 3}, user_args={'b': 2}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(default_args=None, user_args=None) == {}, "Update model args failed."
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={'a': 3, 'c': 4}) == {'a': 3, 'b': 2, 'c': 4}
	assert candidate(
    default_args=None, user_args={"b": 3, "c": 4}
) == {"b": 3, "c": 4}
	assert candidate(default_args={'a': 1, 'b': 2}, user_args={'b': 3}) == {'a': 1, 'b': 3}
	assert candidate(
    {'a': 1, 'b': 2}, None) == {'a': 1, 'b': 2}
def test_check():
	check(update_model_args)
