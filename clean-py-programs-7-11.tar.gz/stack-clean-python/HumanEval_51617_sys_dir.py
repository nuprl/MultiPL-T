def sys_dir(folder):
    """ check if windows system dir"""
	### Canonical solution below ###    
    import re

    system_dir = r'windows' + r'program files' + r'system32' + r'system'

    for dir in system_dir:
        match = re.search(dir, folder, flags=re.IGNORECASE)
        if match:
            return True

    return False

### Unit tests below ###
def check(candidate):
	assert candidate(r'C:\Windows\system32\system') == True
	assert candidate(r'c:\windows\system32\system') == True
	assert candidate(r'C:\Windows\System32\syStem32') is True
	assert candidate(r'C:\Windows\System32\SYSTEM32\system') == True
	assert candidate(r'C:\windows\system32') == True
	assert candidate(r'C:\Program Files\Windows\system32\system32')
	assert candidate(r'c:\windows\system32\system')
	assert candidate(r'C:\WINDOWS\system32\System')
	assert candidate(r'C:\Windows\System32\System32') is True
	assert candidate(r'C:\windows\system32\system32\system32') == True
	assert candidate(r'C:\Windows\Program Files\System32\system32') == True
	assert candidate(r'c:\Windows\program files\System\System') == True
	assert candidate(r'C:\Windows\System32\system') is True
	assert candidate(r'C:\Windows\System32\cmd.exe') == True
	assert candidate(r'C:\Windows\system32') == True
	assert candidate(r'c:\Windows\program files\system32\System') == True
	assert candidate(r'C:\Windows\System32\SYSTEM32\SYSTEM32\system') == True
	assert candidate(r'C:\Program Files\System32\System') == True
	assert candidate(r'C:\Windows\Program Files\System32\System') == True
	assert candidate(r"C:\windows\system32\system") == True
	assert candidate(r'Windows\Program Files\System32\System')
	assert candidate(r'C:\windows\system32\system')
	assert candidate(r'c:\windows\system32\program files\system32\system') == True
	assert candidate(r'C:\Windows\Program Files\System32') == True
	assert candidate(r'Windows\Program Files\System32\System') is True
	assert candidate(r'C:\Windows\System32\System') == True
	assert candidate(r'c:\windows\program files\system32\system') == True
	assert candidate(r'windows\program files\system32\system') == True
	assert candidate(r'C:\Windows\System32\system') == True
	assert candidate(r'c:\Windows\system32\System') == True
	assert candidate(r'C:\Program Files\Windows\system32\system')
	assert candidate(r'C:\Windows\System32\syStem') is True
	assert candidate(r'C:\Windows\System32\Windows\System32') is True
	assert candidate(r'C:\windows\system32\system') == True
	assert candidate(r'C:\Windows\System32\system32') is True
	assert candidate(r'C:\Windows\System32\System')
	assert candidate(r'c:\windows\system32\program files\system32\system32\system') == True
	assert candidate(r'C:\windows\program files\system32\system') == True
	assert candidate(r'C:\WINDOWS\system32\system') == True
	assert candidate(r'C:\Windows\System32\System') is True
	assert candidate(r'c:\Windows\program files\system\System') == True
	assert candidate(r'C:\WINDOWS\system32\system\system32')
	assert candidate(r'C:\Windows\System32\SYSTEM') is True
	assert candidate(r'C:\WINDOWS\system32\system')
	assert candidate(r'c:\Windows\system\System') == True
	assert candidate(r'C:\WINDOWS\system32\system') is True
	assert candidate(r'C:\windows\System32\system') == True
	assert candidate(r'C:\windows\system') == True
	assert candidate(r'C:\Windows\Program Files\System32\system') == True
def test_check():
	check(sys_dir)
