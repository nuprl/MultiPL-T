def get_p_lsh_candidate(jsim, n_bands, n_rows_per_band):
    """Computes probability that two signatures will be detected as similar using the
    LSH algorithm.

    Args:
        jsim: Actuall/Assumed Jaccard Similarity between the hypothetical signatures
        n_bands: Number of bands
        n_rows_per_band: Number of rows per band

    Returns:
        (float) Probability that the hypothetical signatures will be detected as
            similar.
    """
    ### Canonical solution below ###
    return 1 - (1 - jsim ** n_rows_per_band) ** n_bands


### Unit tests below ###
def check(candidate):
	assert candidate(0.75, 2, 1) == (1 - (1 - 0.75 ** 1) ** 2)
	assert candidate(0.5, 1, 1) == 0.5
	assert candidate(1, 1, 1) == 1
	assert candidate(0.75, 2, 4) == (1 - (1 - 0.75 ** 4) ** 2)
	assert candidate(jsim=0.5, n_bands=1, n_rows_per_band=2) == 0.25
	assert candidate(0.75, 2, 2) == (1 - (1 - 0.75 ** 2) ** 2)
def test_check():
	check(get_p_lsh_candidate)
