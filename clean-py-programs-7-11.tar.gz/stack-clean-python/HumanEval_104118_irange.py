def irange(*args):
    """ 
     Similar to range but stop is an inclusive upper bound.
     """
	### Canonical solution below ###  
  if len(args) == 0:
    raise TypeError("irange expected at least 1 arguments, got 0")
  elif len(args) == 1:
    stop = args[0]
    start = 0
    step = 1
  elif len(args) == 2:
    start, stop = args
    step = 1
  elif len(args) == 3:
    start, stop, step = args
  else:
    raise TypeError("irange expected at most 3 arguments, got " + str(len(args)))

  if step == 0:
    raise ValueError("irange() step argument must not be zero")

  stop = stop + 1 if step > 0 else stop - 1
  return range(start, stop, step)

### Unit tests below ###
def check(candidate):
	assert candidate(-1, -10, -2) == range(-1, -10, -2)
	assert candidate(10, 15, 2) == range(10, 15, 2)
	assert candidate(10, 5, -2) == range(10, 5, -2)
	assert candidate(10, 15, -2) == range(10, 15, -2)
	assert candidate(10, 5, -3) == range(10, 5, -3)
	assert candidate(5, 10, 3) == range(5, 10, 3)
	assert candidate(1, 5, -2) == range(1, 5, -2)
	assert candidate(10, 1, 1) == range(10, 1, 1)
	assert candidate(3, 1, -1) == range(3, 0, -1)
	assert candidate(5, 0, -2) == range(5, 0, -2)
	assert candidate(10, 1, -2) == range(10, 1, -2)
	assert candidate(-1, -3) == range(-1, -3)
	assert candidate(0, 5, 2) == range(0, 5, 2)
	assert candidate(-10) == range(-10)
	assert candidate(10, 5) == range(10, 5)
	assert candidate(1, 3, 3) == range(1, 2)
	assert candidate(5, 1, 1) == range(5, 1, 1)
	assert candidate(-1, -10) == range(-1, -10)
	assert candidate(1, -3) == range(1, -3)
	assert candidate(1, 3, 4) == range(1, 2)
	assert candidate(-1) == range(-1)
	assert candidate(1, 10, 2) == range(1, 10, 2)
	assert candidate(10, 15, 100) == range(10, 15, 100)
	assert candidate(3, 1, -2) == range(3, 0, -2)
	assert candidate(1, 5, -1) == range(1, 5, -1)
	assert candidate(3, 1, -3) == range(3, 0, -3)
	assert candidate(5, 10, 2) == range(5, 10, 2)
	assert candidate(10, 15, -100) == range(10, 15, -100)
	assert candidate(3, 1, -4) == range(3, 1, -4)
def test_check():
	check(irange)
