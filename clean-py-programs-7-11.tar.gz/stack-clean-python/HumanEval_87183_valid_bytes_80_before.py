def valid_bytes_80_before(valid_bytes_48_before):
    """ 
     Fixture that yields a :class:`~bytes` that is 80 bits and is ordered "less than" the
     result of the :func:`~valid_bytes_80_after` fixture.
     """
	### Canonical solution below ###    
    return valid_bytes_48_before + b'\0' * 4

### Unit tests below ###
def check(candidate):
	assert candidate(b'1' * 48) < b'1' * 80
	assert candidate(b'6' * 48) < b'6' * 80
	assert candidate(b'\xff' * 6) < candidate(b'\xff' * 6 + b'\x80' * 4)
	assert candidate(b'a') == candidate(b'a')
	assert candidate(b'4' * 48) < b'4' * 80
	assert candidate(b'\xff' * 6) < candidate(b'\xff' * 6 + b'\x81' * 4)
	assert candidate(b'b') >= candidate(b'a')
	assert candidate(b'5' * 48) < b'5' * 80
	assert candidate(b'a') < candidate(b'b')
	assert candidate(b'3' * 48) < b'3' * 80
	assert candidate(b'\0' * 4) < candidate(b'\xff' * 4)
	assert candidate(b'9' * 48) < b'9' * 80
	assert candidate(b'\0' * 48 + b'\5') < candidate(b'\0' * 48 + b'\6')
	assert candidate(b'\x00' * 6) < candidate(b'\x00' * 6 + b'\x01' * 4)
	assert candidate(b'\0' * 48 + b'\2') < candidate(b'\0' * 48 + b'\3')
	assert candidate(b'\0' * 48 + b'\7') < candidate(b'\0' * 48 + b'\8')
	assert candidate(b'\0' * 4) < candidate(b'\x01\x00\x00' + b'\xff' * 2)
	assert candidate(b'b') > candidate(b'a')
	assert candidate(b'\0' * 48 + b'\6') < candidate(b'\0' * 48 + b'\7')
	assert candidate(b'\x00' * 48) == candidate(b'\x00' * 48)
	assert candidate(b'\xff' * 6) < candidate(b'\xff' * 6 + b'\xff' * 4)
	assert candidate(b'7' * 48) < b'7' * 80
	assert candidate(b'\0' * 4) < candidate(b'\x01\x00\x00\x00\x00' + b'\xff' * 0)
	assert candidate(b'\0' * 4) < candidate(b'\x01\x00\x00\x00' + b'\xff' * 1)
	assert candidate(b'\x00' * 6) < candidate(b'\x00' * 6 + b'\0' * 4)
	assert candidate(b'a') <= candidate(b'b')
	assert candidate(b'\0' * 48) < candidate(b'\0' * 48 + b'\1')
	assert candidate(b'2' * 48) < b'2' * 80
	assert candidate(b'\0' * 48 + b'\4') < candidate(b'\0' * 48 + b'\5')
	assert candidate(b'\0' * 4) < candidate(b'\x01\x00' + b'\xff' * 3)
	assert candidate(b'\xff' * 6) < candidate(b'\xff' * 6 + b'\x7f' * 4)
	assert candidate(b'8' * 48) < b'8' * 80
	assert candidate(b'\0' * 48 + b'\3') < candidate(b'\0' * 48 + b'\4')
	assert candidate(b'\xff' * 6) < candidate(b'\xff' * 6 + b'\x01' * 4)
	assert candidate(b'\xff' * 6) < candidate(b'\xff' * 6 + b'\0' * 4)
	assert candidate(b'\0' * 48 + b'\1') < candidate(b'\0' * 48 + b'\2')
def test_check():
	check(valid_bytes_80_before)
