def re_remote_url(s):
    """ Tests if a string is a "remote" URL, http, https, ftp. """
	### Canonical solution below ###    
    s = s.lower()
    if s.startswith("http://"):
        return True
    if s.startswith("https://"):
        return True
    if s.startswith("ftp://"):
        return True
    return False

### Unit tests below ###
def check(candidate):
	assert candidate( "http://www.google.com" )
	assert candidate( "/home/user/file" ) == False
	assert not candidate( "www.example.com/index.html" )
	assert not candidate("debian.org/debian/")
	assert candidate( "FTP://somewhere.com/file.zip" )
	assert not candidate("ftp:/")
	assert not candidate(r"http:/foo.com/bar")
	assert candidate( "ftp://foo.com/bar.html" )
	assert not candidate("ftp.debian.org/debian/")
	assert not candidate(u"smb://google.com")
	assert candidate( "ftp://www.google.com" )
	assert candidate("ftp://") is True
	assert not candidate(u"rsync://google.com")
	assert candidate(
    "https://www.google.com"
) == True, "candidate test failed"
	assert not candidate("www.debian.org/debian/")
	assert candidate( "https://www.google.com" )
	assert not candidate(u"svn://google.com")
	assert not candidate( "foo" )
	assert not candidate(u"www.google.com/")
	assert not candidate(u"gopher://google.com")
	assert not candidate(u"git://google.com")
	assert candidate( "ftp://www.example.com" )
	assert candidate(u"https://google.com/something/else") == True
	assert candidate("abc") is False
	assert candidate("http://") == True
	assert candidate("http://www.google.com/file.html") == True
	assert candidate( "https://www.example.com" )
	assert candidate("https://www.google.com/file.html") == True
	assert candidate(
    "google.com"
) == False, "candidate test failed"
	assert candidate(u"ftp://google.com")
	assert candidate("ftp://www.google.com") == True
	assert not candidate( "foo.com/bar.html" )
	assert candidate( "ftp://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/" )
	assert not candidate( "file:///index.html" )
	assert not candidate("debian.org")
	assert candidate("ftp://abc") is True
	assert not candidate( "www.google.com/" )
	assert candidate(
    "https://www.google.com/a/b/c"
) == True, "candidate test failed"
	assert not candidate(u"imap://google.com")
	assert candidate( "http://google.com" )
	assert candidate( "http://google.com/index.html" )
	assert candidate("ftp://www.google.com/file.html?query=string") == True
	assert not candidate(r"www.google.com")
	assert not candidate(u"nntp://google.com")
	assert candidate(u"https://google.com/something") == True
	assert not candidate(u"news://google.com")
	assert not candidate(u"svn+ssh://google.com")
	assert candidate(
    "http://www.google.com/search?q=hello&btnG=Google+Search"
    )
	assert candidate("ftp://") == True
	assert candidate( "ftp://ftp.ncbi.nlm.nih.gov/pubchem/Compound_3D/01_conf_per_cmpd/SDF/" )
	assert candidate( "http://foo.com/bar.html" )
	assert candidate( "ftp://www.google.com/" )
	assert candidate("http://") is True
	assert candidate( "https://google.com/index.html" )
	assert candidate("https://www.google.com/file.html?query=string") == True
	assert candidate(r"HTTP://foo.com/bar")
	assert not candidate( "" )
	assert candidate(
    "https://www.google.com") == True
	assert candidate("ftp://www.google.com/file.html?query=string&another=string") == True
	assert candidate(r"http://www.google.com")
	assert not candidate( "www.google.com" )
	assert candidate("https://www.google.com/file.html?query=string&another=string") == True
	assert candidate(u"http://www.google.com")
	assert not candidate( "google.com" )
	assert not candidate( "file://www.google.com" )
	assert candidate( "https://www.google.com/" )
	assert candidate(u"http://google.com/something/else/more") == True
	assert not candidate(u"nfs://google.com")
	assert candidate( "ftp://somewhere.com/file.zip" )
	assert candidate("https://") is True
	assert not candidate("https:/")
	assert candidate(
    "http://www.google.com/search?q=hello+world")
	assert candidate( "httpswww.google.com" ) == False
	assert candidate( "www.google.com" ) == False
	assert candidate( "ftp://google.com" ) == True
	assert candidate( "ftp://ftp.ncbi.nih.gov" ) == True
	assert not candidate( "file://index.html" )
	assert candidate("https://www.google.com") == True
	assert candidate(
    "http://www.google.com") == True
	assert not candidate("google.com/search?q=hello+world")
	assert candidate(
    "https://google.com") == True
	assert candidate(u"ftp://www.google.com/")
	assert candidate("http://www.google.com/file.html?query=string") == True
	assert candidate(
    "https://www.google.com/index.html") == True
	assert not candidate( "file://google.com/index.html" )
	assert candidate(u"http://ftp.ncbi.nlm.nih.gov")
	assert candidate(u"https://www.google.com/")
	assert candidate(
    "google.com") == False
	assert candidate(
    "index.html") == False
	assert candidate("ftp://www.google.com/file.html") == True
	assert candidate( "google.com" ) == False
	assert candidate(u"ftp://google.com/something/else/more") == True
	assert candidate(u"http://google.com") == True
	assert not candidate("www.debian.org")
	assert candidate( "ftp://google.com/a/b/c" ) == True
	assert candidate("ftp://ftp.debian.org/debian/")
	assert not candidate( "file:///foo.com/bar.html" )
	assert candidate("") == False
	assert candidate(r"FTP://foo.com/bar")
	assert candidate( "file:///home/user/file" ) == False
	assert not candidate( "/foo.com/bar.html" )
	assert candidate( "https://www.google.com" ) == True
	assert not candidate( "file:///C:/home/user/file" )
	assert candidate( "ftp://google.com/index.html" )
	assert candidate(r"https://www.google.com")
	assert candidate(
    "ftp://www.google.com"
) == True, "candidate test failed"
	assert candidate("http://www.google.com") == True
	assert not candidate(u"bzr://google.com")
	assert candidate(
    "ftp://www.google.com/a/b/c"
) == True, "candidate test failed"
	assert candidate(u"ftp://www.google.com")
	assert candidate(u"ftp://google.com/something") == True
	assert candidate( "https://google.com" ) == True
	assert not candidate(r"C:\Program Files\Python36")
	assert candidate("http://www.google.com/file.html?query=string&another=string") == True
	assert candidate(
    "http://google.com") == True
	assert candidate(r"http://foo.com/bar")
	assert candidate(u"https://www.google.com/something") == True
	assert candidate( "ftp://ftp.google.com" )
	assert candidate(
    "http://www.google.com/a/b/c"
) == True, "candidate test failed"
	assert not candidate( "google" )
	assert not candidate(r"C:\Program Files\Python36\python.exe")
	assert not candidate(u"cvs://google.com")
	assert candidate(u"http://www.google.com/something") == True
	assert not candidate( "example.com" )
	assert candidate("ftp://ftp.ncbi.nlm.nih.gov/pubchem/Compound/")
	assert not candidate( "example.com/index.html" )
	assert not candidate( "somewhere.com/file.zip" )
	assert candidate(u"http://www.google.com/")
	assert candidate( "ftpftp.ncbi.nih.gov" ) == False
	assert candidate( "httpwww.google.com" ) == False
	assert candidate(
    "ftp://www.google.com/index.html") == True
	assert candidate(
    "http://www.google.com"
) == True, "candidate test failed"
	assert not candidate( "www.example.com" )
	assert candidate( "ftp://ftp.ncbi.nlm.nih.gov/blast/db/" )
	assert not candidate( "file.zip" )
	assert candidate(
    "/a/b/c"
) == False, "candidate test failed"
	assert candidate(
    "https://www.google.com/search?q=hello&btnG=Google+Search"
    )
	assert not candidate(r"https:/foo.com/bar")
	assert candidate("https://") == True
	assert candidate(
    "www.google.com"
) == False, "candidate test failed"
	assert candidate(
    "www.google.com/a/b/c"
) == False, "candidate test failed"
	assert candidate(
    "ftp://www.google.com") == True
	assert not candidate( "/home/user/file" )
	assert not candidate( "index.html" )
	assert candidate(u"http://www.google.com/something/else") == True
	assert candidate(r"https://foo.com/bar")
	assert candidate( "HTTPS://somewhere.com/file.zip" )
	assert not candidate(u"google.com")
	assert not candidate(r"ftp:/foo.com/bar")
	assert not candidate("ftp.debian.org")
	assert not candidate( "/index.html" )
	assert candidate(u"ftp://www.google.com") == True
	assert not candidate(u"file://google.com")
	assert candidate( "http://www.example.com" )
	assert candidate(u"https://www.google.com")
	assert candidate( "http://www.google.com/" )
	assert candidate(r"HTTPS://foo.com/bar")
	assert candidate(u"ftp://google.com/something/else") == True
	assert candidate(u"http://google.com")
	assert candidate(u"https://google.com") == True
	assert candidate(u"https://ftp.ncbi.nlm.nih.gov")
	assert not candidate(u"telnet://google.com")
	assert not candidate( "file:///home/user/file" )
	assert candidate( "https://somewhere.com/file.zip" )
	assert candidate(u"https://google.com")
	assert candidate( "http://google.com" ) == True
	assert candidate(u"https://google.com/something/else/more") == True
	assert candidate( "http://www.google.com" ) == True
	assert candidate( "HTTP://somewhere.com/file.zip" )
	assert candidate( "https://google.com" )
	assert candidate(u"ftp://www.google.com/something") == True
	assert not candidate(u"git+ssh://google.com")
	assert not candidate( "C:\\home\\user\\file" )
	assert candidate(
    "http://www.google.com/index.html") == True
	assert not candidate(u"ftps://google.com")
	assert candidate(r"ftp://foo.com/bar")
	assert candidate(u"https://www.google.com") == True
	assert not candidate("file://foo/bar/baz")
	assert candidate( "ftp://google.com" )
	assert candidate("abc http://") is False
	assert candidate( "ftp://www.google.com" ) == True
	assert candidate(u"http://google.com/something") == True
	assert candidate( "http://somewhere.com/file.zip" )
	assert candidate( "https://foo.com/bar.html" )
	assert not candidate(r"foo.com/bar")
	assert candidate(u"http://www.google.com") == True
	assert candidate( "ftp://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/nt.gz" )
	assert not candidate( "file:///tmp/x" )
	assert not candidate(u"wais://google.com")
	assert not candidate(u"sftp://google.com")
	assert not candidate(u"pop://google.com")
	assert not candidate("ftp.ncbi.nlm.nih.gov/pubchem/Compound/")
	assert candidate(u"ftp://google.com") == True
	assert candidate(r"ftp://www.google.com")
	assert not candidate(u"www.google.com")
	assert candidate(
    "google.com/a/b/c"
) == False, "candidate test failed"
	assert candidate(
    "www.google.com/index.html") == False
	assert candidate(
    "https://www.google.com/search?q=hello+world")
	assert candidate(
    "ftp://google.com") == True
	assert not candidate(u"prospero://google.com")
	assert candidate( "ftp://ftp.ncbi.nlm.nih.gov" )
	assert candidate(u"http://google.com/something/else") == True
	assert candidate(u"ftp://ftp.ncbi.nlm.nih.gov")
	assert not candidate("http:/")
def test_check():
	check(re_remote_url)
