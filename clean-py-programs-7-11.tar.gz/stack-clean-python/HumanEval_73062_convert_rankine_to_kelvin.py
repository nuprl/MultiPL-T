def convert_rankine_to_kelvin(temp):
    """Convert the temperature from Rankine to Kelvin scale.

    :param float temp: The temperature in degrees Rankine.
    :returns: The temperature in degrees Kelvin.
    :rtype: float
    """
    ### Canonical solution below ###
    return (temp * 5) / 9


### Unit tests below ###
def check(candidate):
	assert candidate(100) == 55.555555555555555
	assert candidate(0) == 0
	assert candidate(0) == 0.0
	assert candidate(491.67) == 273.15
	assert candidate(0.0) == 0.0
def test_check():
	check(convert_rankine_to_kelvin)
