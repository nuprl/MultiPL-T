def is_anagram(word1, word2):
    """ Receives two words and returns True/False (boolean) if word2 is
     an anagram of word1, ignore case and spacing.
     About anagrams: https://en.wikipedia.org/wiki/Anagram"""
	### Canonical solution below ###    
    
    # short way
    # word1 = word1.strip().replace(' ', '').lower()
    # word2 = word2.strip().replace(' ', '').lower()
    # return sorted(word1) == sorted(word2)
    
    # longer way
    word1 = word1.strip().replace(' ', '').lower()
    word2 = word2.strip().replace(' ', '').lower()
    
    if len(word1) != len(word2):
        return False
        
    count = {}
    
    for letter in word1:
        if letter in count:
            count[letter] += 1
        else:
            count[letter] = 1
            
    for letter in word2:
        if letter in count:
            count[letter] -= 1
        else:
            count[letter] = 1
            
    for c in count:
        if count[c] != 0:
            return False
    return True

### Unit tests below ###
def check(candidate):
	assert candidate(word1="A gentleman", word2="A gentlemans") == False
	assert candidate(word1='Time and tide wait for no man', word2='Notified madman into water') is True
	assert candidate(word1="Silent", word2="Listen") == True
	assert candidate( "rail safety", "fairy tales" )
	assert candidate( 'aabbcc', 'aacc' ) == False
	assert candidate( 'A gentleman', 'Elegant mAn' )
	assert not candidate( "abc", "ab" )
	assert candidate( "The eyes look for you", "The eyes for you") == False
	assert candidate( "a", "b") == False
	assert candidate( "Hello", "Ole Oh" ) == False
	assert candidate(word1 = "123", word2 = "12  ") == False
	assert candidate( 'aabbcc', 'aabbccdd' ) == False
	assert not candidate(word1="Not a gentleman", word2="Elegant man"), "Diff letters"
	assert candidate(word1 = "hi man", word2 = "hi     man") == True
	assert candidate( "Silent", "List") == False
	assert candidate( "The eyes look for you", "Look for eyes") == False
	assert candidate( "Silent", "Silent") == True
	assert not candidate( 'Hi there', 'Bye there' )
	assert candidate( "aabbcc", "aabbc" ) == False
	assert candidate(word1='Time and tide wait for no man.', word2='Notified madman into water.') == True
	assert not candidate( 'a', 'b' )
	assert candidate( 'A', 'a' )
	assert candidate(word1="A gentleman", word2="An Elegant man") == False
	assert candidate( "Listen!", "Silent") == False
	assert candidate( "Listen", "Silent!") == False
	assert candidate(word1='This is a string', word2='This is a striing') == False
	assert candidate( "go go go", "gggooo" )
	assert candidate(word1='Yo-yo', word2='yo-Yo') is True
	assert candidate(word1="A gentleman", word2="A lemans") == False
	assert candidate( "Dormitory", "Dirty room") == True
	assert candidate( "Dormitory", "Dirty room")
	assert candidate( "orchestra", "Orchestra") == True
	assert not candidate( 'Yo-yo', 'yoo-yo' )
	assert candidate( 'a', 'A' )
	assert candidate( "car", "rac" )
	assert candidate( "Listen", "Liten") == False
	assert candidate(word1 = "aabbcc", word2 = "aabbc") == False
	assert candidate( "A gentleman", "A man") == False
	assert candidate( 'a', 'a' )
	assert not candidate( "rat", "car" )
	assert not candidate( "hi", "bye" )
	assert candidate( 'aabbcc', 'aabbcc' ) == True
	assert candidate( "A gentleman", "A gentleman") == True
	assert candidate( "Slot machines", "Cash lost in me")
	assert candidate(word1='This is a string', word2='This is a string') == True
	assert candidate( "A", "B") == False
	assert candidate( 'A gentleman', 'Elegant men!' ) == False
	assert candidate( "banana", "ananan") == False
	assert candidate(word1="Listen", word2="Silent") == True
	assert candidate( "A gentleman", "Elegant men") == False
	assert candidate( 'Yo-yo', 'yo-yo' )
	assert candidate( "Listen", "Listen") == True
	assert candidate( "Listen", "Silent") == True
	assert not candidate( 'A gentleman', 'A gentlemen' )
	assert candidate( "Is this a string?", "This is a string?" )
	assert candidate(word1="Time and tide wait for no man", word2="Notified madman into water"), "Example"
	assert candidate( "Not a gentleman", "Elegant men" ) == False
	assert candidate( "Dormitory", "Dirty room" ) == True
	assert candidate( "The eyes look for you", "Lies for eyes") == False
	assert candidate(word1='rail safety', word2='fairy tales') is True
	assert not candidate( 'RAIL! SAFETY!', 'fairy tales' )
	assert candidate( "Listen!", "Listen") == False
	assert candidate( "Hi there", "Bye there" ) == False
	assert candidate(word1 = "abc", word2 = "cba") == True
	assert not candidate( 'Hi there', 'hi' )
	assert not candidate( "aabbcc", "aabcd" )
	assert candidate(word1 = "go go go", word2 = "gggooo") == True
	assert candidate( "aabbcc", "abbc" ) == False
	assert candidate(word1='rail safety', word2='fairy tales') == True
	assert candidate( "Silent", "Listen") == True
	assert candidate( "restful", "fluster") == True
	assert candidate( "Silent", "Listen!") == False
	assert candidate( 'rail safety', 'fairy tales' )
	assert candidate( 'rail safety', 'fairy tales' ) == True
	assert not candidate( 'aabbcc', 'aabbc' )
	assert not candidate( 'Yo dog', 'I do goo' )
	assert candidate(word1='This is a string', word2='This is not a string') == False
	assert candidate( 'aabbcc', 'bbcc' ) == False
	assert candidate( "Is this a string?", "Is a string? This" )
	assert candidate( "This is a string", "Is this a string" )
	assert candidate(word1 = "123", word2 = "1 2") == False
	assert candidate( 'This is a string', 'Is this a string!' ) == False
	assert candidate(word1="Listen", word2="Silent!") == False
	assert candidate( "Silent", "Listen")
	assert not candidate( "RAIL! SAFETY!", "fairy tales" )
	assert candidate( "School master", "The classroom" )
	assert candidate( 'aabbcc', 'aabbc' ) == False
	assert not candidate( "A gentleman", "Elegant woman" )
	assert candidate(word1='This is a string', word2='This is a strng') == False
	assert candidate(word1='Hi there', word2='Bye there') == False
	assert candidate( "Listen", "Listen!") == False
	assert candidate(word1="Silent", word2="Listen!") == False
	assert candidate( "clint eastwood", "old west action" ) == True
	assert candidate(word1='Yo-yo', word2='Oy-o') is False
	assert candidate( "Slot machines", "Cash lost in me" )
	assert candidate( "Sister", "Silent") == False
	assert candidate( "Orchestra", "Orchestra") == True
	assert not candidate( "hi man", "bye man" )
	assert candidate( "rail safety", "fairy tales" ) == True
	assert not candidate( "A gentleman", "A lemngent man" )
	assert candidate(word1='This is a string', word2='This is a string.') == False
	assert candidate( 'Hi there', 'hi   therE' )
	assert candidate( "Dormitory", "Dirty room" )
	assert not candidate(word1="Hello", word2="Ole Oh"), "Diff len"
	assert candidate( "aabbcc", "aabbcc" ) == True
	assert candidate( "Time and tide wait for no man", "Notified madman into water") == True
	assert candidate( "Dormitory", "Dirty room!") == False
	assert not candidate( "A gentleman", "Elegant men")
	assert candidate( "Elbow", "Below" )
	assert candidate( 'Time and tide wait for no man', 'Notified madman into water' ) == True
	assert candidate( "banana", "ananab") == True
	assert candidate( "rat", "art" )
	assert not candidate( 'Yo-yo', 'no lemon, no melon' )
	assert candidate( 'Hi there', 'Bye there' ) == False
	assert candidate( 'This is a string', 'Is this a string.' ) == False
	assert candidate(word1 = "Time and tide wait for no man", word2 = "Notified madman into water") == True
	assert candidate( "Old MacDonald had a farm", "Farm had a Old MacDonald" )
	assert not candidate( "A gentleman", "Elegant men" )
	assert candidate( "hi man", "hi     man" )
	assert candidate( "Not a gentleman", "Not a men") == False
	assert candidate( "Time and tide wait for no man", "Notified madman into water" )
	assert candidate( "Not a gentleman", "Elegant men") == False
	assert candidate(word1='Hi there', word2='Bye there') is False
def test_check():
	check(is_anagram)
