def notas(*n, sit=False):
    """ 
     -> Funcao para analisar notas e situacoes de alunos
     :param n: uma ou mais notas de alunos
     :param sit: valor opcional, indicando se deve ou nao adicionar a situacao
     :return: dicionario com varias informacoes sobre a situacao da turma
     """
	### Canonical solution below ###    
    r = dict()
    r['total'] = len(n)
    r['maior'] = max(n)
    r['menor'] = min(n)
    r['media'] = sum(n)/len(n)
    if sit:
        if r['media'] >= 7:
            r['situacao'] = 'BOA'
        elif r['media'] >= 5:
            r['situacao'] = 'RAZOAVEL'
        else:
            r['situacao'] = 'RUIM'
    return r

### Unit tests below ###
def check(candidate):
	assert candidate(10, 10, 10, 10, sit=True) == {'total': 4,'maior': 10,'menor': 10,'media': 10.0,'situacao': 'BOA'}
	assert candidate(2.5, 2.5, 2.5, sit=True) == {'total': 3,'maior': 2.5,'menor': 2.5,'media': 2.5,'situacao': 'RUIM'}
	assert candidate(2.5, 5.5, 5.5, sit=True) == {'total': 3,'maior': 5.5,'menor': 2.5,'media': 4.5,'situacao': 'RUIM'}
	assert candidate(1.5, 2.5, 3.5, sit=True) == {'total': 3,'maior': 3.5,'menor': 1.5,'media': 2.5,'situacao': 'RUIM'}
	assert candidate(10, 10, 10, sit=True) == {'total': 3,'maior': 10,'menor': 10,'media': 10.0,'situacao': 'BOA'}
	assert candidate(2.5, 2.5, 2.5) == {'total': 3,'maior': 2.5,'menor': 2.5,'media': 2.5}
	assert candidate(2.5, 2.5, 2.5) == {'total': 3,'maior': 2.5,'menor': 2.5,'media': 2.5}, 'Funcao candidate nao esta funcionando corretamente'
	assert candidate(2.5, 2.5, 2.5, 2.5, sit=True) == {'total': 4,'maior': 2.5,'menor': 2.5,'media': 2.5,'situacao': 'RUIM'}
	assert candidate(2.5, 2.5, 2.5, 2.5) == {'total': 4,'maior': 2.5,'menor': 2.5,'media': 2.5}
def test_check():
	check(notas)
