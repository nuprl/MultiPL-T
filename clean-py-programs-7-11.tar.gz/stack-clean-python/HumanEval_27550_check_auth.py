def check_auth(username, password):
    """ This function is called to check if a username /
     password combination is valid.
     """
	### Canonical solution below ###    
    return username == 'admin' and password == 'admin'

### Unit tests below ###
def check(candidate):
	assert candidate('foo', 'admin') == False
	assert candidate('admin', 'not_admin') is False
	assert candidate('wrong', 'admin') == False
	assert candidate('wrong username', 'wrong password') == False
	assert candidate('not_admin', 'admin') is False
	assert candidate('user', 'admin') == False
	assert candidate('admin', 'foo') == False
	assert candidate('admin', 'user') == False
	assert candidate('admin', 'admin') == True
	assert candidate('admin', 'wrong password') == False
	assert candidate('admin', 'not-admin') == False
	assert candidate('admin', 'not_admin') == False
	assert candidate(None, None) == False
	assert candidate('admin', 'wrong') is False
	assert not candidate(username='admin', password='<PASSWORD>')
	assert candidate(username='admin1', password='<PASSWORD>') is False
	assert candidate('', '') is False
	assert candidate(None, 'admin') == False
	assert candidate('wrong user', 'admin') == False
	assert candidate('admin', 'wrong') == False
	assert candidate('admin', 'admin') is True
	assert candidate(None, None) is False
	assert candidate('admin', 'not admin') == False
	assert candidate('wrong', 'wrong') == False
	assert candidate('not admin', 'admin') == False
	assert candidate('wrong', 'admin') is False
	assert candidate('admin', None) == False
	assert candidate('not_admin', 'admin') == False
	assert candidate('not-admin', 'admin') == False
	assert candidate('wrong username', 'admin') == False
	assert candidate(username='admin', password='<PASSWORD>') == False
	assert not candidate(username='user', password='<PASSWORD>')
	assert candidate(username='admin', password='<PASSWORD>') is False
def test_check():
	check(check_auth)
