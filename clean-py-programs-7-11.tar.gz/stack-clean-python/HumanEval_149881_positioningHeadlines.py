def positioningHeadlines(headlines):
    """ 
     Strips unnecessary whitespaces/tabs if first header is not left-aligned
     """
	### Canonical solution below ###    
    left_just = False
    for row in headlines:
        if row[-1] == 1:
            left_just = True
            break
    if not left_just:
        for row in headlines:
            row[-1] -= 1
    return headlines

### Unit tests below ###
def check(candidate):
	assert candidate(
    [[1, 'a', 0], [1, 'b', 1], [1, 'c', 2]]) == [[1, 'a', 0], [1, 'b', 1], [1, 'c', 2]]
	assert candidate(
    [["", "Heading 1", "Heading 2", "Heading 3", "Heading 4"],
     ["", 1, 1, 1, 1],
     ["", 1, 1, 1, 1],
     ["", 1, 1, 1, 1],
     ["", 1, 1, 1, 1],
     ["", 1, 1, 1, 1]]
) == [["", "Heading 1", "Heading 2", "Heading 3", "Heading 4"],
      ["", 1, 1, 1, 1],
      ["", 1, 1, 1, 1],
      ["", 1, 1, 1, 1],
      ["", 1, 1, 1, 1],
      ["", 1, 1, 1, 1]]
	assert candidate( [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3]] ) == [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3]]
	assert candidate( [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3], [4, 4, 4, 4], [5, 5, 5, 5]] ) == [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3], [4, 4, 4, 4], [5, 5, 5, 5]]
	assert candidate(
    [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3], [4, 4, 4, 4]]) == [
        [1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3], [4, 4, 4, 4]]
	assert candidate(
    [["", "Heading 1", "Heading 2", "Heading 3", "Heading 4"],
     ["", 1, 1, 1, 1],
     ["", 1, 1, 1, 1],
     ["", 1, 1, 1, 1],
     ["", 1, 1, 1, 1]]
) == [["", "Heading 1", "Heading 2", "Heading 3", "Heading 4"],
      ["", 1, 1, 1, 1],
      ["", 1, 1, 1, 1],
      ["", 1, 1, 1, 1],
      ["", 1, 1, 1, 1]]
	assert candidate(
    [['abc', 'abc', 1], ['abc', 'abc', 1], ['abc', 'abc', 1]]) == [['abc', 'abc', 1], ['abc', 'abc', 1], ['abc', 'abc', 1]]
	assert candidate( [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3], [4, 4, 4, 4]] ) == [[1, 1, 1, 1], [2, 2, 2, 2], [3, 3, 3, 3], [4, 4, 4, 4]]
	assert candidate(
    [[0, 1, 0], [0, 1, 1], [1, 1, 0]]) == [[0, 1, 0], [0, 1, 1], [1, 1, 0]]
	assert candidate(
    [['abc', 'abc', 2], ['abc', 'abc', 2], ['abc', 'abc', 2]]) == [['abc', 'abc', 1], ['abc', 'abc', 1], ['abc', 'abc', 1]]
	assert candidate(
    [['a', 'b', 'c', 1], ['d', 'e', 'f', 2], ['g', 'h', 'i', 3]]) == [['a', 'b', 'c', 1], ['d', 'e', 'f', 2], ['g', 'h', 'i', 3]]
	assert candidate(
    [['a', 'b', 'c', 2], ['d', 'e', 'f', 3], ['g', 'h', 'i', 4]]) == [['a', 'b', 'c', 1], ['d', 'e', 'f', 2], ['g', 'h', 'i', 3]]
def test_check():
	check(positioningHeadlines)
