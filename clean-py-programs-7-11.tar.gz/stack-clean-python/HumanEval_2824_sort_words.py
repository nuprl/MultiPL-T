def sort_words(arguments, words):
    """
    Takes a dict of command line arguments and a list of words to be sorted.
    Returns a sorted list based on `alphabetical`, `length` and `reverse`.
    """
    ### Canonical solution below ###
    if arguments.get('--alphabetical', False):
        words.sort()
    elif arguments.get('--length', False):
        words.sort(key=len)

    if arguments.get('--reverse', False):
        words.reverse()

    return words


### Unit tests below ###
def check(candidate):
	assert candidate(dict(alphabetical=False), ['c', 'a', 'b']) == ['c', 'a', 'b']
	assert candidate(
    {'--alphabetical': True}, ['cat', 'dog', 'apple', 'banana']) == [
    'apple', 'banana', 'cat', 'dog']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': False},
    ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(dict(alphabetical=True), ['abc', 'def', 'ghi']) == ['abc', 'def', 'ghi']
	assert candidate(dict(length=True), ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(dict(), ['a', 'ab', 'b']) == ['a', 'ab', 'b']
	assert candidate(
    {'--alphabetical': True},
    ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(
    {'--alphabetical': True, '--length': True},
    ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(
    {
        '--alphabetical': False,
        '--length': False,
        '--reverse': True
    },
    ['a', 'b', 'c', 'd']
) == ['d', 'c', 'b', 'a']
	assert candidate(
    {'--alphabetical': True, '--length': True, '--reverse': True},
    ['cat', 'dog','mouse', 'rat', 'tiger', 'zebra']
) == ['zebra', 'tiger', 'rat','mouse', 'dog', 'cat']
	assert candidate(dict(), []) == []
	assert candidate(
    {'--alphabetical': True, '--length': False, '--reverse': False},
    ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(dict(), ['a', 'ab']) == ['a', 'ab']
	assert candidate(dict(alphabetical=True), ['apple', 'banana', 'cucumber']) == ['apple', 'banana', 'cucumber']
	assert candidate(
    {'--alphabetical': True, '--length': False, '--reverse': False},
    ['a', 'apple', 'b', 'banana', 'c', 'carrot']
) == ['a', 'apple', 'b', 'banana', 'c', 'carrot']
	assert candidate(dict(alphabetical=False), ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': True},
    ['a', 'b', 'c']) == ['c', 'b', 'a']
	assert candidate(dict(alphabetical=True), ['abc', 'def', 'ghi', 'jkl']) == ['abc', 'def', 'ghi', 'jkl']
	assert candidate(dict(length=True, reverse=True), ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': False},
    ['cat', 'dog','mouse', 'rat', 'tiger', 'zebra']
) == ['cat', 'dog','mouse', 'rat', 'tiger', 'zebra']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': True},
    ['a', 'b', 'c', 'd']) == ['d', 'c', 'b', 'a']
	assert candidate(dict(length=True, reverse=True), ['one', 'two', 'three']) == ['one', 'two', 'three']
	assert candidate(
    {
        '--alphabetical': True,
        '--length': False,
        '--reverse': False
    },
    ['a', 'b', 'c', 'd']
) == ['a', 'b', 'c', 'd']
	assert candidate(dict(length=True, alphabetical=True), ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(
    {'--alphabetical': True, '--length': True, '--reverse': True},
    ['a', 'b', 'c', 'd']) == ['d', 'c', 'b', 'a']
	assert candidate(
    {'--alphabetical': True, '--length': True, '--reverse': True},
    ['apple', 'banana', 'orange', 'pear']) == \
    ['pear', 'orange', 'banana', 'apple']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': False},
    ['apple', 'banana', 'orange', 'pear']) == \
    ['apple', 'banana', 'orange', 'pear']
	assert candidate(dict(length=True, reverse=True), ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(
    {'--alphabetical': True, '--reverse': True},
    ['a', 'b', 'c']) == ['c', 'b', 'a']
	assert candidate(dict(alphabetical=True), ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(
    {'--alphabetical': True, '--length': True, '--reverse': True},
    ['a', 'b', 'c']) == ['c', 'b', 'a']
	assert candidate(dict(), ['a', 'b']) == ['a', 'b']
	assert candidate(
    {
        '--alphabetical': True,
        '--length': True,
        '--reverse': True
    },
    ['a', 'b', 'c', 'd']
) == ['d', 'c', 'b', 'a']
	assert candidate(dict(), ['hello', 'world']) == ['hello', 'world']
	assert candidate(dict(length=True), ['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']
	assert candidate(dict(), ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(dict(length=True), ['ghi', 'abc', 'def']) == ['ghi', 'abc', 'def']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': True},
    ['cat', 'dog','mouse', 'rat', 'tiger', 'zebra']
) == ['zebra', 'tiger', 'rat','mouse', 'dog', 'cat']
	assert candidate(dict(alphabetical=True), ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(dict(length=True, alphabetical=True, reverse=True), ['c', 'b', 'a']) == ['c', 'b', 'a']
	assert candidate(
    {'--alphabetical': True, '--length': False, '--reverse': True},
    ['apple', 'banana', 'orange', 'pear']) == \
    ['pear', 'orange', 'banana', 'apple']
	assert candidate(
    {'--alphabetical': True, '--length': False, '--reverse': False},
    ['apple', 'banana', 'orange', 'pear']) == \
    ['apple', 'banana', 'orange', 'pear']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': False},
    ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(dict(length=False), ['c', 'a', 'b']) == ['c', 'a', 'b']
	assert candidate(
    {'--alphabetical': True, '--length': False, '--reverse': False},
    ['cat', 'dog','mouse', 'rat', 'tiger', 'zebra']
) == ['cat', 'dog','mouse', 'rat', 'tiger', 'zebra']
	assert candidate(dict(length=True), ['ghi', 'abc', 'def', 'jkl']) == ['ghi', 'abc', 'def', 'jkl']
	assert candidate(
    {'--alphabetical': True, '--length': False, '--reverse': True},
    ['python', 'java', 'kotlin', 'javascript']
) == ['python', 'kotlin', 'javascript', 'java']
	assert candidate(
    {'--alphabetical': True, '--length': False, '--reverse': True},
    ['a', 'b', 'c', 'd']) == ['d', 'c', 'b', 'a']
	assert candidate(dict(), ['apple', 'banana', 'cucumber']) == ['apple', 'banana', 'cucumber']
	assert candidate(dict(length=False), ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(
    {'--alphabetical': False, '--length': False, '--reverse': True},
    ['apple', 'banana', 'orange', 'pear']) == \
    ['pear', 'orange', 'banana', 'apple']
	assert candidate(
    {'--alphabetical': True, '--reverse': True},
    ['cat', 'dog', 'apple', 'banana']) == ['dog', 'cat', 'banana', 'apple']
	assert candidate(dict(alphabetical=True), ['cat', 'dog','moose']) == ['cat', 'dog','moose']
	assert candidate(dict(alphabetical=True, length=False, reverse=False),
                  ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(
    {'--alphabetical': False, '--length': True, '--reverse': False},
    ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(dict(), ['cat', 'dog','moose']) == ['cat', 'dog','moose']
	assert candidate(dict(alphabetical=True), ['hello', 'world']) == ['hello', 'world']
	assert candidate(
    {
        '--alphabetical': False,
        '--length': False,
        '--reverse': False
    },
    ['a', 'b', 'c', 'd']
) == ['a', 'b', 'c', 'd']
	assert candidate(dict(length=True, reverse=True), ['z', 'y', 'x']) == ['z', 'y', 'x']
	assert candidate(dict(reverse=False), ['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
	assert candidate(dict(length=True, alphabetical=True), ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(dict(reverse=False), ['one', 'two', 'three']) == ['one', 'two', 'three']
	assert candidate(
    {'--alphabetical': True, '--length': True, '--reverse': False},
    ['a', 'apple', 'b', 'banana', 'c', 'carrot']
) == ['a', 'apple', 'b', 'banana', 'c', 'carrot']
	assert candidate(dict(reverse=False, length=False), ['c', 'a', 'b']) == ['c', 'a', 'b']
	assert candidate(dict(), ['a', 'ab', 'b', 'ba']) == ['a', 'ab', 'b', 'ba']
	assert candidate(dict(), ['abc', 'def', 'ghi']) == ['abc', 'def', 'ghi']
	assert candidate(dict(), ['abc', 'def', 'ghi', 'jkl']) == ['abc', 'def', 'ghi', 'jkl']
	assert candidate(dict(), ['a', 'b', 'c']) == ['a', 'b', 'c']
def test_check():
	check(sort_words)
