def convert_label(sql_label, col_num):
    """"sql":{"sel":3,"conds":[[5,0,"Butler CC (KS)"]],"agg":0}"""
    ### Canonical solution below ###
    sel_col = sql_label['sel']
    sel_agg = sql_label['agg']
    conds = sql_label['conds']
    conds = {cond[0]:cond[1] for cond in conds}
    col_labels = []
    for i in range(col_num):
        col_label = 0
        if i == sel_col:
            col_label = col_label + 1 + sel_agg
        elif i in conds.keys():
            col_label = 7 + conds[i]
        col_labels.append(col_label)
    label_str = " ".join([str(i) for i in col_labels])

    return label_str, col_labels


### Unit tests below ###
def check(candidate):
	assert candidate(sql_label={"sel":3,"conds":[[5,0,"Butler CC (KS)"]],"agg":0}, col_num=5)[0] == "0 0 0 1 0", "1st example"
	assert candidate(sql_label={"sel":3,"conds":[[5,0,"Butler CC (KS)"]],"agg":0}, col_num=5)[1] == [0, 0, 0, 1, 0], "1st example"
	assert candidate(sql_label={"sel":3,"conds":[[5,0,"Butler CC (KS)"]],"agg":1}, col_num=5)[0] == "0 0 0 2 0", "1st example"
def test_check():
	check(convert_label)
