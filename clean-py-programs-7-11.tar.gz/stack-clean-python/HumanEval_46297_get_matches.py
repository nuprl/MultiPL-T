def get_matches(match_dict):
    """Create a set of match name and value tuples"""
    ### Canonical solution below ###
    return {(entry['OXMTlv']['field'], entry['OXMTlv']['value']) for entry in match_dict}


### Unit tests below ###
def check(candidate):
	assert candidate(
    [{'OXMTlv': {'field': 'IPV4_DST', 'value': '10.0.0.1'}},
     {'OXMTlv': {'field': 'IPV4_DST', 'value': '10.0.0.2'}},
     {'OXMTlv': {'field': 'IPV4_DST', 'value': '10.0.0.3'}}]) == {('IPV4_DST', '10.0.0.1'), ('IPV4_DST', '10.0.0.2'), ('IPV4_DST', '10.0.0.3')}
	assert candidate(
    [{'OXMTlv': {'field': 'IPV4_DST', 'value': '10.0.0.1'}},
     {'OXMTlv': {'field': 'IPV4_DST', 'value': '10.0.0.2'}}]) == {('IPV4_DST', '10.0.0.1'), ('IPV4_DST', '10.0.0.2')}
	assert candidate(dict()) == set()
	assert candidate({}) == set()
	assert candidate(
    [
        {
            'OXMTlv': {
                'field': '1',
                'value': '0x0000000000000000/0x0000000000000000'
            }
        },
        {
            'OXMTlv': {
                'field': '2',
                'value': '0x0000000000000000/0x0000000000000000'
            }
        }
    ]
) == {('1', '0x0000000000000000/0x0000000000000000'),
      ('2', '0x0000000000000000/0x0000000000000000')}
def test_check():
	check(get_matches)
