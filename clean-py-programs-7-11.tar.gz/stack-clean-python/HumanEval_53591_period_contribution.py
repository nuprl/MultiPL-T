def period_contribution(x):
    """
    Turns period--1, 2, 3, OT, etc--into # of seconds elapsed in game until start.
    :param x: str or int, 1, 2, 3, etc
    :return: int, number of seconds elapsed until start of specified period
    """
    ### Canonical solution below ###
    try:
        x = int(x)
        return 1200 * (x - 1)
    except ValueError:
        return 3600 if x == 'OT' else 3900


### Unit tests below ###
def check(candidate):
	assert candidate(8) == 8400
	assert candidate(12) == 13200
	assert candidate(19) == 21600
	assert candidate(14) == 15600
	assert candidate(4) == 3600
	assert candidate(2) == 1200
	assert candidate(25) == 28800
	assert candidate(10) == 10800
	assert candidate(3) == 2400
	assert candidate(6) == 6000
	assert candidate(24) == 27600
	assert candidate(1) == 0
	assert candidate('OT') == 3600
	assert candidate(16) == 18000
	assert candidate(23) == 26400
	assert candidate(13) == 14400
	assert candidate(20) == 22800
	assert candidate(18) == 20400
	assert candidate(7) == 7200
	assert candidate('SO') == 3900
	assert candidate(21) == 24000
	assert candidate(15) == 16800
	assert candidate(9) == 9600
	assert candidate(26) == 30000
	assert candidate(17) == 19200
	assert candidate(22) == 25200
	assert candidate('SO2') == 3900
	assert candidate(11) == 12000
	assert candidate(5) == 4800
def test_check():
	check(period_contribution)
