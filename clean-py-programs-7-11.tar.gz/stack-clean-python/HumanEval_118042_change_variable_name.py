def change_variable_name(text):
    """ 
     doc
     :param text:
     :return:
     """
	### Canonical solution below ###    
    lst = []
    for index, char in enumerate(text):
        if char.isupper() and index != 0:
            lst.append("_")
        lst.append(char)
    return "".join(lst).lower()

### Unit tests below ###
def check(candidate):
	assert candidate(
    "VariableName") == "variable_name", "Variable Name example"
	assert candidate(
    "variable__name") == "variable__name", "There is a problem with variable__name"
	assert candidate(text="myVar2") == "my_var2"
	assert candidate(
    "variableName123") == "variable_name123", "There is a problem with variableName123"
	assert candidate(
    "TheRainInSpain") == "the_rain_in_spain", "Variable names should be separated by underscores"
	assert candidate(text="TestVariable") == "test_variable", "First"
	assert candidate("Variable_name") == "variable_name", "variable_name"
	assert candidate(
    "VariableName") == "variable_name", "VariableName is not correct"
	assert candidate("camelCase"), "Second"
	assert candidate("variable_name") == "variable_name", "variable_name example"
	assert candidate(text="myvar") == "myvar"
	assert candidate(text="var_name") == "var_name"
	assert candidate(
    "variable_name") == "variable_name", "Already in proper format"
	assert candidate(text="TestVariable2") == "test_variable2", "Second"
	assert candidate(text="MyVar") == "my_var"
	assert candidate(text="camel_case") == "camel_case"
	assert candidate(text="VarName") == "var_name"
	assert candidate(
    "Variable_name") == "variable_name"
	assert candidate("Variable_name") == "variable_name"
	assert candidate(
    "A1234567890") == "a1234567890", "Variable names should not be changed"
	assert candidate("camelCase") == "camel_case", "camelCase failed"
	assert candidate(
    "variable_name") == "variable_name", "variable_name is not correct"
	assert candidate(text="VariableName") == "variable_name", "Fifth"
	assert candidate(text="PascalCase") == "pascal_case"
	assert candidate(text="camel2Case") == "camel2_case"
	assert candidate("variableName") == "variable_name"
	assert candidate(
    "Variable_name"
) == "variable_name", "Forth"
	assert candidate(
    "__variableName") == "__variable_name", "Start with two underscores"
	assert candidate(
    "variable__name_") == "variable__name_", "There is a problem with variable__name_"
	assert candidate(text="Variable") == "variable", "Fourth"
	assert candidate("variableNameK12") == "variable_name_k12"
	assert candidate(
    "myVariable_name") == "my_variable_name", "Underscore"
	assert candidate("snake2kebab") == "snake2kebab", "snake2kebab failed"
	assert candidate(
    "variable__name_1") == "variable__name_1", "There is a problem with variable__name_1"
	assert candidate(
    "variableName") == "variable_name", "variableName is not correct"
	assert candidate(
    "variableName") == "variable_name", "First lower case"
	assert candidate(
    "VariableName") == "variable_name", "First"
	assert candidate(
    "camelCase") == "camel_case", "camelCase failed"
	assert candidate(
    "Variable_name") == "variable_name", "Fourth"
	assert candidate(
    "variable_name_1") == "variable_name_1", "There is a problem with variable_name_1"
	assert candidate(
    "CamelCase"
) == "camel_case", "First"
	assert candidate("camel2snake") == "camel2snake", "camel2snake failed"
	assert candidate(
    "variable_name") == "variable_name"
	assert candidate(
    "variableName1") == "variable_name1", "There is a problem with variableName1"
	assert candidate("get2HTTPResponseCodeXYZ2"), "Eleventh"
	assert candidate("variableNameK1") == "variable_name_k1"
	assert candidate(
    "variableName") == "variable_name", "There is a problem with variableName"
	assert candidate(
    "variableName"
) == "variable_name", "First"
	assert candidate(
    "variable_name123") == "variable_name123", "Forth"
	assert candidate(
    "variableName") == "variable_name"
	assert candidate(text="VariableName") == "variable_name"
	assert candidate("get2HTTPResponseCode"), "Sixth"
	assert candidate(
    "variable__name_12")
	assert candidate(
    "variableName") == "variable_name", "First"
	assert candidate("snake2screaming_snake") == "snake2screaming_snake", "snake2screaming_snake failed"
	assert candidate(
    "variable_name") == "variable_name", "Third"
	assert candidate("VariableNameK") == "variable_name_k"
	assert candidate(text='camelCase') == 'camel_case'
	assert candidate("variableName") == "variable_name", "Variable name"
	assert candidate(text="varName") == "var_name"
	assert candidate("get2HTTPResponseCodeXYZ"), "Ninth"
	assert candidate(
    "the_rain_in_spain") == "the_rain_in_spain", "Variable names should be separated by underscores"
	assert candidate(text="CamelCase") == "camel_case"
	assert candidate("camel2Camel2Case"), "Fourth"
	assert candidate("camelCase") == "camel_case", "camelCase test failed"
	assert candidate(
    "CamelCase") == "camel_case", "camelCase test failed"
	assert candidate(text="my-var") == "my-var"
	assert candidate(text="camelCamelCase") == "camel_camel_case"
	assert candidate("getHTTPResponseCode"), "Fifth"
	assert candidate("variable_name") == "variable_name"
	assert candidate(text="myVar") == "my_var"
	assert candidate(
    "variableName") == "variable_name", "Second"
	assert candidate(text="camel2snake") == "camel2snake"
	assert candidate(
    "variable_name"
) == "variable_name", "Third"
	assert candidate(
    "VariableName") == "variable_name", "All lower case"
	assert candidate("HTTPResponseCodeXYZ"), "Eight"
	assert candidate(text='CamelCase') == 'camel_case'
	assert candidate("CAMELCase"), "Third"
	assert candidate(text="camelCase") == "camel_case"
	assert candidate("PascalCase") == "pascal_case", "PascalCase failed"
	assert candidate(
    "variableName1"
) == "variable_name1", "Second"
	assert candidate("variable_name") == "variable_name", "Variable_name"
	assert candidate(
    "_myVariableName") == "_my_variable_name", "Start with underscore"
	assert candidate(text="my_var") == "my_var"
	assert candidate(
    "my_variable_name") == "my_variable_name", "Already in proper format"
	assert candidate(
    "myVariableName") == "my_variable_name", "Simple"
	assert candidate("snake2camel") == "snake2camel", "snake2camel failed"
	assert candidate(text="variableName") == "variable_name"
	assert candidate(text="variable") == "variable", "Third"
	assert candidate(
    "variableName123") == "variable_name123", "Third"
	assert candidate(
    "variableName12") == "variable_name12", "There is a problem with variableName12"
	assert candidate(text="snake_case") == "snake_case"
	assert candidate("HTTPResponseCodeXYZ2"), "Tenth"
	assert candidate(
    "variable_name_") == "variable_name_", "There is a problem with variable_name_"
	assert candidate(
    "MyVariableName") == "my_variable_name", "MyVariableName is not correct"
	assert candidate(
    "variable_name_12") == "variable_name_12", "There is a problem with variable_name_12"
	assert candidate("variableName") == "variable_name", "variableName example"
	assert candidate(text='camel2Camel') == 'camel2_camel'
	assert candidate(
    "VariableName") == "variable_name"
	assert candidate(text="camel2Camel") == "camel2_camel"
	assert candidate("variableNameK") == "variable_name_k"
	assert candidate(text="my var") == "my var"
	assert candidate(
    "myVariableName2") == "my_variable_name2", "Two uppercase letters"
	assert candidate(
    "variable_name") == "variable_name", "Second"
	assert candidate("snake_case") == "snake_case", "snake_case failed"
	assert candidate(
    "Variable_name") == "variable_name", "Forth"
	assert candidate(
    "variableName") == "variable_name", "Start with lowercase"
	assert candidate(
    "VariableName") == "variable_name", "There is a problem with VariableName"
	assert candidate("HTTPResponseCode"), "Seventh"
	assert candidate(
    "variable_name") == "variable_name", "There is a problem with variable_name"
	assert candidate("HTTPResponseCodeXYZ23"), "Twelfth"
	assert candidate(
    "VariableName") == "variable_name", "variable name"
	assert candidate(
    "myVariable__name") == "my_variable__name", "Two underscores in a row"
def test_check():
	check(change_variable_name)
