def sign(a: int) -> int:
    """ Returns the sign of a """
	### Canonical solution below ###    
    return 0 if a == 0 else (-1 if a < 0 else 1)

### Unit tests below ###
def check(candidate):
	assert candidate(-12) == -1
	assert candidate(5) == 1
	assert candidate(-123) == -1
	assert candidate(-123.456) == -1
	assert candidate(-1.23) == -1
	assert candidate(-100.0) == -1
	assert candidate(3.14) == 1
	assert candidate(100.0) == 1
	assert candidate(123) == 1
	assert candidate(5.0) == 1
	assert candidate(-1.0) == -1
	assert candidate(0.123) == 1
	assert candidate(34) == 1
	assert candidate(-3) == -1
	assert candidate(-1) == -1
	assert candidate(-0.0) == 0
	assert candidate(1.23) == 1
	assert candidate(-5.123) == -1
	assert candidate(-1.2) == -1
	assert candidate(-5.6) == -1
	assert candidate(1.0) == 1
	assert candidate(100.5) == 1
	assert candidate(-100.5) == -1
	assert candidate(-0.1) == -1
	assert candidate(1e500) == 1
	assert candidate(1) == 1
	assert candidate(-100) == -1
	assert candidate(-10) == -1
	assert candidate(-5) == -1
	assert candidate(3) == 1
	assert candidate(-5.0) == -1
	assert candidate(2) == 1
	assert candidate(0.1) == 1
	assert candidate(10000000) == 1
	assert candidate(10) == 1
	assert candidate(123.456) == 1
	assert candidate(5.6) == 1
	assert candidate(100) == 1
	assert candidate(1.2) == 1
	assert candidate(-0.123) == -1
	assert candidate(0.987) == 1
	assert candidate(-1e500) == -1
	assert candidate(5.123) == 1
	assert candidate(0.0) == 0
	assert candidate(-2) == -1
	assert candidate(-0.987) == -1
	assert candidate(-3.14) == -1
	assert candidate(0) == 0
def test_check():
	check(sign)
