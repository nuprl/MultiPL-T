def WordStartingAt( str, x ):
    """ Return the word in the given string starting at the given position"""
	### Canonical solution below ###  
  return str[ x : str.index( ' ', x+1 ) ]

### Unit tests below ###
def check(candidate):
	assert candidate( 'the quick brown fox', 4 ) == 'quick'
	assert candidate( 'hello world', 0 ) == 'hello'
	assert candidate( "a b c", 0 ) == "a"
	assert candidate( "This is a test", 5 ) == "is"
	assert candidate( 'one two three', 0 ) == 'one'
	assert candidate( "Hello world", 0 ) == "Hello"
	assert candidate( 'word word word', 5 ) == 'word'
	assert candidate( 'Hello World', 0 ) == 'Hello'
	assert candidate( "abc def ghi", 0 ) == "abc"
	assert candidate( 'word starting at zero', 0 ) == 'word'
	assert candidate( "hello world", 0 ) == "hello"
	assert candidate( 'This is a test', 8 ) == 'a'
	assert candidate( 'word word', 0 ) == 'word'
	assert candidate( "a b c d", 0 ) == "a"
	assert candidate( "a b", 0 ) == "a"
	assert candidate( "This is a test", 8 ) == "a"
	assert candidate( 'a b c', 0 ) == 'a'
	assert candidate( 'one two three', 4 ) == 'two'
	assert candidate( 'a b', 0 ) == 'a'
	assert candidate( "hi there", 0 ) == "hi"
	assert candidate( "This is a test", 0 ) == "This"
	assert candidate( 'word word word', 0 ) == 'word'
	assert candidate( 'This is a test', 0 ) == 'This'
	assert candidate( "hello there", 0 ) == "hello"
	assert candidate( 'This is a test', 5 ) == 'is'
def test_check():
	check(WordStartingAt)
