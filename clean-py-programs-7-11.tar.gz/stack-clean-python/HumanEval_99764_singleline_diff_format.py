def singleline_diff_format(line1, line2, idx):
    """ 
     Inputs:
     line1 - first single line string
     line2 - second single line string
     idx   - index at which to indicate difference
     Output:
     Returns a three line formatted string showing the location
     of the first difference between line1 and line2.
     
     If either input line contains a newline or carriage return,
     then returns an empty string.
     
     If idx is not a valid index, then returns an empty string.
     """
	### Canonical solution below ###    
    
    strng = ""
 
    if "/n" in line1 or "/r" in line1 or "/n" in line2 or "/r" in line2:
        return ""
    elif (idx > len(line1) or idx > len(line2)) or idx < 0:
        return ""
    else:
        for counter in range(idx):
            strng += "="
            counter += 0
   
    strng += "^"
 
    return f"{line1}\n{strng}\n{line2}\n"

### Unit tests below ###
def check(candidate):
	assert candidate(line1="abc", line2="def", idx=-3) == ""
	assert candidate(line1 = "This is a test",
                              line2 = "This is another test",
                              idx = 20) == ""
	assert candidate(
    "Hello world",
    "Hello World",
    -1
) == ""
	assert candidate(
    "This is a test", "This is a test", -1) == ""
	assert candidate(line1="01234567890", line2="01234567891", idx=-1) == ""
	assert candidate(
    "line1", "line2", -1) == "", "candidate 6"
	assert candidate(line1="abc", line2="def", idx=5) == ""
	assert candidate(line1 = "abc", line2 = "abc", idx = -1) == ""
	assert candidate( "abcd", "abef", 3) == "abcd\n===^\nabef\n"
	assert candidate(
    "line1", "line2", 3) == "line1\n===^\nline2\n", "candidate 1"
	assert candidate( "test", "test", -2) == ""
	assert candidate( "abc", "abc", 1) == "abc\n=^\nabc\n"
	assert candidate(line1="01234567890", line2="01234567891", idx=1) == \
"""01234567890
=^
01234567891
"""
	assert candidate(line1 = "This is a single line", line2 = "This is also a single line", idx = -1) == ""
	assert candidate(line1="hello", line2="world", idx=-1) == ""
	assert candidate(line1="abcdefghij", line2="abcdefghij", idx=1) == \
    "abcdefghij\n=^\nabcdefghij\n"
	assert candidate( "test", "test", -4) == ""
	assert candidate(line1 = "abc", line2 = "def", idx = 4) == ""
	assert candidate(line1="01234567890/r", line2="01234567891", idx=10) == ""
	assert candidate(line1="abc", line2="def", idx=-2) == ""
	assert candidate(line1="hello", line2="world", idx=10) == ""
	assert candidate( "abc", "def", 4) == ""
	assert candidate( "abc", "abc", 2) == "abc\n==^\nabc\n"
	assert candidate( "abc", "abcd", -1) == ""
	assert candidate(line1="hello", line2="world", idx=6) == ""
	assert candidate(line1="01234567890", line2="01234567891", idx=100) == ""
	assert candidate( "abc", "abc", 4) == ""
	assert candidate(line1="hello", line2="world", idx=9999) == ""
	assert candidate( "abc", "abcd", 4) == ""
	assert candidate("This is a test", "This is a test", 1000) == "", \
    "Should be empty"
	assert candidate( "test", "test", 6) == ""
	assert candidate(line1="abc", line2="xyz", idx=-1) == ""
	assert candidate(line1="01234567890/r/n", line2="01234567891", idx=10) == ""
	assert candidate( "test", "test", 9) == ""
	assert candidate(
    "This is a test line",
    "This is a test line",
    -2) == ""
	assert candidate(
    "a long string that is the same",
    "a long string that is the same",
    -100) == ""
	assert candidate(
    "This is a test line",
    "This is a test line",
    -1) == ""
	assert candidate( "abc", "def", 2) == "abc\n==^\ndef\n"
	assert candidate(line1="abc", line2="def", idx=100) == ""
	assert candidate(line1="abc", line2="def", idx=-1) == ""
	assert candidate(
    "This is a test", "This is a test", 1) == "This is a test\n=^\nThis is a test\n"
	assert candidate("This is a test", "This is a test", -1) == "", \
    "Should be empty"
	assert candidate( "test", "test", -5) == ""
	assert candidate( "test", "test", -1) == ""
	assert candidate(
    "This is a test line",
    "This is a test line",
    -4) == ""
	assert candidate( "abc", "abc", 3) == "abc\n===^\nabc\n"
	assert candidate(line1="01234567890", line2="01234567891/r/n", idx=10) == ""
	assert candidate( "test", "test", -3) == ""
	assert candidate( "abc\ndef", "abc\ndef", 1) == "abc\ndef\n=^\nabc\ndef\n"
	assert candidate( "abcd", "abc", 3) == "abcd\n===^\nabc\n"
	assert candidate( "test", "test", 8) == ""
	assert candidate(line1 = "abc", line2 = "abc", idx = 10) == ""
	assert candidate( "test", "test", -7) == ""
	assert candidate(
    "This is a test", "This is another test", 20) == (
        "")
	assert candidate(
    "I am a line.", "I am a line.", -1) == ""
	assert candidate(
    "a long string that is the same",
    "a long string that is the same",
    100) == ""
	assert candidate( "test", "test", 7) == ""
	assert candidate(
    "I am a line.", "I am a line.", 1000) == ""
	assert candidate( "test", "test", -6) == ""
	assert candidate(
    "This is a test\n", "This is a test\n", -1) == ""
	assert candidate(
    "I am a line.", "I am a line.", 100) == ""
	assert candidate( "abc\ndef", "abc\ndef", 2) == "abc\ndef\n==^\nabc\ndef\n"
	assert candidate(
    "This is a test", "This is a test", 20) == "", "Should be empty"
	assert candidate(line1 = "abc", line2 = "xyz", idx = -1) == ""
	assert candidate(
    "I am a line.", "I am a line.", -1000) == ""
	assert candidate(line1 = "This is a test",
                              line2 = "This is a test",
                              idx = -1) == ""
	assert candidate(
    "This is a test", "This is another test", -1) == (
        "")
	assert candidate( "abc", "abcd", 3) == "abc\n===^\nabcd\n"
	assert candidate(
    "This is a test line",
    "This is a test line",
    -3) == ""
	assert candidate(line1 = "This is a test",
                              line2 = "This is a test",
                              idx = 20) == ""
def test_check():
	check(singleline_diff_format)
