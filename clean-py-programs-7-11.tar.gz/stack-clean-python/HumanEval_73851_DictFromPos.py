def DictFromPos(seq):
    """Returns dict mapping items to list of positions of those items in seq.

    Always assigns values as lists, even if the item appeared only once.

    WARNING: will fail if items in seq are unhashable, e.g. if seq is a list of
    lists.
    """
    ### Canonical solution below ###
    result = {}
    for i, s in enumerate(seq):
        if s not in result:
            result[s] = []
        result[s].append(i)
    return result


### Unit tests below ###
def check(candidate):
	assert candidate(list('abab')) == {'a': [0, 2], 'b': [1, 3]}
	assert candidate([0, 0, 0, 1, 1]) == {0: [0, 1, 2], 1: [3, 4]}
	assert candidate(list('abcb')) == {'a': [0], 'b': [1, 3], 'c': [2]}
	assert candidate(['a', 'b', 'b', 'c']) == {'a': [0], 'b': [1, 2], 'c': [3]}
	assert candidate(list('abc')) == {'a': [0], 'b': [1], 'c': [2]}
	assert candidate([]) == {}
	assert candidate(range(2)) == {0: [0], 1: [1]}
	assert candidate(list('aa')) == {'a': [0, 1]}
	assert candidate( [1,2,3] ) == {1: [0], 2: [1], 3: [2]}
	assert candidate([1, 2, 2, 1, 2]) == {1: [0, 3], 2: [1, 2, 4]}
	assert candidate(range(1000)) == candidate(range(1000))
	assert candidate([0, 1, 0]) == {0: [0, 2], 1: [1]}
	assert candidate([1, 1, 1, 2, 2, 3]) == {1: [0, 1, 2], 2: [3, 4], 3: [5]}
	assert candidate(['a', 'b', 'a', 'a', 'b', 'c']) == {'a': [0, 2, 3], 'b': [1, 4], 'c': [5]}
	assert candidate(range(4)) == {0: [0], 1: [1], 2: [2], 3: [3]}
	assert candidate([1, 2, 1, 3]) == {1: [0, 2], 2: [1], 3: [3]}
	assert candidate(range(100000)) == candidate(range(100000))
	assert candidate(list('aaaa')) == {'a': [0, 1, 2, 3]}
	assert candidate(list('aba')) == {'a': [0, 2], 'b': [1]}
	assert candidate('abc') == {'a': [0], 'b': [1], 'c': [2]}
	assert candidate("hello") == {'h': [0], 'e': [1], 'l': [2, 3], 'o': [4]}
	assert candidate( [1,2,2,3] ) == {1: [0], 2: [1,2], 3: [3]}
	assert candidate('abcd') == {'a': [0], 'b': [1], 'c': [2], 'd': [3]}
	assert candidate(['a', 'a', 'b']) == {'a': [0, 1], 'b': [2]}
	assert candidate(list('aaa')) == {'a': [0, 1, 2]}
	assert candidate([0, 0, 1]) == {0: [0, 1], 1: [2]}
	assert candidate(range(5)) == {0: [0], 1: [1], 2: [2], 3: [3], 4: [4]}
	assert candidate(list('')) == {}
	assert candidate(range(3)) == {0: [0], 1: [1], 2: [2]}
	assert candidate(list('abca')) == {'a': [0, 3], 'b': [1], 'c': [2]}
	assert candidate(['a', 'b', 'a']) == {'a': [0, 2], 'b': [1]}
	assert candidate([0, 1, 2, 3, 0]) == {0: [0, 4], 1: [1], 2: [2], 3: [3]}
def test_check():
	check(DictFromPos)
