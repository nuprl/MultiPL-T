def create_multiples(factor, limit):
    """Return a set of multiples of the factor up to the limit.
    Start with factor**2."""
    ### Canonical solution below ###
    multiples = set()
    counter = 0
    product = 0

    print('    Function begins.')
    while True:
        product = factor * (factor + counter)
        if product > limit:
            print(f'    {factor} * {factor + counter} = {product}.',
                  f'Loop within function breaks. Fucntion returns ouput')
            break
        multiples.add(product)
        print(f'    {factor} * {factor + counter} = {product}')
        counter += 1
        print('Multiples: ' )
    return multiples


### Unit tests below ###
def check(candidate):
	assert candidate(1, 5) == {1, 2, 3, 4, 5}
	assert candidate(2, 100) == {4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94, 96, 98, 100}
	assert candidate(3, 1) == set()
	assert candidate(1, 10) == {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	assert candidate(2, 10) == {4, 6, 8, 10}
	assert candidate(3, 15) == {9, 12, 15}
	assert candidate(3, 10) == {9}
	assert candidate(5, 10) == set()
	assert candidate(10, 100) == {100}
	assert candidate(1, 3) == {1, 2, 3}
	assert candidate(3, 20) == {9, 12, 15, 18}
def test_check():
	check(create_multiples)
