def parse_tune_id(parts_dict):
    """ In place parse tune path from parts dict.
     
     Arguments:
     parts_dict (dict): dict(entity=,project=,name=).  Modifies dict inplace.
     
     Returns:
     None or str if there is an error
     """
	### Canonical solution below ###    

    entity = None
    project = None
    tune_id = parts_dict.get("name")
    if not isinstance(tune_id, str):
        return "Expected string tune_id"

    tune_split = tune_id.split("/")
    if len(tune_split) == 1:
        pass
    elif len(tune_split) == 2:
        split_project, tune_id = tune_split
        project = split_project or project
    elif len(tune_split) == 3:
        split_entity, split_project, tune_id = tune_split
        project = split_project or project
        entity = split_entity or entity
    else:
        return "Expected tune_id in form of tune, project/tune, or entity/project/tune"
    parts_dict.update(dict(name=tune_id, project=project, entity=entity))

### Unit tests below ###
def check(candidate):
	assert candidate(dict(name="entity/project/tune_id/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity//project/tune")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(entity="entity", project="project", name="project/tune")) == None
	assert candidate(dict(name="entity/project/tune/extra/extra/")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(entity="entity", project=None, name="entity/project/tune")) == None
	assert candidate(dict(name="entity/project/tune")) is None
	assert candidate(dict(entity="entity", project=None, name="project/tune")) == None
	assert candidate(dict(name="entity/tune", entity="entity")) == None
	assert candidate(dict(name="project/tune/extra")) == None
	assert candidate(dict(name="test")) == None
	assert candidate(dict(name="/entity/project/tune")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/tune", entity="entity")) == None
	assert candidate(dict(name="project/entity/tune", project="project")) == None
	assert candidate(dict(name="tune", entity="entity", project="project")) == None
	assert candidate(dict(name="proj/tune")) is None
	assert candidate(dict(name="entity/tune/project/extra", entity="entity")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/tune")) is None
	assert candidate(dict(name="entity/project/tune/extra/extra/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/tune/project/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/tune_id")) == None
	assert candidate(dict(name="ent/proj/tune")) is None
	assert candidate(dict(name="tune/project")) == None
	assert candidate(dict(name="entity/project/tune/id")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(entity="entity", project="project", name="tune")) == None
	assert candidate(dict(name="entity/tune", entity="entity")) is None
	assert candidate(dict(name="entity/project/tune/project/")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/tune/project")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="tune", project="project")) is None
	assert candidate(dict(entity="entity", project=None, name="tune")) == None
	assert candidate(dict(name="entity/test")) == None
	assert candidate(dict(entity="entity", project="project", name="entity/project/entity/project/entity/project/tune")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="tune", project="proj")) is None
	assert candidate(dict(name="a/b/c/d")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="tune", entity="entity")) == None
	assert candidate(dict(entity=None, project=None, name="entity/project/tune/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/tune/project", entity="entity")) == None
	assert candidate(dict(entity=None, project=None, name="entity/project/tune")) == None
	assert candidate(dict(name="entity/project//test")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="tune", entity="ent")) is None
	assert candidate(dict(entity=None, project=None, name="entity/tune")) == None
	assert candidate(dict(name="entity/tune", project="project", entity="entity")) == None
	assert candidate(dict(name="entity/project/test/")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(entity=None, project="project", name="project/tune")) == None
	assert candidate(dict(name="tune", entity="ent", project="proj")) is None
	assert candidate(dict(name="entity/project/tune/")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="project/entity/tune")) == None
	assert candidate(dict(entity=None, project=None, name="tune")) == None
	assert candidate(dict(name="tune", project="project", entity="entity")) == None
	assert candidate(dict(entity=None, project=None, name="project/tune")) == None
	assert candidate(dict(name="entity/project/tune/project/extra/")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="project/entity/tune", entity="entity")) == None
	assert candidate(dict(name="entity/project/tune", project="project")) is None
	assert candidate(dict(entity=None, project="project", name="entity/project/tune")) == None
	assert candidate(dict(name="tune_id")) == None
	assert candidate(dict(name="entity/project/tune", entity="entity", project="project")) is None
	assert candidate(dict(name="entity/tune")) == None
	assert candidate(dict(name="entity/tune_id")) == None
	assert candidate(dict(entity="entity", project="project", name="entity/tune")) == None
	assert candidate(dict(name="entity/project/tune/extra/")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/tune", project="project", entity="entity")) == None
	assert candidate(dict(name="entity/project/tune", project="project")) == None
	assert candidate(dict(name="project/tune_id")) == None
	assert candidate(dict(name="entity/tune/project/tune")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/test/extra/")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="project/entity/tune", project="project", entity="entity")) == None
	assert candidate(dict(name="entity/project//tune")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/test/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="entity/project/tune", entity="entity", project="project")) == None
	assert candidate(dict(name="entity/project/test")) == None
	assert candidate(dict(name="tune")) == None
	assert candidate(dict(name="entity/tune/project")) == None
	assert candidate(dict(name="tune/project/entity/tune", project="project", entity="entity", other="other")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="tune", entity="entity")) is None
	assert candidate(dict(name="entity/tune", project="project")) is None
	assert candidate(dict(name="a/b")) == None
	assert candidate(dict(name="project/tune")) == None
	assert candidate(dict(name="entity/project/tune", entity="entity")) is None
	assert candidate(dict(name="tune")) is None
	assert candidate(dict(entity="entity", project=None, name="entity/project/tune/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="project/tune", project="project", entity="entity")) == None
	assert candidate(dict(entity="entity", project="project", name="entity/project/tune")) == None
	assert candidate(dict(name="a")) == None
	assert candidate(dict(name="entity/project/tune")) == None
	assert candidate(dict(name="tune", project="project")) == None
	assert candidate(dict(name="entity/project/tune/extra/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(entity=None, project="project", name="tune")) == None
	assert candidate(dict(entity=None, project="project", name="entity/tune")) == None
	assert candidate(dict(name="tune/project", entity="entity")) == None
	assert candidate(dict(name="tune/")) == None
	assert candidate(dict(entity="entity", project=None, name="entity/tune")) == None
	assert candidate(dict(name="entity/project/tune/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name=None)) == "Expected string tune_id"
	assert candidate(dict(entity="entity", project="project", name="entity/project/tune/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="ent/proj/tune/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name=1)) == "Expected string tune_id"
	assert candidate(dict(name="entity/tune", project="project")) == None
	assert candidate(dict(entity=None, project="project", name="entity/project/tune/extra")) == "Expected tune_id in form of tune, project/tune, or entity/project/tune"
	assert candidate(dict(name="a/b/c")) == None
def test_check():
	check(parse_tune_id)
