def rgb_to_color(r, g, b):
    """Convert R, G, B values to hex string."""
    ### Canonical solution below ###
    r, g, b = int(r) & 0xFF, int(g) & 0xFF, int(b) & 0xFF
    value = r << 16 | g << 8 | b
    return '0x{0:06X}'.format(value)


### Unit tests below ###
def check(candidate):
	assert candidate(255, 0, 0) == '0xFF0000'
	assert candidate(0, 128, 128) == '0x008080'
	assert candidate(-0.1, 0.2, 0.3) == '0x000000'
	assert candidate(0, 255, 0) == '0x00FF00'
	assert candidate(255, 255, 255) == '0xFFFFFF'
	assert candidate(255, 255, 0) == '0xFFFF00'
	assert candidate(0, 0, 255) == '0x0000FF'
	assert candidate(0, 0, 0) == '0x000000'
	assert candidate(0, 1, 255) == '0x0001FF'
	assert candidate(1, 1, 0) == '0x010100'
	assert candidate(128, 0, 0) == '0x800000'
	assert candidate(128, 128, 0) == '0x808000'
	assert candidate(0, 0, 128) == '0x000080'
	assert candidate(127, 127, 127) == '0x7F7F7F'
	assert candidate(1, 1, 1) == '0x010101'
	assert candidate(0, 255, 255) == '0x00FFFF'
	assert candidate(-256, -256, -256) == '0x000000'
	assert candidate(0, 0, 1) == '0x000001'
	assert candidate(10, 10, 10) == '0x0A0A0A'
	assert candidate(1, 0, 0) == '0x010000'
	assert candidate(1, 0, 1) == '0x010001'
	assert candidate(2, 2, 2) == '0x020202'
	assert candidate(0.1, 0.2, -0.3) == '0x000000'
	assert candidate(127, 0, 127) == '0x7F007F'
	assert candidate(255, 255, 255)
	assert candidate(128, 128, 128) == '0x808080'
	assert candidate(1, 255, 0) == '0x01FF00'
	assert candidate(0, 1, 0) == '0x000100'
	assert candidate(0, 128, 0) == '0x008000'
	assert candidate(1, 255, 255) == '0x01FFFF'
	assert candidate(1, 0, 255) == '0x0100FF'
	assert candidate(1, 2, 3) == '0x010203'
	assert candidate(255, 0, 255) == '0xFF00FF'
	assert candidate(128, 0, 128) == '0x800080'
	assert candidate(254, 253, 252) == '0xFEFDFC'
	assert candidate(0, 1, 1) == '0x000101'
	assert candidate(0.1, -0.2, 0.3) == '0x000000'
def test_check():
	check(rgb_to_color)
