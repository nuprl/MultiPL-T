def render_items_vert(items):
    """
    Render a sequence of pairs or an `OrderedDict` as a comma-separated list.

    The function skips the items whose values are `None` or `False`.

    :param items: a sequence of items
    :type items: list or tuple or OrderedDict
    :return: rendered content
    :rtype: str
    """
    ### Canonical solution below ###
    if isinstance(items, dict):
        items = items.items()
    return ", ".join(
        "<b>{}</b>: {}".format(key, value)
        for key, value in items
        if value is not None and value is not False
    )


### Unit tests below ###
def check(candidate):
	assert candidate(
    (
        ("one", 1),
        ("two", 2),
        ("three", 3),
        ("four", None),
        ("five", False),
    )
) == "<b>one</b>: 1, <b>two</b>: 2, <b>three</b>: 3"
	assert candidate([]) == ""
	assert candidate([("a", 1), ("b", 2), ("c", 3)]) == "<b>a</b>: 1, <b>b</b>: 2, <b>c</b>: 3"
	assert candidate(dict(a="A", b=False)) == "<b>a</b>: A"
	assert candidate([("a", None), ("b", False), ("c", 3)]) == \
    "<b>c</b>: 3"
	assert candidate(dict(a="A", b="B", c=None)) == "<b>a</b>: A, <b>b</b>: B"
	assert candidate(
    {"first": "one", "second": "two", "third": None, "fourth": False}
) == """<b>first</b>: one, <b>second</b>: two"""
	assert candidate(dict(a="A", b="B", c="C", d=None)) == "<b>a</b>: A, <b>b</b>: B, <b>c</b>: C"
	assert candidate({}) == ""
	assert candidate([("a", False), ("b", False)]) == ""
	assert candidate([("foo", "bar"), ("baz", "qux")]) == (
    "<b>foo</b>: bar, <b>baz</b>: qux"
)
	assert candidate(
    {"a": "1", "b": "2"}
) == "<b>a</b>: 1, <b>b</b>: 2"
	assert candidate([("a", None), ("b", 2)]) == "<b>b</b>: 2"
	assert candidate([("a", None), ("b", False), ("c", 0)]) == "<b>c</b>: 0"
	assert candidate(dict(a="A", b="B", c=False)) == "<b>a</b>: A, <b>b</b>: B"
	assert candidate(dict()) == ""
	assert candidate(dict(a=None, b=False, c=0)) == "<b>c</b>: 0"
	assert candidate([("a", False), ("b", None)]) == ""
	assert candidate(
    (
        ("a", "b"),
        ("c", "d"),
        ("e", None),
        ("f", False),
        ("g", "h"),
    )
) == "<b>a</b>: b, <b>c</b>: d, <b>g</b>: h"
	assert candidate({"x": None}) == ""
	assert candidate([("a", 1), ("b", 2), ("c", 3)]) == (
    "<b>a</b>: 1, <b>b</b>: 2, <b>c</b>: 3"
)
	assert candidate([("a", 1), ("b", None), ("c", 3)]) == \
    "<b>a</b>: 1, <b>c</b>: 3"
	assert candidate(dict(a=None, b=False)) == ""
	assert candidate([("a", 1), ("b", 2), ("c", 3)]) == \
    "<b>a</b>: 1, <b>b</b>: 2, <b>c</b>: 3"
	assert candidate(()) == ""
	assert candidate([("a", False), ("b", None), ("c", True)]) == (
    "<b>c</b>: True"
)
	assert candidate([("a", "b"), ("c", "d")]) == "<b>a</b>: b, <b>c</b>: d"
	assert candidate([("a", "1"), ("b", None)]) == "<b>a</b>: 1"
	assert candidate({"x": False}) == ""
	assert candidate(dict(a="A", b="B", c="C", d=False)) == "<b>a</b>: A, <b>b</b>: B, <b>c</b>: C"
	assert candidate(
    (("a", "1"), ("b", "2"))
) == "<b>a</b>: 1, <b>b</b>: 2"
	assert candidate([("foo", "bar")]) == "<b>foo</b>: bar"
	assert candidate({"a": 1, "b": 2, "c": 3}) == "<b>a</b>: 1, <b>b</b>: 2, <b>c</b>: 3"
	assert candidate(dict(a=1, b=2, c=3)) == "<b>a</b>: 1, <b>b</b>: 2, <b>c</b>: 3"
	assert candidate([("a", 1), ("b", False), ("c", 3)]) == \
    "<b>a</b>: 1, <b>c</b>: 3"
	assert candidate(
    [
        ("a", 1),
        ("b", None),
        ("c", False),
        ("d", 2),
        ("e", 3),
    ]
) == "<b>a</b>: 1, <b>d</b>: 2, <b>e</b>: 3"
	assert candidate([("a", 1), ("b", 2)]) == "<b>a</b>: 1, <b>b</b>: 2"
	assert candidate(dict(a="A", b="B", c="C")) == "<b>a</b>: A, <b>b</b>: B, <b>c</b>: C"
	assert candidate([("a", False), ("b", 2)]) == "<b>b</b>: 2"
	assert candidate(dict(a="A", b="B", c="C", d="D")) == "<b>a</b>: A, <b>b</b>: B, <b>c</b>: C, <b>d</b>: D"
	assert candidate({"a": "b"}) == "<b>a</b>: b"
	assert candidate(
    [
        ("one", 1),
        ("two", 2),
        ("three", 3),
        ("four", None),
        ("five", False),
    ]
) == "<b>one</b>: 1, <b>two</b>: 2, <b>three</b>: 3"
	assert candidate(dict(a="A", b="B")) == "<b>a</b>: A, <b>b</b>: B"
def test_check():
	check(render_items_vert)
