def camel_to_snake(field_camel, remap_keys):
    """ 
     
     :param field_camel:
     :param remap_keys:
     :return:
     """
	### Canonical solution below ###    

    field_snake = field_camel
    if field_camel in remap_keys:
        field_snake = remap_keys[field_camel]
    return field_snake

### Unit tests below ###
def check(candidate):
	assert candidate(field_camel="myField", remap_keys={"myField": "my_field_2"}) == "my_field_2"
	assert candidate('CamelCase', {'CamelCase':'snake_case'}) =='snake_case'
	assert candidate("fooBar", {}) == "fooBar"
	assert candidate(
    'userFirstName',
    {'userFirstName': 'user_first_name', 'userLastName': 'user_last_name'}
) == 'user_first_name'
	assert candidate('a', {}) == 'a'
	assert candidate("aBcDeF", {"aBcDeF": "a_bc_de_f"}) == "a_bc_de_f"
	assert candidate(None, {}) is None
	assert candidate(
    'thisIsCamelCase',
    {
        'thisIsCamelCase': 'this_is_snake_case',
        'thisIsCamelCase2': 'this_is_snake_case_2',
    }
) == 'this_is_snake_case'
	assert candidate(
    "camelCase", {"camelCase": "snake_case"}) == "snake_case"
	assert candidate(
    'helloWorld',
    {
        'helloWorld': 'hello_world'
    }
) == 'hello_world'
	assert candidate('fooBarBazBax', {'fooBarBazBax': 'fizz_buzz'}) == 'fizz_buzz'
	assert candidate("fooBarBaz", {"fooBarBaz": "bar_baz"}) == "bar_baz"
	assert candidate(field_camel="myField", remap_keys={"myField": "my_field"}) == "my_field"
	assert candidate('fooBar', {'fooBar': 'foo_bar'}) == 'foo_bar'
	assert candidate("test", {}) == "test"
	assert candidate(field_camel="testCamel1", remap_keys={"testCamel1": "test_snake_1", "testCamel1": "test_snake_2"}) == "test_snake_2"
	assert candidate('camelCase', {}) == 'camelCase'
	assert candidate('foo', {}) == 'foo'
	assert candidate('fooBar', {}) == 'fooBar'
	assert candidate(
    'camelCase',
    {'camelCase': 'camelCase'}) == 'camelCase'
	assert candidate(field_camel="test_camel", remap_keys={"test_camel": "test_snake"}) == "test_snake"
	assert candidate(None, {}) == None
	assert candidate(
    'camelCase',
    {'camelCase': 'camelCase','snake_case':'snake_case'}) == 'camelCase'
	assert candidate("field_name", {}) == "field_name"
	assert candidate(
    'thisIsCamelCase',
    {'thisIsCamelCase': 'this_is_snake_case'}
) == 'this_is_snake_case'
	assert candidate('helloWorld', {}) == 'helloWorld'
	assert candidate("test_camel", {}) == "test_camel"
	assert candidate("fooBar", {"fooBar": "foo_bar"}) == "foo_bar"
	assert candidate(
    'thisIsCamelCase',
    {'thisIsCamelCase': 'this_is_snake_case', 'anotherCamel': 'another_snake'}
) == 'this_is_snake_case'
	assert candidate(field_camel='myField', remap_keys={'myField':'my_field'}) =='my_field'
	assert candidate(
    'fooBar', {
        'fooBar': 'foo_bar',
        'fooBarBaz': 'foo_bar_baz'
    }) == 'foo_bar'
	assert candidate('helloWorld', {'helloWorld': 'bye'}) == 'bye'
	assert candidate(
    'userFirstName',
    {'userFirstName': 'user_first_name'}
) == 'user_first_name'
	assert candidate('fooBar', {'fooBar': 'fooBar_snake'}) == 'fooBar_snake'
	assert candidate("fooBar", {"fooBar": "foo_bar", "foo_bar": "foo_bar"}) == "foo_bar"
	assert candidate('fooBar', {'barFoo': 'barFoo_snake'}) == 'fooBar'
	assert candidate(field_camel='helloWorld', remap_keys={}) == 'helloWorld'
	assert candidate('fooBarBaz', {'fooBarBaz': 'foo_bar_baz'}) == 'foo_bar_baz'
	assert candidate('camelCase', {'camelCase':'snake_case'}) =='snake_case'
	assert candidate("a", {}) == "a"
	assert candidate(field_camel='helloWorld', remap_keys={'helloWorld': 'hello_world'}) == 'hello_world'
	assert candidate(
    "testCamelCase", {"testCamelCase": "test_snake_case"}
) == "test_snake_case"
	assert candidate(
    'fooBar', {
        'fooBar': 'foo_bar'
    }) == 'foo_bar'
	assert candidate(field_camel="testCamel1", remap_keys={"testCamel1": "test_snake_1"}) == "test_snake_1"
	assert candidate(
    'fooBarBaz',
    {'fooBarBaz': 'foo_bar_baz'}
) == 'foo_bar_baz'
	assert candidate(
    "thisIsCamelCaseButRemapped",
    {"thisIsCamelCaseButRemapped": "this_is_a_snake_case"}
) == "this_is_a_snake_case"
	assert candidate("testCamel", {"testCamel": "test_snake"}) == "test_snake"
	assert candidate('', {}) == ''
	assert candidate(field_camel="test", remap_keys={"test": "test_snake"}) == "test_snake"
	assert candidate(field_camel='helloWorld', remap_keys={'helloWorld': 'hello_world', 'helloWorld2': 'hello_world2'}) == 'hello_world'
	assert candidate("foo", {}) == "foo"
	assert candidate(
    "thisIsCamelCase2",
    {
        "thisIsCamelCase": "this_is_snake_case",
        "thisIsCamelCase2": "this_is_snake_case_2"
    }
) == "this_is_snake_case_2"
	assert candidate(
    'camelCase',
    {'camelCase':'snake_case'}) =='snake_case'
	assert candidate(field_camel="test_Camel", remap_keys={"test_Camel": "test_snake"}) == "test_snake"
	assert candidate(
    "thisIsCamelCase",
    {
        "thisIsCamelCase": "this_is_snake_case"
    }
) == "this_is_snake_case"
	assert candidate(
    'fooBarBaz', {
        'fooBar': 'foo_bar',
        'fooBarBaz': 'foo_bar_baz'
    }) == 'foo_bar_baz'
	assert candidate(
    'thisIsCamelCase2',
    {
        'thisIsCamelCase': 'this_is_snake_case',
        'thisIsCamelCase2': 'this_is_snake_case_2',
    }
) == 'this_is_snake_case_2'
	assert candidate("", {}) == ""
	assert candidate(
    "thisIsACamelCase",
    {"thisIsACamelCase": "this_is_a_snake_case"}
) == "this_is_a_snake_case"
	assert candidate(field_camel="testCamel", remap_keys={"testCamel": "test_snake"}) == "test_snake"
	assert candidate('fooBar', {'fooBar': 'foo_bar', 'fooBarBaz': 'foo_bar_baz'}) == 'foo_bar'
	assert candidate("fooBarBaz", {"fooBarBaz": "foo_bar_baz"}) == "foo_bar_baz"
	assert candidate(
    'fooBar',
    {'fooBar': 'foo_bar'}
) == 'foo_bar'
	assert candidate(
    "thisIsCamelCase",
    {
        "thisIsCamelCase": "this_is_snake_case",
        "thisIsCamelCase2": "this_is_snake_case_2"
    }
) == "this_is_snake_case"
	assert candidate('fooBar', {'fooBar': 'fooBar_snake', 'barFoo': 'barFoo_snake'}) == 'fooBar_snake'
	assert candidate("thisIsCamelCase", {"thisIsCamelCase": "this_is_snake_case"}) == "this_is_snake_case"
def test_check():
	check(camel_to_snake)
