def check_add_suffix(list_ids, document_id, number):
    """Check if EDR API returns list of edr ids with more then 1 element add suffix to document id"""
    ### Canonical solution below ###
    len_list_ids = len(list_ids)
    if len_list_ids > 1:
        return '{document_id}.{amount}.{number}'.format(document_id=document_id, amount=len_list_ids, number=number)
    return document_id


### Unit tests below ###
def check(candidate):
	assert candidate(list_ids=['a', 'c'], document_id='b', number=2) == 'b.2.2'
	assert candidate(list_ids=['a', 'c'], document_id='b', number=1) == 'b.2.1'
	assert candidate(list_ids=['1', '2'], document_id='1', number=1) == '1.2.1'
	assert candidate(list_ids=[], document_id='123', number=1) == '123'
	assert candidate(list_ids=['id1', 'id2', 'id3'], document_id='doc1', number=3) == 'doc1.3.3'
	assert candidate(list_ids=['1', '2', '3'], document_id='1', number=1) == '1.3.1'
	assert candidate(list_ids=['123456789', '123456780'], document_id='123456789', number=1) == '123456789.2.1'
	assert candidate(list_ids=['id1', 'id2', 'id3', 'id4', 'id5', 'id6'], document_id='doc_id', number=1) == 'doc_id.6.1'
	assert candidate(list_ids=['a', 'b'], document_id='a', number=3) == 'a.2.3'
	assert candidate(list_ids=['123456789', '123456780'], document_id='123456789', number=3) == '123456789.2.3'
	assert candidate(list_ids=['2000000001-001-00001', '2000000001-001-00002'], document_id='2000000001-001', number=1) == '2000000001-001.2.1'
	assert candidate(list_ids=['123'], document_id='123', number=1) == '123'
	assert candidate(list_ids=['id1', 'id2', 'id3'], document_id='doc_id', number=1) == 'doc_id.3.1'
	assert candidate(list_ids=[1, 2], document_id='id', number=1) == 'id.2.1'
	assert candidate(list_ids=['12345678', '12345678', '12345678'], document_id='12345678', number=1) == '12345678.3.1'
	assert candidate(list_ids=['123', '123'], document_id='123', number=1) == '123.2.1'
	assert candidate(list_ids=['1111', '2222', '3333'], document_id='1111', number=1) == '1111.3.1'
	assert candidate(list_ids=[1, 2], document_id=1, number=1) == '1.2.1'
	assert candidate(list_ids=['123456789', '123456789', '123456789'], document_id='123456789', number=2) == '123456789.3.2'
	assert candidate(list_ids=['543210', '543211'], document_id='54321', number=1) == '54321.2.1'
	assert candidate(list_ids=['1234567890', '1234567890'], document_id='1234567890', number=1) == '1234567890.2.1'
	assert candidate(list_ids=['1', '2', '3'], document_id='1', number=3) == '1.3.3'
	assert candidate(list_ids=['a', 'b'], document_id='b', number=1) == 'b.2.1'
	assert candidate(list_ids=[1, 2, 3], document_id='id', number=1) == 'id.3.1'
	assert candidate(list_ids=['1'], document_id='1', number=1) == '1'
	assert candidate(list_ids=[1, 2, 3], document_id='test_id', number=1) == 'test_id.3.1'
	assert candidate(list_ids=['1', '2'], document_id='1.2', number=3) == '1.2.2.3'
	assert candidate(list_ids=['id1', 'id2'], document_id='id', number=1) == 'id.2.1'
	assert candidate(list_ids=['1234567890'], document_id='1234567890', number=1) == '1234567890'
	assert candidate(list_ids=['123', '123', '123', '123', '123', '123', '123'], document_id='123', number=1) == '123.7.1'
	assert candidate(list_ids=['1111111111', '2222222222'], document_id='1111111111', number=1) == '1111111111.2.1'
	assert candidate(list_ids=['1111', '2222'], document_id='1111', number=1) == '1111.2.1'
	assert candidate(list_ids=['1111111111', '2222222222'], document_id='2222222222', number=1) == '2222222222.2.1'
	assert candidate(list_ids=['123456789', '123456789', '123456789'], document_id='123456789', number=1) == '123456789.3.1'
	assert candidate(list_ids=['123', '123', '123'], document_id='123', number=1) == '123.3.1'
	assert candidate(list_ids=[1, 2, 3], document_id='id', number=4) == 'id.3.4'
	assert candidate(list_ids=['id1', 'id2', 'id3', 'id4', 'id5'], document_id='doc_id', number=1) == 'doc_id.5.1'
	assert candidate(list_ids=['id1', 'id2', 'id3', 'id4'], document_id='doc_id', number=1) == 'doc_id.4.1'
	assert candidate(list_ids=['123', '456'], document_id='123', number=1) == '123.2.1', "Should be '123.2.1'"
	assert candidate(list_ids=['1', '2'], document_id='1', number=2) == '1.2.2'
	assert candidate(list_ids=['2000000001-001-00001', '2000000001-001-00002'], document_id='2000000001-001', number=2) == '2000000001-001.2.2'
	assert candidate(list_ids=['123', '123', '123', '123'], document_id='123', number=1) == '123.4.1'
	assert candidate(list_ids=['123', '456'], document_id='123', number=1) == '123.2.1'
	assert candidate(list_ids=['123456789', '123456789', '123456789'], document_id='123456789', number=3)
	assert candidate(list_ids=['123', '123', '123', '123', '123', '123'], document_id='123', number=1) == '123.6.1'
	assert candidate(list_ids=['1', '2'], document_id='1', number=3) == '1.2.3'
	assert candidate(list_ids=['id1', 'id2', 'id3'], document_id='doc1', number=2) == 'doc1.3.2'
	assert candidate(list_ids=['id1', 'id2'], document_id='doc_id', number=1) == 'doc_id.2.1'
	assert candidate(list_ids=['12345678', '12345678'], document_id='12345678', number=1) == '12345678.2.1'
	assert candidate(list_ids=[1, 2], document_id='id', number=2) == 'id.2.2'
	assert candidate(list_ids=['12345678', '12345678'], document_id='12345678', number=2) == '12345678.2.2'
	assert candidate(list_ids=['123456789', '123456780'], document_id='123456789', number=2) == '123456789.2.2'
	assert candidate(list_ids=[1, 2, 3], document_id='id', number=3) == 'id.3.3'
	assert candidate(list_ids=['id1', 'id2', 'id3', 'id4', 'id5', 'id6', 'id7'], document_id='doc_id', number=1) == 'doc_id.7.1'
	assert candidate(list_ids=[1, 2, 3], document_id='id', number=2) == 'id.3.2'
	assert candidate(list_ids=['123456789', '123456789'], document_id='123456789', number=1) == '123456789.2.1'
	assert candidate(list_ids=['a', 'b'], document_id='a', number=2) == 'a.2.2'
	assert candidate(list_ids=['a'], document_id='b', number=1) == 'b'
	assert candidate(list_ids=['01234567890123456789012345678901234567890123456789012345678901234'], document_id='01234567890123456789012345678901234567890123456789012345678901234', number=0) == '01234567890123456789012345678901234567890123456789012345678901234'
	assert candidate(list_ids=['a', 'b'], document_id='a', number=1) == 'a.2.1'
	assert candidate(list_ids=['123456789', '123456789'], document_id='123456789', number=2) == '123456789.2.2'
	assert candidate(list_ids=['12345678', '12345678', '12345678'], document_id='12345678', number=3) == '12345678.3.3'
	assert candidate(list_ids=['1', '2'], document_id='1234', number=5) == '1234.2.5'
	assert candidate(list_ids=[1, 2], document_id='id', number=3) == 'id.2.3'
	assert candidate(list_ids=['id1', 'id2', 'id3'], document_id='doc1', number=1) == 'doc1.3.1'
	assert candidate(list_ids=['123', '123', '123', '123', '123'], document_id='123', number=1) == '123.5.1'
	assert candidate(list_ids=['123'], document_id='123', number=1) == '123', "Should be '123'"
	assert candidate(list_ids=['2'], document_id='1', number=1) == '1'
def test_check():
	check(check_add_suffix)
