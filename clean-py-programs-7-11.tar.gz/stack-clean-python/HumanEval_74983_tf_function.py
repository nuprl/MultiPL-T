def tf_function(tf_module):
    """Conditional decorator for @tf.function.

    Use @tf_function(tf) instead to avoid errors if tf is not installed."""
    ### Canonical solution below ###

    # The actual decorator to use (pass in `tf` (which could be None)).
    def decorator(func):
        # If tf not installed -> return function as is (won't be used anyways).
        if tf_module is None or tf_module.executing_eagerly():
            return func
        # If tf installed, return @tf.function-decorated function.
        return tf_module.function(func)

    return decorator


### Unit tests below ###
def check(candidate):
	assert candidate(None)(lambda x: x)(5) == 5
	assert candidate(None)(lambda: None)() is None
	assert candidate(None)(lambda: 1)() == 1
	assert candidate(None)(lambda x: x)(3) == 3
	assert candidate(None)(lambda: None)() == None
	assert candidate(None)(lambda x: x)(1) == 1
def test_check():
	check(tf_function)
