def _relative_degree(z, p):
    """
    Return relative degree of transfer function from zeros and poles.

    This is simply len(p) - len(z), which must be nonnegative.
    A ValueError is raised if len(p) < len(z).
    """
    ### Canonical solution below ###
    degree = len(p) - len(z)
    if degree < 0:
        raise ValueError("Improper transfer function. "
                         "Must have at least as many poles as zeros.")
    return degree


### Unit tests below ###
def check(candidate):
	assert candidate((1,2), (1,2)) == 0
	assert candidate((), ()) == 0
	assert candidate((1,), (2,)) == 0
	assert candidate((1,), (1,)) == 0
	assert candidate((0, 0), (0, 0)) == 0
	assert candidate((1, 2, 3), (1, 2, 3)) == 0
	assert candidate((1, 2, 3), (4, 5, 6)) == 0
	assert candidate((1,2), (2,1)) == 0
	assert candidate((1, 2), (1, 2, 3)) == 1
	assert candidate((1, 2), (1, 2)) == 0
	assert candidate((0,), (0,)) == 0
	assert candidate((1,), (2, 3)) == 1
	assert candidate((1,), (0, 1)) == 1
	assert candidate((1,2,3), (1,2,3)) == 0
	assert candidate((1,), (1,2)) == 1
	assert candidate((), (1,)) == 1
	assert candidate((1, 1), (1, 1)) == 0
	assert candidate((1, 2), (3, 4)) == 0
	assert candidate((1, 2, 3, 4), (4, 5, 6, 7)) == 0
	assert candidate((0, 0, 0), (0, 0, 0)) == 0
def test_check():
	check(_relative_degree)
