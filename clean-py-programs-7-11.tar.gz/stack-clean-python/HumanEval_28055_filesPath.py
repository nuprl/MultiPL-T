def filesPath():
    """
    Gera de maneira recursiva os paths para os arquivos especificados

    """
    ### Canonical solution below ###

    path = "/home/developer/Code/datalab-work-at-deliverycenter/datasets/"
    nameFiles = [
        "channels",
        "deliveries",
        "drivers",
        "hubs",
        "orders",
        "payments",
        "stores",
    ]
    files = [f"{path}{i}.csv" for i in nameFiles]

    return files, nameFiles


### Unit tests below ###
def check(candidate):
	assert candidate(
    ) == ([
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'
    ], [
        'channels',
        'deliveries',
        'drivers',
        'hubs',
        'orders',
        'payments',
       'stores'
    ])
	assert candidate(
)[0] == ["/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv"], "Esperado: ['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'], recebido: " + str(
    candidate()[0]
)
	assert candidate(
) == (
    ['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'], 
    ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores']
), "Esperado ['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'], ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores']"
	assert candidate(
)[0] == [
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv",
], "Esperado: [ '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv', ]"
	assert candidate(
)[1] == [
    "channels",
    "deliveries",
    "drivers",
    "hubs",
    "orders",
    "payments",
    "stores",
], "O primeiro elemento do retorno deve ser os paths para os arquivos"
	assert candidate(
) == (
    ['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'],
    ['channels',
     'deliveries',
     'drivers',
     'hubs',
     'orders',
     'payments',
    'stores']
)
	assert candidate(
)[0] == [
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv",
], "Test failed"
	assert candidate(
) == ([
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'],
   ['channels',
    'deliveries',
    'drivers',
    'hubs',
    'orders',
    'payments',
   'stores'])
	assert candidate(
) == (
    [
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv",
    ],
    [
        "channels",
        "deliveries",
        "drivers",
        "hubs",
        "orders",
        "payments",
        "stores",
    ],
), "O teste para a função candidate falhou!"
	assert candidate(
) == (['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'], ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores']), "Files paths not generated correctly"
	assert candidate(
) == (
    [
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'
    ],
    [
        'channels',
        'deliveries',
        'drivers',
        'hubs',
        'orders',
        'payments',
       'stores'
    ]
), "Wrong result from candidate"
	assert candidate(
) == (["/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv", "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv"], ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores'])
	assert candidate(
) == ([
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'
     ], [
         'channels',
         'deliveries',
         'drivers',
         'hubs',
         'orders',
         'payments',
        'stores'
     ])
	assert candidate(
) == ([
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv',
    ], [
        'channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores'
    ])
	assert candidate(
) == ([
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'
    ], [
        'channels',
        'deliveries',
        'drivers',
        'hubs',
        'orders',
        'payments',
       'stores'
    ])
	assert candidate(
)[0] == [
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
    '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'
]
	assert candidate(
) == (
    [
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv",
    ],
    [
        "channels",
        "deliveries",
        "drivers",
        "hubs",
        "orders",
        "payments",
        "stores",
    ],
), "Should be equal"
	assert candidate(
)[1] == ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores'], "O retorno da função não é o esperado"
	assert candidate(
)[0] == ['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv', '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'], "O retorno da função não é o esperado"
	assert candidate(
) == (['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
        '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'],
       ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores'])
	assert candidate(
) == ([
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv",
], [
    "channels",
    "deliveries",
    "drivers",
    "hubs",
    "orders",
    "payments",
    "stores",
])
	assert candidate(
) == ([
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
         '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'
     ], ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores'])
	assert candidate(
)[0] == [
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv",
    "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv",
], "candidate() is not working as expected"
	assert candidate(
) == (
    ['/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv',
     '/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv'],
    ['channels', 'deliveries', 'drivers', 'hubs', 'orders', 'payments','stores'])
	assert candidate(
) == (
    [
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/channels.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/deliveries.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/drivers.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/hubs.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/orders.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/payments.csv",
        "/home/developer/Code/datalab-work-at-deliverycenter/datasets/stores.csv",
    ],
    [
        "channels",
        "deliveries",
        "drivers",
        "hubs",
        "orders",
        "payments",
        "stores",
    ],
)
def test_check():
	check(filesPath)
