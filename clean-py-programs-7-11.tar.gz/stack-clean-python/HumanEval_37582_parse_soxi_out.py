def parse_soxi_out(cmd:bytes):
    """
    this gross parser takes the bytes from the soxi output, decodes to utf-8, 
    splits by the newline "\n", takes the second element of the array which is
    the number of channels, splits by the semi-colon ':' takes the second element
    which is the string of the num channels and converts to int.
    """
    ### Canonical solution below ###
    return int(cmd.decode("utf-8").strip().split("\n")[1].split(':')[1].strip())


### Unit tests below ###
def check(candidate):
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 2\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:00.61 = 13670 samples ~ 228.2 CDDA sectors\nFile Size       : 3.8M\nBit Rate        : 512k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 2\nSample Rate    : 48000\nPrecision      : 16-bit\nDuration       : 00:00:00.15 = 17600 samples ~ 68.25 cts\nFile Size      : 6.25K\nBit Rate       : 15.6\nSample Encoding: 16-bit Signed Integer PCM") == 2
	assert candidate(b"Input File     : 'test_data/16000_mono.wav'\nChannels        : 1\nSample Rate     : 16000\nPrecision       : 16-bit\nDuration        : 00:00:00.03 = 1153 samples ~ 230.6 CDDA sectors\nFile Size       : 1.79k\nBit Rate        : 32k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'foo.wav'\nChannels       : 2\nSample Rate    : 44100\nPrecision      : 16-bit\nDuration       : 00:00:00.12 (12000 samples)\nFile Size      : 12.5k\nBit Rate       : 32k\nSample Encoding: 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 2") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 2\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:05.00 = 108,240 samples ~ 176 CDDA sectors\nFile Size       : 384k\nBit Rate        : 256k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 1\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:04.00 = 104857 samples ~ 21.5 CDDA sectors\nFile Size       : 2.3M\nBit Rate        : 96k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 6\nSample Rate     : 16000\nPrecision       : 16-bit\nDuration        : 00:00:00.24\nFile Size       : 1.11K\nBit Rate        : 64k\nSample Encoding : 16-bit Signed Integer PCM\n") == 6
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 5\nSample Rate    : 44100\nPrecision      : 16-bit\nDuration       : 00:00:04.96 = 787040 samples ~ 170.523 CDDA sectors\nFile Size      : 22.2M\nBit Rate       : 1.60M\nSample Encoding: 16-bit Signed Integer PCM\n") == 5
	assert candidate(b"Input File     : 'foo.wav'\nChannels       : 2\nSample Rate    : 44100\nPrecision      : 16-bit\nDuration       : 00:00:00.13 = 1302 samples ~ 17.423 CDDA sectors\nFile Size      : 1.3M\nBit Rate       : 192k\nSample Encoding: 16-bit Signed Integer PCM") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 1\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:00.61 = 13670 samples ~ 228.2 CDDA sectors\nFile Size       : 1.9M\nBit Rate        : 256k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 6\nSample Rate    : 48000\nPrecision      : 16-bit\nDuration       : 00:00:00.15 = 17600 samples ~ 68.25 cts\nFile Size      : 6.25K\nBit Rate       : 15.6\nSample Encoding: 16-bit Signed Integer PCM") == 6
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 4\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:03.50 = 144000 samples ~ 58.105 CDDA sectors\nFile Size      : 1.0M\nBit Rate       : 16k\nSample Encoding: 16-bit Signed Integer PCM\n") == 4
	assert candidate(b'Input File     : \'test.wav\'\nChannels       : 2\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:01.00 = 1920 samples ~ 384000 bps\nFile Size      : 6.7k\nBit Rate       : 384 kb/s\nSample Encoding: 16-bit Signed Integer PCM\n') == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 1") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 5\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:05.00 = 108,240 samples ~ 176 CDDA sectors\nFile Size       : 384k\nBit Rate        : 256k\nSample Encoding : 16-bit Signed Integer PCM\n") == 5
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 1\nSample Rate    : 44100\nPrecision      : 16-bit\nDuration       : 00:00:04.96 = 787040 samples ~ 170.523 CDDA sectors\nFile Size      : 2.22M\nBit Rate       : 320k\nSample Encoding: 16-bit Signed Integer PCM\n") == 1
	assert candidate(b'Input File     : 02-stereo.wav\nChannels       : 2') == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 2\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:03.50 = 144000 samples ~ 58.105 CDDA sectors\nFile Size      : 1.0M\nBit Rate       : 16k\nSample Encoding: 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 1\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:05.00 = 108,240 samples ~ 176 CDDA sectors\nFile Size       : 384k\nBit Rate        : 256k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 1\nSample Rate     : 8000\nPrecision       : 16-bit\nDuration        : 00:00:00.00 = 131072 samples ~ 101.049 CDDA sectors\nFile Size       : 1.8M\nBit Rate        : 11.6k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 2\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:04.00 = 104857 samples ~ 21.5 CDDA sectors\nFile Size       : 2.3M\nBit Rate        : 96k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 2\nSample Rate     : 8000\nPrecision       : 16-bit\nDuration        : 00:00:00.00 = 131072 samples ~ 101.049 CDDA sectors\nFile Size       : 3.6M\nBit Rate        : 23.2k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 1\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:03.50 = 144000 samples ~ 58.105 CDDA sectors\nFile Size      : 1.0M\nBit Rate       : 16k\nSample Encoding: 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 1\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:01.25 = 4800 samples ~ 13.75 CDDA sectors\nFile Size      : 4.9k\nBit Rate       : 256k\nSample Encoding: 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 2\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:00.00\nFile Size       : 3.77M\nBit Rate        : 320k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b'Input File     : /data/home/james/Documents/Code/python/soxi/test.wav\nChannels        : 1\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:01.00 = 32000 samples ~ 100.1 CDDA sectors\nFile Size       : 31.5k\nBit Rate        : 20.3k\nSample Encoding : 16-bit Signed Integer PCM\n') == 1
	assert candidate(b"Input File     : 'example.wav'\nChannels        : 2\nSample Rate     : 22050\nPrecision       : 16-bit\nDuration        : 00:00:04.43 = 102752 samples ~ 227.52 CDDA sectors\nFile Size       : 650.3k\nBit Rate        : 256k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b'Input File     : 01-mono.wav\nChannels       : 1') == 1
	assert candidate(b'Input File     : "foo.wav"\nChannels       : 1\nSample Rate    : 48000\nPrecision      : 16-bit\nDuration       : 00:00:10.00 = 24000 samples ~ 101.7 CDDA sectors\nFile Size      : 3125000 Byte\nBit Rate       : 192k\nSample Encoding: 16-bit Signed Integer PCM\n') == 1
	assert candidate(b"Input File     : 'tests/data/test16k.raw'\nChannels       : 2\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:04.00 = 10240 samples ~ 22.5 CDDA sectors\nFile Size      : 1.04KB\nBit Rate       : 1536k\nSample Encoding: 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 5") == 5
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 2\nSample Rate     : 16000\nPrecision       : 16-bit\nDuration        : 00:00:00.24\nFile Size       : 1.11K\nBit Rate        : 64k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'foo.wav'\nChannels       : 1\nSample Rate    : 44100\nPrecision      : 16-bit\nDuration       : 00:00:00.12 (12000 samples)\nFile Size      : 6.25k\nBit Rate       : 16k\nSample Encoding: 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 3") == 3
	assert candidate(b'Input File     : 04-5.1.wav\nChannels       : 6') == 6
	assert candidate(b'Input File     : 05-7.1.wav\nChannels       : 8') == 8
	assert candidate(b"Input File     : 'example.wav'\nChannels        : 1\nSample Rate     : 22050\nPrecision       : 16-bit\nDuration        : 00:00:04.43 = 102752 samples ~ 227.52 CDDA sectors\nFile Size       : 650.3k\nBit Rate        : 256k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'tests/data/test16k.raw'\nChannels       : 1\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:04.00 = 10240 samples ~ 22.5 CDDA sectors\nFile Size      : 1.04KB\nBit Rate       : 1536k\nSample Encoding: 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 4\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:00.61 = 13670 samples ~ 228.2 CDDA sectors\nFile Size       : 7.6M\nBit Rate        : 1M\nSample Encoding : 16-bit Signed Integer PCM\n") == 4
	assert candidate(b"Input File     : '2014-02-25-160000.flac'\nChannels       : 2\nSample Rate    : 44100\nPrecision      : 16-bit\nDuration       : 00:00:03.59 (3.59 seconds)\nFile Size      : 1.42M\nBit Rate       : 192k\nSample Encoding: 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 1\nSample Rate     : 44100\nPrecision       : 16-bit\nDuration        : 00:00:00.00\nFile Size       : 1.89M\nBit Rate        : 160k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 1\nSample Rate    : 48000\nPrecision      : 16-bit\nDuration       : 00:00:01.00 = 32000 samples ~ 19.2 cts\nFile Size      : 11.0k\nBit Rate       : 256k") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 1\nSample Rate    : 48000\nPrecision      : 16-bit\nDuration       : 00:00:00.15 = 17600 samples ~ 68.25 cts\nFile Size      : 6.25K\nBit Rate       : 15.6\nSample Encoding: 16-bit Signed Integer PCM") == 1
	assert candidate(b"Input File     : 'test_data/16000_stereo.wav'\nChannels        : 2\nSample Rate     : 16000\nPrecision       : 16-bit\nDuration        : 00:00:00.03 = 1153 samples ~ 230.6 CDDA sectors\nFile Size       : 3.57k\nBit Rate        : 64k\nSample Encoding : 16-bit Signed Integer PCM\n") == 2
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 2\nSample Rate    : 16000\nPrecision      : 16-bit\nDuration       : 00:00:01.25 = 4800 samples ~ 13.75 CDDA sectors\nFile Size      : 4.9k\nBit Rate       : 256k\nSample Encoding: 16-bit Signed Integer PCM\n") == 2
	assert candidate(b'Input File     : 03-quad.wav\nChannels       : 4') == 4
	assert candidate(b"Input File     : 'test.wav'\nChannels        : 1\nSample Rate     : 16000\nPrecision       : 16-bit\nDuration        : 00:00:00.24\nFile Size       : 1.11K\nBit Rate        : 64k\nSample Encoding : 16-bit Signed Integer PCM\n") == 1
	assert candidate(b"Input File     : 'test.wav'\nChannels       : 2\nSample Rate    : 44100\nPrecision      : 16-bit\nDuration       : 00:00:04.96 = 787040 samples ~ 170.523 CDDA sectors\nFile Size      : 4.44M\nBit Rate       : 640k\nSample Encoding: 16-bit Signed Integer PCM\n") == 2
	assert candidate(b'Input File     : 06-dual-mono.wav\nChannels       : 2') == 2
def test_check():
	check(parse_soxi_out)
