def serialize_utf8(value, partition_key):
    """ A serializer accepting bytes or str arguments and returning utf-8 encoded bytes
     
     Can be used as `pykafka.producer.Producer(serializer=serialize_utf8)`
     """
	### Canonical solution below ###    
    if value is not None and type(value) != bytes:
        # allow UnicodeError to be raised here if the encoding fails
        value = value.encode('utf-8')
    if partition_key is not None and type(partition_key) != bytes:
        partition_key = partition_key.encode('utf-8')
    return value, partition_key

### Unit tests below ###
def check(candidate):
	assert candidate(b'\xff', b'bar') == (b'\xff', b'bar')
	assert candidate(b'foo', b'bar') == (b'foo', b'bar')
	assert candidate(b'a', b'b') == (b'a', b'b')
	assert candidate(b"foo", b"bar") == (b"foo", b"bar")
	assert candidate(b'abc', u'abc') == (b'abc', b'abc')
	assert candidate(b'abc', b'def') == (b'abc', b'def')
	assert candidate(b'hello', b'world') == (b'hello', b'world')
	assert candidate(None, 'bar') == (None, b'bar')
	assert candidate(b'asdf', None) == (b'asdf', None)
	assert candidate(u'test', u'partition_key') == (b'test', b'partition_key')
	assert candidate(u'foo', b'bar') == (b'foo', b'bar')
	assert candidate(u'\u2603', u'\u2603') == (
    b'\xe2\x98\x83', b'\xe2\x98\x83')
	assert candidate(b"foo", b"bar") == (b'foo', b'bar')
	assert candidate(b'foo', 'bar') == (b'foo', b'bar')
	assert candidate(b'foobar', b'partition_key') == (b'foobar', b'partition_key')
	assert candidate("foo", "bar") == (b'foo', b'bar')
	assert candidate(None, None) == (None, None)
	assert candidate('hello', None) == (b'hello', None)
	assert candidate(b'test', b'test') == (b'test', b'test')
	assert candidate(b'\xe2\x98\x83', b'\xe2\x98\x83') == (
    b'\xe2\x98\x83', b'\xe2\x98\x83')
	assert candidate('foo', 'bar') == (b'foo', b'bar')
	assert candidate(u'asdf', None) == (b'asdf', None)
	assert candidate('test', 'test') == (b'test', b'test')
	assert candidate(b'a', None) == (b'a', None)
	assert candidate(u'abc', u'abc') == (b'abc', b'abc')
	assert candidate(u'abc', None) == (b'abc', None)
	assert candidate(u'foo', None) == (b'foo', None)
	assert candidate(b'foo', u'bar') == (b'foo', b'bar')
	assert candidate(b'test', b'partition_key') == (b'test', b'partition_key')
	assert candidate('\xff', 'bar') == (b'\xc3\xbf', b'bar')
	assert candidate(b'abc', None) == (b'abc', None)
	assert candidate(u'test', None) == (b'test', None)
	assert candidate(u"🐍", "🐍") == (b"\xf0\x9f\x90\x8d", b"\xf0\x9f\x90\x8d")
	assert candidate(u"foo", u"bar") == (b'foo', b'bar')
	assert candidate(u'abc', b'abc') == (b'abc', b'abc')
	assert candidate(u'foobar', 'partition_key') == (b'foobar', b'partition_key')
	assert candidate(u'foo', 'bar') == (b'foo', b'bar')
	assert candidate(b'foo', None) == (b'foo', None)
	assert candidate(u'\u2603', None) == (
    b'\xe2\x98\x83', None)
	assert candidate(b'asdf', u'asdf') == (b'asdf', b'asdf')
	assert candidate(u'abc', u'def') == (b'abc', b'def')
	assert candidate(u"foo", u"bar") == (b"foo", b"bar")
	assert candidate(u'a', None) == (b'a', None)
	assert candidate(b'hello', None) == (b'hello', None)
	assert candidate(u'hello', u'world') == (b'hello', b'world')
	assert candidate("foo", None) == (b"foo", None)
	assert candidate(u'\u20ac', u'world') == (b'\xe2\x82\xac', b'world')
	assert candidate(None, u'b') == (None, b'b')
	assert candidate("baz", "key") == (b"baz", b"key")
	assert candidate(None, u'def') == (None, b'def')
	assert candidate(None, b'b') == (None, b'b')
	assert candidate(b'test', None) == (b'test', None)
	assert candidate(u"a\u2603c", u"a\u2603c") == (b"a\xe2\x98\x83c", b"a\xe2\x98\x83c")
	assert candidate(u'test', u'test') == (b'test', b'test')
	assert candidate(u"qux", u"key") == (b"qux", b"key")
	assert candidate(b'test', 'test') == (b'test', b'test')
	assert candidate(u"bar", None) == (b"bar", None)
	assert candidate(u'hello', None) == (b'hello', None)
	assert candidate(None, b'def') == (None, b'def')
	assert candidate(b'hello', u'world') == (b'hello', b'world')
	assert candidate(b'abc', b'abc') == (b'abc', b'abc')
	assert candidate('test', b'test') == (b'test', b'test')
	assert candidate(u'hello', b'world') == (b'hello', b'world')
	assert candidate('foo', u'bar') == (b'foo', b'bar')
	assert candidate(u'a', u'b') == (b'a', b'b')
	assert candidate(b'\xe2\x98\x83', None) == (
    b'\xe2\x98\x83', None)
	assert candidate(b"\xf0\x9f\x90\x8d", b"\xf0\x9f\x90\x8d") == (b"\xf0\x9f\x90\x8d", b"\xf0\x9f\x90\x8d")
	assert candidate(u'asdf', u'asdf') == (b'asdf', b'asdf')
	assert candidate(u'foo', u'bar') == (b'foo', b'bar')
def test_check():
	check(serialize_utf8)
