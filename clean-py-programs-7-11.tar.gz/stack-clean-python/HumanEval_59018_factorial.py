def factorial(n):
    """ 
     input: positive integer 'n'
     returns the factorial of 'n' (n!)
     """
	### Canonical solution below ###    
    
    # precondition
    assert isinstance(n,int) and (n >= 0), "'n' must been a int and >= 0"
    
    ans = 1 # this will be return.
    
    for factor in range(1,n+1):
        ans *= factor
    
    return ans

### Unit tests below ###
def check(candidate):
	assert candidate(12) == 479001600
	assert candidate(6) == 720
	assert candidate(5) == 120
	assert candidate(1) == 1, "1! should be 1"
	assert candidate(1) == 1, "1! should equal 1"
	assert candidate(5) == 120, "5! should equal 120"
	assert candidate(22)
	assert candidate(4) == 24
	assert candidate(13) == 6227020800
	assert candidate(10) == 3628800
	assert candidate(14) == 87178291200
	assert candidate(18) == 6402373705728000
	assert candidate(5) == 120, "5! should be 120"
	assert candidate(2) == 2, "2! should equal 2"
	assert candidate(16) == 20922789888000
	assert candidate(15) == 1307674368000
	assert candidate(1) == 1
	assert candidate(19) == 121645100408832000
	assert candidate(21) == 51090942171709440000
	assert candidate(2) == 2
	assert candidate(8) == 40320
	assert candidate(30) == 265252859812191058636308480000000
	assert candidate(17) == 355687428096000
	assert candidate(3) == 6, "3! should equal 6"
	assert candidate(9) == 362880
	assert candidate(4) == 24, "4! should equal 24"
	assert candidate(20) == 2432902008176640000
	assert candidate(0) == 1
	assert candidate(7) == 5040
	assert candidate(3) == 6
	assert candidate(10) == 3628800, "10! should be 3628800"
	assert candidate(0) == 1, "0! should equal 1"
	assert candidate(11) == 39916800
def test_check():
	check(factorial)
