def zonehemisf(lon, lat, feature, parent):
    """ 
     Return the zone and hemisphere from longitude and latitude.
     <h2>Example usage:</h2>
     <ul>
     <li>zonehemisf("lon", "lat") -> 25S</li>
     </ul>
     """
	### Canonical solution below ###    
    # Calculo do Fuso
    fuso = round((183+lon)/6.0)
    # Hemisferio
    hemisf = 'N' if lat>= 0 else 'S'
    return str(fuso) + hemisf

### Unit tests below ###
def check(candidate):
	assert candidate(179.9, 89.9, "feature", "parent") == "60N", "candidate(179.9, 89.9, \"feature\", \"parent\") should return 60N"
	assert candidate(-179.9, 89.9, "feature", "parent")
	assert candidate(16.3888, 48.2000, "E", "F") == "33N", "Zonehemisf test 3 failed"
	assert candidate(37.0, 15.0, None, None) == '37N', "candidate(37.0, 15.0, None, None)"
	assert candidate(180, 90, "feature", "parent") == "60N"
def test_check():
	check(zonehemisf)
