def non_zero_balance(balance):
    """ 
     Return the balance with zero-value coins removed
     """
	### Canonical solution below ###    
    non_zero_balance = {}
    for coin, amount in balance.items():
        if amount > 0:
            non_zero_balance[coin] = amount

    return non_zero_balance

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'a': 1, 'b': 1, 'c': 1, 'd': 1}) == {'a': 1, 'b': 1, 'c': 1, 'd': 1}
	assert candidate(
    {'a': 1, 'b': 0, 'c': 0, 'd': 1}) == {'a': 1, 'd': 1}
	assert candidate(balance={'a': 1, 'b': 1, 'c': 0}) == {'a': 1, 'b': 1}
	assert candidate(
    {
        "BTC": 0,
        "BCH": 0,
        "LTC": 1,
        "ETH": 0
    }
) == {
    "LTC": 1
}
	assert candidate({'Bitcoin': 10000, 'Ethereum': 0}) == {'Bitcoin': 10000}
	assert candidate(
    {
        "BTC": 0,
        "BCH": 0,
        "LTC": 0,
        "ETH": 1
    }
) == {
    "ETH": 1
}
	assert candidate(
    {'a': 1, 'b': 0, 'c': 1, 'd': 1}) == {'a': 1, 'c': 1, 'd': 1}
	assert candidate(
        {'BTC': 1, 'ETH': 1, 'DOGE': 0, 'XMR': 3, 'LTC': 4, 'BCH': 5}) == {
        'BTC': 1, 'ETH': 1, 'XMR': 3, 'LTC': 4, 'BCH': 5}
	assert candidate(
    {"BTC": 1, "ETH": 1, "LTC": 2}) == {"BTC": 1, "ETH": 1, "LTC": 2}
	assert candidate(
    {"BTC": 1, "ETH": 0, "LTC": 2}) == {"BTC": 1, "LTC": 2}
	assert candidate(balance={'a': 0, 'b': 0, 'c': 0}) == {}
	assert candidate(
    {
        "BTC": 0,
        "BCH": 0,
        "LTC": 0,
        "ETH": 0
    }
) == {}
	assert candidate(
    {"Bitcoin": 0, "Litecoin": 100, "Dogecoin": 200}) == {"Litecoin": 100, "Dogecoin": 200}
	assert candidate(
        {'BTC': 1, 'ETH': 1, 'DOGE': 2, 'XMR': 0, 'LTC': 4, 'BCH': 5}) == {
        'BTC': 1, 'ETH': 1, 'DOGE': 2, 'LTC': 4, 'BCH': 5}
	assert candidate(
    {
        "BTC": 0,
        "BCH": 0,
        "LTC": 1,
        "ETH": 2
    }
) == {
    "LTC": 1,
    "ETH": 2
}
	assert candidate(balance={'a': 1, 'b': 1, 'c': 1}) == {'a': 1, 'b': 1, 'c': 1}
	assert candidate(
    {'BTC': 0.0, 'ETH': 1.0, 'LTC': 1.0}) == {'ETH': 1.0, 'LTC': 1.0}
	assert candidate(
    {
        'BTC': 0,
        'ETH': 0,
        'USD': 0,
    },
) == {}
	assert candidate(
    {'a': 100, 'b': 1, 'c': 0, 'd': 0}) == {'a': 100, 'b': 1}
	assert candidate(
    {"BTC": 1, "ETH": 1, "LTC": 0}) == {"BTC": 1, "ETH": 1}
	assert candidate(
    {'BTC': 0.0, 'ETH': 0.0, 'LTC': 0.0}) == {}
	assert candidate(
        {'BTC': 1, 'ETH': 0, 'DOGE': 2, 'XMR': 3, 'LTC': 4, 'BCH': 5}) == {
        'BTC': 1, 'DOGE': 2, 'XMR': 3, 'LTC': 4, 'BCH': 5}
	assert candidate(
    {
        "BTC": 0,
        "BCH": 1,
        "LTC": 0,
        "ETH": 0
    }
) == {
    "BCH": 1
}
	assert candidate(
    {'Bitcoin': 0, 'Ethereum': 1, 'Ripple': 2, 'Bitcoin Cash': 3}) == {'Ethereum': 1, 'Ripple': 2, 'Bitcoin Cash': 3}
	assert candidate(
    {"Bitcoin": 0, "Litecoin": 0, "Dogecoin": 0}) == {}
	assert candidate(
    {
        'BTC': 0,
        'ETH': 1000,
        'LTC': 2000
    }
) == {
    'ETH': 1000,
    'LTC': 2000
}
	assert candidate(
    {
        'BTC': 0,
        'ETH': 10,
        'USD': 0,
    },
) == {'ETH': 10}
	assert candidate(
    {"Bitcoin": 100, "Litecoin": 0, "Dogecoin": 200}) == {"Bitcoin": 100, "Dogecoin": 200}
	assert candidate(balance={'a': 0, 'b': 0, 'c': 1}) == {'c': 1}
	assert candidate(
    {'a': 0, 'b': 1, 'c': 0, 'd': 1}) == {'b': 1, 'd': 1}
	assert candidate(
    {
        "BTC": 1,
        "BCH": 0,
        "LTC": 0,
        "ETH": 0
    }
) == {
    "BTC": 1
}
	assert candidate(
    {'BTC': 0.0, 'ETH': 0.0, 'LTC': 1.0}) == {'LTC': 1.0}
	assert candidate(balance={'a': 0, 'b': 1, 'c': 0}) == {'b': 1}
	assert candidate(
    {
        'BTC': 10,
        'ETH': 10,
        'USD': 0,
    },
) == {'BTC': 10, 'ETH': 10}
	assert candidate(
    {"BTC": 0, "ETH": 1, "LTC": 2}) == {"ETH": 1, "LTC": 2}
	assert candidate(balance={'a': 0, 'b': 1, 'c': 1}) == {'b': 1, 'c': 1}
	assert candidate(
        {'BTC': 0, 'ETH': 1, 'DOGE': 2, 'XMR': 3, 'LTC': 4, 'BCH': 5}) == {
        'ETH': 1, 'DOGE': 2, 'XMR': 3, 'LTC': 4, 'BCH': 5}
	assert candidate(
    {'a': 1, 'b': 1, 'c': 0, 'd': 1}) == {'a': 1, 'b': 1, 'd': 1}
	assert candidate(balance={'a': 1, 'b': 0, 'c': 1}) == {'a': 1, 'c': 1}
	assert candidate( {'a':1, 'b':2, 'c':0}) == {'a':1, 'b':2}
	assert candidate(balance={'a': 1, 'b': 0, 'c': 0}) == {'a': 1}
	assert candidate(
    {'a': 0, 'b': 1, 'c': 0, 'd': 100}) == {'b': 1, 'd': 100}
	assert candidate({'Bitcoin': 10000, 'Ethereum': 10000}) == {'Bitcoin': 10000, 'Ethereum': 10000}
	assert candidate(
    {"Bitcoin": 100, "Litecoin": 100, "Dogecoin": 0}) == {"Bitcoin": 100, "Litecoin": 100}
def test_check():
	check(non_zero_balance)
