def domain(url):
    """ 
     Extracts the domain of an url
     
     >>> domain('https://gitlab.laas.fr/pipo')
     'gitlab.laas.fr'
     
     >>> domain('gitlab.laas.fr/pipo')
     'gitlab.laas.fr'
     """
	### Canonical solution below ###    
    if '://' in url or url.startswith('//'):
        url = url.split('//')[1]
    return url.split('/')[0]

### Unit tests below ###
def check(candidate):
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr'
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate 2"
	assert candidate('http://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'Extract candidate from url without protocol'
	assert candidate('gitlab.laas.fr') == 'gitlab.laas.fr'
	assert candidate(
    'gitlab.laas.fr/pipo') == 'gitlab.laas.fr'
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate 1"
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', \
    "candidate(gitlab.laas.fr/pipo) should be 'gitlab.laas.fr'"
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate('gitlab.laas.fr/pipo')"
	assert candidate(
    "https://gitlab.laas.fr/pipo") == "gitlab.laas.fr"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate with https"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate('https://gitlab.laas.fr/pipo')"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', \
    "candidate(https://gitlab.laas.fr/pipo) should be 'gitlab.laas.fr'"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate test 1"
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'Extract candidate from url without protocol'
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate is wrong"
	assert candidate('http://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'candidate'
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate without https"
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate should return the candidate of a url"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'candidate failed'
	assert candidate(
    'gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'candidate test 2'
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate('gitlab.laas.fr/pipo') is incorrect"
	assert candidate('https://gitlab.laas.fr') == 'gitlab.laas.fr'
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate('https://gitlab.laas.fr/pipo') is incorrect"
	assert candidate('http://gitlab.laas.fr') == 'gitlab.laas.fr', 'candidate'
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate on http url"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'candidate'
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'Failed test 2'
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate should return the candidate of a url"
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'candidate failed'
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', candidate(
        'https://gitlab.laas.fr/pipo')
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr'
	assert candidate('http://gitlab.laas.fr/') == 'gitlab.laas.fr', 'candidate'
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate is wrong"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'Extract candidate from http url'
	assert candidate("gitlab.laas.fr/pipo") == "gitlab.laas.fr"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', candidate(
    'https://gitlab.laas.fr/pipo')
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate on https url"
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'candidate test 1'
	assert candidate(
    'gitlab.laas.fr/pipo') == 'gitlab.laas.fr', "candidate test 2"
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', candidate(
    'gitlab.laas.fr/pipo')
	assert candidate(
    'https://gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'Failed test 1'
	assert candidate('//gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'Extract candidate from url without protocol'
	assert candidate('gitlab.laas.fr/pipo') == 'gitlab.laas.fr', 'candidate'
def test_check():
	check(domain)
