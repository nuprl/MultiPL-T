def apply_policy(observation):
    """ 
     A policy under which one will stick if the sum of cards is >= 20 and hit otherwise.
     """
	### Canonical solution below ###    
    score, dealer_score, usable_ace = observation
    return 0 if score >= 20 else 1

### Unit tests below ###
def check(candidate):
	assert candidate(observation=(10, 12, True)) == 1
	assert candidate(observation=(19, 20, True)) == 1
	assert candidate(observation=(18, 20, False)) == 1
	assert candidate(observation=[10, 7, False]) == 1
	assert candidate(observation=(12, 18, False)) == 1
	assert candidate(observation=(17, 21, True)) == 1
	assert candidate(observation=(12, 14, True)) == 1
	assert candidate((30, 2, False)) == 0
	assert candidate(observation=[19, 8, False]) == 1
	assert candidate(observation=[18, 17, False]) == 1
	assert candidate(observation=(12, 15, False)) == 1
	assert candidate(observation = (10, 10, False)) == 1
	assert candidate((38, 2, False)) == 0
	assert candidate(observation=[2, 3, False]) == 1
	assert candidate((20, 2, False)) == 0
	assert candidate(observation=(12, 21, False)) == 1
	assert candidate(observation=(10, 21, False)) == 1
	assert candidate(observation=(12, 16, False)) == 1
	assert candidate((29, 2, False)) == 0
	assert candidate(observation=[19, 2, False]) == 1
	assert candidate(observation=(19, 18, True)) == 1
	assert candidate(observation=(17, 19, False)) == 1
	assert candidate(observation=(15, 20, False)) == 1
	assert candidate(observation=[10, 9, True]) == 1
	assert candidate(observation=(10, 17, False)) == 1
	assert candidate(observation=(16, 20, True)) == 1
	assert candidate(observation=(10, 15, True)) == 1
	assert candidate((35, 2, False)) == 0
	assert candidate(observation=(22, 13, False)) == 0
	assert candidate( (20, 10, 1) ) == 0
	assert candidate(observation=(1, 13, True)) == 1
	assert candidate(observation=(18, 21, False)) == 1
	assert candidate(observation=(10, 20, False)) == 1
	assert candidate(observation=(12, 13, True)) == 1
	assert candidate(observation=(17, 18, True)) == 1
	assert candidate(observation=(19, 20, False)) == 1
	assert candidate(observation=(17, 19, True)) == 1
	assert candidate(observation=(10, 14, True)) == 1
	assert candidate((34, 2, False)) == 0
	assert candidate(observation=(10, 14, False)) == 1
	assert candidate(observation=(19, 18, False)) == 1
	assert candidate(observation=[11, 6, False]) == 1
	assert candidate(observation=(10, 13, False)) == 1
	assert candidate(observation=(12, 16, True)) == 1
	assert candidate(observation=(12, 19, True)) == 1
	assert candidate(observation=[17, 8, False]) == 1
	assert candidate(observation=(16, 17, True)) == 1
	assert candidate(observation=(10, 18, True)) == 1
	assert candidate(observation=(12, 17, False)) == 1
	assert candidate(observation=(18, 20, True)) == 1
	assert candidate((25, 2, False)) == 0
	assert candidate(observation=(17, 21, False)) == 1
	assert candidate(observation=[20, 2, False]) == 0
	assert candidate( (1, 10, 1) ) == 1
	assert candidate(observation=(10, 18, False)) == 1
	assert candidate(observation=(12, 17, True)) == 1
	assert candidate(observation=(12, 20, True)) == 1
	assert candidate((19, 2, False)) == 1
	assert candidate(observation=(12, 15, True)) == 1
	assert candidate(observation=(17, 18, False)) == 1
	assert candidate(observation=[1, 11, False]) == 1
	assert candidate(observation=(12, 19, False)) == 1
	assert candidate(observation = (2, 7, True)) == 1
	assert candidate((28, 2, False)) == 0
	assert candidate(observation=(10, 15, False)) == 1
	assert candidate(observation=(12, 21, True)) == 1
	assert candidate(observation=[20, 17, False]) == 0
	assert candidate(observation=(10, 20, True)) == 1
	assert candidate((24, 2, False)) == 0
	assert candidate(observation=(10, 19, False)) == 1
	assert candidate(observation=(10, 17, True)) == 1
	assert candidate((21, 2, False)) == 0
	assert candidate(observation=(1, 2, False)) == 1
	assert candidate(observation=(12, 20, False)) == 1
	assert candidate(observation=(10, 13, True)) == 1
	assert candidate(observation=(18, 19, False)) == 1
	assert candidate(observation=(15, 20, True)) == 1
	assert candidate(observation=(21, 20, False)) == 0
	assert candidate( (17, 10, 1) ) == 1
	assert candidate(observation=(16, 20, False)) == 1
	assert candidate(observation=[19, 2, True]) == 1
	assert candidate(observation=[12, 6, False]) == 1
	assert candidate(observation=(10, 19, True)) == 1
	assert candidate(observation=(2, 2, False)) == 1
	assert candidate(observation=(13, 17, True)) == 1
	assert candidate(observation=(16, 17, False)) == 1
	assert candidate(observation=[10, 9, False]) == 1
	assert candidate(observation=(12, 14, False)) == 1
	assert candidate(observation=(18, 21, True)) == 1
	assert candidate(observation=(1, 2, True)) == 1
	assert candidate(observation=(12, 18, True)) == 1
	assert candidate(observation=(18, 18, True)) == 1
	assert candidate(observation=(10, 16, True)) == 1
	assert candidate(observation=(10, 16, False)) == 1
	assert candidate(observation=(17, 20, False)) == 1
	assert candidate(observation=(18, 13, False)) == 1
	assert candidate(observation=(19, 13, False)) == 1
	assert candidate(observation=(20, 18, True)) == 0
	assert candidate(observation=(20, 18, False)) == 0
	assert candidate(observation=(18, 17, True)) == 1
	assert candidate(observation=(18, 19, True)) == 1
	assert candidate(observation=(21, 20, True)) == 0
	assert candidate((18, 2, False)) == 1
	assert candidate(observation = (10, 10, True)) == 1
	assert candidate(observation = (2, 7, False)) == 1
	assert candidate(observation=(17, 20, True)) == 1
	assert candidate(observation=(10, 11, True)) == 1
	assert candidate(observation=(10, 12, False)) == 1
	assert candidate(observation=[20, 8, False]) == 0
def test_check():
	check(apply_policy)
