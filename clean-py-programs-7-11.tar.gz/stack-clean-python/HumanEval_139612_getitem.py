def getitem(dict, item):
    """ my_dict|getitem:'b' """
	### Canonical solution below ###    
    try:
        return dict.get(item)
    except KeyError:
        return ''

### Unit tests below ###
def check(candidate):
	assert candidate(dict(a=1, b=2), 'b') == 2
	assert candidate(dict(a=1, b=2, c=3), 'b') == 2
	assert candidate(dict(a=1, b=2), 'a') == 1
	assert candidate(dict({1: 1, 2: 2}), 1) == 1
	assert candidate(dict(a='A'), 'a') == 'A'
	assert candidate(dict(a=1, b=2, c=3), 'c') == 3
	assert candidate(dict(a=1, b=2, c=3), 'a') == 1
	assert candidate(dict(a='b'), 'a') == 'b'
	assert candidate(dict({1: 1, 2: 2}), 2) == 2
	assert candidate(dict(a=1), 'a') == 1
def test_check():
	check(getitem)
