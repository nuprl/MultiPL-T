def sum_items(a_list):
    """ 
     @purpose Returns the sum of all items in a_list, and return 0 if empty list
     @param
     a_list: a list of items passed to this function to sum
     @complexity:
     Worst Case - O(N): When summing all values of a list with N items
     Best Case - O(1): when passing empty list
     @precondition Passing a list with numerical values
     @postcondition Return the sum of those numerical values in list
     """
	### Canonical solution below ###    
    try:
        if len(a_list) > 0:
            #Naive linear iterating to sum
            sum = 0
            for i in range(len(a_list)):
                sum += a_list[i]
            return sum
        else:
            return 0
    except TypeError:
        return "Please only insert numerical type lists."

### Unit tests below ###
def check(candidate):
	assert candidate([]) == 0
	assert candidate(a_list=[0,0,0,0,0]) == 0, "Should be 0"
	assert candidate("string") == "Please only insert numerical type lists."
	assert candidate([1, "hello", 3]) == "Please only insert numerical type lists."
	assert candidate(a_list=[10,10,10,10,10]) == 50, "Should be 50"
	assert candidate(list(range(1, 10))) == 45
	assert candidate([1,2,3,4,"a"]) == "Please only insert numerical type lists."
	assert candidate(a_list="hello") == "Please only insert numerical type lists.", "Should be 'Please only insert numerical type lists.'"
	assert candidate(a_list=[1,2,3,4]) == 10, "Failed to return the correct sum"
	assert candidate( [1, 2, 3, 4, "5"] ) == "Please only insert numerical type lists."
	assert candidate([1, 2, 3, "cat"]) == "Please only insert numerical type lists."
	assert candidate(range(10)) == 45
	assert candidate(a_list = [5,6,7,8]) == 26, "Sum should be 26"
	assert candidate(list(range(5))) == 10
	assert candidate(a_list=[1,2,3,4,"a"]) == "Please only insert numerical type lists.", "Should return error message"
	assert candidate([1,'a',3]) == "Please only insert numerical type lists.", "Should return error message"
	assert candidate(a_list=None) == "Please only insert numerical type lists."
	assert candidate([]) == 0, "Sum is incorrect"
	assert candidate( [1, 2, 3, 4, 5] ) == 15
	assert candidate(a_list=[1.0,2.0,3.0,4.0,5.0]) == 15.0, "Sum of a list of numbers should be 15"
	assert candidate([1, 2, 3, 4, 5]) == 15, "Should be 15"
	assert candidate([]) == 0, "Should be 0"
	assert candidate([1, 2, 3, 4]) == 10
	assert candidate([1,2,3,"a"]) == "Please only insert numerical type lists."
	assert candidate( [1, 2, 3] ) == 6, "Sum is not correct"
	assert candidate([]) == 0, "Error! Empty list returns a value"
	assert candidate([1, 2, 3, 4, "a"]) == "Please only insert numerical type lists."
	assert candidate([10,20,30,40,50]) == 150, "Should return 150"
	assert candidate([1, 2, 3, "4"]) == "Please only insert numerical type lists."
	assert candidate([]) == 0, "Sum is not correct"
	assert candidate(a_list=[10, 20, 30, 40, 50, 60, 70, 80, 90, 100]) == 550
	assert candidate([1, 2, 3, "four"]) == "Please only insert numerical type lists."
	assert candidate(a_list=[1,2,3,4,5,6,7,8,9,10]) == 55, "Should return 55"
	assert candidate([1,"a",True,False,2.2]) == "Please only insert numerical type lists."
	assert candidate([1,2,3,4,5,6,7,8,9]) == 45
	assert candidate("abc") == "Please only insert numerical type lists.", "Should return 'Please only insert numerical type lists.'"
	assert candidate(a_list = [1,2,3,4,5]) == 15, "Sum should be 15"
	assert candidate(a_list=[1,2,3,4,"a"]) == "Please only insert numerical type lists."
	assert candidate(a_list=[1,2,"3",4,5,6]) == "Please only insert numerical type lists."
	assert candidate(a_list=[]) == 0
	assert candidate(a_list=[1,2,3,4,5,6]) == 21
	assert candidate(a_list=[1,2,3]) == 6, "Should be 6"
	assert candidate(list([1])) == 1
	assert candidate([2, 4, 6, 8]) == 20
	assert candidate([1, 2, 3, "hello", 5]) == "Please only insert numerical type lists."
	assert candidate(a_list=[1,2,3,4,5]) == 15
	assert candidate(a_list=[1,2,3,4,5]) == 15, "Should be 15"
	assert candidate("not a list") == "Please only insert numerical type lists."
	assert candidate([1, 2, 3]) == 6
	assert candidate(1) == "Please only insert numerical type lists."
	assert candidate( [1, 2, 3, "a"] ) == "Please only insert numerical type lists.", "Sum is not correct"
	assert candidate(a_list=[1, 2, 3, "four", 5]) == "Please only insert numerical type lists."
	assert candidate(a_list=[-1]) == -1
	assert candidate(list([1,2,3])) == 6
	assert candidate(a_list=[]) == 0, "Should be 0"
	assert candidate(list()) == 0, "Should return 0"
	assert candidate([1, 2, 3, 4, 5]) == 15, "Error! Sum of list is incorrect"
	assert candidate(a_list=[]) == 0, "Should return 0"
	assert candidate( [] ) == 0
	assert candidate(a_list = [1,2,3,4,5,6,7,8]) == 36, "Sum should be 36"
	assert candidate([1,2,3,4,5]) == 15, "Should return 15"
	assert candidate(a_list = [1,2,3,4,5,6]) == 21, "Sum should be 21"
	assert candidate([1, 2, 3, "a"]) == "Please only insert numerical type lists.", "Should return error message"
	assert candidate(a_list=['a', 'b', 'c', 'd']) == "Please only insert numerical type lists.", "Failed to return the correct sum"
	assert candidate(list(range(1,10))) == 45, "Should be 45"
	assert candidate(a_list = [1,2,3,4,5,6,7,8,9,10]) == 55, "Sum should be 55"
	assert candidate(a_list=[1, 2, 3, 4]) == 10
	assert candidate(a_list=['a','b','c','d']) == "Please only insert numerical type lists."
	assert candidate(a_list=[1000, 2000, 3000, 4000]) == 10000
	assert candidate(list([1,2])) == 3
	assert candidate(a_list=[-1,-2,-3,-4]) == -10, "Failed to return the correct sum"
	assert candidate( [10, 20, 30] ) == 60, "Sum is not correct"
	assert candidate(list(range(10))) == 45
	assert candidate(a_list=[-1,-2,-3]) == -6, "Should be -6"
	assert candidate(a_list=[1,'b',3,4]) == "Please only insert numerical type lists."
	assert candidate([1,2,3,4]) == 10
	assert candidate([1, 2, 3, 4, 5, 6]) == 21
	assert candidate(a_list=[1, 2, 3, 4, 5]) == 15
	assert candidate(list([1,2,3,4,5])) == 15
	assert candidate(a_list = [1,2,3,4,5,6,7]) == 28, "Sum should be 28"
	assert candidate(a_list=[1]) == 1
	assert candidate("1") == "Please only insert numerical type lists."
	assert candidate(a_list=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 55
	assert candidate(a_list=[]) == 0, "Failed to return the correct sum"
	assert candidate(a_list=[-1,-2,-3,-4,-5,-6,-7,-8,-9,-10]) == -55
	assert candidate([100,200,300,400,500]) == 1500, "Should return 1500"
	assert candidate(list()) == 0, "Empty list should return 0"
	assert candidate(a_list=[-10, -20, -30, -40]) == -100
	assert candidate(list([1,2,3,4])) == 10
	assert candidate(a_list=[-1,-2,-3,-4,-5,-6,-7,-8]) == -36
	assert candidate([1, 2, 3]) == 6, "Should return 6"
	assert candidate("a") == "Please only insert numerical type lists."
	assert candidate(a_list=[1,2,3]) == 6
	assert candidate(a_list=[1, 2, 3, "a"]) == "Please only insert numerical type lists."
	assert candidate(a_list=[1,2,3,4]) == 10
	assert candidate([4, "a", 6]) == "Please only insert numerical type lists."
	assert candidate([1,2,3,4,5]) == 15
	assert candidate(a_list=[1,2,3,4,5]) == 15, "Sum of a list of numbers should be 15"
	assert candidate(a_list=[1,"a",3,4,5]) == "Please only insert numerical type lists.", "Should be error msg"
	assert candidate(a_list = [1,2,3,4,5,6,7,8,9]) == 45, "Sum should be 45"
	assert candidate([1, 2, 3, 4, 5]) == 15
	assert candidate([1,2,3]) == 6, "Should be 6"
	assert candidate(a_list = [1,2,3,4]) == 10, "Sum should be 10"
def test_check():
	check(sum_items)
