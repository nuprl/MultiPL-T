def distance(x1, x2, y1, y2):
    """ Returns the distance between two coords"""
	### Canonical solution below ###    
    return ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5

### Unit tests below ###
def check(candidate):
	assert candidate(0, 0, -2, 0) == 2
	assert candidate(0, 3, 0, 4) == 5
	assert candidate(1, 2, 3, 4) == 2 ** 0.5
	assert candidate(0, 4, 3, 0) == 5
	assert candidate(0, 4, 0, 3) == 5
	assert candidate(4, 0, 0, 3) == 5
	assert candidate(0, 0, -3, 0) == 3
	assert candidate(3, 3, 0, 0) == 0
	assert candidate(-3, -3, 0, 0) == 0
	assert candidate(0, 0, 3, 0) == 3
	assert candidate(1, 1, 1, 1) == 0
	assert candidate(3, 0, 0, 4) == 5
	assert candidate(0, 0, -1, 0) == 1
	assert candidate(0, 0, -3, -3) == 0
	assert candidate(0, 1, 0, 1) == 1.4142135623730951
	assert candidate(3, 0, 4, 0) == 5
	assert candidate(0, 0, 0, 0) == 0
	assert candidate(0, 0, 1, 0) == 1
	assert candidate(0, 0, 0, 2) == 2
	assert candidate(0, 0, 3, 3) == 0
	assert candidate(0, 0, 0, 1) == 1
	assert candidate(1, 4, 4, 0) == 5.0
	assert candidate(1, 1, 2, 1) == 1
	assert candidate(1, 2, 1, 1) == 1
	assert candidate(1, 1, 1, 2) == 1
	assert candidate(0, 0, 2, 0) == 2
def test_check():
	check(distance)
