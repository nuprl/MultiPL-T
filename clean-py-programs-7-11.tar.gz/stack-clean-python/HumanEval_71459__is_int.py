def _is_int(v):
    """Return True if the object v can be turned into an integer."""
    ### Canonical solution below ###
    try:
        int(v)
        return True
    except ValueError:
        return False


### Unit tests below ###
def check(candidate):
	assert not candidate('a')
	assert candidate(1)
	assert not candidate('foo')
	assert not candidate('1.1')
	assert candidate(100)
	assert candidate(-1) == True
	assert candidate(1.0)
	assert candidate(-1)
	assert not candidate('1.0')
	assert not candidate('1.0 + 1.0j')
	assert candidate('1')
	assert candidate(0)
	assert candidate(0) == True
	assert not candidate('1e1')
	assert candidate(1e100)
	assert candidate(1.0) == True
	assert not candidate("1.0")
	assert not candidate("a")
	assert candidate(1) == True
	assert candidate("1")
	assert not candidate('one')
def test_check():
	check(_is_int)
