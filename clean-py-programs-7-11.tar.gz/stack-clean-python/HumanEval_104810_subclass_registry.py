def subclass_registry(collection, *attrs):
    """ Metaclass constructor which maintains a registry of subclasses."""
	### Canonical solution below ###    

    class registry(type):
        def __new__(metatype, name, bases, namespace):
            implementation = type.__new__(metatype, name, bases, namespace)
            subclasses = getattr(implementation, collection)

            identifier = None
            if attrs:
                for attr in attrs:
                    identifier = getattr(implementation, attr, None)
                    if identifier:
                        subclasses[identifier] = implementation
            else:
                module = namespace.get('__module__')
                if module and module != '__main__':
                    identifier = '%s.%s' % (module, name)
                if identifier:
                    subclasses[identifier] = implementation

            return implementation
    return registry

### Unit tests below ###
def check(candidate):
	assert candidate(
    '_subclasses', '_identifier', '_label', '_plural_label', '_plural_label_lower')
	assert candidate(
    '_registry', 'identifier'
).__name__ =='registry'
	assert candidate(
    '_subclasses',
    'identifier',
    'identifier_alt',
    'identifier_alt2'
) is not None
	assert candidate(
    '__subclasses__', 'identifier',
)
	assert candidate(
    '__subclasses__',
    'identifier'
)('Foo', (), {})
	assert candidate(
   'registry',
    '__module__',
)
	assert candidate(
    '_subclasses', '_identifier', '_registry').__name__ =='registry'
	assert candidate(
    '__subclasses__',
)
	assert candidate(
    '__subclasses__',
    'identifier'
).__subclasses__ == candidate(
    '__subclasses__',
    'identifier'
).__subclasses__
	assert candidate(
   'subclasses', 'identifier'
).__name__ =='registry'
def test_check():
	check(subclass_registry)
