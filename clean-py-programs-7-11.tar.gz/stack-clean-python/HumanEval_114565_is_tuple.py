def is_tuple(a):
    """Check if argument is a tuple"""
    ### Canonical solution below ###
    return isinstance(a, tuple)


### Unit tests below ###
def check(candidate):
	assert candidate("hi") == False
	assert candidate( (1, 2, 3) )
	assert not candidate(1)
	assert candidate([1, 2]) == False
	assert candidate(42) == False
	assert candidate((1, 2))
	assert candidate([1,2,3]) == False
	assert candidate(False) == False
	assert candidate(b"hello") == False
	assert candidate("abc") == False
	assert candidate({1: 2, 3: 4}) == False
	assert not candidate( 1.0 )
	assert candidate('string') == False
	assert candidate('a') == False
	assert candidate('abc') == False
	assert candidate((1,2)) is True
	assert candidate([1, 2, 3]) == False
	assert candidate(bytearray(b"abc")) == False
	assert candidate((1,)) == True
	assert not candidate([])
	assert candidate(bytearray()) == False
	assert candidate( () )
	assert candidate({"a": 1}) == False
	assert candidate((1, 2, 3)) == True
	assert candidate([1]) == False
	assert not candidate( 1 )
	assert candidate(Ellipsis) == False
	assert not candidate('abc')
	assert candidate(object()) == False
	assert candidate(1) is False
	assert candidate(b"abc") == False
	assert candidate((1,2,3)) == True
	assert candidate(None) == False
	assert candidate( (1,2,3) )
	assert not candidate( 5 )
	assert not candidate(dict())
	assert candidate("hello") == False
	assert candidate((1, 2, 3, 4))
	assert candidate((1, 2)) == True
	assert not candidate(None)
	assert candidate(['a', 'b', 'c']) == False
	assert candidate(range(1)) == False
	assert not candidate( [1, 2, 3] )
	assert not candidate(1.0)
	assert candidate(()) is True
	assert not candidate( [] )
	assert not candidate( [1,2,3] )
	assert candidate(b"hi") == False
	assert candidate(True) == False
	assert candidate(b"") == False
	assert candidate(1.1) == False
	assert candidate(range(2)) == False
	assert not candidate(set())
	assert candidate(memoryview(b"abc")) == False
	assert candidate({1, 2, 3}) == False
	assert candidate(1) == False
	assert not candidate( "hello" )
	assert candidate("1") == False
	assert candidate({1: 2}) == False
	assert candidate(range(0)) == False
	assert not candidate( "str" )
	assert candidate({'a': 1, 'b': 2}) == False
	assert candidate((1, 2)) is True
	assert candidate(range(3)) == False
	assert not candidate(b"hello")
	assert candidate(tuple())
	assert candidate([1,2]) == False
	assert candidate((1, 2, 3))
	assert candidate((1,2)) == True
	assert candidate("foo") == False
	assert not candidate(b"")
	assert candidate(range(5)) == False
	assert candidate("") == False
	assert candidate(lambda x: x) == False
	assert candidate(()) == True
	assert candidate(b"123") == False
	assert candidate("123") == False
	assert not candidate("")
	assert candidate("str") == False
	assert not candidate( None )
	assert not candidate([1, 2, 3])
	assert candidate([]) == False
	assert candidate(NotImplemented) == False
	assert not candidate("hello")
	assert candidate(1.0) == False
	assert candidate(range(10)) == False
	assert not candidate( '123' )
	assert candidate([]) is False
	assert candidate(frozenset([1, 2])) == False
	assert candidate(set([1, 2])) == False
	assert not candidate(False)
	assert not candidate(True)
	assert candidate(set()) == False
def test_check():
	check(is_tuple)
