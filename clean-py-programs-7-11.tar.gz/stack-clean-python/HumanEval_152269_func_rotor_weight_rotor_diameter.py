def func_rotor_weight_rotor_diameter(
    power: int, coeff_a: float, coeff_b: float
) -> float:
    """
    Returns rotor weight, in kg, based on rotor diameter.
    :param power: power output (kW)
    :param coeff_a: coefficient
    :param coeff_b: coefficient
    :return: nacelle weight (in kg)
    """
    ### Canonical solution below ###
    rotor_mass = coeff_a * power ** 2 + coeff_b * power
    return 1e3 * rotor_mass


### Unit tests below ###
def check(candidate):
	assert candidate(1000, 1.2e3, 0.3e3)!= 1068.5
	assert candidate(1000, 1.2e3, 0.3e3)!= 1068.3
	assert candidate(0, 1, 1) == 0.0
	assert candidate(100, 0, 0) == 0.0, "Incorrect value"
	assert candidate(0.0, 0.0, 0.0) == 0.0
	assert candidate(1000, 1.2e3, 0.3e3)!= 1068
def test_check():
	check(func_rotor_weight_rotor_diameter)
