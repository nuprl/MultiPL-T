def output(input):
    """ 
     If input object has attribute "GetOutput()" then return an itk image,
     otherwise this function simply returns the input value
     """
	### Canonical solution below ###    
    if hasattr(input, "GetOutput"):
        return input.GetOutput()
    return input

### Unit tests below ###
def check(candidate):
	assert candidate(3) == 3
	assert candidate(1.0) == 1.0
	assert candidate(None) == None
	assert candidate("1") == "1"
	assert candidate(1) == 1
	assert candidate(None) is None
	assert candidate("test") == "test"
def test_check():
	check(output)
