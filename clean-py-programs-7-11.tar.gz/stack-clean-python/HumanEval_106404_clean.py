def clean(s):
    """Clean a string."""
    ### Canonical solution below ###
    return s.replace(u'\\xa0', u' ').replace("\\n", " ").strip()


### Unit tests below ###
def check(candidate):
	assert candidate(u"\\xa0a\\xa0b\\xa0c\\xa0d\\xa0") == u"a b c d"
	assert candidate(u'\\n') == u''
	assert candidate(u'\\n\\n\\nhello') == u'hello'
	assert candidate("hello \\xa0") == "hello"
	assert candidate("\\n") == ""
	assert candidate(u'\\xa0\\xa0Hello\\xa0\\xa0\\n\\n') == u'Hello'
	assert candidate(u'hello\\n') == u'hello'
	assert candidate(u"\\xa0 \\xa0") == u""
	assert candidate(u'\\xa0\\xa0hello\\xa0') == u'hello'
	assert candidate(u'\\xa0hello') == u'hello'
	assert candidate(u"\\n\\n\\n\\n") == u""
	assert candidate(u'\\n\\n\\xa0\\n\\n') == u''
	assert candidate(u"\\xa0 \\xa0 \\xa0 \\xa0 \\xa0 \\xa0") == u""
	assert candidate(u'\\xa0 \\xa0 \\xa0 \\n \\xa0 \\n \\xa0 \\n \\xa0 \\n \\xa0 \\n') == u''
	assert candidate(u'hello\\nworld') == u'hello world'
	assert candidate(u'\\n\\n\\n\\n\\nhello') == u'hello'
	assert candidate(u'\\n\\n\\n\\n\\n\\nhello') == u'hello'
	assert candidate(u'\\nhello') == u'hello'
	assert candidate(u'hello') == u'hello'
	assert candidate(u"\\xa0 \\xa0 \\xa0 \\xa0") == u""
	assert candidate(u"foo\\xa0") == u"foo"
	assert candidate(u'\\xa0\\n') == u''
	assert candidate(u"\\xa0a\\xa0b\\xa0") == u"a b"
	assert candidate(u"\\xa0a\\xa0") == u"a"
	assert candidate(u'\\n\\xa0\\n') == u''
	assert candidate(u'\\xa0\\n\\xa0\\n\\xa0') == u''
	assert candidate(u'hello\\xa0\\xa0') == u'hello'
	assert candidate(u'\\n\\n\\n\\n\\n\\n\\nhello') == u'hello'
	assert candidate(u"   \xa0\xa0\xa0\xa0") == u""
	assert candidate(u'hello\\xa0') == u'hello'
	assert candidate(u"foo") == u"foo"
	assert candidate(u"\\xa0\\xa0") == u""
	assert candidate(u'\\n\\n\\n') == u''
	assert candidate(u'\\n\\nhello') == u'hello'
	assert candidate(u'\\n\\nhello\\n\\n') == u'hello'
	assert candidate(u'\\xa0\\n\\nHello\\xa0\\n\\n') == u'Hello'
	assert candidate(u'\\xa0\\n\\n\\n\\n') == u''
	assert candidate(u'foo') == u'foo'
	assert candidate(u'\\xa0hello\\xa0') == u'hello'
	assert candidate(u"\\xa0 \\xa0 \\xa0 \\xa0 \\xa0") == u""
	assert candidate(" test ") == "test"
	assert candidate(u'\\xa0\\n\\nHello\\xa0\\xa0\\n\\n') == u'Hello'
	assert candidate(u"\\xa0") == u""
	assert candidate(u"\\n\\n\\n") == u""
	assert candidate(u'\\n\\n\\n\\n\\n\\n\\n\\nhello') == u'hello'
	assert candidate(u'\\n\\n') == u''
	assert candidate("foo") == "foo"
	assert candidate(u"\\xa0 \\xa0 \\xa0 ") == u""
	assert candidate(u'\\n\\n\\n\\xa0\\n\\n\\n') == u''
	assert candidate(u'\\xa0') == u''
	assert candidate("hello \\n") == "hello"
	assert candidate(u'\\xa0 \\xa0 \\xa0 \\n \\xa0') == u''
	assert candidate(u'hello\\n\\n') == u'hello'
	assert candidate(u'\\n\\n\\n\\xa0') == u''
	assert candidate("  foo  ") == "foo"
	assert candidate(u'\\xa0\\xa0Hello\\xa0\\xa0') == u'Hello'
	assert candidate(u'\\xa0 \\xa0 \\xa0 \\n \\xa0 \\n \\xa0 \\n \\xa0 \\n') == u''
	assert candidate(u'\\n\\n\\n\\xa0\\n') == u''
	assert candidate(u"\\xa0  ") == u""
	assert candidate(u'foo\\n') == u'foo'
	assert candidate(u'\\xa0 \\xa0 \\xa0 \\n \\xa0 \\n \\xa0 \\n \\xa0') == u''
	assert candidate(u'\\xa0 \\xa0 \\xa0 \\n \\xa0 \\n \\xa0') == u''
	assert candidate(u"\\xa0 \\xa0 \\xa0") == u""
	assert candidate(u"  \\xa0") == u""
	assert candidate(u'hello\\n\\n\\n\\n') == u'hello'
	assert candidate(u"\\xa0 \\xa0 \\xa0 \\xa0 ") == u""
	assert candidate(u'\\n\\n\\n\\n\\n\\n\\n\\n\\nhello') == u'hello'
	assert candidate(" foo ") == "foo"
	assert candidate(u'\\xa0\\xa0\\xa0') == u''
	assert candidate(u"\\xa0\\xa0\\xa0\\xa0") == u""
	assert candidate(u"\\nfoo") == u"foo"
	assert candidate(u'\\xa0\\xa0\\n\\n') == u''
	assert candidate(u'\\n\\n\\n\\nhello') == u'hello'
	assert candidate(u"\\n\\n") == u""
	assert candidate(u'\\n\\n\\xa0\\n') == u''
	assert candidate(u"\\xa0 \\xa0 ") == u""
	assert candidate(u'\\n\\n\\n\\xa0\\n\\n') == u''
	assert candidate(u'\\xa0 \\xa0 \\xa0 \\n \\xa0 \\n \\xa0 \\n') == u''
	assert candidate(u"\\xa0 \\xa0 \\xa0 \\xa0 \\xa0 ") == u""
	assert candidate(u"foo\\n") == u"foo"
	assert candidate(u'\\n\\n\\n\\n\\xa0\\n') == u''
	assert candidate("   ") == ""
	assert candidate(u'\\n\\n\\xa0\\n\\n\\n') == u''
	assert candidate(u"\\n\\xa0") == u""
	assert candidate(u'\\xa0 \\xa0 \\xa0 \\n \\xa0 \\n \\xa0 \\n \\xa0 \\n \\xa0') == u''
	assert candidate(u"\\xa0 \\xa0 \\xa0 \\xa0 \\xa0 \\xa0 ") == u""
	assert candidate(u" \t\t\t\xa0\xa0\xa0foo\xa0\xa0\xa0 \t\t\t\n") == u"foo"
	assert candidate(u'\\n\\n\\xa0') == u''
	assert candidate(u"\\xa0\\xa0\\n") == u""
	assert candidate(u'\\n\\n\\n\\n') == u''
	assert candidate(u"\\xa0foo") == u"foo"
	assert candidate(u'\\xa0\\n\\xa0') == u''
	assert candidate(u'\\n\\nHello\\n\\n') == u'Hello'
	assert candidate(u'\\n\\n\\n\\n\\xa0') == u''
	assert candidate(u'\\n\\nHello\\xa0\\xa0\\n\\n') == u'Hello'
	assert candidate(u'\\xa0Hello\\xa0') == u'Hello'
	assert candidate(u'hello\\xa0world') == u'hello world'
	assert candidate("hello") == "hello"
	assert candidate(u"\\xa0a\\xa0b\\xa0c\\xa0") == u"a b c"
	assert candidate(u"\\xa0\\xa0\\xa0") == u""
	assert candidate(u'\\xa0\\xa0') == u''
	assert candidate(u'\\xa0\\n\\n\\n') == u''
	assert candidate('  hello  ') == 'hello'
	assert candidate(u'\\xa0 \\n') == u''
	assert candidate(u'\\xa0\\n\\nHello\\n\\n') == u'Hello'
	assert candidate(u'\\xa0\\n\\xa0\\n') == u''
	assert candidate(u'\\xa0Hello\\n\\n') == u'Hello'
	assert candidate(u"\\n") == u""
	assert candidate(u'\\xa0\\xa0Hello\\n\\n') == u'Hello'
	assert candidate(u'\\n\\xa0') == u''
	assert candidate(u'\\nhello\\n') == u'hello'
	assert candidate(u"\\xa0\\n") == u""
def test_check():
	check(clean)
