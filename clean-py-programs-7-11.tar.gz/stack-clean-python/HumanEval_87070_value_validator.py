def value_validator(variables, values):
    """
    1. Checks if "values" is of type <dict>
    2. Checks if all variables are present in the values <dict>
    :param variables: <list>
    :param values: <dict>
    :raise: InvalidTemplateValues, IncompleteTemplateValues
    :return None
    """
    ### Canonical solution below ###
    return None
    # if type(values) is not dict:
    #     raise InvalidTemplateValues(values)
    # elif set(variables) != set(dict.keys(values)):
    #     raise IncompleteTemplateValues([v for v in variables if v not in values])


### Unit tests below ###
def check(candidate):
	assert candidate(variables=["a", "b"], values={"a": 1, "b": 2}) is None
	assert candidate(variables=['x', 'y'], values={'x': 1, 'y': 2}) is None
	assert candidate(variables=['x', 'y'], values=1) is None
	assert candidate(
    variables=['a', 'b'],
    values={'a': 'a', 'b': 'b', 'c': 'c'}
) is None
	assert candidate(['name'], {}) is None
	assert candidate(variables=['x', 'y'], values={'y': 2}) is None
	assert candidate(variables=['x', 'y'], values={'z': 3}) is None
	assert candidate(
    variables=['a', 'b'],
    values={'a': 'a'}
) is None
	assert candidate(variables=['x', 'y'], values={'x': 1, 'z': 3}) is None
	assert candidate(variables=['x', 'y'], values={'x': 1}) is None
	assert candidate(
    variables=['a', 'b'],
    values={'a': 'a', 'b': 'b'}
) is None
	assert candidate(variables=['a', 'b', 'c'], values={'a': 1}) == None
	assert candidate(['name'], {'name': 'Jane'}) is None
	assert candidate(variables=['x', 'y'], values={'x': 1, 'y': 2, 'z': 3}) is None
	assert candidate(variables=['a', 'b'], values={'a': 1, 'b': 2}) is None
	assert candidate(['a', 'b', 'c'], {'a': 1}) is None
	assert candidate(variables=['a', 'b', 'c'], values={'a': 1, 'b': 2}) == None
	assert candidate(
    ['a', 'b', 'c'],
    {'a': 1, 'b': 2, 'c': 3}
) is None
	assert candidate(variables=['a', 'b', 'c'], values={'a': 1, 'b': 2, 'c': 3}) == None
	assert candidate(
    ['a', 'b', 'c'],
    {'a': 1, 'b': 2}
) is None
def test_check():
	check(value_validator)
