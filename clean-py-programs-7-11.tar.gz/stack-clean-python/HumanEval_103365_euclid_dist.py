def euclid_dist(a, b):
    """ Return euclidean distance between a and b"""
	### Canonical solution below ###    
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2) ** 0.5

### Unit tests below ###
def check(candidate):
	assert candidate( (0, 0, 0), (0, 0, 0) ) == 0
	assert candidate(
    (0, 0, 0),
    (0, 0, 0)
) == 0
	assert candidate(
    (1, 1, 1),
    (2, 2, 2)
) == 3 ** 0.5
	assert candidate( (0, 0, 0), (0, 1, 0) ) == 1
	assert candidate( (0, 0, 0), (1, 0, 0) ) == 1
	assert candidate([0, 0, 0], [0, 0, 0]) == 0, "Euclidean distance not calculated correctly"
	assert candidate(
    (0, 0, 0),
    (3, 4, 0)
) == 5
	assert candidate( (3,4,0), (0,0,0) ) == 5
	assert candidate( (0,0,0), (3,4,0) ) == 5
	assert candidate( (1,2,3), (4,5,6) ) == 5.196152422706632
	assert candidate( (1,2,3), (1,2,3) ) == 0
	assert candidate( (0, 0, 0), (0, 0, 1) ) == 1
	assert candidate( (0,0,0), (0,0,0) ) == 0
def test_check():
	check(euclid_dist)
