def format_ruckus_value(value, force_str=False):
    """Format a string value into None, int, or bool if possible."""
    ### Canonical solution below ###
    value = value.strip()

    if not value:
        return None

    if not force_str:
        if value.isnumeric():
            return int(value)

        if value in ["true", "Enabled", "Yes"]:
            return True
        if value in ["false", "Disabled", "No"]:
            return False

    return value


### Unit tests below ###
def check(candidate):
	assert candidate("Disabled") is False
	assert candidate("true", True) == "true"
	assert candidate("100") == 100
	assert candidate("   ") is None
	assert candidate(" Disabled ") is False
	assert candidate("1 ") == 1
	assert candidate("Disabled") == False
	assert candidate("000") == 0
	assert candidate("Yes", force_str=True) == "Yes"
	assert candidate("") is None
	assert candidate("hello 123") == "hello 123"
	assert candidate("Yes") == True
	assert candidate("No") is False
	assert candidate("Yes ") is True
	assert candidate("true") == True
	assert candidate("1.1") == "1.1"
	assert candidate("true") is True
	assert candidate(" Disabled") is False
	assert candidate("false", force_str=True) == "false"
	assert candidate("foo", force_str=True) == "foo"
	assert candidate("No", force_str=True) == "No"
	assert candidate("1234", True) == "1234"
	assert candidate("  ") is None
	assert candidate("123") == 123
	assert candidate("10.1") == "10.1"
	assert candidate("test") == "test"
	assert candidate("1234") == 1234
	assert candidate("hello123") == "hello123"
	assert candidate("true ") is True
	assert candidate("False", force_str=True) == "False"
	assert candidate("1", force_str=True) == "1"
	assert candidate("1234.5") == "1234.5"
	assert candidate(" Enabled ") is True
	assert candidate("12") == 12
	assert candidate(" true") is True
	assert candidate("hello") == "hello"
	assert candidate("") == None
	assert candidate(" 2 ") == 2
	assert candidate("Hello World") == "Hello World"
	assert candidate("false") is False
	assert candidate("true", force_str=True) == "true"
	assert candidate("hello-123") == "hello-123"
	assert candidate(" false ") is False
	assert candidate("false", True) == "false"
	assert candidate("2") == 2
	assert candidate("Enabled") == True
	assert candidate("Enabled", force_str=True) == "Enabled"
	assert candidate("1234.567") == "1234.567"
	assert candidate("Disabled ") is False
	assert candidate("Test") == "Test"
	assert candidate("001") == 1
	assert candidate("Hello") == "Hello"
	assert candidate("True", force_str=True) == "True"
	assert candidate("42.5") == "42.5"
	assert candidate(" ") is None
	assert candidate("True ", force_str=True) == "True"
	assert candidate("Hello World", force_str=True) == "Hello World"
	assert candidate(" 1 ") == 1
	assert candidate(" false") is False
	assert candidate("0000") == 0
	assert candidate("1.1.1 ") == "1.1.1"
	assert candidate("0001") == 1
	assert candidate("foo") == "foo"
	assert candidate("false") == False
	assert candidate("1000") == 1000
	assert candidate("12345") == 12345
	assert candidate("1.1.1") == "1.1.1"
	assert candidate("Disabled", force_str=True) == "Disabled"
	assert candidate("     ") is None
	assert candidate(" Enabled") is True
	assert candidate(" 10 ") == 10
	assert candidate(" true ") is True
	assert candidate("Enabled ") is True
	assert candidate("False ", force_str=True) == "False"
	assert candidate("42") == 42
	assert candidate("false ") is False
	assert candidate("Yes") is True
	assert candidate("10") == 10
	assert candidate("123 hello") == "123 hello"
	assert candidate("Enabled") is True
	assert candidate("0") == 0
	assert candidate("1") == 1
	assert candidate(" 0 ") == 0
	assert candidate("1.1", force_str=True) == "1.1"
	assert candidate("No") == False
	assert candidate("123 ") == 123
	assert candidate("10.0") == "10.0"
	assert candidate("123", force_str=True) == "123"
def test_check():
	check(format_ruckus_value)
