def target_video_frame_image_to_bytes(document_asl_consultant_target_video_index_schemad_pcoll_row_tpl):
  """
  document_asl_consultant_target_video_index_schemad_pcoll_row_tpl:
    ((<corpus doc id>, <asl consultant id>, <camera perspective>), (<target video filename>, <target video frame seq id>, <target video frame path>))
  """
    ### Canonical solution below ###
  corpus_doc_id = document_asl_consultant_target_video_index_schemad_pcoll_row_tpl[0][0]
  asl_consultant_id = document_asl_consultant_target_video_index_schemad_pcoll_row_tpl[0][1]
  camera_perspective = document_asl_consultant_target_video_index_schemad_pcoll_row_tpl[0][2]
  target_video_fname = document_asl_consultant_target_video_index_schemad_pcoll_row_tpl[1][0]
  frame_seq_id = document_asl_consultant_target_video_index_schemad_pcoll_row_tpl[1][1]
  frame_path = document_asl_consultant_target_video_index_schemad_pcoll_row_tpl[1][2]

  # # frame_tensor = img_to_array(load_img(frame_path, target_size=fidscs_globals.FRAME_IMG_INPUT_SHAPE))
  # img = load_img(frame_path, target_size=fidscs_globals.FRAME_IMG_INPUT_SHAPE)
  # bytesio = io.BytesIO()
  # img.save(bytesio, format='JPEG')
  # jpeg_bytes = bytesio.getvalue()

  # # now delete corresponding image file
  # fileio.delete_file(frame_path)
  # if fidscs_globals.OUTPUT_INFO_LEVEL <= fidscs_globals.OUTPUT_INFO_LEVEL__DEBUG:
  #   print(f"PROCESSED/DELETED target video frame: {frame_path}")

  return (
    (
      corpus_doc_id,
      asl_consultant_id,
      camera_perspective
    ),
    (
      target_video_fname,
      frame_seq_id,
      frame_path
      # , jpeg_bytes
    )
  )


### Unit tests below ###
def check(candidate):
	assert candidate(
  (
    (
      '2014-01-21-01-00-00-000000',
      '000',
      '0'
    ),
    (
      '2014-01-21-01-00-00-000000.mp4',
      0,
      '/tmp/2014-01-21-01-00-00-000000.mp4'
    )
  )
) == (
  (
    '2014-01-21-01-00-00-000000',
    '000',
    '0'
  ),
  (
    '2014-01-21-01-00-00-000000.mp4',
    0,
    '/tmp/2014-01-21-01-00-00-000000.mp4'
    #, b'SOME JPEG BYTES'
  )
)
	assert candidate(
  (
    ('d1', 'a1', 'c1'),
    ('t1', 2, '/tmp/d1/a1/c1/t1/2.jpg')
  )
) == (
  (
    'd1',
    'a1',
    'c1'
  ),
  (
    't1',
    2,
    '/tmp/d1/a1/c1/t1/2.jpg'
    #, b'12345'
  )
)
	assert candidate(
  (
    (1, 1, 1),
    ("1.avi", 1, "/path/to/1.avi/1.jpg")
  )
) == (
  (1, 1, 1),
  ("1.avi", 1, "/path/to/1.avi/1.jpg")
)
	assert candidate(
  (
    ('d1', 'a1', 'c1'),
    ('t1', 1, '/tmp/d1/a1/c1/t1/1.jpg')
  )
) == (
  (
    'd1',
    'a1',
    'c1'
  ),
  (
    't1',
    1,
    '/tmp/d1/a1/c1/t1/1.jpg'
    #, b'12345'
  )
)
	assert candidate(
  (
    (
      '1-1-1',
      '1',
      '1'
    ),
    (
      '1-1-1-1.mp4',
      1,
      '/path/to/1-1-1-1.mp4/1.jpg'
    )
  )
) == (
  (
    '1-1-1',
    '1',
    '1'
  ),
  (
    '1-1-1-1.mp4',
    1,
    '/path/to/1-1-1-1.mp4/1.jpg'
  )
)
	assert candidate(
  document_asl_consultant_target_video_index_schemad_pcoll_row_tpl=(
    (
      "1234567890",
      "Fred",
      "Left"
    ),
    (
      "video_1.mp4",
      1,
      "/path/to/video_1.mp4/frame_00001.jpg"
    )
  )
) == (
  (
    "1234567890",
    "Fred",
    "Left"
  ),
  (
    "video_1.mp4",
    1,
    "/path/to/video_1.mp4/frame_00001.jpg"
  )
)
	assert candidate(
  document_asl_consultant_target_video_index_schemad_pcoll_row_tpl=
    (
      (
        '1234567890',
        '1234567890',
        '0'
      ),
      (
        'video_1.mp4',
        0,
        '/path/to/1234567890/video_1/frame_000000.jpg'
      )
    )
) == (
    (
      '1234567890',
      '1234567890',
      '0'
    ),
    (
      'video_1.mp4',
      0,
      '/path/to/1234567890/video_1/frame_000000.jpg'
    )
  )
	assert candidate(
  (
    (
      '00001234',
      '1',
      'L'
    ),
    (
      '00001234.mp4',
      0,
      '/tmp/00001234.mp4/00001234_00000000.jpg'
    )
  )
) == (
  (
    '00001234',
    '1',
    'L'
  ),
  (
    '00001234.mp4',
    0,
    '/tmp/00001234.mp4/00001234_00000000.jpg'
    #, <jpeg_bytes>
  )
)
	assert candidate(
  document_asl_consultant_target_video_index_schemad_pcoll_row_tpl = (
    (
      '000000000',
      '000000000',
      '0'
    ),
    (
      '000000000_000000000_0.mp4',
      1,
      '/path/to/000000000_000000000_0.mp4/frame_000000.jpg'
    )
  )
) == (
  (
    '000000000',
    '000000000',
    '0'
  ),
  (
    '000000000_000000000_0.mp4',
    1,
    '/path/to/000000000_000000000_0.mp4/frame_000000.jpg'
    #, jpeg_bytes
  )
)
	assert candidate(
  (
    (
      '123',
      '456',
      '789'
    ),
    (
      'video123.mp4',
      0,
      '/tmp/video123_frame_000000.png'
    )
  )
) == (
  (
    '123',
    '456',
    '789'
  ),
  (
    'video123.mp4',
    0,
    '/tmp/video123_frame_000000.png'
  )
)
	assert candidate(
  (
    (
      '2121',
      '4',
      '1'
    ),
    (
      '2121_4_1_11111111111111111_00001_00001.mp4',
      1,
      '/tmp/2121_4_1_11111111111111111_00001_00001.jpg'
    )
  )
) == (
  (
    '2121',
    '4',
    '1'
  ),
  (
    '2121_4_1_11111111111111111_00001_00001.mp4',
    1,
    '/tmp/2121_4_1_11111111111111111_00001_00001.jpg'
  )
)
	assert candidate(
  (
    (1, 1, 1),
    ("video1.mp4", 1, "/tmp/video1.mp4/frame1.jpg")
  )
) == (
  (1, 1, 1),
  ("video1.mp4", 1, "/tmp/video1.mp4/frame1.jpg")
)
	assert candidate(
  (
    ('5a087668-781d-4225-9120-35725d5397f8', '5e5092e4-0a58-4408-a6b4-377504990e61', 'front'),
    ('video_0001_0000000001.mp4', 1, '/path/to/frame_0000000001.jpg')
  )
) == (
  (
    '5a087668-781d-4225-9120-35725d5397f8',
    '5e5092e4-0a58-4408-a6b4-377504990e61',
    'front'
  ),
  (
    'video_0001_0000000001.mp4',
    1,
    '/path/to/frame_0000000001.jpg'
  )
)
	assert candidate(
  (
    (1, 2, 3),
    (
      'target_video_fname',
      1,
      '/path/to/target_video_frame_image'
    )
  )
) == (
  (
    1,
    2,
    3
  ),
  (
    'target_video_fname',
    1,
    '/path/to/target_video_frame_image'
  )
), "candidate failed"
	assert candidate(
  (
    (
      '254629', '10327', '1'
    ),
    (
      '254629_1_1_367.png', 367, '/home/jovyan/work/data/asl_consultant_target_videos/10327/1/254629_1_1_367.png'
    )
  )
) == (
  (
    '254629', '10327', '1'
  ),
  (
    '254629_1_1_367.png', 367, '/home/jovyan/work/data/asl_consultant_target_videos/10327/1/254629_1_1_367.png'
  )
)
	assert candidate(
  (
    (1, 1, 0),
    ('a.mp4', 1, '/tmp/a.mp4/a-1.jpg')
  )
) == (
  (1, 1, 0),
  ('a.mp4', 1, '/tmp/a.mp4/a-1.jpg')
)
	assert candidate(
  (
    (
      '0000001',
      '001',
      '001'
    ),
    (
      'ASL_VIDEO_0000001_001_001.mp4',
      0,
      '/app/data/0000001/ASL_VIDEO_0000001_001_001.mp4/0000000.jpg'
    )
  )
) == (
  (
    '0000001',
    '001',
    '001'
  ),
  (
    'ASL_VIDEO_0000001_001_001.mp4',
    0,
    '/app/data/0000001/ASL_VIDEO_0000001_001_001.mp4/0000000.jpg'
  )
)
	assert candidate(
  (
    (
      '001', 'A1', 'R'
    ),
    (
      'video_01.mp4', 0, '/tmp/video_01_frame_000000.jpg'
    )
  )
) == (
  (
    '001',
    'A1',
    'R'
  ),
  (
    'video_01.mp4',
    0,
    '/tmp/video_01_frame_000000.jpg'
    #, b'jpeg_bytes'
  )
)
	assert candidate(
  (
    (
      'corpus-doc-id-1',
      'asl-consultant-id-1',
      'camera-perspective-1'
    ),
    (
      'target-video-fname-1',
      1,
      '/path/to/target-video-1'
    )
  )
) == (
  (
    'corpus-doc-id-1',
    'asl-consultant-id-1',
    'camera-perspective-1'
  ),
  (
    'target-video-fname-1',
    1,
    '/path/to/target-video-1'
  )
)
	assert candidate(
  (
    ('d1', 'a1', 'c1'),
    ('t1', 3, '/tmp/d1/a1/c1/t1/3.jpg')
  )
) == (
  (
    'd1',
    'a1',
    'c1'
  ),
  (
    't1',
    3,
    '/tmp/d1/a1/c1/t1/3.jpg'
    #, b'12345'
  )
)
def test_check():
	check(target_video_frame_image_to_bytes)
