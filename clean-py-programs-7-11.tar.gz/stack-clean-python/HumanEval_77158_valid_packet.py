def valid_packet(packet, constraint):
    """ 
     Check if a hex encoded packet received from
     rflib.Rfcat.RFrecv has the constraint value in it.
     
     Idea From:
     https://github.com/mossmann/stealthlock/blob/master/sl.pyL17
     
     :param packet:
     :param constraint:
     :return:
     """
	### Canonical solution below ###    

    if constraint not in packet:
        return False

    return True

### Unit tests below ###
def check(candidate):
	assert not candidate(b'30313233343536373839414243444546', b'0123456789ABCDEF0')
	assert not candidate(b'11111111', b'11110110')
	assert not candidate(b'0123456789', b'9876543210')
	assert not candidate(b'11111111', b'11110011')
	assert candidate(b'4500002400010000000000004006261642d6c6f63616c0000010001', b'd-local0') is False
	assert not candidate(b'0123456789', b'01234567891')
	assert not candidate(b'1234', b'4321')
	assert not candidate(b'30313233343536373839414243444546', b'0123456789ABCDEFG')
	assert candidate(b'11111111', b'1111111')
	assert not candidate(b'11111111', b'11111101')
	assert not candidate(b'11111111', b'11110111')
	assert not candidate(b'0123456789abcdef', b'0123456789abcdf')
	assert candidate(b'0123456789', b'0123456789')
	assert not candidate(b'11111111', b'11111100')
	assert candidate(b'1234567890', b'1234567890') is True
	assert candidate(b'1234', b'34')
	assert not candidate(b'1234', b'12345')
	assert not candidate(b'11111111', b'11111010')
	assert not candidate(b'1234567890', b'1234567891')
	assert candidate(b'Hello World', b'Hello')
	assert candidate(b'1234567890', b'12345678')
	assert not candidate(b'11111111', b'11111000')
	assert not candidate(b'11111111', b'11110101')
	assert not candidate(b'0123456789', b'01234567890')
	assert not candidate(b'11111111', b'11111001')
	assert candidate(b'4500002400010000000000004006261642d6c6f63616c0000010001', b'invalid') is False
	assert candidate(b'11111111', b'11111111')
	assert not candidate(b'11111111', b'11111110')
	assert candidate(b'234567', b'234567') is True
	assert candidate(b'4500002400010000000000004006261642d6c6f63616c0000010001', b'invalid0') is False
	assert candidate(b'0123456789abcdef', b'0123456789abcdef')
	assert not candidate(b'30313233343536373839414243444546', b'0123456789ABCDEF01')
	assert not candidate(b'Hello World', b'Goodbye')
	assert candidate(b'1234567890', b'1234567890')
	assert not candidate(b'30313233343536373839414243444546', b'0123456789abcdef')
	assert not candidate(b'11111111', b'11111011')
	assert not candidate(b'11111111', b'11110100')
def test_check():
	check(valid_packet)
