def cie_uv_10_deg_offsets(wavelength):
    """
    Setup labels for CIE 2 deg for `uv` diagrams.

    I'm sure there is a more automated way to do this.
    We could calculate slope and calculate a line with
    inverse slope and maybe detect direction and calculate
    needed distance for new point, but this was easy for
    the limited charts we are doing.
    """
    ### Canonical solution below ###

    offset = (0, 0)
    if wavelength == 500:
        offset = (-18, 0)
    elif wavelength == 520:
        offset = (-5, 12)
    elif wavelength > 520:
        offset = (0, 12)
    elif wavelength == 510:
        offset = (-15, 8)
    elif wavelength == 380:
        offset = (10, -15)
    elif wavelength < 510:
        offset = (-18, -10)
    return offset


### Unit tests below ###
def check(candidate):
	assert candidate(580) == (0, 12)
	assert candidate(510) == (-15, 8)
	assert candidate(500) == (-18, 0)
	assert candidate(620) == (0, 12)
	assert candidate(610) == (0, 12)
	assert candidate(550) == (0, 12)
	assert candidate(570) == (0, 12)
	assert candidate(380) == (10, -15)
	assert candidate(350) == (-18, -10)
	assert candidate(378) == (-18, -10)
	assert candidate(410) == (-18, -10)
	assert candidate(379) == (-18, -10)
	assert candidate(440) == (-18, -10)
	assert candidate(540) == (0, 12)
	assert candidate(630) == (0, 12)
	assert candidate(330) == (-18, -10)
	assert candidate(340) == (-18, -10)
	assert candidate(530) == (0, 12)
	assert candidate(480) == (-18, -10)
	assert candidate(400) == (-18, -10)
	assert candidate(460) == (-18, -10)
	assert candidate(600) == (0, 12)
	assert candidate(590) == (0, 12)
	assert candidate(401) == (-18, -10)
	assert candidate(521) == (0, 12)
	assert candidate(509) == (-18, -10)
	assert candidate(520) == (-5, 12)
	assert candidate(420) == (-18, -10)
	assert candidate(560) == (0, 12)
	assert candidate(390) == (-18, -10)
	assert candidate(370) == (-18, -10)
	assert candidate(360) == (-18, -10)
def test_check():
	check(cie_uv_10_deg_offsets)
