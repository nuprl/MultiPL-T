def alterarPosicao(changePosition, change):
    """ This looks complicated but I'm doing this:
     Current_pos == (x, y)
     change == (a, b)
     new_position == ((x + a), (y + b))
     """
	### Canonical solution below ###    
    return (changePosition[0] + change[0]), (changePosition[1] + change[1])

### Unit tests below ###
def check(candidate):
	assert candidate( (0, 0), (-2, 2) ) == (-2, 2)
	assert candidate( (1, 2), (0, 1) ) == (1, 3), "Coordenadas alteradas erradas"
	assert candidate(changePosition=(0, 0), change=(0, 0)) == (0, 0)
	assert candidate( (0, 0), (-1, -1) ) == (-1, -1)
	assert candidate(changePosition=(1, 1), change=(0, 1)) == (1, 2)
	assert candidate(changePosition=(1, 0), change=(1, 0)) == (2, 0)
	assert candidate( (1,1), (0,-1) ) == (1,0)
	assert candidate( (1, 1), (1, -1) ) == (2, 0)
	assert candidate( (-1, 1), (1, 1) ) == (0, 2)
	assert candidate( (1, 1), (1, 2) ) == (2, 3)
	assert candidate( (-2, -3), (0, 0) ) == (-2, -3)
	assert candidate( (1, 2), (0, 0) ) == (1, 2), "Coordenadas alteradas erradas"
	assert candidate( (1, 2), (-1, 0) ) == (0, 2), "Coordenadas alteradas erradas"
	assert candidate(changePosition=(0, 0), change=(1, 0)) == (1, 0)
	assert candidate( (0, 0), (2, -2) ) == (2, -2)
	assert candidate( (1, 1), (0, -1) ) == (1, 0)
	assert candidate( (10, 10), (5, 5) ) == (15, 15)
	assert candidate(
    (1, 1),
    (0, -1)
) == (1, 0)
	assert candidate( (1,1), (-1,-1) ) == (0,0)
	assert candidate( (1, -1), (1, 1) ) == (2, 0)
	assert candidate( (0,0), (1,0) ) == (1,0)
	assert candidate( (10, 10), (-5, 5) ) == (5, 15)
	assert candidate(
    (0, 0), (-1, -1)
) == (-1, -1), "Posicao alterada corretamente"
	assert candidate(
    (1, 2), (1, 1)
) == (2, 3), "Posicao alterada corretamente"
	assert candidate( (10, 10), (-5, -5) ) == (5, 5)
	assert candidate( (1, 1), (0, 1) ) == (1, 2)
	assert candidate( (0, 0), (1, 0) ) == (1, 0), "Mudou de lugar"
	assert candidate( (1,1), (-1,0) ) == (0,1)
	assert candidate(changePosition=(1, 0), change=(0, 0)) == (1, 0)
	assert candidate( (1,1), (0,1) ) == (1,2)
	assert candidate( (1, 2), (3, 4) ) == (4, 6), "Coordenadas alteradas erradas"
	assert candidate( (10, 10), (5, -5) ) == (15, 5)
	assert candidate( (0, 0), (-1, 1) ) == (-1, 1), "Mudou de lugar"
	assert candidate(
    (1, 1),
    (1, 0)
) == (2, 1)
	assert candidate( (0, 0), (-1, -1) ) == (-1, -1), "Mudou de lugar"
	assert candidate( (1, 1), (-1, 1) ) == (0, 2)
	assert candidate( (1,1), (-1,1) ) == (0,2)
	assert candidate( (1, 2), (0, -1) ) == (1, 1), "Coordenadas alteradas erradas"
	assert candidate(
    (1, 1),
    (1, 1)
) == (2, 2)
	assert candidate(changePosition=(0, 0), change=(1, 1)) == (1, 1)
	assert candidate( (0, 0), (2, 2) ) == (2, 2)
	assert candidate( (10, 10), (0, 0) ) == (10, 10)
	assert candidate(
    (0, 0),
    (1, 1)
) == (1, 1)
	assert candidate( (0, 0), (0, -1) ) == (0, -1)
	assert candidate( (2, 3), (0, 0) ) == (2, 3)
	assert candidate( (0, 0), (-2, -2) ) == (-2, -2)
	assert candidate(changePosition=(0, 1), change=(1, 1)) == (1, 2)
	assert candidate( (1,1), (1,-1) ) == (2,0)
	assert candidate( (0, 0), (0, 0) ) == (0, 0), "Coordenadas alteradas erradas"
	assert candidate( (0,0), (0,1) ) == (0,1)
	assert candidate( (0, 0), (10, 10) ) == (10, 10)
	assert candidate( (1,1), (1,0) ) == (2,1)
	assert candidate( (0, 0), (1, 1) ) == (1, 1)
	assert candidate( (0, 0), (-1, 0) ) == (-1, 0)
	assert candidate( (1, 2), (1, 1) ) == (2, 3), "Coordenadas alteradas erradas"
	assert candidate(
    (1, 1),
    (-1, 0)
) == (0, 1)
	assert candidate( (1, 1), (-1, 0) ) == (0, 1)
	assert candidate( (0, 0), (2, 3) ) == (2, 3)
	assert candidate( (0, 0), (0, 0) ) == (0, 0)
	assert candidate( (1, 1), (1, 1) ) == (2, 2), "Mudou de lugar"
	assert candidate( (0, 0), (1, 1) ) == (1, 1), "Coordenadas alteradas erradas"
	assert candidate( (1,1), (-2,2) ) == (-1,3)
	assert candidate(
    (0, 0), (1, 1)
) == (1, 1), "Posicao alterada corretamente"
	assert candidate( (1, -1), (1, -1) ) == (2, -2)
	assert candidate( (-1, -2), (-3, -4) ) == (-4, -6)
	assert candidate(
    (0, 0),
    (-1, -1)
) == (-1, -1)
	assert candidate( (1,1), (0,0) ) == (1,1)
	assert candidate(changePosition=(0, 1), change=(1, 0)) == (1, 1)
	assert candidate( (10, 10), (-1, -1) ) == (9, 9)
	assert candidate( (1, 2), (1, 0) ) == (2, 2), "Coordenadas alteradas erradas"
	assert candidate(changePosition=(1, 0), change=(0, 1)) == (1, 1)
	assert candidate( (1, 2), (2, 3) ) == (3, 5)
	assert candidate( (0, 0), (-1, 1) ) == (-1, 1)
	assert candidate( (1,1), (0,-2) ) == (1,-1)
	assert candidate( (1, 2), (3, 4) ) == (4, 6)
	assert candidate( (2, 2), (1, 1) ) == (3, 3)
	assert candidate( (0, 0), (-2, -3) ) == (-2, -3)
	assert candidate(changePosition=(0, 1), change=(0, 1)) == (0, 2)
	assert candidate( (1,1), (2,-2) ) == (3,-1)
	assert candidate( (0, 0), (3, 4) ) == (3, 4)
	assert candidate( (1, 2), (-1, -2) ) == (0, 0), "Coordenadas alteradas erradas"
	assert candidate( (-1, 1), (-1, 1) ) == (-2, 2)
	assert candidate(
    (0, 0),
    (1, 0)
) == (1, 0)
	assert candidate( (1,1), (1,1) ) == (2,2)
	assert candidate( (1, -1), (-1, 1) ) == (0, 0)
	assert candidate( (1, 1), (1, 1) ) == (2, 2)
	assert candidate( (0, 0), (1, -1) ) == (1, -1)
	assert candidate( (1, 1), (-1, -1) ) == (0, 0)
	assert candidate(changePosition=(1, 1), change=(0, 0)) == (1, 1)
	assert candidate(
    (1, 1),
    (-1, -1)
) == (0, 0)
	assert candidate( (-1, -1), (-1, -1) ) == (-2, -2)
	assert candidate( (0, 0), (0, -1) ) == (0, -1), "Mudou de lugar"
	assert candidate(
    (1, 1),
    (0, 1)
) == (1, 2)
	assert candidate( (1, 2), (1, -1) ) == (2, 1)
	assert candidate( (10, 10), (1, 1) ) == (11, 11)
	assert candidate( (1, 2), (-1, -1) ) == (0, 1), "Coordenadas alteradas erradas"
	assert candidate( (0, 0), (1, 1) ) == (1, 1), "Mudou de lugar"
	assert candidate(changePosition=(0, 0), change=(0, 1)) == (0, 1)
	assert candidate( (0,0), (1,1) ) == (1,1)
	assert candidate(changePosition=(1, 0), change=(1, 1)) == (2, 1)
	assert candidate( (0, 0), (1, 0) ) == (1, 0)
	assert candidate( (1, 1), (-10, -10) ) == (-9, -9)
	assert candidate(changePosition=(0, 1), change=(0, 0)) == (0, 1)
	assert candidate( (1,1), (-2,0) ) == (-1,1)
	assert candidate( (1, 2), (-1, 1) ) == (0, 3)
	assert candidate( (1, 1), (0, 0) ) == (1, 1)
	assert candidate( (-1, 1), (1, -1) ) == (0, 0)
	assert candidate(
    (-1, -1),
    (-1, -1)
) == (-2, -2)
	assert candidate( (0, 0), (0, 1) ) == (0, 1)
	assert candidate( (-1, 1), (-1, -1) ) == (-2, 0)
	assert candidate( (1, 1), (1, 0) ) == (2, 1)
def test_check():
	check(alterarPosicao)
