def path2gt_datasets(path, dataset):
    """ Given the audio path, it returns the ground truth label.
     Define HERE a new dataset to employ this code with other data.
     """
	### Canonical solution below ###    
    if dataset == 'GTZAN':
        if 'blues' in path:
            return 0
        elif 'classical' in path:
            return 1
        elif 'country' in path:
            return 2
        elif 'disco' in path:
            return 3
        elif 'hiphop' in path:
            return 4
        elif 'jazz' in path:
            return 5
        elif 'metal' in path:
            return 6
        elif 'pop' in path:
            return 7
        elif 'reggae' in path:
            return 8
        elif 'rock' in path:
            return 9
        else:
            print('Did not find the corresponding ground truth (' + str(path) + ')!')

    else:
            print('Did not find the implementation of ' + str(dataset) + ' dataset!')

### Unit tests below ###
def check(candidate):
	assert candidate(path='./data/genres/disco/disco.00000.au', dataset='GTZAN') == 3
	assert candidate(path='/home/carol/Music/genres/blues/blues.00001.wav', dataset='GTZAN') == 0
	assert candidate(path='rock/rock.00000', dataset='GTZAN') == 9
	assert candidate(path='./genres_original/hiphop/hiphop.00000.wav', dataset='GTZAN') == 4, "ERROR: GTZAN hiphop.00000.wav should return 4"
	assert candidate(path='./genres_original/blues/blues.00000.wav', dataset='GTZAN') == 0, "ERROR: GTZAN blues.00000.wav should return 0"
	assert candidate(path='genres_original/metal/00004.wav', dataset='GTZAN') == 6
	assert candidate(path = 'GTZAN/genres_original/pop/pop.00000.wav',
                        dataset = 'GTZAN') == 7
	assert candidate(path = 'data/genres_original/metal/00000.au',
                        dataset = 'GTZAN') == 6
	assert candidate(path='/home/user/Downloads/genres_original/hiphop/hiphop.00000.wav', dataset='GTZAN') == 4
	assert candidate(path = 'genres_original/classical/classical.00000.wav', dataset = 'GTZAN') == 1
	assert candidate(path = 'genres_original/blues/blues.00000.wav', dataset = 'GTZAN') == 0
	assert candidate(path='/home/felix/Downloads/genres_original/metal/metal.00026.wav',
                        dataset='GTZAN') == 6
	assert candidate(path='/home/user/data/GTZAN/genres/blues/blues.00000.wav',
                        dataset='GTZAN') == 0
	assert candidate(path='./genres/metal/hiphop/hiphop.00015.wav', dataset='GTZAN') == 4
	assert candidate(path='/home/user/Downloads/genres_original/disco/disco.00000.wav', dataset='GTZAN') == 3
	assert candidate(path = '../audio_example/metal/metal.00000.wav', dataset = 'GTZAN') == 6
	assert candidate(path = '../audio_example/reggae/reggae.00000.wav', dataset = 'GTZAN') == 8
	assert candidate(path = '../audio_example/rock/rock.00000.wav', dataset = 'GTZAN') == 9
	assert candidate(path='./data/genres/hiphop/hiphop.00000.au', dataset='GTZAN') == 4
	assert candidate(path='./genres/metal/jazz/jazz.00015.wav', dataset='GTZAN') == 5
	assert candidate(path='/home/user/data/GTZAN/genres/jazz/jazz.00000.wav',
                        dataset='GTZAN') == 5
	assert candidate(path='../data/genres_original/pop/pop.00000.wav', dataset='GTZAN') == 7
	assert candidate(path='./data/genres/classical/classical.00000.au', dataset='GTZAN') == 1
	assert candidate(path='./data/genres/jazz/jazz.00000.au', dataset='GTZAN') == 5
	assert candidate(path='/home/user/data/GTZAN/genres/country/country.00000.wav',
                        dataset='GTZAN') == 2
	assert candidate(path='./data/genres_original/pop/pop.00000.wav', dataset='GTZAN') == 7
	assert candidate(path='genres_original/metal/hiphop/hiphop.00000.wav', dataset='GTZAN') == 4
	assert candidate(path='./genres_original/jazz/jazz.00000.wav', dataset='GTZAN') == 5, "ERROR: GTZAN jazz.00000.wav should return 5"
	assert candidate(path='genres_original/metal/classical/classical.00000.wav', dataset='GTZAN') == 1
	assert candidate(path='../data/genres_original/rock/rock.00000.wav', dataset='GTZAN') == 9
	assert candidate(path='./genres/metal/country/country.00015.wav', dataset='GTZAN') == 2
	assert candidate(path='audio/genres/hiphop/hiphop.00001.wav', dataset='GTZAN') == 4, "ERROR: Wrong label for hiphop.00001"
	assert candidate(path='genres_original/metal/00003.wav', dataset='GTZAN') == 6
	assert candidate(path='classical/classical.00000', dataset='GTZAN') == 1
	assert candidate(path = 'genres_original/hiphop/hiphop.00000.wav', dataset = 'GTZAN') == 4
	assert candidate(path='/home/user/data/GTZAN/genres/blues/blues.00000.wav', dataset='GTZAN') == 0
	assert candidate(path='/home/user/data/GTZAN/genres/disco/disco.00000.wav',
                        dataset='GTZAN') == 3
	assert candidate(path='/home/carol/Music/genres/hiphop/hiphop.00001.wav', dataset='GTZAN') == 4
	assert candidate(path='audio/genres/disco/disco.00001.wav', dataset='GTZAN') == 3, "ERROR: Wrong label for disco.00001"
	assert candidate(path = 'genres_original/pop/pop.00000.wav', dataset = 'GTZAN') == 7
	assert candidate(path ='metal/metal.00000.wav', dataset = 'GTZAN') == 6
	assert candidate(path='/home/user/data/GTZAN/genres/jazz/jazz.00000.wav', dataset='GTZAN') == 5
	assert candidate(path='genres_original/metal/00000.wav', dataset='GTZAN') == 6
	assert candidate(path='./data/genres_original/disco/disco.00000.wav', dataset='GTZAN') == 3
	assert candidate(path='country/country.00000', dataset='GTZAN') == 2
	assert candidate(path='genres_original/metal/00002.wav', dataset='GTZAN') == 6
	assert candidate(path='/home/carol/Music/genres/metal/metal.00001.wav', dataset='GTZAN') == 6
	assert candidate(path='blues/blues.00000', dataset='GTZAN') == 0
	assert candidate(path = 'hiphop/hiphop.00001.wav', dataset = 'GTZAN') == 4
	assert candidate(path='../data/genres_original/blues/blues.00000.wav',
                        dataset='GTZAN') == 0, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path = 'country/country.00001.wav', dataset = 'GTZAN') == 2
	assert candidate(path='genres_original/metal/jazz/jazz.00000.wav', dataset='GTZAN') == 5
	assert candidate(path = './data/genres/disco/disco.00000.au', dataset = 'GTZAN') == 3
	assert candidate(path='./data/genres_original/rock/rock.00000.wav', dataset='GTZAN') == 9
	assert candidate(path='/home/user/Downloads/genres_original/blues/blues.00000.wav', dataset='GTZAN') == 0
	assert candidate(path='../data/genres_original/jazz/jazz.00000.wav',
                        dataset='GTZAN') == 5, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path='/home/felix/Downloads/genres_original/metal/metal.00026.wav',
                        dataset='custom') == None
	assert candidate(path='/home/user/Music/rock/blues/blues.00000.wav', dataset='GTZAN') == 0
	assert candidate(path='disco/disco.00000', dataset='GTZAN') == 3
	assert candidate(path = '../audio_example/jazz/jazz.00000.wav', dataset = 'GTZAN') == 5
	assert candidate(path='../data/genres_original/classical/classical.00000.wav', dataset='GTZAN') == 1
	assert candidate(path = 'jazz/jazz.00001.wav', dataset = 'GTZAN') == 5
	assert candidate(path = 'genres_original/rock/rock.00000.wav', dataset = 'GTZAN') == 9
	assert candidate(path = 'blues/blues.00001.wav', dataset = 'GTZAN') == 0
	assert candidate(path='genres_original/metal/country/country.00000.wav', dataset='GTZAN') == 2
	assert candidate(path = 'genres_original/metal/metal.00000.wav', dataset = 'GTZAN') == 6
	assert candidate(path = 'data/genres_original/metal/00000.au',
                        dataset = 'MyNewDataset') == None
	assert candidate(path = 'GTZAN/genres_original/blues/blues.00000.wav',
                        dataset = 'GTZAN') == 0
	assert candidate(path='audio/genres/jazz/jazz.00001.wav', dataset='GTZAN') == 5, "ERROR: Wrong label for jazz.00001"
	assert candidate(path = '../audio_example/hiphop/hiphop.00000.wav', dataset = 'GTZAN') == 4
	assert candidate(path = 'GTZAN/genres_original/metal/metal.00000.wav',
                        dataset = 'GTZAN') == 6
	assert candidate(path = 'genres_original/reggae/reggae.00000.wav', dataset = 'GTZAN') == 8
	assert candidate(path = './data/genres/classical/classical.00000.au', dataset = 'GTZAN') == 1
	assert candidate(path='/home/user/data/GTZAN/genres/disco/disco.00000.wav', dataset='GTZAN') == 3
	assert candidate(path='./genres/metal/disco/disco.00015.wav', dataset='GTZAN') == 3
	assert candidate(path = './data/genres/metal/metal.00000.au', dataset = 'GTZAN') == 6
	assert candidate(path='./genres/metal/blues/blues.00015.wav', dataset='GTZAN') == 0
	assert candidate(path='./data/genres_original/metal/metal.00000.wav', dataset='GTZAN') == 6
	assert candidate(path='/home/user/data/GTZAN/genres/classical/classical.00000.wav',
                        dataset='GTZAN') == 1
	assert candidate(path = 'jazz/jazz.00000.wav', dataset = 'GTZAN') == 5
	assert candidate(path='audio/genres/country/country.00001.wav', dataset='GTZAN') == 2, "ERROR: Wrong label for country.00001"
	assert candidate(path='data/genres/blues/blues.00001.wav', dataset='GTZAN') == 0
	assert candidate(path='/home/user/Downloads/genres_original/country/country.00000.wav', dataset='GTZAN') == 2
	assert candidate(path='hiphop/hiphop.00000', dataset='GTZAN') == 4
	assert candidate(path='./genres/metal/classical/classical.00015.wav', dataset='GTZAN') == 1
	assert candidate(path='genres_original/metal/00001.wav', dataset='GTZAN') == 6
	assert candidate(path = 'classical/classical.00000.wav', dataset = 'GTZAN') == 1
	assert candidate(path='/home/user/data/GTZAN/genres/hiphop/hiphop.00000.wav', dataset='GTZAN') == 4
	assert candidate(path='genres_original/metal/00005.wav', dataset='GTZAN') == 6
	assert candidate(path = '../audio_example/country/country.00000.wav', dataset = 'GTZAN') == 2
	assert candidate(path = 'GTZAN/genres_original/disco/disco.00000.wav',
                        dataset = 'GTZAN') == 3
	assert candidate(path='./genres_original/disco/disco.00000.wav', dataset='GTZAN') == 3, "ERROR: GTZAN disco.00000.wav should return 3"
	assert candidate(path='/home/user/Music/rock/rock.00000.wav', dataset='GTZAN') == 9
	assert candidate(path = 'rock/rock.00001.wav', dataset = 'GTZAN') == 9
	assert candidate(path='/home/user/data/GTZAN/genres/metal/metal.00000.wav',
                        dataset='GTZAN') == 6
	assert candidate(path='/home/carol/Music/genres/classical/classical.00001.wav', dataset='GTZAN') == 1
	assert candidate(path='audio/genres/classical/classical.00001.wav', dataset='GTZAN') == 1, "ERROR: Wrong label for classical.00001"
	assert candidate(path = 'GTZAN/genres_original/reggae/reggae.00000.wav',
                        dataset = 'GTZAN') == 8
	assert candidate(path='../data/genres_original/country/country.00000.wav', dataset='GTZAN') == 2
	assert candidate(path='/home/user/Downloads/genres_original/classical/classical.00000.wav', dataset='GTZAN') == 1
	assert candidate(path = 'GTZAN/genres_original/classical/classical.00000.wav',
                        dataset = 'GTZAN') == 1
	assert candidate(path='../data/genres_original/hiphop/hiphop.00000.wav',
                        dataset='GTZAN') == 4, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path = 'pop/pop.00000.wav', dataset = 'GTZAN') == 7
	assert candidate(path='../data/genres_original/classical/classical.00000.wav',
                        dataset='GTZAN') == 1, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path ='reggae/reggae.00001.wav', dataset = 'GTZAN') == 8
	assert candidate(path = 'blues/blues.00000.wav', dataset = 'GTZAN') == 0
	assert candidate(path = 'country/country.00000.wav', dataset = 'GTZAN') == 2
	assert candidate(path='./genres/metal/metal/metal.00015.wav', dataset='GTZAN') == 6
	assert candidate(path = '../audio_example/disco/disco.00000.wav', dataset = 'GTZAN') == 3
	assert candidate(path='/home/user/data/GTZAN/genres/pop/pop.00000.wav',
                        dataset='GTZAN') == 7
	assert candidate(path='metal/metal.00000', dataset='GTZAN') == 6
	assert candidate(path='/home/user/Downloads/genres_original/jazz/jazz.00000.wav', dataset='GTZAN') == 5
	assert candidate(path='../data/genres_original/disco/disco.00000.wav',
                        dataset='GTZAN') == 3, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path = 'hiphop/hiphop.00000.wav', dataset = 'GTZAN') == 4
	assert candidate(path = 'GTZAN/genres_original/jazz/jazz.00000.wav',
                        dataset = 'GTZAN') == 5
	assert candidate(path='pop/pop.00000', dataset='GTZAN') == 7
	assert candidate(path = 'rock/rock.00000.wav', dataset = 'GTZAN') == 9
	assert candidate(path = 'genres_original/country/country.00000.wav', dataset = 'GTZAN') == 2
	assert candidate(path='/home/user/data/GTZAN/genres/reggae/reggae.00000.wav', dataset='GTZAN') == 8
	assert candidate(path = './data/genres/jazz/jazz.00000.au', dataset = 'GTZAN') == 5
	assert candidate(path='./data/genres_original/reggae/reggae.00000.wav', dataset='GTZAN') == 8
	assert candidate(path='./data/genres_original/blues/blues.00000.wav', dataset='GTZAN') == 0
	assert candidate(path='./genres_original/country/country.00000.wav', dataset='GTZAN') == 2, "ERROR: GTZAN country.00000.wav should return 2"
	assert candidate(path='../data/genres_original/metal/metal.00000.wav', dataset='GTZAN') == 6
	assert candidate(path = '../audio_example/blues/blues.00000.wav', dataset = 'GTZAN') == 0
	assert candidate(path='../data/genres_original/disco/disco.00000.wav', dataset='GTZAN') == 3
	assert candidate(path='data/genres/rock/rock.00001.wav', dataset='GTZAN') == 9
	assert candidate(path = './data/genres/hiphop/hiphop.00000.au', dataset = 'GTZAN') == 4
	assert candidate(path='/home/user/data/GTZAN/genres/pop/pop.00000.wav', dataset='GTZAN') == 7
	assert candidate(path='./data/genres/country/country.00000.au', dataset='GTZAN') == 2
	assert candidate(path='/home/user/data/GTZAN/genres/classical/classical.00000.wav', dataset='GTZAN') == 1
	assert candidate(path='/home/user/Music/genres_original/metal/blues/blues.00015.wav', dataset='GTZAN') == 0
	assert candidate(path='genres_original/metal/disco/disco.00000.wav', dataset='GTZAN') == 3
	assert candidate(path='/home/carol/Music/genres/reggae/reggae.00001.wav', dataset='GTZAN') == 8
	assert candidate(path = 'pop/pop.00001.wav', dataset = 'GTZAN') == 7
	assert candidate(path='./genres_original/classical/classical.00000.wav', dataset='GTZAN') == 1, "ERROR: GTZAN classical.00000.wav should return 1"
	assert candidate(path='reggae/reggae.00000', dataset='GTZAN') == 8
	assert candidate(path = './data/genres/reggae/reggae.00000.au', dataset = 'GTZAN') == 8
	assert candidate(path = 'GTZAN/genres_original/hiphop/hiphop.00000.wav',
                        dataset = 'GTZAN') == 4
	assert candidate(path='/home/carol/Music/genres/country/country.00001.wav', dataset='GTZAN') == 2
	assert candidate(path ='metal/metal.00001.wav', dataset = 'GTZAN') == 6
	assert candidate(path='/home/carol/Music/genres/pop/pop.00001.wav', dataset='GTZAN') == 7
	assert candidate(path='../data/genres_original/pop/pop.00000.wav',
                        dataset='GTZAN') == 7, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path = 'genres_original/disco/disco.00000.wav', dataset = 'GTZAN') == 3
	assert candidate(path='./data/genres_original/jazz/jazz.00000.wav', dataset='GTZAN') == 5
	assert candidate(path='../data/genres_original/metal/metal.00000.wav',
                        dataset='GTZAN') == 6, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path = './data/genres/blues/blues.00000.au', dataset = 'GTZAN') == 0
	assert candidate(path='/home/user/Downloads/genres_original/reggae/reggae.00000.wav', dataset='GTZAN') == 8
	assert candidate(path='audio/genres/metal/metal.00001.wav', dataset='GTZAN') == 6, "ERROR: Wrong label for metal.00001"
	assert candidate(path = '../audio_example/pop/pop.00000.wav', dataset = 'GTZAN') == 7
	assert candidate(path='../data/genres_original/hiphop/hiphop.00000.wav', dataset='GTZAN') == 4
	assert candidate(path ='reggae/reggae.00000.wav', dataset = 'GTZAN') == 8
	assert candidate(path='jazz/jazz.00000', dataset='GTZAN') == 5
	assert candidate(path = './data/genres/rock/rock.00000.au', dataset = 'GTZAN') == 9
	assert candidate(path='genres_original/metal/blues/blues.00000.wav', dataset='GTZAN') == 0
	assert candidate(path='/home/user/Downloads/genres_original/pop/pop.00000.wav', dataset='GTZAN') == 7
	assert candidate(path='/home/user/data/GTZAN/genres/hiphop/hiphop.00000.wav',
                        dataset='GTZAN') == 4
	assert candidate(path = '../audio_example/classical/classical.00000.wav', dataset = 'GTZAN') == 1
	assert candidate(path = 'disco/disco.00001.wav', dataset = 'GTZAN') == 3
	assert candidate(path='./data/genres/blues/blues.00000.au', dataset='GTZAN') == 0
	assert candidate(path = 'GTZAN/genres_original/country/country.00000.wav',
                        dataset = 'GTZAN') == 2
	assert candidate(path='./data/genres_original/classical/classical.00000.wav', dataset='GTZAN') == 1
	assert candidate(path='../data/genres_original/reggae/reggae.00000.wav', dataset='GTZAN') == 8
	assert candidate(path='/home/user/Downloads/genres_original/metal/metal.00000.wav', dataset='GTZAN') == 6
	assert candidate(path = 'genres_original/jazz/jazz.00000.wav', dataset = 'GTZAN') == 5
	assert candidate(path='/home/user/data/GTZAN/genres/country/country.00000.wav', dataset='GTZAN') == 2
	assert candidate(path='../data/genres_original/country/country.00000.wav',
                        dataset='GTZAN') == 2, 'Wrong implementation of GTZAN dataset!'
	assert candidate(path='audio/genres/blues/blues.00001.wav', dataset='GTZAN') == 0, "ERROR: Wrong label for blues.00001"
	assert candidate(path='/home/user/data/GTZAN/genres/metal/metal.00000.wav', dataset='GTZAN') == 6
	assert candidate(path = './data/genres/pop/pop.00000.au', dataset = 'GTZAN') == 7
	assert candidate(path='../data/genres_original/blues/blues.00000.wav', dataset='GTZAN') == 0
	assert candidate(path = 'disco/disco.00000.wav', dataset = 'GTZAN') == 3
	assert candidate(path='./data/genres_original/country/country.00000.wav', dataset='GTZAN') == 2
	assert candidate(path = './data/genres/country/country.00000.au', dataset = 'GTZAN') == 2
	assert candidate(path='./data/genres_original/hiphop/hiphop.00000.wav', dataset='GTZAN') == 4
	assert candidate(path='../data/genres_original/jazz/jazz.00000.wav', dataset='GTZAN') == 5
	assert candidate(path='/home/carol/Music/genres/jazz/jazz.00001.wav', dataset='GTZAN') == 5
	assert candidate(path='genres_original/metal/metal/metal.00000.wav', dataset='GTZAN') == 6
	assert candidate(path='/home/carol/Music/genres/disco/disco.00001.wav', dataset='GTZAN') == 3
	assert candidate(path = 'classical/classical.00001.wav', dataset = 'GTZAN') == 1
def test_check():
	check(path2gt_datasets)
