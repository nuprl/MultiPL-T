def mstar_from_stellarprops(rstar, logg):
    """Gives stellar mass from the rstar and logg
       INPUT:
         rstar - Radius of star [Rsun]
         logg - log surface gravity [cgs]
       OUTPUT:
         mstar - stellar mass [Msun]
    """
    ### Canonical solution below ###
    # Convert logg and rstar into stellar mass assuming logg_sun=4.437
    mstar = 10.0**logg * rstar**2. / 10.0**4.437
    return mstar


### Unit tests below ###
def check(candidate):
	assert candidate(10, 4.437) > 1.0
	assert candidate(1.0, 4.436) < 1.0
	assert candidate(1.0, 4.437) == 1.0, \
    "Expected 1.0, got {}".format(candidate(1.0, 4.437))
	assert candidate(2.5, 5.0) == 10.0**5.0 * 2.5**2. / 10.0**4.437
	assert candidate(1.0, 4.438) > candidate(1.0, 4.436)
	assert candidate(1, 4.437+1) > 1.0
	assert candidate(1.0, 4.438) > 1.0
	assert candidate(1, 4.437) == 1.0
	assert candidate(0.0, 4.437) == 0.0
	assert candidate(0.5, 4.437) == 0.25
	assert candidate(rstar=1.0, logg=4.437) == 1.0, "Failed unit test for candidate."
	assert candidate(1.0, 4.437) == 1.0
	assert candidate(10, 4.437+1) > 10.0
	assert candidate(2.5, 4.0) == 10.0**4.0 * 2.5**2. / 10.0**4.437
	assert candidate(1.2, 4.0) == 10.0**4.0 * 1.2**2. / 10.0**4.437
	assert candidate(1.0, 4.437-0.01) < 1.0
	assert candidate(1.0, 4.437+0.01) > 1.0
	assert candidate(1.0, 4.438) > candidate(1.0, 4.437)
	assert candidate(2.0, 4.5) == 10.0**4.5 * 2.0**2. / 10.0**4.437
def test_check():
	check(mstar_from_stellarprops)
