def aggregate_metrics(metric_list):
    """
    Make aggregation for list of metrics
    :param metric_list: List of latest metrics
    :return: Aggregated list of metrics for CloudWatch
    """
    ### Canonical solution below ###
    agr_metrics = {
        'maximum': max(metric_list),
        'minimum': min(metric_list),
        'samplecount': len(metric_list),
        'sum': round(float(sum(metric_list)), 2),
        'average': round(float(sum(metric_list)/len(metric_list)), 2)
    }
    return agr_metrics


### Unit tests below ###
def check(candidate):
	assert candidate( [1.0, 2.0, 3.0, 4.0, 5.0]) == {
   'maximum': 5.0,
   'minimum': 1.0,
   'samplecount': 5,
   'sum': 15.0,
    'average': 3.0
}
	assert candidate(metric_list=[1,2,3]) == {
   'maximum': 3,
   'minimum': 1,
   'samplecount': 3,
   'sum': 6,
    'average': 2
}
	assert candidate(metric_list=[1]) == {'maximum': 1,'minimum': 1,'samplecount': 1,'sum': 1.0, 'average': 1.0}
	assert candidate(metric_list=[2, 4, 6, 8]) == {
   'maximum': 8,
   'minimum': 2,
   'samplecount': 4,
   'sum': 20,
    'average': 5
}
	assert candidate(metric_list=[1,2,3]) == {'maximum': 3,'minimum': 1,'samplecount': 3,'sum': 6.0, 'average': 2.0}
	assert candidate(metric_list=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == {
   'maximum': 10,
   'minimum': 1,
   'samplecount': 10,
   'sum': 55,
    'average': 5.5
}
	assert candidate(metric_list=[1, 2, 3, 4, 5, 6, 7, 8]) == {'maximum': 8,'minimum': 1,'samplecount': 8,'sum': 36, 'average': 4.5}
	assert candidate(metric_list=[1, 2, 3, 4, 5]) == {
   'maximum': 5,
   'minimum': 1,
   'samplecount': 5,
   'sum': 15.0,
    'average': 3.0
}
	assert candidate(metric_list=[1, 1, 1]) == {
   'maximum': 1,
   'minimum': 1,
   'samplecount': 3,
   'sum': 3,
    'average': 1
}
	assert candidate(metric_list=[1, 2, 3]) == {
   'maximum': 3,
   'minimum': 1,
   'samplecount': 3,
   'sum': 6,
    'average': 2
}
	assert candidate(metric_list=[2, 4, 6, 8, 10]) == {
   'maximum': 10,
   'minimum': 2,
   'samplecount': 5,
   'sum': 30,
    'average': 6
}
	assert candidate(metric_list=[1,2,3,4,5]) == {
   'maximum': 5,
   'minimum': 1,
   'samplecount': 5,
   'sum': 15,
    'average': 3
}
	assert candidate( [10000.0, 20000.0, 30000.0, 40000.0, 50000.0]) == {
   'maximum': 50000.0,
   'minimum': 10000.0,
   'samplecount': 5,
   'sum': 150000.0,
    'average': 30000.0
}
	assert candidate(
    [100, 200, 300, 400, 500]) == {'maximum': 500,'minimum': 100,'samplecount': 5,'sum': 1500, 'average': 300.0}
	assert candidate( [1.0, 1.0, 1.0, 1.0, 1.0]) == {
   'maximum': 1.0,
   'minimum': 1.0,
   'samplecount': 5,
   'sum': 5.0,
    'average': 1.0
}
	assert candidate(range(1000)) == {
   'maximum': 999,
   'minimum': 0,
   'samplecount': 1000,
   'sum': 499500.0,
    'average': 499.5
}
	assert candidate(metric_list=[1, 2, 3]) == {'maximum': 3,'minimum': 1,'samplecount': 3,'sum': 6, 'average': 2.0}
	assert candidate(metric_list=[1, 2, 3]) == {'maximum': 3,'minimum': 1,'samplecount': 3,'sum': 6, 'average': 2}
	assert candidate(
    [300, 600, 900, 1200, 1500]) == {'maximum': 1500,'minimum': 300,'samplecount': 5,'sum': 4500, 'average': 900.0}
	assert candidate(metric_list=[1,2,3,4,5]) == {'maximum': 5,'minimum': 1,'samplecount': 5,'sum': 15, 'average': 3}
	assert candidate(metric_list=[1, 2, 3, 4, 5]) == {'maximum': 5,'minimum': 1,'samplecount': 5,'sum': 15, 'average': 3}
	assert candidate(metric_list=[1,2,3,4,5,6]) == {
   'maximum': 6,
   'minimum': 1,
   'samplecount': 6,
   'sum': 21.0,
    'average': 3.5
}
	assert candidate(range(1, 10)) == {'maximum': 9,'minimum': 1,'samplecount': 9,'sum': 45, 'average': 5.0}
	assert candidate(
    [200, 400, 600, 800, 1000]) == {'maximum': 1000,'minimum': 200,'samplecount': 5,'sum': 3000, 'average': 600.0}
	assert candidate(metric_list=[1, 2, 3, 4]) == {
   'maximum': 4,
   'minimum': 1,
   'samplecount': 4,
   'sum': 10,
    'average': 2.5
}
	assert candidate(metric_list=[2, 4, 6, 8]) == {
   'maximum': 8,
   'minimum': 2,
   'samplecount': 4,
   'sum': 20,
    'average': 5.0
}
	assert candidate(metric_list=[1,2]) == {'maximum': 2,'minimum': 1,'samplecount': 2,'sum': 3.0, 'average': 1.5}
	assert candidate(range(10)) == {
   'maximum': 9,
   'minimum': 0,
   'samplecount': 10,
   'sum': 45,
    'average': 4.5
}
	assert candidate(metric_list=[1, 2, 3, 4]) == {'maximum': 4,'minimum': 1,'samplecount': 4,'sum': 10, 'average': 2.5}
	assert candidate(metric_list=[1.1, 2.2, 3.3, 4.4, 5.5]) == {
   'maximum': 5.5,
   'minimum': 1.1,
   'samplecount': 5,
   'sum': 16.5,
    'average': 3.3
}
	assert candidate(metric_list=[1, 2, 3, 4, 5]) == {'maximum': 5,'minimum': 1,'samplecount': 5,'sum': 15, 'average': 3.0}
	assert candidate(metric_list=[1,2,3,4]) == {
   'maximum': 4,
   'minimum': 1,
   'samplecount': 4,
   'sum': 10.0,
    'average': 2.5
}
	assert candidate([1, 2, 3, 4, 5]) == {
   'maximum': 5,
   'minimum': 1,
   'samplecount': 5,
   'sum': 15.0,
    'average': 3.0
}
	assert candidate(metric_list=[1, 2, 3, 4, 5]) == {
   'maximum': 5,
   'minimum': 1,
   'samplecount': 5,
   'sum': 15,
    'average': 3
}
	assert candidate(metric_list=[1, 2, 3]) == {
   'maximum': 3,
   'minimum': 1,
   'samplecount': 3,
   'sum': 6,
    'average': 2.0
}
	assert candidate(metric_list=[1, 2, 3, 4, 5, 6]) == {'maximum': 6,'minimum': 1,'samplecount': 6,'sum': 21, 'average': 3.5}
	assert candidate(metric_list=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]) == {
   'maximum': 1.0,
   'minimum': 0.1,
   'samplecount': 10,
   'sum': 5.5,
    'average': 0.55
}
def test_check():
	check(aggregate_metrics)
