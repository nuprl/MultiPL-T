def parse_violated_policy_rule(raw_violated_policy_rule_list: list) -> list:
    """
    Parses a list of rules to context paths
    :param raw_violated_policy_rule_list: the raw rules list
    :return: the parsed rules list
    """
    ### Canonical solution below ###
    violated_policy_rule_list: list = []
    for raw_violated_policy_rule in raw_violated_policy_rule_list:
        violated_policy_rule: dict = {
            'Name': raw_violated_policy_rule.get('ruleName'),
            'ID': raw_violated_policy_rule.get('ID')
        }
        violated_policy_rule_list.append({key: val for key, val in violated_policy_rule.items() if val})
    return violated_policy_rule_list


### Unit tests below ###
def check(candidate):
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'test_rule_name', 'ID': 'test_rule_id'}]) == [{'Name': 'test_rule_name', 'ID': 'test_rule_id'}]
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'test1', 'ID': 'test1'}, {'ruleName': 'test2', 'ID': 'test2'}]) == [{'Name': 'test1', 'ID': 'test1'}, {'Name': 'test2', 'ID': 'test2'}]
	assert candidate(
    [
        {'ruleName': 'TestRule1', 'ID': 'TestID1'},
        {'ruleName': 'TestRule2', 'ID': 'TestID2'}
    ]
) == [
    {'Name': 'TestRule1', 'ID': 'TestID1'},
    {'Name': 'TestRule2', 'ID': 'TestID2'}
]
	assert candidate(
    [
        {
            'ID': '1',
            'ruleName': 'rule1',
            'ruleType': 'type1'
        },
        {
            'ID': '2',
            'ruleName': 'rule2',
            'ruleType': 'type2'
        }
    ]
) == [
    {
        'ID': '1',
        'Name': 'rule1'
    },
    {
        'ID': '2',
        'Name': 'rule2'
    }
]
	assert candidate(
    [{'ruleName': 'Name', 'ID': 'ID'}]) == [{'Name': 'Name', 'ID': 'ID'}]
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'Rule 1', 'ID': '123'}, {'ruleName': 'Rule 2', 'ID': '456'}]) == [
    {'Name': 'Rule 1', 'ID': '123'}, {'Name': 'Rule 2', 'ID': '456'}]
	assert candidate(
    [{'ruleName': 'TestRule', 'ID': '123'}]
) == [{'Name': 'TestRule', 'ID': '123'}]
	assert candidate(
    [
        {
            'ruleName': 'test_rule_1',
            'ID': 1
        },
        {
            'ruleName': 'test_rule_2',
            'ID': 2
        },
        {
            'ruleName': 'test_rule_3',
            'ID': 3
        }
    ]
) == [
    {
        'Name': 'test_rule_1',
        'ID': 1
    },
    {
        'Name': 'test_rule_2',
        'ID': 2
    },
    {
        'Name': 'test_rule_3',
        'ID': 3
    }
]
	assert candidate(raw_violated_policy_rule_list=[{
    'ruleName': 'ruleName1',
    'ID': 'id1'
}, {
    'ruleName': 'ruleName2',
    'ID': 'id2'
}]) == [{
    'Name': 'ruleName1',
    'ID': 'id1'
}, {
    'Name': 'ruleName2',
    'ID': 'id2'
}]
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'Rule 1', 'ID': '123'}]) == [
    {'Name': 'Rule 1', 'ID': '123'}]
	assert candidate(
    raw_violated_policy_rule_list=[
        {'ruleName': 'rule_name_1', 'ID': 'id_1'},
        {'ruleName': 'rule_name_2', 'ID': 'id_2'},
        {'ruleName': 'rule_name_3', 'ID': 'id_3'}
    ]
) == [
    {'Name': 'rule_name_1', 'ID': 'id_1'},
    {'Name': 'rule_name_2', 'ID': 'id_2'},
    {'Name': 'rule_name_3', 'ID': 'id_3'}
]
	assert candidate(
    [{'ruleName': 'Name', 'ID': 'ID'}, {'ruleName': 'Name2', 'ID': 'ID2'}]) == [{'Name': 'Name', 'ID': 'ID'},
                                                                               {'Name': 'Name2', 'ID': 'ID2'}]
	assert candidate(raw_violated_policy_rule_list=[]) == []
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'Rule1', 'ID': 1}, {'ruleName': 'Rule2', 'ID': 2}]) == [{'Name': 'Rule1', 'ID': 1}, {'Name': 'Rule2', 'ID': 2}]
	assert candidate(raw_violated_policy_rule_list=[
    {'ruleName': 'Rule 1', 'ID': 'ID 1'},
    {'ruleName': 'Rule 2', 'ID': 'ID 2'},
    {'ruleName': 'Rule 3', 'ID': 'ID 3'},
]) == [
    {'Name': 'Rule 1', 'ID': 'ID 1'},
    {'Name': 'Rule 2', 'ID': 'ID 2'},
    {'Name': 'Rule 3', 'ID': 'ID 3'},
]
	assert candidate(
    [{'ruleName': 'TestRule', 'ID': '123'}, {'ruleName': 'TestRule2', 'ID': '456'}]
) == [{'Name': 'TestRule', 'ID': '123'}, {'Name': 'TestRule2', 'ID': '456'}]
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'rule_name', 'ID': 'rule_id'}]) == [{
    'Name': 'rule_name',
    'ID': 'rule_id'
}]
	assert candidate(
    [{'ruleName': 'test_rule_1', 'ID': 'test_id_1'},
     {'ruleName': 'test_rule_2'}]
) == [
    {'Name': 'test_rule_1', 'ID': 'test_id_1'},
    {'Name': 'test_rule_2'}
]
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'test', 'ID': '123'}, {'ruleName': 'test2', 'ID': '456'}]) == [{'Name': 'test', 'ID': '123'}, {'Name': 'test2', 'ID': '456'}]
	assert candidate(
    raw_violated_policy_rule_list=[
        {
            'ruleName': 'Rule1',
            'ID': 'ID1'
        },
        {
            'ruleName': 'Rule2',
            'ID': 'ID2'
        }
    ]
) == [
    {
        'Name': 'Rule1',
        'ID': 'ID1'
    },
    {
        'Name': 'Rule2',
        'ID': 'ID2'
    }
]
	assert candidate(
    [
        {
            'ruleName': 'AWS GuardDuty Finding',
            'ID': 'f1896658-a084-4627-9056-754056b95697'
        },
        {
            'ruleName': 'AWS GuardDuty Finding',
            'ID': 'f1896658-a084-4627-9056-754056b95697'
        }
    ]
) == [
    {
        'Name': 'AWS GuardDuty Finding',
        'ID': 'f1896658-a084-4627-9056-754056b95697'
    },
    {
        'Name': 'AWS GuardDuty Finding',
        'ID': 'f1896658-a084-4627-9056-754056b95697'
    }
]
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'rule_name', 'ID': 'id'}]) == [{'Name': 'rule_name', 'ID': 'id'}]
	assert candidate([]) == []
	assert candidate([{'ruleName': 'TestRule', 'ID': 123}]) == [{'Name': 'TestRule', 'ID': 123}]
	assert candidate(
    []
) == []
	assert candidate(
    [{'ruleName': 'test_rule_1', 'ID': 'test_id_1'},
     {'ruleName': 'test_rule_2', 'ID': 'test_id_2'}]
) == [
    {'Name': 'test_rule_1', 'ID': 'test_id_1'},
    {'Name': 'test_rule_2', 'ID': 'test_id_2'}
]
	assert candidate(
    [
        {
            'ruleName': 'Policy Rule 1',
            'ID': '11111111-1111-1111-1111-111111111111'
        },
        {
            'ruleName': 'Policy Rule 2',
            'ID': '22222222-2222-2222-2222-222222222222'
        }
    ]
) == [
    {
        'Name': 'Policy Rule 1',
        'ID': '11111111-1111-1111-1111-111111111111'
    },
    {
        'Name': 'Policy Rule 2',
        'ID': '22222222-2222-2222-2222-222222222222'
    }
]
	assert candidate(
    [{'ruleName': 'Rule 1', 'ID': '123'}, {'ruleName': 'Rule 2', 'ID': '456'}, {'ruleName': 'Rule 3', 'ID': '789'}]
) == [{'Name': 'Rule 1', 'ID': '123'}, {'Name': 'Rule 2', 'ID': '456'}, {'Name': 'Rule 3', 'ID': '789'}]
	assert candidate(raw_violated_policy_rule_list=[{'ruleName': 'test', 'ID': '123'}]) == [{'Name': 'test', 'ID': '123'}]
def test_check():
	check(parse_violated_policy_rule)
