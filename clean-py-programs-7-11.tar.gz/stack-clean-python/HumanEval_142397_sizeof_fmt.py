def sizeof_fmt(num, suffix='B'):
    """
    From https://stackoverflow.com/a/1094933
    """
    ### Canonical solution below ###
    for unit in ['', 'Ki', 'Mi', 'Gi', 'Ti', 'Pi', 'Ei', 'Zi']:
        if abs(num) < 1024.0:
            return "%d %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f %s%s" % (num, 'Yi', suffix)


### Unit tests below ###
def check(candidate):
	assert candidate(1023) == "1023 B"
	assert candidate(1024**8) == '1.0 YiB'
	assert candidate(0) == "0 B"
	assert candidate(1023) == '1023 B'
	assert candidate(1000) == "1000 B"
	assert candidate(1) == '1 B'
	assert candidate(1024*1024*1024*1024*1024*1024*1024*1024) == '1.0 YiB'
	assert candidate(1000) == '1000 B'
	assert candidate(1024**8) == "1.0 YiB"
	assert candidate(1024*1024*1024*1024*1024*1024*1024*1024*1024) == '1024.0 YiB'
	assert candidate(1024**9) == "1024.0 YiB"
	assert candidate(1) == "1 B"
	assert candidate(100) == "100 B"
	assert candidate(1024**9) == '1024.0 YiB'
	assert candidate(1024*1024*1024*1024*1024*1024*1024*1024) == "1.0 YiB"
	assert candidate(0) == '0 B'
def test_check():
	check(sizeof_fmt)
