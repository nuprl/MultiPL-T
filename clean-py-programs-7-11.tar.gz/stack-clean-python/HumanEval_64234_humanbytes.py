def humanbytes(inbytes):
    """
    NB: not mebibytes, units with zeroes
    """
    ### Canonical solution below ###
    if inbytes < 10000:
        return "%d bytes" % inbytes
    elif inbytes < 10000000:
        return "%d Kbytes" % (inbytes // 1000)
    elif inbytes < 10000000000:
        return "%d Mbytes" % (inbytes // 10**6)
    else:
        return "%d Gbytes" % (inbytes // 10**9)


### Unit tests below ###
def check(candidate):
	assert candidate(100000) == "100 Kbytes"
	assert candidate(10000000000) == "10 Gbytes"
	assert candidate(10000) == "10 Kbytes"
	assert candidate(1000) == "1000 bytes"
	assert candidate(10000000) == "10 Mbytes"
	assert candidate(0) == '0 bytes'
	assert candidate(0) == "0 bytes"
	assert candidate(10) == "10 bytes"
	assert candidate(100) == "100 bytes"
	assert candidate(1) == "1 bytes"
	assert candidate(100000000) == "100 Mbytes"
	assert candidate(100000000000) == "100 Gbytes"
	assert candidate(1024) == '1024 bytes'
	assert candidate(1023) == "1023 bytes"
	assert candidate(100000000000000000)
	assert candidate(1023) == '1023 bytes'
	assert candidate(999) == "999 bytes"
def test_check():
	check(humanbytes)
