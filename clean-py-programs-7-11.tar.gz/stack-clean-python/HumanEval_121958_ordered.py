def ordered(obj):
    """ Return consistently ordered version of the passed object."""
	### Canonical solution below ###    
    if isinstance(obj, dict):
        return sorted((k, ordered(v)) for k, v in obj.items())
    if isinstance(obj, list):
        return sorted(ordered(x) for x in obj)
    return obj

### Unit tests below ###
def check(candidate):
	assert candidate([4, 3, 1]) == [1, 3, 4]
	assert candidate({'a': 42, 'b': [1, 2, 3]})!= {'a': 42, 'b': [1, 3, 2]}
	assert candidate("abc") == "abc"
	assert candidate({'b': 2, 'a': 1}) == [('a', 1), ('b', 2)]
	assert type(candidate(42)) == int
	assert candidate([1,2])!= [1,2,3]
	assert candidate(True) == True
	assert candidate([{'a': 1}, {'b': 2}]) == [[('a', 1)], [('b', 2)]]
	assert candidate({'a': 1, 'b': {'x': 3, 'y': 4}}) == [('a', 1), ('b', [('x', 3), ('y', 4)])]
	assert candidate(5.0) == 5.0
	assert candidate([]) == []
	assert candidate({'a':1,'b':2})!= {'b':2,'a':1}
	assert candidate('1') == '1'
	assert candidate((1,2,3)) == (1,2,3)
	assert candidate("5") == "5"
	assert candidate({4: 5, 3: 6, 1: 7}) == [(1, 7), (3, 6), (4, 5)]
	assert candidate({3: 4, 1: 2}) == [(1, 2), (3, 4)]
	assert candidate((3, 1, 4)) == (3, 1, 4)
	assert candidate('a') == 'a'
	assert candidate([1,2,3])!= [1,2]
	assert candidate(b'\x00\x01\x02') == b'\x00\x01\x02'
	assert candidate({"b": 2, "a": 1}) == [("a", 1), ("b", 2)]
	assert candidate(set([5, 4, 3])) == set([3, 4, 5])
	assert type(candidate('42')) == str
	assert candidate(u'42') == u'42'
	assert candidate({'a': 1, 'b': 2, 'c': [1, 2, 3]}) == \
    [('a', 1), ('b', 2), ('c', [1, 2, 3])]
	assert candidate([1,2,3])!= [1,2,3,4]
	assert candidate({'a': 1}) == [('a', 1)]
	assert candidate('abc') == 'abc'
	assert candidate([1.0, 2.0, 3.0]) == [1.0, 2.0, 3.0]
	assert candidate({"b": [2, 3], "a": 1}) == [("a", 1), ("b", [2, 3])]
	assert candidate("test") == "test"
	assert candidate([5, 4, 3]) == [3, 4, 5]
	assert candidate("foo") == "foo"
	assert candidate(b"foo") == b"foo"
	assert candidate({1: 1, 2: 2}) == [(1, 1), (2, 2)]
	assert candidate({"a": 1, "b": 2}) == [("a", 1), ("b", 2)]
	assert candidate({'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
	assert candidate(1.0) == 1.0
	assert candidate(dict(a=1, b=2, c=3)) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(None) is None
	assert candidate({'foo': 4, 'bar': {'foo': 4, 'bar': 'foo'}}) == [
    ('bar', [
        ('bar', 'foo'),
        ('foo', 4),
    ]),
    ('foo', 4),
]
	assert candidate({'foo': 4, 'bar': 'foo'}) == [
    ('bar', 'foo'),
    ('foo', 4),
]
	assert candidate({'4': 5, '3': 6, '1': 7}) == [('1', 7), ('3', 6), ('4', 5)]
	assert candidate({"a": 1, "b": 2, "c": {"d": 3}}) == [("a", 1), ("b", 2), ("c", [("d", 3)])]
	assert candidate({'a':1,'b':2})!= {'a':1,'b':2,'c':3}
	assert candidate(
    [1, 2, 3]) == [1, 2, 3]
	assert candidate({1: 1}) == [(1, 1)]
	assert candidate({'a': 1, 'b': [2, 3], 'c': {'d': 4}}) == [
    ('a', 1),
    ('b', [2, 3]),
    ('c', [('d', 4)]),
]
	assert candidate({1:2, 3:4}) == [(1,2), (3,4)]
	assert candidate(42.0) == 42.0
	assert candidate(set([1, 2, 3])) == set([1, 2, 3])
	assert candidate([42]) == [42]
	assert candidate(
    {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5, 'f': 6}}) == [
        ('a', 1), ('b', 2), ('c', [
            ('d', 4), ('e', 5), ('f', 6)])]
	assert candidate("a") == "a"
	assert candidate({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}) == \
    [('a', 1), ('b', 2), ('c', [('d', 3), ('e', 4)])]
	assert candidate({'a': 1, 'b': {'z': 2, 'y': 3}}) == [('a', 1), ('b', [('y', 3), ('z', 2)])]
	assert candidate(b'42') == b'42'
	assert candidate(42) == 42
	assert candidate(5) == 5
	assert candidate({'a': 1, 'b': [3, 2]}) == [('a', 1), ('b', [2, 3])]
	assert candidate({"a": 1, "b": [2, 3]}) == [("a", 1), ("b", [2, 3])]
	assert candidate('42') == '42'
	assert candidate({'b': {'y': [1, 2, 3], 'x': 3}, 'a': 1}) == [('a', 1), ('b', [('x', 3), ('y', [1, 2, 3])])]
	assert candidate({'b': {'z': 2, 'y': 3}, 'a': 1}) == [('a', 1), ('b', [('y', 3), ('z', 2)])]
	assert candidate([1, 2, 3])!= [1, 3, 2]
	assert candidate(False) is False
	assert candidate([1,2,3])!= [3,2,1]
	assert candidate({'a': 42}) == [('a', 42)]
	assert candidate([1]) == [1]
	assert candidate({'a':1,'b':2,'c':3})!= {'a':1,'b':2}
	assert candidate(False) == False
	assert candidate('foo') == 'foo'
	assert candidate([1, 2]) == [1, 2]
	assert candidate({'a': 1, 'b': 2, 'c': 3}) == [
    ('a', 1),
    ('b', 2),
    ('c', 3),
]
	assert candidate({'a': 1, 'b': {'x': 3, 'y': [1, 2, 3]}}) == [('a', 1), ('b', [('x', 3), ('y', [1, 2, 3])])]
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}) == [
        ('a', 1), ('b', 2), ('c', 3)]
	assert candidate(u"foo") == u"foo"
	assert candidate([1,2]) == [1,2]
	assert candidate({'a': 1, 'b': {'c': 3}}) == [('a', 1), ('b', [('c', 3)])]
	assert candidate(3.14) == 3.14
	assert candidate({'a':1,'b':2})!= [('b',2),('a',1)]
	assert candidate({'a': 1, 'b': 2}) == candidate({'b': 2, 'a': 1})
	assert type(candidate(42.0)) == float
	assert candidate(3) == 3
	assert candidate((1, 2, 3)) == (1, 2, 3)
	assert candidate({'a':1,'b':2}) == [('a',1),('b',2)]
	assert candidate([3, 2, 1]) == [1, 2, 3]
	assert candidate({1: 2, 3: 4}) == [(1, 2), (3, 4)]
	assert candidate({'a': 1, 'b': [2, 3]}) == [('a', 1), ('b', [2, 3])]
	assert candidate({'b': 2, 'a': 1}) == [("a", 1), ("b", 2)]
	assert candidate({'a': 1, 'b': {'c': 2}}) == [('a', 1), ('b', [('c', 2)])]
	assert candidate(True) is True
	assert candidate([1,2,3]) == [1,2,3]
	assert candidate(1) == 1
	assert candidate({'a': 1, 'b': 2}) == [("a", 1), ("b", 2)]
	assert candidate((1,2)) == (1,2)
	assert candidate(dict(c=3, b=2, a=1)) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate({'a': 1, 'b': 2, 'c': 3}) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(None) == None
	assert candidate({'b': {'y': 4, 'x': 3}, 'a': 1}) == [('a', 1), ('b', [('x', 3), ('y', 4)])]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate("1") == "1"
	assert candidate(4) == 4
def test_check():
	check(ordered)
