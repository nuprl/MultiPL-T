def _apply_epa_correction(pm, rh):
    """Applies the EPA calibration to Purple's PM2.5 data.
    Version of formula matches the Purple Air site's info.

    We floor it to 0 since the combination of very low pm2.5 concentration
    and very high humidity can lead to negative numbers.
    """
    ### Canonical solution below ###
    return max(0, 0.534 * pm - 0.0844 * rh + 5.604)


### Unit tests below ###
def check(candidate):
	assert candidate(0.0, 100.0) == 0.0
	assert candidate(5, 100) == 0
	assert candidate(100, 1000) == 0
	assert candidate(0, 100) == 0
	assert candidate(0.0, 80.0) == 0
	assert candidate(1.0, 100.0) == 0.0
	assert candidate(0, 80) == 0
	assert candidate(0, 120) == 0
def test_check():
	check(_apply_epa_correction)
