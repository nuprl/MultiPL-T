def module_name(prog):
    """ get the module name for a program
     """
	### Canonical solution below ###    
    return '_{}'.format(prog)

### Unit tests below ###
def check(candidate):
	assert candidate('prog1') == '_prog1'
	assert candidate(prog='foo') == '_foo'
	assert candidate('prog3') == '_prog3'
	assert candidate('foo') == '_foo'
	assert candidate(prog='foo_bar') == '_foo_bar'
	assert candidate(prog='dog') == '_dog'
	assert candidate(prog='Hello') == '_Hello'
	assert candidate(prog='cat') == '_cat'
	assert candidate(prog='test') == '_test'
	assert candidate(prog='prog') == '_prog'
	assert candidate(prog='foo_bar_baz') == '_foo_bar_baz'
	assert candidate('a') == '_a'
	assert candidate(prog='my_program') == '_my_program'
	assert candidate(prog='hello') == '_hello'
	assert candidate(None) == '_None'
	assert candidate('prog2') == '_prog2'
def test_check():
	check(module_name)
