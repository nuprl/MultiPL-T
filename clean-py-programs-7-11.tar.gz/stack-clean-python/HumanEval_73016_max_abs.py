def max_abs(lst):
    """ return largest abs value element of a list """
    ### Canonical solution below ###
    return max(abs(num) for num in lst)


### Unit tests below ###
def check(candidate):
	assert candidate( [0, 1, 2, 3, 4, 5] ) == 5
	assert candidate( [1, -1, 1, -1, 1, -1, 1, -1, 1] ) == 1
	assert candidate( [ 1, 3, 5, 7, 9, 0 ] ) == 9
	assert candidate( [-1, -1, -1, -1, -1, 1, 1, 1, 1] ) == 1
	assert candidate(list(range(0, 5))) == 4
	assert candidate([-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6]) == 6
	assert candidate( [ -1, 2, -3, 4 ] ) == 4
	assert candidate([-1, 2, 3, -4, 5]) == 5
	assert candidate( [ 1, 3, 5, 7, 9 ] ) == 9
	assert candidate([-2.5, 2.5]) == 2.5
	assert candidate(list(range(-10, 11))) == 10
	assert candidate(list(range(-10, 10))) == 10
	assert candidate(list(range(0, 6))) == 5
	assert candidate( [1, 2, 3, 4, 5] ) == 5
	assert candidate( [1, 2, 3, 4] ) == 4
	assert candidate( [ -1, 2, 3, 4, -5, 6, 7, 8, 9, 10 ] ) == 10
	assert candidate([-1]) == 1
	assert candidate([1, 2, 3, 4, 5, 6]) == 6
	assert candidate( [2, -1, -3, 5, 6] ) == 6
	assert candidate([10, 20, -30, 40]) == 40
	assert candidate([-10, -20, -30, -40, -50]) == 50
	assert candidate([-1, -2, -3, -4, -5, -6, -2]) == 6
	assert candidate( [0, 1, 2, 3, 4] ) == 4
	assert candidate( [1, 2, 3, 4, -5, -6, -7, -8] ) == 8
	assert candidate( [1, 2, 3, 4, -1, -2, -3, -4] ) == 4
	assert candidate( [-0, -0, -0, -0, -0] ) == 0
	assert candidate( [ -1, -3, -5, -7, -9 ] ) == 9
	assert candidate([-1, 1, 0]) == 1
	assert candidate([0, 2, 3, 4, 5, 6]) == 6
	assert candidate( [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] ) == 0
	assert candidate(list(range(-1, 0))) == 1
	assert candidate(list(range(5))) == 4
	assert candidate( [1, -2, 3, 4, -5] ) == 5
	assert candidate(list(range(-5, 0))) == 5
	assert candidate([-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5]) == 5
	assert candidate(list(range(10))) == 9
	assert candidate( [1, 2, 3, 4, -5] ) == 5
	assert candidate([-1, 2, -3, 4, -5, 6, -2]) == 6
	assert candidate([-1, 0, 1]) == 1
	assert candidate( [1, 1, 1, 1, 1] ) == 1
	assert candidate([-2, -4, 6, -8]) == 8
	assert candidate( [3, -3, 4, -4] ) == 4
	assert candidate( [-1, 2, -3, 4, -5] ) == 5
	assert candidate([-2, -4, -7]) == 7
	assert candidate(list(range(-1, 5))) == 4
	assert candidate([-1, -2, -3, -4, -5, -6]) == 6
	assert candidate([-10, -20, -30, -40]) == 40
	assert candidate( [-3, -3, -4, -5] ) == 5
	assert candidate([-2, 3, -4, 5]) == 5
	assert candidate( [0, 0, 0, 0, -0] ) == 0
	assert candidate([0, -2, -3, -4, -5, -6]) == 6
	assert candidate([-4, -3, -2, -1]) == 4
	assert candidate([-1, -2, -3, -4, -5]) == 5
	assert candidate([-10, 0, 10]) == 10
	assert candidate([1, 2, 3]) == 3
	assert candidate([1, -2, 3, -4, 5, -6, 2]) == 6
	assert candidate([-1, -2, -3, -4]) == 4
	assert candidate([-10, 20, 30, 40]) == 40
	assert candidate( [-2, 1, -3, 5, 6] ) == 6
	assert candidate( [-3, -3, 4, 5, -4, 5] ) == 5
	assert candidate([-1, 1, 1, -1, 1]) == 1
	assert candidate([2, -3, 4, 5, -10, 11]) == 11
	assert candidate(list(range(-2, 3))) == 2
	assert candidate(list(range(5, -6, -1))) == 5
	assert candidate(list(range(1, 2))) == 1
	assert candidate([-1, 1]) == 1
	assert candidate([-1, -2, -3]) == 3
	assert candidate( [ 2, -3, 4, -5 ] ) == 5
	assert candidate([2, -3, 4, -5]) == 5
	assert candidate( [1, 1, 1, 1, 1, -1, -1, -1, -1] ) == 1
	assert candidate([-1, 1, 1, -1, 1, -1, 1]) == 1
	assert candidate([-100, 100]) == 100
	assert candidate([-1, 1, 1, -1, 1, -1, 1, -1]) == 1
	assert candidate([-1, 1, 1, -1, 1, -1]) == 1
	assert candidate([1]) == 1
	assert candidate( [0, -0, 0, -0, 0] ) == 0
	assert candidate( [ -1, -2, -3, -4, -5, -6, -7, -8, -9, -10 ] ) == 10
	assert candidate([-1, 1, 2, 3, 4, -5]) == 5
	assert candidate(range(10)) == 9
	assert candidate( [-1, -2, -3, -4, -5, -6, -7, -8] ) == 8
	assert candidate( [0, 0, 0, 0, 0] ) == 0
	assert candidate(list(range(-5, 6))) == 5
	assert candidate( [ 1, 3, -5, 7, -9, 0 ] ) == 9
	assert candidate( [1, -2, 3, -4, 5] ) == 5
	assert candidate([1, 2, 3, 4, 5, 6, 2]) == 6
	assert candidate([-1, 2, 3, 4, -5]) == 5
	assert candidate( [0, 1, 2, 3, 4, -1, -2, -3, -4] ) == 4
	assert candidate([-2, -4, 0, 2, 4]) == 4
	assert candidate( [1, 2, -3, 4, 5, -6, 7, -8, 9, 10] ) == 10
	assert candidate([-10, 100, -100]) == 100
	assert candidate( [ 1, 2, 3, -4, 5, 6, -7, 8, 9, 10 ] ) == 10
	assert candidate([10, 20, 30, 40]) == 40
	assert candidate([-2, 1, -3, 4, -5]) == 5
	assert candidate( [-1, -1, -1, -1, -1] ) == 1
	assert candidate([-10, -100, 10]) == 100
	assert candidate([-1, 0, 1, 2, 3, 4, 5]) == 5
	assert candidate([1.0, -1.0, 3.0, -3.0]) == 3.0
	assert candidate( [-1, -2, -3, -4, -5] ) == 5
	assert candidate( [ 1, 3, -5, 7, -9 ] ) == 9
	assert candidate( [1, 2, -3, 4, 5] ) == 5
	assert candidate(list(range(1, 5))) == 4
	assert candidate([-1, 1, 1, -1]) == 1
	assert candidate( [-1, -1, -1, -1, -1, -1, -1, -1, -1] ) == 1
	assert candidate( [1, -2, -3, -4, -5] ) == 5
	assert candidate( [3, -3, 4, 5, -4] ) == 5
	assert candidate( [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ] ) == 10
	assert candidate( [-1, -2, -3, -4] ) == 4
	assert candidate(list(range(0, 100))) == 99
	assert candidate( [-1, 1, 2, 3, 4, 5] ) == 5
	assert candidate([-1, -2, 3, 4]) == 4
	assert candidate( [0, 0, 0, 0] ) == 0
	assert candidate([0, 0, 0]) == 0
	assert candidate(list(range(-10, 10, 2))) == 10
def test_check():
	check(max_abs)
