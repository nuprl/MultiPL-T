def is_cap_used(use_caps, i):
    """Returns ``True`` if a cap is used.

    Parameters
    ----------
    use_caps : :class:`int`
        Bit mask indicating which cap is used.
    i : :class:`int`
        Number indicating which cap we are interested in.

    Returns
    -------
    :class:`bool`
        ``True`` if a cap is used.
    """
    ### Canonical solution below ###
    return (use_caps & 1 << i) != 0


### Unit tests below ###
def check(candidate):
	assert candidate(0x0000, 0) == False
	assert candidate(0b101, 2) is True
	assert candidate(2, 1) is True
	assert not candidate(0x01, 4)
	assert candidate(0b11011111, 0) == True
	assert candidate(0b11111111, 1) == True
	assert candidate(0b0011, 1) == True
	assert not candidate(0x1, 3)
	assert candidate(0x30, 2) == False
	assert candidate(0b00000001, 0) == True
	assert candidate(0x2, 1) == True
	assert candidate(0, 0) is False
	assert candidate(0x5, 2) == True
	assert not candidate(0x01, 2)
	assert candidate(0, 6) == False
	assert candidate(0b11111111, 2) == True
	assert candidate(0b11111111, 6) == True
	assert candidate(0, 2) == False
	assert candidate(0b00000010, 1) == True
	assert candidate(1, 5) == False
	assert candidate(0b00000000000000000000000000000010, 1)
	assert candidate(7, 3) == False
	assert candidate(0b00000000, 0) == False
	assert not candidate(0b10000000000000000000000000000000, 1)
	assert not candidate(0x01, 3)
	assert candidate(0x4, 0) == False
	assert candidate(1, 7) == False
	assert candidate(2, 3) == False
	assert candidate(0, 5) == False
	assert candidate(0b11011111, 6) == True
	assert candidate(0b1010, 5) == False
	assert candidate(3, 0) == True
	assert candidate(2, 5) == False
	assert candidate(0x0010, 3) == False
	assert candidate(0b1111111111, 7) == True
	assert candidate(0xf, 3) == True
	assert candidate(2, 6) == False
	assert candidate(0x0008, 1) == False
	assert candidate(1, 2) == False
	assert candidate(0x5, 3) == False
	assert candidate(5, 0) == True
	assert candidate(0x1, 0)
	assert candidate(0b01000000, 6) == True
	assert candidate(0x70, 3) == False
	assert not candidate(1, 1)
	assert candidate(0b00000000000000000000000000000110, 1)
	assert candidate(0x0010, 2) == False
	assert candidate(1 << 31, 31) == True
	assert candidate(0b1101, 4) == False
	assert candidate(0x0, 0) == False
	assert candidate(2, 0) == False
	assert candidate(0x0, 1) == False
	assert not candidate(0x03, 3)
	assert candidate(0b00010000, 4) == True
	assert candidate(0x0020, 4) == False
	assert candidate(0b1111111111, 6) == True
	assert candidate(0xf0, 3) == False
	assert candidate(3, 0) is True
	assert candidate(0x1, 2) == False
	assert candidate(0b1010, 0) == False
	assert candidate(0x0010, 1) == False
	assert candidate(0b11111111, 3) == True
	assert candidate(0x5, 1) == False
	assert candidate(0, 4) == False
	assert not candidate(0x00, 1)
	assert candidate(0x2, 3) == False
	assert candidate(0b00001000, 3) == True
	assert candidate(0b10000000000000000000000000000010, 1)
	assert candidate(0x10, 0) == False
	assert candidate(0xf, 1) == True
	assert candidate(0b11011111, 3) == True
	assert candidate(3, 1) == True
	assert candidate(0b1000, 4) == False
	assert candidate(0x1, 0) == True
	assert candidate(0xf0, 2) == False
	assert candidate(0b0001, 0) == True
	assert candidate(0x3, 1) == True
	assert candidate(3, 3) == False
	assert candidate(0b00000000, 7) == False
	assert candidate(1 << 32, 0) == False
	assert candidate(7, 1) == True
	assert candidate(0b1111111111, 1) == True
	assert candidate(1, 0) is True
	assert candidate(0x0020, 1) == False
	assert candidate(0x4, 3) == False
	assert candidate(0xf0, 1) == False
	assert candidate(0b00000000, 2) == False
	assert candidate(0b00000000, 4) == False
	assert candidate(0b1111111111, 0) == True
	assert candidate(0b1111111111, 2) == True
	assert candidate(0x3, 3) == False
	assert candidate(4, 2) == True
	assert candidate(3, 2) == False
	assert candidate(0b1111111111, 9) == True
	assert candidate(0x2, 2) == False
	assert candidate(0b1101, 3) == True
	assert candidate(0x0020, 3) == False
	assert candidate(0x1, 1) == False
	assert not candidate(0x00, 4)
	assert not candidate(0x1, 2)
	assert candidate(0b1010, 2) == False
	assert candidate(1, 0) == True
	assert candidate(0b00100000, 5) == True
	assert candidate(1 << 32, 31) == False
	assert candidate(0x0020, 2) == False
	assert candidate(6, 1) == True
	assert candidate(1, 4) == False
	assert candidate(0x2, 0) == False
	assert not candidate(0x00, 3)
	assert candidate(0b1111111111, 5) == True
	assert candidate(0b11011111, 5) == False
	assert candidate(3, 1)
	assert candidate(0, 0) == False
	assert candidate(0x20, 1) == False
	assert candidate(0x5, 0) == True
	assert candidate(0b0110, 3) == False
	assert candidate(0x4, 2) == True
	assert candidate(0b1010, 1) == True
	assert candidate(0b1111111111, 4) == True
	assert candidate(0b00000000, 3) == False
	assert candidate(0b0000, 0) == False
	assert candidate(5, 2) == True
	assert candidate(1, 6) == False
	assert candidate(0, 3) == False
	assert not candidate(0x07, 4)
	assert candidate(0x1, 3) == False
	assert candidate(0b00000100, 2) == True
	assert candidate(0x0, 3) == False
	assert not candidate(0, 0)
	assert candidate(0b1110, 7) == False
	assert candidate(0x3, 0) == True
	assert candidate(0b11111111, 0) == True
	assert candidate(7, 0) == True
	assert candidate(0b0101, 2) == True
	assert candidate(0x0001, 0) == True
	assert candidate(0b00000000, 6) == False
	assert candidate(1, 1) == False
	assert candidate(0b00000000, 1) == False
	assert candidate(0b10000000, 7) == True
	assert not candidate(0x00, 2)
	assert candidate(2, 7) == False
	assert candidate(0x4, 1) == False
	assert candidate(2, 1) == True
	assert candidate(1 << 1, 0) == False
	assert candidate(0b11111111, 5) == True
	assert candidate(0x0008, 2) == False
	assert not candidate(0x2, 0)
	assert not candidate(0x03, 4)
	assert candidate(0x3, 2) == False
	assert candidate(1, 3) == False
	assert candidate(1 << 2 | 1, 3) == False
	assert candidate(0xf0, 0) == False
	assert candidate(2, 2) == False
	assert candidate(1, 0)
	assert candidate(0, 7) == False
	assert candidate(1 << 1 | 1, 0) == True
	assert candidate(0x0, 2) == False
	assert candidate(0b1100, 6) == False
	assert candidate(2, 4) == False
	assert candidate(0x0004, 1) == False
	assert candidate(0b1101, 5) == False
	assert candidate(0xf, 2) == True
	assert candidate(0xf, 0) == True
	assert candidate(0b11111111, 4) == True
	assert candidate(0b10000000000000000000000000000110, 1)
	assert candidate(0b00000000, 5) == False
	assert candidate(0b1111111111, 8) == True
	assert candidate(0b1111111111, 3) == True
	assert candidate(0, 1) == False
	assert candidate(7, 2) == True
def test_check():
	check(is_cap_used)
