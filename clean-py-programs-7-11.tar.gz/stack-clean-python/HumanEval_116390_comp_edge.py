def comp_edge(_P, P):  # Used in scan_P_().
    """ 
     Check for end-point relative position and overlap.
     Used in scan_P__().
     """
	### Canonical solution below ###    
    _x0 = _P['x0']
    _xn = _x0 + _P['L']
    x0 = P['x0']
    xn = x0 + P['L']

    if _xn < xn:  # End-point relative position.
        return True, x0 < _xn  # Overlap.
    else:
        return False, _x0 < xn

### Unit tests below ###
def check(candidate):
	assert candidate(dict(x0=0, L=1), dict(x0=0, L=2)) == (True, True)
	assert candidate(dict(x0=1, L=1), dict(x0=1, L=1)) == (False, True)
	assert candidate(dict(x0=100, L=50), dict(x0=150, L=100)) == (True, False)
	assert candidate(dict(x0=1, L=1), dict(x0=3, L=1)) == (True, False)
	assert candidate(dict(x0=2, L=1), dict(x0=1, L=2)) == (False, True)
	assert candidate(
    {'x0': 0, 'L': 10}, {'x0': 2, 'L': 10})
	assert candidate(dict(x0=0, L=1), dict(x0=2, L=1)) == (True, False)
	assert candidate(
    {'x0': 0, 'L': 1},
    {'x0': 2, 'L': 1}
) == (True, False)
	assert candidate(dict(x0=100, L=50), dict(x0=125, L=25)) == (False, True)
	assert candidate(dict(x0=0, L=10), dict(x0=20, L=10)) == (True, False)
	assert candidate(dict(x0=0, L=2), dict(x0=2, L=1)) == (True, False)
	assert candidate(dict(x0=1, L=1), dict(x0=3, L=3)) == (True, False)
	assert candidate(dict(x0=0, L=1), dict(x0=0, L=1)) == (False, True)
	assert candidate(dict(x0=0, L=1), dict(x0=1, L=1)) == (True, False)
	assert candidate(dict(x0=0, L=1), dict(x0=2, L=2)) == (True, False)
	assert candidate(
    {'x0': 100, 'L': 10}, {'x0': 110, 'L': 11}) == (True, False)
	assert candidate(
    {'x0': 0, 'L': 10}, {'x0': 9, 'L': 10}) == (True, True)
	assert candidate(P={'x0': 0, 'L': 3}, _P={'x0': 4, 'L': 4}) == (False, False)
	assert candidate(
    {'x0': 100, 'L': 10}, {'x0': 100, 'L': 11}) == (True, True)
	assert candidate(dict(x0=1, L=1), dict(x0=2, L=1)) == (True, False)
	assert candidate(dict(x0=0, L=1), dict(x0=1, L=2)) == (True, False)
	assert candidate(
    {'x0': 100, 'L': 10}, {'x0': 100, 'L': 10}) == (False, True)
def test_check():
	check(comp_edge)
