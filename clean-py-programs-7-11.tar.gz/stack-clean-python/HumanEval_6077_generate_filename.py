def generate_filename(blob_name: str, message_index: int) -> str:
    """Strip the file type suffix from the blob name, and append message index."""
    ### Canonical solution below ###
    fname = blob_name.split("/")[-1]
    fname, _ = fname.rsplit(".", 1)
    return f"{fname}-{message_index}"


### Unit tests below ###
def check(candidate):
	assert candidate(blob_name="test-123.txt", message_index=100) == "test-123-100"
	assert candidate(
    "my-bucket/my-folder/my-file.json", message_index=1
) == "my-file-1"
	assert candidate(blob_name="hello.txt", message_index=0) == "hello-0"
	assert candidate(blob_name="abc/123.txt", message_index=2) == "123-2"
	assert candidate(blob_name="abc/123.txt", message_index=9) == "123-9"
	assert candidate(
    "2021/10/19/00/38/45/000000000-e2a58800-5561-4590-8f78-900634156804.avro", 10
) == "000000000-e2a58800-5561-4590-8f78-900634156804-10"
	assert candidate(blob_name="test.txt", message_index=10) == "test-10"
	assert candidate(blob_name="file.txt", message_index=1000) == "file-1000"
	assert candidate(
    "gs://my-bucket/my-folder/my-file.json", 10) == "my-file-10"
	assert candidate(blob_name="file.json", message_index=10000) == "file-10000"
	assert candidate(
    "gs://my-bucket/my-object.json", 1234) == "my-object-1234"
	assert candidate(
    "my-bucket/my-file.csv", 3
) == "my-file-3"
	assert candidate(blob_name="test.json", message_index=1) == "test-1"
	assert candidate(blob_name="test.txt", message_index=1000) == "test-1000"
	assert candidate(blob_name="abc/123.txt", message_index=1) == "123-1"
	assert candidate(blob_name="a/b/c.json", message_index=10) == "c-10"
	assert candidate(blob_name="test.json", message_index=100) == "test-100"
	assert candidate(blob_name="test.json", message_index=1000000000000) == "test-1000000000000"
	assert candidate(blob_name="abc/123.txt", message_index=11) == "123-11"
	assert candidate(blob_name="a/b/c.json", message_index=1) == "c-1"
	assert candidate(
    "20180221_233312.jpg", 1234
) == "20180221_233312-1234"
	assert candidate(
    "2021/10/19/00/38/45/000000000-e2a58800-5561-4590-8f78-900634156804.avro", 1
) == "000000000-e2a58800-5561-4590-8f78-900634156804-1"
	assert candidate(blob_name="a/b/c.json", message_index=100) == "c-100"
	assert candidate(blob_name="test.json", message_index=1000000) == "test-1000000"
	assert candidate(blob_name="test.txt", message_index=123) == "test-123"
	assert candidate(blob_name="test.txt", message_index=1) == "test-1"
	assert candidate(blob_name="a/b/c.json", message_index=9) == "c-9"
	assert candidate(blob_name="foo.json", message_index=123) == "foo-123"
	assert candidate(blob_name="file.json", message_index=100000) == "file-100000"
	assert candidate(
    "20180221_233312.jpg", 12345678
) == "20180221_233312-12345678"
	assert candidate(blob_name="hello.txt", message_index=1) == "hello-1"
	assert candidate(blob_name="file.txt", message_index=1) == "file-1"
	assert candidate(blob_name="test.txt", message_index=0) == "test-0"
	assert candidate(
    "gs://my-bucket/path/to/file.json", 1
) == "file-1"
	assert candidate(blob_name="hello.txt", message_index=10) == "hello-10"
	assert candidate(
    "20180221_233312.jpg", 1
) == "20180221_233312-1"
	assert candidate(blob_name="abc/123.txt", message_index=10) == "123-10"
	assert candidate(blob_name="file.json", message_index=1) == "file-1"
	assert candidate(
    "my-bucket/my-file.parquet", 3
) == "my-file-3"
	assert candidate(
    "my-bucket/my-file.json", 3
) == "my-file-3"
	assert candidate(blob_name="file.json", message_index=1000) == "file-1000"
	assert candidate(blob_name="test.txt", message_index=2) == "test-2"
	assert candidate(blob_name="a/b/c.json", message_index=1000) == "c-1000"
	assert candidate(blob_name="test.txt", message_index=100) == "test-100"
	assert candidate(blob_name="foo.bar", message_index=456) == "foo-456"
	assert candidate(blob_name="file.json", message_index=1000000) == "file-1000000"
	assert candidate(blob_name="a/b/c.json", message_index=0) == "c-0"
def test_check():
	check(generate_filename)
