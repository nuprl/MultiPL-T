def replace_all(text, dict):
    """ Replace all using dictionary of find:replace"""
	### Canonical solution below ###    
    for k, v in dict.items():
        text = text.replace(k, v)
    return text

### Unit tests below ###
def check(candidate):
	assert candidate(
    "I think therefore I am", {
        "I am": "you are",
        "I think": "you think"
    }) == "you think therefore you are"
	assert candidate("I am happy", {"I am": "You are"}) == "You are happy"
	assert candidate(
    "the aardvark jumped over the fence",
    {"over": "around", "fence": "gate"}) \
    == "the aardvark jumped around the gate"
	assert candidate(
    "I think therefore I am",
    {"I": "You", "am": "are", "I think": "You think", "I am": "You are", "am therefore": "are therefore", "I therefore": "You therefore", "I think therefore": "You think therefore"}
    ) == "You think therefore You are"
	assert candidate(
    "the aardvark jumped over the fence",
    {
        "aardvark": "zebra",
        "fence": "mountain",
    }
) == "the zebra jumped over the mountain"
	assert candidate(
    "I think therefore I am",
    {"I": "You", "am": "are", "I think": "You think", "I am": "You are", "am therefore": "are therefore", "I therefore": "You therefore"}
    ) == "You think therefore You are"
	assert candidate("I am happy", {"happy": "sad"}) == "I am sad"
	assert candidate(
    "I think therefore I am",
    {"I": "You", "am": "are", "I think": "You think", "I am": "You are"}
    ) == "You think therefore You are"
	assert candidate(
    "Don't touch the {}!",
    {'{}': 'eggplant', 'touch':'scratch'}) == "Don't scratch the eggplant!"
	assert candidate("I think I know what I'm doing", {"I think": "You think", "know": "understand", "I'm doing": "You're doing", "I know": "You know", "I'm": "You're", "I": "You"}) == "You think You understand what You're doing"
	assert candidate(
    "the aardvark jumped over the fence",
    {"over": "around", "fence": "gate", "aardvark": "zebra"}) \
    == "the zebra jumped around the gate"
	assert candidate(
    "I like bananas",
    {"bananas": "apples", "I ": "You "}) == "You like apples"
	assert candidate("I think I know what I'm doing", {"I think": "You think"}) == "You think I know what I'm doing"
	assert candidate("I think I know what I'm doing", {}) == "I think I know what I'm doing"
	assert candidate(
    "I like bananas",
    {"bananas": "apples", "I ": "You ", " ": "_"}) == "You_like_apples"
	assert candidate('hello', {}) == 'hello'
	assert candidate(
    "I think therefore I am",
    {"I": "You", "am": "are", "I think": "You think", "I am": "You are", "am therefore": "are therefore"}
    ) == "You think therefore You are"
	assert candidate(
    "My name is Tom", {"Tom": "Jerry", "name": "Sue"}) == "My Sue is Jerry"
	assert candidate(
    "I think therefore I am",
    {"I": "You", "am": "are", "I think": "You think"}
    ) == "You think therefore You are"
	assert candidate(
    "one two three",
    {
        "one": "ONE",
        "two": "TWO",
        "three": "THREE",
    },
) == "ONE TWO THREE"
	assert candidate(
    "A quick brown fox",
    {"quick": "slow", "brown": "blue", "fox": "hound"}) == "A slow blue hound"
	assert candidate(
    "I like bananas",
    {"bananas": "apples"}) == "I like apples"
	assert candidate(
    "I think therefore I am", {"I am": "You are", "I think": "You think"}) == \
    "You think therefore You are"
def test_check():
	check(replace_all)
