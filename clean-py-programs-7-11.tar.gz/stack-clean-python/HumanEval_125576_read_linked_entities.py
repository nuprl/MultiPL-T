def read_linked_entities(data):
    """ Obtain lists of liken entities (IDs and names) from dictionary
     Args:
     data (json): dictionary with linked pages.
     
     Returns:
     (list): List of liked entityIDs
     (list): List of liked entity names
     """
	### Canonical solution below ###    
    related_entities = []
    related_names = []
    if data == {}:
        return related_entities, related_names
    for c in data.get("results").get("bindings"):
        url = c.get("valUrl").get("value")
        related_entities.append(url.replace("http://www.wikidata.org/entity/", ""))
        name = c.get("valLabel").get("value")
        related_names.append(name)
    return related_entities, related_names

### Unit tests below ###
def check(candidate):
	assert candidate({"results": {"bindings": []}}) == ([], [])
	assert candidate(
    {
        "results": {
            "bindings": [
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q43229"
                    },
                    "valLabel": {
                        "xml:lang": "en",
                        "type": "literal",
                        "value": "Earl of March"
                    }
                },
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q11073"
                    },
                    "valLabel": {
                        "xml:lang": "en",
                        "type": "literal",
                        "value": "<NAME>"
                    }
                }
            ]
        }
    }
) == (["Q43229", "Q11073"], ["Earl of March", "<NAME>"])
	assert candidate(
    {
        "results": {
            "bindings": [
                {"valUrl": {"type": "uri", "value": "http://www.wikidata.org/entity/Q1234"},
                 "valLabel": {"type": "literal", "value": "Some entity"}},
                {"valUrl": {"type": "uri", "value": "http://www.wikidata.org/entity/Q5678"},
                 "valLabel": {"type": "literal", "value": "Another entity"}}
            ]
        }
    }
) == (["Q1234", "Q5678"], ["Some entity", "Another entity"])
	assert candidate(
    {
        "results": {
            "bindings": [
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q1234567"
                    },
                    "valLabel": {
                        "xml:lang": "en",
                        "type": "literal",
                        "value": "related entity name"
                    }
                },
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q1234568"
                    },
                    "valLabel": {
                        "xml:lang": "en",
                        "type": "literal",
                        "value": "related entity name 2"
                    }
                }
            ]
        }
    }
) == ([
    "Q1234567",
    "Q1234568"], [
    "related entity name",
    "related entity name 2"])
	assert candidate(
    {"results": {"bindings": [{"valUrl": {"value": "http://www.wikidata.org/entity/Q3599"}, "valLabel": {"value": "London"}}]}}) == ([
         'Q3599'], ['London'])
	assert candidate({"results": {"bindings": [{"valUrl": {"value": "http://www.wikidata.org/entity/Q23456789"}, "valLabel": {"value": "some name"}}]}}) == (["Q23456789"], ["some name"])
	assert candidate(
    {
        "results": {
            "bindings": [
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q1234567"
                    },
                    "valLabel": {
                        "xml:lang": "en",
                        "type": "literal",
                        "value": "related entity name"
                    }
                }
            ]
        }
    }
) == ([
    "Q1234567"], ["related entity name"])
	assert candidate({}) == ([], [])
	assert candidate(
    {
        "results": {
            "bindings": []
        }
    }
) == ([], [])
	assert candidate(
    {
        "results": {
            "bindings": [
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q148101",
                    },
                    "valLabel": {"type": "literal", "value": "Dutch"},
                },
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q148102",
                    },
                    "valLabel": {"type": "literal", "value": "French"},
                },
            ]
        }
    }
) == (
    ["Q148101", "Q148102"],
    ["Dutch", "French"],
)
	assert candidate(
    {
        "results": {
            "bindings": [
                {
                    "valUrl": {
                        "type": "uri",
                        "value": "http://www.wikidata.org/entity/Q148101",
                    },
                    "valLabel": {"type": "literal", "value": "Dutch"},
                }
            ]
        }
    }
) == (["Q148101"], ["Dutch"])
	assert candidate(
    {'results': {
        'bindings': [
            {
                'valUrl': {
                    'type': 'uri',
                    'value': 'http://www.wikidata.org/entity/Q693686'
                },
                'valLabel': {
                    'xml:lang': 'en',
                    'type': 'literal',
                    'value': 'London'
                }
            },
            {
                'valUrl': {
                    'type': 'uri',
                    'value': 'http://www.wikidata.org/entity/Q122196'
                },
                'valLabel': {
                    'xml:lang': 'en',
                    'type': 'literal',
                    'value': 'England'
                }
            }
        ]
    }
    }
) == (
    ['Q693686', 'Q122196'],
    ['London', 'England']
)
def test_check():
	check(read_linked_entities)
