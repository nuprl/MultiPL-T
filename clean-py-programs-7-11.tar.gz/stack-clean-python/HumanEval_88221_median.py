def median(values):
    """ Calculates the median of the values.
     
     :param values: The values.
     :return: The median.
     """
	### Canonical solution below ###    
    values = sorted(values)

    if len(values) % 2:
        return values[len(values) // 2]
    else:
        return (values[len(values) // 2 - 1] + values[len(values) // 2]) / 2

### Unit tests below ###
def check(candidate):
	assert candidate(range(10)) == 4.5
	assert candidate(list(range(1, 6)) + [6, 7]) == 4
	assert candidate(list(range(1000))) == 499.5
	assert candidate([1, 2]) == 1.5
	assert candidate([1, 2, 3, 4, 5]) == 3
	assert candidate(range(100)) == 49.5
	assert candidate([1, 1, 3]) == 1
	assert candidate(range(1, 1000)) == 500
	assert candidate([1, 1, 1, 3]) == 1
	assert candidate(list(range(11))) == 5.0
	assert candidate(list(range(1, 6)) + [6, 7, 8, 9]) == 5
	assert candidate(sorted([1, 2, 3])) == 2
	assert candidate([1, 1, 2, 2, 3, 3, 4, 4]) == 2.5
	assert candidate([1, 3, 5, 7, 9, 11]) == 6
	assert candidate(range(1, 10)) == 5
	assert candidate(sorted([1, 2, 3, 4])) == 2.5
	assert candidate(range(5)) == 2
	assert candidate([1, 2, 3]) == 2
	assert candidate(list(range(1, 11))) == 5.5
	assert candidate(list(range(1, 1001))) == 500.5
	assert candidate([1, 3, 5, 7, 9]) == 5
	assert candidate(list(range(1, 6))) == 3
	assert candidate(list(range(1, 12))) == 6
	assert candidate(range(11)) == 5
	assert candidate(range(1, 102)) == 51
	assert candidate(range(1, 6)) == 3
	assert candidate(range(1, 100)) == 50
	assert candidate(sorted([1, 2, 3, 4, 5, 6])) == 3.5
	assert candidate([1, 2, 3, 4]) == 2.5
	assert candidate(range(1, 10001)) == 5000.5
	assert candidate(list(range(1, 100))) == 50
	assert candidate([1, 1, 1, 1, 1, 3]) == 1
	assert candidate([1, 2, 3, 4, 5, 6]) == 3.5
	assert candidate(list(range(1, 6)) + [6, 7, 8]) == 4.5
	assert candidate(list(range(10))) == 4.5
	assert candidate(sorted([1, 2, 3, 4, 5])) == 3
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8]) == 4.5
	assert candidate(list(range(100))) == 49.5
	assert candidate(range(1, 101)) == 50.5
	assert candidate([1]) == 1
	assert candidate([1, 1, 2, 2, 3, 3]) == 2
	assert candidate(range(1, 13)) == 6.5
	assert candidate(list(range(1, 13))) == 6.5
	assert candidate(range(1, 11)) == 5.5
	assert candidate(list(range(10000))) == 4999.5
	assert candidate(range(1, 12)) == 6
	assert candidate(range(1, 1001)) == 500.5
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9]) == 5
	assert candidate([2, 4, 6]) == 4
	assert candidate([1, 2, 3, 4, 5, 6, 7]) == 4
def test_check():
	check(median)
