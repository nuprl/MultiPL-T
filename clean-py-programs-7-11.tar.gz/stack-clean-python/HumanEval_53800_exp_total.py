def exp_total(lvl, exp):
    """ \
     returns the ammount of xp you have as value from lvl"""
	### Canonical solution below ###    
    return 5 * lvl * (lvl + 7) * (2 * lvl + 13) // 6 + exp

### Unit tests below ###
def check(candidate):
	assert candidate(21, 100)
	assert candidate(1, 5) == 105
	assert candidate(0, 50) == 50
	assert candidate(0, 0) == 0
def test_check():
	check(exp_total)
