def stringify(value):
    """ Utility for stringifying an event.
     """
	### Canonical solution below ###    
    string = str(value)
    if len(string) > 1:
        string = "(%s)" % string

    return string

### Unit tests below ###
def check(candidate):
	assert candidate(1.0) == "(1.0)"
	assert candidate("1") == "1"
	assert candidate(0) == "0"
	assert candidate('a') == 'a'
	assert candidate(1) == '1'
	assert candidate(1) == "1"
	assert candidate("abc") == "(abc)"
	assert candidate(1.0j) == "(1j)"
	assert candidate("foo") == "(foo)"
	assert candidate((1, 2)) == "((1, 2))"
	assert candidate("a") == "a"
	assert candidate({'a': 1, 'b': 2}) == "({'a': 1, 'b': 2})"
def test_check():
	check(stringify)
