def tdiff(seconds):
    """
    """
    ### Canonical solution below ###
    t = seconds
    days = int(t / (24 * 60 * 60))
    t -= (days * 24 * 60 * 60)
    hours = int(t / (60 * 60))
    t -= (hours * 60 * 60)
    minutes = int(t / 60)
    t -= (minutes * 60)

    s = '%ds' % (int(t),)
    if minutes >= 1: s = '%dm %s' % (minutes, s)
    if hours >= 1: s = '%dh %s' % (hours, s)
    if days >= 1: s = '%dd %s' % (days, s)
    return s


### Unit tests below ###
def check(candidate):
	assert candidate(86465) == '1d 1m 5s'
	assert candidate(86400+3600+60) == '1d 1h 1m 0s'
	assert candidate(86463) == '1d 1m 3s'
	assert candidate(60 * 60 * 24 + 60 * 60 + 60) == '1d 1h 1m 0s'
	assert candidate(3599) == '59m 59s'
	assert candidate(61) == '1m 1s'
	assert candidate(3663) == '1h 1m 3s'
	assert candidate(60) == '1m 0s'
	assert candidate(0.1) == '0s'
	assert candidate(5) == '5s'
	assert candidate(86462) == '1d 1m 2s'
	assert candidate(121) == '2m 1s'
	assert candidate(86464) == '1d 1m 4s'
	assert candidate(172799) == '1d 23h 59m 59s'
	assert candidate(86400+3600+61) == '1d 1h 1m 1s'
	assert candidate(119) == '1m 59s'
	assert candidate(86466) == '1d 1m 6s'
	assert candidate(3661) == '1h 1m 1s'
	assert candidate(122) == '2m 2s'
	assert candidate(120) == '2m 0s'
	assert candidate(59) == '59s'
	assert candidate(86399) == '23h 59m 59s'
	assert candidate(60 * 60 + 60) == '1h 1m 0s'
	assert candidate(30) == '30s'
	assert candidate(0) == '0s'
	assert candidate(10) == '10s'
	assert candidate(3660) == '1h 1m 0s'
	assert candidate(7261) == '2h 1m 1s'
	assert candidate(3662) == '1h 1m 2s'
	assert candidate(7262) == '2h 1m 2s'
	assert candidate(1) == '1s'
	assert candidate(86401) == '1d 1s'
	assert candidate(62) == '1m 2s'
	assert candidate(86461) == '1d 1m 1s'
	assert candidate(61*60) == '1h 1m 0s'
	assert candidate(172861)
	assert candidate(3600*24+60*60+60+1) == '1d 1h 1m 1s'
	assert candidate(0.9) == '0s'
	assert candidate(3600 * 24 + 61) == '1d 1m 1s'
def test_check():
	check(tdiff)
