def rotated_array_search(input_list, number):
    """ Find the index of a given number in a sorted but rotated list.
     
     Uses a modified binary search.
     
     Args:
     input_list: A list of ints representing the list to search in
     number: An int representing the value to search for
     
     Returns:
     index: An int representing the index of the number in the list, -1 if
     the number is not found
     """
	### Canonical solution below ###    
    if len(input_list) == 0:
        return -1

    guess = len(input_list) // 2

    if (input_list[0] <= number < input_list[guess]) or (
        number > input_list[0] > input_list[guess]
    ):
        guess = rotated_array_search(input_list[:guess], number)
    elif input_list[guess] != number:
        added = rotated_array_search(input_list[guess + 1 :], number)
        if added == -1:
            return -1
        guess += added + 1

    return guess

### Unit tests below ###
def check(candidate):
	assert candidate([1, 3, 5, 7], 1) == 0
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find the index of an element in a list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find the first index of number 6"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find an item in the middle of the list"
	assert candidate(
    [1], 1
) == 0, "Edge Case: List with one element"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4],
    8
) == 2
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the index of an element in a list"
	assert candidate(
    [10], 10
) == 0, "Edge case: The list has only one element"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Finding the index of the number in the right half of the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4],
    1,
) == 3
	assert candidate(
    [], 10
) == -1, "Edge case: Empty list."
	assert candidate(
    [1, 2, 3, 4], 2
) == 1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Value not present in the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Didn't find 1 at the end of the list"
	assert candidate([5], 5) == 0
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find the first index of number 6."
	assert candidate(
    [1],
    1
) == 0
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic case 2"
	assert candidate(
    [1, 2, 3, 4, 5], 2
) == 1
	assert candidate(
    [], 10
) == -1, "Empty list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Found first element"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4],
    10,
) == -1
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Finding the start of a rotated list"
	assert candidate([6, 7, 8, 1, 2, 3, 4], 100) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: The target is not in the list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Finding an item in the left half of a list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Didn't find 1 in the middle of the list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find the index of the number 6"
	assert candidate(
    [1, 1, 1, 1, 1], 2
) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Not found 1"
	assert candidate([], 5) == -1
	assert candidate(
    [6], 6
) == 0, "List with one element"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find the first index of an item in a rotated list."
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find the last index of number 1."
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4],
    6,
) == 0
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the index of an element in a list"
	assert candidate([6, 7, 8, 1, 2, 3, 4], 1) == 3
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Multiple Rotations: Find the index of an element in a list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the number in the middle of the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the middle index of number 1"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4],
    1
) == 3
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find the index of an element in a list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic case 3"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4],
    6
) == 0
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic case 1"
	assert candidate(
    [1], 1
) == 0, "Found a value from a list of length 1"
	assert candidate([5, 6, 7, 8, 9, 1, 2, 3, 4], 5) == 0
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the middle index of number 8."
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Didn't find 6 at the beginning of the list"
	assert candidate(
    [1, 2, 3, 4, 5], 1
) == 0
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the number in the middle of the list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Found an element in the middle of the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Not found"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0
	assert candidate(
    [11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 1, 2, 3, 4, 5], 2
) == 11, "Rotated: Find in the middle"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 4
) == 6, "Basic: Find the middle index of the last item in a rotated list."
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find first index"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the first item of the list"
	assert candidate([6, 7, 8, 1, 2, 3, 4], 8) == 2
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Finding the end of a list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Finding the index of the number in the middle of the list"
	assert candidate([1, 3, 5, 7], 5) == 2
	assert candidate(
    [1, 2, 3, 4], 4
) == 3
	assert candidate(
    [1, 2, 3, 4], 5
) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the middle index of number 8"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Found the only element in the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Find the index of a number not in the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: 10 not in list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the middle index of number 1."
	assert candidate([7, 3, 5, 1], 5) == 2
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 10
) == 4, "Basic: Find the number at the end of the list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find the last index of number 1"
	assert candidate(
    [1, 2, 3, 4, 5], 5
) == 4
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4],
    10
) == -1
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 10
) == 9
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find first item in list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find an item at the end of the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Element not present in the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the middle index of the first item in a rotated list."
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Item is not in the list."
	assert candidate(
    [], 1
) == -1, "Basic: Empty list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: It returns -1 when the number doesn't exist"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: It works with duplicates"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find in the middle"
	assert candidate(
    [1], 10
) == -1, "Edge case: Single element list."
	assert candidate(
    [], 1
) == -1, "Edge case: Empty list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find the last index of an item in a rotated list."
	assert candidate(
    [6, 7, 8], 6
) == 0, "List with three elements"
	assert candidate(
    [], 1
) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic case 4"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Finding an item in the right half of a list"
	assert candidate(
    [1], 1
) == 0, "Edge Case: List with only one element"
	assert candidate(
    [1, 2, 3, 4], 3
) == 2
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Found a value from the wrong list"
	assert candidate(
    [], 10
) == -1
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4],
    1
) == 5
	assert candidate(
    [1], 1
) == 0, "Edge Case: List with only one item."
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find the index of a number in a rotated list."
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Finding the first index of the number"
	assert candidate(
    [], 10
) == -1, "Edge case: The list is empty"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Finding the last item of a list"
	assert candidate([6, 7, 8, 10, 1, 2, 3, 4], 11) == -1
	assert candidate(
    [], 10
) == -1, "Edge Case: Empty list"
	assert candidate([6], 6) == 0
	assert candidate(
    [], 10
) == -1, "Edge Case: Empty list."
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Found an element at the end of the list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Finding the start of a list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Not finding an element in a list"
	assert candidate(
    [4, 3, 2, 1], 1
) == 3
	assert candidate([], 6) == -1
	assert candidate([6, 7, 8, 1, 2, 3, 4], 11) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Finding the end of a list"
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 10
) == 9, "Rotated: Find first item in list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Finding the midpoint of a rotated list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find the index of a number in a rotated list."
	assert candidate(
    [1, 2, 3, 4], 1
) == 0
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1
) == 0
	assert candidate([6, 7, 8, 10, 1, 2, 3, 4], 1) == 4
	assert candidate([1, 3, 5, 7], 3) == 1
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 5
) == 4
	assert candidate(
    [],
    10,
) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the middle index of an item in a rotated list."
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Didn't find 8 in the middle of the list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4],
    1,
) == 5
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the index of a number in a rotated list."
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Find the index of a number in a rotated list."
	assert candidate(
    [2, 1], 1
) == 1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the index of the number 1"
	assert candidate([6, 7, 8, 10, 1, 2, 3, 4], 10) == 3
	assert candidate([4, 5, 6, 7, 8, 1, 2, 3], 1) == 5
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Number not in the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Value not in the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the number at the end of the list"
	assert candidate(
    [], 1
) == -1, "Found a value from an empty list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Multiple Rotations: Find the index of an element in a list"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Finding a value in the middle of a list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find the index of a number in a rotated list."
	assert candidate([6, 7, 8, 9, 10, 1, 2, 3, 4], 1) == 5
	assert candidate(
    [],
    1
) == -1
	assert candidate(
    [1], 1
) == 0, "Edge case: List with one element"
	assert candidate(
    [], 1
) == -1, "Edge Case: Empty list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: Value is not contained in the list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4],
    8,
) == 2
	assert candidate([1, 3, 5, 7], 7) == 3
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 10
) == -1, "Basic: 10 not in list."
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Finding the last index of the number"
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find the index of the number 1"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the index of the number 8"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 1
) == 3, "Basic: Find in the right half"
	assert candidate(
    [1], 1
) == 0
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Find the number in the middle of the list"
	assert candidate(
    [6, 7], 6
) == 0, "List with two elements"
	assert candidate([6, 7, 8, 9, 10, 1, 2, 3, 4], 6) == 0
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 1
) == 5, "Basic: Finding the end of a rotated list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 12
) == -1, "Not found 2"
	assert candidate([7, 3, 5, 1], 1) == 3
	assert candidate(
    [1, 2], 1
) == 0
	assert candidate(
    [1, 2], 2
) == 1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Finding the midpoint of a rotated list"
	assert candidate([5], 7) == -1
	assert candidate(
    [6, 7, 8, 9, 10, 1, 2, 3, 4], 6
) == 0, "Basic: Find the number at the beginning of the list"
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 2
) == 1
	assert candidate([6, 7, 8, 1, 2, 3, 4], 10) == -1
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Finding the first item of a list"
	assert candidate(
    [6, 7, 8, 1, 2, 3, 4], 8
) == 2, "Basic: Find the last index"
def test_check():
	check(rotated_array_search)
