def fix_taxonomy_from_file(data=dict(), names=list()):
    """
    Fixes a dictionary with default keys

    Args:
        src (str): path to the data structure file
    """
    ### Canonical solution below ###

    for i, item in enumerate(names, 1):
        key = '{:02}00-nr'.format(i)
        if key not in data:
            data[key] = {'nameSeq' : i, 'txID' : key}
        key = '{:02}99-na'.format(i)
        if key not in data:
            data[key] = {'nameSeq' : i, 'txID' : key}
    return data


### Unit tests below ###
def check(candidate):
	assert candidate({'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}}, ['12345']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}}
	assert candidate(data={}, names=['A', 'B']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate(data={'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}}, names=['a', 'b']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}, '0200-nr' : {'nameSeq' : 2, 'txID' : '0200-nr'}, '0299-na' : {'nameSeq' : 2, 'txID' : '0299-na'}}
	assert candidate(data=dict(), names=['a', 'b']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate(dict(), ['a']) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'},
}
	assert candidate(data={}, names=['a', 'b']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate(dict(), ['a', 'b', 'c']) == \
    {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
     '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'},
     '0300-nr': {'nameSeq': 3, 'txID': '0300-nr'},
     '0199-na': {'nameSeq': 1, 'txID': '0199-na'},
     '0299-na': {'nameSeq': 2, 'txID': '0299-na'},
     '0399-na': {'nameSeq': 3, 'txID': '0399-na'}}
	assert candidate(data={}, names=['a', 'b']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}, '0200-nr' : {'nameSeq' : 2, 'txID' : '0200-nr'}, '0299-na' : {'nameSeq' : 2, 'txID' : '0299-na'}}
	assert candidate(data=dict(), names=['a']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
	assert candidate(data={}, names=[]) == {}
	assert candidate(data=dict(), names=[]) == {}
	assert candidate({'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}, ['a', 'b']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate(dict(), ['A', 'B', 'C', 'D']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}, '0300-nr': {'nameSeq': 3, 'txID': '0300-nr'}, '0399-na': {'nameSeq': 3, 'txID': '0399-na'}, '0400-nr': {'nameSeq': 4, 'txID': '0400-nr'}, '0499-na': {'nameSeq': 4, 'txID': '0499-na'}}
	assert candidate(dict(), []) == {}
	assert candidate(dict(), ['a']) == {
    '0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'},
    '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}
}
	assert candidate(dict(), ['a', 'b']) == {
    '0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'},
    '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'},
    '0200-nr' : {'nameSeq' : 2, 'txID' : '0200-nr'},
    '0299-na' : {'nameSeq' : 2, 'txID' : '0299-na'}
}
	assert candidate(dict(), ['a', 'b', 'c', 'd']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}, '0200-nr' : {'nameSeq' : 2, 'txID' : '0200-nr'}, '0299-na' : {'nameSeq' : 2, 'txID' : '0299-na'}, '0300-nr' : {'nameSeq' : 3, 'txID' : '0300-nr'}, '0399-na' : {'nameSeq' : 3, 'txID' : '0399-na'}, '0400-nr' : {'nameSeq' : 4, 'txID' : '0400-nr'}, '0499-na' : {'nameSeq' : 4, 'txID' : '0499-na'}}
	assert candidate(dict(), ['a']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
	assert candidate({'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}}, ['Bacteria']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}}
	assert candidate({'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}}, ['1', '2']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate(data={}, names=[1]) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
	assert candidate(dict(), ['1']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
	assert candidate(dict(), list()) == dict(), 'test candidate'
	assert candidate({'0200-nr': {'nameSeq': 2, 'txID': '0200-nr'},
                                '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
                                '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}, ['A'])
	assert candidate(dict(), ['a', 'b', 'c']) == \
    {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
     '0199-na': {'nameSeq': 1, 'txID': '0199-na'},
     '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'},
     '0299-na': {'nameSeq': 2, 'txID': '0299-na'},
     '0300-nr': {'nameSeq': 3, 'txID': '0300-nr'},
     '0399-na': {'nameSeq': 3, 'txID': '0399-na'}}
	assert candidate(dict(), ['a', 'b', 'c']) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'},
    '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'},
    '0299-na': {'nameSeq': 2, 'txID': '0299-na'},
    '0300-nr': {'nameSeq': 3, 'txID': '0300-nr'},
    '0399-na': {'nameSeq': 3, 'txID': '0399-na'},
}
	assert candidate({'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}}, ['Bacteria']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}}
	assert candidate(dict(), list()) == dict()
	assert candidate({'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}}, ['A']) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
	assert candidate(data={}, names=['a', 'b', 'c']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}, '0300-nr': {'nameSeq': 3, 'txID': '0300-nr'}, '0399-na': {'nameSeq': 3, 'txID': '0399-na'}}
	assert candidate(dict(), ['a', 'b']) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'},
    '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'},
    '0299-na': {'nameSeq': 2, 'txID': '0299-na'}
}
	assert candidate(dict(), ['a', 'b']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate(dict(), ['a', 'b']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}, '0200-nr' : {'nameSeq' : 2, 'txID' : '0200-nr'}, '0299-na' : {'nameSeq' : 2, 'txID' : '0299-na'}}
	assert candidate({'100-na': {'nameSeq': 1, 'txID': '100-na'}}, list()) == \
    {'100-na': {'nameSeq': 1, 'txID': '100-na'}}
	assert candidate(data={}, names=['A', 'B', 'C']) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'},
    '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'},
    '0299-na': {'nameSeq': 2, 'txID': '0299-na'},
    '0300-nr': {'nameSeq': 3, 'txID': '0300-nr'},
    '0399-na': {'nameSeq': 3, 'txID': '0399-na'},
}
	assert candidate(dict(), ['1', '2']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}, '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate(data=dict(), names=['a', 'b', 'c']) == {
    '0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'},
    '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'},
    '0200-nr' : {'nameSeq' : 2, 'txID' : '0200-nr'},
    '0299-na' : {'nameSeq' : 2, 'txID' : '0299-na'},
    '0300-nr' : {'nameSeq' : 3, 'txID' : '0300-nr'},
    '0399-na' : {'nameSeq' : 3, 'txID' : '0399-na'}
    }
	assert candidate(dict(), ['A']) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
	assert candidate(data={}, names=['a']) == {'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'}, '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
	assert candidate(dict(), ['A', 'B']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}, '0200-nr' : {'nameSeq' : 2, 'txID' : '0200-nr'}, '0299-na' : {'nameSeq' : 2, 'txID' : '0299-na'}}
	assert candidate(dict(), ['12345']) == {'0100-nr' : {'nameSeq' : 1, 'txID' : '0100-nr'}, '0199-na' : {'nameSeq' : 1, 'txID' : '0199-na'}}
	assert candidate(data={}, names=[1, 2]) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'},
    '0200-nr': {'nameSeq': 2, 'txID': '0200-nr'},
    '0299-na': {'nameSeq': 2, 'txID': '0299-na'}}
	assert candidate({'0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
                                '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}, ['A']) == {
    '0100-nr': {'nameSeq': 1, 'txID': '0100-nr'},
    '0199-na': {'nameSeq': 1, 'txID': '0199-na'}}
def test_check():
	check(fix_taxonomy_from_file)
