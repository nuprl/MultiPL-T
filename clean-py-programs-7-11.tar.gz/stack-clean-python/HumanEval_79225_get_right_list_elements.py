def get_right_list_elements(result):
    """Some of the results are empty - therefore, the try-except.
    Others are lists with more than one element and only specific
    elements are relevant.

    Args:
        result (dict of lists): result of the xpath elements.

    Returns:
        dict of strs
    """
    ### Canonical solution below ###

    for key in ["title", "ort", "merkmale", "weitere_eigenschaften", "beschreibung"]:
        try:
            result[key] = result[key][0]
        except:
            pass
    for key in ["preis", "anzahl_raeume", "wohnflaeche", "grundstuecksflaeche"]:
        try:
            result[key] = result[key][1]
        except:
            pass

    return result


### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        "title": ["title1", "title2"],
        "ort": ["ort1", "ort2"],
        "merkmale": ["merkmale1", "merkmale2"],
        "weitere_eigenschaften": ["weitere_eigenschaften1", "weitere_eigenschaften2"],
        "beschreibung": ["beschreibung1", "beschreibung2"],
        "preis": ["preis1", "preis2"],
        "anzahl_raeume": ["anzahl_raeume1", "anzahl_raeume2"],
        "wohnflaeche": ["wohnflaeche1", "wohnflaeche2"],
        "grundstuecksflaeche": ["grundstuecksflaeche1", "grundstuecksflaeche2"],
    }
) == {
    "title": "title1",
    "ort": "ort1",
    "merkmale": "merkmale1",
    "weitere_eigenschaften": "weitere_eigenschaften1",
    "beschreibung": "beschreibung1",
    "preis": "preis2",
    "anzahl_raeume": "anzahl_raeume2",
    "wohnflaeche": "wohnflaeche2",
    "grundstuecksflaeche": "grundstuecksflaeche2",
}
	assert candidate({"preis": ["a", "b", "c"]}) == {"preis": "b"}
	assert candidate({"title": ["title", "title"]}) == {"title": "title"}
	assert candidate(
    {"title": ["test"], "ort": ["test"], "merkmale": ["test"], "weitere_eigenschaften": ["test"], "beschreibung": ["test"], "preis": ["test", "test"], "anzahl_raeume": ["test", "test"], "wohnflaeche": ["test", "test"], "grundstuecksflaeche": ["test", "test"]}
) == {"title": "test", "ort": "test", "merkmale": "test", "weitere_eigenschaften": "test", "beschreibung": "test", "preis": "test", "anzahl_raeume": "test", "wohnflaeche": "test", "grundstuecksflaeche": "test"}
	assert candidate(dict(title=['a'])) == dict(title='a')
	assert candidate({"title": ["title"]}) == {"title": "title"}
	assert candidate({"title": ["title1"], "ort": ["ort1"]}) == {
    "title": "title1",
    "ort": "ort1",
}
	assert candidate(
    {"title": ["title1", "title2"], "ort": ["ort1", "ort2"],
     "merkmale": ["merkmale1", "merkmale2"],
     "weitere_eigenschaften": ["weitere_eigenschaften1", "weitere_eigenschaften2"],
     "beschreibung": ["beschreibung1", "beschreibung2"],
     "preis": ["preis1", "preis2"], "anzahl_raeume": ["anzahl_raeume1", "anzahl_raeume2"],
     "wohnflaeche": ["wohnflaeche1", "wohnflaeche2"],
     "grundstuecksflaeche": ["grundstuecksflaeche1", "grundstuecksflaeche2"]}
) == {"title": "title1", "ort": "ort1", "merkmale": "merkmale1", "weitere_eigenschaften": "weitere_eigenschaften1",
      "beschreibung": "beschreibung1", "preis": "preis2", "anzahl_raeume": "anzahl_raeume2",
      "wohnflaeche": "wohnflaeche2", "grundstuecksflaeche": "grundstuecksflaeche2"}
	assert candidate(
    {"title": ["Title"], "ort": ["Ort"], "merkmale": ["Merkmale"], "weitere_eigenschaften": ["Weitere Eigenschaften"], "beschreibung": ["Beschreibung"], "preis": ["Preis", "Preis"], "anzahl_raeume": ["Anzahl Räume", "Anzahl Räume"], "wohnflaeche": ["Wohnfläche", "Wohnfläche"], "grundstuecksflaeche": ["Grundstückfläche", "Grundstückfläche"]}
) == {"title": "Title", "ort": "Ort", "merkmale": "Merkmale", "weitere_eigenschaften": "Weitere Eigenschaften", "beschreibung": "Beschreibung", "preis": "Preis", "anzahl_raeume": "Anzahl Räume", "wohnflaeche": "Wohnfläche", "grundstuecksflaeche": "Grundstückfläche"}
	assert candidate(
    {"title": ["test"], "ort": ["test"], "merkmale": ["test"], "weitere_eigenschaften": ["test"],
     "beschreibung": ["test"], "preis": ["test", "test"], "anzahl_raeume": ["test", "test"],
     "wohnflaeche": ["test", "test"], "grundstuecksflaeche": ["test", "test"]}) == {
        "title": "test", "ort": "test", "merkmale": "test", "weitere_eigenschaften": "test",
        "beschreibung": "test", "preis": "test", "anzahl_raeume": "test",
        "wohnflaeche": "test", "grundstuecksflaeche": "test"}
	assert candidate(dict(title='a', ort='b', merkmale='c', weitere_eigenschaften='d', beschreibung='e', preis='f', anzahl_raeume='g', wohnflaeche='h', grundstuecksflaeche='i')) == dict(title='a', ort='b', merkmale='c', weitere_eigenschaften='d', beschreibung='e', preis='f', anzahl_raeume='g', wohnflaeche='h', grundstuecksflaeche='i')
	assert candidate({"beschreibung": ["a", "b", "c"]}) == {"beschreibung": "a"}
	assert candidate(
    {"title": ["title1"], "ort": ["ort1"], "merkmale": ["merkmale1"], "weitere_eigenschaften": ["weitere_eigenschaften1"], "beschreibung": ["beschreibung1"], "preis": ["preis1", "preis2"], "anzahl_raeume": ["anzahl_raeume1", "anzahl_raeume2"], "wohnflaeche": ["wohnflaeche1", "wohnflaeche2"], "grundstuecksflaeche": ["grundstuecksflaeche1", "grundstuecksflaeche2"]}
    ) == {"title": "title1", "ort": "ort1", "merkmale": "merkmale1", "weitere_eigenschaften": "weitere_eigenschaften1", "beschreibung": "beschreibung1", "preis": "preis2", "anzahl_raeume": "anzahl_raeume2", "wohnflaeche": "wohnflaeche2", "grundstuecksflaeche": "grundstuecksflaeche2"}
	assert candidate({"preis": ["a", "b"]}) == {"preis": "b"}
	assert candidate(dict(title=['a', 'b'])) == dict(title='a')
	assert candidate(
    {"title": ["title1", "title2"], "ort": ["ort1", "ort2"], "merkmale": ["merkmale1", "merkmale2"],
     "weitere_eigenschaften": ["weitere_eigenschaften1", "weitere_eigenschaften2"],
     "beschreibung": ["beschreibung1", "beschreibung2"], "preis": ["preis1", "preis2"],
     "anzahl_raeume": ["anzahl_raeume1", "anzahl_raeume2"],
     "wohnflaeche": ["wohnflaeche1", "wohnflaeche2"],
     "grundstuecksflaeche": ["grundstuecksflaeche1", "grundstuecksflaeche2"]}) == {
        "title": "title1", "ort": "ort1", "merkmale": "merkmale1",
        "weitere_eigenschaften": "weitere_eigenschaften1", "beschreibung": "beschreibung1",
        "preis": "preis2", "anzahl_raeume": "anzahl_raeume2",
        "wohnflaeche": "wohnflaeche2", "grundstuecksflaeche": "grundstuecksflaeche2"}
	assert candidate({"title": ["a", "b"]}) == {"title": "a"}
	assert candidate(dict(title='a')) == dict(title='a')
	assert candidate(dict(title=['a', 'b', 'c'])) == dict(title='a')
	assert candidate(dict(title='a', ort='b', merkmale='c', weitere_eigenschaften='d', beschreibung='e')) == dict(title='a', ort='b', merkmale='c', weitere_eigenschaften='d', beschreibung='e')
	assert candidate(dict()) == dict()
	assert candidate({"beschreibung": ["a", "b"]}) == {"beschreibung": "a"}
	assert candidate({"title": ["a", "b", "c"]}) == {"title": "a"}
	assert candidate(
    {"title": ["title1", "title2"],
     "ort": ["ort1", "ort2"],
     "merkmale": ["merkmale1", "merkmale2"],
     "weitere_eigenschaften": ["weitere_eigenschaften1", "weitere_eigenschaften2"],
     "beschreibung": ["beschreibung1", "beschreibung2"],
     "preis": ["preis1", "preis2"],
     "anzahl_raeume": ["anzahl_raeume1", "anzahl_raeume2"],
     "wohnflaeche": ["wohnflaeche1", "wohnflaeche2"],
     "grundstuecksflaeche": ["grundstuecksflaeche1", "grundstuecksflaeche2"]}
    ) == {"title": "title1",
          "ort": "ort1",
          "merkmale": "merkmale1",
          "weitere_eigenschaften": "weitere_eigenschaften1",
          "beschreibung": "beschreibung1",
          "preis": "preis2",
          "anzahl_raeume": "anzahl_raeume2",
          "wohnflaeche": "wohnflaeche2",
          "grundstuecksflaeche": "grundstuecksflaeche2"}
	assert candidate(
    {"title": ["Title"], "ort": ["Ort"], "merkmale": ["Merkmale"], "weitere_eigenschaften": ["Weitere Eigenschaften"],
     "beschreibung": ["Beschreibung"], "preis": ["Preis", "Preis"], "anzahl_raeume": ["Anzahl Räume", "Anzahl Räume"],
     "wohnflaeche": ["Wohnfläche", "Wohnfläche"], "grundstuecksflaeche": ["Grundstückfläche", "Grundstückfläche"]}) == \
       {"title": "Title", "ort": "Ort", "merkmale": "Merkmale", "weitere_eigenschaften": "Weitere Eigenschaften",
        "beschreibung": "Beschreibung", "preis": "Preis", "anzahl_raeume": "Anzahl Räume", "wohnflaeche": "Wohnfläche",
        "grundstuecksflaeche": "Grundstückfläche"}
	assert candidate(dict(title=['a', 'b', 'c'], ort=['d', 'e'], merkmale=['f', 'g'], weitere_eigenschaften=['h', 'i'], beschreibung=['j', 'k'])) == dict(title='a', ort='d', merkmale='f', weitere_eigenschaften='h', beschreibung='j')
	assert candidate(
    {"title": ["title1", "title2"], "ort": ["ort1", "ort2"], "preis": ["preis1", "preis2"], "anzahl_raeume": ["anzahl_raeume1", "anzahl_raeume2"], "wohnflaeche": ["wohnflaeche1", "wohnflaeche2"], "grundstuecksflaeche": ["grundstuecksflaeche1", "grundstuecksflaeche2"], "merkmale": ["merkmale1", "merkmale2"], "weitere_eigenschaften": ["weitere_eigenschaften1", "weitere_eigenschaften2"], "beschreibung": ["beschreibung1", "beschreibung2"]}
) == {"title": "title1", "ort": "ort1", "preis": "preis2", "anzahl_raeume": "anzahl_raeume2", "wohnflaeche": "wohnflaeche2", "grundstuecksflaeche": "grundstuecksflaeche2", "merkmale": "merkmale1", "weitere_eigenschaften": "weitere_eigenschaften1", "beschreibung": "beschreibung1"}
	assert candidate({}) == {}
def test_check():
	check(get_right_list_elements)
