def createCVEEntry():
    """Create empty CVE entry for easy initialisation."""
    ### Canonical solution below ###
    return {
        "cve_id": "",
        "description": "",
        "references": "",
        "created": "NA",
        "modified": "NA",
        "vector": "",
        "attackVector": "",
        "attackComplexity": "",
        "privilegeRequired": "",
        "userInteraction": "",
        "scope": "",
        "confidentialityImpact": "",
        "integrityImpact": "",
        "availabilityImpact": "",
        "baseScore": -1,
        "predictedScore": -1,
        "severity": "",
        "exploitabilityScore": -1,
        "impactScore": -1,
    }


### Unit tests below ###
def check(candidate):
	assert candidate()["exploitabilityScore"] == -1
	assert candidate()["vector"] == ""
	assert candidate() == {
    'cve_id': '',
    'description': '',
   'references': '',
    'created': 'NA',
   'modified': 'NA',
   'vector': '',
    'attackVector': '',
    'attackComplexity': '',
    'privilegeRequired': '',
    'userInteraction': '',
   'scope': '',
    'confidentialityImpact': '',
    'integrityImpact': '',
    'availabilityImpact': '',
    'baseScore': -1,
    'predictedScore': -1,
   'severity': '',
    'exploitabilityScore': -1,
    'impactScore': -1,
}
	assert candidate()["predictedScore"] == -1
	assert candidate()["availabilityImpact"] == ""
	assert candidate()["scope"] == ""
	assert candidate(
) == {
        "cve_id": "",
        "description": "",
        "references": "",
        "created": "NA",
        "modified": "NA",
        "vector": "",
        "attackVector": "",
        "attackComplexity": "",
        "privilegeRequired": "",
        "userInteraction": "",
        "scope": "",
        "confidentialityImpact": "",
        "integrityImpact": "",
        "availabilityImpact": "",
        "baseScore": -1,
        "predictedScore": -1,
        "severity": "",
        "exploitabilityScore": -1,
        "impactScore": -1,
    }
	assert candidate()["modified"] == "NA"
	assert candidate()["confidentialityImpact"] == ""
	assert candidate(
    ) == {
    "cve_id": "",
    "description": "",
    "references": "",
    "created": "NA",
    "modified": "NA",
    "vector": "",
    "attackVector": "",
    "attackComplexity": "",
    "privilegeRequired": "",
    "userInteraction": "",
    "scope": "",
    "confidentialityImpact": "",
    "integrityImpact": "",
    "availabilityImpact": "",
    "baseScore": -1,
    "predictedScore": -1,
    "severity": "",
    "exploitabilityScore": -1,
    "impactScore": -1,
}
	assert candidate()["integrityImpact"] == ""
	assert candidate()["attackVector"] == ""
	assert candidate()["baseScore"] == -1
	assert candidate(
) == {
    "cve_id": "",
    "description": "",
    "references": "",
    "created": "NA",
    "modified": "NA",
    "vector": "",
    "attackVector": "",
    "attackComplexity": "",
    "privilegeRequired": "",
    "userInteraction": "",
    "scope": "",
    "confidentialityImpact": "",
    "integrityImpact": "",
    "availabilityImpact": "",
    "baseScore": -1,
    "predictedScore": -1,
    "severity": "",
    "exploitabilityScore": -1,
    "impactScore": -1,
}
	assert candidate()["attackComplexity"] == ""
	assert candidate(
    ) == {
        "cve_id": "",
        "description": "",
        "references": "",
        "created": "NA",
        "modified": "NA",
        "vector": "",
        "attackVector": "",
        "attackComplexity": "",
        "privilegeRequired": "",
        "userInteraction": "",
        "scope": "",
        "confidentialityImpact": "",
        "integrityImpact": "",
        "availabilityImpact": "",
        "baseScore": -1,
        "predictedScore": -1,
        "severity": "",
        "exploitabilityScore": -1,
        "impactScore": -1,
    }, "candidate() should return an empty CVE entry."
	assert candidate()["description"] == ""
	assert candidate(
    ) == {
        "cve_id": "",
        "description": "",
        "references": "",
        "created": "NA",
        "modified": "NA",
        "vector": "",
        "attackVector": "",
        "attackComplexity": "",
        "privilegeRequired": "",
        "userInteraction": "",
        "scope": "",
        "confidentialityImpact": "",
        "integrityImpact": "",
        "availabilityImpact": "",
        "baseScore": -1,
        "predictedScore": -1,
        "severity": "",
        "exploitabilityScore": -1,
        "impactScore": -1,
    }
	assert candidate()["privilegeRequired"] == ""
	assert candidate() is not None
	assert candidate()["cve_id"] == ""
	assert candidate()["created"] == "NA"
	assert candidate()["references"] == ""
	assert candidate()["impactScore"] == -1
	assert candidate(
) == {
    "cve_id": "",
    "description": "",
    "references": "",
    "created": "NA",
    "modified": "NA",
    "vector": "",
    "attackVector": "",
    "attackComplexity": "",
    "privilegeRequired": "",
    "userInteraction": "",
    "scope": "",
    "confidentialityImpact": "",
    "integrityImpact": "",
    "availabilityImpact": "",
    "baseScore": -1,
    "predictedScore": -1,
    "severity": "",
    "exploitabilityScore": -1,
    "impactScore": -1,
}, "Create CVE entry failed"
	assert candidate()["userInteraction"] == ""
	assert candidate()["severity"] == ""
def test_check():
	check(createCVEEntry)
