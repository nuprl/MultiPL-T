def find_sentence_starts(data):
    """ Finds the positions inside a memory-mapped file, where the sentences
     (lines) start.
     
     TextIOWrapper disables tell() when readline() is called, so search for
     sentence starts in memory-mapped data.
     
     :type data: mmap.mmap
     :param data: memory-mapped data of the input file
     
     :rtype: list of ints
     :returns: a list of file offsets pointing to the next character from a
     newline (including file start and excluding file end)
     """
	### Canonical solution below ###    

    result = [0]

    pos = 0
    while True:
        pos = data.find(b'\n', pos)
        if pos == -1:
            break
        pos += 1
        if pos < len(data):
            result.append(pos)

    return result

### Unit tests below ###
def check(candidate):
	assert candidate(b"A\nB") == [0, 2]
	assert candidate(b'a\nb\nc\nd') == [0, 2, 4, 6]
	assert candidate(b'foo') == [0]
	assert candidate(b'Hello!\nWorld!') == [0, 7]
	assert candidate(b'a\nb\nc') == [0, 2, 4]
	assert candidate(b'a\nb') == [0, 2]
	assert candidate(b'a\nb\nc\nd\ne') == [0, 2, 4, 6, 8]
	assert candidate(b"a\nb\n\nc") == [0, 2, 4, 5]
	assert candidate(b"\n\n\n\n\n") == [0, 1, 2, 3, 4]
	assert candidate(b'abc\ndef') == [0, 4]
	assert candidate(b'a\nb\nc\nd\ne\nf\ng') == [0, 2, 4, 6, 8, 10, 12]
	assert candidate(b"abc\ndef") == [0, 4]
	assert candidate(b'') == [0]
	assert candidate(b'foo\nbar') == [0, 4]
	assert candidate(b"a\nb") == [0, 2]
	assert candidate(b"a\nb\nc") == [0, 2, 4]
	assert candidate(b"") == [0]
	assert candidate(b'a\nb\nc\nd\ne\nf') == [0, 2, 4, 6, 8, 10]
def test_check():
	check(find_sentence_starts)
