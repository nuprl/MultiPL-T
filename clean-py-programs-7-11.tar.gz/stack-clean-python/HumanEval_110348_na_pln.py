def na_pln(currency, total_balance, rate_eur, rate_usd):
    """ Calculate the values in PLN"""
	### Canonical solution below ###    
    if 'EUR' in currency:
        return total_balance * rate_eur
    elif 'USD' in currency:
        return total_balance * rate_usd
    else:
        return total_balance

### Unit tests below ###
def check(candidate):
	assert candidate(currency='EUR', total_balance=100, rate_eur=0.9, rate_usd=1.0) == 90
	assert candidate(currency='PLN', total_balance=100, rate_eur=0.13, rate_usd=0) == 100
	assert candidate(currency='EUR', total_balance=1000, rate_eur=1.2, rate_usd=1) == 1200
	assert candidate(currency='USD', total_balance=100, rate_eur=0.18, rate_usd=1) == 100
	assert candidate(currency='USD', total_balance=100, rate_eur=2, rate_usd=1) == 100
	assert candidate(currency='USD', total_balance=100, rate_eur=0.9, rate_usd=1.0) == 100
	assert candidate(currency='EUR', total_balance=1000, rate_eur=2, rate_usd=3) == 2000
	assert candidate(currency='EUR', total_balance=100, rate_eur=0.18, rate_usd=1) == 18
	assert candidate(currency='USD', total_balance=1000, rate_eur=1, rate_usd=1) == 1000
	assert candidate(currency='USD', total_balance=1000, rate_eur=2, rate_usd=2) == 2000
	assert candidate(currency='GBP', total_balance=100, rate_eur=0.9, rate_usd=1.0) == 100
	assert candidate(currency='GBP', total_balance=1000, rate_eur=2, rate_usd=2) == 1000
	assert candidate(currency='USD', total_balance=100, rate_eur=1, rate_usd=1) == 100
	assert candidate(currency='USD', total_balance=1000, rate_eur=0.25, rate_usd=0.23) == 230.0
	assert candidate(currency='GBP', total_balance=1000, rate_eur=3.5, rate_usd=4) == 1000
	assert candidate(currency='GBP', total_balance=100, rate_eur=1, rate_usd=2) == 100, "Should be 100"
	assert candidate(currency='GBP', total_balance=100, rate_eur=1.15, rate_usd=1.0) == 100
	assert candidate(currency='EUR', total_balance=100, rate_eur=1, rate_usd=2) == 100, "Should be 100"
	assert candidate(currency='PLN', total_balance=100, rate_eur=4, rate_usd=4) == 100
	assert candidate(currency='PLN', total_balance=100, rate_eur=1.2, rate_usd=1) == 100
	assert candidate(currency='GBP', total_balance=100, rate_eur=0.03, rate_usd=0.03) == 100.0
	assert candidate(currency='EUR', total_balance=100, rate_eur=2, rate_usd=0) == 200
	assert candidate(currency='PLN', total_balance=100, rate_eur=2.0, rate_usd=3.0) == 100
	assert candidate(currency='USD', total_balance=100, rate_eur=1.15, rate_usd=1.0) == 100
	assert candidate(currency='GBP', total_balance=100, rate_eur=4, rate_usd=3) == 100
	assert candidate(currency='USD', total_balance=100, rate_eur=0.84, rate_usd=1.0) == 100
	assert candidate(currency='EUR', total_balance=100, rate_eur=1.2, rate_usd=1) == 120
	assert candidate(currency='USD', total_balance=100, rate_eur=1.2, rate_usd=1) == 100
	assert candidate(currency='EUR', total_balance=1000, rate_eur=4, rate_usd=5) == 4000
	assert candidate(currency='EUR', total_balance=100, rate_eur=0.9, rate_usd=1.1) == 90
	assert candidate(currency='EUR', total_balance=100, rate_eur=0.13, rate_usd=0) == 13.0
	assert candidate(currency='EUR', total_balance=10, rate_eur=1.17, rate_usd=1.31) == 11.7
	assert candidate(currency='EUR', total_balance=100, rate_eur=0.84, rate_usd=1.0) == 84
	assert candidate(currency='EUR', total_balance=1000, rate_eur=1, rate_usd=1) == 1000
	assert candidate(currency='USD', total_balance=100, rate_eur=4, rate_usd=3) == 300
	assert candidate(currency='EUR', total_balance=100, rate_eur=1, rate_usd=1) == 100
	assert candidate(currency='USD', total_balance=1000, rate_eur=3.5, rate_usd=4) == 4000
	assert candidate(currency='EUR', total_balance=1000, rate_eur=3.5, rate_usd=4) == 3500
	assert candidate(currency='PLN', total_balance=100, rate_eur=4, rate_usd=3) == 100
	assert candidate(currency='PLN', total_balance=100, rate_eur=3.0, rate_usd=3.0) == 100
	assert candidate(currency='USD', total_balance=1000, rate_eur=1, rate_usd=1.2) == 1200
	assert candidate(currency='EUR', total_balance=100, rate_eur=4, rate_usd=4) == 400
	assert candidate(currency='USD', total_balance=100, rate_eur=1, rate_usd=2) == 200, "Should be 200"
	assert candidate(currency='JPY', total_balance=100, rate_eur=2, rate_usd=1) == 100
	assert candidate(currency='GBP', total_balance=100, rate_eur=2, rate_usd=0) == 100
	assert candidate(currency="GBP", total_balance=100, rate_eur=3, rate_usd=3) == 100
	assert candidate(currency='PLN', total_balance=1000, rate_eur=4, rate_usd=5) == 1000
	assert candidate(currency='EUR', total_balance=100, rate_eur=2, rate_usd=1) == 200
	assert candidate(currency='USD', total_balance=1000, rate_eur=2, rate_usd=3) == 3000
	assert candidate(currency="USD", total_balance=100, rate_eur=3, rate_usd=3) == 300
	assert candidate(currency='GBP', total_balance=1000, rate_eur=1, rate_usd=1) == 1000
	assert candidate(currency='EUR', total_balance=1000, rate_eur=3.15, rate_usd=0) == 3150
	assert candidate(currency='EUR', total_balance=100, rate_eur=4, rate_usd=3) == 400
	assert candidate(currency="EUR", total_balance=100, rate_eur=3, rate_usd=3) == 300
	assert candidate(currency='EUR', total_balance=1000, rate_eur=0.25, rate_usd=0.23) == 250.0
	assert candidate(currency='PLN', total_balance=1000, rate_eur=3.15, rate_usd=0) == 1000
	assert candidate(currency='GBP', total_balance=100, rate_eur=1, rate_usd=1) == 100
	assert candidate(currency='GBP', total_balance=1000, rate_eur=0.25, rate_usd=0.23) == 1000.0
	assert candidate(currency='GBP', total_balance=100, rate_eur=1.15, rate_usd=1.10) == 100
	assert candidate(currency='PLN', total_balance=100, rate_eur=2, rate_usd=2.5) == 100, 'Should be 100'
	assert candidate(currency='PLN', total_balance=100, rate_eur=0.89, rate_usd=1.12) == 100.0
	assert candidate(currency='GBP', total_balance=1000, rate_eur=2, rate_usd=3) == 1000
	assert candidate(currency='USD', total_balance=100, rate_eur=4, rate_usd=4) == 400
	assert candidate(currency='EUR', total_balance=1000, rate_eur=2, rate_usd=2) == 2000
def test_check():
	check(na_pln)
