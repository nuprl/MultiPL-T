def execute(code_source, **namespace):
    """ Execute code in a namespace, returning the namespace."""
	### Canonical solution below ###    
    code_object = compile(
        code_source, '<generated code: {}>'.format(code_source), 'exec')
    exec(code_object, namespace)
    return namespace

### Unit tests below ###
def check(candidate):
	assert candidate(
    'a = 1\n'
    'b = 2\n'
    'c = 3\n'
    'd = 4\n'
)['a'] == 1
	assert candidate(
    'a = 1; b = 2; c = 3',
)['b'] == 2
	assert candidate(
    'def f(x):\n'
   '   def g(y):\n'
   '       return y + 1\n'
   '   return g\n'
    'f(10)\n'
)['f'](10)(10) == 11
	assert candidate(
    'a = 5',
    b=6)['a'] == 5
	assert candidate(
    'a = 1\n'
    'b = 2\n'
    'c = a + b\n'
    'print(c)\n'
)['c'] == 3
	assert candidate(
    'a = 1; b = 2; c = 3',
)['a'] == 1
	assert candidate(
    'a = 1\n'
    'b = 2\n'
    'c = 3\n'
    'd = 4\n'
)['c'] == 3
	assert candidate(
    'a = 5\nb = 6')['b'] == 6
	assert candidate(
    'a = 10\nb = 20\n'
)['a'] == 10
	assert candidate(
    'a = 1; b = 2; c = 3',
)['c'] == 3
	assert candidate(
    'x = 10\n'
    'y = 20\n'
    'x = 30\n',
    x=0)['x'] == 30
	assert candidate(
    'def f():\n'
   '   return 23\n'
    'print(f())\n'
)['f']() == 23
	assert candidate(
    'a = 1\n'
    'b = 2\n'
    'c = 3\n'
    'd = 4\n'
)['b'] == 2
	assert candidate(
    'def f(x):\n'
   '   def g(y):\n'
   '       return y + 1\n'
   '   return g(x)\n'
    'f(10)\n'
)['f'](10) == 11
	assert candidate(
    """
def test():
    return 1
test()
"""
)['test']() == 1
	assert candidate(
    'def f(x):\n'
   '   return x + 1\n'
    'f(10)\n'
)['f'](10) == 11
	assert candidate(
    'x = 10\n',
    x=0)['x'] == 10
	assert candidate(
    'a = 5\nb = 6')['a'] == 5
	assert candidate(
    'a = 1\n'
    'b = 2\n'
    'c = 3\n'
    'd = 4\n'
)['d'] == 4
	assert candidate(
    'a = 10\nb = 20\n'
)['b'] == 20
	assert candidate(
    'a = 1\n'
    'def f():\n'
   '   b = 2\n'
   '   def g():\n'
   '       return b\n'
   '   return g\n'
    'd = f()\n'
    'e = d()\n'
)['e'] == 2
	assert candidate(
    'a = 1\n'
    'b = 2\n'
    'c = 3\n'
    'd = 4\n'
    'e = 5\n'
)['a'] == 1
	assert candidate(
    'x = 10\n'
    'y = 20\n',
    x=0)['x'] == 10
	assert candidate(
    'a = 10\n'
    'b = 20\n'
    'c = a + b\n'
    'print(c)'
)['c'] == 30
	assert candidate(
    'a = 1; b = 2; c = a + b',
    a=10, b=20, c=30
)['a'] == 1
	assert candidate(
    'a = 10',
    b=20
)['a'] == 10
def test_check():
	check(execute)
