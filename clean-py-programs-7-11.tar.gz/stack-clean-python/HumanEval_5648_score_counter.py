def score_counter(sentence_tokens,entity_tokens,sentence_index=0,entity_index=0,current_score=0,exact_matching=True):
    """ 
     Recieved
     - sentence_tokens - The tokens of the sentence
     - entity_tokens - The tokens of the entity
     - sentence_index - The current index of the sentence
     - entity_index - The current index of the entity
     - current_score=0 - The current score of the entity
     
     Returns the score of the entity.
     The score is an integer that indicates how many tokens of the entity in order are present in the
     sentence starting from the recieved sentence_index.
     """
	### Canonical solution below ###    

    def counter_aux(sentence_tokens,entity_tokens,sentence_index,entity_index,current_score):
        """
        Auxiliary recursive function for the 'score_counter' function.
        Does not check for exact matching.
        """
       
        if sentence_tokens[sentence_index] == entity_tokens[entity_index]:
            # Reached last token of the sentence or entity
            if sentence_index+1 == len(sentence_tokens) or entity_index+1 == len(entity_tokens):
                return current_score+1
            return counter_aux(sentence_tokens, entity_tokens, sentence_index+1, entity_index+1, current_score+1)
        return current_score

    score = counter_aux(sentence_tokens,entity_tokens,sentence_index,entity_index,current_score)
    # If exact matching selected, ignore other cases
    if exact_matching and not score == len(entity_tokens):
        return 0
    return score

### Unit tests below ###
def check(candidate):
	assert candidate(
    ["I", "love", "you"], ["I", "love", "you"], exact_matching=False) == 3
	assert candidate(
    ["I", "love", "you"], ["I", "love", "you"], exact_matching=True) == 3
	assert candidate(sentence_tokens=['hello','world'], entity_tokens=['world'], sentence_index=1, entity_index=0, current_score=2) == 0
	assert candidate(sentence_tokens=['hello','world'], entity_tokens=['world'], sentence_index=0, entity_index=0, current_score=4) == 0
	assert candidate(
    ["This","is","a","test"],
    ["This","is","a"],
    exact_matching=False) == 3
	assert candidate(
    ["I","like","cats","and","dogs"],
    ["cats","and","dogs"],
    sentence_index=4,
    entity_index=0,
    current_score=0
) == 0
	assert candidate(sentence_tokens=["a","b","c","d"],entity_tokens=["a","b","c","d"],sentence_index=1,exact_matching=True) == 0
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','d'],sentence_index=1,entity_index=1,current_score=6) == 0
	assert candidate(
    ['i','am','a','man'],
    ['i','am','a','man','and'],
    exact_matching=False) == 4
	assert candidate(sentence_tokens=["a","b","c","d"],entity_tokens=["a","b","c","d"],entity_index=1,exact_matching=True) == 0
	assert candidate(sentence_tokens=['hello','world'], entity_tokens=['world'], sentence_index=0, entity_index=0, current_score=2) == 0
	assert candidate(sentence_tokens=["a","b","c","d"],entity_tokens=["a","b","c","d"],exact_matching=True) == 4
	assert candidate(sentence_tokens=['hello','world'], entity_tokens=['world'], sentence_index=0, entity_index=0, current_score=3) == 0
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','d'],sentence_index=1,entity_index=1,current_score=5) == 0
	assert candidate(sentence_tokens = ['I','like','cats','and','dogs'],entity_tokens = ['cats','and','dogs','now'],sentence_index=1,entity_index=1,current_score=0,exact_matching=True) == 0
	assert candidate(list('abc'),list('abc'),0,0,current_score=5,exact_matching=False) == 8
	assert candidate(sentence_tokens = ["The", "boy", "saw", "a", "girl", "with", "a", "telescope"],
                     entity_tokens = ["boy", "girl", "telescope"],
                     sentence_index=0,
                     entity_index=0,
                     current_score=0,
                     exact_matching=True) == 0
	assert candidate(list('abc'),list('abc'),0,0) == 3
	assert candidate(sentence_tokens=['hello','world'], entity_tokens=['world'], sentence_index=0, entity_index=0, current_score=1) == 1
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','d','e'],exact_matching=False) == 4
	assert candidate(sentence_tokens=["a","b","c","d"],entity_tokens=["a","b","c","d"]) == 4
	assert candidate(
    ['i','am','a','man'],
    ['i','am','a','man'],
    exact_matching=True) == 4
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','d'],exact_matching=False) == 4
	assert candidate(sentence_tokens=["a","b","c","d"],entity_tokens=["a","b","c","d"],sentence_index=3,entity_index=3) == 0
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','e'],exact_matching=False) == 3
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','d']) == 4
	assert candidate(sentence_tokens=['hello','world'], entity_tokens=['world'], sentence_index=1, entity_index=0, current_score=3) == 0
	assert candidate(
    ['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog'],
    ['the', 'brown', 'fox'],
    exact_matching=True
    ) == 0
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['d','c','b','a']) == 0
	assert candidate(
    sentence_tokens=['the','quick','brown','fox','jumps','over','the','lazy','dog'],
    entity_tokens=['fox','jumps','over'],
    exact_matching=True) == 0
	assert candidate(
    ["This","is","a","test"],
    ["This","is","a","test"],
    exact_matching=True) == 4
	assert candidate(
    ['i','am','a','man'],
    ['i','am','a','man','and'],
    exact_matching=True) == 0
	assert candidate(
    ["This","is","a","test"],
    ["This","is","a","test"],
    exact_matching=False) == 4
	assert candidate(sentence_tokens=["a","b","c","d"],entity_tokens=["a","b","c","d"],sentence_index=0,entity_index=0,current_score=0,exact_matching=True) == 4
	assert candidate(sentence_tokens=["The","man","is","walking","with","the","dog"],entity_tokens=["the","man"],sentence_index=2,entity_index=0,current_score=0,exact_matching=True) == 0
	assert candidate(
    ['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog'],
    ['the', 'brown', 'fox', 'jumps', 'over'],
    exact_matching=True
    ) == 0
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['b','c','d'],sentence_index=1,entity_index=0,current_score=0,exact_matching=False) == 3
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','d'],sentence_index=1,entity_index=1,current_score=4) == 0
	assert candidate(sentence_tokens=['hello','world'], entity_tokens=['world'], sentence_index=1, entity_index=0, current_score=0) == 1
	assert candidate(
    ['i','am','a','man'],
    ['i','am','a','man'],
    exact_matching=False) == 4
	assert candidate(list('abc'),list('abc'),0,0,exact_matching=False) == 3
	assert candidate(sentence_tokens=["a","b","c","d"],entity_tokens=["a","b","c","d"],sentence_index=0,entity_index=0,current_score=0,exact_matching=False) == 4
	assert candidate(sentence_tokens=['a','b','c','d'],entity_tokens=['a','b','c','d'],sentence_index=1,entity_index=1,current_score=3) == 0
def test_check():
	check(score_counter)
