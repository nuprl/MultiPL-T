def aidstr(aid, ibs=None, notes=False):
    """ Helper to make a string from an aid """
    ### Canonical solution below ###
    if not notes:
        return 'aid%d' % (aid,)
    else:
        assert ibs is not None
        notes = ibs.get_annot_notes(aid)
        name  = ibs.get_annot_names(aid)
        return 'aid%d-%r-%r' % (aid, str(name), str(notes))


### Unit tests below ###
def check(candidate):
	assert candidate(10) == 'aid10'
	assert candidate(123) == 'aid123'
	assert candidate(2) == 'aid2'
	assert candidate(100) == 'aid100'
	assert candidate(0, notes=False) == 'aid0'
	assert candidate(1) == 'aid1'
	assert candidate(0) == 'aid0'
def test_check():
	check(aidstr)
