def flatten(l):
    """ Flatten List of Lists to List"""
	### Canonical solution below ###    
    return [item for sublist in l for item in sublist]

### Unit tests below ###
def check(candidate):
	assert candidate([[1, 2], [3, 4], [5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate([[1, 2, 3], [4, 5]]) == [1, 2, 3, 4, 5]
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]] ) == [1,2,3,4,5,6,7,8,9]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([[1, 2, 3], [4], [5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[1,2,3], [4,5,6]] ) == [1,2,3,4,5,6]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9], "Basic Test"
	assert candidate([[1, 2, 3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate( [[1, 2], [3, 4]] ) == [1, 2, 3, 4]
	assert candidate( [[1, 2], [3], [4, 5, 6]] ) == [1, 2, 3, 4, 5, 6]
	assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[1,2],[3,4]] ) == [1,2,3,4]
	assert candidate( [[1,2,3,4],[5,6,7,8],[9,10,11,12]] ) == [1,2,3,4,5,6,7,8,9,10,11,12]
	assert candidate( [ [1,2,3], [4], [5,6] ] ) == [1,2,3,4,5,6]
	assert candidate([[1, 2, 3], [4, 5], [6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate( [[1,2,3],[4,5],[6]] ) == [1,2,3,4,5,6]
	assert candidate( [[1, 2, 3], [4, 5], [6, 7, 8, 9]] ) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[1,2,3,4],[5,6,7,8]] ) == [1,2,3,4,5,6,7,8]
	assert candidate( [[1,2],[3,4],[5,6]] ) == [1,2,3,4,5,6]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]]
) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
	assert candidate( [] ) == []
	assert candidate( [[],[]] ) == []
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
	assert candidate( [[]] ) == []
	assert candidate([]) == []
	assert candidate([[1, 2], [3, 4, 5], [6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate( [[],[],[]] ) == []
	assert candidate( [ [1], [2], [3], [4], [5], [6] ] ) == [1,2,3,4,5,6]
	assert candidate([[1]]) == [1]
	assert candidate([[1, 2, 3]]) == [1, 2, 3]
	assert candidate( [[1, 2], [3, 4], [5, 6]] ) == [1, 2, 3, 4, 5, 6]
	assert candidate([[1], [2], [3]]) == [1, 2, 3]
	assert candidate( [ [1], [2,3], [4,5,6] ] ) == [1,2,3,4,5,6]
	assert candidate( [[[1,2,3]], [[4,5,6]], [[7,8,9]]] ) == [[1,2,3], [4,5,6], [7,8,9]]
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]] ) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [ [1,2], [3,4], [5,6] ] ) == [1,2,3,4,5,6]
	assert candidate([[1, 2, 3], [4, 5], [6, 7]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate([[1, 2], [3, 4]]) == [1, 2, 3, 4]
	assert candidate( [[1,2,3],[4,5,6]] ) == [1,2,3,4,5,6]
def test_check():
	check(flatten)
