def set_bit(arg, index, val):
    """
    Set the index:th bit of arg to 1 if val is truthy,
    else to 0, and return the new value.
    """
    ### Canonical solution below ###
    mask = 1 << index  # Compute mask with just bit 'index' set
    arg &= ~mask      # Clear the bit indicated by the mask
    if val:
        arg |= mask   # If val is True, set the bit indicated by the mask
    return arg


### Unit tests below ###
def check(candidate):
	assert candidate(1, 6, 1) == 65
	assert candidate(127, 2, 0) == 123
	assert candidate(10, 3, 1) == 10
	assert candidate(0, 0, 1) == 1
	assert candidate(1, 2, 0) == 1
	assert candidate(2, 2, 1) == 6
	assert candidate(10, 2, 0) == 10
	assert candidate(5, 2, 1) == 5
	assert candidate(0, 3, 0) == 0
	assert candidate(5, 0, 0) == 4
	assert candidate(5, 3, 1) == 13
	assert candidate(1, 3, 0) == 1
	assert candidate(127, 0, 0) == 126
	assert candidate(1, 1, 0) == 1
	assert candidate(127, 1, 0) == 125
	assert candidate(128, 2, 1) == 132
	assert candidate(10, 2, 1) == 14
	assert candidate(127, 1, 1) == 127
	assert candidate(127, 2, 1) == 127
	assert candidate(1, 2, 0) == 0b1
	assert candidate(0, 4, 1) == 16
	assert candidate(1, 4, 0) == 1
	assert candidate(5, 0, 1) == 5
	assert candidate(2, 2, 1) == 6, "candidate(2, 2, 1)"
	assert candidate(0, 0, 0) == 0
	assert candidate(1, 7, 0) == 1
	assert candidate(255, 2, 1) == 255
	assert candidate(255, 6, 1) == 255
	assert candidate(177, 0, 0) == 176
	assert candidate(4, 1, 0) == 4
	assert candidate(177, 2, 1) == 181
	assert candidate(1, 7, 1) == 129
	assert candidate(170, 2, 1) == 174
	assert candidate(0, 0, 1) == 1, "candidate(0, 0, 1)"
	assert candidate(177, 1, 0) == 177
	assert candidate(0, 1, 1) == 2, "candidate(0, 1, 1)"
	assert candidate(128, 7, 0) == 0
	assert candidate(177, 9, 0) == 177
	assert candidate(0, 1, 1) == 2
	assert candidate(0, 5, 1) == 32
	assert candidate(255, 4, 1) == 255
	assert candidate(1, 5, 0) == 1
	assert candidate(10, 4, 0) == 10
	assert candidate(1, 3, 1) == 9
	assert candidate(2, 2, 0) == 2
	assert candidate(128, 3, 1) == 136
	assert candidate(177, 8, 0) == 177
	assert candidate(1, 2, 1) == 5, "candidate(1, 2, 1)"
	assert candidate(0, 2, 1) == 4, "candidate(0, 2, 1)"
	assert candidate(255, 5, 1) == 255
	assert candidate(1, 4, 1) == 17
	assert candidate(177, 3, 1) == 185
	assert candidate(177, 3, 0) == 177
	assert candidate(3, 4, 0) == 3
	assert candidate(4, 1, 1) == 6
	assert candidate(255, 1, 1) == 255
	assert candidate(1, 2, 1) == 5
	assert candidate(4, 2, 0) == 0
	assert candidate(177, 2, 0) == 177
	assert candidate(177, 1, 1) == 179
	assert candidate(0, 1, 0) == 0
	assert candidate(1, 0, 0) == 0
	assert candidate(255, 0, 1) == 255
	assert candidate(4, 2, 1) == 4
	assert candidate(177, 0, 1) == 177
	assert candidate(0, 7, 0) == 0
	assert candidate(1, 1, 1) == 3
	assert candidate(255, 3, 1) == 255
	assert candidate(1, 5, 1) == 33
	assert candidate(0, 5, 0) == 0
	assert candidate(0, 6, 1) == 64
	assert candidate(1, 0, 1) == 1
	assert candidate(2, 0, 0) == 2
	assert candidate(128, 4, 1) == 144
	assert candidate(255, 7, 1) == 255
	assert candidate(0, 7, 1) == 128
	assert candidate(1, 1, 0) == 0b1
	assert candidate(1, 6, 0) == 1
	assert candidate(0, 4, 0) == 0
	assert candidate(1, 1, 1) == 3, "candidate(1, 1, 1)"
	assert candidate(2, 3, 0) == 2
	assert candidate(0, 6, 0) == 0
	assert candidate(127, 0, 1) == 127
	assert candidate(1, 0, 1) == 0b1
	assert candidate(0, 3, 1) == 8
	assert candidate(128, 1, 1) == 130
	assert candidate(0, 2, 1) == 4
	assert candidate(0, 2, 0) == 0
	assert candidate(128, 7, 1) == 128
	assert candidate(1000, 4, 0) == 1000
	assert candidate(177, 6, 0) == 177
def test_check():
	check(set_bit)
