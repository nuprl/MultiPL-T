def BGL_form_factor(z, p, phi, a: list):
    """
    Calculates the BGL form factor.
    :param z: BGL expansion parameter.
    :param p: The Blaschke factors containing explicit poles in the q2 region.
    :param phi: Outer functions.
    :param a: Expansion coefficients.
    :return:
    """
    ### Canonical solution below ###
    return 1 / (p(z) * phi(z)) * sum([a_i * z ** n for n, a_i in enumerate(a)])


### Unit tests below ###
def check(candidate):
	assert candidate(4, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(5, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(2, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(1, lambda z: z ** 2, lambda z: z ** 3, [1]) == 1
	assert candidate(0, lambda x: 1, lambda x: 1, [1, 2, 3]) == 1.0
	assert candidate(1, lambda z: 1, lambda z: z, [1, 0]) == 1
	assert candidate(0, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(1, lambda z: 1, lambda z: 1, [1, 0, 0]) == 1
	assert candidate(1, lambda z: 1, lambda z: 1, [1, 0]) == 1
	assert candidate(1, lambda z: 1, lambda z: 1, [0]) == 0
	assert candidate(8, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 1, 1, 1, 1, 1, 1, 1]) == 1
	assert candidate(11, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(1, lambda z: z, lambda z: z, [1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 1]) == 1
	assert candidate(7, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(3, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(4, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(1, lambda z: 1, lambda z: 1, [0, 0, 1]) == 1
	assert candidate(1.0, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 0]) == 1
	assert candidate(0, p=lambda z: 1, phi=lambda z: 1, a=[1]) == 1
	assert candidate(9, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(1, lambda z: z ** 3, lambda z: z ** 2, [1]) == 1
	assert candidate(1, lambda z: 1, lambda z: 1, [0, 1]) == 1
	assert candidate(1, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(0.0, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(1, lambda x: x, lambda x: x, [1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 1, 1, 1]) == 1
	assert candidate(0.5, lambda x: 1, lambda x: 1, [1]) == 1.0
	assert candidate(1, lambda z: 1, lambda z: z, [0, 1]) == 1
	assert candidate(1, p=lambda z: 1, phi=lambda z: z**3, a=[1]) == 1
	assert candidate(3, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(1, lambda z: z ** 2, lambda z: z ** 2, [1]) == 1
	assert candidate(1, p=lambda z: 1, phi=lambda z: z**2, a=[1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 1, 1, 1, 1, 1]) == 1
	assert candidate(2, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(0, lambda x: 1, lambda x: 1, [1, 2]) == 1.0
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 2]) == 1
	assert candidate(6, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(1, lambda z: 1, lambda z: z, [1]) == 1
	assert candidate(10, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(1, lambda z: z, lambda z: z ** 2, [1]) == 1
	assert candidate(1, lambda z: z, lambda z: 1, [1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 1, 1, 1, 1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 1, 1]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1]) == 1
	assert candidate(1, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(6, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(5, lambda x: 1, lambda x: 1, [1]) == 1
	assert candidate(1, p=lambda z: 1, phi=lambda z: z, a=[1]) == 1
	assert candidate(1, lambda z: 1, lambda z: 1, [0, 1, 0]) == 1
	assert candidate(1, p=lambda z: 1, phi=lambda z: 1, a=[1]) == 1
	assert candidate(0.5, lambda z: 1, lambda z: 1, [1, 0, 0, 0, 0, 0]) == 1
	assert candidate(0, lambda z: 1, lambda z: 1, [1, 1, 1, 1, 1, 1, 1]) == 1
	assert candidate(12, lambda x: 1, lambda x: 1, [1]) == 1
def test_check():
	check(BGL_form_factor)
