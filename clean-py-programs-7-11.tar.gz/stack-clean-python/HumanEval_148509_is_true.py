def is_true(boolstring: str):
    """ Converts an environment variables to a Python boolean. """
	### Canonical solution below ###    
    if boolstring.lower() in ('true', 'True', '1', True):
        return True
    return False

### Unit tests below ###
def check(candidate):
	assert candidate('true') == True
	assert candidate('1') == True
	assert candidate('off') is False
	assert candidate("FALSE") == False
	assert candidate('on') == False
	assert candidate('1') is True
	assert candidate('False') is False
	assert candidate("true") == True
	assert candidate('0') == False
	assert candidate('True')
	assert candidate("True") == True
	assert candidate('off') == False
	assert candidate('FALSE') == False
	assert candidate('True') is True
	assert candidate('yes') == False
	assert candidate('false') == False
	assert candidate('0') is False
	assert candidate('no') is False
	assert candidate("false") == False
	assert candidate("0") == False
	assert candidate("TRUE") == True
	assert candidate('False') == False
	assert candidate('no') == False
	assert candidate('false') is False
	assert candidate('TRUE') == True
	assert not candidate('False')
	assert candidate('true')
	assert candidate('1')
	assert not candidate('0')
	assert candidate('y') == False
	assert candidate('n') == False
	assert candidate('True') == True
	assert candidate('true') is True
	assert candidate("False") == False
	assert candidate("1") == True
	assert not candidate('false')
def test_check():
	check(is_true)
