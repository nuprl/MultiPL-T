def longest_increasing_subsequence(sequence):
    """ 
     Dynamic Programming Algorithm for
     counting the length of longest increasing subsequence
     type sequence: list[int]
     rtype: int
     """
	### Canonical solution below ###    
    length = len(sequence)
    counts = [1 for _ in range(length)]
    for i in range(1, length):
        for j in range(0, i):
            if sequence[i] > sequence[j]:
                counts[i] = max(counts[i], counts[j] + 1)
                print(counts)
    return max(counts)

### Unit tests below ###
def check(candidate):
	assert candidate(sequence=[1, 2, 3]) == 3
	assert candidate(sequence=[2, 2, 2, 2, 2]) == 1
	assert candidate([0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]) == 6
	assert candidate(
    [3, 2, 1, 0]) == 1
	assert candidate([5, 4, 3, 2, 1]) == 1
	assert candidate(
    [10, 22, 3, 1, 44, 41, 60]) == 4
	assert candidate(sequence=[10, 22]) == 2
	assert candidate(sequence=[1]) == 1
	assert candidate([10, 22, 3, 1, 44, 41, 60]) == 4
	assert candidate(sequence=[0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]) == 6
	assert candidate(list(range(10))) == 10
	assert candidate([1]) == 1
	assert candidate([10]) == 1
	assert candidate(
    [2, 2, 2, 2, 2]) == 1
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 10
	assert candidate([10, 7, 8, 9, 11, 15, 12, 13]) == 6
	assert candidate(
    [3, 10, 2, 1, 20]) == 3, 'Test 3'
	assert candidate(sequence=[1, 3, 5, 4, 7]) == 4
	assert candidate(sequence=[10]) == 1
	assert candidate(
    [10, 22, 9, 33, 21, 50]) == 4
	assert candidate([11, 13, 10, 12]) == 2
	assert candidate(sequence=[1, 2, 3, 4, 5, 6]) == 6
	assert candidate([3, 2, 1]) == 1
	assert candidate(sequence=[10, 22, 9, 33, 21, 50, 41, 60]) == 5
	assert candidate(
    [10, 10, 10, 10]) == 1
	assert candidate(sequence=[10, 22, 9, 33, 21, 50, 41, 60, 80]) == 6
	assert candidate(
    [10, 22, 9]) == 2
	assert candidate(
    [10]) == 1
	assert candidate(
    [10, 22, 9, 33, 21, 50, 41, 60]) == 5
	assert candidate(sequence=[1, 2, 3, 3, 4, 4]) == 4
	assert candidate(
    [3, 2]) == 1, 'Test 4'
	assert candidate(sequence=[10, 22, 9, 33, 21, 50, 41]) == 4
	assert candidate(sequence=[10, 22, 9, 33, 21, 50]) == 4
	assert candidate(sequence=[10, 22, 9, 33, 21]) == 3
	assert candidate(
    [1, 2, 3, 4]) == 4
	assert candidate(
    [1, 1, 1, 1, 1, 1, 1, 1]) == 1
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8]) == 8
	assert candidate(
    [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]) == 6
	assert candidate(
    [1, 2, 3, 4, 5]) == 5, 'Test 6'
	assert candidate(sequence=[7, 7, 7, 7, 7, 7, 7]) == 1
	assert candidate([7, 7, 7, 7, 7, 7, 7]) == 1
	assert candidate(sequence=[1, 2, 3, 4, 5]) == 5
	assert candidate(
    [0, 1, 0, 3, 2, 3]) == 4
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9]) == 9
	assert candidate(
    [int(item) for item in "10 9 2 5 3 7 101 18".split(" ")]) == 4
	assert candidate(
    [10, 22, 33, 41, 50]) == 5
	assert candidate(
    [int(item) for item in "0 8 4 12 2 10 6 14 1 9 5 13 3 11 7 15".split(" ")]) == 6
	assert candidate(
    [7, 7, 7, 7, 7, 7, 7]) == 1
	assert candidate([13, 12, 11, 10]) == 1
	assert candidate(
    [10, 22]) == 2
	assert candidate(
    [10, 22, 9, 33, 21]) == 3
	assert candidate([3, 10, 2, 1, 20]) == 3
	assert candidate(
    [10, 22, 9, 33, 21, 50, 41, 60, 80, 100]) == 7
	assert candidate([11, 10, 13, 12]) == 2
	assert candidate(sequence=[1, 2, 3, 3, 3, 4, 4]) == 4
	assert candidate(
    [10, 22, 9, 33, 21, 50, 41, 60, 80]) == 6
	assert candidate([3, 4, -1, 0, 6, 2, 3]) == 4
	assert candidate(
    [5, 4, 3, 2, 1]) == 1
	assert candidate(sequence=[10, 22, 3, 1, 44, 38, 55, 2]) == 4
	assert candidate(
    [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]) == 6, "Testcase failed"
	assert candidate(
    [3, 2, 1]) == 1
	assert candidate(sequence=[1, 2, 3, 4]) == 4
	assert candidate(
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]) == 1
	assert candidate(
    [2, 2, 2, 2, 2]) == 1, "Testcase failed"
	assert candidate(
    [10, 22, 9, 33, 21, 50, 41]) == 4
	assert candidate(
    [10, 22, 9, 33, 21, 50, 41, 60, 80, 5]) == 6
	assert candidate(
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == 10
	assert candidate([1, 2, 3, 4, 5]) == 5
	assert candidate(sequence=[1, 2]) == 2
	assert candidate(
    [10, 9, 22, 33, 21, 50, 41, 60]) == 5
	assert candidate(
    [1, 2, 3, 4, 5]) == 5
	assert candidate(
    [5, 4, 3, 2, 1]) == 1, 'Test 5'
	assert candidate(
    [7, 7, 7, 7, 7, 7, 7]) == 1, "Testcase failed"
	assert candidate(sequence=[10, 22, 9]) == 2
	assert candidate(
    [10, 9, 2, 5, 3, 7, 101, 18]) == 4
	assert candidate([11, 13, 12, 10]) == 2
	assert candidate(
    [10, 22, 3, 1, 44, 38, 5, 6, 7, 90]) == 5
def test_check():
	check(longest_increasing_subsequence)
