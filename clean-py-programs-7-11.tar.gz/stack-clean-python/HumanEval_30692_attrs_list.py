def attrs_list(obj, attrs):
    """ Return a list of values from 'obj' in order of the given `attrs`."""
	### Canonical solution below ###    
    return [getattr(obj, attr) for attr in attrs]

### Unit tests below ###
def check(candidate):
	assert candidate(1, ['__class__', '__class__']) == [int, int]
	assert candidate(1, []) == []
	assert candidate(1, ['__class__']) == [int]
	assert candidate(object(), []) == []
	assert candidate(None, []) == []
def test_check():
	check(attrs_list)
