def hr_range_formatter(start, end, step):
    """Format a range (sequence) in a simple and human-readable format by
    specifying the range's starting number, ending number (inclusive), and step
    size.

    Parameters
    ----------
    start, end, step : numeric

    Notes
    -----
    If `start` and `end` are integers and `step` is 1, step size is omitted.

    The format does NOT follow Python's slicing syntax, in part because the
    interpretation is meant to differ; e.g.,
        '0-10:2' includes both 0 and 10 with step size of 2
    whereas
        0:10:2 (slicing syntax) excludes 10

    Numbers are converted to integers if they are equivalent for more compact
    display.

    Examples
    --------
    >>> hr_range_formatter(start=0, end=10, step=1)
    '0-10'
    >>> hr_range_formatter(start=0, end=10, step=2)
    '0-10:2'
    >>> hr_range_formatter(start=0, end=3, step=8)
    '0-3:8'
    >>> hr_range_formatter(start=0.1, end=3.1, step=1.0)
    '0.1-3.1:1'

    """
    ### Canonical solution below ###
    if int(start) == start:
        start = int(start)
    if int(end) == end:
        end = int(end)
    if int(step) == step:
        step = int(step)
    if int(start) == start and int(end) == end and step == 1:
        return '{}-{}'.format(start, end)
    return '{}-{}:{}'.format(start, end, step)


### Unit tests below ###
def check(candidate):
	assert candidate(start=0, end=10, step=0.5) == '0-10:0.5'
	assert candidate(1, 10, 2) == '1-10:2'
	assert candidate(0, 0, 8) == '0-0:8'
	assert candidate(3.1, 0.1, 1.0) == '3.1-0.1:1'
	assert candidate(start=0, end=10, step=2) == '0-10:2'
	assert candidate(start=0, end=10, step=1) == '0-10'
	assert candidate(10, 0, 1) == '10-0'
	assert candidate(0, 1, 8) == '0-1:8'
	assert candidate(0, 1, 10) == '0-1:10'
	assert candidate(0, 0, 1) == '0-0'
	assert candidate(1.1, 3.1, 1.0) == '1.1-3.1:1'
	assert candidate(0, 1, 2) == '0-1:2'
	assert candidate(1.0, 10, 2) == '1-10:2'
	assert candidate(3, 0, 8) == '3-0:8'
	assert candidate(0, 0, 100000) == '0-0:100000'
	assert candidate(0.1, 3.1, 1.0) == '0.1-3.1:1'
	assert candidate(0, 0, 20) == '0-0:20'
	assert candidate(0, 0, 10) == '0-0:10'
	assert candidate(1, 3, 8) == '1-3:8'
	assert candidate(0, 0, 100) == '0-0:100'
	assert candidate(1.0, 10.0, 1.0) == '1-10'
	assert candidate(10, 0, 2) == '10-0:2'
	assert candidate(0, 3, 8) == '0-3:8'
	assert candidate(start=0.1, end=3.1, step=1.0) == '0.1-3.1:1'
	assert candidate(1.0, 10, 1) == '1-10'
	assert candidate(0, 0, 2) == '0-0:2'
	assert candidate(1.0, 10.0, 2.0) == '1-10:2'
	assert candidate(start=0, end=10, step=0) == '0-10:0'
	assert candidate(start=0, end=10, step=1.5) == '0-10:1.5'
	assert candidate(0, 0, 10000) == '0-0:10000'
	assert candidate(0, 1, 100) == '0-1:100'
	assert candidate(start=0.1, end=3.1, step=1.8) == '0.1-3.1:1.8'
	assert candidate(0, 1, 1) == '0-1'
	assert candidate(0, 0, 1000) == '0-0:1000'
	assert candidate(1.0, 3.0, 8.0) == '1-3:8'
	assert candidate(0, 10, 1) == '0-10'
	assert candidate(1, 10, 1) == '1-10'
	assert candidate(0, 10, 2) == '0-10:2'
	assert candidate(start=0.1, end=3.1, step=1.5) == '0.1-3.1:1.5'
	assert candidate(start=0, end=10, step=10) == '0-10:10'
	assert candidate(start=0, end=3, step=8) == '0-3:8'
	assert candidate(start=0.1, end=3.1, step=1.1) == '0.1-3.1:1.1'
	assert candidate(0, 1, 20) == '0-1:20'
def test_check():
	check(hr_range_formatter)
