def _to_list(a):
    """convert value `a` to list

    Args:
        a: value to be convert to `list`

    Returns (list):

    """
    ### Canonical solution below ###
    if isinstance(a, (int, float)):
        return [a, ]
    else:
        # expected to be list or some iterable class
        return a


### Unit tests below ###
def check(candidate):
	assert candidate(1.) == [1.]
	assert candidate(2.3) == [2.3, ]
	assert candidate(1) == [1, ]
	assert candidate([1,2,3]) == [1,2,3]
	assert candidate(1) == [1]
	assert candidate(1.0) == [1.0]
	assert candidate(1.1) == [1.1, ]
	assert candidate(0) == [0, ]
	assert candidate(1.0) == [1.0, ]
	assert candidate([1, ]) == [1, ]
	assert candidate(1) == [1,]
	assert candidate([1, 2]) == [1, 2]
	assert candidate([0, 1]) == [0, 1]
	assert candidate([1]) == [1]
	assert candidate(0) == [0]
	assert candidate([1, 2, 3]) == [1, 2, 3]
def test_check():
	check(_to_list)
