def _get_max_size(x, y, map_info):
    """ 
     Get the size of the biggest square matrix in the map
     with first point: (x, y)
     
     Arguments:
     x -- column index
     y -- line index
     map_info -- a dict of the map and its information
     
     Returns:
     size -- biggest square matrix size
     """
	### Canonical solution below ###    
    x_max = map_info["line_len"]
    y_max = map_info["line_num"]
    return min(x_max-x, y_max-y)

### Unit tests below ###
def check(candidate):
	assert candidate(2, 1, {"line_num": 5, "line_len": 3}) == 1
	assert candidate(2, 2, {"line_len": 10, "line_num": 20}) == 8
	assert candidate(0, 0, {"line_num": 5, "line_len": 5}) == 5
	assert candidate(0, 0, {"line_num": 4, "line_len": 4}) == 4, "candidate(0, 0, map_info)!= 4"
	assert candidate(5, 0, {"line_num": 5, "line_len": 5}) == 0
	assert candidate(0, 3, {"line_num": 4, "line_len": 4}) == 1, "candidate(0, 3, map_info)!= 1"
	assert candidate(0, 0, {"line_len": 8, "line_num": 8}) == 8
	assert candidate(1, 3, {"line_len": 5, "line_num": 5}) == 2
	assert candidate(0, 5, {"line_num": 5, "line_len": 5}) == 0
	assert candidate(0, 5, {"line_len": 10, "line_num": 10}) == 5
	assert candidate(0, 0, {"line_len": 10, "line_num": 10}) == 10
	assert candidate(5, 0, {"line_len": 10, "line_num": 10}) == 5
	assert candidate(2, 2, {"line_len": 5, "line_num": 5}) == 3
	assert candidate(1, 1, {"line_len": 5, "line_num": 5}) == 4
	assert candidate(7, 7, {"line_len": 8, "line_num": 8}) == 1
	assert candidate(1, 0, {"line_num": 5, "line_len": 5}) == 4
	assert candidate(8, 5, {"line_len": 10, "line_num": 10}) == 2
	assert candidate(0, 0, {"line_len": 1, "line_num": 10}) == 1
	assert candidate(0, 0, {"line_len": 5, "line_num": 5}) == 5
	assert candidate(3, 3, {"line_num": 4, "line_len": 4}) == 1, "candidate(3, 3, map_info)!= 1"
	assert candidate(0, 0, {"line_len": 3, "line_num": 5}) == 3
	assert candidate(5, 8, {"line_len": 10, "line_num": 10}) == 2
	assert candidate(4, 4, {"line_len": 5, "line_num": 5}) == 1
	assert candidate(0, 0, {"line_len": 1, "line_num": 1}) == 1
	assert candidate(0, 1, {"line_num": 5, "line_len": 5}) == 4
	assert candidate(2, 2, {"line_len": 10, "line_num": 10}) == 8
	assert candidate(3, 0, {"line_num": 4, "line_len": 4}) == 1, "candidate(3, 0, map_info)!= 1"
	assert candidate(5, 4, {"line_len": 10, "line_num": 10}) == 5
	assert candidate(2, 4, {"line_len": 3, "line_num": 5}) == 1
def test_check():
	check(_get_max_size)
