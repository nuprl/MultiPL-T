def bytes2human(n, format='%(value).1f %(symbol)s', symbols='iec'):
    """ 
     Convert n bytes into a human readable string based on format.
     symbols can be either "customary", "customary_ext", "iec" or "iec_ext",
     see: http://goo.gl/kTQMs
     """
	### Canonical solution below ###    
    SYMBOLS = {
        'customary': ('B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'),
        'customary_ext': ('byte', 'kilo', 'mega', 'giga', 'tera', 'peta', 'exa', 'zetta', 'iotta'),
        'customary_with_B': ('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'),
        'iec': ('Bi', 'Ki', 'Mi', 'Gi', 'Ti', 'Pi', 'Ei', 'Zi', 'Yi'),
        'iec_ext': ('byte', 'kibi', 'mebi', 'gibi', 'tebi', 'pebi', 'exbi', 'zebi', 'yobi'),
        'iec_with_B': ('Bi', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'),
    }

    n = int(n)
    if n < 0:
        raise ValueError("n < 0")
    if "iec" in symbols:
        base = 1024
    else:
        base = 1000
    symbols = SYMBOLS[symbols]
    prefix = {}
    for i, s in enumerate(symbols):
        prefix[s] = base ** i
    for symbol in reversed(symbols):
        if n >= prefix[symbol]:
            value = float(n) / prefix[symbol]
            return format % locals()
    return format % dict(symbol=symbols[0], value=n)

### Unit tests below ###
def check(candidate):
	assert candidate(100001221, symbols="iec_with_B") == '95.4 MiB'
	assert candidate(9856, symbols="iec_ext") == '9.6 kibi'
	assert candidate(100001221, symbols="iec_ext") == '95.4 mebi'
	assert candidate(9856, symbols="iec") == '9.6 Ki'
	assert candidate(10000, "%(value).1f %(symbol)s/sec", symbols="iec") == '9.8 Ki/sec'
def test_check():
	check(bytes2human)
