def player_1_win_check (original_state,end_of_round_check,score,player_symbol): 
    """ 
     This function is used to iterate through each index of the list and check whether the player has entered an 'X' or 'O' in the following combination of indexes:
     [0,1,2] OR [3,4,5] OR [6,7,8] OR  [0,3,6] OR [1,4,7] 0R [2,5,8] OR [0,4,8] OR [2,4,6]
     If the player has fulfilled any one of the conditions, the score will be incremented by 1 
     
     Parameters:
     ------------
     original_state: List
     this is a list of string that contains the moves played by the player. 
     end_of_round_check: Boolean 
     this is to set whether this is the end of the current round
     score: integer
     incrementing the score of the player
     player_symbol: Str 
     passed as either 'X' or 'O' based on player
     
     Returns
     --------
     Array
     contains the check to end this round or continue, and player's score
     
     """
	### Canonical solution below ###
      
       
    if (player_symbol in  original_state[0] and player_symbol in  original_state[1] and player_symbol in original_state[2]) \
    or (player_symbol in  original_state[3] and player_symbol in  original_state[4] and player_symbol in original_state[5]) \
    or (player_symbol in  original_state[6] and player_symbol in  original_state[7] and player_symbol in original_state[8]) \
    or (player_symbol in  original_state[0] and player_symbol in  original_state[3] and player_symbol in original_state[6]) \
    or (player_symbol in  original_state[1] and player_symbol in  original_state[4] and player_symbol in original_state[7]) \
    or (player_symbol in  original_state[2] and player_symbol in  original_state[5] and player_symbol in original_state[8]) \
    or (player_symbol in original_state [0] and player_symbol in  original_state[4] and player_symbol in original_state[8]) \
    or (player_symbol in  original_state[2] and player_symbol in  original_state[4] and player_symbol in original_state[6]): 
        end_of_round_check = True #Set to True if player has met the condition   
        score += 1 #increase points of the player
    else:
        end_of_round_check = False #if player doesnt align any of his 'x' correctly, he should not get a point

    return end_of_round_check, score

### Unit tests below ###
def check(candidate):
	assert candidate(original_state = ['O','','O','','X','','X','',''],end_of_round_check = False,score = 0,player_symbol = 'X') == (False, 0)
	assert candidate(original_state = ['X','O','X','O','X','O','O','O','O'], end_of_round_check=False, score = 0, player_symbol = 'X') == (False, 0)
	assert candidate(original_state = ['X','X','X','O','O','X','O','O','X'], end_of_round_check=False,score=0,player_symbol='X') == (True, 1)
	assert candidate(original_state = ['O','X','X','O','O','X','O','O','X'], end_of_round_check=False,score=0,player_symbol='X') == (True, 1)
	assert candidate(['X', 'O', 'X', 'X', 'X', 'O', 'O', 'O', 'O'],False,0,'X') == (False, 0), "candidate function incorrect"
	assert candidate( ['X','X','O','O','X','O','X','O','X'],False,0,'O') == (False,0)
	assert candidate(original_state = ['X','O','X','O','X','O','X','O','X'], end_of_round_check=False, score = 0, player_symbol = 'X') == (True, 1)
	assert candidate(original_state = ['X','','','O','','','O','',''],end_of_round_check = False,score = 0,player_symbol = 'X') == (False, 0)
	assert candidate(original_state = ['x','o','','','','','','',''], end_of_round_check = False, score = 0, player_symbol = 'o') == (False, 0), "Test 2"
	assert candidate(['X', 'O', 'X', 'O', 'X', 'X', 'O', 'O', 'O'],False,0,'X') == (False, 0), "candidate function incorrect"
	assert candidate( ['X','O','O','X','X','X','O','X','O'], False, 0, 'O') == (False, 0)
	assert candidate(original_state = ['x', 'x', 'o', 'o', 'x', 'o', 'o', 'x', 'o'], end_of_round_check = False, score = 0, player_symbol = 'x') == (True, 1)
	assert candidate(original_state = ['x', 'o', 'x', 'o', 'x', 'o', 'o', 'x', 'o'], end_of_round_check = False, score = 0, player_symbol = 'x') == (False, 0)
	assert candidate(original_state= ['X', 'X', 'X', 'O', 'O', 'O', 'O', 'X', 'O'], end_of_round_check= True, score= 0, player_symbol= 'X') == (True, 1)
	assert candidate(original_state = ['','','','','x','','','o',''], end_of_round_check = False, score = 0, player_symbol = 'o') == (False, 0), "Test 4"
	assert candidate( ['X','O','O','X','X','X','O','X','X'], False, 0, 'X') == (True, 1)
	assert candidate(original_state= ['X', 'X', 'X', 'O', 'O', 'O', 'O', 'X', 'X'], end_of_round_check= False, score= 0, player_symbol= 'X') == (True, 1)
	assert candidate(original_state = ['x', 'o', 'x', 'x', 'x', 'o', 'o', 'x', 'o'], end_of_round_check = False, score = 0, player_symbol = 'x') == (False, 0)
	assert candidate(['X', 'O', 'O', 'X', 'O', 'X', 'X', 'X', 'O'],False,0,'X') == (True, 1), "candidate function incorrect"
	assert candidate( ['O','O','O','X','X','X','O','X','X'], False, 0, 'O') == (True, 1)
	assert candidate(original_state = ['','','','','','x','','o',''], end_of_round_check = False, score = 0, player_symbol = 'o') == (False, 0), "Test 6"
	assert candidate(['X', 'O', 'O', 'X', 'O', 'X', 'O', 'X', 'O'],False,0,'X') == (False, 0), "candidate function incorrect"
	assert candidate( ['X','X','O','O','X','O','X','O','X'],False,0,'X') == (True,1)
	assert candidate(original_state = ['X','X','X','O','O','X','O','O','X'], end_of_round_check=False,score=0,player_symbol='O') == (False, 0)
def test_check():
	check(player_1_win_check)
