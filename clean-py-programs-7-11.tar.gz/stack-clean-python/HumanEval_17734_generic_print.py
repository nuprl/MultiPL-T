def generic_print(expr):
    """Returns an R print statement for expr
    
    print("expr");
    """
    ### Canonical solution below ###
    return "print(\"{}\");".format(expr)


### Unit tests below ###
def check(candidate):
	assert candidate("1+1") == "print(\"1+1\");"
	assert candidate("a+b+c+d+e") == "print(\"a+b+c+d+e\");"
	assert candidate(1 + 2 + 3) == "print(\"6\");"
	assert candidate("a[1]") == "print(\"a[1]\");"
	assert candidate(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8) == "print(\"36\");"
	assert candidate("abc" + "def") == "print(\"abcdef\");"
	assert candidate("test\"") == "print(\"test\"\");"
	assert candidate("a+b+c+d+e+f") == "print(\"a+b+c+d+e+f\");"
	assert candidate("a+b") == "print(\"a+b\");"
	assert candidate(1.2) == "print(\"1.2\");"
	assert candidate(1 + 2 + 3 + 4 + 5 + 6 + 7) == "print(\"28\");"
	assert candidate(1 + 2 + 3 + 4 + 5) == "print(\"15\");"
	assert candidate("3.0e-1") == "print(\"3.0e-1\");"
	assert candidate(1 + 2 + 3 + 4 + 5 + 6) == "print(\"21\");"
	assert candidate("A") == "print(\"A\");"
	assert candidate(3) == "print(\"3\");"
	assert candidate("3.0e+1") == "print(\"3.0e+1\");"
	assert candidate(1) == "print(\"1\");"
	assert candidate(1.0) == "print(\"1.0\");"
	assert candidate(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10) == "print(\"55\");"
	assert candidate("3.0e0") == "print(\"3.0e0\");"
	assert candidate("a b") == "print(\"a b\");"
	assert candidate("Hello") == "print(\"Hello\");"
	assert candidate("hello world") == "print(\"hello world\");"
	assert candidate("a" + "b") == "print(\"ab\");"
	assert candidate("a") == "print(\"a\");"
	assert candidate("hello\nworld") == "print(\"hello\nworld\");"
	assert candidate("a+b+c") == "print(\"a+b+c\");"
	assert candidate('a') == 'print("a");'
	assert candidate(1 + 2) == "print(\"3\");"
	assert candidate(1 + 2 + 3 + 4) == "print(\"10\");"
	assert candidate(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9) == "print(\"45\");"
	assert candidate(3.0) == "print(\"3.0\");"
	assert candidate("3.0") == "print(\"3.0\");"
	assert candidate(1) == 'print("1");'
	assert candidate(1.2e-10) == "print(\"1.2e-10\");"
	assert candidate(123) == "print(\"123\");"
	assert candidate(2) == "print(\"2\");"
	assert candidate("hello") == "print(\"hello\");"
	assert candidate('foo') == "print(\"foo\");"
	assert candidate("hi\"") == "print(\"hi\"\");"
	assert candidate("a+b+c+d") == "print(\"a+b+c+d\");"
	assert candidate("1") == "print(\"1\");"
	assert candidate(1.1) == 'print("1.1");'
	assert candidate("3") == "print(\"3\");"
	assert candidate(1+1) == "print(\"2\");"
	assert candidate(1.1) == "print(\"1.1\");"
	assert candidate("hi") == "print(\"hi\");"
	assert candidate("abc") == "print(\"abc\");"
	assert candidate('"a"') == 'print("\"a\"");'
	assert candidate("test") == "print(\"test\");"
	assert candidate("foo") == "print(\"foo\");"
def test_check():
	check(generic_print)
