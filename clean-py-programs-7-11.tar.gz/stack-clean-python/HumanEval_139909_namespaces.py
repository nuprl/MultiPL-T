def namespaces(labels):
    """ 
     Converts fully-qualified names to a list of namespaces.
     namespaces(['clojure.core/map']) => ['clojure.core']
     """
	### Canonical solution below ###    
    return list(map(lambda label: label.split('/')[0], labels))

### Unit tests below ###
def check(candidate):
	assert candidate(
    ['clojure.core/map',
     'clojure.core/filter',
     'clojure.core/reduce']) == \
    ['clojure.core',
     'clojure.core',
     'clojure.core']
	assert candidate(
    ['clojure.core/map', 'clojure.core/filter', 'clojure.core/str']) == \
    ['clojure.core', 'clojure.core', 'clojure.core']
	assert candidate(
    ['clojure.core/map', 'clojure.core/filter', 'clojure.core/reduce']) == [
        'clojure.core', 'clojure.core', 'clojure.core']
	assert candidate(candidate(['clojure.core/map'])) == ['clojure.core']
	assert candidate(
    ['clojure.core/map', 'clojure.test/is', 'clojure.core/reduce']) == [
        'clojure.core', 'clojure.test', 'clojure.core']
	assert candidate(['clojure.core/map', 'clojure.test/is']) == ['clojure.core', 'clojure.test']
	assert candidate(['clojure.core/map', 'clojure.test/is']) == \
    ['clojure.core', 'clojure.test']
	assert candidate(
    ['clojure.core/map', 'clojure.core/filter', 'clojure.core/assoc']) == [
        'clojure.core', 'clojure.core', 'clojure.core']
	assert candidate(
    ['clojure.core/map', 'clojure.core/filter', 'clojure.core/reduce']) == [
    'clojure.core', 'clojure.core', 'clojure.core']
	assert candidate(['clojure.core/map', 'clojure/filter']) == ['clojure.core', 'clojure']
	assert candidate(
    ['clojure.core/map', 'clojure.data/map']) == ['clojure.core', 'clojure.data']
	assert candidate(
    ['clojure.core/map', 'clojure.core/reduce', 'clojure.core/conj']) == \
    ['clojure.core', 'clojure.core', 'clojure.core']
	assert candidate(['clojure.core/map', 'clojure.test/is']) == \
        ['clojure.core', 'clojure.test']
	assert candidate(['clojure.core/map']) == ['clojure.core']
	assert candidate(
    ['clojure.core/map', 'clojure.core/filter', 'clojure.core/map']) == \
        ['clojure.core', 'clojure.core', 'clojure.core']
	assert candidate(['clojure.core/map', 'clojure.string/join']) == \
    ['clojure.core', 'clojure.string']
	assert candidate(
    ['clojure.core/map', 'clojure.core/filter', 'clojure.core/map', 'clojure.core/reduce']) == \
    ['clojure.core', 'clojure.core', 'clojure.core', 'clojure.core']
	assert candidate(['clojure.core/map', 'clojure.core/filter']) == ['clojure.core', 'clojure.core']
	assert candidate(
    ['clojure.core/map', 'clojure.string/join', 'clojure.set/intersection']) == \
    ['clojure.core', 'clojure.string', 'clojure.set']
def test_check():
	check(namespaces)
