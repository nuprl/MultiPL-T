def width(grid):
    """Gets the width of a rectangular grid (stored row-major)."""
    ### Canonical solution below ###
    try:
        return len(grid[0])
    except IndexError:
        return 0


### Unit tests below ###
def check(candidate):
	assert candidate([[1]]) == 1
	assert candidate( [] ) == 0
	assert candidate(list()) == 0
	assert candidate([]) == 0
	assert candidate([[1, 2], [3, 4]]) == 2
	assert candidate( [[1, 2], [3]] ) == 2
def test_check():
	check(width)
