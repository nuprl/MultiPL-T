def fibonacci_dp(n):
    """Fibonacci series by bottom-up dynamic programming.

    - Time complexity: O(n).
    - Space complexity: O(n).
    """
    ### Canonical solution below ###
    T = [None] * (n + 1)
    T[0] = 0
    T[1] = 1
    for n in range(2, n + 1):
        T[n] = T[n - 1] + T[n - 2]
    return T[n]


### Unit tests below ###
def check(candidate):
	assert candidate(10) == 55
	assert candidate(22) == 17711
	assert candidate(4) == 3
	assert candidate(15) == 610
	assert candidate(11) == 89
	assert candidate(21) == 10946
	assert candidate(24) == 46368
	assert candidate(23) == 28657
	assert candidate(30) == 832040
	assert candidate(26) == 121393
	assert candidate(3) == 2
	assert candidate(19) == 4181
	assert candidate(5) == 5
	assert candidate(8) == 21
	assert candidate(13) == 233
	assert candidate(1) == 1
	assert candidate(16) == 987
	assert candidate(20) == 6765
	assert candidate(7) == 13
	assert candidate(18) == 2584
	assert candidate(6) == 8
	assert candidate(2) == 1
	assert candidate(17) == 1597
	assert candidate(14) == 377
	assert candidate(9) == 34
	assert candidate(12) == 144
	assert candidate(25) == 75025
def test_check():
	check(fibonacci_dp)
