def match_objs():
    """ Mock the results of an internal and an external match"""
	### Canonical solution below ###    
    matches = [
        {  # External match where test_patient is the query and with results
            "_id": "match_1",
            "has_matches": True,
            "data": {
                "patient": {"id": "P0001058", "contact": {"href": "mailto:test_contact@email.com"}}
            },
            "results": [
                {
                    "node": {"id": "test_node1", "label": "Test Node 1"},
                    "patients": [{"patient": {"id": "patient1"}}, {"patient": {"id": "patient2"}}],
                },
                {
                    "node": {"id": "test_node2", "label": "Test Node 2"},
                    "patients": [{"patient": {"id": "patient3"}}],
                },
            ],
            "match_type": "external",
        },
        {  # Internal match where test_patient is the query and there are no results
            "_id": "match_2",
            "has_matches": False,
            "data": {
                "patient": {"id": "P0001058"},
                "contact": {"href": "mailto:test_contact@email.com"},
            },
            "results": [
                {
                    "node": {"id": "patientMatcher", "label": "patientMatcher server"},
                    "patients": [{"patient": {"id": "int_patient_id"}}],
                }
            ],
            "match_type": "internal",
        },
        {  #  Internal match where test_patient is among results
            "_id": "match_3",
            "has_matches": True,
            "data": {
                "patient": {
                    "id": "external_patient_1",
                    "contact": {"href": "mailto:test_contact@email.com"},
                }
            },
            "results": [
                {
                    "node": {"id": "test_node1", "label": "Test Node 1"},
                    "patients": [
                        {
                            "patient": {
                                "id": "P0001058",
                                "contact": {"href": "mailto:test_contact2@email.com"},
                            }
                        }
                    ],
                }
            ],
            "match_type": "internal",
        },
    ]
    return matches

### Unit tests below ###
def check(candidate):
	assert candidate()[1]["results"][0]["node"]["id"] == "patientMatcher", "candidate should return a list of dicts"
	assert candidate()[1]["_id"] == "match_2", "candidate should return a list of dicts"
	assert candidate()[2]["has_matches"] == True, "candidate should return a list of dicts"
	assert candidate(
)[0]["results"][0]["node"]["id"] == "test_node1"
	assert candidate()[1]["data"]["patient"]["id"] == "P0001058"
	assert candidate()[1]["match_type"] == "internal"
	assert candidate(
)[0]["results"][0]["patients"][0]["patient"]["id"] == "patient1"
	assert candidate()[0]["match_type"] == "external"
	assert candidate()[0]["results"][0]["patients"][0]["patient"]["id"] == "patient1"
	assert candidate()[1]["data"]["patient"]["id"] == "P0001058", "candidate should return a list of dicts"
	assert candidate(
)[2]["results"][0]["patients"][0]["patient"]["contact"]["href"] == "mailto:test_contact2@email.com"
	assert candidate()[0]["has_matches"] == True, "candidate should return a list of dicts"
	assert candidate()[2]["data"]["patient"]["id"] == "external_patient_1"
	assert candidate(
)[0]["has_matches"] is True
	assert candidate(
)[2]["results"][0]["node"]["id"] == "test_node1"
	assert candidate(
)[0]["data"]["patient"]["id"] == "P0001058"
	assert candidate()[2]["results"][0]["patients"][0]["patient"]["id"] == "P0001058"
	assert candidate()[1]["has_matches"] == False, "candidate should return a list of dicts"
	assert candidate(
)[2]["data"]["patient"]["id"] == "external_patient_1"
	assert candidate()[0]["results"][0]["node"]["id"] == "test_node1", "candidate should return a list of dicts"
	assert candidate(
)[2]["has_matches"] is True
	assert candidate(
)[0]["_id"] == "match_1", "candidate should return a list of dicts"
	assert candidate()[0]["data"]["patient"]["id"] == "P0001058"
	assert candidate()[0]["results"][0]["patients"][0]["patient"]["id"] == "patient1", "candidate should return a list of dicts"
	assert candidate(
)[0] == {  # External match where test_patient is the query and with results
    "_id": "match_1",
    "has_matches": True,
    "data": {
        "patient": {"id": "P0001058", "contact": {"href": "mailto:test_contact@email.com"}}
    },
    "results": [
        {
            "node": {"id": "test_node1", "label": "Test Node 1"},
            "patients": [{"patient": {"id": "patient1"}}, {"patient": {"id": "patient2"}}],
        },
        {
            "node": {"id": "test_node2", "label": "Test Node 2"},
            "patients": [{"patient": {"id": "patient3"}}],
        },
    ],
    "match_type": "external",
}
	assert candidate()[1]["results"][0]["node"]["id"] == "patientMatcher"
	assert candidate()[1]["results"][0]["patients"][0]["patient"]["id"] == "int_patient_id"
	assert candidate(
)[0]["_id"] == "match_1"
	assert candidate()[2]["match_type"] == "internal"
	assert candidate()[1]["has_matches"] == False
	assert candidate()[0]["data"]["patient"]["id"] == "P0001058", "candidate should return a list of dicts"
	assert candidate(
)[1]["data"]["patient"]["id"] == "P0001058"
	assert candidate(
)[1]["results"][0]["node"]["id"] == "patientMatcher"
	assert candidate(
)[1]["results"][0]["patients"][0]["patient"]["id"] == "int_patient_id"
	assert candidate()[2]["_id"] == "match_3"
	assert candidate(
)[2]["results"][0]["patients"][0]["patient"]["id"] == "P0001058"
	assert candidate()[2]["_id"] == "match_3", "candidate should return a list of dicts"
	assert candidate()[2]["results"][0]["node"]["id"] == "test_node1"
	assert candidate()[1]["results"][0]["patients"][0]["patient"]["id"] == "int_patient_id", "candidate should return a list of dicts"
	assert candidate()[2]["has_matches"] == True
	assert candidate()[0]["has_matches"] == True
	assert candidate()[1]["_id"] == "match_2"
	assert candidate(
)[1]["has_matches"] is False
	assert candidate()[0]["results"][0]["node"]["id"] == "test_node1"
def test_check():
	check(match_objs)
