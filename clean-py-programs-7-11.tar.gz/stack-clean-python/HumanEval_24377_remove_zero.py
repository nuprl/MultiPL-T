def remove_zero(number: str) -> str:
    """
    :param number:
    :return:
    """
    ### Canonical solution below ###
    if number.startswith("0") and number.endswith("0"):
        return "0"
    elif number.startswith("0"):
        return number.replace("0", "")
    else:
        return number


### Unit tests below ###
def check(candidate):
	assert candidate(number="100000") == "100000"
	assert candidate(number="001") == "1"
	assert candidate(number="000") == "0"
	assert candidate(number="123") == "123"
	assert candidate(number="00000123456") == "123456"
	assert candidate(number="123456") == "123456"
	assert candidate(number = "00") == "0"
	assert candidate(number="1200") == "1200"
	assert candidate(number="0001") == "1"
	assert candidate(number="000000") == "0"
	assert candidate(number="12") == "12"
	assert candidate(number="000123456") == "123456"
	assert candidate(number="000001") == "1"
	assert candidate(number="10") == "10"
	assert candidate(number="000000000") == "0"
	assert candidate(number="120000") == "120000"
	assert candidate(number="00000000") == "0"
	assert candidate(number = "100") == "100"
	assert candidate(number="01") == "1"
	assert candidate(number = "1010") == "1010"
	assert candidate(number="1000000") == "1000000"
	assert candidate(number="00000") == "0"
	assert candidate(number="12000") == "12000"
	assert candidate(number="10000") == "10000"
	assert candidate(number="1200000") == "1200000"
	assert candidate(number="0000000") == "0"
	assert candidate(number="12345") == "12345"
	assert candidate(number="0000123456") == "123456"
	assert candidate(number="000000123456") == "123456"
	assert candidate(number="000000000123456") == "123456"
	assert candidate(number="0000") == "0"
	assert candidate(number="0") == "0"
	assert candidate(number = "0") == "0"
	assert candidate(number="0123456") == "123456"
	assert candidate(number="0000000123456") == "123456"
	assert candidate(number="120") == "120"
	assert candidate(number="00000000123456") == "123456"
	assert candidate(number="00123456") == "123456"
	assert candidate(number="1000") == "1000"
	assert candidate(number="100") == "100"
	assert candidate(number="1") == "1"
	assert candidate(number="00") == "0"
def test_check():
	check(remove_zero)
