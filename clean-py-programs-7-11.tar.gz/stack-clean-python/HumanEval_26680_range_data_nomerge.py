def range_data_nomerge(main_data, added_data):
    """ 
     Take main data and then update clusters with the added data only if they do
     not already exist.  Return only the valid clusters (not full set)
     """
	### Canonical solution below ###  
  ret_data = {}
  for cluster in added_data:
    if main_data.get(cluster) is None:
      ret_data[cluster] = added_data[cluster]

  return ret_data

### Unit tests below ###
def check(candidate):
	assert candidate(
  {'a': 1, 'b': 2, 'c': 3, 'd': 4},
  {'a': 10, 'e': 20, 'f': 30}
  ) == {'e': 20, 'f': 30}
	assert candidate(
  {'a': 1, 'b': 2, 'c': 3, 'd': 4},
  {'a': 10, 'b': 20, 'e': 30, 'f': 40}
  ) == {'e': 30, 'f': 40}
	assert candidate(
  {"cluster1": {"cluster_size": 200, "range_data": {"start": 10, "end": 100}}},
  {"cluster1": {"cluster_size": 300, "range_data": {"start": 50, "end": 150}}}
) == {}
	assert candidate(
  {'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9]},
  {'A': [1, 2, 3], 'B': [4, 5, 6]}
) == {}
	assert candidate(
  {
    '0': {'range': 1, 'total': 2, 'count': 2},
    '1': {'range': 1, 'total': 2, 'count': 2}
  },
  {
    '0': {'range': 1, 'total': 2, 'count': 2},
    '1': {'range': 1, 'total': 2, 'count': 2}
  }) == {}
	assert candidate(
  {1: (1, 5)},
  {1: (2, 5)}
) == {}
	assert candidate(
  {1: (1, 5)},
  {1: (1, 4)}
) == {}
	assert candidate(
  {1: [1,2,3], 2: [4,5,6]},
  {1: [1,2,3], 2: [4,5,6]}
) == {}
	assert candidate(
  {'A': {'a': {'1': 1, '2': 2, '3': 3}, 'b': {'4': 4, '5': 5, '6': 6}}},
  {'A': {'a': {'1': 1, '2': 2, '3': 3}, 'b': {'4': 4, '5': 5, '6': 6}, 'c': {'7': 7, '8': 8, '9': 9}}}
) == {}
	assert candidate(
  {1: (1, 5)},
  {1: (1, 5)}
) == {}
	assert candidate({}, {'a': 1}) == {'a': 1}
	assert candidate(
  {'a': 1, 'b': 2, 'c': 3, 'd': 4},
  {'a': 10, 'b': 20, 'c': 30, 'd': 40, 'e': 50, 'f': 60}
  ) == {'e': 50, 'f': 60}
	assert candidate({'a': 1}, {'a': 1}) == {}
	assert candidate(
  {'cluster1': {'data': [1, 2, 3], 'range': [0, 3]}},
  {'cluster1': {'data': [1, 2, 3], 'range': [0, 3]}}
) == {}
	assert candidate(
  {
    '0': {'range': 1, 'total': 2, 'count': 2},
    '1': {'range': 1, 'total': 2, 'count': 2},
    '2': {'range': 1, 'total': 2, 'count': 2},
  },
  {
    '0': {'range': 1, 'total': 2, 'count': 2},
    '1': {'range': 1, 'total': 2, 'count': 2},
  }) == {}
	assert candidate(
  {1: (1, 5)},
  {1: (4, 6)}
) == {}
	assert candidate(
  {
    '0': {'range': 1, 'total': 2, 'count': 2},
    '1': {'range': 1, 'total': 2, 'count': 2}
  },
  {
    '0': {'range': 1, 'total': 2, 'count': 2},
    '1': {'range': 1, 'total': 2, 'count': 2},
    '2': {'range': 1, 'total': 2, 'count': 2},
  }) == {
    '2': {'range': 1, 'total': 2, 'count': 2}
  }
	assert candidate(
  {'cluster1': {'data': [1, 2, 3], 'range': [0, 3]}},
  {'cluster2': {'data': [1, 2, 3], 'range': [0, 3]}}
) == {'cluster2': {'data': [1, 2, 3], 'range': [0, 3]}}
	assert candidate({}, {}) == {}
	assert candidate(
  {'cluster_1': {'1': 'a', '2': 'b'}, 'cluster_2': {'3': 'c'}},
  {'cluster_1': {'1': 'a', '2': 'b'}, 'cluster_2': {'3': 'c'}, 'cluster_3': {'4': 'd'}}
) == {'cluster_3': {'4': 'd'}}
	assert candidate(
  {'a': 1, 'b': 2, 'c': 3, 'd': 4},
  {'a': 10, 'b': 20, 'c': 30, 'e': 40, 'f': 50}
  ) == {'e': 40, 'f': 50}
	assert candidate(
  {'a': {'min': 1,'max': 10}, 'b': {'min': 1,'max': 10}},
  {'a': {'min': 1,'max': 10}, 'c': {'min': 1,'max': 10}}
) == {'c': {'min': 1,'max': 10}}
	assert candidate(
  {'cluster_1': {'1': 'a', '2': 'b'}, 'cluster_2': {'3': 'c'}},
  {'cluster_1': {'1': 'a', '2': 'b'}, 'cluster_2': {'3': 'c'}}
) == {}
	assert candidate(
  {"cluster1": {"cluster_size": 200, "range_data": {"start": 10, "end": 100}}},
  {"cluster2": {"cluster_size": 300, "range_data": {"start": 50, "end": 150}}}
) == {"cluster2": {"cluster_size": 300, "range_data": {"start": 50, "end": 150}}}
def test_check():
	check(range_data_nomerge)
