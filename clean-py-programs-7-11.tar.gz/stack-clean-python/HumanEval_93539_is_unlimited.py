def is_unlimited(rate_limit):
    """ 
     Check whether a rate limit is None or unlimited (indicated by '-1').
     
     :param rate_limit: the rate limit to check
     :return: bool
     """
	### Canonical solution below ###    
    return rate_limit is None or rate_limit == -1

### Unit tests below ###
def check(candidate):
	assert not candidate(10)
	assert candidate(0) == False
	assert candidate(-1)
	assert not candidate(100)
	assert not candidate(0)
	assert candidate(None)
	assert not candidate("foo")
	assert candidate(10) is False
	assert candidate(None) is True
	assert not candidate(1)
	assert candidate(100) == False
	assert candidate(1) is False
	assert candidate(1000) is False
	assert not candidate(5)
	assert candidate(-1) is True
	assert candidate(10) == False
	assert candidate(None) == True
	assert candidate(-1) == True
def test_check():
	check(is_unlimited)
