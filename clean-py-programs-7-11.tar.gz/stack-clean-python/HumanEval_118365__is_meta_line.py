def _is_meta_line(line):
    """ Check if a line is a meta line or a data line"""
	### Canonical solution below ###    
    return line[:9] == "fixedStep" or line[:12] == "variableStep"

### Unit tests below ###
def check(candidate):
	assert candidate("variableStep chrom=chr1 span=1000000")
	assert candidate(
    "variableStep chrom=chr1 span=100000") == True
	assert candidate( "variableStep chrom=chr1 start=10" ) == True
	assert candidate(u'variableStep chrom=chr1 span=10000')
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=100000 span=100000") == True
	assert not candidate("##reference=file:///seq/references/1000GenomesPilot-NCBI36.fasta")
	assert candidate("variableStep chrom=chr1 span=10000000")
	assert candidate(
    "fixedStep chrom=chr10 start=10 step=10000 span=10000")
	assert not candidate(b"chr1\t10\t20\t1")
	assert not candidate("chr1\t10000000\t0\t0\t20")
	assert not candidate("chr10\t10\t10000")
	assert candidate(
    "fixedStep chrom=chr1 start=100 step=10000") == True
	assert candidate(
    "chrom=chr1\n") == False
	assert candidate( "fixedStep chrom=chr10 start=100 step=2" ) == True
	assert candidate( "fixedStep chrom=chr1" )
	assert candidate(
    "variableStep chrom=chr1 span=100000000") == True
	assert candidate( "fixedStep chrom=chr1 start=10 step=2 span=2" ) == True
	assert candidate(r"chrom=chr1 start=1 step=1") == False
	assert not candidate("chr20\t100\t1000\t10000\t100000\n")
	assert not candidate(b"chr1\t10\t100")
	assert candidate( "variableStep chrom=chr10 start=100" ) == True
	assert candidate(line="fixedStep")
	assert candidate( "variableStep chrom=chr10 start=100 step=2" ) == True
	assert candidate("variableStep chrom=chr20 span=1000000")
	assert not candidate( "chr1\t200" )
	assert candidate(
    "variableStep chrom=chr1\n") == True
	assert candidate( "fixedStep chrom=chr1 start=10" ) == True
	assert candidate( "variableStep chrom=chr1" )
	assert not candidate(b"# comment")
	assert candidate( "fixedStep chrom=chr10" ) == True
	assert candidate( "fixedStep chrom=chr1" ) == True
	assert candidate( "fixedStep" ) == True
	assert not candidate("##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Total Depth\">")
	assert not candidate(b"")
	assert candidate( "fixedStep chrom=chr1 start=10 step=2" ) == True
	assert not candidate(b"fixedStep\tchrom=chr1\tstart=100")
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=10000000 span=100000000.0") == True
	assert candidate(u'fixedStep chrom=chr1 start=1 step=10000')
	assert not candidate(b"chr1\t10\t100\tA")
	assert candidate( "fixedStep")
	assert not candidate("##INFO=<ID=AA,Number=1,Type=String,Description=\"Ancestral Allele\">")
	assert candidate(
    "chrom=chr1 start=100 step=10000\n") == False
	assert not candidate("chr2\t1000\t100100\t1")
	assert not candidate(b"foo")
	assert candidate(r"fixedStep chrom=chr1 start=1 step=1") == True
	assert candidate(r"variableStep chrom=chr1") == True
	assert not candidate(b"##")
	assert candidate( "fixedStep\tchrom=chr1")
	assert not candidate( "chr1\t200\t300" )
	assert candidate(
    "fixedStep\tchrom=chr2\tstart=1\tstep=1\tspan=1")
	assert not candidate("chr20\t100\t1000\t10000\t100000")
	assert candidate( "hello" ) == False
	assert not candidate(b"variableStep\tchrom=chr1")
	assert candidate("Hello World") == False
	assert not candidate("##INFO=<ID=NS,Number=1,Type=Integer,Description=\"Number samples with data\">")
	assert not candidate("track name=test")
	assert candidate(
    "chrom=chr1 start=100 step=10000") == False
	assert candidate(
    "other line") == False
	assert candidate( "variableStep chrom=chr10" ) == True
	assert not candidate("##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">")
	assert candidate(
    "variableStep chrom=chr2 span=1")
	assert candidate( "variableStep chrom=chr1 start=10 step=2 span=2" ) == True
	assert candidate(
    "fixedStep chrom=chr20 start=100 step=100 span=1000000")
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=10000000") == True
	assert candidate("variableStep chrom=chr1")
	assert candidate( "variableStep chrom=chr1 start=10 step=2" ) == True
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=10000000 span=10000000")
	assert candidate(
    "variableStep chrom=chr10 start=1") == True
	assert candidate(
"""fixedStep chrom=chr1 start=1 step=10
""")
	assert candidate( "variableStep chrom=chr10 start=100 step=2 span=5" ) == True
	assert not candidate( "data\tchrom=chr1")
	assert not candidate("chr1\t1\t1000000\t1.0")
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=20000 span=100000000") == True
	assert not candidate("##INFO=<ID=H2,Number=0,Type=Flag,Description=\"HapMap2 membership\">")
	assert candidate( "variableStep\tchrom=chr1")
	assert not candidate("chr1\t10000\t10010\t12\t23,45,67,89\t100\t.")
	assert not candidate("##INFO=<ID=DB,Number=0,Type=Flag,Description=\"dbSNP membership, build 129\">")
	assert candidate(u"fixedStep")
	assert not candidate("chr1\t1\t100\t1")
	assert not candidate(line="hello world")
	assert not candidate("##source=myImputationProgramV3.1")
	assert not candidate(b"chr1\t10\t20\t1\n")
	assert candidate(
    "variableStep chrom=chr1 span=1000000") == True
	assert not candidate("##contig=<ID=chr1,length=248956422>")
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=10000000 span=100000000.0")
	assert not candidate(u'chr1\t10000\t.\tA\tG')
	assert candidate(
"""variableStep chrom=chr1
""")
	assert candidate( "variableStep" ) == True
	assert candidate( "fixedStep chrom=chr10 start=100 step=2 span=5" ) == True
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=1000000") == True
	assert not candidate( "data")
	assert candidate(
    "fixedStep chrom=chr2 start=1000 step=10000")
	assert candidate(
    "fixedStep chrom=chr1 start=1 step=1000000 span=1000000")
	assert not candidate("chr1\t1\t1000\tA\tT")
	assert candidate( "variableStep chrom=chr1" ) == True
	assert not candidate("##INFO=<ID=AF,Number=A,Type=Float,Description=\"Allele Frequency\">")
	assert candidate(
    "chr1\t100000") == False
	assert candidate(
    "variableStep chrom=chr1 span=100000000.0") == True
	assert candidate( "fixedStep chrom=chr10 start=100" ) == True
	assert candidate(
    "fixedStep chrom=chr1 start=100 step=10000\n") == True
	assert not candidate("chr1\t10000000\t0\t0")
def test_check():
	check(_is_meta_line)
