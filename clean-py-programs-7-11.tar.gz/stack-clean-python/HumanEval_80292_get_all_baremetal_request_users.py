def get_all_baremetal_request_users():
    """ 
     ONLY for test
     """
	### Canonical solution below ###    
    return ["test"]

### Unit tests below ###
def check(candidate):
	assert candidate(
) == ["test"], "candidate failed"
	assert candidate(
) == ["test"]
	assert candidate(
) == ["test"], "candidate test failed"
	assert candidate(
) == ["test"], "test_candidate failed"
	assert candidate(
) == ["test"], "Test failed: candidate()"
	assert candidate(
) == ["test"], "candidate() test failed"
	assert candidate(
) == ['test']
	assert candidate(
    ) == ["test"]
def test_check():
	check(get_all_baremetal_request_users)
