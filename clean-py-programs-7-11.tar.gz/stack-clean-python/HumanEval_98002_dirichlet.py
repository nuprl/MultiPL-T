def dirichlet(x):
    """ return a harmonic function"""
	### Canonical solution below ###    
    return ((x[0] + 1.j * x[1]) ** 2).real

### Unit tests below ###
def check(candidate):
	assert candidate([1, 1]) == 0.
	assert candidate([0, 0]) == 0
	assert candidate([1, -1]) == 0.
	assert candidate([-1, 1]) == 0.
def test_check():
	check(dirichlet)
