def char_count( text, ignore_spaces=True):
    """
    Function to return total character counts in a text,
    pass the following parameter `ignore_spaces = False`
    to ignore whitespaces
    """
    ### Canonical solution below ###
    if ignore_spaces:
        text = text.replace(" ", "")
    return len(text)


### Unit tests below ###
def check(candidate):
	assert candidate( "abc ", True) == 3, "abc should have 3 characters"
	assert candidate( "I love Python") == 11
	assert candidate( "hello") == 5
	assert candidate( "I love Python", ignore_spaces=False) == 13
	assert candidate( " Hello, World!" ) == 12
	assert candidate( "Hello World! ", False ) == 13
	assert candidate( "Test", False ) == 4
	assert candidate( "Hello") == 5
	assert candidate( "Hello World", False) == 11
	assert candidate( "Hello", False) == 5
	assert candidate( "Hello, World! " ) == 12
	assert candidate( "abc  ") == 3
	assert candidate( "Hello, World") == 11
	assert candidate( " Hello World!", False ) == 13
	assert candidate( "abc") == 3
	assert candidate( "abc") == 3, "abc should have 3 characters"
	assert candidate( "abc  ", True) == 3, "abc should have 3 characters"
	assert candidate( "Hello World", True) == 10
	assert candidate("") == 0
	assert candidate( "abc  ") == 3, "abc should have 3 characters"
	assert candidate( "") == 0
	assert candidate( "Hello, World", False) == 12
	assert candidate( "Test" ) == 4
def test_check():
	check(char_count)
