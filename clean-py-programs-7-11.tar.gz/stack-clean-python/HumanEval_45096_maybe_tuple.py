def maybe_tuple(data):
    """Returns `tuple(data)` if :attr:`data` contains more than 1 elements.

    Used to wrap `map_func` inputs.
    """
    ### Canonical solution below ###
    data = tuple(data)
    data = data if len(data) > 1 else data[0]
    return data


### Unit tests below ###
def check(candidate):
	assert candidate((1, 2, 3)) == (1, 2, 3)
	assert candidate([1]) == 1
	assert candidate(range(2)) == (0, 1)
	assert candidate((1,2,3)) == (1,2,3)
	assert candidate(((1, 2), (3, 4))) == ((1, 2), (3, 4))
	assert candidate([[1], [2]]) == ([1], [2])
	assert candidate((1, (2, 3))) == (1, (2, 3))
	assert candidate([[1, 2], [3, 4]]) == ([1, 2], [3, 4])
	assert candidate([1,2,3]) == (1,2,3)
	assert candidate([1,2,3,4,5]) == (1,2,3,4,5)
	assert candidate(range(3)) == (0, 1, 2)
	assert candidate([1, 2]) == (1, 2)
	assert candidate((0, 1)) == (0, 1)
	assert candidate(range(1)) == 0
	assert candidate([1, 2, 3]) == (1, 2, 3)
	assert candidate((1,)) == 1
	assert candidate((1, 2)) == (1, 2)
def test_check():
	check(maybe_tuple)
