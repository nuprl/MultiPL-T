def check_if_numbers_are_consecutive(list_):
    """ 
     Returns True if numbers in the list are consecutive
     :param list_: list of integers
     :return: Boolean
     """
	### Canonical solution below ###    
    return all((True if second - first == 1 else False
                for first, second in zip(list_[:-1], list_[1:])))

### Unit tests below ###
def check(candidate):
	assert not candidate([1, 2, 4, 6])
	assert candidate(range(10)) is True
	assert candidate(list_=[1, 2, 3, 5, 6, 8]) == False
	assert candidate(list_=[1, 2, 3, 4]) == True
	assert candidate(list_=[1, 2, 3, 4, 6]) is False
	assert candidate(list_=list(range(1000000))) is True
	assert candidate(range(1, 10, 2)) is False
	assert candidate(list_=list(range(10))) == True
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 9, 10]) == False, "Seventh example"
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
	assert candidate(list_=[1, 2, 3, 4, 5]) == True
	assert candidate(list(range(10))) is True
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20])
	assert candidate(list_=[1]) is True
	assert candidate(list_=[1, 2, 3, 4]) is True
	assert candidate(list_=[1, 2, 3, 4, 5, 6]) == True
	assert candidate([0, 1, 2, 3, 5, 6, 8, 9, 10]) == False
	assert candidate(list_=list(range(100000))) is True
	assert candidate(list_=list(range(10))) is True
	assert candidate(list(range(1, 100))) is True
	assert candidate(list_=list(range(1, 1000000))) is True
	assert not candidate([1, 2, 3, 4, 5, 6, 7, 9])
	assert candidate(list(range(10))) == True
	assert not candidate([1, 2, 3, 4, 5, 6, 8])
	assert candidate([0, 2, 4, 5, 6, 8, 9]) == False
	assert candidate(list_=list()) == True
	assert candidate(range(0, 10, 3)) is False
	assert candidate(list_=list(range(1, 10, 4))) is False
	assert candidate(list_=[1, 2, 3, 5]) == False
	assert candidate(
    [1, 2, 3, 4, 6]) is False
	assert candidate(list(range(2, 10, 2))) is False
	assert candidate(
    [1, 2, 3, 4, 5]) is True
	assert candidate([]) is True
	assert candidate([1]) is True
	assert candidate(list_=[-10, -9, -8, -7, -6, -5, -4, -3, 0]) == False
	assert candidate(list_=[1]) == True
	assert candidate(list_=list(range(1, 100))) is True
	assert not candidate([1, 2, 3, 4, 5, 6, 7, 9, 10])
	assert candidate(list_=[1, 2, 3, 4, 5, 6, 8]) == False
	assert candidate(list(range(100, 1, -2))) is False
	assert candidate(list_=[1, 2, 3, 4, 5, 6, 8, 10]) == False
	assert candidate(list_=[]) == True
	assert candidate(list_=[10, 9, 8, 7, 6, 5, 4, 3, 2]) == False
	assert candidate(list_=[-10, -9, -8, -7, -6, -5, -4, -3]) == True
	assert candidate([1, 3, 4, 6, 7, 8, 9, 10]) is False
	assert candidate(
    [1, 2, 3, 4, 6]) == False, "Second example"
	assert candidate(list_=[1, 2, 3, 4, 6]) == False
	assert candidate(list_=[10, 9, 8, 7, 6, 5, 4, 3]) == False
	assert candidate(list_=list(range(10000000))) is True
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12]) == False
	assert candidate(list_=[]) is True
	assert not candidate([1, 2, 3, 4, 5, 6, 7, 8, 10])
	assert candidate(list_=list(range(1, 100000))) is True
	assert candidate(list_=list(range(1, 10, 3))) is False
	assert candidate(list_=list(range(1, 10, 6))) is False
	assert candidate(list_=[10, 1, 2, 3, 4, 5, 6, 7]) == False
	assert candidate(list(range(10000))) == True
	assert not candidate([1, 2, 3, 4, 5, 6, 8, 9, 10])
	assert candidate(range(1, 10)) is True
	assert candidate(list_=[1, 2]) is True
	assert candidate(list_=list(range(1, 10, 10))) is True
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13])
	assert candidate(
    [1, 2, 3, 4, 5]) == True, "First example"
	assert candidate(list_=[1, 1, 1, 1, 1, 1, 2]) == False
	assert candidate(list_=[1, 2]) == True
	assert candidate(list(range(1, 10))) == True
	assert candidate(list(range(1, 10))) is True
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 11]) == False
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
	assert candidate([1, 3, 4, 6, 7, 8, 9, 10, 12]) is False
	assert candidate(list_=list(range(1, 10000))) is True
	assert candidate([1, 2, 3, 4])
	assert candidate(list_=list(range(1, 10, 5))) is False
	assert candidate(list_=[-10, -9, -8, -7, -6, -5, -4, -2]) == False
	assert candidate(list_=list(range(100))) is True
	assert candidate(list_=list(range(10)))
	assert candidate(list_=[1, 2, 2, 3]) is False
	assert candidate(list_=list(range(1000))) is True
	assert candidate(list(range(1, 10, 3))) == False
	assert candidate(list_=list(range(1, 1000))) is True
	assert candidate(list_=list(range(10000))) is True
	assert candidate(list(range(1, 10, 4))) == False
	assert candidate(list_=list(range(2, 10)))
	assert not candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13])
	assert candidate(list_=[1, 2, 3]) == True
	assert candidate(
    [-3, -2, -1, 1, 2, 4]) == False, "Fifth example"
	assert candidate(list_=[1, 2, 3, 5, 6, 7]) == False
	assert candidate(list(range(100))) is True
	assert candidate(list_=[1, 2, 3, 4, 5, 7]) == False
	assert candidate(list_=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == True
	assert candidate(list_=[1, 2, 3, 4, 5, 6, 7, 8]) == True
	assert candidate([0, 1, 2, 3, 4, 5, 6, 8, 9, 10]) == False
	assert not candidate([1, 2, 3, 5])
	assert candidate(list_=[-3, -2, -1, 0, 1]) == True
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == True
	assert not candidate(list_=list(range(0, 10, 2)))
	assert candidate([1, 2, 3]) is True
	assert candidate(list_=[1, 2, 3, 4, 5]) is True
	assert candidate(list(range(10)))
	assert not candidate(list_=list(range(1, 10, 2)))
	assert candidate(list_=[1, 2, 3]) is True
	assert candidate(list_=list(range(1, 10))) is True
	assert candidate(list_=list(range(1, 10, 8))) is False
	assert candidate(
    [1000, 1001, 1002]) == True, "Sixth example"
	assert candidate(list_=list(range(1, 10, 7))) is False
	assert candidate(list_=[1, 2, 3, 4, 5, 6, 7, 6]) == False
	assert not candidate([1, 2, 3, 4, 6, 7, 8, 9, 10])
	assert candidate(list_=[1, 2, 3, 4, 5, 6, 7]) == True
	assert not candidate([1, 2, 3, 4, 5, 7, 8, 9, 10])
	assert candidate(list(range(1000000))) == True
def test_check():
	check(check_if_numbers_are_consecutive)
