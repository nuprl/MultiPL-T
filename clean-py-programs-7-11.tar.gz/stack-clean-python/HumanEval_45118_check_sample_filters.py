def check_sample_filters(sample, project):
    """
    :param sample:
    :param project:
    :return:
    """
    ### Canonical solution below ###
    if project == 'ENCODE':
        bt = sample['biosample_type']
        if bt.startswith('immortal') or bt.startswith('in vitro'):
            return False
        btn = (sample['biosample_term_name']).lower()
        if btn == 'naive b cell':
            return False
        if any([x in btn for x in ['right', 'left', 'female', 'fat',
                                   'induced', 'inferior', 'superior',
                                   'uterus', 'putamen', 'l1-s8', 'gland',
                                   'testis', 'ovary', 'prostate', 'psoas',
                                   'horn', 'pons', 'gyrus', 'nucleus', 'pedal',
                                   'abdomen', 'amnion', 'chorion', 'amniotic',
                                   'mononuclear', 'langerhans', 'cortex', 'cortical',
                                   'occipital', 'pallidus', 'olfactory', 'hematopoietic',
                                   'telencephalon']]):
            return False
        if 'fibroblast' in btn and 'product_id' in sample:
            # numerous fibroblast cell lines
            return False
        if 'life_stage' in sample:
            ls = (sample['life_stage']).lower()
            if any([x in ls for x in ['adult', 'unknown']]):
                return True
        return False
    elif project == 'Roadmap Epigenomics':
        bt = sample['TYPE']
        if bt in ['CellLine', 'ESCDerived']:
            return False
        if 'AGE' in sample:
            age = (sample['AGE']).lower()
            if any([x in age for x in ['fetus', 'child', 'postnatal',
                                       '0y', 'newborn', 'fetal']]):
                return False
        edn = (sample['EDACC_NAME']).lower()
        if any([x in edn for x in ['fetal', 'stimulated', 'gm12878',
                                   'k562', 'induced']]):
            return False
        std = (sample['STD_NAME']).lower()
        if any([x in std for x in ['ips', 'neurospheres', 'derived',
                                   'variant', 'left', 'right', 'nuclei',
                                   'psoas', 'gyrus', 'pedal', 'imr90',
                                   'abdomen', 'amnion', 'chorion']]):
            return False
        return True
    else:
        raise ValueError('Unknown project: {}'.format(project))


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'immortalized cell line'},
    'ENCODE'
) is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(sample=dict(biosample_type='immortalized cell line'), project='ENCODE') is False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells', 'biosample_term_name': 'naive b cell',
     'product_id': 'ENCDO123ABC'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell line', 'biosample_term_name': 'B cell'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell'}, project='ENCODE') == False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B cells'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell line', 'biosample_term_name': 'naive B cell', 'product_id': 'naive-B-cell'},
    'ENCODE') is False
	assert candidate(sample=dict(biosample_type='cell line', biosample_term_name='naive B cell'), project='ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B cell'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'in vitro differentiated cells', 'biosample_term_name': 'K562'}, project='ENCODE') == False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B cell',
     'product_id': 'ABC123'},
    'ENCODE') == False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell',
     'life_stage': 'fetus'},
    'ENCODE') is False
	assert candidate(sample={'biosample_term_name': 'lung', 'biosample_type': 'cell line', 'life_stage': 'unknown', 'product_id': 'ENCLB000AAB'}, project='ENCODE') == True
	assert candidate(
    {'biosample_term_name': 'neuron', 'product_id': 'ENCDO000AAA',
     'biosample_type': 'immortalized cell line'},
    'ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'naive b cell', 'biosample_type': 'immortalized cell line'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive b cell',
     'product_id': 'ABC123'},
    'ENCODE') == False
	assert candidate(
    {'biosample_type': 'cell culture',
     'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type':'stem cell'},
    'ENCODE') is False
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive b cells'}, project='ENCODE') == False
	assert candidate(dict(biosample_type='in vitro differentiated cells',
                                 biosample_term_name='naive B cell'),
                           'ENCODE') == False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type':'stem cell'},
    'ENCODE'
) is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive b cells'},
    'ENCODE') is False
	assert candidate(dict(biosample_type='in vitro differentiated cells'),
                           'ENCODE') is False
	assert candidate(sample=dict(biosample_type='cell line', biosample_term_name='naive B cell', product_id='novel'), project='ENCODE') is False
	assert candidate(sample={'biosample_type': 'in vitro sample',
                                    'biosample_term_name': 'naive T cell',
                                    'product_id': 'ENCDO000AAA'},
                            project='ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell'},
    'ENCODE'
) is False
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'right lung'}, project='ENCODE') == False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells',
     'biosample_term_name': 'naive b cell'},
    'ENCODE') is False
	assert candidate(sample=dict(biosample_type='cell line', biosample_term_name='naive b cell', product_id='novel'), project='ENCODE') is False
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'fat K562'}, project='ENCODE') == False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells',
     'biosample_term_name': 'fetal stem cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells',
     'biosample_term_name': 'naive B cell'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive b cell'}, project='ENCODE') == False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'immortalized cell line'},
    'ENCODE') is False
	assert candidate(sample={'biosample_term_name': 'lung', 'biosample_type': 'tissue'}, project='ENCODE') == False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'induced pluripotent stem cell line'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell',
     'product_id': 'ENCBS000AAA', 'life_stage': 'postnatal'}, 'ENCODE') == False
	assert candidate(sample={'biosample_term_name': 'lung', 'biosample_type': 'cell line', 'life_stage': 'adult'}, project='ENCODE') == True
	assert candidate(dict(biosample_type='immortalized cell line',
                                 biosample_term_name='T cell'),
                           'ENCODE') == False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B-cell'},
    'ENCODE') is False
	assert candidate(
    {'TYPE': 'ESCDerived', 'AGE': 'fetus'},
    'Roadmap Epigenomics'
) is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B-cells derived cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell line',
     'biosample_term_name': 'naive b cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B cell'},
    'ENCODE') == False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells', 'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'B cell', 'biosample_type': 'in vitro differentiated cells'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'cell line',
                                    'biosample_term_name': 'naive b cell',
                                    'product_id': 'SRR1373362'},
                            project='ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'cell line', 'product_id': 'foo'},
    'ENCODE'
) is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive b cell',
     'product_id': 'ENCBS000AAA'}, 'ENCODE') == False
	assert candidate(
    {'biosample_type': 'cell line', 'biosample_term_name':'stem cell'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'immortalized cell line',
                                    'biosample_term_name': 'naive T cell',
                                    'product_id': 'ENCDO000AAA'},
                            project='ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive b cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell culture',
     'biosample_term_name': 'naive b cell'},
    'ENCODE') is False
	assert candidate(dict(biosample_type='immortalized cell line'),
                           'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'fetal stem cell'},
    'ENCODE') is False
	assert candidate(dict(biosample_type='in vitro differentiated cells',
                                 biosample_term_name='naive b cell'),
                           'ENCODE') == False
	assert candidate(
    {'TYPE': 'ESCDerived', 'AGE': '1y'},
    'Roadmap Epigenomics'
) is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell', 'product_id': 'naive-B-cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell',
     'product_id': 'ENCBS000AAA', 'life_stage': 'fetal'}, 'ENCODE') == False
	assert candidate(
    {'biosample_type': 'in vitro sample',
     'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'in vitro differentiated cells'},
    'ENCODE'
) is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive B cell'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'cell line',
                                    'biosample_term_name': 'immortalized cell line',
                                    'product_id': 'SRR1373362'},
                            project='ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive b cell'},
    'ENCODE'
) is False
	assert candidate(dict(biosample_type='in vitro differentiated cells',
                                 biosample_term_name='naive T cell'),
                           'ENCODE') == False
	assert candidate(
    {'biosample_type':'stem cell',
     'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell line', 'biosample_term_name': 'fibroblast'}, 'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell line',
     'biosample_term_name': 'HepG2',
     'product_id': 'HepG2-human',
     'life_stage': 'adult'},
    'ENCODE'
)
	assert candidate(dict(biosample_type='cell line', biosample_term_name='naive B cell'), 'ENCODE') is False
	assert candidate(dict(biosample_type='immortalized cell line',
                                 biosample_term_name='naive B cell'),
                           'ENCODE') == False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells', 'biosample_term_name': 'naive B cell'}, 'ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'in vitro differentiated cells'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive b cell'},
    'ENCODE') == False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B-cells derived cells'},
    'ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'primary cell'},
    'ENCODE') is False
	assert candidate(
    {'TYPE': 'CellLine', 'AGE': '1y'},
    'Roadmap Epigenomics'
) is False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells', 'biosample_term_name': 'naive B cell'},
    'ENCODE'
) is False
	assert candidate(sample=dict(biosample_type='cell line', biosample_term_name='naive b cells'), project='ENCODE') is False
	assert candidate(sample=dict(biosample_type='cell line', biosample_term_name='naive b cell'), project='ENCODE') is False
	assert candidate(dict(biosample_type='in vitro differentiated cells', biosample_term_name='H1-hESC'), 'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B-Cells'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'immortalized cell line',
     'biosample_term_name': 'naive B-cells'},
    'ENCODE') is False
	assert candidate(dict(biosample_type='in vitro differentiated cells',
                                 biosample_term_name='T cell'),
                           'ENCODE') == False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells',
     'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(dict(biosample_type='cell line', biosample_term_name='H1-hESC', life_stage='adult'), 'ENCODE') is True
	assert candidate(
    {'biosample_type': 'immortalized cell line', 'biosample_term_name': 'naive b cell'},
    'ENCODE') is False
	assert candidate(sample=dict(biosample_type='cell line', biosample_term_name='naive B cells'), project='ENCODE') is False
	assert candidate(sample={'biosample_type': 'cell line',
                                    'biosample_term_name': 'fibroblast',
                                    'product_id': 'SRR1373362'},
                            project='ENCODE') is False
	assert candidate(sample={'biosample_type': 'cell line',
                                    'biosample_term_name': 'naive B cell',
                                    'product_id': 'SRR1373362'},
                            project='ENCODE') is False
	assert candidate(
    {'biosample_type': 'in vitro differentiated cells', 'biosample_term_name': 'naive B cell',
     'product_id': 'ENCDO123ABC'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell line',
     'biosample_term_name': 'naive B cell'},
    'ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'B cell', 'biosample_type': 'immortalized cell line'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'K562'}, project='ENCODE') == False
	assert candidate(dict(biosample_type='immortalized cell line',
                                 biosample_term_name='naive b cell'),
                           'ENCODE') == False
	assert candidate(dict(biosample_type='immortalized cell line', biosample_term_name='H1-hESC'), 'ENCODE') is False
	assert candidate(dict(biosample_type='immortalized cell line',
                                 biosample_term_name='naive T cell'),
                           'ENCODE') == False
	assert candidate(sample={'biosample_term_name': 'lung', 'biosample_type': 'cell line', 'life_stage': 'unknown', 'product_id': 'ENCLB000AAA'}, project='ENCODE') == True
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'female K562'}, project='ENCODE') == False
	assert candidate(sample={'biosample_term_name': 'lung', 'biosample_type': 'cell line', 'life_stage': 'fetal'}, project='ENCODE') == False
	assert candidate(
    {'biosample_type': 'cell line',
     'biosample_term_name': 'HepG2',
     'product_id': 'HepG2-human',
     'life_stage': 'unknown'},
    'ENCODE'
)
	assert candidate(dict(biosample_type='immortalized cell line',
                                 biosample_term_name='B cell'),
                           'ENCODE') == False
	assert candidate(sample={'biosample_type': 'in vitro sample',
                                    'biosample_term_name': 'naive B cell',
                                    'product_id': 'ENCDO000AAA'},
                            project='ENCODE') is False
	assert candidate(
    {'biosample_term_name': 'naive B cell', 'biosample_type': 'primary cell line'},
    'ENCODE') is False
	assert candidate(
    {'biosample_type': 'cell line', 'biosample_term_name': 'naive b cell'}, 'ENCODE') is False
	assert candidate(sample={'biosample_type': 'immortalized cell line', 'biosample_term_name': 'right lungs'}, project='ENCODE') == False
	assert candidate(
    {'biosample_term_name': 'naive b cell', 'biosample_type': 'in vitro differentiated cells'},
    'ENCODE') is False
def test_check():
	check(check_sample_filters)
