def combinations(input_list):
    """Return all possible combinations of the elements in an input
    sequence.  The last returned element will be the empty list.

    E.g., combinations([0,1]) returns [[0, 1], [0], [1], []]

    Taken from the internet:
      http://desk.stinkpot.org:8080/tricks/index.php/2008/04/get-all-possible-combinations-of-a-lists-elements-in-python/

    :Requirements: :doc:`copy`
    """
    ### Canonical solution below ###
    # 2010-10-09 17:06 IJC: Created from internet
    import copy

    swap_list_list = [[]]
    for swap in input_list:
        temp_lists = []
        for list_stub in swap_list_list:
            this_list = copy.copy(list_stub)
            this_list.append(swap)
            temp_lists.append(this_list)
            temp_lists.append(list_stub)
        swap_list_list = temp_lists

    return swap_list_list


### Unit tests below ###
def check(candidate):
	assert candidate(range(1)) == [[0], []]
	assert candidate([0]) == [[0], []]
	assert candidate('abc') == [['a', 'b', 'c'], ['a', 'b'], ['a', 'c'], ['a'], ['b', 'c'], ['b'], ['c'], []]
	assert candidate([0, 1, 2]) == [[0, 1, 2], [0, 1], [0, 2], [0], [1, 2], [1], [2], []]
	assert candidate(range(2)) == [[0, 1], [0], [1], []]
	assert candidate(range(3)) == [[0, 1, 2], [0, 1], [0, 2], [0], [1, 2], [1], [2], []]
	assert candidate(range(0)) == [[]]
	assert candidate([0,1]) == [[0, 1], [0], [1], []]
	assert candidate([0,1,2]) == [[0, 1, 2], [0, 1], [0, 2], [0], [1, 2], [1], [2], []]
	assert candidate([]) == [[]]
	assert candidate([0, 1]) == [[0, 1], [0], [1], []]
	assert candidate([1,2,3]) == [[1, 2, 3], [1, 2], [1, 3], [1], [2, 3], [2], [3], []]
def test_check():
	check(combinations)
