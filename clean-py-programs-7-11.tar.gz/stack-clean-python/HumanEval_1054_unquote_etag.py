def unquote_etag(etag):
    """ Unquote a single etag:
     
     >>> unquote_etag('w/"bar"')
     ('bar', True)
     >>> unquote_etag('"bar"')
     ('bar', False)
     
     :param etag: the etag identifier to unquote.
     :return: a ``(etag, weak)`` tuple.
     """
	### Canonical solution below ###    
    if not etag:
        return None, None
    etag = etag.strip()
    weak = False
    if etag[:2] in ('w/', 'W/'):
        weak = True
        etag = etag[2:]
    if etag[:1] == etag[-1:] == '"':
        etag = etag[1:-1]
    return etag, weak

### Unit tests below ###
def check(candidate):
	assert candidate('W/"bar"') == ('bar', True)
	assert candidate(None) == (None, None)
	assert candidate('"b\xe9r"') == ('b\xe9r', False)
	assert candidate('bar') == ('bar', False)
	assert candidate(' W/"bar"') == ('bar', True)
	assert candidate('"W/bar" ') == ('W/bar', False)
	assert candidate('') == (None, None)
	assert candidate('"foo" ') == ('foo', False)
	assert candidate('"foo"bar') == ('"foo"bar', False)
	assert candidate('"W/bar"') == ('W/bar', False)
	assert candidate('W/"bar" ') == ('bar', True)
	assert candidate(' w/"bar" ') == ('bar', True)
	assert candidate(' W/"bar" ') == ('bar', True)
	assert candidate('foo') == ('foo', False)
	assert candidate('w/"bar" ') == ('bar', True)
	assert candidate('"foo"') == ('foo', False)
	assert candidate('w/bar') == ('bar', True)
	assert candidate(' "bar"') == ('bar', False)
	assert candidate('w/"bar"') == ('bar', True)
	assert candidate(' "foo"') == ('foo', False)
	assert candidate('w/"b"ar"') == ('b"ar', True)
	assert candidate('W/"foo"') == ('foo', True)
	assert candidate('foo"') == ('foo"', False)
	assert candidate(' "bar" ') == ('bar', False)
	assert candidate('w/" bar"') == (' bar', True)
	assert candidate('"bar" ') == ('bar', False)
	assert candidate(' w/"bar"') == ('bar', True)
	assert candidate("w/\"bar\"") == ("bar", True)
	assert candidate(' "foo" ') == ('foo', False)
	assert candidate('w/"foo"') == ('foo', True)
	assert candidate('foo"bar') == ('foo"bar', False)
	assert candidate('"foo') == ('"foo', False)
	assert candidate('"bar"') == ('bar', False)
	assert candidate("\"bar\"") == ("bar", False)
	assert candidate("") == (None, None)
	assert candidate('" bar"') == (' bar', False)
def test_check():
	check(unquote_etag)
