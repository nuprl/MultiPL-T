def attribute_match_all(
    attribute, length=None, data=None, value=None, endswith=None
):
    """
    Check if an attribute matches all of the following specified conditions:

    - Minimum length.
    - Contains an item.
    - Is exactly a value.

    Note that only those conditions explicitly passed will be checked.

    Parameters
    ----------
    attribute : anything
        The attribute to match against.
    length : int, default is None
        If specified, the attribute must reach this length (or higher).
    data : anything, default is None
        If specified, the attribute must contain this value.
    value : anything, default is None
        If specified, the attribute must be this value.
    endswith : sequence, default is None
        If specified, the attribute must end with this sequence.

    Returns
    -------
    bool
        Whether the attribute matches any condition.
    """
    ### Canonical solution below ###
    assert (
        length is not None
        or data is not None
        or value is not None
        or endswith is not None
    ), 'No condition passed! Will return True always...'
    if length is not None and len(attribute) < length:
        return False
    if data is not None and data not in attribute:
        return False
    if value is not None and attribute != value:
        return False
    if endswith is not None and attribute[-len(endswith) :] != endswith:
        return False
    return True


### Unit tests below ###
def check(candidate):
	assert candidate(attribute='a', data='a') == True
	assert not candidate(
    'a', length=2, data='a', value='a', endswith=['b']
)
	assert candidate(range(10), data=9)
	assert not candidate([1, 2, 3], length=4)
	assert candidate([1, 2, 3, 4], data=1)
	assert not candidate(3, value=4)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}, length=2, data=2, value=3, endswith=(1, 2, 3, 4)
) is False
	assert candidate(attribute='123456', length=5, data='123', value='123456')
	assert candidate(attribute='a', length=2, value='b') == False
	assert not candidate([1, 2, 3, 4], data=[1, 10])
	assert not candidate(
    'a', length=3, data='a', value='a', endswith=['a']
)
	assert not candidate([1], data=2)
	assert candidate([1, 2, 3], data=1)
	assert candidate(attribute='abc', endswith='b') is False
	assert candidate(attribute=b'abc', length=3) == True
	assert not candidate([1, 2, 3, 4], endswith=[1, 10])
	assert candidate(attribute='abcde', length=5, data='b')
	assert candidate(attribute='abc', length=2, data='c') is True
	assert candidate(attribute='a', data='b') == False
	assert candidate(attribute='abc', value='c') is False
	assert not candidate(b'abcdef', value=b'abc', endswith=b'abc')
	assert candidate(attribute='test', data='es', endswith='st')
	assert candidate([1,2,3], endswith=[1,2,3]) == True
	assert candidate(attribute='a', value='b') == False
	assert not candidate(attribute='123456', length=7)
	assert candidate([1,2,3], value=[1,2,3,4]) == False
	assert candidate(attribute=['a', 'b', 'c'], value=['a', 'b', 'c'])
	assert candidate(attribute='abcde', length=5, data='e')
	assert candidate([], length=0)
	assert not candidate(b'abcdef', value=b'abc')
	assert candidate([1,2,3], endswith=[4]) == False
	assert not candidate('abcde', 3, value='abc')
	assert not candidate([1, 2], value=3)
	assert candidate(attribute='a', endswith='ab') == False
	assert candidate('abcdef', 6, value='abcdef')
	assert not candidate([1, 2, 3, 4], value=[1, 2, 3])
	assert not candidate(b'abcdef', length=3, value=b'abc')
	assert candidate([1,2,3], endswith=[3]) == True
	assert candidate(attribute='test', length=2)
	assert not candidate(b'Hello World', length=12, data=b'Hello', value=b'Hello World', endswith=b'World')
	assert not candidate(range(10), endswith=(0, 1, 2, 3, 4, 5, 6))
	assert candidate(attribute=b'abc', length=3, value=b'ab') == False
	assert not candidate(attribute='test', length=2, data='esa')
	assert not candidate(attribute='test', value='test', endswith='es')
	assert candidate(
    'abc', length=1, data='b', value='abc', endswith='c'
)
	assert not candidate(
    'abc', length=3, data='b', value='abd', endswith='c'
)
	assert candidate(list(range(10)), data=5)
	assert candidate(b'Hello World', length=11)
	assert not candidate(attribute='test', data='es', endswith='es')
	assert candidate(attribute='abcde', length=5, value='abcde', endswith='de')
	assert candidate([1], data=1)
	assert candidate(attribute='test', value='test', endswith='st')
	assert candidate(attribute=['a', 'b', 'c'], endswith=['a', 'b', 'c'])
	assert not candidate([1], value=2)
	assert candidate('abcde', 5, data='abc')
	assert candidate([1], endswith=[1])
	assert candidate(attribute='123456', length=5)
	assert candidate(attribute='abc', length=2, endswith='b') is False
	assert candidate(attribute='abc', length=2, value='a') is False
	assert candidate([1,2,3], value=[1,2,3]) == True
	assert candidate(attribute='a', data='a', value='b') == False
	assert not candidate(
    'this is a test', length=10, data='is', endswith='not'
)
	assert not candidate(
    'abcde', length=1, data='a', value='def', endswith='cde'
)
	assert candidate([1, 2], endswith=[1, 2])
	assert not candidate('abcde', 5, value='abc', endswith='def')
	assert candidate(attribute=b'abc', data=b'a') == True
	assert candidate(attribute=b'abc', endswith=b'ac') == False
	assert not candidate(b'Hello World', length=11, data=b'Hello', value=b'Hello World', endswith=b'!')
	assert candidate([1, 2, 3], 3, data=1)
	assert candidate(attribute='abcde', length=5, data='c', endswith='de')
	assert candidate(attribute='a', endswith='a') == True
	assert candidate(1, value=1) is True
	assert candidate(range(10), value=range(10))
	assert candidate(attribute='abc', length=3) is True
	assert candidate(attribute='abc', length=2, value='c') is False
	assert candidate(attribute='abc', value='b') is False
	assert not candidate([1, 2, 3, 4], data=10)
	assert candidate(attribute=b'abc', length=3, data=b'a') == True
	assert candidate([1,2,3], endswith=[1,2,3,4]) == False
	assert not candidate(b'abcdef', length=3, endswith=b'abc')
	assert not candidate(
    attribute=[1, 2, 3], length=2, data=1, value=2, endswith=[3, 4]
)
	assert not candidate(
    'a', length=2, data='b', value='a', endswith=['a']
)
	assert candidate([1, 2, 3], length=3)
	assert candidate(attribute='abc', value='a') is False
	assert candidate(attribute='123456', length=5, data='123')
	assert not candidate(
    'this is a test', length=10, data='not', endswith='test'
)
	assert not candidate(attribute='test', endswith='es')
	assert not candidate(b'Hello World', length=12, data=b'Hello', value=b'Hello World', endswith=b'!')
	assert not candidate(
    attribute=[1, 2, 3], length=2, data=1, value=2, endswith=[4, 5]
)
	assert candidate('abcde', 5, endswith='cde')
	assert candidate(attribute=b'abc', value=b'ab') == False
	assert candidate(attribute='abcde', length=5, data='b', endswith='de')
	assert candidate(b'abcdef', data=b'cde')
	assert not candidate(
    '12345', length=3, data='4', value='123', endswith='5'
), 'candidate() failed!'
	assert candidate(attribute=b'abc', length=3, value=b'abc') == True
	assert candidate(attribute=b'abc', length=4) == False
	assert candidate(range(10), length=5)
	assert candidate('abcdef', 6, endswith='def')
	assert candidate(123, value=3) == False
	assert candidate(attribute='test', endswith='st')
	assert not candidate(range(10), length=11)
	assert candidate(attribute='test', data='es')
	assert not candidate('abcde', 3, value='abc', endswith='cde')
	assert not candidate(attribute=['a', 'b', 'c'], value=['d', 'e', 'f'])
	assert not candidate(
    'hello', length=5, data='l', value='world', endswith='lo'
)
	assert candidate(list(range(10)), length=5, data=5)
	assert not candidate(b'abcdef', data=b'cde', endswith=b'abc')
	assert not candidate(range(10), value=range(11))
	assert not candidate(
    'this is a test', length=10, data='not', endswith='not'
)
	assert candidate(range(10), length=10)
	assert candidate(attribute='abcde', length=5, data='e', endswith='de')
	assert not candidate(
    ['a', 'b', 'c'], length=3, data='a', value='c', endswith=['a', 'b', 'd']
)
	assert candidate(attribute='abcde', length=5, data='a')
	assert candidate(b'Hello World', length=11, data=b'Hello', value=b'Hello World')
	assert candidate(attribute=b'abc', value=b'abc') == True
	assert candidate(attribute='abcde', length=5, data='d', endswith='de')
	assert candidate(attribute='a', data='a', value='a') == True
	assert not candidate(
    'hello', length=5, data='l', value='hello', endswith='ol'
)
	assert not candidate(attribute=['a', 'b', 'c'], length=5)
	assert not candidate([1, 2], endswith=[3])
	assert not candidate('abcdef', 6, endswith='cde')
	assert candidate(list(range(10)), length=5, data=5, endswith=[9])
	assert not candidate(attribute='123456', length=5, data='12', value='1234567', endswith='6')
	assert candidate(
    'abc', length=3, data='b', value='abc', endswith='c'
)
	assert candidate([1,2,3], data=4) == False
	assert candidate(attribute='test', value='test')
	assert candidate([1, 2, 3, 4], value=[1, 2, 3, 4])
	assert candidate(attribute='test', length=2, data='es', value='test')
	assert candidate(
    'this is a test', length=10, data='is', endswith='test'
)
	assert not candidate(
    'abc', length=3, data='d', value='abc', endswith='c'
)
	assert candidate(
    'hello', length=5, data='l', value='hello', endswith='lo'
)
	assert candidate([1, 2], data=1)
	assert candidate(b'abcdef', length=3)
	assert not candidate(
    'abc', length=3, data='b', value='abc', endswith='d'
)
	assert not candidate(b'abcdef', endswith=b'cde')
	assert not candidate(
    '12345', length=3, data='3', value='124', endswith='5'
), 'candidate() failed!'
	assert candidate(3, value=3)
	assert not candidate(
    attribute=[1, 2, 3], length=3, data=1, value=2, endswith=[3, 4]
)
	assert candidate(attribute='abcde', length=5)
	assert not candidate(attribute='test', length=2, value='tes')
	assert not candidate(b'Hello World', length=12, data=b'Hello', value=b'Hello World')
	assert not candidate(
    '12345', length=3, data='3', value='123', endswith='6'
), 'candidate() failed!'
	assert candidate(attribute='abcde', length=5, value='abcde')
	assert candidate(attribute=b'abc', data=b'c') == True
	assert not candidate(range(10), endswith=(0, 1, 2, 3, 4, 5))
	assert candidate(attribute='a', length=1, endswith='a') == True
	assert not candidate([1, 2, 3], data=4)
	assert candidate(attribute=b'abc', endswith=b'ab') == False
	assert candidate(attribute='abc', length=2, value='b') is False
	assert candidate(1, value=2) is False
	assert candidate(attribute='a', length=2, endswith='ab') == False
	assert not candidate('abcde', 3, value='abc', endswith='def')
	assert not candidate(
    'a', length=2, data='a', value='b', endswith=['a']
)
	assert not candidate(
    'hello', length=6, data='l', value='hello', endswith='lo'
)
	assert not candidate(
    ['a', 'b', 'c'], length=4, data='a', value='c', endswith=['a', 'b', 'c']
)
	assert candidate(attribute='abcde', length=5, endswith='abcde')
	assert candidate(attribute='123456', length=5, data='123', value='123456', endswith='6')
	assert candidate('abcde', 5, 'abc')
	assert candidate(b'Hello World', length=11, data=b'Hello')
	assert candidate(attribute='test', length=2, value='test')
	assert candidate(list(range(10)), endswith=[9])
	assert candidate(list(range(10)), data=5, endswith=[9])
	assert candidate(attribute='a', value='a') == True
	assert not candidate(attribute='test', data='esa')
	assert candidate(attribute='abcde', endswith='de') == True
	assert candidate([1,2,3], data=2) == True
	assert candidate(attribute='abc', data='c') is True
	assert candidate(attribute=b'abc', value=b'ac') == False
	assert not candidate('abc', endswith='d')
	assert candidate(attribute='a', length=1, value='a') == True
	assert not candidate(range(10), data=11)
	assert candidate([1, 2], data=2)
	assert not candidate(attribute='test', value='tes')
	assert candidate(attribute=b'abc', endswith=b'abc') == True
	assert candidate(attribute='test', length=2, data='es')
	assert candidate(attribute='abcde', length=5, endswith='de')
	assert candidate(attribute='abcde', length=5, data='c')
	assert not candidate(
    'abc', length=4, data='b', value='abc', endswith='c'
)
	assert candidate(list(range(10)), length=5, endswith=[9])
	assert not candidate([1, 2], data=3)
	assert candidate(b'Hello World', length=11, data=b'Hello', value=b'Hello World', endswith=b'World')
	assert candidate(attribute='a', length=2, data='b') == False
	assert candidate([1, 2], endswith=[2])
	assert not candidate([1], endswith=[2])
	assert not candidate(
    '12345', length=6, data='3', value='123', endswith='5'
), 'candidate() failed!'
	assert not candidate(attribute='test', length=2, value='tes', endswith='st')
	assert candidate(attribute='abcde', length=5, data='a', endswith='de')
	assert not candidate(b'Hello World', length=12)
	assert not candidate(b'Hello World', length=12, data=b'Hello')
	assert candidate(123, value=2) == False
	assert candidate('abc', endswith='c')
	assert not candidate(
    attribute=[1, 2, 3], length=2, data=1, value=3, endswith=[3, 4]
)
	assert candidate(attribute='a', length=1, data='a') == True
	assert candidate(b'abcdef', endswith=b'def')
	assert not candidate(attribute=['a', 'b', 'c'], endswith=['d', 'e', 'f'])
	assert candidate(
    'abcde', length=1, data='a', value='abcde', endswith='cde'
)
	assert not candidate(b'abcdef', data=b'cde', value=b'abc')
	assert candidate(attribute='abcde', value='ab') == False
	assert candidate(attribute='abcde', length=5, data='d')
	assert candidate(attribute=['a', 'b', 'c'], data='a')
	assert candidate(b'abcdef', value=b'abcdef')
	assert not candidate(attribute='123456', length=5, data='12', value='1234567')
	assert candidate(attribute='abcde', length=5, endswith='bcde')
	assert not candidate(
    'abcde', length=1, data='a', value='abcde', endswith='xyz'
)
	assert not candidate(attribute=['a', 'b', 'c'], data='d')
	assert not candidate(attribute='test', length=2, data='es', value='tes')
	assert candidate(list(range(10)), length=10)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}, length=2, data=2, value=4, endswith=(1, 2, 3)
) is False
	assert candidate(range(10), data=5)
def test_check():
	check(attribute_match_all)
