def resolve_attr(obj, path):
    """ A recursive version of getattr for navigating dotted paths.
     
     Args:
     obj: An object for which we want to retrieve a nested attribute.
     path: A dot separated string containing zero or more attribute names.
     
     Returns:
     The attribute referred to by obj.a1.a2.a3...
     
     Raises:
     AttributeError: If there is no such attribute.
     """
	### Canonical solution below ###    
    if not path:
        return obj
    head, _, tail = path.partition('.')
    head_obj = getattr(obj, head)
    return resolve_attr(head_obj, tail)

### Unit tests below ###
def check(candidate):
	assert candidate(dict, 'popitem') == dict.popitem
	assert candidate(dict, 'pop') == dict.pop
	assert candidate(range(10),'stop.real') == 10
	assert candidate(None, '') is None
	assert candidate(range(10), '') == range(10)
	assert candidate(dict(a1=dict(a2=dict(a3=42))), '') == dict(a1=dict(a2=dict(a3=42)))
	assert candidate(dict, 'keys') == dict.keys
	assert candidate(range(10),'step') == 1
	assert candidate(dict, 'items') == dict.items
	assert candidate(range(10),'start.imag') == 0
	assert candidate(range(10),'start') == 0
	assert candidate(range(10),'step.imag') == 0
	assert candidate(range(10),'start.real') == 0
	assert candidate(dict, 'values') == dict.values
	assert candidate(dict, '') == dict
	assert candidate(range(10),'stop.imag') == 0
	assert candidate(1, '') == 1
	assert candidate(range(10),'stop') == 10
	assert candidate(range(10),'step.real') == 1
def test_check():
	check(resolve_attr)
