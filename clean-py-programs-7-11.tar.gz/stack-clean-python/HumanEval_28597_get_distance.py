def get_distance(sigma_phi_1, sigma_phi_2, mean_phi_1, mean_phi_2, phi_1, phi_2):
    """
    Returns the "distance" that an object has relative to a specific region in terms of phi_1 and phi_2 considering the standar deviation.
    Arguments:
        sigma_phi_1 {float} - Standard deviation in phi_1 axis.
        sigma_phi_2 {float} - Standard deviation in phi_2 axis.
        mean_phi_1 {float} - Mean or center of the region in phi_1 axis.
        mean_phi_2 {float} - Mean or center of the region in phi_2 axis.
        phi_1 {float} - Center of the object in phi_1 axis.
        phi_2 {float} - Center of the object in phi_2 axis.
    Returns:
        Float -- Distance between the center of the object and the center of the region.
    """
    ### Canonical solution below ###
    return ( ( phi_1 - mean_phi_1 ) / sigma_phi_1 )**2 + ( ( phi_2 - mean_phi_2 ) / sigma_phi_2 )**2 
    # return ( phi_1 - mean_phi_1 )**2 + ( phi_2 - mean_phi_2 )**2 


### Unit tests below ###
def check(candidate):
	assert candidate(1, 1, 1, 1, -1, -1) == 8, "Test 6: Failed"
	assert candidate(1, 1, 1, 1, 1, 1) == 0, "Test 1: Failed"
	assert candidate(1, 1, 0, 0, 1, 2) == 5
	assert candidate(0.1, 0.1, 0, 0, 0, 0.001) == 0.0001
	assert candidate(1, 1, 1, 1, 1, 2) == 1
	assert candidate(1, 1, 1, 1, 2, 1) == 1
	assert candidate(1,1,1,1,0,2) == 2
	assert candidate(1, 1, 0, 0, 0, 0) == 0
	assert candidate(1, 1, 0, 1, 1, 0) == 2
	assert candidate(1, 1, 0, 0, 1, -1) == 2
	assert candidate(1, 1, 1, 1, 2, 1) == 1, "Wrong distance."
	assert candidate(1, 1, 1, 1, 1, 1) == 0, "Wrong distance."
	assert candidate(1, 1, 1, 2, 1, 1) == 1
	assert candidate(1,1,1,1,2,2) == 2
	assert candidate(1, 1, 2, 1, 1, 1) == 1
	assert candidate(1, 1, 0, 0, 1, -1) == 2, "candidate is not working properly"
	assert candidate(0.5, 0.5, 0, 0, 0, 0) == 0
	assert candidate(0.1, 0.1, 0.1, 0.1, 0.1, 0.1) == 0.0
	assert candidate(1, 1, 1, 1, 2, 1) == 1.0, "Distance is not 1"
	assert candidate(1.0, 1.0, 0.0, 0.0, 0.0, 0.0) == 0.0
	assert candidate(1, 1, 0, 0, -1, -1) == 2, "candidate is not working properly"
	assert candidate(1, 1, 1, 1, 2, 3) == 5.0, "Distance is not 5"
	assert candidate(1, 1, 0, 0, 1, 0) == 1, "candidate is not working properly"
	assert candidate(1, 1, 1, 1, 1, 1) == 0.0, "Distance is not 0"
	assert candidate(1, 1, 0, 0, 1, 0) == 1
	assert candidate(1.0, 1.0, 0.0, 0.0, 2.0, 0.0) == 4.0
	assert candidate(1, 1, 0, 0, 0, 1) == 1
	assert candidate(1, 1, 1, 1, 3, 2) == 5
	assert candidate(1, 1, 1, 1, 0, 0) == 2
	assert candidate(1, 1, 1, 1, 2, 3) == 5
	assert candidate(1,1,1,1,1,0) == 1
	assert candidate(1, 1, 1, 1, 1, 2) == 1, "Wrong distance."
	assert candidate(1.0, 1.0, 0.0, 0.0, -1.0, 1.0) == 2.0
	assert candidate(1, 1, 1, 1, 2, 2) == 2, "Wrong distance."
	assert candidate(0.01, 0.01, 0, 0, 0, 0) == 0
	assert candidate(sigma_phi_1=1, sigma_phi_2=1, mean_phi_1=0, mean_phi_2=0, phi_1=0, phi_2=1) == 1.0, "candidate(sigma_phi_1=1, sigma_phi_2=1, mean_phi_1=0, mean_phi_2=0, phi_1=0, phi_2=1) must be 1.0"
	assert candidate(1,1,1,1,0,1) == 1
	assert candidate(1, 1, 1, 1, 1, 3) == 4
	assert candidate(1, 1, 0, 0, 1, 1) == 2, "candidate is not working properly"
	assert candidate(1.0, 1.0, 0.0, 0.0, -1.0, -1.0) == 2.0
	assert candidate(1, 1, 1, 1, 0, 0) == 2, "Test 2: Failed"
	assert candidate(1.0, 1.0, 0.0, 0.0, 0.0, 1.0) == 1.0
	assert candidate(1,1,1,1,1,1) == 0
	assert candidate(2, 2, 2, 2, 2, 2) == 0
	assert candidate(1, 1, 1, 1, 2, 2) == 2
	assert candidate(1, 1, 1, 0, 0, 1) == 2
	assert candidate(1.0, 1.0, 0.0, 0.0, 0.0, 2.0) == 4.0
	assert candidate(3, 3, 0, 0, 0, 0) == 0
	assert candidate(1.0, 1.0, 0.0, 0.0, 0.0, -1.0) == 1.0
	assert candidate(1.0, 1.0, 0.0, 0.0, 1.0, -1.0) == 2.0
	assert candidate(1,1,1,1,2,0) == 2
	assert candidate(1, 1, 0, 0, 0, 1) == 1, "candidate is not working properly"
	assert candidate(1, 1, 0, 0, -1, 1) == 2
	assert candidate(sigma_phi_1=1, sigma_phi_2=1, mean_phi_1=0, mean_phi_2=0, phi_1=0, phi_2=0) == 0.0, "candidate(sigma_phi_1=1, sigma_phi_2=1, mean_phi_1=0, mean_phi_2=0, phi_1=0, phi_2=0) must be 0.0"
	assert candidate(1,1,1,1,2,1) == 1
	assert candidate(1, 1, 1, 1, 1, 2) == 1.0, "Distance is not 1"
	assert candidate(0.1, 0.1, 10, 10, 10, 10) == 0.0, "0.0 expected"
	assert candidate(1, 1, 0, 1, 0, 0) == 1
	assert candidate(1, 1, 1, 1, 1, 1) == 0
	assert candidate(1.0, 1.0, 0.0, 0.0, 1.0, 1.0) == 2.0
	assert candidate(1, 1, 0, 0, 1, 1) == 2
	assert candidate(1, 1, 1, 0, 0, 0) == 1
	assert candidate(1, 1, 1, 1, 3, 1) == 4
	assert candidate(1.0, 1.0, 0.0, 0.0, 1.0, 0.0) == 1.0
	assert candidate(1, 1, 2, 2, 1, 1) == 2
	assert candidate(1, 1, 0, 0, -1, 1) == 2, "candidate is not working properly"
	assert candidate(1,1,1,1,1,2) == 1
	assert candidate(1, 1, 1, 1, 2, 2) == 2.0, "Distance is not 2"
def test_check():
	check(get_distance)
