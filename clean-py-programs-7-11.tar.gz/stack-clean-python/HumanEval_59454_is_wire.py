def is_wire(arg):
    """Returns whether the passed argument is a tuple of wires."""
    ### Canonical solution below ###
    return isinstance(arg, tuple) and arg[0] == "wires"


### Unit tests below ###
def check(candidate):
	assert candidate( ("wires", 1) )
	assert candidate(tuple(["wires", 3]))
	assert candidate( ("wires",) ) == True
	assert not candidate( ("notwires", 1) )
	assert not candidate( ["12"] )
	assert candidate( ("wires", 0, 1) ) == True
	assert not candidate((1, 2))
	assert candidate("wires") == False
	assert not candidate( 1 )
	assert not candidate( ["wires", "12", "34"] )
	assert not candidate( ["wires", "12", "34", "56", "78", "90"] )
	assert not candidate( 12 )
	assert not candidate( ["wires", "12"] )
	assert candidate( ("notwires",) ) == False
	assert not candidate( ["wires", "12", "34", "56", "78", "90", "111"] )
	assert candidate(("wires", "a")) == True
	assert candidate(("wires", 1, 2, 3, 4))
	assert not candidate( ("notwires", (0, 1, 2, 3)) )
	assert not candidate(1.0)
	assert candidate(("wires", 0, 1, 2))
	assert not candidate( ["wires"] )
	assert not candidate(0)
	assert not candidate(1)
	assert not candidate( ("not_wires", 1, 2, 3) )
	assert not candidate((1, 2, 3))
	assert candidate( ("wires", 1, 2, 3) )
	assert candidate(("wires", 1))
	assert candidate( ("wires", (0, 1, 2)) )
	assert not candidate(("notwires",))
	assert candidate(tuple(["wires", 1, 2])) == True
	assert candidate(("wires",))
	assert not candidate( ["wires", "12", "34", "56"] )
	assert candidate(("wires", (1, 2, 3, 4)))
	assert candidate(None) == False
	assert candidate( ("wires", 0, 1, 2) ) == True
	assert candidate("a") == False
	assert candidate( ("wires", "12") )
	assert candidate( ("wires", "12", "34") )
	assert not candidate( ("notwires", (0, 1, 2)) )
	assert not candidate( (1,2) )
	assert not candidate( ("12",) )
	assert not candidate(("notwires", 1))
	assert not candidate("wires")
	assert not candidate(("not", "wires", 0))
	assert not candidate( "12" )
	assert not candidate( ("notwires", 0) )
	assert candidate(1) == False
	assert candidate(("wires", 0))
	assert not candidate("not a wire")
	assert not candidate( 0 )
	assert not candidate( "wires" )
	assert candidate(("a", "b")) == False
	assert candidate(("wires", 2, 3)) == True
	assert candidate( ("wires", 0) )
	assert not candidate( ["wires", "12", "34", "56", "78"] )
def test_check():
	check(is_wire)
