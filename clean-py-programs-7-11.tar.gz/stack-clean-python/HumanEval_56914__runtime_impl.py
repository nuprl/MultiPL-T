def _runtime_impl(f):
    """marks a generic function as being runtime-implemented"""
    ### Canonical solution below ###
    f.__runtime_impl__ = True
    return f


### Unit tests below ###
def check(candidate):
	assert candidate(lambda: 1) is not None
	assert candidate(lambda: 42) is not None
	assert candidate(lambda x, y, z: None)._candidate__
	assert candidate(lambda x: 1)._candidate__
	assert candidate(lambda x: x)
	assert candidate(lambda x: x + 1)(1) == 2
	assert candidate(lambda x: 1)._candidate__ == True
	assert candidate(lambda x, y, z: 1)._candidate__
	assert candidate(lambda x: x)._candidate__ == True
	assert candidate(lambda x: None)._candidate__ == True
	assert candidate(lambda x, y: None)._candidate__
	assert candidate(lambda x: x)(10) == 10
	assert candidate(lambda x: x)._candidate__
	assert candidate(lambda *args: None)._candidate__ == True
	assert candidate(lambda x: x) is not None
	assert candidate(lambda x, y: x + y)(2, 3) == 5
	assert candidate(lambda x, y, z: x + y + z)(2, 3, 4) == 9
	assert candidate(lambda x: x + 1) is not None
	assert candidate(lambda: None)._candidate__ == True
	assert candidate(lambda x: x)(1) == 1
	assert candidate(lambda **kwargs: None)._candidate__ == True
	assert candidate(lambda **kwargs: 1)._candidate__ == True
	assert candidate(lambda: None)._candidate__
	assert candidate(lambda: 1)._candidate__
	assert candidate(lambda: 42)._candidate__
	assert candidate(lambda x: None)._candidate__
	assert candidate(lambda: 1)._candidate__ == True
	assert candidate(lambda x, y: None)._candidate__ == True
	assert candidate(lambda x: x)._candidate__ is True
	assert candidate(lambda x, y: 1)._candidate__ == True
	assert candidate(lambda x: x + 1)(2) == 3
	assert candidate(lambda x, y: 1)._candidate__
	assert candidate(lambda: None)._candidate__ is True
	assert not candidate(lambda: None)._candidate__ is False
	assert candidate(lambda x: x + 1)._candidate__
	assert candidate(lambda x, y, z, w: None)._candidate__
	assert candidate(lambda *args: 1)._candidate__ == True
	assert candidate(lambda x, y, z: None)._candidate__ == True
def test_check():
	check(_runtime_impl)
