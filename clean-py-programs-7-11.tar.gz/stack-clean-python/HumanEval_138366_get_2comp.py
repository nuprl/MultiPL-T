def get_2comp(val_int, val_size=16):
    """ Get the 2's complement of Python int val_int
     :param val_int: int value to apply 2's complement
     :type val_int: int
     :param val_size: bit size of int value (word = 16, long = 32) (optional)
     :type val_size: int
     :returns: 2's complement result
     :rtype: int
     """
	### Canonical solution below ###    
    # test MSBit (1 for negative)
    if val_int & (1 << (val_size - 1)):
        # do complement
        val_int -= 1 << val_size
    return val_int

### Unit tests below ###
def check(candidate):
	assert candidate(0x000B, 16) == 0x000B
	assert candidate(0x000C) == 12
	assert candidate(0x0004) == 4
	assert candidate(0x0016) == 22
	assert candidate(0x01) == 1
	assert candidate(0x000C, 16) == 0x000C
	assert candidate(0x04) == 0x04
	assert candidate(0x0000FFFF, 32) == 65535
	assert candidate(3, 32) == 3
	assert candidate(0x7fffffff, 32) == 2147483647
	assert candidate(0x7FF7) == 32759
	assert candidate(0x7FF5) == 32757
	assert candidate(0x15) == 0x15
	assert candidate(0x0009) == 9
	assert candidate(0x01) == 0x01
	assert candidate(0xFFFF, 16) == -1
	assert candidate(0x00) == 0x00
	assert candidate(0x0001, 16) == 1
	assert candidate(0x0008, 16) == 0x0008
	assert candidate(0x7FFE) == 32766
	assert candidate(0x000D) == 13
	assert candidate(0x0006) == 6
	assert candidate(0x0000, 8) == 0x00
	assert candidate(0x06) == 0x06
	assert candidate(1, 32) == 1
	assert candidate(0x7FFE, 16) == 32766
	assert candidate(0x1234, 32) == 0x1234
	assert candidate(12345, 32) == 12345
	assert candidate(0x0A) == 0x0A
	assert candidate(0x7FFB) == 32763
	assert candidate(0x0009, 16) == 0x0009
	assert candidate(1, 16) == 1
	assert candidate(0x05) == 0x05
	assert candidate(0x0001, 8) == 0x01
	assert candidate(0x0007) == 7
	assert candidate(0, 16) == 0
	assert candidate(0x0001, 32) == 1
	assert candidate(0x7fffffffffffffff, 64) == 9223372036854775807
	assert candidate(0xFF, 8) == -1
	assert candidate(3, 16) == 3
	assert candidate(123) == 123
	assert candidate(0x12) == 0x12
	assert candidate(0x0E) == 0x0E
	assert candidate(0x7FFD, 16) == 0x7FFD
	assert candidate(0x8000, 32) == 0x8000
	assert candidate(0x0010) == 16
	assert candidate(12345) == 12345
	assert candidate(0x8000000000000000, 64) == -9223372036854775808
	assert candidate(0x0000, 16) == 0
	assert candidate(0x7FFC) == 32764
	assert candidate(0x11) == 0x11
	assert candidate(0x800D, 16)
	assert candidate(0x8001, 16) == -32767
	assert candidate(0x00FF) == 0x00FF
	assert candidate(0x02) == 0x02
	assert candidate(0x0C) == 0x0C
	assert candidate(0x0006, 16) == 0x0006
	assert candidate(0xFFFF, 32) == 0xFFFF
	assert candidate(0x0003) == 3
	assert candidate(0, 32) == 0
	assert candidate(0x7FFFFFFF, 32) == 0x7FFFFFFF
	assert candidate(0x7FFD) == 32765
	assert candidate(0x0000) == 0
	assert candidate(0x08) == 0x08
	assert candidate(0x7FF6) == 32758
	assert candidate(0x8002) == -32766
	assert candidate(0x13) == 0x13
	assert candidate(2, 32) == 2
	assert candidate(0x0000, 32) == 0x0000
	assert candidate(0x8001) == -32767
	assert candidate(0x0014) == 20
	assert candidate(0x0011) == 17
	assert candidate(12345, 8) == 12345
	assert candidate(0x0003, 16) == 0x0003
	assert candidate(0x00008000, 32) == 32768
	assert candidate(0x7FF9) == 32761
	assert candidate(2, 16) == 2
	assert candidate(0x80000000, 32) == -0x80000000
	assert candidate(1 << 15) == -1 << 15
	assert candidate(0x1234, 16) == 0x1234
	assert candidate(0x8000, 16) == -0x8000
	assert candidate(0x03) == 0x03
	assert candidate(0x0080) == 0x0080
	assert candidate(0x07) == 0x07
	assert candidate(0xFFFFFFFFFFFFFFFF, 64) == -1
	assert candidate(0x7FFF) == 32767
	assert candidate(0x7FFFFFFE, 32) == 2147483646
	assert candidate(0x8000) == -32768
	assert candidate(0x0F) == 0x0F
	assert candidate(2**16 - 1, 16) == -1
	assert candidate(0x0001) == 1
	assert candidate(0x007f) == 127
	assert candidate(0x00000001, 16) == 0x0001
	assert candidate(0x0008) == 8
	assert candidate(0x80000000, 32) == -2147483648
	assert candidate(0xFFFF) == -1
	assert candidate(0x000A, 16) == 0x000A
	assert candidate(0x1234) == 0x1234
	assert candidate(0x0015) == 21
	assert candidate(0x14) == 0x14
	assert candidate(0x0001, 16) == 0x0001
	assert candidate(0x0002, 16) == 0x0002
	assert candidate(0x7FFA) == 32762
	assert candidate(12345, 16) == 12345
	assert candidate(0x7FF3) == 32755
	assert candidate(0x16) == 0x16
	assert candidate(0x000E, 16) == 0x000E
	assert candidate(0x00000000, 32) == 0
	assert candidate(0x0012) == 18
	assert candidate(0x0B) == 0x0B
	assert candidate(0x0005, 16) == 0x0005
	assert candidate(0x09) == 0x09
	assert candidate(0x7fff, 16) == 32767
	assert candidate(0x000E) == 14
	assert candidate(127, 8) == 127
	assert candidate(0x7FF2) == 32754
	assert candidate(0x0D) == 0x0D
	assert candidate(0x0000) == 0x0000
	assert candidate(0x80000001, 32) == -2147483647
	assert candidate(4294967295, 32) == -1
	assert candidate(0x0013) == 19
	assert candidate(0x000B) == 11
	assert candidate(0x10) == 0x10
	assert candidate(0x000D, 16) == 0x000D
	assert candidate(0x7FFF, 16) == 32767
	assert candidate(0x0004, 16) == 0x0004
	assert candidate(0xffff, 32) == 0xffff
	assert candidate(0x8000, 16) == -32768
	assert candidate(0x0005) == 5
	assert candidate(0x000A) == 10
	assert candidate(0xFFFFFFFF, 32) == -1
	assert candidate(65535, 16) == -1
	assert candidate(0x000F) == 15
	assert candidate(0x7FF8) == 32760
	assert candidate(0x0081) == 0x0081
	assert candidate(0x00) == 0
	assert candidate(0x7FFF, 16) == 0x7FFF
	assert candidate(0x00000000, 16) == 0x0000
	assert candidate(1) == 1
	assert candidate(0x7F) == 127
	assert candidate(0x0002) == 2
	assert candidate(0x0000, 16) == 0x0000
	assert candidate(0x8003) == -32765
	assert candidate(0) == 0
	assert candidate(0x007F) == 0x007F
	assert candidate(0x7FF4) == 32756
	assert candidate(0x7FFE, 16) == 0x7FFE
	assert candidate(0x0001, 32) == 0x0001
	assert candidate(255, 8) == -1
	assert candidate(128, 8) == -128
	assert candidate(0x0007, 16) == 0x0007
	assert candidate(0x7fff) == 32767
	assert candidate(0x7FFFFFFF, 32) == 2147483647
def test_check():
	check(get_2comp)
