def deep_merge_dicts(dict_to, dict_from):
    """ 
     Function takes dictionaries to merge
     
     Merge dict_from to dict_to and returns dict_to
     """
	### Canonical solution below ###    

    if not dict_to and not dict_from:
        return dict_to

    if not dict_to:
        return dict_from

    if not isinstance(dict_to, dict):
        return dict_to

    if not dict_from or not isinstance(dict_from, dict):
        # either dict_from is None/empty or is last value whose key matched
        # already, so no need to add
        return dict_to

    for _key in dict_from.keys():
        if _key not in dict_to:
            dict_to[_key] = dict_from[_key]
        else:
            dict_to[_key] = deep_merge_dicts(dict_to[_key], dict_from[_key])

    return dict_to

### Unit tests below ###
def check(candidate):
	assert candidate({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
	assert candidate({'a': 1, 'b': 2}, {}) == {'a': 1, 'b': 2}
	assert candidate({}, {'a': {'b': 'c'}}) == {'a': {'b': 'c'}}
	assert candidate({}, {"a": 1}) == {"a": 1}
	assert candidate({"a": 1, "b": {"c": 3}}, {"b": {"d": 4}}) == {"a": 1, "b": {"c": 3, "d": 4}}
	assert candidate({"key": "value"}, {"new_key": "new_value"}) == {"key": "value", "new_key": "new_value"}
	assert candidate({"key": "value"}, None) == {"key": "value"}
	assert candidate({'a': {'b': {'c': 1}}}, {'a': {'b': {'d': 2}}}) == {'a': {'b': {'c': 1, 'd': 2}}}
	assert candidate({"a": 1, "b": 2}, {"a": 1}) == {"a": 1, "b": 2}
	assert candidate({'a': {'b': 'c'}}, {'a': {'d': 'e'}}) == {'a': {'b': 'c', 'd': 'e'}}
	assert candidate({'a': {'b': 2}}, {'a': {'c': 3}}) == {'a': {'b': 2, 'c': 3}}
	assert candidate({1: 2, 3: 4}, {2: 3}) == {1: 2, 3: 4, 2: 3}
	assert candidate({'a': 1, 'b': 2}, {'c': 3, 'd': 4}) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
	assert candidate({1: {2: 3}}, {1: {4: 5}}) == {1: {2: 3, 4: 5}}
	assert candidate({"a": {"b": 1}}, {"a": {"c": 2}}) == {"a": {"b": 1, "c": 2}}
	assert candidate({'a': 1}, {'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate({'a': 1, 'b': 2, 'c': {'d': 1, 'e': 2}}, {'c': {'f': 3}}) == {'a': 1, 'b': 2, 'c': {'d': 1, 'e': 2, 'f': 3}}
	assert candidate({'a': 1}, {'a': 1}) == {'a': 1}
	assert candidate({'a': {'a': 1}}, {'a': {'b': 1}}) == {'a': {'a': 1, 'b': 1}}
	assert candidate(
    {'a': 1},
    {'b': 2}
) == {'a': 1, 'b': 2}
	assert candidate({"a": 1, "b": {"c": 2}}, {"b": {"d": 3}}) == {"a": 1, "b": {"c": 2, "d": 3}}
	assert candidate(None, None) == None
	assert candidate({}, {'a': 1}) == {'a': 1}
	assert candidate({"a": 1, "b": 2}, {"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
	assert candidate({"a": 1}, {"b": {"c": 2, "d": 3}}) == {
    "a": 1,
    "b": {"c": 2, "d": 3},
}
	assert candidate({1: 1, 2: 2}, {3: 3}) == {1: 1, 2: 2, 3: 3}
	assert candidate({"a": {"b": 1}}, {"a": {"b": 1, "c": 2}}) == {"a": {"b": 1, "c": 2}}
	assert candidate({"a": 1}, {"b": 1}) == {"a": 1, "b": 1}
	assert candidate(
    {'key': 'val', 'key2': {'key3': 'val3'}},
    {'key': 'val2', 'key2': {'key4': 'val4', 'key5': 'val5'}}) == {
    'key': 'val',
    'key2': {'key3': 'val3', 'key4': 'val4', 'key5': 'val5'}}
	assert candidate({}, None) == {}
	assert candidate({"a": 1}, {"b": {"c": 2}}) == {"a": 1, "b": {"c": 2}}
	assert candidate({"key": "value"}, {"key": "value"}) == {"key": "value"}
	assert candidate(None, {"a": 1}) == {"a": 1}
	assert candidate({"a": 1, "b": {"c": 2}}, {"b": {"d": 3}}) == {
    "a": 1,
    "b": {"c": 2, "d": 3},
}
	assert candidate({"a": 1, "b": 1}, {"a": 1}) == {"a": 1, "b": 1}
	assert candidate({"key": {"key2": "value"}}, {"key": {"key3": "value"}}) == {"key": {"key2": "value", "key3": "value"}}
	assert candidate({'a': 1}, {}) == {'a': 1}
	assert candidate(None, None) is None
	assert candidate({"a": 1}, None) == {"a": 1}
	assert candidate({}, {'a': 'b'}) == {'a': 'b'}
	assert candidate(None, {}) is None
	assert candidate({'a': 1, 'b': 2}, {'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate({}, {1: 2}) == {1: 2}
	assert candidate({1: 2}, {}) == {1: 2}
	assert candidate({'a': 1, 'b': {'c': 2}}, {'b': {'d': 3}}) == {'a': 1, 'b': {'c': 2, 'd': 3}}
	assert candidate({}, {}) == {}
	assert candidate({'a': 1}, None) == {'a': 1}
	assert candidate({'a': {'b': 1}}, {'a': {'c': 2}}) == {'a': {'b': 1, 'c': 2}}
	assert candidate({1: 2}, {1: 2}) == {1: 2}
	assert candidate(
    {'key': 'val', 'key2': {'key3': 'val3'}},
    {'key': 'val2', 'key2': {'key4': 'val4'}}) == {
    'key': 'val',
    'key2': {'key3': 'val3', 'key4': 'val4'}}
	assert candidate({"a": {"b": 1}}, {"a": {"c": {"d": 2}}}) == {"a": {"b": 1, "c": {"d": 2}}}
	assert candidate({"a": 1}, {}) == {"a": 1}
	assert candidate(
    {'key': 'val', 'key2': {'key3': 'val3'}},
    {'key': 'val2', 'key2': {'key4': {'key5': 'val5'}}}) == {
    'key': 'val',
    'key2': {'key3': 'val3', 'key4': {'key5': 'val5'}}}
	assert candidate({1: 2}, {2: 3}) == {1: 2, 2: 3}
	assert candidate({'a': 1}, {'b': 1}) == {'a': 1, 'b': 1}
	assert candidate({"a": 1}, {"b": 2}) == {"a": 1, "b": 2}
	assert candidate({"a": {"b": 1}}, {"a": {"b": 1}}) == {"a": {"b": 1}}
	assert candidate(None, {"key": "value"}) == {"key": "value"}
	assert candidate({"a": 1, "b": 2, "c": 3}, {"a": 1, "b": 2}) == {"a": 1, "b": 2, "c": 3}
	assert candidate({"a": 1}, {"a": 1}) == {"a": 1}
	assert candidate({"a": 1, "b": 2}, {"a": 1, "b": 2}) == {"a": 1, "b": 2}
	assert candidate({'a': 'b'}, {}) == {'a': 'b'}
	assert candidate(
    {'a': 1, 'b': 2},
    {'c': 3}
) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(None, {'a': 1}) == {'a': 1}
	assert candidate({"a": 1}, {"a": 1, "b": 1}) == {"a": 1, "b": 1}
	assert candidate({'a': 1, 'b': 2}, None) == {'a': 1, 'b': 2}
	assert candidate({'a': {'b': 'c'}}, {}) == {'a': {'b': 'c'}}
def test_check():
	check(deep_merge_dicts)
