def lorentz(v, v0, I, w):
    """
    A lorentz function that takes linewidth at half intensity (w) as a
    parameter.

    When `v` = `v0`, and `w` = 0.5 (Hz), the function returns intensity I.

    Arguments
    ---------
    v : float
        The frequency (x coordinate) at which to evaluate intensity (y
        coordinate).
    v0 : float
        The center of the distribution.
    I : float
        the relative intensity of the signal
    w : float
        the peak width at half maximum intensity

    Returns
    -------
    float
        the intensity (y coordinate) for the Lorentzian distribution
        evaluated at frequency `v`.
    """
    ### Canonical solution below ###
    # Adding a height scaling factor so that peak intensities are lowered as
    # they are more broad. If I is the intensity with a default w of 0.5 Hz:
    scaling_factor = 0.5 / w  # i.e. a 1 Hz wide peak will be half as high
    return scaling_factor * I * (
            (0.5 * w) ** 2 / ((0.5 * w) ** 2 + (v - v0) ** 2))


### Unit tests below ###
def check(candidate):
	assert candidate(0, 0, 1, 0.5) == 1
	assert candidate(v=0, v0=0, I=1, w=0.5) == 1
	assert candidate(1.0, 0.0, 1.0, 2.0) == 0.125
	assert candidate(0.0, 0.0, 1.0, 256.0) == 0.001953125
	assert candidate(0.0, 0.0, 1.0, 64.0) == 0.0078125
	assert candidate(-1.0, 0.0, 1.0, 2.0) == 0.125
	assert candidate(0.0, 0.0, 1.0, 2.0) == 0.25
	assert candidate(1, 1, 4, 1) == 2.0
	assert candidate(0.0, 0.0, 1.0, 128.0) == 0.00390625
	assert candidate(100, 100, 1, 1) == 0.5
	assert candidate(0, 0, 1, 2) == 0.25
	assert candidate(0.0, 0.0, 1.0, 1.0) == 0.5
	assert candidate(0, 0, 1, 1) == 0.5
	assert candidate(0.0, 0.0, 1.0, 32.0) == 0.015625
	assert candidate(1, 0, 1, 2) == 0.5 * 0.25
	assert candidate(100, 100, 1, 2) == 0.25
	assert candidate(0, 0, 1, 2.0) == 0.25
	assert candidate(1, 1, 1, 0.5) == 1
	assert candidate(0.0, 0.0, 1.0, 512.0) == 0.0009765625
	assert candidate(0, 0, 1, 1.0) == 0.5
	assert candidate(1, 1, 2, 1) == 1.0
	assert candidate(v=1, v0=1, I=1, w=1) == 0.5
	assert candidate(1, 0, 1, 2) == 0.125
	assert candidate(0.0, 0.0, 1.0, 8.0) == 0.0625
	assert candidate(0.0, 0.0, 1.0, 16.0) == 0.03125
	assert candidate(1, 1, 3, 1) == 1.5
	assert candidate(0, 0, 0.5, 1) == 0.25
	assert candidate(0.0, 0.0, 1.0, 0.5) == 1.0
	assert candidate(0.0, 0.0, 1.0, 4.0) == 0.125
	assert candidate(1, 0, 1, 2) == 0.5 * 0.5 / 2
	assert candidate(1, 1, 1, 1) == 0.5
def test_check():
	check(lorentz)
