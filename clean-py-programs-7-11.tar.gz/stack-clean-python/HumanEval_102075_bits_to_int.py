def bits_to_int(bits: list, base: int = 2) -> int:
    """ Converts a list of "bits" to an integer"""
	### Canonical solution below ###    
    return int("".join(bits), base)

### Unit tests below ###
def check(candidate):
	assert candidate(list("00000101")) == 5
	assert candidate(list("00001000")) == 8
	assert candidate(list("101010101010101")) == 21845
	assert candidate(list("1010")) == 10
	assert candidate(list("10101")) == 21
	assert candidate(list("00000100")) == 4
	assert candidate(list("101")) == 5
	assert candidate(list("1010"), base=2) == 10
	assert candidate(list("00000000")) == 0
	assert candidate(list("000000000000000000000000000001011")) == 11
	assert candidate(list("11111111")) == 255
	assert candidate(list('00000000'), 10) == 0
	assert candidate(list("10101010101")) == 1365
	assert candidate(list('11111111')) == 255
	assert candidate(list("1010"), 2) == 10
	assert candidate(list("101010101")) == 341
	assert candidate(list("01010101")) == 85
	assert candidate(list("00001111")) == 15
	assert candidate(list("00001011")) == 11
	assert candidate(list("10101010101010101")) == 87381
	assert candidate(list("1010101010")) == 682
	assert candidate(list("101010101010")) == 2730
	assert candidate(list("00001010")) == 10
	assert candidate(list("1010101010101")) == 5461
	assert candidate(list("00010000")) == 16
	assert candidate(list("00001100")) == 12
	assert candidate(list("101010")) == 42
	assert candidate(list('00000000')) == 0
	assert candidate(list("00000011")) == 3
	assert candidate(list("10101010101010")) == 10922
	assert candidate(list("00110")) == 6
	assert candidate(list("1010101010101010")) == 43690
	assert candidate(list("10101010")) == 170
	assert candidate(list("00000010")) == 2
	assert candidate(list("00010001")) == 17
	assert candidate(list("00001110")) == 14
	assert candidate(list("1010101")) == 85
	assert candidate(list("00000001")) == 1
	assert candidate(list("00001001")) == 9
	assert candidate(list("00001101")) == 13
	assert candidate(list('10000000')) == 128
	assert candidate(list("00000110")) == 6
	assert candidate(list("00000111")) == 7
def test_check():
	check(bits_to_int)
