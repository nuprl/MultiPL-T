def single_letter_count(word, letter):
    """How many times does letter appear in word (case-insensitively)?
    
        >>> single_letter_count('Hello World', 'h')
        1
        
        >>> single_letter_count('Hello World', 'z')
        0
        
        >>> single_letter_count("Hello World", 'l')
        3
    """
    ### Canonical solution below ###
    new = word.lower()
    return new.count(letter)


### Unit tests below ###
def check(candidate):
	assert candidate(word='Hello World', letter='h') == 1, "candidate('Hello World', 'h')"
	assert candidate(u'HELLO WORLD', u'h') == 1
	assert candidate(
    'Hello World', 'z') == 0, "Should be 0"
	assert candidate(
    'HELLO WORLD', 'h') == 1, "Should be 1"
	assert candidate( "Hello World", "h" ) == 1
	assert candidate( "Hello World", "l") == 3
	assert candidate("Hello World", 'l') == 3
	assert candidate(word='Hello World', letter='l') == 3, "candidate('Hello World', 'l')"
	assert candidate(
    "Hello World", 'h') == 1, "candidate('Hello World', 'h') is incorrect."
	assert candidate( "Hello World", 'l' ) == 3
	assert candidate("Aaaa", 'a') == 4, "Should be 4"
	assert candidate(word='Hello World', letter='z') == 0
	assert candidate(u'Hello, World!', u'H') == 0
	assert candidate( "Hello World", "z") == 0
	assert candidate( 'Hello World', 'z') == 0
	assert candidate( 'Hello World', 'z' ) == 0
	assert candidate( "Hello World", "h") == 1
	assert candidate(word="Hello World", letter='l') == 3
	assert candidate(u'Hello, World!', u'h') == 1
	assert candidate( "Hello World", "z" ) == 0
	assert candidate(
    'Hello World', 'l') == 3, "candidate('Hello World', 'l')"
	assert candidate(u'Hello World', u'l') == 3
	assert candidate('Hello World', 'h') == 1
	assert candidate("Hello World", "l") == 3, "Should be 3"
	assert candidate("Hello World", 'l') == 3, "Should be 3"
	assert candidate(
    'Hello World', 'h') == 1, "Should be 1"
	assert candidate(word='Hello World', letter='h') == 1
	assert candidate(word='Hello World', letter='z') == 0, "candidate('Hello World', 'z')"
	assert candidate(
    "Hello World", 'l') == 3,'single letter count'
	assert candidate(u'hello, world!', u'H') == 0
	assert candidate(u'Hello World', u'z') == 0
	assert candidate( 'Hello World', 'h') == 1
	assert candidate("Hello World", 'z') == 0
	assert candidate(
    "Hello World", "h") == 1, "Should be 1"
	assert candidate("Hello World", 'x') == 0, "Should be 0"
	assert candidate( "Hello World", 'l') == 3
	assert candidate(
    "Hello World", 'z') == 0, "candidate('Hello World', 'z') is incorrect."
	assert candidate(word='Hello World', letter='h') == 1,'candidate(word=\'Hello World\', letter=\'h\')'
	assert candidate(
    'HELLO WORLD', 'z') == 0, "Should be 0"
	assert candidate("aaaa", 'a') == 4, "Should be 4"
	assert candidate(u'hello, world!', u'h') == 1
	assert candidate(word='Hello World', letter='l') == 3
	assert candidate( "Hello World", 'z') == 0
	assert candidate(
    'Hello World', 'z') == 0,'single letter count'
	assert candidate(
    "Hello World", 'l') == 3, "Should be 3"
	assert candidate(word='Hello World', letter='z') == 0,'candidate(word=\'Hello World\', letter=\'z\')'
	assert candidate(
    'Hello World', 'h') == 1,'single letter count'
	assert candidate(
    'Hello World', 'z') == 0, "candidate('Hello World', 'z')"
	assert candidate(word='Hello World', letter='l') == 3,'candidate(word=\'Hello World\', letter=\'l\')'
	assert candidate("Hello World", "z") == 0, "Should be 0"
	assert candidate(
    "Hello World", 'l') == 3, "candidate('Hello World', 'l') is incorrect."
	assert candidate('Hello World', 'z') == 0, "Should be 0"
	assert candidate(u"Hello World", u'l') == 3, "candidate(u'Hello World', u'l') returns 3"
	assert candidate( "Hello World", 'h') == 1
	assert candidate(u'Hello World', u'h') == 1
	assert candidate( 'Hello World', 'o') == 2
	assert candidate( "", 'o') == 0
	assert candidate(
    'Hello World', 'h') == 1, "candidate('Hello World', 'h')"
	assert candidate(u'Hello World', u'z') == 0, "candidate(u'Hello World', u'z') returns 0"
	assert candidate('Hello World', 'z') == 0
	assert candidate(
    "HELLO WORLD", 'l') == 3, "Should be 3"
	assert candidate( "Hello World", "l" ) == 3
	assert candidate(u'Hello World', u'H') == 0
	assert candidate( 'Hello World', 'h' ) == 1
	assert candidate(u'Hello World', u'h') == 1, "candidate(u'Hello World', u'h') returns 1"
	assert candidate(
    'hitchhiker\'s guide to the galaxy', 'g') == 2, "Should be 2"
def test_check():
	check(single_letter_count)
