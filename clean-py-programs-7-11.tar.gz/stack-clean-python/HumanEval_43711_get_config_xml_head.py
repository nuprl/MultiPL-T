def get_config_xml_head(head_xpath):
    """Get xml head string when config.
    Args:
        head_xpath: The string of xpath_key.
    Returns:
        xml_head_str: The xml head str.
    """
    ### Canonical solution below ###
    xml_head_str = "<config>"
    for item in head_xpath.split("/")[1:]:
        xml_head_str = xml_head_str + "<" + item + ">"
    return xml_head_str


### Unit tests below ###
def check(candidate):
	assert candidate(head_xpath="/a/b/c/d/e/f") == "<config><a><b><c><d><e><f>"
	assert candidate(head_xpath="/a/b/c/d") == "<config><a><b><c><d>"
	assert candidate(
    head_xpath="/devices/device/config/aaa/authentication/users/user/username") == \
    "<config><devices><device><config><aaa><authentication><users><user><username>"
	assert candidate(
    "/devices/entry/deviceconfig/system/login/user/user-list/user/aaa") == "<config><devices><entry><deviceconfig><system><login><user><user-list><user><aaa>"
	assert candidate(
    head_xpath="/sonic-port:sonic-port/PORT/PORT_LIST/PORT") == \
        "<config><sonic-port:sonic-port><PORT><PORT_LIST><PORT>"
	assert candidate(
    "/native/ip/igmp/interfaces/interface/igmp-snooping/global") == "<config><native><ip><igmp><interfaces><interface><igmp-snooping><global>"
	assert candidate(
    "data/network-instances/network-instance/protocols/protocol/bgp/neighbors") == "<config><network-instances><network-instance><protocols><protocol><bgp><neighbors>", \
    "candidate failed"
	assert candidate(
    head_xpath="/sonic-port:sonic-port/PORT") == \
        "<config><sonic-port:sonic-port><PORT>"
	assert candidate(
    head_xpath="/system/login/user"
) == "<config><system><login><user>", "candidate() error!"
	assert candidate(head_xpath="/interface/ethernet/switchport/trunk") == "<config><interface><ethernet><switchport><trunk>", "candidate function error"
	assert candidate(
    "/devices/entry/deviceconfig/system/login/user/user-list/user") == "<config><devices><entry><deviceconfig><system><login><user><user-list><user>"
	assert candidate(head_xpath="/a/b/c") == "<config><a><b><c>"
	assert candidate(head_xpath="/a/b/c/d/e") == "<config><a><b><c><d><e>"
	assert candidate(
    "/system/services/ssh/server/netconf-subsystem/netconf-server/listen/endpoint") == \
    "<config><system><services><ssh><server><netconf-subsystem><netconf-server><listen><endpoint>"
	assert candidate(
    "/native/ip/igmp/interfaces/interface/igmp-snooping/group/static-group/source/static-source") == "<config><native><ip><igmp><interfaces><interface><igmp-snooping><group><static-group><source><static-source>"
	assert candidate(
    "/native/ip/igmp/interfaces/interface/igmp-snooping/group/static-group/source/static-source/group-address") == "<config><native><ip><igmp><interfaces><interface><igmp-snooping><group><static-group><source><static-source><group-address>"
	assert candidate(
    head_xpath="/sonic-port:sonic-port/PORT/PORT_LIST") == \
        "<config><sonic-port:sonic-port><PORT><PORT_LIST>"
	assert candidate(
    "/native/ip/igmp/interfaces/interface/igmp-snooping/group") == "<config><native><ip><igmp><interfaces><interface><igmp-snooping><group>"
	assert candidate(head_xpath="/ifmgr/interfaces/interface") == "<config><ifmgr><interfaces><interface>"
	assert candidate(
    "data/network-instances/network-instance/protocols/protocol/bgp/neighbors/neighbor/afi-safis") == "<config><network-instances><network-instance><protocols><protocol><bgp><neighbors><neighbor><afi-safis>", \
    "candidate failed"
	assert candidate(head_xpath="/ifmgr/interfaces/interface/unit") == "<config><ifmgr><interfaces><interface><unit>"
	assert candidate(
    head_xpath="/sonic-port:sonic-port") == \
        "<config><sonic-port:sonic-port>"
	assert candidate(head_xpath="/ifmgr/interfaces/interface/unit/family") == "<config><ifmgr><interfaces><interface><unit><family>"
	assert candidate(
    "/native/ip/igmp/interfaces/interface/igmp-snooping/group/static-group/source") == "<config><native><ip><igmp><interfaces><interface><igmp-snooping><group><static-group><source>"
	assert candidate(
    "data/network-instances/network-instance/protocols/protocol/bgp/neighbors/neighbor/afi-safis/afi-safi") == "<config><network-instances><network-instance><protocols><protocol><bgp><neighbors><neighbor><afi-safis><afi-safi>", \
    "candidate failed"
	assert candidate(
    "/native/ip/igmp/interfaces/interface/igmp-snooping/group/static-group") == "<config><native><ip><igmp><interfaces><interface><igmp-snooping><group><static-group>"
	assert candidate(
    "/devices/entry/deviceconfig/system/login/user/user-list/user/aaa/authentication") == "<config><devices><entry><deviceconfig><system><login><user><user-list><user><aaa><authentication>"
	assert candidate(head_xpath="/ifmgr/interfaces") == "<config><ifmgr><interfaces>"
	assert candidate(
    "data/network-instances/network-instance/protocols/protocol/bgp/neighbors/neighbor") == "<config><network-instances><network-instance><protocols><protocol><bgp><neighbors><neighbor>", \
    "candidate failed"
	assert candidate(
    "data/network-instances/network-instance/protocols/protocol/bgp") == "<config><network-instances><network-instance><protocols><protocol><bgp>", \
    "candidate failed"
	assert candidate(head_xpath="/a/b/c/d/e/f/g") == "<config><a><b><c><d><e><f><g>"
	assert candidate(
    "/devices/entry/deviceconfig/system/login/user") == "<config><devices><entry><deviceconfig><system><login><user>"
	assert candidate(
    "/devices/entry/deviceconfig/system/login/user/user-list/user/aaa/authentication/password") == "<config><devices><entry><deviceconfig><system><login><user><user-list><user><aaa><authentication><password>"
def test_check():
	check(get_config_xml_head)
