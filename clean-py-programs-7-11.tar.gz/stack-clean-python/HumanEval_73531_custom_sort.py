def custom_sort(stack):
    """Custom version of list sort. This should never be used."""
    ### Canonical solution below ###
    new_stack = []
    while len(stack):
        temp = stack.pop()
        while len(new_stack) and new_stack[-1] > temp:
            stack.append(new_stack.pop())
        new_stack.append(temp)
    return new_stack


### Unit tests below ###
def check(candidate):
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate([5, 3, 1, 2]) == [1, 2, 3, 5]
	assert candidate(stack=[1, 3, 2, 5, 4]) == [1, 2, 3, 4, 5]
	assert candidate(stack=[1, 0, 2]) == [0, 1, 2]
	assert candidate([2, 4, 1, 3]) == [1, 2, 3, 4]
	assert candidate([1, 5, 3, 2]) == [1, 2, 3, 5]
	assert candidate([1, 3, 2, 5]) == [1, 2, 3, 5]
	assert candidate(stack=[5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate(list('zyx')) == ['x', 'y', 'z']
	assert candidate([5, 1, 3, 2]) == [1, 2, 3, 5]
	assert candidate([2, 3, 1, 5]) == [1, 2, 3, 5]
	assert candidate(stack=[3, 2, 1, 0, 4]) == [0, 1, 2, 3, 4]
	assert candidate(stack=[2, 4, 7, 1, 3, 9, 6, 5, 8]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(stack=[0, 0, 0, 0, 0]) == [0, 0, 0, 0, 0]
	assert candidate(stack=[3, 2, 1]) == [1, 2, 3]
	assert candidate([1]) == [1]
	assert candidate([2, 1]) == [1, 2]
	assert candidate(stack=[9, 8, 7, 6, 5, 4, 3, 2, 1, 0]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([]) == []
	assert candidate(stack=[1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
	assert candidate(stack=[4, 3, 1, 2]) == [1, 2, 3, 4]
	assert candidate(list('abc')) == ['a', 'b', 'c']
	assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
	assert candidate(list('cba')) == ['a', 'b', 'c']
	assert candidate(stack=[3, 2, 1, 0]) == [0, 1, 2, 3]
	assert candidate(stack=[1, 2, 3]) == [1, 2, 3]
	assert candidate(stack=[2, 2, 2, 2, 2]) == [2, 2, 2, 2, 2]
	assert candidate(list("cba")) == list("abc")
	assert candidate([1, 2, 4, 3]) == [1, 2, 3, 4]
	assert candidate(stack=[1, 3, 5, 7, 9, 2, 4, 6, 8, 0]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 3, 5, 7, 2, 4, 6]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(stack=[5, 4, 3, 2, 1, 0]) == [0, 1, 2, 3, 4, 5]
	assert candidate([1, 5, 2, 3]) == [1, 2, 3, 5]
	assert candidate(stack=[2, 1, 0]) == [0, 1, 2]
	assert candidate([3, 2, 1, 4]) == [1, 2, 3, 4]
	assert candidate([5, 1, 3, 4, 2]) == [1, 2, 3, 4, 5]
	assert candidate(list()) == list()
	assert candidate(stack=[4, 3, 2, 1, 0]) == [0, 1, 2, 3, 4]
	assert candidate([1, 3, 2]) == [1, 2, 3]
	assert candidate([4, 3, 2, 1]) == [1, 2, 3, 4]
	assert candidate([1, 2]) == [1, 2]
	assert candidate([5, 1, 2, 3]) == [1, 2, 3, 5]
	assert candidate([3, 2, 1]) == [1, 2, 3]
	assert candidate([2, 1, 3]) == [1, 2, 3]
	assert candidate([3, 1, 4, 2]) == [1, 2, 3, 4]
	assert candidate(stack=[1]) == [1]
	assert candidate([1, 5, 2, 6, 3, 7, 4]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate([1, 3, 5, 2]) == [1, 2, 3, 5]
	assert candidate([1, 4, 2, 3]) == [1, 2, 3, 4]
	assert candidate([1, 2, 3, 5]) == [1, 2, 3, 5]
	assert candidate(stack=[2, 3, 1]) == [1, 2, 3]
	assert candidate(stack=[2, 4, 7, 1, 3, 9, 6, 5, 8])!= [1, 2, 3, 4, 5, 6, 7, 8, 9][::-1]
	assert candidate(stack=[4, 3, 2, 1, 0, 5]) == [0, 1, 2, 3, 4, 5]
	assert candidate(stack=[1, 3, 2]) == [1, 2, 3]
	assert candidate([7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(stack=[]) == []
	assert candidate([2, 1, 4, 3]) == [1, 2, 3, 4]
def test_check():
	check(custom_sort)
