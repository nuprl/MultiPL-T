def juris_dependency_dictionary():
    """Certain fields in jurisdiction files refer to other jurisdiction files.
    E.g., ElectionDistricts are ReportingUnits"""
    ### Canonical solution below ###
    d = {'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party','Party':'Party',
         'Election':'Election'}
    return d


### Unit tests below ###
def check(candidate):
	assert candidate()['Election'] == 'Election'
	assert candidate( )['Election'] == 'Election'
	assert candidate( )['Election']=='Election'
	assert candidate( )['ElectionDistrict']=='ReportingUnit'
	assert candidate( ) == {'ElectionDistrict':'ReportingUnit', 'Office':'Office', 'PrimaryParty':'Party', 'Party':'Party', 'Election':'Election'}
	assert candidate() == {'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party',
                                       'Party':'Party','Election':'Election'}
	assert candidate(
    ) == {'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party','Party':'Party','Election':'Election'}
	assert candidate()['Office'] == 'Office', "Failed test candidate"
	assert candidate( )['PrimaryParty']=='Party'
	assert candidate(
    ) == {'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party','Party':'Party',
           'Election':'Election'}
	assert candidate(
    ) == {'ElectionDistrict': 'ReportingUnit', 'Office': 'Office', 'PrimaryParty': 'Party', 'Party': 'Party', 'Election': 'Election'}
	assert candidate( ) == { 'ElectionDistrict': 'ReportingUnit', 'Office': 'Office', 'PrimaryParty': 'Party', 'Party': 'Party', 'Election': 'Election' }
	assert candidate()['PrimaryParty'] == 'Party', "Failed test candidate"
	assert candidate( )['Office']=='Office'
	assert candidate()['Election'] == 'Election', "Failed test candidate"
	assert candidate(
)=={'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party','Party':'Party',
 'Election':'Election'}
	assert candidate( )['ElectionDistrict'] == 'ReportingUnit'
	assert candidate( )['Party'] == 'Party'
	assert candidate( ) == {'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party','Party':'Party',
         'Election':'Election'}
	assert candidate(
    )!= {'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party','Party':'Party'}
	assert candidate(
) == {'ElectionDistrict':'ReportingUnit','Office':'Office','PrimaryParty':'Party','Party':'Party',
      'Election':'Election'}
	assert candidate()['Party'] == 'Party', "Failed test candidate"
	assert candidate()['Office'] == 'Office'
	assert candidate( )['PrimaryParty'] == 'Party'
	assert candidate( )['Party']=='Party'
	assert candidate(

)
	assert candidate( )['Office'] == 'Office'
	assert candidate( )['ElectionDistrict'] == 'ReportingUnit', "Failed test candidate"
	assert candidate( ) == {'ElectionDistrict':'ReportingUnit','Office':'Office',
    'PrimaryParty':'Party','Party':'Party','Election':'Election'}
def test_check():
	check(juris_dependency_dictionary)
