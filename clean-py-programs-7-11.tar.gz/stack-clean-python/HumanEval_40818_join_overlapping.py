def join_overlapping(s, e):
    """ Join overlapping intervals.
     
     Transforms a list of possible overlapping intervals into non-overlapping
     intervals.
     
     Parameters
     ----------
     s : list
     List with start of interval sorted in ascending order
     e : list
     List with end of interval.
     
     Returns
     -------
     tuple
     `tuple` (s, e) of non-overlapping intervals.
     """
	### Canonical solution below ###    
    rs = []
    re = []
    n = len(s)
    if n == 0:
        return (rs, re)
    l = s[0]
    r = e[0]
    for i in range(1, n):
        if s[i] > r:
            rs.append(l)
            re.append(r)
            l = s[i]
            r = e[i]
        else:
            r = max(r, e[i])
    rs.append(l)
    re.append(r)
    return (rs, re)

### Unit tests below ###
def check(candidate):
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 4]) == ([1, 2, 3, 4], [1, 2, 3, 4])
	assert candidate(
    [0, 1, 2, 3, 4], [0, 0, 0, 0, 0])
	assert candidate([1, 3, 5], [2, 4, 6]) == ([1, 3, 5], [2, 4, 6])
	assert candidate(
    [1, 2, 3, 4], [1, 2, 3, 4]) == ([1, 2, 3, 4], [1, 2, 3, 4])
	assert candidate(
    [0, 1, 2, 3, 4], [0, 1, 2, 3, 4]) == ([0, 1, 2, 3, 4], [0, 1, 2, 3, 4])
	assert candidate([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]) == ([1, 2, 3, 4, 5], [1, 2, 3, 4, 5])
	assert candidate(list(range(10)), list(range(10))) == (list(range(10)), list(range(10)))
	assert candidate([], []) == ([], [])
	assert candidate([1, 3, 5, 7], [2, 4, 6, 8]) == ([1, 3, 5, 7], [2, 4, 6, 8])
def test_check():
	check(join_overlapping)
