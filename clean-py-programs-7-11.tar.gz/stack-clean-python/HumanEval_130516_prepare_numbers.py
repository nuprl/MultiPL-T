def prepare_numbers(numbers):
    """Prepares the numbers for the chatbot to interpret.
    
    Parameters
    ----------
    numbers : list
        Numbers that the user has input into the chatbot
        
    Returns
    -------
    numb : list
        List of integers that the chatbot can use to put into the calculator.
    """
    ### Canonical solution below ###
    
    numb = []
    for item in numbers:
        numb.append(int(item))
    return numb


### Unit tests below ###
def check(candidate):
	assert candidate(numbers = ['10', '20', '30']) == [10, 20, 30]
	assert candidate(numbers=['1']) == [1], "The function is not working."
	assert candidate(numbers = ["1"]) == [1], "Test 1: Prepare numbers 1."
	assert candidate(numbers=['1','2','3','4','5','6','7','8','9','10']) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(numbers = ["1", "2", "3", "4"]) == [1, 2, 3, 4], "Test 4: Prepare numbers 4."
	assert candidate(numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(numbers = ['10', '20', '30', '40', '50', '60', '70', '80', '90', '100']) == [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
	assert candidate(numbers=['1','2','3','4','5','6','7']) == [1,2,3,4,5,6,7], "The function is not working."
	assert candidate(numbers=['4', '7']) == [4, 7]
	assert candidate(numbers = ['2', '3', '4']) == [2, 3, 4]
	assert candidate(numbers=["1", "2", "3", "4"]) == [1, 2, 3, 4]
	assert candidate(numbers=['1','2','3']) == [1,2,3]
	assert candidate(numbers=['1', '2']) == [1, 2]
	assert candidate(numbers=["1", "2", "3"]) == [1, 2, 3]
	assert candidate(numbers=["1", "2", "3", "4", "5", "6", "7"]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(numbers=['1','2','3','4','5']) == [1, 2, 3, 4, 5]
	assert candidate(numbers=['1','2','3','4','5','6','7','8','9']) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(numbers = ['3', '6', '7']) == [3, 6, 7]
	assert candidate(numbers = ["1", "2", "3", "4"]) == [1, 2, 3, 4]
	assert candidate(numbers=[]) == [], "The function is not working."
	assert candidate(numbers = ["1", "2", "3", "4", "5", "6"]) == [1, 2, 3, 4, 5, 6], "Test 6: Prepare numbers 6."
	assert candidate(numbers=['1', '2', '3', '4']) == [1, 2, 3, 4]
	assert candidate(numbers=['1', '2', '3']) == [1, 2, 3]
	assert candidate(numbers=['1','2','3']) == [1, 2, 3]
	assert candidate(numbers = ["5", "6", "7"]) == [5, 6, 7]
	assert candidate(numbers = ['1', '2', '3']) == [1, 2, 3]
	assert candidate(numbers=['1','2','3','4','5','6','7','8']) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(numbers = ["1", "2"]) == [1, 2], "Test 2: Prepare numbers 2."
	assert candidate(numbers=["2", "3", "4", "5", "6", "7"]) == [2, 3, 4, 5, 6, 7]
	assert candidate(numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20']) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
	assert candidate(numbers=["2", "5", "1", "3"]) == [2, 5, 1, 3]
	assert candidate(numbers=['1','2','3','4','5','6','7']) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(numbers=["1", "2", "3", "4", "5"]) == [1, 2, 3, 4, 5]
	assert candidate(numbers = ["1", "2", "3"]) == [1, 2, 3], "Test 3: Prepare numbers 3."
	assert candidate(numbers=["1"]) == [1]
	assert candidate(numbers = ["2", "3", "4"]) == [2, 3, 4]
	assert candidate(numbers=["3", "5", "1", "1"]) == [3, 5, 1, 1]
	assert candidate(numbers=['2', '3']) == [2, 3]
	assert candidate(numbers=['1','2']) == [1,2], "The function is not working."
	assert candidate(numbers=['1', '2', '3'])!= [1, 3, 2]
	assert candidate(numbers=['1','2','3']) == [1,2,3], "The function is not working."
	assert candidate(numbers = ["1", "2", "3", "4", "5"]) == [1, 2, 3, 4, 5], "Test 5: Prepare numbers 5."
	assert candidate(numbers=["1", "3", "5"]) == [1, 3, 5]
	assert candidate(numbers=["1", "2", "3", "4", "5", "6"]) == [1, 2, 3, 4, 5, 6]
	assert candidate(numbers=['1']) == [1]
	assert candidate(numbers = ["2", "3", "4", "5", "6"]) == [2, 3, 4, 5, 6]
	assert candidate(numbers=["1", "2"]) == [1, 2]
	assert candidate(numbers=['1','2','3','4']) == [1,2,3,4], "The function is not working."
	assert candidate(numbers=["1", "2", "3", "4", "5", "6", "7", "8"]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(numbers=['1', '3', '5', '7', '9']) == [1, 3, 5, 7, 9]
	assert candidate(numbers=['1', '2', '3'])!= [1, 2]
	assert candidate(numbers=['1', '2', '3'])!= [1, 2, 3, 4]
	assert candidate(numbers = ['1']) == [1]
def test_check():
	check(prepare_numbers)
