def degseq_to_data(degree_sequence):
    """
    Convert a degree sequence list to a sorted (max-min) integer data type.

    The input degree sequence list (of Integers) is converted to a sorted
    (max-min) integer data type, as used for faster access in the underlying
    database.

    INPUT:

    - ``degree_sequence`` -- list of integers; input degree sequence list

    EXAMPLES::

        sage: from sage.graphs.graph_database import degseq_to_data
        sage: degseq_to_data([2,2,3,1])
        3221
    """
    ### Canonical solution below ###
    degree_sequence.sort()
    return sum(degree_sequence[i]*10**i for i in range(len(degree_sequence)))


### Unit tests below ###
def check(candidate):
	assert candidate(list(range(10))) == 9876543210
	assert candidate( [1,1,1,1,1,1,1,1,1,1,1,1,1,1] ) == 11111111111111
	assert candidate([0,0,0,0,0,0]) == 0
	assert candidate( [2,1,1] ) == 211
	assert candidate( [1,1] ) == 11
	assert candidate( [1,1,1,1,1,1,1,1,1,1,1] ) == 11111111111
	assert candidate( [4,4,4,4] ) == 4444
	assert candidate( [2,2,3,2,1] ) == 32221
	assert candidate([2,2,3,1]) == 3221
	assert candidate( [4,3,2,1] ) == 4321
	assert candidate( [1,1,1,1,1,1] ) == 111111
	assert candidate( [1,1,1] ) == 111
	assert candidate( [1,1,1,1] ) == 1111
	assert candidate( [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1] ) == 111111111111111
	assert candidate([2,2,3,1,0]) == 32210
	assert candidate( [1,2,2,3,1] ) == 32211
	assert candidate( [1] ) == 1
	assert candidate( [1,1,1,1,1,1,1,1,1,1,1,1,1] ) == 1111111111111
	assert candidate( [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1] ) == 1111111111111111
	assert candidate([10]) == 10
	assert candidate([1,1,1,1,1,1,1,1,1,1,1]) == 11111111111
	assert candidate( [3,3,3,3] ) == 3333
	assert candidate( [1,2,3,2,1] ) == 32211
	assert candidate( [3,2,2] ) == 322
	assert candidate( [3,3,3] ) == 333
	assert candidate([1,1,1,1,1,1,1,1,1,1]) == 1111111111
	assert candidate( [2,2,1] ) == 221
	assert candidate( [2,2,3,1] ) == 3221
	assert candidate( [2,2] ) == 22
	assert candidate( [2,2,2] ) == 222
	assert candidate([1,1,1]) == 111
	assert candidate( [2,1,1,1] ) == 2111
	assert candidate( [] ) == 0
	assert candidate( [1,1,1,1,1,1,1,1,1,1] ) == 1111111111
	assert candidate( [2,1] ) == 21
	assert candidate( [1,1,1,1,1,1,1,1,1,1,1,1] ) == 111111111111
	assert candidate([]) == 0
	assert candidate( [2] ) == 2
def test_check():
	check(degseq_to_data)
