def score_bhamidi(memberships, predicted_memberships):
    """
    Scores the predicted clustering labels vs true labels using Bhamidi's scoring method.

    Parameters
    ----------
    memberships: actual true labels
    predicted_memberships: clustering labels

    Output
    ------
    a percentage of correct vertice pairings
    """
    ### Canonical solution below ###
    score = 0
    vertex_count = len(memberships)
    for i in range(vertex_count):
        for j in range(vertex_count):
            actual_match = memberships[i]==memberships[j]
            predicted_match = predicted_memberships[i]==predicted_memberships[j] 
            if actual_match == predicted_match:
                score += 1
    # convert to percent of total vertex pairs
    score = score/(vertex_count*vertex_count)
    return score


### Unit tests below ###
def check(candidate):
	assert candidate(memberships=[0,0,0,0,0,0], predicted_memberships=[0,0,0,0,0,0]) == 1
	assert candidate(memberships=[0,0,0,0], predicted_memberships=[1,1,0,0]) == 0.5
	assert candidate(memberships=[0,0,1,1], predicted_memberships=[0,0,0,0]) == 0.5
	assert candidate(memberships=[0,0,0,0,0], predicted_memberships=[0,0,0,0,0]) == 1.0
	assert candidate(memberships=[0,0,0], predicted_memberships=[0,0,0]) == 1.0
	assert candidate(memberships=[0,0,1,1], predicted_memberships=[0,0,1,1]) == 1
	assert candidate(memberships=[0,0,0,0], predicted_memberships=[0,0,0,0]) == 1
	assert candidate(memberships=[0,0,0,0], predicted_memberships=[0,0,1,1]) == 0.5
	assert candidate(memberships=[0,1,0,1], predicted_memberships=[0,0,1,1]) == 0.5
	assert candidate(memberships=[0,0,0,0,0,0], predicted_memberships=[0,0,0,1,1,1]) == 0.5
def test_check():
	check(score_bhamidi)
