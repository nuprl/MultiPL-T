def wears_jacket_with_if(temp, raining):
  """
  
  >>> wears_jacket_with_if(90, False)
  False
  >>> wears_jacket_with_if(40, False)
  True
  >>> wears_jacket_with_if(100, True)
  True
  """
    ### Canonical solution below ###
  if temp < 60 or raining == True:
    return True
  else:
    return False


### Unit tests below ###
def check(candidate):
	assert candidate(100, True) == True
	assert candidate(100, False) == False
	assert candidate(40, False) == True
	assert candidate(90, False) == False
def test_check():
	check(wears_jacket_with_if)
