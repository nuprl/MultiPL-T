def embedded_certs(certificate):
    """Sets ups certs from filesystem"""
    ### Canonical solution below ###

    def _setup(tls_policy_view):
        tls_policy_view.add_embedded_certs(certificate)

    return _setup


### Unit tests below ###
def check(candidate):
	assert candidate("a") is not None
	assert candidate(b'abc') is not None
	assert candidate("a,b,c,d,e,f,g,h") is not None
	assert candidate('test') is not None
	assert candidate("a.pem,b.pem,c.pem") is not None
	assert candidate("a.pem, b.pem, c.pem") is not None
	assert candidate("a.pem, b.pem, c.pem, d.pem") is not None
	assert candidate("a.pem,b.pem") is not None
	assert candidate("a,b,c,d,e,f,g,h,i") is not None
	assert candidate(None) is not None
	assert candidate("   ") is not None
	assert candidate("a,b,c") is not None
	assert candidate("a,b,c,d,e,f,") is not None
	assert candidate("a,b,c,d,e,f,g,h,") is not None
	assert candidate("a,b,c,d,e") is not None
	assert candidate("a,b,c,d,e,f,g") is not None
	assert candidate("a,b,c,d,") is not None
	assert candidate("valid")!= None
	assert candidate('cert') is not None
	assert candidate("a.pem") is not None
	assert candidate("a.pem,b.pem,c.pem,d.pem") is not None
	assert candidate("a,b,c,") is not None
	assert candidate("a.pem, b.pem") is not None
	assert candidate("foo") is not None
	assert candidate(certificate="certificate") is not None
	assert candidate("a.pem, b.pem, c.pem, d.pem, e.pem") is not None
	assert candidate("certificate") is not None
	assert candidate("a,b,c,d,e,f") is not None
	assert candidate(certificate=None) is not None
	assert candidate("a.pem,b.pem,c.pem,d.pem,e.pem") is not None
	assert candidate("a,b,c,d,e,") is not None
	assert candidate("a,b,c,d,e,f,g,") is not None
	assert candidate("") is not None
	assert candidate('') is not None
	assert candidate("a,b,c,d") is not None
	assert candidate(" ") is not None
def test_check():
	check(embedded_certs)
