def _overline(symbol_list):
    """ applies the overline function """
	### Canonical solution below ###    
    if not isinstance(symbol_list, list):
        symbol_list = [symbol_list]
    return r"\overline{{{0}}}".format(" ".join(symbol_list))

### Unit tests below ###
def check(candidate):
	assert candidate(r"\alpha_1 \beta_2") == r"\overline{\alpha_1 \beta_2}"
	assert candidate(r"x^2_1") == r"\overline{x^2_1}"
	assert candidate(r"\alpha x_1^2") == r"\overline{\alpha x_1^2}"
	assert candidate(r"x") == r"\overline{x}"
	assert candidate([r"\alpha", r"\beta"]) == r"\overline{\alpha \beta}"
	assert candidate("a b") == r"\overline{a b}"
	assert candidate([r"a b c", r"d e f"]) == r"\overline{a b c d e f}"
	assert candidate(r"x y z") == r"\overline{x y z}"
	assert candidate([r"x^2_1", r"y^3_2"]) == r"\overline{x^2_1 y^3_2}"
	assert candidate(r"x_1 x_2") == r"\overline{x_1 x_2}"
	assert candidate(r"x_1 x_2 x_3") == r"\overline{x_1 x_2 x_3}"
	assert candidate(r"x y") == r"\overline{x y}"
	assert candidate([r"x^2", r"y^2"]) == r"\overline{x^2 y^2}"
	assert candidate(r"{\alpha}") == r"\overline{{\alpha}}"
	assert candidate(r"a") == r"\overline{a}"
	assert candidate(r"\alpha") == r"\overline{\alpha}"
	assert candidate(r"\alpha \beta x_1") == r"\overline{\alpha \beta x_1}"
	assert candidate(["a", "b"]) == r"\overline{a b}"
	assert candidate([r"x^2", r"y^3"]) == r"\overline{x^2 y^3}"
	assert candidate([r"x_1^2_3", r"y_2^3_4"]) == r"\overline{x_1^2_3 y_2^3_4}"
	assert candidate([r"x_1", r"x_2", r"x_3"]) == r"\overline{x_1 x_2 x_3}"
	assert candidate(r"x_1^2 x_2") == r"\overline{x_1^2 x_2}"
	assert candidate(r"\alpha_1") == r"\overline{\alpha_1}"
	assert candidate(r"\sigma") == r"\overline{\sigma}"
	assert candidate(r"\alpha x_1") == r"\overline{\alpha x_1}"
	assert candidate(r"\alpha \beta x_1^2") == r"\overline{\alpha \beta x_1^2}"
	assert candidate(r"\alpha \beta") == r"\overline{\alpha \beta}"
	assert candidate(r"x^2") == r"\overline{x^2}"
	assert candidate([r"x_1", r"x_2"]) == r"\overline{x_1 x_2}"
	assert candidate([r"x", r"y"]) == r"\overline{x y}"
	assert candidate([r"\sigma", r"\tau"]) == r"\overline{\sigma \tau}"
	assert candidate([r"a", r"b"]) == r"\overline{a b}"
	assert candidate([r"x_1", r"x_2", r"x_3", r"x_4"]) == r"\overline{x_1 x_2 x_3 x_4}"
	assert candidate(r"x_1") == r"\overline{x_1}"
	assert candidate(r"x_1^2") == r"\overline{x_1^2}"
	assert candidate([r"{\alpha}", r"{\beta}"]) == r"\overline{{\alpha} {\beta}}"
	assert candidate([r"x_1^2", r"y_2^3"]) == r"\overline{x_1^2 y_2^3}"
	assert candidate(r"a b") == r"\overline{a b}"
	assert candidate(r"x_1^2_3") == r"\overline{x_1^2_3}"
	assert candidate(r"a b c") == r"\overline{a b c}"
def test_check():
	check(_overline)
