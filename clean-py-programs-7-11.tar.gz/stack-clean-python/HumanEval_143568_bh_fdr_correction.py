def bh_fdr_correction(pvals):
    """ 
     Benjamin-Hochberg FDR correction.
     Reference: http://en.wikipedia.org/wiki/False_discovery_rate
     """
	### Canonical solution below ###    
    n = len(pvals)
    k = 1
    cr = [1.0] * n
    mx = 0.0
    for pos, pval in sorted(enumerate(pvals), key = lambda x : x[1]):
        mx = max(pval * n / k, mx)
        if mx < 1.0:
            cr[pos] = mx
        k += 1
    return cr

### Unit tests below ###
def check(candidate):
	assert candidate(pvals = [0.01, 0.02, 0.03, 0.04]) == [0.04, 0.04, 0.04, 0.04]
	assert candidate( [3.0, 1.0, 2.0] ) == [1.0, 1.0, 1.0]
	assert candidate( [1.0, 3.0, 2.0] ) == [1.0, 1.0, 1.0]
	assert candidate( [1.0, 1.0, 1.0] ) == [1.0, 1.0, 1.0]
	assert candidate(pvals = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07]) == [0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07]
	assert candidate(pvals = [0.01, 0.02, 0.03, 0.04, 0.05]) == [0.05, 0.05, 0.05, 0.05, 0.05]
	assert candidate( [1.0, 1.0, 2.0] ) == [1.0, 1.0, 1.0]
	assert candidate( [2.0, 1.0, 3.0] ) == [1.0, 1.0, 1.0]
	assert candidate(range(10, 0, -1)) == [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
	assert candidate([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]) == [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
	assert candidate(range(1, 10)) == [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
	assert candidate( [3.0, 2.0, 1.0] ) == [1.0, 1.0, 1.0]
	assert candidate([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0]) == [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0]
	assert candidate( [1.0, 2.0, 3.0] ) == [1.0, 1.0, 1.0]
	assert candidate( [2.0, 3.0, 1.0] ) == [1.0, 1.0, 1.0]
	assert candidate( [2.0, 2.0, 3.0] ) == [1.0, 1.0, 1.0]
def test_check():
	check(bh_fdr_correction)
