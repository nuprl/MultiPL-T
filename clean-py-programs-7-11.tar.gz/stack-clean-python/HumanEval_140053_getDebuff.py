def getDebuff(state, debuffType) :
    """ Get the lists of debuff modifiers for a specific debuff type
     """
	### Canonical solution below ###    
    return [ b['props'][debuffType] for b in state['enemy']['debuff'] if debuffType in b['props'] ]

### Unit tests below ###
def check(candidate):
	assert candidate({'enemy':{'debuff':[{'props':{'stun':100,'damage':200}}]}}, "damage") == [200]
	assert candidate(
    {'enemy': {'debuff': [
        {'props': {'test1': 1, 'test2': 2}},
        {'props': {'test3': 3}},
        {'props': {'test1': 4}}
    ]}},
    'test3'
) == [3]
	assert candidate(
    {'enemy': {'debuff': [
        {'props': {'test1': 1, 'test2': 2}},
        {'props': {'test3': 3}},
        {'props': {'test1': 4}}
    ]}},
    'test4'
) == []
	assert candidate(
    {'enemy': {'debuff': [
        {'props': {'test1': 1, 'test2': 2}},
        {'props': {'test3': 3}},
        {'props': {'test1': 4}}
    ]}},
    'test2'
) == [2]
	assert candidate({'enemy':{'debuff':[{'props':{'stun':100}}]}}, "stun") == [100]
	assert candidate(
    {'enemy': {'debuff': [
        {'props': {'test1': 1, 'test2': 2}},
        {'props': {'test3': 3}},
        {'props': {'test1': 4}}
    ]}},
    'test1'
) == [1, 4]
	assert candidate({'enemy':{'debuff':[{'props':{'stun':100,'damage':200}}]}}, "stun") == [100]
def test_check():
	check(getDebuff)
