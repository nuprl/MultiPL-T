def compute_f(match_num, test_num, gold_num):
    """
    Compute the f-score based on the matching triple number,
                                 triple number of AMR set 1,
                                 triple number of AMR set 2
    Args:
        match_num: matching triple number
        test_num:  triple number of AMR 1 (test file)
        gold_num:  triple number of AMR 2 (gold file)
    Returns:
        precision: match_num/test_num
        recall: match_num/gold_num
        f_score: 2*precision*recall/(precision+recall)
    """
    ### Canonical solution below ###
    if test_num == 0 or gold_num == 0:
        return 0.00, 0.00, 0.00
    precision = float(match_num) / float(test_num)
    recall = float(match_num) / float(gold_num)
    if (precision + recall) != 0:
        f_score = 2 * precision * recall / (precision + recall)
        return precision, recall, f_score
    else:
        return precision, recall, 0.00


### Unit tests below ###
def check(candidate):
	assert candidate(1, 0, 1) == (0.0, 0.0, 0.0)
	assert candidate(0, 10, 15) == (0.0, 0.0, 0.0)
	assert candidate(10, 10, 10) == (1.00, 1.00, 1.00)
	assert candidate(0, 100, 100) == (0.0, 0.0, 0.0)
	assert candidate(0, 10, 10) == (0.0, 0.0, 0.0)
	assert candidate(0, 10, 0) == (0.0, 0.0, 0.0)
	assert candidate(10, 20, 30) == (0.5, 0.3333333333333333, 0.4)
	assert candidate(0, 0, 15) == (0.0, 0.0, 0.0)
	assert candidate(2, 2, 2) == (1.00, 1.00, 1.00)
	assert candidate(2, 4, 4) == (0.5, 0.5, 0.5)
	assert candidate(0, 0, 0) == (0.0, 0.0, 0.0)
	assert candidate(1, 1, 0) == (0.0, 0.0, 0.0)
	assert candidate(0, 0, 1) == (0.00, 0.00, 0.00)
	assert candidate(1, 2, 2) == (0.5, 0.5, 0.5)
	assert candidate(4, 0, 0) == (0.0, 0.0, 0.0)
	assert candidate(2, 0, 0) == (0.0, 0.0, 0.0)
	assert candidate(0, 10, 100) == (0.0, 0.0, 0.0)
	assert candidate(0, 100, 10) == (0.0, 0.0, 0.0)
	assert candidate(0, 10, 10) == (0.00, 0.00, 0.00)
	assert candidate(3, 4, 4) == (0.75, 0.75, 0.75)
	assert candidate(2, 2, 2) == (1.0, 1.0, 1.0)
	assert candidate(2, 3, 3) == (0.6666666666666666, 0.6666666666666666, 0.6666666666666666)
	assert candidate(100, 100, 100) == (1.00, 1.00, 1.00)
	assert candidate(2, 2, 0) == (0.0, 0.0, 0.0)
	assert candidate(10, 0, 10) == (0.0, 0.0, 0.0)
	assert candidate(0, 1, 1) == (0.00, 0.00, 0.00)
	assert candidate(10, 10, 10) == (1.0, 1.0, 1.0)
	assert candidate(10, 10, 0) == (0.00, 0.00, 0.00)
	assert candidate(5, 10, 10) == (0.50, 0.50, 0.50)
	assert candidate(1, 2, 2) == (0.50, 0.50, 0.50)
	assert candidate(1, 1, 1) == (1.00, 1.00, 1.00)
	assert candidate(0, 1, 0) == (0.0, 0.0, 0.0)
	assert candidate(1, 0, 0) == (0.0, 0.0, 0.0)
	assert candidate(1, 1, 1) == (1.0, 1.0, 1.0)
	assert candidate(2, 0, 2) == (0.0, 0.0, 0.0)
	assert candidate(0, 0, 10) == (0.0, 0.0, 0.0)
	assert candidate(0, 0, 0) == (0.00, 0.00, 0.00)
	assert candidate(2, 1, 0) == (0.0, 0.0, 0.0)
	assert candidate(10, 0, 10) == (0.00, 0.00, 0.00)
	assert candidate(3, 3, 3) == (1.00, 1.00, 1.00)
	assert candidate(0, 1, 0) == (0.00, 0.00, 0.00)
	assert candidate(1, 0, 0) == (0.00, 0.00, 0.00)
	assert candidate(100, 100, 100) == (1.0, 1.0, 1.0)
	assert candidate(4, 4, 4) == (1.0, 1.0, 1.0)
	assert candidate(1, 0, 1) == (0.00, 0.00, 0.00)
	assert candidate(1, 2, 1) == (0.5, 1.0, 0.6666666666666666)
	assert candidate(10, 20, 10) == (0.5, 1.0, 0.6666666666666666)
	assert candidate(0, 100, 100) == (0.00, 0.00, 0.00)
	assert candidate(0, 1, 1) == (0.0, 0.0, 0.0)
	assert candidate(100, 0, 100) == (0.00, 0.00, 0.00)
	assert candidate(10, 0, 0) == (0.0, 0.0, 0.0)
	assert candidate(3, 3, 3) == (1.0, 1.0, 1.0)
def test_check():
	check(compute_f)
