def in_seconds(days=0, hours=0, minutes=0, seconds=0):
    """ 
     Tiny helper that is similar to the timedelta API that turns the keyword arguments into
     seconds. Most useful for calculating the number of seconds relative to an epoch.
     
     >>> in_seconds()
     0
     >>> in_seconds(hours=1.5)
     5400
     >>> in_seconds(hours=3)
     10800
     >>> in_seconds(minutes=30)
     1800
     >>> in_seconds(hours=3, minutes=30, seconds=10)
     12610
     >>> in_seconds(days=1)
     86400
     >>> in_seconds(days=3, hours=10)
     295200
     """
	### Canonical solution below ###    
    return int((days * 86400) + (hours * 3600) + (minutes * 60) + seconds)

### Unit tests below ###
def check(candidate):
	assert candidate(hours=3) == 10800
	assert candidate(days=1, hours=1) == 90000
	assert candidate() == 0
	assert candidate(days=1, hours=1, minutes=1) == 90060
	assert candidate(days=3, hours=10) == 295200
	assert candidate(minutes=1) == 60
	assert candidate(minutes=30) == 1800
	assert candidate(0, 0, 0, 0) == 0
	assert candidate(0) == 0
	assert candidate(days=1) == 86400
	assert candidate(days=1, hours=2) == 93600
	assert candidate(days=1, hours=1, minutes=1, seconds=1) == 90061
	assert candidate(hours=1.5) == 5400
	assert candidate(hours=1) == 3600
	assert candidate(hours=1, minutes=30) == 5400
	assert candidate(hours=1, minutes=1, seconds=1) == 3661
	assert candidate(seconds=1) == 1
	assert candidate(hours=3, minutes=30, seconds=10) == 12610
def test_check():
	check(in_seconds)
