def min_none(a,b):
  """
  Min(a,b), returns the other element if either of `a` or `b` is None

  Args:
      a: int or float value
      b: int or float value
  Returns:
      minimum of a or b
  """
    ### Canonical solution below ###
  if not a:
    return b
  if not b:
    return a
  return min(a,b)


### Unit tests below ###
def check(candidate):
	assert candidate(1.5,1) == 1
	assert candidate(3,None) == 3
	assert candidate(1, 2.0) == 1.0
	assert candidate(1.5,2.5) == 1.5
	assert candidate(10, None) == 10
	assert candidate(2,None) == 2
	assert candidate(None, 0) == 0
	assert candidate(0,0) == 0
	assert candidate(None, 10) == 10
	assert candidate(1,1.5) == 1
	assert candidate(10.2, 10.2) == 10.2
	assert candidate(3, None) == 3
	assert candidate(10.2, 10.1) == 10.1
	assert candidate(10.1, 10.2) == 10.1
	assert candidate(100, 200) == 100
	assert candidate(1, 1) == 1
	assert candidate(1,1) == 1
	assert candidate(None, 1) == 1
	assert candidate(200, 100) == 100
	assert candidate(1.0, 2.0) == 1.0
	assert candidate(None, 5) == 5
	assert candidate(2,1) == 1
	assert candidate(10, 10) == 10
	assert candidate(2.0, 1.0) == 1.0
	assert candidate(1.5,None) == 1.5
	assert candidate(1.5,1.5) == 1.5
	assert candidate(2.5,1.5) == 1.5
	assert candidate(2, 1) == 1
	assert candidate(None, 4) == 4
	assert candidate(1, 2) == 1
	assert candidate(None,2) == 2
	assert candidate(None, None) == None
	assert candidate(None, 2) == 2
	assert candidate(0, 0) == 0
	assert candidate(2, 2) == 2
	assert candidate(1, None) == 1
	assert candidate(10, 20) == 10
	assert candidate(None, 100) == 100
	assert candidate(100, None) == 100
	assert candidate(2, None) == 2
	assert candidate(None,1.5) == 1.5
	assert candidate(None,3) == 3
	assert candidate(2,3) == 2
	assert candidate(10.1, 10.1) == 10.1
	assert candidate(None, 3) == 3
	assert candidate(None,None) is None
	assert candidate(20, 10) == 10
	assert candidate(1,2) == 1
	assert candidate(None,1) == 1
	assert candidate(None,None) == None
	assert candidate(1,None) == 1
	assert candidate(None, None) is None
	assert candidate(2, 3) == 2
def test_check():
	check(min_none)
