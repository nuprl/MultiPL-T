def memory():
    """ 
     Get node total memory and memory usage
     """
	### Canonical solution below ###	
	with open('/proc/meminfo', 'r') as mem:
		ret = {}
		tmp = 0
		for i in mem:
			sline = i.split()
			if str(sline[0]) == 'MemTotal:':
				ret['total'] = int(sline[1])
			elif str(sline[0]) in ('MemFree:', 'Buffers:', 'Cached:'):
				tmp += int(sline[1])
		ret['free'] = tmp
		ret['used'] = int(ret['total']) - int(ret['free'])
		return ret

### Unit tests below ###
def check(candidate):
	assert candidate()['free'] > 0, "Free candidate should be more than 0"
	assert candidate()['total'] > 0, "Total candidate should be more than 0"
	assert candidate()['used'] > 0, "Used candidate should be more than 0"
def test_check():
	check(memory)
