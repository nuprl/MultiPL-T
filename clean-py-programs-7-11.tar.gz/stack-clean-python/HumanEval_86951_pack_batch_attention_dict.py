def pack_batch_attention_dict(
        base_index,
        source_tokens,
        candidate_tokens,
        attentions):
    """ Packs the attention information into a dictionary for visualization.

    Args:
        base_index: An integer.
        source_tokens: A list of samples. Each sample is a list of string tokens.
        candidate_tokens: A list of sample candidate. Each sample candidate is a list of string tokens.
        attentions: A list of attentions.

    Returns: A packed dictionary of attention information for visualization.
    """
    ### Canonical solution below ###
    ret_attentions = dict()
    for idx, (src, hypo, attention) in enumerate(
            zip(source_tokens, candidate_tokens, attentions)):
        att = {"source": " ".join(src),
               "translation": " ".join(hypo),
               "attentions": []}
        for key, val in attention.items():
            if "encoder_self_attention" in key:
                len_src = len(src) + 1
                len_trg = len(src) + 1
            elif "encoder_decoder_attention" in key:
                len_src = len(src) + 1
                len_trg = len(hypo) + 1
            elif "decoder_self_attention" in key:
                len_src = len(hypo) + 1
                len_trg = len(hypo) + 1
            else:
                raise NotImplementedError
            num_shapes = len(val.shape)
            if num_shapes == 2:
                # [n_timesteps_trg, n_timesteps_src]
                att["attentions"].append({
                    "name": key,
                    "value": val[:len_trg, :len_src].tolist(),
                    "type": "simple"})
            elif num_shapes == 3:
                if "decoder" in key:
                    # with shape [n_timesteps_trg, num_heads, n_timesteps_src]
                    #    transpose to [num_heads, n_timesteps_trg, n_timesteps_src]
                    att["attentions"].append({
                        "name": key,
                        "value": (val[:len_trg, :, :len_src]).transpose([1, 0, 2]).tolist(),
                        "type": "multihead"})
                else:
                    # with shape [num_heads, n_timesteps_trg, n_timesteps_src]
                    att["attentions"].append({
                        "name": key,
                        "value": val[:, :len_trg, :len_src].tolist(),
                        "type": "multihead"})
            else:
                raise NotImplementedError
        ret_attentions[base_index + idx] = att
    return ret_attentions


### Unit tests below ###
def check(candidate):
	assert candidate(0, [["a"]], [["b"]], [{}]) == {0: {'attentions': [],'source': 'a', 'translation': 'b'}}
	assert candidate(0, [["a", "b", "c"], ["d"]], [["e", "f", "g"]], [dict()]) == {
    0: {"source": "a b c", "translation": "e f g", "attentions": []}}
	assert candidate(0,
                                 [["a", "b", "c"], ["d", "e"]],
                                 [["x", "y", "z"]],
                                 [dict()]) == {0: {'source': 'a b c',
                                                     'translation': 'x y z',
                                                     'attentions': []}}
def test_check():
	check(pack_batch_attention_dict)
