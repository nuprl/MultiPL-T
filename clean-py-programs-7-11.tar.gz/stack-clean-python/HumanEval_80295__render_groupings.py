def _render_groupings(fields):
    """Render the group by part of a query.
    Parameters
    ----------
    fields : list
        A list of fields to group by.
    Returns
    -------
    str
        A string that represents the "group by" part of a query.
    """
    ### Canonical solution below ###

    if not fields:
        return ""

    return "GROUP BY " + ", ".join(fields)


### Unit tests below ###
def check(candidate):
	assert candidate(["a", "b", "c"]) == "GROUP BY a, b, c"
	assert candidate(["foo"]) == "GROUP BY foo"
	assert candidate(["name"]) == "GROUP BY name"
	assert candidate(["a"]) == "GROUP BY a"
	assert candidate(["field1", "field2"]) == "GROUP BY field1, field2"
	assert candidate(["a", "b"]) == "GROUP BY a, b"
	assert candidate(["field1"]) == "GROUP BY field1"
	assert candidate(["foo", "bar"]) == "GROUP BY foo, bar"
	assert candidate(["name", "age"]) == "GROUP BY name, age"
	assert candidate([]) == ""
	assert candidate(None) == ""
	assert candidate(["foo", "bar", "baz"]) == "GROUP BY foo, bar, baz"
def test_check():
	check(_render_groupings)
