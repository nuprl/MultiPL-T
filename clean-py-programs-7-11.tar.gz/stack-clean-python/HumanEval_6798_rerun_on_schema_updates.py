def rerun_on_schema_updates(func):
    """ Tasks decorated with this will rerun upon database version updates."""
	### Canonical solution below ###    
    func._rerun_on_schema_updates = True
    return func

### Unit tests below ###
def check(candidate):
	assert not candidate(lambda: None).__name__ == 'foo'
	assert candidate(lambda: True)
	assert hasattr(candidate(lambda: 1), '_candidate')
	assert candidate(lambda: None)._candidate is True
	assert candidate(lambda: None)._candidate
	assert candidate(lambda x, y=None, z=None: None)._candidate is True
	assert not candidate(lambda: None).__name__ == 'lambda'
	assert candidate(lambda x=None, y=None: None)._candidate is True
	assert candidate(lambda x, y=None, z=None, *args, **kwargs: None)._candidate is True
	assert candidate(lambda x: None)._candidate is True
	assert hasattr(candidate(lambda: None), '_candidate')
	assert candidate(lambda: None)._candidate == True
	assert candidate(lambda: None) is not None
	assert not hasattr(candidate(lambda: None), '_no_autoflush')
	assert candidate(candidate(lambda: None))._candidate is True
	assert candidate(lambda: None)
	assert candidate(lambda x, y=None: None)._candidate is True
	assert hasattr(candidate(lambda: True), '_candidate')
	assert candidate(lambda: 1)() == 1
	assert candidate(lambda x=None: None)._candidate is True
	assert candidate(lambda: True)._candidate is True
	assert candidate(lambda x, y: None)._candidate is True
	assert candidate(lambda: True)._candidate == True
def test_check():
	check(rerun_on_schema_updates)
