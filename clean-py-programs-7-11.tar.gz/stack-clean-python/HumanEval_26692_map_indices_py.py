def map_indices_py(arr):
    """ 
     Returns a dictionary with (element, index) pairs for each element in the
     given array/list
     """
	### Canonical solution below ###    
    return dict([(x, i) for i, x in enumerate(arr)])

### Unit tests below ###
def check(candidate):
	assert candidate(range(4)) == {0: 0, 1: 1, 2: 2, 3: 3}
	assert candidate(range(10)) == dict([(x, i) for i, x in enumerate(range(10))])
	assert candidate([]) == {}
	assert candidate(list('abcd')) == {'a': 0, 'b': 1, 'c': 2, 'd': 3}
	assert candidate(list("abcde")) == {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4}
	assert candidate([1, 3, 5, 7, 9]) == {1: 0, 3: 1, 5: 2, 7: 3, 9: 4}
	assert candidate([1, 2, 3, 4]) == {1: 0, 2: 1, 3: 2, 4: 3}
	assert candidate(list(range(10))) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate(list('abcde')) == {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4}
	assert candidate(list("abc")) == {"a": 0, "b": 1, "c": 2}
	assert candidate(list('abc')) == {'a': 0, 'b': 1, 'c': 2}
	assert candidate("abcde") == {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4}
	assert candidate("abcd") == {'a': 0, 'b': 1, 'c': 2, 'd': 3}
	assert candidate(list(range(5))[::-1]) == {4: 0, 3: 1, 2: 2, 1: 3, 0: 4}
	assert candidate([1, 2, 3, 4, 5]) == {1: 0, 2: 1, 3: 2, 4: 3, 5: 4}
	assert candidate(range(3)) == {0: 0, 1: 1, 2: 2}
	assert candidate([2]) == {2: 0}
	assert candidate([1, 3, 2, 4, 5]) == {1: 0, 3: 1, 2: 2, 4: 3, 5: 4}
	assert candidate([1]) == {1: 0}
	assert candidate([0, 1, 2, 3, 4]) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4}
	assert candidate(list('cba')) == {'a': 2, 'b': 1, 'c': 0}
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 7, 9: 8, 10: 9}
	assert candidate(range(5)) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4}
	assert candidate([2, 3, 4]) == {2: 0, 3: 1, 4: 2}
	assert candidate([1, 2, 3]) == {1: 0, 2: 1, 3: 2}
	assert candidate(range(10)) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate([1, 3, 2, 5, 4]) == {1: 0, 3: 1, 2: 2, 5: 3, 4: 4}
	assert candidate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate(list(range(5))) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4}
	assert candidate(range(10)) == dict(enumerate(range(10)))
def test_check():
	check(map_indices_py)
