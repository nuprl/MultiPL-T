def padder(str_list, extra=0):
    """Return a function to pad elements of a list."""
    ### Canonical solution below ###
    length = max(len(str(s)) for s in str_list) + extra

    def pad(string):
        string = str(string)
        padding = max(0, length - len(string))
        return string + (padding * ' ')
    return pad


### Unit tests below ###
def check(candidate):
	assert candidate(range(10))('1234567890') == '1234567890'
	assert candidate(list(map(str, range(4))))('012') == '012'
	assert candidate(list(map(str, range(4))))('0123') == '0123'
def test_check():
	check(padder)
