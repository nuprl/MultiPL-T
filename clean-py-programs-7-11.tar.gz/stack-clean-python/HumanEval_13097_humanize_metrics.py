def humanize_metrics(metrics):
    """
    Prepare interesting metrics for display
    :param metrics:
    :return:
    """
    ### Canonical solution below ###
    metric_defs = {
        'failed': {
            'title': 'Jobs failure',
            'unit': '%',
            'class': [],
        },
        'maxpss_per_actualcorecount': {
            'title': 'Median maxPSS/core',
            'unit': 'GB',
            'class': [],
        },
        'walltime': {
            'title': 'Median jobs walltime',
            'unit': 'hours',
            'class': [],
        },
        'queuetime': {
            'title': 'Median jobs time to start',
            'unit': 'hours',
            'class': [],
        },
        'efficiency': {
            'title': ' Median jobs efficiency',
            'unit': '%',
            'class': [],
        },
        'attemptnr': {
            'title': ' Average number of job attempts',
            'unit': '',
            'class': [],
        },
        'cpua7': {
            'title': 'Personal CPU hours for last 7 days',
            'unit': '',
            'class': ['neutral', ],
        },
        'cpup7': {
            'title': 'Group CPU hours for last 7 days',
            'unit': '',
            'class': ['neutral', ],
        },
    }

    metrics_thresholds = {
        'pss': {
            'warning': [2, 2.5],
            'alert': [2.5, 1000000]
        },
        'time': {
            'warning': [36, 48],
            'alert': [48, 1000000]
        },
        'walltime': {
            'warning': [1, 2],
            'alert': [0, 1]
        },
        'queuetime': {
            'warning': [4, 12],
            'alert': [12, 1000000]
        },
        'fail': {
            'warning': [20, 40],
            'alert': [40, 100]
        },
        'efficiency': {
            'warning': [50, 70],
            'alert': [0, 50]
        },
        'attemptnr': {
            'warning': [2, 4],
            'alert': [4, 100]
        }
    }

    metrics_list = []
    for md in metric_defs:
        if md in metrics and metrics[md]:
            if 'pss' in md:
                metric_defs[md]['value'] = round(metrics[md], 2)
            elif 'efficiency' in md:
                metric_defs[md]['value'] = round(metrics[md] * 100., 2)
            else:
                metric_defs[md]['value'] = metrics[md]

            for key, thresholds in metrics_thresholds.items():
                if key in md:
                    metric_defs[md]['class'].extend([c for c, crange in thresholds.items() if metric_defs[md]['value'] >= crange[0] and metric_defs[md]['value'] < crange[1]])

            metric_defs[md]['class'] = metric_defs[md]['class'][0] if len(metric_defs[md]['class']) > 0 else 'ok'
            metrics_list.append(metric_defs[md])

    return metrics_list


### Unit tests below ###
def check(candidate):
	assert candidate({'maxpss_per_actualcorecount': 1}) == [{'class': 'ok', 'unit': 'GB', 'title': 'Median maxPSS/core', 'value': 1}]
	assert candidate(dict()) == []
	assert candidate({'maxpss_per_actualcorecount': 5}) == [{'class': 'alert', 'unit': 'GB', 'title': 'Median maxPSS/core', 'value': 5}]
	assert candidate(dict(walltime=100)) == [{'title': 'Median jobs walltime', 'unit': 'hours', 'class': 'alert', 'value': 100}]
	assert candidate(dict(maxpss_per_actualcorecount=100)) == [{'title': 'Median maxPSS/core', 'unit': 'GB', 'class': 'alert', 'value': 100.0}]
	assert candidate({'maxpss_per_actualcorecount': 1000}) == [{'class': 'alert', 'unit': 'GB', 'title': 'Median maxPSS/core', 'value': 1000}]
def test_check():
	check(humanize_metrics)
