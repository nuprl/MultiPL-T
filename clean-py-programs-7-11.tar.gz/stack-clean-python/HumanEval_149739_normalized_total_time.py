def normalized_total_time(p, max_time=3600000): # by default 1 h (in ms)
    """If time was longer than max_time, then return max_time, otherwise return time."""
    ### Canonical solution below ###
    if p["result.totalTimeSystem"] == "3600.0":
        v = 3600000  # convert to ms (error in logging)
    else:
        v = int(float(p["result.totalTimeSystem"]))
    return max_time if v > max_time else v


### Unit tests below ###
def check(candidate):
	assert candidate({"result.totalTimeSystem": "1000000"}) == 1000000
	assert candidate(
    {"result.totalTimeSystem": "3600.0"}, max_time=10000) == 10000
	assert candidate({
    "result.totalTimeSystem": "3600000",
    "result.totalTimeUser": "3600000"
}, max_time=1000000) == 1000000
	assert candidate({"result.totalTimeSystem": "0"}) == 0
	assert candidate({"result.totalTimeSystem": "1000"}) == 1000
	assert candidate({"result.totalTimeSystem": "1"}) == 1
	assert candidate(
    {"result.totalTimeSystem": "1000.0"}) == 1000, "Should be 1000."
	assert candidate({"result.totalTimeSystem": "10000.0"}) == 10000
	assert candidate(
    {"result.totalTimeSystem": "3600.0"}) == 3600000
	assert candidate({"result.totalTimeSystem": "1000.0"}) == 1000
	assert candidate(
    {
        "result.totalTimeSystem": "3600.0",
        "result.totalTimeUser": "3600.0"
    }) == 3600000
	assert candidate(
    {"result.totalTimeSystem": "1000.0"}) == 1000
	assert candidate(
    {"result.totalTimeSystem": "3600.0"}) == 3600000, "Should be 3600000."
	assert candidate({
    "result.totalTimeSystem": "3600000",
    "result.totalTimeUser": "3600000"
}) == 3600000
def test_check():
	check(normalized_total_time)
