def support(transactions, itemsets):
    """ Returns the percentages of transactions that contain the itemsets.
     
     Parameters
     ----------
     transactions : list of list
     itemsets : list of frozenset
     
     Returns
     -------
     dict
     Key of each item is the itemset and the value is the itemset's support
     """
	### Canonical solution below ###    
    counts = {}
    for itemset in itemsets:
        counts[itemset] = 0
    for transaction in transactions:
        for itemset in itemsets:
            if itemset.issubset(transaction):
                counts[itemset] += 1
    supports = {}
    total_transactions = len(transactions)
    for itemset, count in counts.items():
        supports[itemset] = count / total_transactions
    return supports

### Unit tests below ###
def check(candidate):
	assert candidate(
    transactions=[[1, 3, 4], [2, 3, 5], [1, 2, 3, 5], [2, 5]],
    itemsets=[frozenset([1, 3]), frozenset([2, 5])]) == {
        frozenset([1, 3]): 0.5,
        frozenset([2, 5]): 0.75}
	assert candidate(
    [
        [1, 3, 4],
        [2, 3, 5],
        [1, 2, 3, 5],
        [2, 5]
    ],
    [frozenset([1, 3]), frozenset([2, 5])]) == {
        frozenset([1, 3]): 2/4,
        frozenset([2, 5]): 3/4
    }
	assert candidate(
    [[1, 3, 4], [2, 3, 5], [1, 2, 3, 5], [2, 5]],
    [frozenset([1, 3]), frozenset([2, 3]), frozenset([1, 2, 3, 5])]) == {
        frozenset([1, 3]): 0.5, frozenset([2, 3]): 0.5,
        frozenset([1, 2, 3, 5]): 0.25}
	assert candidate(
    [
        [1, 3, 4],
        [2, 3, 5],
        [1, 2, 3, 5],
        [2, 5]
    ],
    [frozenset([1, 3]), frozenset([2, 5]), frozenset([1, 2, 3, 5])]
) == {
    frozenset([1, 3]): 2/4,
    frozenset([2, 5]): 3/4,
    frozenset([1, 2, 3, 5]): 1/4
}
def test_check():
	check(support)
