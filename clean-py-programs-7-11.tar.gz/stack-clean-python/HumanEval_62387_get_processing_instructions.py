def get_processing_instructions(body):
    """ Extract the processing instructions / acl / etc. at the beginning of a page's body.
     
     Hint: if you have a Page object p, you already have the result of this function in
     p.meta and (even better) parsed/processed stuff in p.pi.
     
     Returns a list of (pi, restofline) tuples and a string with the rest of the body.
     """
	### Canonical solution below ###    
    pi = []
    while body.startswith('#'):
        try:
            line, body = body.split('\n', 1) # extract first line
        except ValueError:
            line = body
            body = ''

        # end parsing on empty (invalid) PI
        if line == "#":
            body = line + '\n' + body
            break

        if line[1] == '#':# two hash marks are a comment
            comment = line[2:]
            if not comment.startswith(' '):
                # we don't require a blank after the ##, so we put one there
                comment = ' ' + comment
                line = '##%s' % comment

        verb, args = (line[1:] + ' ').split(' ', 1) # split at the first blank
        pi.append((verb.lower(), args.strip()))

    return pi, body

### Unit tests below ###
def check(candidate):
	assert candidate(u'#\nThis is the rest of the page body.') == ([], u'#\nThis is the rest of the page body.')
	assert candidate(u'#foo bar') == ([('foo', 'bar')], u'')
	assert candidate(u'#\n\nThis is the rest of the page body.') == ([], u'#\n\nThis is the rest of the page body.')
	assert candidate(u'# foo bar baz') == candidate('# foo bar baz')
	assert candidate(u'#foo bar baz') == ([('foo', 'bar baz')], '')
	assert candidate(u'#foo ') == ([('foo', '')], u'')
	assert candidate(u'#foo') == ([('foo', '')], u'')
	assert candidate(
    'This is the body of the page.\n'
    '#\n'
    'This is the second line of the body.\n'
    '#foo\n'
    'This is the third line of the body.\n'
    ) == (
        [],
        'This is the body of the page.\n'
        '#\n'
        'This is the second line of the body.\n'
        '#foo\n'
        'This is the third line of the body.\n'
        )
	assert candidate(u'Some text\n#hello\n#there\n') == ([], u'Some text\n#hello\n#there\n')
	assert candidate(u'#foo bar\n') == ([('foo', 'bar')], u'')
	assert candidate(u'#hello\n#there\n') == ([('hello', ''), ('there', '')], u'')
	assert candidate(u'This is a #comment') == ([], 'This is a #comment')
	assert candidate(u"") == ([], u"")
def test_check():
	check(get_processing_instructions)
