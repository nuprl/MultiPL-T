def Prefactor(flux,index,emin,emax,escale):
    """ Compute the prefactor at the energy escale knowing
     the flux and index between emin and emax"""
	### Canonical solution below ###    

    Denomin = pow(emax,-abs(index)+1.) -pow(emin,-abs(index)+1.)
    return flux*(-abs(index)+1)*pow(escale,-abs(index)) / Denomin

### Unit tests below ###
def check(candidate):
	assert candidate(1,0,1,2,2.) == 1.
	assert candidate(1.,0.,1.,2.,1.) == 1.
	assert candidate(1,0,1,2,1.5) == 1.
def test_check():
	check(Prefactor)
