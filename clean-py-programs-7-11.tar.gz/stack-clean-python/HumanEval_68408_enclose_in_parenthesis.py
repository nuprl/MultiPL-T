def enclose_in_parenthesis(query_txt):
    """ 
     Encloses each word in query_txt in double quotes.
     Args:
     query_txt: Search query
     Returns:
     '(query_word1) AND (query_word2) ...'
     """
	### Canonical solution below ###    
    query_words = query_txt.split(',')
    return '(' + ') AND ('.join([word for word in query_words if word]) + ')'

### Unit tests below ###
def check(candidate):
	assert candidate(query_txt='python') == '(python)'
	assert candidate('hi') == '(hi)'
	assert candidate(
    'hello world') == '(hello world)'
	assert candidate(query_txt='hello') == '(hello)'
	assert candidate('python') == '(python)'
	assert candidate('query_word1,,query_word2,') == '(query_word1) AND (query_word2)'
	assert candidate('the') == '(the)'
	assert candidate(query_txt='abc,def') == '(abc) AND (def)'
	assert candidate('hello,world,') == '(hello) AND (world)'
	assert candidate('the,quick,lazy,brown,fox,jumps,over,dog') == '(the) AND (quick) AND (lazy) AND (brown) AND (fox) AND (jumps) AND (over) AND (dog)'
	assert candidate('query_word1') == '(query_word1)'
	assert candidate(
    'the,lazy,dog') == '(the) AND (lazy) AND (dog)'
	assert candidate(query_txt='hello,world') == '(hello) AND (world)'
	assert candidate(
    'hello,world,foo,bar') == '(hello) AND (world) AND (foo) AND (bar)'
	assert candidate(query_txt='abc,,def') == '(abc) AND (def)'
	assert candidate(
    'hello,world,test') == '(hello) AND (world) AND (test)'
	assert candidate(
    'hello,world,123,456') == '(hello) AND (world) AND (123) AND (456)'
	assert candidate('hello,,world') == '(hello) AND (world)'
	assert candidate(
    'this is a test') == '(this is a test)'
	assert candidate(
    'the,quick,brown,fox,jumps,over,the,lazy,dog') == '(the) AND (quick) AND (brown) AND (fox) AND (jumps) AND (over) AND (the) AND (lazy) AND (dog)'
	assert candidate(',hello,world,') == '(hello) AND (world)'
	assert candidate('query_word1,,query_word2') == '(query_word1) AND (query_word2)'
	assert candidate('hello,world') == '(hello) AND (world)'
	assert candidate(
    "Hello, I am a test string, how are you?") == candidate(
        "Hello, I am a test string, how are you?")
	assert candidate(',query_word1,,query_word2,') == '(query_word1) AND (query_word2)'
	assert candidate('hello') == '(hello)'
	assert candidate(
    "query_word1,query_word2,query_word3") == "(query_word1) AND (query_word2) AND (query_word3)"
	assert candidate(
    ',fox,,') == '(fox)'
	assert candidate('python,') == '(python)'
	assert candidate('a') == '(a)'
	assert candidate('the,lazy,dog') == '(the) AND (lazy) AND (dog)'
	assert candidate(
    'hello,world, foo,bar')
	assert candidate(query_txt=',hello,world,') == '(hello) AND (world)'
	assert candidate(
    'one,two,three'
) == '(one) AND (two) AND (three)', \
    'Incorrect candidate'
	assert candidate(
    'query_word1') == '(query_word1)'
	assert candidate(query_txt='abc,def,') == '(abc) AND (def)'
	assert candidate(',query_word1,,query_word2,,') == '(query_word1) AND (query_word2)'
	assert candidate(
    'the,quick,lazy,brown,fox,jumps,over,dog') == '(the) AND (quick) AND (lazy) AND (brown) AND (fox) AND (jumps) AND (over) AND (dog)'
	assert candidate('one') == '(one)'
	assert candidate('query_word1,') == '(query_word1)'
	assert candidate(query_txt='python,java,c++') == '(python) AND (java) AND (c++)'
	assert candidate(
    'fox,,,') == '(fox)'
	assert candidate(query_txt='hello,world,!') == '(hello) AND (world) AND (!)'
	assert candidate('the,quick,brown,fox,jumps,over,the,lazy,dog') == '(the) AND (quick) AND (brown) AND (fox) AND (jumps) AND (over) AND (the) AND (lazy) AND (dog)'
	assert candidate(
    'query_word1,query_word2,query_word3') == '(query_word1) AND (query_word2) AND (query_word3)'
	assert candidate(
    'query_word1,query_word2') == '(query_word1) AND (query_word2)'
	assert candidate(
    'hello,world,hi,there') == '(hello) AND (world) AND (hi) AND (there)'
	assert candidate(query_txt='hello world') == '(hello world)'
	assert candidate('hello,') == '(hello)'
	assert candidate(
    'this is a test,this is another test') == '(this is a test) AND (this is another test)'
	assert candidate(
    'hello,world,how,are,you,today') == '(hello) AND (world) AND (how) AND (are) AND (you) AND (today)'
	assert candidate(
    'dog') == '(dog)'
	assert candidate('hello world') == '(hello world)'
	assert candidate(',query_word1,query_word2') == '(query_word1) AND (query_word2)'
	assert candidate(query_txt='hello,world,') == '(hello) AND (world)'
	assert candidate(
    'fox') == '(fox)'
	assert candidate(query_txt='abc,def,ghi,') == '(abc) AND (def) AND (ghi)'
	assert candidate(query_txt='python,java') == '(python) AND (java)'
	assert candidate(
    'fox,,') == '(fox)'
	assert candidate(
    'united,states,of,america,united,kingdom,india'
) == '(united) AND (states) AND (of) AND (america) AND (united) AND (kingdom) AND (india)'
	assert candidate(query_txt='abc,def,ghi') == '(abc) AND (def) AND (ghi)'
	assert candidate(
    'hello,world,123,') == '(hello) AND (world) AND (123)'
	assert candidate('query_word1,query_word2') == '(query_word1) AND (query_word2)'
	assert candidate(
    'hello,world,123') == '(hello) AND (world) AND (123)'
	assert candidate(',,,') == '()'
	assert candidate(
    'hello,world') == '(hello) AND (world)'
	assert candidate(
    'fox,') == '(fox)'
	assert candidate(
    'hello') == '(hello)', "candidate('hello')"
def test_check():
	check(enclose_in_parenthesis)
