def get_while_step_pipeline():
    """Test pipeline for while."""
    ### Canonical solution below ###
    return {
        'sg1': [
            'sg1.step1',
            'sg1.step2'
        ],
        'sg2': [
            'sg2.step1',
            'sg2.step2'
        ],
        'sg3': [
            {'name': 'sg3.step1',
             'while': {
                 'max': 3},
             },
            'sg3.step2'
        ],
        'sg4': [
            'sg4.step1',
            'sg4.step2'
        ],
        'sg5': [
            'sg5.step1'
        ],
        'sg6': [
            'sg6.step1',
            'sg6.step2'
        ]
    }


### Unit tests below ###
def check(candidate):
	assert candidate(
) == {'sg1': ['sg1.step1','sg1.step2'],
    'sg2': ['sg2.step1','sg2.step2'],
    'sg3': [{'name':'sg3.step1', 'while': {'max': 3}},'sg3.step2'],
    'sg4': ['sg4.step1','sg4.step2'],
    'sg5': ['sg5.step1'],
    'sg6': ['sg6.step1','sg6.step2']}
	assert candidate(
) == {
   'sg1': [
       'sg1.step1',
       'sg1.step2'
    ],
   'sg2': [
       'sg2.step1',
       'sg2.step2'
    ],
   'sg3': [
        {'name':'sg3.step1',
         'while': {
            'max': 3},
         },
       'sg3.step2'
    ],
   'sg4': [
       'sg4.step1',
       'sg4.step2'
    ],
   'sg5': [
       'sg5.step1'
    ],
   'sg6': [
       'sg6.step1',
       'sg6.step2'
    ]
}
	assert candidate(
) == {'sg1': ['sg1.step1','sg1.step2'],
     'sg2': ['sg2.step1','sg2.step2'],
     'sg3': [{'name':'sg3.step1', 'while': {'max': 3}},'sg3.step2'],
     'sg4': ['sg4.step1','sg4.step2'],
     'sg5': ['sg5.step1'],
     'sg6': ['sg6.step1','sg6.step2']
      }
	assert candidate(
    ) == {'sg1': ['sg1.step1','sg1.step2'],
         'sg2': ['sg2.step1','sg2.step2'],
         'sg3': [{'name':'sg3.step1', 'while': {'max': 3}},'sg3.step2'],
         'sg4': ['sg4.step1','sg4.step2'],
         'sg5': ['sg5.step1'],
         'sg6': ['sg6.step1','sg6.step2']}
	assert candidate(
) == {'sg1': ['sg1.step1','sg1.step2'],
    'sg2': ['sg2.step1','sg2.step2'],
    'sg3': [{'name':'sg3.step1',
              'while': {'max': 3}},
            'sg3.step2'],
    'sg4': ['sg4.step1','sg4.step2'],
    'sg5': ['sg5.step1'],
    'sg6': ['sg6.step1','sg6.step2']}
	assert candidate(
) == {
   'sg1': ['sg1.step1','sg1.step2'],
   'sg2': ['sg2.step1','sg2.step2'],
   'sg3': [
        {
            'name':'sg3.step1',
            'while': {
               'max': 3
            }
        },
       'sg3.step2'
    ],
   'sg4': ['sg4.step1','sg4.step2'],
   'sg5': ['sg5.step1'],
   'sg6': ['sg6.step1','sg6.step2']
}
	assert candidate(
) == {
   'sg1': [
       'sg1.step1',
       'sg1.step2'
    ],
   'sg2': [
       'sg2.step1',
       'sg2.step2'
    ],
   'sg3': [
        {
            'name':'sg3.step1',
            'while': {
               'max': 3
            }
        },
       'sg3.step2'
    ],
   'sg4': [
       'sg4.step1',
       'sg4.step2'
    ],
   'sg5': [
       'sg5.step1'
    ],
   'sg6': [
       'sg6.step1',
       'sg6.step2'
    ]
}
	assert candidate(
) == {
   'sg1': ['sg1.step1','sg1.step2'],
   'sg2': ['sg2.step1','sg2.step2'],
   'sg3': [{'name':'sg3.step1',
             'while': {
                'max': 3},
             },
           'sg3.step2'],
   'sg4': ['sg4.step1','sg4.step2'],
   'sg5': ['sg5.step1'],
   'sg6': ['sg6.step1','sg6.step2']
}
	assert candidate(
) == {'sg1': ['sg1.step1','sg1.step2'],
     'sg2': ['sg2.step1','sg2.step2'],
     'sg3': [{'name':'sg3.step1', 'while': {'max': 3}},'sg3.step2'],
     'sg4': ['sg4.step1','sg4.step2'],
     'sg5': ['sg5.step1'],
     'sg6': ['sg6.step1','sg6.step2']}
def test_check():
	check(get_while_step_pipeline)
