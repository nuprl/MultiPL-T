def _str2num(s):
    """ Converts a string to a number checking whether it is int or not"""
	### Canonical solution below ###  
  return int(s) if s.lstrip('-').isdigit() else float(s)

### Unit tests below ###
def check(candidate):
	assert candidate(str(123.456)) == 123.456
	assert candidate('1.234') == 1.234
	assert candidate(str(1.0e+3)) == 1.0e+3
	assert candidate( "1" ) == 1
	assert candidate(str(1.0e-3)) == 1.0e-3
	assert candidate(str(123)) == 123
	assert candidate('-1000.0') == -1000
	assert candidate( '-1e10' ) == -1e10
	assert candidate( '-100' ) == -100
	assert candidate('1e1') == 1e1
	assert candidate( '1' ) == 1
	assert candidate(u'-1.0e-1') == -1.0e-1
	assert candidate( "-2e3" ) == -2e3
	assert candidate('1e3') == 1000.0
	assert candidate(u'1.0e1') == 1.0e1
	assert candidate("123") == 123
	assert candidate(u'1.0') == 1.0
	assert candidate("0") == 0
	assert candidate( '1234.56E-7' ) == 1234.56E-7
	assert candidate(str(123.4)) == 123.4
	assert candidate( "-2.2e3" ) == -2.2e3
	assert candidate( '1e-10' ) == 1e-10
	assert candidate(u'1.0e-1') == 1.0e-1
	assert candidate('1000.0') == 1000
	assert candidate(str(-1.0e-3)) == -1.0e-3
	assert candidate(str(-1e-10)) == -1e-10
	assert candidate('1.') == 1.
	assert candidate('1e2') == 100
	assert candidate('-1.234') == -1.234
	assert candidate("-1.1") == -1.1
	assert candidate( "-1e-10" ) == -1e-10
	assert candidate( "2" ) == 2
	assert candidate(str(1.0)) == 1.0
	assert candidate( "2e3" ) == 2e3
	assert candidate('-10') == -10
	assert candidate( '-1.0' ) == -1.0
	assert candidate(str(-1.0e+3)) == -1.0e+3
	assert candidate(str(-1)) == -1
	assert candidate('1') == 1
	assert candidate("1") == 1
	assert candidate(u'-1.0') == -1.0
	assert candidate( "01" ) == 1
	assert candidate(str(-123.456)) == -123.456
	assert candidate(str(-1.0e6)) == -1.0e6
	assert candidate('10.0') == 10.0
	assert candidate('1e3') == 1e3
	assert candidate("123.4") == 123.4
	assert candidate("-0") == 0
	assert candidate('-1e2') == -100
	assert candidate(str(1.0e6)) == 1.0e6
	assert candidate(str(1.0e+15)) == 1.0e+15
	assert candidate( '-1e-10' ) == -1e-10
	assert candidate( "1e-10" ) == 1e-10
	assert candidate("-1.5") == -1.5
	assert candidate("1.5") == 1.5
	assert candidate(str(1.1)) == 1.1
	assert candidate(str(-1.0e+15)) == -1.0e+15
	assert candidate(str(1.1e-10)) == 1.1e-10
	assert candidate( "-01" ) == -1
	assert candidate( "-2.2" ) == -2.2
	assert candidate( '100.0e+1' ) == 1000.0
	assert candidate( '1234.56' ) == 1234.56
	assert candidate('1.0') == 1.0
	assert candidate(u'1') == 1
	assert candidate( '-1' ) == -1
	assert candidate('4') == 4
	assert candidate('-1e-1') == -0.1
	assert candidate('-1') == -1
	assert candidate(str(0.123456)) == 0.123456
	assert candidate(str(-1.1e-10)) == -1.1e-10
	assert candidate('1.1e3') == 1100.0
	assert candidate(str(-0.123456)) == -0.123456
	assert candidate( '1e10' ) == 1e10
	assert candidate('1e-3') == 1e-3
	assert candidate('1e-1') == 0.1
	assert candidate( '1e-1' ) == 0.1
	assert candidate( '-1234.56' ) == -1234.56
	assert candidate( '100' ) == 100
	assert candidate(str(-123)) == -123
	assert candidate('100.0' ) == 100.0
	assert candidate( "-1.0e-10" ) == -1.0e-10
	assert candidate('-1000') == -1000
	assert candidate(str(1.5)) == 1.5
	assert candidate( '1234.56e-7' ) == 1234.56e-7
	assert candidate( '1e1' ) == 10
	assert candidate( "1.0" ) == 1.0
	assert candidate('4.0') == 4.0
	assert candidate( "2.2" ) == 2.2
	assert candidate( "2.2e3" ) == 2.2e3
	assert candidate( "-2" ) == -2
	assert candidate( '1234' ) == 1234
	assert candidate(str(-1.1)) == -1.1
	assert candidate( '1.0' ) == 1.0
	assert candidate('1000') == 1000
	assert candidate( '-1e1' ) == -10
	assert candidate('10') == 10
	assert candidate(str(1)) == 1
	assert candidate('-1.0') == -1.0
	assert candidate('1.2e1') == 1.2e1
	assert candidate( "1.0e-10" ) == 1.0e-10
	assert candidate(str(1e6)) == 1e6
	assert candidate(str(0)) == 0
	assert candidate('1234' ) == 1234
	assert candidate(str(-1.0)) == -1.0
	assert candidate('100' ) == 100
	assert candidate('-4') == -4
	assert candidate(u'-1') == -1
	assert candidate('-4.0') == -4.0
	assert candidate( '-1234' ) == -1234
	assert candidate( '-100.0' ) == -100.0
	assert candidate('1.1') == 1.1
	assert candidate( '-1e-1' ) == -0.1
	assert candidate( '-100.0e-1' ) == -10.0
	assert candidate("-123.4") == -123.4
	assert candidate(str(-1e6)) == -1e6
	assert candidate("1.1") == 1.1
	assert candidate("-1") == -1
	assert candidate( '1234.56e7' ) == 1234.56e7
	assert candidate(str(1.0e-15)) == 1.0e-15
	assert candidate(u'-1.0e1') == -1.0e1
	assert candidate(str(-1.0e-15)) == -1.0e-15
	assert candidate(str(1e-10)) == 1e-10
	assert candidate('-1e3') == -1000.0
	assert candidate(str(0.0)) == 0.0
def test_check():
	check(_str2num)
