def unwrap_py2(func):
    """Unwrap a wrapped function.

    The function inspect.unwrap has been implemented only in Python 3.4. With
    Python 2, this works only for functions wrapped by wraps_py2().

    """
    ### Canonical solution below ###
    unwrapped_func = func
    try:
        while True:
            unwrapped_func = unwrapped_func.__wrapped__
    except AttributeError:
        return unwrapped_func


### Unit tests below ###
def check(candidate):
	assert candidate(candidate(candidate)) is candidate
	assert candidate(candidate) is candidate
	assert candidate(candidate) == candidate
def test_check():
	check(unwrap_py2)
