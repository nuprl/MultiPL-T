def CountReordered(sequence_numbers):
    """ Returns number of reordered indices.
     
     A reordered index is an index `i` for which sequence_numbers[i] >=
     sequence_numbers[i + 1]
     """
	### Canonical solution below ###  
  return sum(1 for (s1, s2) in zip(sequence_numbers,
                                   sequence_numbers[1:]) if
             s1 >= s2)

### Unit tests below ###
def check(candidate):
	assert candidate(range(7)) == 0
	assert candidate([0, 1, 3, 5, 7, 8, 6, 4, 2, 5]) == 3
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9]) == 1
	assert candidate(range(10)[::-1]) == 9
	assert candidate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 10]) == 1
	assert candidate(sequence_numbers=[1, 2, 3, 4]) == 0
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 0
	assert candidate(list(range(5))) == 0
	assert candidate(
    [1, 3, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]) == 0
	assert candidate(range(10, 1, -2)) == 4
	assert candidate(range(9)) == 0
	assert candidate([1, 2, 3, 5, 4, 6, 7, 9, 10, 8]) == 2
	assert candidate(range(0)) == 0
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8]) == 2
	assert candidate([1, 2, 3, 5, 4, 6, 7, 8, 9, 10]) == 1
	assert candidate(range(100)[1:]) == 0
	assert candidate(sequence_numbers=[1, 3, 2, 4]) == 1
	assert candidate(range(0, 1000, 10)) == 0
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 0
	assert candidate(range(3)) == 0
	assert candidate(list(range(10))) == 0
	assert candidate([1, 2, 3, 4, 5, 4, 3]) == 2
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 8]) == 1
	assert candidate(sequence_numbers=[1, 3, 2, 5, 4]) == 2
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9]) == 0
	assert candidate([1, 2, 3, 4, 5, 4]) == 1
	assert candidate([0, 1, 2, 3, 4]) == 0
	assert candidate(
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]) == 0
	assert candidate([1, 2, 3, 4, 5]) == 0
	assert candidate(range(100)) == 0
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7]) == 3
	assert candidate(range(0, 100, 2)) == 0
	assert candidate([1, 2, 4, 6, 3, 5, 7, 8, 9, 10]) == 1
	assert candidate(range(1)) == 0
	assert candidate(
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]) == 0
	assert candidate(range(5)) == 0
	assert candidate(range(10)) == 0
	assert candidate([2, 4, 3, 1, 0]) == 3
	assert candidate(range(100)[::-1]) == 99
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]) == 0
	assert candidate(range(100)[::-1][1:]) == 98
	assert candidate(range(0, 10)) == 0
def test_check():
	check(CountReordered)
