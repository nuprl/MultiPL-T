def int16_to_bytes(value):
    """ 
     Converts a int to a str with 4 bytes
     
     :param value: int value to convert
     :return: str with 4 bytes
     """
	### Canonical solution below ###    

    ints = [0, 0]
    ints[0] = (value & 0x00FF)
    ints[1] = (value & 0xFF00) >> 8
    return ''.join(chr(b) for b in ints)

### Unit tests below ###
def check(candidate):
	assert candidate(0x0101) == '\x01\x01'
	assert candidate(0x0000) == '\x00\x00'
	assert candidate(0xFFFF) == '\xff\xff'
	assert candidate(0x0F0F) == '\x0F\x0F'
	assert candidate(2) == '\x02\x00'
	assert candidate(-1) == '\xff\xff'
	assert candidate(-2) == '\xfe\xff'
	assert candidate(0x1000) == '\x00\x10'
	assert candidate(-65535) == '\x01\x00'
	assert candidate(65535) == '\xff\xff'
	assert candidate(65535) == '\xFF\xFF'
	assert candidate(-256) == '\x00\xff'
	assert candidate(-255) == '\x01\xff'
	assert candidate(0xFFFF) == '\xFF\xFF'
	assert candidate(255) == '\xff\x00'
	assert candidate(65537) == '\x01\x00'
	assert candidate(256) == '\x00\x01'
	assert candidate(0) == '\x00\x00'
	assert candidate(1234) == '\xd2\x04'
	assert candidate(0x1234) == '\x34\x12'
	assert candidate(65536) == '\x00\x00'
	assert candidate(257) == '\x01\x01'
	assert candidate(1) == '\x01\x00'
def test_check():
	check(int16_to_bytes)
