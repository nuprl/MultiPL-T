def _get_files_glob(filenames, max_differences = 1, show_differences = False):
    """ Tries to generate a glob-string for a set of filenames, containing
     at most 'max_differences' different columns. If more differences are
     found, or if the length of filenames vary, None is returned."""
	### Canonical solution below ###    
    # File lengths must be the same, otherwise we'd have to do MSA
    if len(set(map(len, filenames))) > 1:
        return None

    glob_fname, differences = [], 0
    for chars in zip(*filenames):
        if "?" in chars:
            chars = ('?',)

        if len(frozenset(chars)) > 1:
            if show_differences:
                chars = ("[%s]" % ("".join(sorted(chars))),)
            else:
                chars = ("?",)
            differences += 1
        glob_fname.append(chars[0])

    if differences > max_differences:
        return None

    return "".join(glob_fname)

### Unit tests below ###
def check(candidate):
	assert candidate(
    ["a.txt", "b.txt", "c.txt"],
    max_differences = 2
) == "?.txt"
	assert candidate(
    [
        "foo.txt",
        "bar.txt",
        "baz.txt",
        "foo.txt",
        "bar.txt",
        "baz.txt",
        "bar.txt",
        "baz.txt"
    ],
    2
) == None, "candidate failed"
	assert candidate(
    ["a.txt", "b.txt", "c.txt"],
    show_differences = True
) == "[abc].txt"
	assert candidate(filenames = ["file1.txt", "file2.txt"], max_differences = 2) == "file?.txt"
	assert candidate(filenames = ["abc", "abcd", "abe"]) == None
	assert candidate(
    ["a.txt", "b.txt", "c.txt", "d.txt"],
    max_differences = 2,
    show_differences = False) == "?.txt"
	assert candidate(
    ["foo.1", "foo.2", "foo.3", "bar.1", "bar.2", "bar.3"], max_differences = 0, show_differences = True) == None
	assert candidate(
    ["a.txt", "b.txt", "c.txt"],
    max_differences = 1,
    show_differences = False) == "?.txt"
	assert candidate(
    ["file1.txt", "file2.txt", "file3.txt", "file4.txt"], max_differences = 1) == "file?.txt"
	assert candidate(
    ["test.txt", "test.txt", "test.txt"],
    max_differences = 2) == "test.txt"
	assert candidate(
    ["a.b", "a.c", "a.d", "a.e"],
    max_differences = 2,
    show_differences = False
) == "a.?"
	assert candidate(
    ["foo.1", "foo.2", "foo.3", "bar.1", "bar.2", "bar.3"], max_differences = 0) == None
	assert candidate(
    ["foo-a-b-c.txt", "foo-a-b-d.txt", "foo-a-b-e.txt"], 3) == "foo-a-b-?.txt"
	assert candidate(filenames = ["a.txt", "a.txt", "a.txt"]) == "a.txt"
	assert candidate(
    ["test.txt", "test.txt", "test.txt", "test.txt"],
    max_differences = 2) == "test.txt"
	assert candidate(
    ["test.txt", "test.txt", "test.txt", "test.txt"]) == "test.txt"
	assert candidate(
    ["a_0.png", "a_1.png", "a_2.png", "a_3.png"],
    max_differences = 1,
    show_differences = False,
) == "a_?.png"
	assert candidate(
    ["test.txt", "test.txt", "test.txt"]) == "test.txt"
	assert candidate(filenames = ["abc.txt", "abc.txt", "abc.txt"]) == "abc.txt"
	assert candidate(filenames = ['a.x', 'b.x', 'c.x']) == '?.x'
	assert candidate(
    ["a.b", "a.c", "a.d", "a.e"],
    max_differences = 1,
    show_differences = False
) == "a.?"
	assert candidate(filenames = ["a.txt", "a.txt", "a.txt", "a.txt"], max_differences = 2) == "a.txt"
	assert candidate(
    ['a.0.txt', 'a.1.txt', 'a.2.txt'],
    max_differences = 3) == 'a.?.txt'
	assert candidate(
    ["foo-a-b-c.txt", "foo-a-b-d.txt", "foo-a-b-e.txt"], 2) == "foo-a-b-?.txt"
	assert candidate(filenames = ["abc", "abc", "abc"]) == "abc"
	assert candidate(
    ["a.txt", "b.txt", "c.txt", "d.txt"],
    max_differences = 1,
    show_differences = False) == "?.txt"
	assert candidate(filenames = ['a.x', 'b.y', 'c.x']) == None
	assert candidate(filenames = ["a.txt", "a.txt", "a.txt", "a.txt"]) == "a.txt"
	assert candidate(
    ["a.txt", "b.txt", "c.txt"],
    max_differences = 2,
    show_differences = True) == "[abc].txt"
	assert candidate(
    ["test.txt", "test.txt", "test.txt", "test.txt", "test.txt"],
    max_differences = 2) == "test.txt"
	assert candidate(
    ["test.txt", "test.txt", "test.txt", "test.txt", "test.txt"]) == "test.txt"
	assert candidate(
    ["test.txt", "test.txt", "test.txt", "test.txt", "test.txt", "test.txt"],
    max_differences = 2) == "test.txt"
	assert candidate(filenames = ["file1.txt", "file2.txt"]) == "file?.txt"
	assert candidate(
    ["foo-a-b-c.txt", "foo-a-b-d.txt", "foo-a-b-e.txt"], 5, True) == "foo-a-b-[cde].txt"
	assert candidate(filenames = ["a.txt", "b.txt", "c.txt", "d.txt"]) == "?.txt"
	assert candidate(
    ["file1.txt", "file2.txt", "file3.txt"]) == "file?.txt"
	assert candidate(
    ["test.txt", "test.txt", "test.txt", "test.txt", "test.txt", "test.txt"]) == "test.txt"
	assert candidate(
    [
        "foo.txt",
        "bar.txt",
        "baz.txt",
        "foo.txt",
        "bar.txt",
        "baz.txt"
    ],
    2
) == None, "candidate failed"
	assert candidate(
    ["a.txt", "b.txt", "c.txt"]
) == "?.txt"
	assert candidate(tuple("abc"), max_differences = 2, show_differences = True) == "[abc]"
	assert candidate(filenames = [("a", "b", "c"), ("a", "b", "c")]) == "abc"
	assert candidate(
    ["foo.1", "foo.2", "foo.3", "bar.1", "bar.2", "bar.3"], max_differences = 2, show_differences = True) == None
	assert candidate(filenames = ["abc.txt", "abc.txt"]) == "abc.txt"
	assert candidate(
    ["foo-a-b-c.txt", "foo-a-b-d.txt", "foo-a-b-e.txt"]) == "foo-a-b-?.txt"
	assert candidate( ("a1", "a2", "b3") ) == None
	assert candidate( ("a1", "a2", "a3", "b4") ) == None
	assert candidate(
    ("/path/to/file1.txt", "/path/to/file2.txt"),
    max_differences = 1,
    show_differences = False) == "/path/to/file?.txt"
def test_check():
	check(_get_files_glob)
