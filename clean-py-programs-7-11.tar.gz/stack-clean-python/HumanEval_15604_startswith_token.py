def startswith_token(s, prefix, separators=None):
	"""Tests if a string is either equal to a given prefix or prefixed by it
	followed by a separator.
	"""
    ### Canonical solution below ###

	if separators is None:
		return s == prefix
	return (
		s.startswith(prefix) and
		(len(s) == len(prefix) or s.startswith(separators, len(prefix))))


### Unit tests below ###
def check(candidate):
	assert not candidate('abc', 'abcd')
	assert candidate(s="abc", prefix="abc", separators=(" ",))
	assert not candidate(u'y x', u'x', u' ')
	assert candidate('', 'foo') == False
	assert candidate(
	'1.23',
	'1.2',
	' ') == False
	assert not candidate(b'ab', b'abc')
	assert not candidate(b'abc', b'abc\t ', b' ')
	assert candidate(' foo', 'foo','') == False
	assert candidate(b'foo', b'foo')
	assert not candidate(s="ab", prefix="b")
	assert not candidate(s="abc", prefix="ab", separators=(" ",))
	assert not candidate("a", "b")
	assert candidate('abc', 'a', ('b',))
	assert not candidate(
	'foo bar', 'foo', separators=',')
	assert candidate(s="a", prefix="a")
	assert candidate('foo ', 'foo ','') == True
	assert candidate('ab', 'ab', ())
	assert candidate(
	'1.23',
	'1.2',
	'.') == False
	assert not candidate(
	"hello\tworld", "hello",
	separators=" \n\r\f\v")
	assert candidate('abc', 'abc', ())
	assert candidate('a ', 'a','')
	assert not candidate('abc', 'abcd', 'abcd')
	assert candidate(
	'foo', 'foo')
	assert candidate('abc', 'abc', 'a')
	assert not candidate(
	"abc", "b",
	separators=(" ", "\t"))
	assert candidate(
	'foo.bar', 'foo', separators=('.', '_'))
	assert candidate('abcd', 'a', ('b', 'c', 'd'))
	assert not candidate('a b', 'a', 'c d e')
	assert candidate('foo', None) == False
	assert not candidate(b'foo bar', b'foo', b'-')
	assert not candidate('a', 'b', separators=' ')
	assert candidate("a", "a")
	assert not candidate(b'a b', b'abc')
	assert not candidate("ab", "a", "ac")
	assert candidate('', '')
	assert candidate('a', 'a', separators=' ')
	assert candidate('foo', 'foo') == True
	assert candidate(
	'1.23',
	'1.2',
	None) == False
	assert candidate('foo bar', 'foo ','') == True
	assert candidate(
	'foo bar', 'foo', separators=' ')
	assert candidate(b'a', b'a')
	assert candidate('ab', 'ab', ('b', 'c'))
	assert candidate(
	"1234567890",
	"1234567890",
)
	assert candidate("abc", "abc")
	assert not candidate(b'ab', b'abc', b' ')
	assert candidate("ab", "a", "b")
	assert candidate('a', 'a', '')
	assert not candidate('a\tb', 'a', separators=' a')
	assert not candidate(b'abc', b'abc\t', b' ')
	assert candidate('abcd', 'a', ('b',))
	assert not candidate(u'a ', u'a')
	assert not candidate(u'foobar', u'foo')
	assert candidate(b"foo", b"foo")
	assert candidate('foo ', 'foo') == False
	assert candidate(b'a', b'a', b' \t\n')
	assert candidate('a', 'a', ('b', 'c'))
	assert not candidate(b'abc', b'ac', b' ')
	assert not candidate('abc', 'abcd', 'a')
	assert not candidate('a b', 'a', separators='c')
	assert not candidate(b'abc', b'b')
	assert candidate(u'x', u'x')
	assert not candidate(b'a', b'b')
	assert not candidate(b'abc', b'ac')
	assert not candidate(
	"foobar",
	"foo",
	None)
	assert not candidate(s="abc", prefix="abcd", separators=(" ",))
	assert candidate(b'a b', b'a', b' ')
	assert not candidate("abc", "ac")
	assert not candidate(
	"abc\t", "b",
	separators=(" ", "\t"))
	assert candidate('ab', 'a', ('b', 'c', 'd'))
	assert not candidate('abc', 'abcd', 'ab')
	assert not candidate(s="ab", prefix="b", separators="abc")
	assert not candidate('', 'a')
	assert not candidate('a', 'b')
	assert not candidate(b'a', b'b', b' \t')
	assert candidate('abc', 'a', ('b', 'c', 'd'))
	assert not candidate('b', 'a')
	assert not candidate(s="a", prefix="ab")
	assert candidate(u'foo', u'foo')
	assert candidate(u'x ', u'x', u' ')
	assert not candidate(b'foo bar', b'bar')
	assert not candidate(b'a\t', b'b', b' \t')
	assert not candidate('ba', 'a')
	assert candidate('foo ', 'foo','') == True
	assert not candidate(
	"1234567890",
	"12345678901",
)
	assert not candidate('abc', 'a', ('c',))
	assert not candidate(
	"abc ", "b",
	separators=(" ", "\t"))
	assert candidate('bar', 'foo','') == False
	assert candidate(
	"foo",
	"foo",
	None)
	assert not candidate(
	"1234567890",
	"123456789",
	"12345678",
)
	assert not candidate(b'a\t', b'b', b' \t\n')
	assert not candidate('ab', 'a')
	assert not candidate(b'\ta', b'b', b' \t')
	assert not candidate('a b', 'a', 'c')
	assert candidate('ab', 'a', ('b', 'c'))
	assert candidate('foo bar', 'foo ','\t\n') == False
	assert not candidate("abc", "abcd")
	assert not candidate(s="abc ", prefix="abc", separators=(":",))
	assert candidate('ab', 'ab')
	assert candidate(b"foo\tbar", b"foo", b"\t")
	assert candidate(s="abc ", prefix="abc", separators=(" ",))
	assert not candidate('a b', 'a', separators=' a')
	assert candidate(b'foo bar', b'foo', b' ')
	assert candidate(b'a', b'a', b' \t')
	assert not candidate(
	"1234567890",
	"123456789",
	"12345678901",
)
	assert candidate('a', 'a', ())
	assert not candidate(s="b", prefix="ab")
	assert candidate("ab", "ab")
	assert candidate('a b', 'a', separators=' ')
	assert candidate("hello", "hello", separators=" \t\n\r\f\v")
	assert not candidate(b'foo bar', b'foobar')
	assert not candidate("ab/c", "ac", separators="\\/")
	assert candidate(b"foo bar", b"foo", b" ")
	assert candidate('abc', 'abc', ('a', 'b', 'c'))
	assert not candidate(None, "")
	assert not candidate('a b', 'a', 'b c d')
	assert candidate(s="a", prefix="a", separators="abc")
	assert candidate(
	'1.23',
	'1',
	'.') == True
	assert not candidate(b"foobar", b"foo", b" ")
	assert candidate(u'a', u'a', u' ')
	assert not candidate(b'foo', b'bar')
	assert candidate('abc', 'a', ('b', 'c'))
	assert candidate('a', 'a', ('b', 'c', 'd'))
	assert candidate('ab', 'ab', ('b',))
	assert not candidate('a b', 'a', 'c d')
	assert candidate(s="ab", prefix="ab")
	assert candidate(u'x', u'x', u' ')
	assert candidate('a', 'a','')
	assert not candidate(b"bar", b"foo")
	assert not candidate('abc', 'abcd', '')
	assert candidate(u'x y', u'x', u' ')
	assert not candidate(b'a b', b'b')
	assert candidate('a b', 'a','')
	assert candidate('foo', 'foo','') == True
	assert candidate('abc', 'abc', ('a', 'b', 'c', 'd'))
	assert candidate('a b', 'a', separators=' b')
	assert candidate(
	'abc', 'abc',
	separators=' ') == True
	assert candidate(u'a ', u'a', u' ')
	assert candidate(u'a', u'a')
	assert candidate(
	'foo.bar', 'foo', separators=('.',))
	assert not candidate('a\tb', 'a', separators='c')
	assert not candidate(b'foo-bar', b'foobar')
	assert candidate('abc', 'abc', 'ab')
	assert not candidate(s="c", prefix="ab")
	assert candidate('abcd', 'a', ('b', 'c'))
	assert not candidate(b'abc', b'abc ', b' ')
	assert not candidate(b'foo', b'foobar')
	assert candidate(u'foo-bar', u'foo', u'-')
	assert not candidate(b'foo/bar', b'foobar', b'/-')
	assert candidate(
	'abc', 'abc',
	separators='') == True
	assert candidate('foo bar', 'foo ','\t.') == False
	assert not candidate("ab\\c", "ac", separators="\\/")
	assert candidate(None, None)
	assert candidate(None, 'foo') == False
	assert not candidate('a b', 'a', 'c ')
	assert candidate("ab/c", "ab", separators="/")
	assert not candidate('abc', 'abcd', 'abc')
	assert candidate(s="", prefix="")
	assert not candidate(b'\ta', b'b', b' \t\n')
	assert candidate('abc', 'abc', 'abc')
	assert candidate('a', 'a', ('b',))
	assert candidate(s="abc", prefix="abc")
	assert candidate('a  ', 'a','')
	assert candidate('abc', 'abc')
	assert candidate(
	'foo', 'foo', separators=('.', '_'))
	assert not candidate(u'foobar', u'foo', u'-')
	assert not candidate(b' \ta', b'a', b' \t')
	assert not candidate(
	"1234567890",
	"12345678901",
	"12345678",
)
	assert candidate(
	'foo_bar', 'foo', separators=('_',))
	assert not candidate(s="abc", prefix="b")
	assert not candidate(b'a', b'b', b' \t\n')
	assert candidate('ab', 'a', ('b',))
	assert not candidate(
	'foo.bar', 'foo', separators=('-',))
	assert not candidate("ab/c", "ac", separators="/")
	assert candidate(b'abc', b'abc')
	assert candidate('a', 'a')
	assert not candidate("ab", "a")
	assert not candidate(b"foo\tbar", b"foo", b" ")
	assert candidate(
	"foo bar",
	"foo",
	" ")
	assert not candidate(s="d", prefix="a", separators="abc")
	assert candidate('abc', 'abc', '')
	assert not candidate(s="a", prefix="b")
def test_check():
	check(startswith_token)
