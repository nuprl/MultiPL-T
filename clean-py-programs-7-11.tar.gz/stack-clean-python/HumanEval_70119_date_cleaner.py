def date_cleaner(date):
    """
    Cleans date string after modifying previous years
    """
    ### Canonical solution below ###

    date = str(date)
    long = len(date)-2
    new = ''
    for x in range(long): new = new + date[x]
    return new


### Unit tests below ###
def check(candidate):
	assert candidate('199912-0') == '199912'
	assert candidate('2020') == '20'
	assert candidate(2020100200) == '20201002'
	assert candidate(20170102.0) == '20170102'
	assert candidate(2020) == '20'
	assert candidate(1994020455) == '19940204'
	assert candidate(1994030101) == '19940301'
	assert candidate(2010030212) == '20100302'
def test_check():
	check(date_cleaner)
