def first_line(s):
    """ Returns the first line of a multi-line string"""
	### Canonical solution below ###    
    return s.splitlines()[0]

### Unit tests below ###
def check(candidate):
	assert candidate('a\nb\nc') == 'a'
	assert candidate("This is a single-line string.") == "This is a single-line string."
	assert candidate(r"""first line
""") == "first line"
	assert candidate("Hello World") == "Hello World", "Whole string is first line"
	assert candidate(
    "Hello\nWorld\n") == "Hello", "Hello is the first line, even with newline"
	assert candidate('a\n\n\n\nb') == 'a'
	assert candidate(
"""This is the first line.
This is the second line.""") == "This is the first line."
	assert candidate('No first line') == 'No first line'
	assert candidate('single line') =='single line'
	assert candidate('The first line\r\nIs the second line') == 'The first line'
	assert candidate(
    'first line\n'
   'second line') == 'first line'
	assert candidate(r"""first line""") == "first line"
	assert candidate("This is a single line string.") == "This is a single line string."
	assert candidate(
    """This is a string
    that has multiple lines.""") == "This is a string"
	assert candidate('The first line\rIs the second line') == 'The first line'
	assert candidate(r"""first line
second line
""") == "first line"
	assert candidate('a') == 'a'
	assert candidate(
    "Hello\nWorld") == "Hello", "Hello is the first line"
	assert candidate(
    """This is a string
    that has multiple lines.
    Only the first line will be returned.""") == "This is a string"
	assert candidate(r"""first line
second line
third line
""") == "first line"
	assert candidate("line 1") == "line 1"
	assert candidate('The first line\nIs the second line') == 'The first line'
	assert candidate(
    'This is the first line.\nThis is the second line.\nThis is the third line.'
) == 'This is the first line.'
def test_check():
	check(first_line)
