def strip_base_dir(filename, base_dir):
    """Strip base directory from filename if it starts there.

    >>> strip_base_dir('/path/to/base/relpath/to/file',
    ...                '/path/to/base/')
    'relpath/to/file'

    >>> strip_base_dir('/path/to/somewhere/else/relpath/to/file',
    ...                '/path/to/base/')
    '/path/to/somewhere/else/relpath/to/file'

    """
    ### Canonical solution below ###
    if filename.startswith(base_dir):
        filename = filename[len(base_dir):]
    return filename


### Unit tests below ###
def check(candidate):
	assert candidate(
    '/path/to/somewhere/else/relpath/to/file',
    '/path/to/base/'
) == '/path/to/somewhere/else/relpath/to/file'
	assert candidate(
    '/path/to/base/relpath/to/file',
    '/path/to/base/') =='relpath/to/file'
	assert candidate(
    '/path/to/base/relpath/to/file',
    '/path/to/base/',
) =='relpath/to/file'
	assert candidate(
    '/path/to/base/relpath/to/file',
    '/path/to/base/'
    ) =='relpath/to/file'
	assert candidate(
    '/path/to/somewhere/else/relpath/to/file',
    '/path/to/base/',
) == '/path/to/somewhere/else/relpath/to/file'
	assert candidate(
    '/path/to/base/relpath/to/file',
    '/path/to/base/'
) =='relpath/to/file'
	assert candidate('/path/to/somewhere/else/relpath/to/file',
                      '/path/to/base') == '/path/to/somewhere/else/relpath/to/file'
	assert candidate(
    '/path/to/somewhere/else/relpath/to/file',
    '/path/to/base/') == '/path/to/somewhere/else/relpath/to/file'
	assert candidate(
    '/path/to/somewhere/else/relpath/to/file',
    '/path/to/base/'
    ) == '/path/to/somewhere/else/relpath/to/file'
	assert candidate('/path/to/somewhere/else/relpath/to/file',
                     '/path/to/base/') == \
    '/path/to/somewhere/else/relpath/to/file'
	assert candidate('/path/to/somewhere/else/relpath/to/file',
                      '/path/to/base/') \
       == '/path/to/somewhere/else/relpath/to/file'
	assert candidate(
    '/path/to/somewhere/else/relpath/to/file', '/path/to/base/') == (
        '/path/to/somewhere/else/relpath/to/file')
	assert candidate(
    '/path/to/somewhere/else/relpath/to/file', '/path/to/base/') == \
    '/path/to/somewhere/else/relpath/to/file'
	assert candidate(
    '/path/to/base/relpath/to/file', '/path/to/base/') =='relpath/to/file'
def test_check():
	check(strip_base_dir)
