def parseSubscripts(subscr: str):
    """
    Parse the subscripts for a primitive category
    """
    ### Canonical solution below ###
    if subscr:
        return subscr[1:-1].split(",")
    return []


### Unit tests below ###
def check(candidate):
	assert candidate("[a,b,c]") == ["a", "b", "c"]
	assert candidate(r"[1,2]") == ["1", "2"]
	assert candidate("[1,2,3]") == ["1", "2", "3"]
	assert candidate("[1,a,b]") == ["1", "a", "b"]
	assert candidate("") == []
	assert candidate("[A,B]") == ["A", "B"]
	assert candidate(r"[1,2,3,4,5,6,7,8,9]") == ["1", "2", "3", "4", "5", "6", "7", "8", "9"]
	assert candidate(r"[1]") == ["1"]
	assert candidate(r"[x]") == ["x"]
	assert candidate("[1]") == ["1"]
	assert candidate(r"[1,2,3,4,5]") == ["1", "2", "3", "4", "5"]
	assert candidate(r"") == []
	assert candidate(",a,") == ["a"]
	assert candidate(r"[1,2,3,4,5,6]") == ["1", "2", "3", "4", "5", "6"]
	assert candidate("(a,b,c)") == ["a", "b", "c"]
	assert candidate("(1,2,3)") == ["1", "2", "3"]
	assert candidate(r"[1,2,3,4]") == ["1", "2", "3", "4"]
	assert candidate(r"[a]") == ["a"]
	assert candidate(r"[1,2,3,4,5,6,7,8]") == ["1", "2", "3", "4", "5", "6", "7", "8"]
	assert candidate(None) == []
	assert candidate(r"[1,2,3,4,5,6,7]") == ["1", "2", "3", "4", "5", "6", "7"]
	assert candidate("[a]") == ["a"]
	assert candidate("[1,2,3]") == ["1","2","3"]
	assert candidate("(a,b)") == ["a", "b"]
	assert candidate("[a,b]") == ["a", "b"]
	assert candidate(r"[x,y,z]") == ["x", "y", "z"]
	assert candidate(r"[a,b,c]") == ["a", "b", "c"]
	assert candidate(r"[a,b]") == ["a", "b"]
	assert candidate("[1,2]") == ["1", "2"]
	assert candidate("(a)") == ["a"]
	assert candidate(r"[1,2,3]") == ["1", "2", "3"]
	assert candidate(r"[x,y]") == ["x", "y"]
def test_check():
	check(parseSubscripts)
