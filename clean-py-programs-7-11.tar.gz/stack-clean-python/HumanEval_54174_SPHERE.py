def SPHERE(X):
    """
    Sphere benchmark function D-dimension
    """
    ### Canonical solution below ###
    DIM = len(X)
    SUM = 0
    for I_COUNT in range(DIM):
        X_I = X[I_COUNT]
        SUM += X_I ** 2
    Y = SUM
    return Y


### Unit tests below ###
def check(candidate):
	assert candidate([1]) == 1
	assert candidate( [1, 2, 3, 4, 5] ) == 55
	assert candidate( [0, 0, 0, 0, 0] ) == 0
	assert candidate([0]) == 0
	assert candidate(X=[1, 2, 3]) == 14.0
	assert candidate([0.5]) == 0.25
	assert candidate(X=[-1, -2, -3]) == 14.0
	assert candidate([0.5, 0.5, 0.5]) == 0.75
	assert candidate(X=[0, 0, 0]) == 0.0
	assert candidate([0.5, 0.5]) == 0.5
	assert candidate(X=[1, 1, 1]) == 3.0
def test_check():
	check(SPHERE)
