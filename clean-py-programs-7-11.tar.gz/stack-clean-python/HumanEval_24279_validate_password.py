def validate_password(password):
    """ Validate user password value."""
	### Canonical solution below ###    
    errors = []
    if not isinstance(password, str):
        errors.append("Password must be string type.")
        return errors

    if len(password) < 8:
        errors.append("Password must have minimum 8 characters.")
    password_chars = set(password)
    if not any(c.islower() for c in password_chars):
        errors.append("Password must have at least one lowercase letter.")
    if not any(c.isupper() for c in password_chars):
        errors.append("Password must have at least one uppercase letter.")
    if not any(c.isdigit() for c in password_chars):
        errors.append("Password must have at least one digit.")

    return errors

### Unit tests below ###
def check(candidate):
	assert candidate(12345) == ["Password must be string type."]
	assert candidate(None) == ["Password must be string type."], \
    "None"
	assert candidate(12345678) == ["Password must be string type."]
	assert candidate(1) == ["Password must be string type."]
	assert candidate(123) == ['Password must be string type.']
	assert candidate(1234) == ["Password must be string type."]
	assert candidate(123) == ["Password must be string type."], \
    "Integer"
	assert candidate(None) == ["Password must be string type."]
	assert candidate(5) == ["Password must be string type."]
	assert candidate(None) == ["Password must be string type."], "None"
	assert candidate(8) == ["Password must be string type."]
	assert candidate(123) == ["Password must be string type."], "Integer"
	assert candidate(123) == ["Password must be string type."]
	assert candidate(123456) == ["Password must be string type."]
def test_check():
	check(validate_password)
