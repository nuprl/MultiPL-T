def lremove(s, prefix):
    """Remove prefix from string s"""
    ### Canonical solution below ###
    return s[len(prefix):] if s.startswith(prefix) else s


### Unit tests below ###
def check(candidate):
	assert candidate(u"abcd", u"ab") == u"cd"
	assert candidate('hello', 'hel') == 'lo'
	assert candidate( 'foobar', ''    ) == 'foobar'
	assert candidate('ab', 'a') == 'b'
	assert candidate( 'foobar', 'baz' ) == 'foobar'
	assert candidate('hello', 'hello') == ''
	assert candidate( 'foobar', 'bar' ) == 'foobar'
	assert candidate(u"abcd", u"a") == u"bcd"
	assert candidate("ABC", "CDE") == "ABC"
	assert candidate( 'foobar', 'foo' ) == 'bar'
	assert candidate('aaa', 'a') == 'aa'
	assert candidate('hello', '') == 'hello'
	assert candidate( "foobar", "foo" ) == "bar"
	assert candidate(candidate('hello', 'he'), 'lo') == 'llo'
	assert candidate( "foobar", "xyz" ) == "foobar"
	assert candidate(s = "1234567890", prefix = "123") == "4567890"
	assert candidate('hello', 'hey') == 'hello'
	assert candidate('abc', 'ab') == 'c'
	assert candidate( "foobar", "x" ) == "foobar"
	assert candidate(s = "1234567890", prefix = "1234") == "567890"
	assert candidate( "foobar", "foobar" ) == ""
	assert candidate('hello', 'h') == 'ello'
	assert candidate( "foobar", "bar" ) == "foobar"
	assert candidate('abc', 'a') == 'bc'
	assert candidate(u"abcd", u"abc") == u"d"
	assert candidate(u"abcd", u"abcd") == u""
def test_check():
	check(lremove)
