def score_single_word(corrs, word):
    """ Returns the best scored correction for a single word, given the lexicon learnt by candidate_generation.
     
     Args:
     corrs (dict): Dict containing the learnt normalisation lexicon.
     word (str): Word to be normalised.
     
     Returns:
     tuple (str, float): Best candidate and its score.
     """
	### Canonical solution below ###    
    return max(corrs[word], key=lambda x: x[1])

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'hello': [('hello', 0.0), ('world', 1.0), ('hello', 1.0)]},
    'hello'
) == ('world', 1.0)
	assert candidate(
    {"a": [("a", 0.9), ("a", 0.5)]},
    "a",
) == ("a", 0.9)
	assert candidate(
    {'hello': [('hello', 1.0), ('world', 1.0), ('hello', 1.0)]},
    'hello'
) == ('hello', 1.0)
	assert candidate(
    {'hello': [('hello', 1.0), ('world', 0.0), ('hello', 1.0)]},
    'hello'
) == ('hello', 1.0)
	assert candidate(
    {'a': [('a', 1), ('b', 0.2)], 'b': [('a', 0.2), ('b', 1)]}, 'a') == ('a', 1)
	assert candidate(
    {'hello': [('hello', 1.0), ('world', 0.0)]},
    'hello'
) == ('hello', 1.0)
	assert candidate(
    {'word': [('word', 1)]},
    'word',
) == ('word', 1)
	assert candidate(
    {'word': [('word', 1)]},
    'word'
) == ('word', 1)
	assert candidate(
    {'hello': [('hello', 0.0), ('world', 1.0)]},
    'hello'
) == ('world', 1.0)
	assert candidate(
    {"the": [("the", 1.0), ("a", 0.8)]}, "the"
) == ("the", 1.0)
	assert candidate(
    {"b": [("b", 0.9), ("a", 0.8), ("c", 0.7)]}, "b") == ("b", 0.9)
	assert candidate(
    {"london": [("london", 1.0), ("lond", 0.9), ("lon", 0.8)]},
    "london",
) == ("london", 1.0)
	assert candidate(
    {'a': [('a', 1), ('b', 0.2)], 'b': [('a', 0.2), ('b', 1)]}, 'b') == ('b', 1)
def test_check():
	check(score_single_word)
