def get_pgroupvolume(module, array):
    """ Return Protection Group Volume or None"""
	### Canonical solution below ###    
    try:
        pgroup = array.get_pgroup(module.params['name'])
        for volume in pgroup['volumes']:
            if volume == module.params['restore']:
                return volume
    except Exception:
        return None

### Unit tests below ###
def check(candidate):
	assert candidate(None, "test") is None
	assert candidate(None, {'volumes': ['test']}) is None
	assert candidate(None, None) is None
	assert candidate(None, {'volumes': ['test_volume']}) is None
	assert candidate(None, {'volumes': ['test1', 'test2', 'test']}) is None
	assert candidate(None, {'volumes': ['test1', 'test2']}) is None
	assert candidate(None, {'volumes': ['test1', 'test2', 'test3']}) is None
	assert candidate(
    {
        'name':'mypgroup',
       'restore':'myvolume3'
    },
    {
        'name':'mypgroup',
        'volumes': ['myvolume','myvolume2']
    }
) is None
	assert candidate(
    {'name': 'test','restore': 'volume3'},
    {'name': 'test', 'volumes': ['volume1', 'volume2']}) is None
	assert candidate(
    {
        'name':'mypgroup',
       'restore':'myvolume'
    },
    {
        'name':'mypgroup2',
        'volumes': ['myvolume','myvolume2']
    }
) is None
def test_check():
	check(get_pgroupvolume)
