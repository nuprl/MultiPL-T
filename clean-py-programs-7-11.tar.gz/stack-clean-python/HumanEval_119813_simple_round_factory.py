def simple_round_factory(tol):
    """ helper function for simple_round (a factory for simple_round functions)"""
	### Canonical solution below ###  
  def simple_round(*args, **kwds):
    argstype = type(args) 
    _args = list(args)
    _kwds = kwds.copy()
    for i,j in enumerate(args):
      if isinstance(j, float): _args[i] = round(j, tol) # don't round int
    for i,j in kwds.items():
      if isinstance(j, float): _kwds[i] = round(j, tol)
    return argstype(_args), _kwds
  return simple_round

### Unit tests below ###
def check(candidate):
	assert candidate(1)(1.23456, 2.3456, 3.4567) == (
  (1.2, 2.3, 3.5), {})
	assert candidate(2)(1.2345678901234567890123456789, a=1.2345678901234567890123456789, b=1.2345678901234567890123456789)
	assert candidate(2)(1.23456, 3.14159, 2.71828) == (
    (1.23, 3.14, 2.72), {})
	assert candidate(4)(1.23456, 2.3456, 3.4567) == (
  (1.2346, 2.3456, 3.4567), {})
	assert candidate(0)(1.23456, 2.3456, 3.4567) == (
  (1.0, 2.0, 3.0), {})
	assert candidate(3)(1.23456, 2.3456, 3.4567) == (
  (1.235, 2.346, 3.457), {})
def test_check():
	check(simple_round_factory)
