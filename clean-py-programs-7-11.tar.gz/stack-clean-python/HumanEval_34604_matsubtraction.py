def matsubtraction(A,B):
    """
    Subtracts matrix B from matrix A and returns difference
        :param A: The first matrix
        :param B: The second matrix
        :return: Matrix difference
    """
    ### Canonical solution below ###
    if(len(A)!=len(B) or len(A[0])!=len(B[0])):
        return "Subtraction not possible"
    for i in range(len(A)):
        for j in range(len(A[0])):
            A[i][j]=A[i][j]-B[i][j]
    return A


### Unit tests below ###
def check(candidate):
	assert candidate([[1,2,3],[4,5,6]],[[0,0,0],[0,0,0]]) == [[1,2,3],[4,5,6]]
	assert candidate([[0, 1, 2], [3, 4, 5], [6, 7, 8]],[[10, 12, 14], [16, 18, 20], [22, 24, 26]])==[[-10, -11, -12], [-13, -14, -15], [-16, -17, -18]]
	assert candidate([[1,2,3],[4,5,6]],[[3,4,5],[6,7,8]]) == [[-2,-2,-2],[-2,-2,-2]]
	assert candidate([[1,2],[3,4]],[[3,4],[5,6]]) == [[-2,-2],[-2,-2]]
def test_check():
	check(matsubtraction)
