def compare_existed_and_needed_objects(before, after, force):
    """
    Compares two dicts
    :param boolean force: param for deleting "ACTIVE" status objects
    (if needed)
    :param dict before: objects that we have in project
    :param dict after: objects that need to create
    :return: objects that need to create and dict with quantity objects that
    have to be deleted
    :rtype: tuple(dict, dict)
    """
    ### Canonical solution below ###
    possible_task = True
    to_create = dict((key, before.get(key))
                     for key in before if key in after)
    to_delete = {}
    for n_key in after:
        if possible_task:
            if n_key not in before:
                to_create.update({n_key: after.get(n_key)})
            else:
                active = before.get(n_key)["ACTIVE"]
                down = before.get(n_key)["DOWN"]
                before_quantity = active + down
                after_quantity = after.get(n_key)
                if after_quantity == before_quantity:
                    to_create.pop(n_key)
                elif after_quantity < before_quantity:
                    to_create.pop(n_key)
                    if not force:
                        if (down >= after_quantity - active and
                                after_quantity >= active):
                            to_delete.update(
                                {n_key: down - (after_quantity - active)})
                        else:
                            possible_task = False
                    else:
                        to_delete.update(
                            {n_key: before_quantity - after_quantity})
                else:
                    to_create[n_key] = after_quantity - before_quantity

    if possible_task:
        return to_create, to_delete
    return {}, {}


### Unit tests below ###
def check(candidate):
	assert candidate(
    {"key": {"ACTIVE": 1, "DOWN": 0}},
    {"key": 1},
    False) == ({}, {})
	assert candidate(
    {"A": {"ACTIVE": 3, "DOWN": 2}},
    {"A": 1},
    False) == ({}, {})
	assert candidate(
    {"1": {"ACTIVE": 5, "DOWN": 10}},
    {"1": 1},
    True) == ({}, {"1": 14})
	assert candidate(
    {},
    {"task_1": 1},
    False
) == ({
    "task_1": 1
}, {})
	assert candidate(
    {},
    {"test": 1},
    False
) == ({"test": 1}, {})
	assert candidate(
    {"a": {"ACTIVE": 1, "DOWN": 2}},
    {"a": 2},
    False
) == ({}, {"a": 1}), "2"
	assert candidate(
    {"a": {"ACTIVE": 1, "DOWN": 2}},
    {"a": 2},
    False
) == ({}, {"a": 1}), "8"
	assert candidate(
    {"key": {"ACTIVE": 1, "DOWN": 0}},
    {"key": 1},
    True) == ({}, {})
	assert candidate(
    {"A": {"ACTIVE": 3, "DOWN": 2}},
    {"A": 5},
    True) == ({}, {})
	assert candidate(
    {"A": {"ACTIVE": 3, "DOWN": 2}},
    {"A": 5},
    False) == ({}, {})
	assert candidate(
    {"a": {"ACTIVE": 1, "DOWN": 10}},
    {"a": 11},
    False
) == ({}, {})
	assert candidate(
    {"key1": {"ACTIVE": 1, "DOWN": 0}, "key2": {"ACTIVE": 0, "DOWN": 1}},
    {"key1": 1, "key2": 3}, False) == ({"key2": 2}, {})
	assert candidate(
    {"1": {"ACTIVE": 1, "DOWN": 1}},
    {"1": 1},
    False
) == (
    {},
    {"1": 1}
)
	assert candidate(
    {"a": {"ACTIVE": 1, "DOWN": 2}},
    {"a": 2},
    True
) == ({}, {"a": 1}), "5"
	assert candidate(
    before={"key": {"ACTIVE": 0, "DOWN": 0}},
    after={"key": 2},
    force=False
) == ({'key': 2}, {})
	assert candidate(
    {"a": {"ACTIVE": 1, "DOWN": 10}},
    {"a": 1},
    True
) == ({}, {"a": 10})
	assert candidate(
    {"A": {"ACTIVE": 3, "DOWN": 2}},
    {"A": 0},
    False) == ({}, {})
	assert candidate(
    {
        'a': {
            "ACTIVE": 1,
            "DOWN": 0
        }
    },
    {
        'a': 2
    },
    False
) == ({
    'a': 1
}, {})
	assert candidate(
    {"1": {"ACTIVE": 5, "DOWN": 10}},
    {"1": 15},
    False) == ({}, {})
	assert candidate(
    before={"key": {"ACTIVE": 1, "DOWN": 0}},
    after={"key": 2},
    force=False
) == ({'key': 1}, {})
	assert candidate(
    {"1": {"ACTIVE": 5, "DOWN": 10}},
    {"1": 5},
    True) == ({}, {"1": 10})
	assert candidate(
    {"key1": {"ACTIVE": 1, "DOWN": 0}, "key2": {"ACTIVE": 0, "DOWN": 1}},
    {"key1": 1, "key2": 4}, False) == ({"key2": 3}, {})
	assert candidate(
    {"A": {"ACTIVE": 3, "DOWN": 2}},
    {"A": 2},
    False) == ({}, {})
	assert candidate(
    {"key": {"ACTIVE": 1, "DOWN": 0}},
    {"key": 0},
    False) == ({}, {})
	assert candidate(
    {"a": {"ACTIVE": 1, "DOWN": 2}},
    {"a": 0},
    False
) == ({}, {})
	assert candidate(
    {"1": {"ACTIVE": 5, "DOWN": 10}},
    {"1": 1},
    False) == ({}, {})
	assert candidate(
    {"a": {"ACTIVE": 1, "DOWN": 2}},
    {"a": 2},
    True
) == ({}, {"a": 1})
def test_check():
	check(compare_existed_and_needed_objects)
