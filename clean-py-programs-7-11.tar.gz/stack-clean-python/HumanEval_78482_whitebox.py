def whitebox(f):
    """Decorator specifying that the TestCase/test method is a whitebox test"""
    ### Canonical solution below ###
    f.whitebox = True
    return f


### Unit tests below ###
def check(candidate):
	assert candidate(lambda: 1)() == 1
	assert candidate(lambda: None).candidate is True
	assert candidate(lambda: None).candidate
	assert not candidate(lambda: None)()
	assert candidate(lambda: None).candidate == True
	assert candidate(lambda: None).__dict__['candidate']
	assert candidate(lambda x: x)(4) == 4
	assert candidate(lambda x: x)
	assert not candidate(lambda: None).candidate == False
	assert candidate(lambda x: x).candidate == True
	assert candidate(lambda x: x+1)(1) == 2
	assert candidate(lambda x: x+1)(2) == 3
	assert candidate(lambda: None).__dict__['candidate'] == True
	assert candidate(lambda x: x)(5) == 5
	assert candidate(lambda x: x).candidate
def test_check():
	check(whitebox)
