def flatten_tree(root):
    """ get a flattened tree of the "paths" of all children of a tree of objects.
     used in sidenav
     """
	### Canonical solution below ###    
    ret = []
    if root["path"]: ret.append(root["path"])
    for child in root["children"]:
        ret = ret + flatten_tree(child)
    return ret

### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        "path": "a",
        "children": [
            {
                "path": "a/b",
                "children": [
                    {
                        "path": "a/b/c",
                        "children": [],
                    },
                ],
            },
            {
                "path": "a/d",
                "children": [],
            },
        ],
    }
) == ["a", "a/b", "a/b/c", "a/d"]
	assert candidate({"path": "a", "children": []}) == ["a"]
	assert candidate(
    {
        "path": "home",
        "children": [
            {"path": "home/foo", "children": []},
            {"path": "home/bar", "children": []},
        ],
    }
) == ["home", "home/foo", "home/bar"]
	assert candidate(
    {"path": "/",
     "children": [{"path": "/foo",
                   "children": [{"path": "/foo/bar",
                                 "children": []}]}]}) == ["/", "/foo", "/foo/bar"]
	assert candidate(
    {"path": "home", "children": [{"path": "home/foo", "children": []}]}
) == ["home", "home/foo"]
	assert candidate(
    {
        "path": "foo",
        "children": [
            {
                "path": "bar",
                "children": [
                    {
                        "path": "baz",
                        "children": []
                    }
                ]
            }
        ]
    }
) == ["foo", "bar", "baz"]
	assert candidate(
    {"path": "root", "children": [{"path": "root/child1", "children": [{"path": "root/child1/grandchild1", "children": [{"path": "root/child1/grandchild1/greatgrandchild1", "children": []}]}]}, {"path": "root/child2", "children": []}]}) == [
    "root", "root/child1", "root/child1/grandchild1", "root/child1/grandchild1/greatgrandchild1", "root/child2"]
	assert candidate(
    {"path": "root", "children": [{"path": "root/child1", "children": [{"path": "root/child1/grandchild1", "children": []}]}, {"path": "root/child2", "children": []}]}) == [
    "root", "root/child1", "root/child1/grandchild1", "root/child2"]
	assert candidate(
    {"path": "root", "children": [{"path": "root/child1", "children": []}, {"path": "root/child2", "children": []}]}) == [
    "root", "root/child1", "root/child2"]
	assert candidate(
    {'path': 'A', 'children': [
        {'path': 'B', 'children': [
            {'path': 'C', 'children': []},
            {'path': 'D', 'children': []},
        ]},
        {'path': 'E', 'children': []},
    ]}
) == ['A', 'B', 'C', 'D', 'E']
	assert candidate(
    {
        "path": "home",
        "children": [
            {
                "path": "home/foo",
                "children": [
                    {"path": "home/foo/bar", "children": []},
                    {"path": "home/foo/baz", "children": []},
                ],
            },
            {"path": "home/bar", "children": []},
        ],
    }
) == ["home", "home/foo", "home/foo/bar", "home/foo/baz", "home/bar"]
	assert candidate(
    {"path": "/", "children": [
        {"path": "/a", "children": [
            {"path": "/a/a", "children": []},
            {"path": "/a/b", "children": []},
        ]},
        {"path": "/b", "children": [
            {"path": "/b/a", "children": []},
            {"path": "/b/b", "children": []},
        ]},
    ]}) == ['/', '/a', '/a/a', '/a/b', '/b', '/b/a', '/b/b']
def test_check():
	check(flatten_tree)
