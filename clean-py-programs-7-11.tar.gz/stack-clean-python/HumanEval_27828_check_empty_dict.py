def check_empty_dict(GET_dict):
    """ 
     Returns True if the GET querstring contains on values, but it can contain
     empty keys.
     This is better than doing not bool(request.GET) as an empty key will return
     True
     """
	### Canonical solution below ###    
    empty = True
    for k, v in GET_dict.items():
        # Don't disable on p(age) or 'all' GET param
        if v and k != 'p' and k != 'all':
            empty = False
    return empty

### Unit tests below ###
def check(candidate):
	assert candidate(dict(all='1')) == True
	assert candidate(dict(foo=1, p=1)) == False
	assert candidate(dict(p=1, all='1', a='a', b='b', c='c', d='d', e='e')) == False
	assert candidate(dict(a=None)) == True
	assert candidate(dict(a='', b='1')) == False
	assert candidate({'p': 1}) == True
	assert candidate({'a': '1'}) is False
	assert candidate(dict(a='1', b='1', c='1', d='')) == False
	assert candidate(dict(a='1', b='1', c='1', d='1', e='')) == False
	assert candidate(dict(a=1, p=1)) == False
	assert candidate(dict(foo='')) == True
	assert candidate(dict(a='1', b='1', c='1', d='1')) == False
	assert candidate(dict(a='b', c='d', page='', all='', other='1', p='1', q='2')) == False
	assert candidate({'p': 1, 'q': 1}) == False
	assert candidate(dict(p=1, all=1)) is True
	assert candidate(dict(a=1, p=1)) is False
	assert candidate(dict(foo='bar', baz='')) == False
	assert candidate(dict(p=1, all='1', a='a', b='b')) == False
	assert candidate(dict(a='b', c='d', page='1', all='1', other='1')) == False
	assert candidate({'a': 'b', 'c': 'd', 'e': ''}) == False
	assert candidate(dict(a=1)) == False
	assert candidate({'a': 'b'}) == False
	assert not candidate(dict(p=1, page=1))
	assert candidate({'p': ''}) is True
	assert candidate(dict(p=1, all='1', a='a')) == False
	assert candidate(dict(p='')) is True
	assert candidate({'all': 1}) == True
	assert candidate(dict(a='1', b='')) == False
	assert candidate(dict(a=0, b=0, c=0, d=0, e=0, f=0, g=0)) == True
	assert candidate(dict(a='1', b='1', c='1', d='1', e='1', f='1', g='')) == False
	assert candidate(dict(a=1, b=1, c=1, p=1, all=1, d=1)) == False
	assert candidate(dict(a='1', b='1', c='1', d='1', e='1', f='')) == False
	assert not candidate(dict(p=1, page=1, all=1))
	assert candidate(dict(a=1, b=1, c=1, p=1)) == False
	assert candidate(dict(all='')) is True
	assert candidate(dict(p=1, all='1', a='a', b='b', c='c', d='d')) == False
	assert candidate(dict(foo=1)) == False
	assert candidate(dict(a='b', c='d', page='', all='', other='1', p='1')) == False
	assert candidate(dict(a='1', b='1', c='1')) == False
	assert candidate(dict(a='1', b='1')) == False
	assert candidate(dict(foo='bar')) == False
	assert candidate(dict(a='1', b='1', c='1', d='1', e='1', f='1')) == False
	assert candidate({'p': '', 'all': '', 'a': '1'}) is False
	assert candidate(dict(a=1, p=1, all=1, b=1)) == False
	assert candidate(dict(p=1, all=1, foo=1)) == False
	assert candidate({'a': '', 'c': ''}) == True
	assert candidate(dict(a=1, b=1, c=1, all=1)) == False
	assert candidate(dict(foo=1, p=1, all=1)) == False
	assert candidate(dict()) == True
	assert candidate(dict(a=1, b=1, c=1)) == False
	assert candidate({'p': '', 'all': ''}) is True
	assert candidate(dict(a='1', b='1', c='1', d='1', e='1')) == False
	assert candidate(dict(a=1)) is False
	assert candidate(dict(p='1', all='')) is True
	assert candidate(dict(a='b')) == False
	assert candidate({'p': '', 'all': '', 'a': ''}) is True
	assert candidate(dict(a=1, b=2, p=3)) == False
	assert candidate(dict(a=1, b=2, c=3)) == False
	assert candidate(dict(a=1, b=1, c=1, p=1, all=1)) == False
	assert candidate({'a': '1', 'b': ''}) is False
	assert candidate(dict(p=1))
	assert candidate(dict(p=1, all='1', a='a', b='b', c='c', d='d', e='e', f='f', g='g')) == False
	assert candidate(dict(a='b', c='d')) == False
	assert candidate(dict(p='1', all='1', x='', y='1')) is False
	assert candidate(dict(a=1, b=None)) == False
	assert candidate(dict(a=0, b=0, c=0, d=0, e=0, f=0)) == True
	assert candidate(dict(a='b', c='d', page='1')) == False
	assert candidate(dict(a='b')) is False
	assert candidate(dict(p='1', all='1')) == True
	assert candidate(dict(p='1', all='1', x='')) is True
	assert candidate(dict(all=1))
	assert candidate(dict(p='1', all='1', x='1')) is False
	assert candidate({'a': 'b', 'p': '1'}) == False
	assert candidate(dict(p=1, all='1', a='a', b='b', c='c')) == False
	assert candidate(dict(a='', p='')) is True
	assert candidate({'all': ''}) is True
	assert candidate({'p': '', 'all': '', 'a': '', 'b': ''}) is True
	assert candidate(dict(a='1', b='1', c='')) == False
	assert candidate(dict(foo='', bar='')) == True
	assert candidate(dict(a='')) is True
	assert candidate({'a': '', 'b': ''}) is True
	assert candidate(dict(a='b', c='d', page='1', all='1')) == False
	assert candidate(dict()) is True
	assert candidate({'p': '', 'all': '', 'a': '', 'b': '1'}) is False
	assert candidate(dict(p='1', all='1', x='1', y='1')) is False
	assert candidate({'p': 1, 'all': 1}) == True
	assert candidate(dict(a=1, b=2)) == False
	assert candidate(dict(a='', b='')) == True
	assert candidate(dict(a=1, b=0, c=0, d=0, e=0, f=0, g=0)) == False
	assert candidate(dict(a=1, p=1, all=1, b=1, c=1)) == False
	assert candidate(dict(p=1, all='1', a='a', b='b', c='c', d='d', e='e', f='f', g='g', h='h')) == False
	assert candidate(dict(p=1)) == True
	assert candidate(dict(a=1, p=1, all=1)) == False
	assert candidate({'a': 'b', 'c': ''}) == False
	assert candidate({}) is True
	assert candidate(dict())
	assert not candidate(dict(page=1, all=1))
	assert candidate(dict(a=None, b=None)) == True
	assert not candidate(dict(page=1))
	assert candidate(dict(a=1, all=1)) is False
	assert candidate(dict(p=1, all='1', a='a', b='b', c='c', d='d', e='e', f='f')) == False
def test_check():
	check(check_empty_dict)
