def combat(health, damage):
    """Take health and damage and return difference or zero."""
    ### Canonical solution below ###
    new_health = health - damage
    if new_health <= 0:
        return 0
    else:
        return new_health


### Unit tests below ###
def check(candidate):
	assert candidate(100, 10) == 90
	assert candidate(10, 9) == 1
	assert candidate(10, 6) == 4
	assert candidate(10, 2) == 8
	assert candidate(20, 20) == 0
	assert candidate(50, 50) == 0
	assert candidate(100, 20) == 80
	assert candidate(20, 100) == 0
	assert candidate(10, 15) == 0
	assert candidate(100, 90) == 10
	assert candidate(10, 10) == 0
	assert candidate(5, 5) == 0
	assert candidate(100, 50) == 50
	assert candidate(5, 10) == 0
	assert candidate(10, 0) == 10
	assert candidate(50, 100) == 0
	assert candidate(10, 3) == 7
	assert candidate(10, 11) == 0
	assert candidate(10, 5) == 5
	assert candidate(10, 1) == 9
	assert candidate(10, 20) == 0
	assert candidate(100, 100) == 0
	assert candidate(10, 4) == 6
	assert candidate(20, 10) == 10
	assert candidate(20, 5) == 15
	assert candidate(5, 2) == 3
def test_check():
	check(combat)
