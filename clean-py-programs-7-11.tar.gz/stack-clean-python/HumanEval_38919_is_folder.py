def is_folder(url):
	"""
	Checks whether a url points to a folder with resources
	"""
    ### Canonical solution below ###
	if 'mod/folder/' in url:
		return True
	else:
		return False


### Unit tests below ###
def check(candidate):
	assert candidate(u'mod/folder/view.php?id=11&abc=123#') == True
	assert candidate(
	'https://www.coursera.org/learn/machine-learning/lecture/l1g3t/machine-learning-recap-and-classification-trees/mod/folder/view.php?id=46'
	) == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/3') == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/9') == True
	assert candidate('http://www.example.com/mod/folder/view.php?id=21') == True
	assert not candidate(url='https://mooc1-1.chaoxing.com/visit/mod/resource/view.jsp?courseId=1332258&fid=5632826&uid=14595740&activeId=0&activeType=0&activeIndex=0&resId=10505013&resType=0')
	assert candidate('mod/folder/') == True
	assert candidate(url='http://www.math.uwaterloo.ca/~hwolkowi//matrixcookbook.pdf') == False
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&filter=author&sort=lastmodified&page=2&") == True
	assert candidate(
	"https://lms.fun-mooc.fr/course/view.php?id=53") == False
	assert not candidate(
	'https://www.coursera.org/learn/machine-learning/lecture/87dJ9/machine-learning-recap-and-getting-started/lecture/k4jU2/quiz-multiple-choice-questions/attempt/L4XqZ'
)
	assert candidate(u'mod/folder/view.php?id=11&abc#') == True
	assert candidate(
		'https://www.coursera.org/learn/machine-learning/lecture/2q5uV/classification-and-regression-trees-2/mod/folder/view.xml?id=223') == True
	assert candidate(u'mod/folder/view.php?id=11&abc=123&') == True
	assert candidate(r'https://www.coursera.org/learn/machine-learning/lecture/9m64N/unsupervised-learning') == False
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&filter=author&sort=lastmodified&page=2&perpage=100") == True
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&filter=author&sort=lastmodified&page=2") == True
	assert candidate(
	'https://www.coursera.org/learn/machine-learning/lecture/vZ5iC/feature-scaling-why-and-how'
	) == False
	assert not candidate(
	'https://web.archive.org/web/20171126182901/https://www.math.leidenuniv.nl/education/courses/mathematics-1/mathematics-1-course-description/lecture-notes/lecture-3/lecture-3-summary'), 'URL is not a folder'
	assert candidate(u'mod/folder/view.php?id=11#') == True
	assert candidate(r'http://www.math.uwaterloo.ca/~hwolkowi//matrixcookbook.pdf') == False
	assert candidate(url='http://www.columbia.edu/itc/mealac/math105/105/mod/folder/view.php?id=1086493') == True
	assert candidate(
	'https://www.edx.org/course/course-v1:MITx+8.033x+2T2019/block-v1:MITx+8.033x+2T2019+type@sequential+block@lec_11_03/block-v1:MITx+8.033x+2T2019+type@vertical+block@ch03-subsec-01'
) == False
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/1') == True
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&page=2&") == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/12') == True
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&filter=author&sort=lastmodified&") == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/8') == True
	assert candidate(url='https://mooc1-1.chaoxing.com/visit/mod/folder/view.jsp?courseId=1332258&fid=5632826&uid=14595740&activeId=0&activeType=0&activeIndex=0&resId=0&resType=0')
	assert candidate(url='https://mooc1-1.chaoxing.com/visit/mod/folder/view.jsp?courseId=1332258&fid=5632826&uid=14595740&activeId=0&activeType=0&activeIndex=0&resId=10505013&resType=0')
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&filter=author&sort=lastmodified") == True
	assert candidate(
		'https://www.coursera.org/learn/machine-learning/lecture/2q5uV/classification-and-regression-trees-2') == False
	assert candidate(u'mod/folder/view.php?id=11&abc=123&def=456&') == True
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&page=2") == True
	assert candidate('http://www.example.com/mod/folder/view.php?id=21&folderid=21') == True
	assert not candidate(
	'https://www.coursera.org/learn/machine-learning/lecture/87dJ9/machine-learning-recap-and-getting-started/lecture/k4jU2/quiz-multiple-choice-questions/attempt/L4XqZ/submit'
)
	assert candidate(
	'https://www.coursera.org/learn/machine-learning/lecture/l1g3t/machine-learning-recap-and-classification-trees/view.php?id=46'
	) == False
	assert candidate(url='http://www.columbia.edu/itc/mealac/math105/105/') == False
	assert candidate(r'https://www.coursera.org/learn/machine-learning/lecture/9m64N/unsupervised-learning/foo') == False
	assert candidate(u'mod/folder/view.php?id=11&abc=123&def=456#') == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/7') == True
	assert candidate(r'http://www.math.uwaterloo.ca/~hwolkowi//mod/folder/view.php?id=218') == True
	assert candidate(r'https://classroom.udacity.com/courses/ud547/lessons/1627462624/concepts/16274634790923/mod/folder/view.php') == True
	assert candidate(u'mod/folder/view.php?id=11&abc') == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/10') == True
	assert candidate( 'https://www.class-central.com/mod/folder/view.php?id=1491&foo=bar') == True
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327") == True
	assert candidate(
	'https://www.coursera.org/learn/machine-learning/lecture/l1g3t/machine-learning-recap-and-classification-trees'
	) == False
	assert candidate(
	"http://localhost:8000/mod/folder/view.php?id=1327&") == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/5') == True
	assert candidate(
	'https://www.edx.org/course/introduction-computer-science-harvardx-cs50x/discussion') == False
	assert not candidate(
	'https://www.coursera.org/learn/machine-learning/lecture/87dJ9/machine-learning-recap-and-getting-started/lecture/k4jU2/quiz-multiple-choice-questions/attempt/L4XqZ/review'
)
	assert candidate(url='http://www.math.uwaterloo.ca/~hwolkowi//mod/folder/view.php?id=68') == True
	assert candidate(u'mod/folder/view.php?id=11') == True
	assert candidate(
	"https://lms.fun-mooc.fr/mod/folder/view.php?id=214") == True
	assert candidate(u'mod/folder/view.php?id=11&') == True
	assert candidate(
	'https://www.edx.org/course/course-v1:MITx+8.033x+2T2019/block-v1:MITx+8.033x+2T2019+type@sequential+block@lec_11_01'
) == False
	assert candidate(
	'https://www.edx.org/course/course-v1:MITx+8.033x+2T2019/block-v1:MITx+8.033x+2T2019+type@sequential+block@lec_11_02/block-v1:MITx+8.033x+2T2019+type@vertical+block@ch02-subsec-01'
) == False
	assert candidate(url='http://www.moodle.com/mod/folder/view.php?id=123456') == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/4') == True
	assert candidate(u'mod/folder/view.php?id=11&abc=123&def#') == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/6') == True
	assert candidate(r'https://classroom.udacity.com/courses/ud547/lessons/1627462624/concepts/16274634790923') == False
	assert candidate( 'https://www.class-central.com/mod/folder/view.php?id=1491') == True
	assert candidate(
	'https://www.edx.org/course/introduction-computer-science-harvardx-cs50x') == False
	assert candidate(url='https://www.coursera.org/learn/python-data-analysis/lecture/jB5sX/python-basics') == False
	assert candidate(u'mod/folder/view.php?id=11&abc=123&def=456') == True
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/2') == True
	assert candidate(u'mod/folder/view.php?id=11&abc=123&def') == True
	assert candidate(u'http://localhost:8080/mod/folder/view.php?id=23388') == True
	assert candidate( 'https://www.coursera.org/learn/machine-learning/lecture/e6830/regularized-linear-regression/mod/folder/view.html' ) == True
	assert candidate(u'mod/folder/view.php?id=11&abc=123') == True
	assert candidate(
	'https://www.edx.org/course/introduction-computer-science-harvardx-cs50x/discussion?forum=1') == False
	assert candidate( 'https://www.coursera.org/learn/machine-learning/lecture/e6830/regularized-linear-regression' ) == False
	assert candidate(
	'http://www.math.ubc.ca/~cass/research/mod/folder/11') == True
def test_check():
	check(is_folder)
