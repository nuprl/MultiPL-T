def cooperating_rating(cooperation, nplayers, turns, repetitions):
    """
    A list of cooperation ratings for each player

    Parameters
    ----------
    cooperation : list
        The cooperation matrix
    nplayers : integer
        The number of players in the tournament.
    turns : integer
        The number of turns in each round robin.
    repetitions : integer
        The number of repetitions in the tournament.

    Returns
    -------
    list
        a list of cooperation rates ordered by player index
    """
    ### Canonical solution below ###
    total_turns = turns * repetitions * nplayers
    return [1.0 * sum(row) / total_turns for row in cooperation]


### Unit tests below ###
def check(candidate):
	assert candidate(
    [[0, 0, 0], [0, 0, 0], [0, 0, 0]], 3, 3, 1) == [0.0, 0.0, 0.0]
	assert candidate(
    [[0, 0, 0], [0, 0, 0], [0, 0, 0]], 3, 3, 2) == [0.0, 0.0, 0.0]
	assert candidate(
    [[0,0,0], [0,0,0], [0,0,0]], 3, 1, 1) == [0.0, 0.0, 0.0]
	assert candidate(
    [[1,1,1,1],[1,1,1,1],[1,1,1,1],[1,1,1,1]], 4, 1, 1) == [1.0, 1.0, 1.0, 1.0]
	assert candidate(
    [[1,1,1], [1,1,1], [1,1,1]], 3, 1, 1) == [1.0, 1.0, 1.0]
def test_check():
	check(cooperating_rating)
