def trianglePoints(x, z, h, w):
    """ 
     Takes the geometric parameters of the triangle and returns the position of the 3 points of the triagles. Format : [[x1, y1, z1], [x2, y2, z2], [x3, y3, z3]]
     """
	### Canonical solution below ###    
    P1 = [x,0,z+h]
    P2 = [x,-w/2,z]
    P3 = [x,w/2,z]
    return [P1,P2,P3]

### Unit tests below ###
def check(candidate):
	assert candidate(1,0,1,2) == [[1, 0, 1], [1, -1, 0], [1, 1, 0]]
	assert candidate(1,0,1,1) == [[1, 0, 1], [1, -0.5, 0], [1, 0.5, 0]]
	assert candidate(0,0,1,2) == [[0, 0, 1], [0, -1, 0], [0, 1, 0]]
	assert candidate(0,0,1,1) == [[0, 0, 1], [0, -0.5, 0], [0, 0.5, 0]]
	assert candidate(0,0,2,1) == [[0, 0, 2], [0, -0.5, 0], [0, 0.5, 0]]
def test_check():
	check(trianglePoints)
