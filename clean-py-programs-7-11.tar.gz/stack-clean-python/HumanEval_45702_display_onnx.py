def display_onnx(model_onnx, max_length=1000):
    """ 
     Returns a shortened string of the model.
     
     @param      model_onnx      onnx model
     @param      max_length      maximal string length
     @return                     string
     """
	### Canonical solution below ###    
    res = str(model_onnx)
    if max_length is None or len(res) <= max_length:
        return res
    begin = res[:max_length // 2]
    end = res[-max_length // 2:]
    return "\n".join([begin, '[...]', end])

### Unit tests below ###
def check(candidate):
	assert candidate("a\nb") == "a\nb"
	assert candidate("a\nb\nc\nd", 14) == "a\nb\nc\nd"
	assert candidate("a") == "a"
	assert candidate(b"string") == "b'string'"
	assert candidate("") == ""
	assert candidate("a\nb\nc\nd", 16) == "a\nb\nc\nd"
	assert candidate(1) == '1'
	assert candidate(set([1, 2])) == "{1, 2}"
	assert candidate(None, 1000) == 'None'
	assert candidate(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
	assert candidate(None) == "None"
	assert candidate({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
	assert candidate("a\nb\nc\nd", 15) == "a\nb\nc\nd"
	assert candidate(None) == 'None'
	assert candidate([1, 2]) == '[1, 2]'
	assert candidate("a\nb\nc\nd", 13) == "a\nb\nc\nd"
	assert candidate(1.2) == "1.2"
	assert candidate(dict(a=1)) == "{'a': 1}"
	assert candidate(tuple([1, 2])) == "(1, 2)"
	assert candidate(False) == "False"
	assert candidate(1) == "1"
	assert candidate(1.2) == '1.2'
	assert candidate(True) == "True"
	assert candidate("a\nb\nc\nd", 12) == "a\nb\nc\nd"
	assert candidate(1.1) == "1.1"
	assert candidate(b'a', 1000) == 'b\'a\''
	assert candidate(3) == "3"
def test_check():
	check(display_onnx)
