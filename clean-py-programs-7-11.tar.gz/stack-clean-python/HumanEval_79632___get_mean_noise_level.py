def __get_mean_noise_level(noises: dict, length: float) -> float:
    """Returns a mean noise level based on noise exposures weighted by the contaminated distances
    to different noise levels.
    """
    ### Canonical solution below ###
    # estimate mean dB of 5 dB range to be min dB + 2.5 dB
    sum_db = sum([(db + 2.5) * length for db, length in noises.items()])
    mean_db = sum_db/length
    return round(mean_db, 1)


### Unit tests below ###
def check(candidate):
	assert candidate(noises={}, length=1) == 0
	assert candidate(dict(), 2) == 0
	assert candidate(noises={0.0: 0.0}, length=1.0) == 0.0
	assert candidate(noises={}, length=1.0) == 0.0
	assert candidate(noises={}, length=10) == 0
	assert candidate(dict(), 1000) == 0
	assert candidate(dict(), 1) == 0
def test_check():
	check(__get_mean_noise_level)
