def unmap_tuples(obj):
    """
    Given a Python object deserialized from JSON, converts any dictionaries that
    represent tuples back to Python tuples. Dictionaries are considered to be
    tuples if they either contain a key `@type` with the value `tuple`, or if
    they have a key `item1`.
    """
    ### Canonical solution below ###
    if isinstance(obj, dict):
        # Does this dict represent a tuple?
        if obj.get('@type', None) in ('tuple', '@tuple') or 'Item1' in obj:
            values = []
            while True:
                item = f"Item{len(values) + 1}"
                if item in obj:
                    values.append(unmap_tuples(obj[item]))
                else:
                    break
            return tuple(values)
        # Since this is a plain dict, unmap its values and we're good.
        return {
            key: unmap_tuples(value)
            for key, value in obj.items()
        }

    elif isinstance(obj, list):
        return [unmap_tuples(value) for value in obj]

    else:
        return obj


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'@type': '@tuple', 'Item1': 1, 'Item2': 2}
) == (1, 2)
	assert candidate([None, True, False, 1, 1.2, 1.2 + 2j, "foo"]) == [None, True, False, 1, 1.2, 1.2 + 2j, "foo"]
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 'hello',
    }
) == ('hello',)
	assert candidate(
    {
        'Item1': 42,
        'Item2': 100,
        '@type': 'tuple',
        'extra':'stuff',
    }
) == (42, 100)
	assert candidate(
    {'@type': 'tuple', 'Item1': [1, 2, 3], 'Item2': [4, 5, 6], 'Item3': 7}
) == ([1, 2, 3], [4, 5, 6], 7)
	assert candidate(
    {
        'Item1': 1,
        'Item2': {
            'Item1': 2,
            'Item2': 3,
            'Item3': 4,
        },
        'Item3': 5,
    }
) == (
    1,
    (2, 3, 4),
    5,
)
	assert candidate(
    {'Item1': {'Item1': 1, 'Item2': 2}, 'Item2': 3}
) == ((1, 2), 3)
	assert candidate(
    {
        "@type": "tuple",
        "Item1": {
            "@type": "tuple",
            "Item1": "A",
            "Item2": "B"
        },
        "Item2": {
            "@type": "tuple",
            "Item1": "C",
            "Item2": "D"
        }
    }
) == (
    ("A", "B"),
    ("C", "D")
)
	assert candidate(42) == 42
	assert candidate(
    {
        'Item1': 42,
        'Item2': 100,
        '@type': 'tuple',
        'Item3': 1000,
    }
) == (42, 100, 1000)
	assert candidate(
    {'@type': 'tuple', 'Item1': 'hello', 'Item2': 'world'}
) == ('hello', 'world')
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': 3}
) == (1, 2, 3)
	assert candidate(
    {'@type': 'tuple', 'Item1': [1, 2, 3], 'Item2': 4, 'Item3': 5}
) == ([1, 2, 3], 4, 5)
	assert candidate(False) == False
	assert candidate(
    {'Item1': 1, 'Item2': 2, 'Item3': 3}) == (1, 2, 3)
	assert candidate({"a": None, "b": True, "c": False, "d": 1, "e": 1.2, "f": 1.2 + 2j, "g": "foo"}) == {"a": None, "b": True, "c": False, "d": 1, "e": 1.2, "f": 1.2 + 2j, "g": "foo"}
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 1,
        'Item2': 2,
        'Item3': 3,
    }
) == (1, 2, 3)
	assert candidate({"@type": "tuple", "Item1": 1, "Item2": 2, "Item3": 3}) == (1, 2, 3)
	assert candidate(
    {'@type': 'tuple', 'Item1': {'Item1': 1, 'Item2': 2}, 'Item2': {'Item1': 3, 'Item2': 4}}
) == ((1, 2), (3, 4))
	assert candidate(1.0) == 1.0
	assert candidate(1.2 + 2j) == 1.2 + 2j
	assert candidate(
    {
        'Item1': 1,
        'Item2': {
            'Item1': 2,
            'Item2': 3,
            'Item3': 4,
        },
    }
) == (
    1,
    (2, 3, 4),
)
	assert candidate(
    {
        'Item1': 'a',
        'Item2': 'b',
        'Item3': 'c',
    }
) == ('a', 'b', 'c')
	assert candidate(['abc']) == ['abc']
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': {'Item1': 3}}
) == (1, 2, (3,))
	assert candidate(
    {
        "Item1": 1,
        "Item2": 2,
        "Item3": {
            "@type": "tuple",
            "Item1": 3,
            "Item2": 4,
        },
    }
) == (1, 2, (3, 4))
	assert candidate(
    {
        '@type': '@tuple',
        'Item1': 'foo',
        'Item2': 'bar',
    }
) == ('foo', 'bar')
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 'hello',
        'Item2': 'world',
    }
) == ('hello', 'world')
	assert candidate({
    'a': 1,
    'b': {
        'c': 2,
        'd': {
            '@type': 'tuple',
            'Item1': 'hello',
            'Item2': 3
        }
    }
}) == {
    'a': 1,
    'b': {
        'c': 2,
        'd': ('hello', 3)
    }
}
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': {
            '@type': 'tuple',
            'Item1': 1,
            'Item2': 2,
        },
        'Item2': 3,
    }
) == ((1, 2), 3)
	assert candidate({
    "@type": "tuple",
    "Item1": None,
    "Item2": 1,
    "Item3": True,
    "Item4": False,
    "Item5": "hello",
    "Item6": [None, 1, True, False, "hello"]
}) == (None, 1, True, False, "hello", [None, 1, True, False, "hello"])
	assert candidate(
    [
        {
            '@type': 'tuple',
            'Item1': 1,
            'Item2': 2,
        },
        3,
    ]
) == [(1, 2), 3]
	assert candidate(1) == 1
	assert candidate(
    {'Item1': 1, 'Item2': 2, 'Item3': {'Item1': 3, 'Item2': 4}}
) == (1, 2, (3, 4))
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': {'Item1': 3, 'Item2': {'Item1': 4, 'Item2': 5}}}
) == (1, 2, (3, (4, 5)))
	assert candidate({
    "a": None,
    "b": 1,
    "c": True,
    "d": False,
    "e": "hello",
    "f": [None, 1, True, False, "hello"]
}) == {
    "a": None,
    "b": 1,
    "c": True,
    "d": False,
    "e": "hello",
    "f": [None, 1, True, False, "hello"]
}
	assert candidate([None, 1, True, False, "hello"]) == [None, 1, True, False, "hello"]
	assert candidate(
    {
        'Item1': 42,
        'Item2': 100,
        '@type': 'tuple',
        'Item3': 1000,
        'Item4': {
            'Item1': 42,
            'Item2': 100,
            '@type': 'tuple',
            'Item3': 1000,
        },
    }
) == (42, 100, 1000, (42, 100, 1000))
	assert candidate(
    {'Item1': 1, 'Item2': 2, 'Item3': {'Item1': 3, 'Item2': 4, 'Item3': 5}}
) == (1, 2, (3, 4, 5))
	assert candidate(
    {'foo': [{'@type': 'tuple', 'Item1': 1, 'Item2': 2}, {'@type': 'tuple', 'Item1': 3, 'Item2': 4}]}
) == {'foo': [(1, 2), (3, 4)]}
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': {
            '@type': 'tuple',
            'Item1': 1,
            'Item2': 2,
            'Item3': 3,
        },
        'Item2': {
            '@type': 'tuple',
            'Item1': 4,
            'Item2': 5,
            'Item3': 6,
        },
    }
) == ((1, 2, 3), (4, 5, 6))
	assert candidate(False) is False
	assert candidate({"@type": "tuple", "Item1": 1, "Item2": 2}) == (1, 2)
	assert candidate({"@type": "tuple", "Item1": 1, "Item2": 2, "Item3": {"@type": "tuple", "Item1": 1, "Item2": 2, "Item3": 3}}) == (1, 2, (1, 2, 3))
	assert candidate(
    {'@type': 'tuple', 'Item1': 'a', 'Item2': 'b', 'Item3': {'@type': 'tuple', 'Item1': 'c', 'Item2': 'd'}}
) == ('a', 'b', ('c', 'd'))
	assert candidate(candidate(
    {
        '@type': 'tuple',
        'Item1': {
            '@type': 'tuple',
            'Item1': 'foo',
            'Item2': 'bar',
        },
        'Item2': 'baz',
    }
)) == (('foo', 'bar'), 'baz')
	assert candidate({"foo": "bar"}) == {"foo": "bar"}
	assert candidate(
    {'Item1': 1, 'Item2': {'Item1': 2, 'Item2': 3}}) == (1, (2, 3))
	assert candidate(
    {
        "Item1": {
            "@type": "tuple",
            "Item1": "A",
            "Item2": "B"
        },
        "Item2": "C"
    }
) == (
    ("A", "B"),
    "C"
)
	assert candidate(1.2) == 1.2
	assert candidate(
    {'foo': [{'@type': 'tuple', 'Item1': 1, 'Item2': 2}, {'bar': [{'@type': 'tuple', 'Item1': 3, 'Item2': 4}]}]}
) == {'foo': [(1, 2), {'bar': [(3, 4)]}]}
	assert candidate(None) == None
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': {
            '@type': 'tuple',
            'Item1': 1,
            'Item2': 2,
        },
        'Item2': 3,
    }
) == (
    (1, 2),
    3,
)
	assert candidate(
    {
        "@type": "tuple",
        "Item1": {
            "@type": "tuple",
            "Item1": "A",
            "Item2": "B"
        }
    }
) == (
    ("A", "B"),
)
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': {
            '@type': 'tuple',
            'Item1': 1,
            'Item2': 2,
            'Item3': 3,
        },
        'Item2': {
            '@type': 'tuple',
            'Item1': 4,
            'Item2': 5,
            'Item3': 6,
        },
        'Item3': 7,
    }
) == ((1, 2, 3), (4, 5, 6), 7)
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': {
            '@type': 'tuple',
            'Item1': 'foo',
            'Item2': 'bar',
        },
        'Item2': 'baz',
    }
) == (('foo', 'bar'), 'baz')
	assert candidate("hello") == "hello"
	assert candidate(
    {
        'a': 1,
        'b': 'abc',
        'c': [1, 2, 3],
    }
) == {'a': 1, 'b': 'abc', 'c': [1, 2, 3]}
	assert candidate('abc') == 'abc'
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 1,
    }
) == (1,)
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 1,
        'Item2': 2,
        'Item3': 3,
        'Item4': 4,
        'Item5': 5,
    }
) == (1, 2, 3, 4, 5)
	assert candidate({"@type": "tuple", "Item1": 1, "Item2": 2, "Item3": {"@type": "tuple", "Item1": 1, "Item2": 2, "Item3": 3, "Item4": 4}}) == (1, 2, (1, 2, 3, 4))
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 'foo',
        'Item2': 'bar',
    }
) == ('foo', 'bar')
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 1,
        'Item2': 2,
    }
) == (1, 2)
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2}
) == (1, 2)
	assert candidate(
    {'@type': 'tuple', 'Item1': [1, 2, 3], 'Item2': 4, 'Item3': [5, 6, 7]}
) == ([1, 2, 3], 4, [5, 6, 7])
	assert candidate({"@type": "tuple", "@items": []}) == ()
	assert candidate(
    {'Item1': 1, 'Item2': 2, 'Item3': 3}
) == (1, 2, 3)
	assert candidate(True) is True
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 'a',
        'Item2': 'b',
        'Item3': 'c',
    }
) == ('a', 'b', 'c')
	assert candidate({
    '@type': 'tuple',
    'Item1': 'hello',
    'Item2': 3
}) == ('hello', 3)
	assert candidate(
    {'foo': {'@type': 'tuple', 'Item1': 1, 'Item2': 2}}
) == {'foo': (1, 2)}
	assert candidate(
    {
        'Item1': 1,
        'Item2': 2,
        'Item3': 3,
    }
) == (
    1,
    2,
    3,
)
	assert candidate(
    {
        'Item1': 'foo',
        'Item2': 'bar',
    }
) == ('foo', 'bar')
	assert candidate({1: 2, 3: 4}) == {1: 2, 3: 4}
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': 3, 'Item4': 4}
) == (1, 2, 3, 4)
	assert candidate(
    [1, {'Item1': 2, 'Item2': 3}]) == [1, (2, 3)]
	assert candidate(
    {
        "Item1": {
            "Item1": "A",
            "Item2": "B"
        },
        "Item2": {
            "Item1": "C",
            "Item2": "D"
        }
    }
) == (
    ("A", "B"),
    ("C", "D")
)
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': {'Item1': 3, 'Item2': {'Item1': 4}}}
) == (1, 2, (3, (4,)))
	assert candidate(
    {'@type': 'tuple', 'Item1': [1, 2, 3], 'Item2': [4, 5, 6], 'Item3': [7, 8, 9]}
) == ([1, 2, 3], [4, 5, 6], [7, 8, 9])
	assert candidate(
    {
        "@type": "tuple",
        "Item1": "A",
        "Item2": "B"
    }
) == ("A", "B")
	assert candidate(
    {'@type': 'tuple', 'Item1': {'Item1': 1, 'Item2': 2}, 'Item2': 3}
) == ((1, 2), 3)
	assert candidate(
    {
        "Item1": "A",
        "Item2": "B"
    }
) == ("A", "B")
	assert candidate(
    {'foo': [{'@type': 'tuple', 'Item1': 1, 'Item2': 2}, {'bar': {'@type': 'tuple', 'Item1': 3, 'Item2': 4}}]}
) == {'foo': [(1, 2), {'bar': (3, 4)}]}
	assert candidate(
    {'foo': [{'@type': 'tuple', 'Item1': 1, 'Item2': 2}]}
) == {'foo': [(1, 2)]}
	assert candidate(42.0) == 42.0
	assert candidate(
    {'Item1': 1, 'Item2': 2}
) == (1, 2)
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 'abc',
        'Item2': 123,
        'Item3': {
            '@type': 'tuple',
            'Item1': 'def',
            'Item2': 456
        },
        'Item4': {
            'Item1': 'ghi',
            'Item2': 789
        }
    }
) == (
    'abc',
    123,
    ('def', 456),
    ('ghi', 789),
)
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': {'Item1': 3, 'Item2': 4}}
) == (1, 2, (3, 4))
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': {
            '@type': 'tuple',
            'Item1': 1,
            'Item2': 2,
            'Item3': 3,
        },
    }
) == ((1, 2, 3),)
	assert candidate(
    [1, 2, 3, {'Item1': 4, 'Item2': 5, 'Item3': 6}]
) == [1, 2, 3, (4, 5, 6)]
	assert candidate(True) == True
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': 3}) == (1, 2, 3)
	assert candidate(
    {
        'Item1': 1,
        'Item2': 2,
        'Item3': 3,
    }
) == (1, 2, 3)
	assert candidate(
    {'@type': 'tuple', 'Item1': 1, 'Item2': 2, 'Item3': 3, 'Item4': 4, 'Item5': 5}
) == (1, 2, 3, 4, 5)
	assert candidate(
    {
        '@type': 'tuple',
    }
) == ()
	assert candidate({"@type": "tuple", "Item1": 1, "Item2": 2, "Item3": [1, 2, 3]}) == (1, 2, [1, 2, 3])
	assert candidate("foo") == "foo"
	assert candidate(None) is None
	assert candidate([
    {'Item1': 1, 'Item2': 2},
    {'Item1': 3, 'Item2': 4}
]) == [(1, 2), (3, 4)]
	assert candidate(
    {'@type': 'tuple', 'Item1': 1}
) == (1,)
	assert candidate(
    {
        'item1': 1,
        'item2': 2,
    }
) == {
    'item1': 1,
    'item2': 2,
}
	assert candidate(
    {
        'Item1': 42,
        'Item2': 100,
        '@type': 'tuple',
    }
) == (42, 100)
	assert candidate(
    {
        '@type': 'tuple',
        'Item1': 1,
        'Item2': {
            '@type': 'tuple',
            'Item1': 2,
            'Item2': 3,
            'Item3': 4,
        },
        'Item3': 5,
    }
) == (
    1,
    (2, 3, 4),
    5,
)
	assert candidate(
    {'Item1': {'Item1': 1, 'Item2': 2}, 'Item2': {'Item1': 3, 'Item2': 4}}
) == ((1, 2), (3, 4))
def test_check():
	check(unmap_tuples)
