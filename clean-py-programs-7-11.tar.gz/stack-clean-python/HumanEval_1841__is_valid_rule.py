def _is_valid_rule(rule: dict, allow_free_standing: bool) -> bool:
    """ This method validates if an alert rule is well formed.
     
     Args:
     rule: A dictionary containing an alert rule definition
     
     Returns:
     True if the alert rule is well formed; False otherwise.
     """
	### Canonical solution below ###    
    mandatory = ["alert", "expr"]
    if any(field not in rule for field in mandatory):
        return False

    if not allow_free_standing and "%%juju_topology%%" not in rule["expr"]:
        return False

    return True

### Unit tests below ###
def check(candidate):
	assert candidate(
    {"alert": "foo", "expr": "bar"},
    allow_free_standing=True
), "Should return True when free-standing alert rule is well formed"
	assert candidate(
    {"alert": "InstanceDown", "expr": "up{job='juju-test-charm'} == 0"},
    allow_free_standing=True,
)
	assert not candidate(
    {"alert": "TestAlert", "expr": "sum(up) by (juju_model, juju_application) > 0"},
    False
)
	assert not candidate(
    {"expr": "sum(up) by (juju_model)"},
    allow_free_standing=False
)
	assert not candidate(
    {
        "expr": "up == 0",
    },
    allow_free_standing=False,
)
	assert not candidate(
    {
        "alert": "TestAlert",
    },
    True,
)
	assert not candidate(
    {
        "expr": "metric1 > 10",
    },
    True,
)
	assert not candidate(
    {"alert": "TestRule", "expr": "histogram_quantile(0.9, sum(rate(juju_model_dummy_test_metric_total[5m])) by (le)) > 1"},
    allow_free_standing=None,
)
	assert candidate(
    {"alert": "HighRequestLatency", "expr": "histogram_quantile(0.99, sum(rate(request_duration_seconds_bucket[5m])) by (le)) > 0.5"},
    True
)
	assert not candidate(
    {
        "alert": "InstanceDown",
        "expr": "up == 0",
        "for": "1m",
        "labels": {"severity": "page"},
    },
    allow_free_standing=False,
)
	assert candidate(
    {"alert": "TestRule", "expr": "%%juju_topology%% up == 1"},
    allow_free_standing=False
) == True
	assert not candidate(
    {"alert": "Test", "expr": "sum(up) by (juju_model)"},
    allow_free_standing=False
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_sum[2m])) by (job) "
        "> 0.5",
    },
    allow_free_standing=True,
)
	assert not candidate(
    {
        "alert": "InstanceDown",
        "expr": 'up{job="juju"} == 0'
    },
    False
)
	assert candidate(
    {"alert": "test_alert", "expr": "test_expr"},
    True
)
	assert not candidate(
    {
        "alert": "InstanceDown",
        "expr": 'up{job="juju"} == 0',
        "for": "0m",
        "labels": {
            "severity": "page"
        }
    },
    False
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_count{job=~\"myjob.*\"}[1m])) by (le) > 0.5",
        "for": "10m",
        "labels": {"severity": "page"},
    },
    True,
)
	assert candidate(
    {"alert": "test_alert", "expr": "test_expr", "for": "test_for"},
    True
)
	assert candidate(
    {"alert": "some alert", "expr": "%%juju_topology%%"}, allow_free_standing=False
)
	assert not candidate(
    {
        "expr": "metric1 > 10",
    },
    False,
)
	assert candidate(
    {"alert": "some alert", "expr": "some expr"}, allow_free_standing=True
)
	assert candidate(
    {"alert": "HighRequestLatency", "expr": "job:request_latency_seconds:mean5m{%%juju_topology%%} > 0.5"},
    True,
)
	assert candidate(
    {
        "alert": "InstanceDown",
        "expr": "up == 0",
    },
    True
)
	assert candidate(
    {"alert": "TestRule", "expr": "up == 1"},
    allow_free_standing=False
) == False
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_sum[1m])) by (job) "
        "> 0.5",
    },
    allow_free_standing=True,
)
	assert not candidate(
    {
        "alert": "InstanceDown",
    },
    allow_free_standing=False,
)
	assert not candidate(
    {"alert": "HighRequestLatency", "expr": "sum(rate(request_latency_seconds_count[1m])) by (job) > 0.5"},
    allow_free_standing=False
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": 'job:request_latency_seconds:mean5m{%%juju_topology%%} > 0.5',
    },
    allow_free_standing=True,
)
	assert not candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_sum[1m])) by (job) "
        "> 0.5",
        "for": "10s",
    },
    False,
)
	assert candidate(
    {"alert": "test_alert", "expr": "%%juju_topology%%"},
    True
)
	assert not candidate(
    {
        "alert": "TestAlert",
        "expr": "metric1 > 10",
    },
    False,
)
	assert candidate(
    {"alert": "TestRule", "expr": "up == 1"},
    allow_free_standing=True
) == True
	assert not candidate(
    {"alert": "foo", "expr": "bar"},
    allow_free_standing=False
), "Should return False when free-standing alert rule is not well formed"
	assert not candidate(
    {"alert": "Free disk space", "expr": "vector(1)\n  /\n  scalar(1)"},
    allow_free_standing=False,
)
	assert not candidate(
    {
        "alert": "TestAlert",
        "expr": "metric1 > 10",
        "for": "1m",
    },
    False,
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "job:request_latency_seconds:mean5m{%%juju_topology%%} > 0.5",
    },
    True,
)
	assert not candidate(
    {"expr": "job:request_latency_seconds:mean5m{%%juju_topology%%} > 0.5"},
    True,
)
	assert candidate(
    {"alert": "foo", "expr": "%%juju_topology%%"},
    allow_free_standing=True
), "Should return True when alert rule with topology is well formed"
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_sum[1m])) by (job) "
        "> 0.5",
    },
    True,
)
	assert not candidate(
    {
        "expr": "metric1 > 10",
        "for": "1m",
    },
    False,
)
	assert not candidate({"alert": "some alert"}, allow_free_standing=False)
	assert candidate(
    {"alert": "TestAlert", "expr": "sum(up) by (juju_model, juju_application) > 0"},
    True
)
	assert candidate(
    {
        "alert": "TestAlert",
        "expr": "metric1 > 10",
        "for": "1m",
    },
    True,
)
	assert not candidate(
    {"alert": "InstanceDown", "expr": "up{job='juju-test-charm'} == 0"},
    allow_free_standing=False,
)
	assert not candidate(
    {
        "alert": "InstanceDown",
        "expr": 'up{job="juju"} == 0',
        "for": "0m"
    },
    False
)
	assert not candidate(
    {"alert": "HighRequestLatency"},
    True,
)
	assert candidate(
    {"alert": "test_alert", "expr": "avg(up) < 1"}, True
)
	assert not candidate(
    {
        "expr": "sum(rate(request_latency_seconds_count{job=~\"myjob.*\"}[1m])) by (le) > 0.5",
    },
    True,
)
	assert candidate(
    {"alert": "CPU_Usage", "expr": "avg(last_10m):avg:system.cpu.user{%%juju_topology%%} > 90"},
    True,
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_count{job=~\"myjob.*\"}[1m])) by (le) > 0.5",
    },
    True,
)
	assert candidate(
    {"alert": "Free disk space", "expr": "vector(1)\n  /\n  scalar(1)"},
    allow_free_standing=True,
)
	assert not candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_sum[1m])) by (job) "
        "> 0.5",
        "for": "2m",
    },
    allow_free_standing=False,
)
	assert not candidate(
    {"alert": "test_alert"},
    True
)
	assert not candidate(
    {},
    True,
)
	assert candidate(
    {"alert": "SomeAlert", "expr": "vector(%%juju_topology%%)"},
    allow_free_standing=True,
)
	assert not candidate({"alert": "HighRequestLatency"}, True)
	assert not candidate(
    {"alert": "Test"},
    allow_free_standing=False
)
	assert not candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_sum[2m])) by (job) "
        "> 0.5",
        "for": "10m",
        "labels": {
            "severity": "page",
            "service": "request-latency",
        },
        "annotations": {
            "summary": "High request latency",
            "description": "Job {{ $labels.job }} has instance "
            "{{ $labels.instance }} with 99th percentile "
            "{{ $value }} seconds.",
        },
        "free_standing": False,
    },
    allow_free_standing=False,
)
	assert not candidate(
    {"alert": "High request latency", "expr": "histogram_quantile(0.99, sum(rate(request_duration_seconds_bucket[5m])) by (le)) > 0.5"},
    False
)
	assert not candidate(
    {"alert": "HighRequestLatency", "expr": "histogram_quantile(0.99, sum(rate(request_duration_seconds_bucket[5m])) by (le)) > 0.5"},
    False
)
	assert candidate(
    {"alert": "HighRequestLatency", "expr": "sum(rate(request_latency_seconds_count[1m])) by (job) > 0.5"},
    allow_free_standing=True
)
	assert not candidate(
    {"expr": "up{job=\"my_job\"} == 1"},
    True,
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_count{job=~\"myjob.*\"}[1m])) by (le) > 0.5",
        "for": "10m",
        "labels": {"severity": "page"},
        "annotations": {"summary": "High request latency"},
    },
    True,
)
	assert candidate(
    {"alert": "TestRule", "expr": "histogram_quantile(0.9, sum(rate(juju_model_dummy_test_metric_total[5m])) by (le)) > 1"},
    allow_free_standing=True,
)
	assert not candidate(
    {"alert": "TestAlert", "expr": "avg(up) by (juju_model, juju_application) > 0"},
    False
)
	assert candidate(
    {
        "alert": "InstanceDown",
        "expr": 'up{job="juju"} == 0',
        "for": "0m",
        "labels": {
            "severity": "page"
        }
    },
    True
)
	assert not candidate(
    {
        "alert": "Test Alert",
        "expr": "up == 1",
        "for": "10s",
        "labels": {
            "severity": "info",
        },
        "annotations": {
            "summary": "Test summary",
        },
        "free_standing": True,
    },
    allow_free_standing=False,
)
	assert candidate(
    {
        "alert": "My Alert",
        "expr": "metric1 > metric2"
    },
    True
)
	assert not candidate({"expr": "some expr"}, allow_free_standing=False)
	assert not candidate(
    {"alert": "my_alert"},
    True,
)
	assert candidate(
    {"alert": "HighRequestLatency", "expr": "job:request_latency_seconds:mean5m{%%juju_topology%%} > 0.5"},
    False,
)
	assert not candidate(
    {
        "expr": "metric1 > 10",
        "for": "1m",
    },
    True,
)
	assert not candidate(
    {
        "alert": "TestAlert",
    },
    False,
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_count{job=~\"myjob.*\"}[1m])) by (le) > 0.5",
        "for": "10m",
    },
    True,
)
	assert not candidate(
    {"alert": "TestRule", "expr": "histogram_quantile(0.9, sum(rate(juju_model_dummy_test_metric_total[5m])) by (le)) > 1"},
    allow_free_standing=False,
)
	assert not candidate(
    {"alert": "test_alert", "expr": "avg(up) < 1"}, False
)
	assert candidate(
    {
        "alert": "HighRequestLatency",
        "expr": "sum(rate(request_latency_seconds_sum[2m])) by (job) "
        "> 0.5",
        "for": "10m",
        "labels": {
            "severity": "page",
            "service": "request-latency",
        },
        "annotations": {
            "summary": "High request latency",
            "description": "Job {{ $labels.job }} has instance "
            "{{ $labels.instance }} with 99th percentile "
            "{{ $value }} seconds.",
        },
    },
    allow_free_standing=True,
)
def test_check():
	check(_is_valid_rule)
