def find_missing_functions(keywords, text):
    """
    %timeit find_missing_funcs(funcs, text)
    1 loops, best of 3: 973 ms per loop
    """
    ### Canonical solution below ###
    found = set()
    for line in text.splitlines():
        if not line.strip().startswith('def '):
            for f in keywords:
                if f in line:
                    found.add(f)
    return list(set(keywords) - found)


### Unit tests below ###
def check(candidate):
	assert candidate(
    ['foo', 'bar', 'baz'],
    """
    foo(1)
    bar(2)
    baz(3)
    """
) == []
	assert candidate(
    ['a', 'b', 'c'],
    'a\n'
    'b\n'
) == ['c']
	assert candidate(
    ['a', 'b', 'c'],
    'a\n'
    'b\n'
    'd\n'
) == ['c']
	assert candidate(
    ['max','min', 'np.max', 'np.min'],
    """
    def mymax(a):
        return np.max(a)

    def mymin(a):
        return np.min(a)
    """
    ) == []
	assert candidate(
    ['def', 'for', 'if', 'print'],
    'for x in range(10):\n    print(x)\nif True:\n    print("hi")') == ['def']
	assert candidate(
    ['foo', 'bar', 'baz'],
    """
    foo(1)
    bar(2)
    baz(3)
    def foobar(x):
        return x**2
    """
) == []
	assert candidate(
    ['a', 'b', 'c'],
    'a\n'
    'b\n'
    'c\n'
) == []
def test_check():
	check(find_missing_functions)
