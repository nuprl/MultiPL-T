def _bti(bs):
    """Convert multibyte character literals in C enum to int value.

    See 6.4.4.4 in C99 (TC3).
    http://stackoverflow.com/a/548312/1376863
    """
    ### Canonical solution below ###
    rbs = reversed(bytearray(bs))
    return sum(b * (2 ** (i * 8)) for b, i in zip(rbs, range(len(bs))))


### Unit tests below ###
def check(candidate):
	assert candidate(b'\x01\x00\x00\x00\x00\x00\x00\x00') == 72057594037927936
	assert candidate(b'\x03') == 3
	assert candidate(b'\x7f') == 127
	assert candidate(b'\x01\x02') == 258
	assert candidate(b'\xff\xff') == 0xffff
	assert candidate(b'\x00\x00\x00\x0b') == 11
	assert candidate(b'\x12') == 18
	assert candidate(b'\x01\x00\x00\x00') == 16777216
	assert candidate(b'\x01\x01') == 257
	assert candidate(b'\x10') == 16
	assert candidate(b'\x01\x00\x00\x00\x00\x00') == 1099511627776
	assert candidate(b'\x14') == 20
	assert candidate(b'\x0b') == 11
	assert candidate(b'\x00\x00\x00\x07') == 7
	assert candidate(b'\x0d') == 13
	assert candidate(b'\x00\x00\x00\x01') == 1
	assert candidate(b'A') == 65
	assert candidate(b'\xff') == 255
	assert candidate(b'\x01\x00') == 256
	assert candidate(b"\x00\x01") == 1
	assert candidate(b'\x19') == 25
	assert candidate(b'\x00\x00\x00\x00') == 0
	assert candidate(b'\x0f') == 15
	assert candidate(b'\x16') == 22
	assert candidate(b'\x00\x00\x00\x02') == 2
	assert candidate(b'\x00\x00\x01') == 1
	assert candidate(b'\xfe') == 254
	assert candidate(b"\x01\x01") == 257
	assert candidate(b'\x01\x00\x00\x00\x00\x00\x00') == 281474976710656
	assert candidate(b'\x00\x00\x00\x08') == 8
	assert candidate(b"\x01\x01") == 1 + (1 << 8)
	assert candidate(b'\x18') == 24
	assert candidate(b'\x00\x00\x00\x0a') == 10
	assert candidate(b"\x00\x00") == 0
	assert candidate(b'\x81') == 129
	assert candidate(b'\x00\x00\x00\x09') == 9
	assert candidate(b'\x09') == 9
	assert candidate(b'\x00\x00') == 0
	assert candidate(b'\x15') == 21
	assert candidate(b'\x01\x00\x00') == 65536
	assert candidate(b'\x01\x02\x03\x04') == 16909060
	assert candidate(b'\x00\x00\x00\x0c') == 12
	assert candidate(b'\x08') == 8
	assert candidate(b'\x11') == 17
	assert candidate(b'\x00\x00\x01\x00') == 256
	assert candidate(b'\x00\x00\x00\x05') == 5
	assert candidate(b'\x00\x01\x00\x00') == 65536
	assert candidate(b'\x13') == 19
	assert candidate(b'\x02') == 2
	assert candidate(b'\x17') == 23
	assert candidate(b'\x06') == 6
	assert candidate(b'\x01') == 1
	assert candidate(b'\x00\x00\x00\x06') == 6
	assert candidate(b'\x01\x00\x00\x01') == 16777217
	assert candidate(b'\x04') == 4
	assert candidate(b'\xf0') == 240
	assert candidate(b'\x00\x01') == 1
	assert candidate(b'\x80') == 128
	assert candidate(b"\x01\x00") == 256
	assert candidate(b'\x00\x00\x00\x00\x00\x00\x00\x00') == 0
	assert candidate(b'\x00\x00\x00\x04') == 4
	assert candidate(b'\x05') == 5
	assert candidate(b'\x0a') == 10
	assert candidate(b'\xff\xff') == 65535
	assert candidate(b'\x00') == 0
	assert candidate(b'\x00\x00\x00\x03') == 3
	assert candidate(b'\x0e') == 14
	assert candidate(b'\x01\x02') == 0x0102
	assert candidate(b'\x12\x34') == 0x1234
	assert candidate(b'\x0c') == 12
	assert candidate(b'\x07') == 7
	assert candidate(b'\x01\x00\x00\x00\x00') == 4294967296
	assert candidate(b"\x01\x02") == 258
def test_check():
	check(_bti)
