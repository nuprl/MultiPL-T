def _list_from_layouttuple(ltuple):
    """Construct a list from the tuple returned by ttk::layout, this is
    somewhat the reverse of _format_layoutlist."""
    ### Canonical solution below ###
    res = []

    indx = 0
    while indx < len(ltuple):
        name = ltuple[indx]
        opts = {}
        res.append((name, opts))
        indx += 1

        while indx < len(ltuple): # grab name's options
            opt, val = ltuple[indx:indx + 2]
            if not opt.startswith('-'): # found next name
                break

            opt = opt[1:] # remove the '-' from the option
            indx += 2

            if opt == 'children':
                val = _list_from_layouttuple(val)

            opts[opt] = val

    return res


### Unit tests below ###
def check(candidate):
	assert candidate(tuple()) == []
	assert candidate(tuple(('a', '-b', 'c'))) == [('a', {'b': 'c'})]
	assert candidate(
    ('a', '-side', 'left', '-children', ('b', '-side', 'top'), 'c', '-side', 'right')) == \
[('a', {'side': 'left', 'children': [('b', {'side': 'top'})]}),
 ('c', {'side': 'right'})]
	assert candidate(
    ('a', '-side', 'left', '-children', ('b', '-side', 'top'))) == \
[('a', {'side': 'left', 'children': [('b', {'side': 'top'})]})]
	assert candidate(tuple(('a',))) == [('a', {})]
	assert candidate(
    ('toplevel', '-sticky', 'news', '-children', ('frame', '-children', ('label', '-text', 'This is a label')))) == \
    [('toplevel', {'sticky': 'news', 'children': [('frame', {'children': [('label', {'text': 'This is a label'})]})]})]
def test_check():
	check(_list_from_layouttuple)
