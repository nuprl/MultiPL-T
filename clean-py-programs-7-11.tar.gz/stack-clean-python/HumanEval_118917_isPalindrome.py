def isPalindrome(txt):
    """ Given a string, determine weather its a palindrome or not"""
	### Canonical solution below ###    
    for i in range(len(txt)):
        if txt[i] != txt[-(i + 1)]:
            return False
    return True

### Unit tests below ###
def check(candidate):
	assert candidate("No 'x' in Nixon") == False
	assert candidate("aa") == True
	assert candidate(txt = "radars xradar x") == False
	assert candidate(txt="radarsarrasas") == False
	assert candidate(txt = 'radars') == False
	assert candidate(txt="not a palindrome") == False
	assert candidate(
    "abc") == False, "N Odd Even test 2 failed"
	assert candidate("abbba") == True
	assert candidate("kayak") == True, "Palindromes can also be words!"
	assert candidate(
    "kayak") == True, "kayak test 3 failed"
	assert candidate(txt="dented") == False
	assert candidate("abc") == False, "Simple Test Failed"
	assert candidate("dented") == False, "dented is not a palindrome"
	assert candidate(txt="noon") == True
	assert candidate(txt = "radar") == True
	assert candidate("a") == True
	assert candidate(txt="") == True
	assert candidate(txt="abbaab") == False
	assert candidate("redivider") == True, "redivider should be True"
	assert candidate(txt = "radars") == False
	assert candidate(
    "not a palindrome") == False, "Not a palindrome"
	assert candidate(txt="radarsarr") == False
	assert candidate(
    "dented") == False, "dented test 4 failed"
	assert candidate("kayak") == True, "kayak is a palindrome"
	assert candidate("aba") == True
	assert candidate(
    "redivider") == True, "redivider test 5 failed"
	assert candidate(txt="radars") == False
	assert candidate("") == True
	assert candidate(txt="hello") == False
	assert candidate("Able was I ere I saw Elba!") == False
	assert candidate(txt="a") == True
	assert candidate(txt="abc") == False
	assert candidate(txt="radarsarrasasa!!!") == False
	assert candidate(txt="radar") == True
	assert candidate("madam")
	assert candidate('abba') == True
	assert candidate('a') == True
	assert candidate("kayak") == True, "kayak should be True"
	assert candidate(txt="tacocat") == True
	assert candidate(txt = "radars xradar") == False
	assert candidate(
    "abc") == False
	assert candidate(txt="radarsarrasasa!") == False
	assert candidate(txt = 'radar') == True
	assert candidate("abc") == False, "abc should be False"
	assert candidate(txt="racecar") == True
	assert candidate(
    "eye") == True, "eye"
	assert candidate(txt="radarsar") == False
	assert candidate(txt="abba") == True
	assert candidate("abc") == False, "Only strings can be palindromes"
	assert candidate("dented") == False, "dented should be False"
	assert candidate(
    "kayak") == True
	assert candidate('abca') == False
	assert candidate(txt="no x in nixon") == False
	assert candidate(txt="abccba") == True
	assert candidate("ab") == False
	assert candidate(
    "abc") == False, "abc is not a palindrome"
	assert candidate("abbcab") == False
	assert candidate(txt="abcba") == True
	assert candidate('') == True
	assert candidate("abba") == True
	assert candidate(txt="peter") == False
	assert candidate("kayak") == True, "Simple Test Failed"
	assert candidate("abbcabb") == False
def test_check():
	check(isPalindrome)
