def clan_url(clan_tag):
    """Return clan URL on CR-API."""
    ### Canonical solution below ###
    return 'http://cr-api.com/clan/{}'.format(clan_tag)


### Unit tests below ###
def check(candidate):
	assert candidate('9G8PYL92') == 'http://cr-api.com/clan/9G8PYL92'
	assert candidate('9PJ82CRC')!= candidate('9PJ82CRCD')
	assert candidate('QQQQQQQ') == 'http://cr-api.com/clan/QQQQQQQ'
	assert candidate('29L8U0Y0') == 'http://cr-api.com/clan/29L8U0Y0'
	assert candidate('9PJ82CRC') == 'http://cr-api.com/clan/9PJ82CRC'
	assert candidate('8900RG8') == 'http://cr-api.com/clan/8900RG8'
	assert candidate('29000000') == 'http://cr-api.com/clan/29000000'
	assert candidate('P0LYJC8C') == 'http://cr-api.com/clan/P0LYJC8C'
	assert candidate('29L8U0Y') == 'http://cr-api.com/clan/29L8U0Y'
	assert candidate('C2QJQV8V') == 'http://cr-api.com/clan/C2QJQV8V'
	assert candidate('9G8PYL') == 'http://cr-api.com/clan/9G8PYL'
	assert candidate('8900R89') == 'http://cr-api.com/clan/8900R89'
	assert candidate('9G8Y2Y2') == 'http://cr-api.com/clan/9G8Y2Y2'
def test_check():
	check(clan_url)
