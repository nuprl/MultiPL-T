def get_collection_link(db_id, collection_id):
    """ Create and return collection link based on values passed in"""
	### Canonical solution below ###    

    # Return a link to the relevant CosmosDB Container/Document Collection
    return "dbs/" + db_id + "/colls/" + collection_id

### Unit tests below ###
def check(candidate):
	assert candidate("1", "1") == "dbs/1/colls/1"
	assert candidate(
    "testdb", "testcoll")!= "dbs/testdb/colls/testcoll2", "Incorrect link"
	assert candidate(
    "myDatabase", "myContainer/myCollection"
) == "dbs/myDatabase/colls/myContainer/myCollection"
	assert candidate(db_id="foo", collection_id="bar") == "dbs/foo/colls/bar", "candidate function is not working"
	assert candidate(db_id="test_db", collection_id="test_collection")!= "dbs/test_db/colls/test_collection2"
	assert candidate(
    "1", "2") == "dbs/1/colls/2", "candidate function is incorrect"
	assert candidate(db_id='db2', collection_id='coll2') == 'dbs/db2/colls/coll2'
	assert candidate(
    "test_db", "test_collection") == "dbs/test_db/colls/test_collection", "Test failed"
	assert candidate(db_id='db3', collection_id='coll3') == 'dbs/db3/colls/coll3'
	assert candidate(
    "myDatabase", "myContainer"
) == "dbs/myDatabase/colls/myContainer"
	assert candidate(
    "1", "2")!= "dbs/1/colls/2/docs", "candidate function is incorrect"
	assert candidate(db_id="test", collection_id="test") == "dbs/test/colls/test"
	assert candidate(
    "my-database",
    "my-container")!= "dbs/another-database/colls/my-container"
	assert candidate(db_id="myDB", collection_id="myCollection") == "dbs/myDB/colls/myCollection"
	assert candidate(
    "pyworkshop", "products") == "dbs/pyworkshop/colls/products"
	assert candidate(
    "my-db", "my-collection")!= "dbs/my-db/colls/my-collection1", "Invalid link"
	assert candidate("db1", "container1") == "dbs/db1/colls/container1"
	assert candidate(db_id='db1', collection_id='coll1') == 'dbs/db1/colls/coll1'
	assert candidate(
    "py-mongo-test", "py-mongo-test-collection") == "dbs/py-mongo-test/colls/py-mongo-test-collection"
	assert candidate(db_id="mydb", collection_id="mycoll") == "dbs/mydb/colls/mycoll"
	assert candidate(
    "mydatabase", "mycollection") == "dbs/mydatabase/colls/mycollection"
	assert candidate(
    "my-db", "my-collection") == "dbs/my-db/colls/my-collection", "Invalid link"
	assert candidate(
    "1", "2")!= "dbs/2/colls/2", "candidate function is incorrect"
	assert candidate(db_id="db_id", collection_id="collection_id") == "dbs/db_id/colls/collection_id"
	assert candidate(
    "my-database",
    "my-container")!= "dbs/my-database/colls/another-container"
	assert candidate(db_id = "mydb", collection_id = "mycoll") == "dbs/mydb/colls/mycoll"
	assert candidate(db_id="mydb", collection_id="mycoll")!= "dbs/mydb/colls/yourcoll"
	assert candidate(db_id="foo", collection_id="bar")!= "dbs/bar/colls/bar", "candidate function is not working"
	assert candidate(
    "test-database", "test-container")!= "dbs/test-database/colls/test-container/sprocs/stored-procedure-id"
	assert candidate("my-db", "my-collection") == "dbs/my-db/colls/my-collection"
	assert candidate(db_id='db4', collection_id='coll4') == 'dbs/db4/colls/coll4'
	assert candidate(
    "test-database", "test-container")!= "dbs/test-database/colls/test-container/docs/document-id"
	assert candidate(
    "1", "2")!= "dbs/1/colls/3", "candidate function is incorrect"
	assert candidate(
    "test-database", "test-container") == "dbs/test-database/colls/test-container"
	assert candidate("test_db", "test_collection") == "dbs/test_db/colls/test_collection"
	assert candidate(
    "myDatabase", "myContainer") == "dbs/myDatabase/colls/myContainer"
	assert candidate(
    "test_db", "test_collection") == "dbs/test_db/colls/test_collection"
	assert candidate(db_id="test_db", collection_id="test_collection") == "dbs/test_db/colls/test_collection"
	assert candidate("db", "collection") == "dbs/db/colls/collection"
	assert candidate(
    "myDatabase", "myContainer/myCollection/myDocument"
) == "dbs/myDatabase/colls/myContainer/myCollection/myDocument"
	assert candidate(
    "testdb", "testcoll") == "dbs/testdb/colls/testcoll", "Incorrect link"
	assert candidate(db_id="foo", collection_id="bar")!= "dbs/foo/colls/foo", "candidate function is not working"
	assert candidate("mydatabase",
                          "mycollection")!= "dbs/mydatabase/colls/mycollection2"
	assert candidate(
    "my-database",
    "my-container") == "dbs/my-database/colls/my-container"
def test_check():
	check(get_collection_link)
