def extend_path(path, valid_extensions, default_extension):
    """
    Return tuple (path, extension) ensuring that path has extension.

    """
    ### Canonical solution below ###
    for extension in valid_extensions:
        if path.endswith("." + extension):
            return (path, extension)
    return (path + "." + default_extension, default_extension)


### Unit tests below ###
def check(candidate):
	assert candidate(path="foo.bar", valid_extensions=["bar"], default_extension="baz") == ("foo.bar", "bar")
	assert candidate(path="foo.py", valid_extensions=("py", "txt"), default_extension="py") == ("foo.py", "py")
	assert candidate("foo.txt", ["txt", "dat"], "txt") == ("foo.txt", "txt")
	assert candidate("foo.dat", ["txt", "dat"], "txt") == ("foo.dat", "dat")
	assert candidate("a.csv", ["csv", "json"], "csv") == ("a.csv", "csv")
	assert candidate(
    "foo/bar/baz",
    ["baz", "bar"],
    "foo") == ("foo/bar/baz.foo", "foo")
	assert candidate(
    "/path/to/file.txt.gz",
    ["tar", "gz"],
    "tar.gz",
) == ("/path/to/file.txt.gz", "gz")
	assert candidate(path="test.txt", valid_extensions=("jpg", "png"), default_extension="jpg") == ("test.txt.jpg", "jpg")
	assert candidate(
    "foo/bar/baz",
    [],
    "baz") == ("foo/bar/baz.baz", "baz")
	assert candidate(path="foo", valid_extensions=["bar"], default_extension="baz") == ("foo.baz", "baz")
	assert candidate(
    "foo/bar/baz",
    ["a", "b", "c"],
    "d"
) == ("foo/bar/baz.d", "d")
	assert candidate(r"C:\temp\temp.txt", ["txt"], "txt") == (r"C:\temp\temp.txt", "txt")
	assert candidate(path="foo.baz", valid_extensions=("bar", "baz"), default_extension="bar") == ("foo.baz", "baz")
	assert candidate("a.json", ["json", "csv"], "json") == ("a.json", "json")
	assert candidate(r"myfile", (".csv", ".txt"), "txt") == (r"myfile.txt", "txt")
	assert candidate(r"C:\temp\temp.txt", ["txt"], "csv") == (r"C:\temp\temp.txt", "txt")
	assert candidate("a", ["json", "csv"], "csv") == ("a.csv", "csv")
	assert candidate(
    "foo/bar/baz",
    ["baz", "bar", "foo"],
    "bar") == ("foo/bar/baz.bar", "bar")
	assert candidate(path="test.png", valid_extensions=("jpg", "png"), default_extension="jpg") == ("test.png", "png")
	assert candidate("foo.bar", ["txt", "dat"], "txt") == ("foo.bar.txt", "txt")
	assert candidate("index.txt", ["txt", "html"], "txt") == ("index.txt", "txt")
	assert candidate("foo.bar", ["bar"], "baz") == ("foo.bar", "bar")
	assert candidate("filename", ("txt", "rst"), "txt") == ("filename.txt", "txt")
	assert candidate(r"foo.txt", ("txt", "dat"), "txt") == (r"foo.txt", "txt")
	assert candidate(
    "foo/bar/baz",
    ["baz"],
    "bar") == ("foo/bar/baz.bar", "bar")
	assert candidate(
    "foo/bar/baz.c",
    ["a", "b", "c"],
    "d"
) == ("foo/bar/baz.c", "c")
	assert candidate(
    "foo/bar/baz.a",
    ["a", "b", "c"],
    "d"
) == ("foo/bar/baz.a", "a")
	assert candidate(r"C:\myfile", (".csv", ".txt"), "txt") == (r"C:\myfile.txt", "txt")
	assert candidate(r"C:\myfile", (".csv", ".txt"), "csv") == (r"C:\myfile.csv", "csv")
	assert candidate(path="foo", valid_extensions=("bar", "baz"), default_extension="bar") == ("foo.bar", "bar")
	assert candidate(path="foo", valid_extensions=["txt"],
                   default_extension="pdf") == ("foo.pdf", "pdf")
	assert candidate(path="file.ext", valid_extensions=["ext", "ext2"], default_extension="ext") == ("file.ext", "ext")
	assert candidate(
    "foo/bar/baz.c.c",
    ["a", "b", "c"],
    "d"
) == ("foo/bar/baz.c.c", "c")
	assert candidate("a.x", ["x", "y"], None) == ("a.x", "x")
	assert candidate("index", ["txt", "html"], "txt") == ("index.txt", "txt")
	assert candidate(
    "foo/bar/baz",
    ["baz", "bar"],
    "bar") == ("foo/bar/baz.bar", "bar")
	assert candidate("a.x", ["x"], None) == ("a.x", "x")
	assert candidate(path="foo", valid_extensions=["ext1", "ext2"], default_extension="ext1") == ("foo.ext1", "ext1")
	assert candidate(r"C:\temp\temp.txt", ["csv"], "csv") == (r"C:\temp\temp.txt.csv", "csv")
	assert candidate("a.x", ["y", "x"], None) == ("a.x", "x")
	assert candidate(
    "foo/bar/baz.a.a",
    ["a", "b", "c"],
    "d"
) == ("foo/bar/baz.a.a", "a")
	assert candidate(path="test.txt", valid_extensions=("txt", "py"), default_extension="txt") == ("test.txt", "txt")
	assert candidate(path="test.py", valid_extensions=("txt", "py"), default_extension="txt") == ("test.py", "py")
	assert candidate(path="test.txt.py", valid_extensions=("txt", "py"), default_extension="txt") == ("test.txt.py", "py")
	assert candidate("foo.bar", ["bar"], None) == ("foo.bar", "bar")
	assert candidate(path="file", valid_extensions=["ext"], default_extension="ext") == ("file.ext", "ext")
	assert candidate("a.x", ["z", "x"], "y") == ("a.x", "x")
	assert candidate(path="foo.txt", valid_extensions=("py", "txt"), default_extension="py") == ("foo.txt", "txt")
	assert candidate("a.csv", ["json", "csv"], "csv") == ("a.csv", "csv")
	assert candidate(r"foo", ("dat", "txt"), "txt") == (r"foo.txt", "txt")
	assert candidate(
    "foo/bar/baz",
    ["baz", "bar", "foo"],
    "baz") == ("foo/bar/baz.baz", "baz")
	assert candidate(
    "foo/bar/baz",
    ["baz"],
    "baz") == ("foo/bar/baz.baz", "baz")
	assert candidate(r"C:\myfile", (".csv", ".txt"), "xlsx") == (r"C:\myfile.xlsx", "xlsx")
	assert candidate(path="test", valid_extensions=("txt"), default_extension="txt") == ("test.txt", "txt")
	assert candidate("foo", ["txt", "dat"], "txt") == ("foo.txt", "txt")
	assert candidate(path="foo.bar.py", valid_extensions=("py", "txt"), default_extension="py") == ("foo.bar.py", "py")
	assert candidate("filename.rst", ("txt", "rst"), "txt") == ("filename.rst", "rst")
	assert candidate(
    "foo/bar/baz",
    ["baz", "bar", "foo"],
    "foo") == ("foo/bar/baz.foo", "foo")
	assert candidate(path="test.jpg", valid_extensions=("jpg", "png"), default_extension="jpg") == ("test.jpg", "jpg")
	assert candidate("filename.txt", ("txt", "rst"), "txt") == ("filename.txt", "txt")
	assert candidate(path="file.json", valid_extensions=["json"], default_extension="json") == ("file.json", "json")
	assert candidate(
    "foo/bar/baz",
    ["baz", "bar"],
    "baz") == ("foo/bar/baz.baz", "baz")
	assert candidate(path="test.jpeg", valid_extensions=("jpg", "png"), default_extension="jpg") == ("test.jpeg.jpg", "jpg")
	assert candidate("a.x", ["z", "y", "x"], "y") == ("a.x", "x")
	assert candidate(path="foo.ext2", valid_extensions=["ext1", "ext2"], default_extension="ext1") == ("foo.ext2", "ext2")
	assert candidate(path="foo.txt", valid_extensions=["txt"],
                   default_extension="txt") == ("foo.txt", "txt")
	assert candidate(path="test", valid_extensions=("jpg", "png"), default_extension="jpg") == ("test.jpg", "jpg")
	assert candidate(path="foo.bar", valid_extensions=("bar", "baz"), default_extension="bar") == ("foo.bar", "bar")
	assert candidate(path="foo.bar.txt", valid_extensions=("py", "txt"), default_extension="py") == ("foo.bar.txt", "txt")
	assert candidate(path="foo", valid_extensions=("py", "txt"), default_extension="py") == ("foo.py", "py")
	assert candidate(path="file.ext", valid_extensions=["ext"], default_extension="ext") == ("file.ext", "ext")
	assert candidate(path="foo.ext1", valid_extensions=["ext1", "ext2"], default_extension="ext1") == ("foo.ext1", "ext1")
	assert candidate(path="foo.bar", valid_extensions=("py", "txt"), default_extension="py") == ("foo.bar.py", "py")
	assert candidate(path="test", valid_extensions=("txt", "py"), default_extension="txt") == ("test.txt", "txt")
	assert candidate(
    "foo/bar/baz.b",
    ["a", "b", "c"],
    "d"
) == ("foo/bar/baz.b", "b")
	assert candidate(
    "foo/bar/baz.b.b",
    ["a", "b", "c"],
    "d"
) == ("foo/bar/baz.b.b", "b")
	assert candidate("a.x", ["z", "y"], "y") == ("a.x.y", "y")
	assert candidate(
    "/path/to/file.txt",
    ["tar", "gz"],
    "tar.gz",
) == ("/path/to/file.txt.tar.gz", "tar.gz")
	assert candidate("a.x", ["x", "z"], "y") == ("a.x", "x")
	assert candidate(r"foo.txt", ("dat", "txt"), "txt") == (r"foo.txt", "txt")
	assert candidate(r"C:\myfile.txt", (".csv", ".txt"), "xlsx") == (r"C:\myfile.txt.xlsx", "xlsx")
	assert candidate("a.json", ["json", "csv"], "csv") == ("a.json", "json")
	assert candidate(
    "/path/to/file",
    ["tar", "gz"],
    "tar.gz",
) == ("/path/to/file.tar.gz", "tar.gz")
	assert candidate("index.html", ["txt", "html"], "txt") == ("index.html", "html")
	assert candidate(r"C:\temp\temp.txt", ["xlsx"], "xlsx") == (r"C:\temp\temp.txt.xlsx", "xlsx")
	assert candidate("a.x", ["y", "z"], "y") == ("a.x.y", "y")
	assert candidate("test", [".txt", ".rst"], "txt") == ("test.txt", "txt")
	assert candidate(
    "foo/bar/baz",
    [],
    "bar") == ("foo/bar/baz.bar", "bar")
	assert candidate("a.b", ["a", "b"], "c") == ("a.b", "b")
	assert candidate(r"foo.dat", ("dat", "txt"), "txt") == (r"foo.dat", "dat")
def test_check():
	check(extend_path)
