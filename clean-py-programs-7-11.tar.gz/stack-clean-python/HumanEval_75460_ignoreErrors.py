def ignoreErrors(func, *args, **kwargs):
    """ 
     >>> ignoreErrors(int, '3')
     3
     >>> ignoreErrors(int, 'three')
     
     """
	### Canonical solution below ###    
    try:    return func(*args, **kwargs)
    except Exception: return None

### Unit tests below ###
def check(candidate):
	assert candidate(int, '3') == 3
	assert candidate(int, 'three', base=16) == None
	assert candidate(int, 'three') == None
	assert candidate(int, 'three') is None
def test_check():
	check(ignoreErrors)
