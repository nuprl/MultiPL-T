def _get_paths(config_dict):
    """ Return a list of all paths referenced by the config dict."""
	### Canonical solution below ###    
    return_list = [
        config_dict["diag_table"],
        config_dict["data_table"],
        config_dict["forcing"],
        config_dict["initial_conditions"],
    ]
    patch_files = config_dict.get("patch_files", [])
    if isinstance(patch_files, list):
        return_list.extend(patch_files)
    else:
        return_list.append(patch_files)
    return return_list

### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        "diag_table": "diag_table.nc",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": ["patch1.nc", "patch2.nc"],
    }
) == [
    "diag_table.nc",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch1.nc",
    "patch2.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.csv",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": ["patch_files.txt", "patch_files2.txt"],
    }
) == [
    "diag_table.csv",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_files.txt",
    "patch_files2.txt",
]
	assert candidate(
    {
        "diag_table": "diag_table.csv",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "ic.nc",
        "patch_files": "patch_files.csv",
    }
) == [
    "diag_table.csv",
    "data_table.csv",
    "forcing.nc",
    "ic.nc",
    "patch_files.csv",
]
	assert candidate(
    {
        "diag_table": "diag_table.csv",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "ic.nc",
        "patch_files": [
            "patch_files.csv",
            "patch_files_2.csv",
        ],
    }
) == [
    "diag_table.csv",
    "data_table.csv",
    "forcing.nc",
    "ic.nc",
    "patch_files.csv",
    "patch_files_2.csv",
]
	assert candidate(
    {
        "diag_table": "diag_table.csv",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": ["patch_file_1.csv", "patch_file_2.csv"],
    }
) == [
    "diag_table.csv",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_file_1.csv",
    "patch_file_2.csv",
]
	assert candidate(
    {
        "diag_table": "diag_table.nc",
        "data_table": "data_table.json",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": "patch_file.nc",
    }
) == [
    "diag_table.nc",
    "data_table.json",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_file.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.nc",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": ["patch_file1.nc", "patch_file2.nc"],
    }
) == [
    "diag_table.nc",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_file1.nc",
    "patch_file2.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.nc",
        "data_table": "data_table.json",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": ["patch_file1.nc", "patch_file2.nc"],
    }
) == [
    "diag_table.nc",
    "data_table.json",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_file1.nc",
    "patch_file2.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.csv",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
    }
) == [
    "diag_table.csv",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.csv",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": "patch_files.txt",
    }
) == [
    "diag_table.csv",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_files.txt",
]
	assert candidate(
    {
        "diag_table": "/path/to/diag_table.nc",
        "data_table": "/path/to/data_table.txt",
        "forcing": "/path/to/forcing.nc",
        "initial_conditions": "/path/to/initial_conditions.nc",
    }
) == [
    "/path/to/diag_table.nc",
    "/path/to/data_table.txt",
    "/path/to/forcing.nc",
    "/path/to/initial_conditions.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.nc",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
    }
) == [
    "diag_table.nc",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.nc",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": "patch.nc",
    }
) == [
    "diag_table.nc",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch.nc",
]
	assert candidate(
    {
        "diag_table": "diag_table.csv",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": "patch_file.csv",
    }
) == [
    "diag_table.csv",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_file.csv",
]
	assert candidate(
    {
        "diag_table": "diag_table.nc",
        "data_table": "data_table.csv",
        "forcing": "forcing.nc",
        "initial_conditions": "initial_conditions.nc",
        "patch_files": "patch_file.nc",
    }
) == [
    "diag_table.nc",
    "data_table.csv",
    "forcing.nc",
    "initial_conditions.nc",
    "patch_file.nc",
]
	assert candidate(
    {
        "diag_table": "/path/to/diag_table.nc",
        "data_table": "/path/to/data_table.txt",
        "forcing": "/path/to/forcing.nc",
        "initial_conditions": "/path/to/initial_conditions.nc",
        "patch_files": ["/path/to/patch_file.txt"],
    }
) == [
    "/path/to/diag_table.nc",
    "/path/to/data_table.txt",
    "/path/to/forcing.nc",
    "/path/to/initial_conditions.nc",
    "/path/to/patch_file.txt",
]
def test_check():
	check(_get_paths)
