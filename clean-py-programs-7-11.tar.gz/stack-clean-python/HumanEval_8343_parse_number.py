def parse_number(value):
    """Quick'n dirty. """
    ### Canonical solution below ###
    return value.replace(" ", "")


### Unit tests below ###
def check(candidate):
	assert candidate(u" 1 2 ") == u"12"
	assert candidate(u"1") == u"1"
	assert candidate(u'1 000 000.00') == u'1000000.00'
	assert candidate(u"10") == "10"
	assert candidate(u"1000") == u"1000"
	assert candidate(u" 1 2 3 4") == u"1234"
	assert candidate(u"1 000") == "1000"
	assert candidate("25.0 ") == "25.0"
	assert candidate(u"123 000") == u"123000"
	assert candidate(u"1 230.45 - 67.89") == "1230.45-67.89"
	assert candidate(u"1 000.00") == u"1000.00"
	assert candidate( "100" ) == "100"
	assert candidate("25 ") == "25"
	assert candidate(
    "12 345") == "12345"
	assert candidate(u"1000") == "1000"
	assert candidate(
    "12 345 67") == "1234567"
	assert candidate(u"34,000,000.000")
	assert candidate(u"1 230.45") == "1230.45"
	assert candidate(u"123.45") == "123.45"
	assert candidate(u'1 000 000') == u'1000000'
	assert candidate(u"1234.567") == "1234.567"
	assert candidate(r"100.0000") == "100.0000"
	assert candidate(u"1 2 ") == u"12"
	assert candidate(u"1 000,00") == u"1000,00"
	assert candidate(
    "12345 ") == "12345"
	assert candidate(u"1 2 3 4 5 6 ") == u"123456"
	assert candidate(u"10 000") == "10000"
	assert candidate(" 20 ") == "20"
	assert candidate(u"123") == "123"
	assert candidate( "100.00" ) == "100.00"
	assert candidate(u" 1") == u"1"
	assert candidate(u"1.23") == "1.23"
	assert candidate(u"1 ") == u"1"
	assert candidate("123 456 7890 1234567890 1234567890") == \
    "123456789012345678901234567890"
	assert candidate("25.0") == "25.0"
	assert candidate(u" 1 2 3 4 5 ") == u"12345"
	assert candidate(u"1 230.45 - 67.89 ") == "1230.45-67.89"
	assert candidate(u"1234.56789") == u"1234.56789"
	assert candidate(u'1.0') == u'1.0'
	assert candidate(u"1 2 3 4") == u"1234"
	assert candidate(u"1.2") == "1.2"
	assert candidate(u'1,000') == u'1,000'
	assert candidate(u"34") == u"34"
	assert candidate("123 456 7890") == "1234567890"
	assert candidate(u"1 230.45 - 67") == "1230.45-67"
	assert candidate(u"1234.567") == u"1234.567"
	assert candidate(u'1') == u'1'
	assert candidate(u" 1 2 3 4 5 6") == u"123456"
	assert candidate("3.14.159") == "3.14.159"
	assert candidate(" 25 ") == "25"
	assert candidate(u" 123 ") == u"123"
	assert candidate(u"34 000") == u"34000"
	assert candidate(u"1.0") == u"1.0"
	assert candidate(u"1  ") == u"1"
	assert candidate(u" 1 2 3 ") == u"123"
	assert candidate(" 25") == "25"
	assert candidate("25") == "25"
	assert candidate(u"1") == "1"
	assert candidate("1234567890") == "1234567890"
	assert candidate(u"1 000") == u"1000"
	assert candidate("1000") == "1000"
	assert candidate(u" 123.456 ") == "123.456"
	assert candidate(r"100.00") == "100.00"
	assert candidate(u'100') == u'100'
	assert candidate(u"1 230.45-67") == "1230.45-67"
	assert candidate(u" 1 2") == u"12"
	assert candidate(u'100 000') == u'100000'
	assert candidate(u"1 2 3 ") == u"123"
	assert candidate(u" 1 2 3 4 ") == u"1234"
	assert candidate(r"100.000") == "100.000"
	assert candidate(u"123") == u"123"
	assert candidate(u"123 ") == u"123"
	assert candidate(u"1000 000") == "1000000"
	assert candidate(u'1 ') == u'1'
	assert candidate("123 456 7890 1234567890") == "12345678901234567890"
	assert candidate(u" 123") == u"123"
	assert candidate(u"1 000.0") == u"1000.0"
	assert candidate(u"1 230.45 -67") == "1230.45-67"
	assert candidate(r"100") == "100"
	assert candidate(u"1 2 3 4 5 ") == u"12345"
	assert candidate(
    "12345") == "12345"
	assert candidate(u" 1 ") == u"1"
	assert candidate(" 25.0") == "25.0"
	assert candidate("") == ""
	assert candidate(u"1 234.567") == "1234.567"
	assert candidate(u"1234.5678") == u"1234.5678"
	assert candidate(u"10.5") == "10.5"
	assert candidate(u"123.45") == u"123.45"
	assert candidate("3,14,159") == "3,14,159"
	assert candidate(u"1 234") == "1234"
	assert candidate(u"1234.567890") == u"1234.567890"
	assert candidate(u"1 000,000") == u"1000,000"
	assert candidate(u"1 2") == "12"
	assert candidate(u"1 2 3 4 ") == u"1234"
	assert candidate(u"1 2") == u"12"
	assert candidate(" 25.0 ") == "25.0"
	assert candidate(u" 1 2 3 4 5") == u"12345"
	assert candidate(u"34 000 000") == u"34000000"
	assert candidate("20") == "20"
	assert candidate(u"1 2 3") == u"123"
	assert candidate(u" 1 2 3") == u"123"
	assert candidate(u"1 230") == "1230"
def test_check():
	check(parse_number)
