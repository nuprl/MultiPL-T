def print_palindromes(palindrome_dict):
    """
Given a dictionary with palindrome positions as keys, and
lengths as first element of the value,
print the positions and lengths separated by a whitespace,
one pair per line.
    """
    ### Canonical solution below ###
    for key, value in palindrome_dict.items():
        print(key, value[0])
        
    return None


### Unit tests below ###
def check(candidate):
	assert candidate(
    {1: [3], 2: [2, 2], 3: [1, 1, 1, 1]}) == None
	assert candidate({'a': [2, 2], 'b': [3, 3], 'c': [2, 2], 'd': [3, 3], 'e': [2, 2], 'f': [3, 3]}) == None
	assert candidate({'a': [2, 2], 'b': [3, 3], 'c': [2, 2], 'd': [3, 3], 'e': [2, 2]}) == None
	assert candidate(
    {1: [7, 7], 2: [6, 6], 3: [5, 5], 4: [4, 4], 5: [3, 3], 6: [2, 2], 7: [1, 1]}) == None
	assert candidate({'a': [2, 2], 'b': [3, 2]}) == None
	assert candidate({'a': [2, 2], 'b': [3, 3]}) == None
	assert candidate({'a': [2, 2], 'b': [2, 2]}) == None
	assert candidate(
    {'1': [2, 2], '2': [2, 2], '3': [3, 2], '4': [4, 2], '5': [5, 2]}) == None
	assert candidate({'a': [2, 2], 'b': [2, 3]}) == None
	assert candidate({'a': [2, 2], 'b': [3, 3], 'c': [2, 2], 'd': [3, 3]}) == None
	assert candidate({'a': [2, 2], 'b': [3, 3], 'c': [2, 2], 'd': [3, 3], 'e': [2, 2], 'f': [3, 3], 'g': [2, 2]}) == None
	assert candidate({'a': [2, 2], 'b': [3, 3], 'c': [2, 2]}) == None
	assert candidate(dict()) == None
def test_check():
	check(print_palindromes)
