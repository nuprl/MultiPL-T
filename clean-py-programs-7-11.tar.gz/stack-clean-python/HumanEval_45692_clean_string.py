def clean_string(s: str) -> str:
    """Cleans and returns an input string
    >>> clean_string(" xYz ")
    'XYZ'
    """
    ### Canonical solution below ###
    return str(s).strip().upper()


### Unit tests below ###
def check(candidate):
	assert candidate(10) == "10"
	assert candidate(" xYz ")!= 'xyz'
	assert candidate(" xYz ") == "XYZ"
	assert candidate("   abc   ") == "ABC"
	assert candidate("  xyz  ") == "XYZ"
	assert candidate(' xYz ') == 'XYZ'
	assert candidate(" aBc ") == "ABC"
	assert candidate(123) == "123"
	assert candidate(2) == "2"
	assert candidate("xyz") == "XYZ"
	assert candidate("") == ""
	assert candidate(" xYz ") == 'XYZ'
	assert candidate('XYZ') == 'XYZ'
	assert candidate('xyz') == 'XYZ'
	assert candidate("123") == "123"
	assert candidate("   xyz    ") == "XYZ"
	assert candidate('ABC123') == 'ABC123'
	assert candidate(' XYZ ') == 'XYZ'
def test_check():
	check(clean_string)
