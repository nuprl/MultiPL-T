def apparent_attenuation(original_extract, apparent_extract):
    """
    Apparent Attenuation

    :param float original_extract: Original degrees Plato
    :param float apparent_extract: Apparent degrees Plato of finished beer
    :return: The percent of apparent attenuation
    :rtype: float

    Source:

    * Formula from Balling: De Clerck, Jean, A Textbook Of Brewing, Chapman & Hall Ltd., 1958
    * http://beersmith.com/blog/2010/09/07/apparent-and-real-attenuation-for-beer-brewers-part-1/
    * http://beersmith.com/blog/2010/09/14/apparent-and-real-attenuation-for-beer-brewers-part-2/
    """  # noqa
    ### Canonical solution below ###
    return (original_extract - apparent_extract) / original_extract


### Unit tests below ###
def check(candidate):
	assert candidate(1, 0.1) == 0.9
	assert candidate(13.0, 13.0) == 0.0
	assert candidate(1, 1) == 0
	assert candidate(1, 0.001) == 0.999
	assert candidate(1.5, 1.125) == 0.25
	assert candidate(10, 10) == 0
	assert candidate(1, 0.005) == 0.995
	assert candidate(1, 0.05) == 0.95
	assert candidate(15, 7.5) == 7.5/15
	assert candidate(2, 1.2) == 0.4
	assert candidate(1, 1) == 0.0
	assert candidate(16, 16) == 0.0
	assert candidate(5.2, 5.2) == 0.0
	assert candidate(10, 9.5)
	assert candidate(10, 10) == 0.0
	assert candidate(20, 10) == 0.5
	assert candidate(5, 5) == 0.0
	assert candidate(15.0, 15.0) == 0.0
	assert candidate(15, 15) == 0
	assert candidate(1, 0.5) == 0.5
	assert candidate(1, 0.01) == 0.99
	assert candidate(10, 5) == 0.5
def test_check():
	check(apparent_attenuation)
