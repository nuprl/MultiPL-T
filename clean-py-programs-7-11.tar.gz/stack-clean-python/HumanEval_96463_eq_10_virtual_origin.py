def eq_10_virtual_origin(D: float, Q_dot_kW: float):
    """ Equation 10 in Section 8.3.1 PD 7974-1:2019 calculates virtual fire origin.
     
     :param D: in m, fire diameter.
     :param Q_dot_kW: in kW, fire heat release rate.
     :return z_0: in m, fire's virtual origin.
     """
	### Canonical solution below ###    

    z_0 = -1.02 * D + 0.083 * Q_dot_kW ** (2 / 5)

    return z_0

### Unit tests below ###
def check(candidate):
	assert candidate(D=0.0, Q_dot_kW=0.0) == 0.0
	assert candidate(0.1, 1) == -1.02 * 0.1 + 0.083 * 1 ** (2 / 5)
	assert candidate(0.0, 0.0) == 0.0
def test_check():
	check(eq_10_virtual_origin)
