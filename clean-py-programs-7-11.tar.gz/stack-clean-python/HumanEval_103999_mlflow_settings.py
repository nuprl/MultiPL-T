def mlflow_settings():
    """
    RUN UI with postgres and HPC:
    REMOTE postgres server:
        # connecting to remote server through ssh tunneling
        ssh -L 5000:localhost:5432 artinmajdi@data7-db1.cyverse.org

        # using the mapped port and localhost to view the data
        mlflow ui --backend-store-uri postgresql://artinmajdi:1234@localhost:5000/chest_db --port 6789

    RUN directly from GitHub or show experiments/runs list:

    export MLFLOW_TRACKING_URI=http://127.0.0.1:5000
    
    mlflow runs list --experiment-id <id>

    mlflow run                 --no-conda --experiment-id 5 -P epoch=2 https://github.com/artinmajdi/mlflow_workflow.git -v main
    mlflow run mlflow_workflow --no-conda --experiment-id 5 -P epoch=2
    
    PostgreSQL server style
        server = f'{dialect_driver}://{username}:{password}@{ip}/{database_name}' """
    ### Canonical solution below ###

    postgres_connection_type = { 'direct':     ('5432', 'data7-db1.cyverse.org'),
                                    'ssh-tunnel': ('5000', 'localhost')
                                }

    port, host = postgres_connection_type['ssh-tunnel'] # 'direct' , 'ssh-tunnel'
    username       = "artinmajdi"
    password       = '1234'
    database_name  = "chest_db_v2"
    dialect_driver = 'postgresql'
    server         = f'{dialect_driver}://{username}:{password}@{host}:{port}/{database_name}'

    Artifacts = { 'hpc':        'sftp://mohammadsmajdi@filexfer.hpc.arizona.edu:/home/u29/mohammadsmajdi/projects/mlflow/artifact_store',
                  'data7_db1':  'sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store'} # :temp2_data7_b

   
    return server, Artifacts['data7_db1']


### Unit tests below ###
def check(candidate):
	assert candidate( )[1] =='sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store'
	assert candidate(  )[1] =='sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store'
	assert candidate( )[0] == 'postgresql://artinmajdi:1234@localhost:5000/chest_db_v2'
	assert candidate( )[1] =='sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store','candidate: not working'
	assert candidate(  )[0] == 'postgresql://artinmajdi:1234@localhost:5000/chest_db_v2','candidate failed to return the correct server connection'
	assert candidate( )[1] =='sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store', 'wrong artifact'
	assert candidate( ) == ('postgresql://artinmajdi:1234@localhost:5000/chest_db_v2','sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store')
	assert candidate( )[1] =='sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store', 'Check your artifact store connection'
	assert candidate( )[1] =='sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store', 'Incorrect artifact store'
	assert candidate( )[0] == 'postgresql://artinmajdi:1234@localhost:5000/chest_db_v2', 'wrong server'
	assert candidate( )[0] == 'postgresql://artinmajdi:1234@localhost:5000/chest_db_v2','candidate: not working'
	assert candidate(  )[1] =='sftp://artinmajdi@data7-db1.cyverse.org:/home/artinmajdi/mlflow_data/artifact_store','candidate failed to return the correct artifact location'
def test_check():
	check(mlflow_settings)
