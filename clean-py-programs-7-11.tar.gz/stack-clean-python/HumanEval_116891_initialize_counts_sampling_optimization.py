def initialize_counts_sampling_optimization(shots, hex_counts=True):
    """Sampling optimization counts"""
    ### Canonical solution below ###
    if hex_counts:
        return [{'0x0': shots/2, '0x2': shots/2}]
    else:
        return [{'0x00': shots/2, '0x10': shots/2}]


### Unit tests below ###
def check(candidate):
	assert candidate(shots=4, hex_counts=True) == [{'0x0': 2, '0x2': 2}]
	assert candidate(shots=100, hex_counts=True) == [{'0x0': 50, '0x2': 50}]
	assert candidate(100, hex_counts=False) == [{'0x00': 50, '0x10': 50}]
	assert candidate(shots=2, hex_counts=True) == [{'0x0': 1, '0x2': 1}]
	assert candidate(1000, hex_counts=False) == [{'0x00': 500, '0x10': 500}]
	assert candidate(0) == [{'0x0': 0, '0x2': 0}]
	assert candidate(100, False) == [{'0x00': 50, '0x10': 50}]
	assert candidate(shots=10, hex_counts=True) == [{'0x0': 5, '0x2': 5}]
	assert candidate(2, True) == [{'0x0': 1, '0x2': 1}]
	assert candidate(100, hex_counts=True) == [{'0x0': 50, '0x2': 50}]
	assert candidate(10, False) == [{'0x00': 5, '0x10': 5}]
	assert candidate(2, hex_counts=False) == [{'0x00': 1, '0x10': 1}]
	assert candidate(shots=1, hex_counts=True) == [{'0x0': 0.5, '0x2': 0.5}]
	assert candidate(shots=2, hex_counts=False) == [{'0x00': 1, '0x10': 1}]
	assert candidate(1) == [{'0x0': 0.5, '0x2': 0.5}]
	assert candidate(10, hex_counts=True) == [{'0x0': 5, '0x2': 5}]
	assert candidate(1000) == [{'0x0': 500, '0x2': 500}]
	assert candidate(shots=8, hex_counts=True) == [{'0x0': 4, '0x2': 4}]
	assert candidate(shots=1, hex_counts=False) == [{'0x00': 0.5, '0x10': 0.5}]
	assert candidate(10, hex_counts=False) == [{'0x00': 5, '0x10': 5}]
	assert candidate(shots=100, hex_counts=False) == [{'0x00': 50, '0x10': 50}]
	assert candidate(2, False) == [{'0x00': 1, '0x10': 1}]
	assert candidate(shots=4, hex_counts=False) == [{'0x00': 2, '0x10': 2}]
	assert candidate(shots=8, hex_counts=False) == [{'0x00': 4, '0x10': 4}]
	assert candidate(2) == [{'0x0': 1, '0x2': 1}]
	assert candidate(shots=10, hex_counts=False) == [{'0x00': 5, '0x10': 5}]
	assert candidate(10) == [{'0x0': 5, '0x2': 5}]
def test_check():
	check(initialize_counts_sampling_optimization)
