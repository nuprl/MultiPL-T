def predicate(line):
    """
    Remove lines starting with `  # `
    """
    ### Canonical solution below ###
    if "#" in line:
        return False
    return True


### Unit tests below ###
def check(candidate):
	assert candidate("  #    ") == False
	assert candidate(
    "def test():  # a comment") == False
	assert candidate("not a comment") == True
	assert candidate(line="  This is a line with no comment") == True
	assert candidate(line="  #") == False
	assert candidate(u"  #") == False
	assert candidate("  # test") == False
	assert candidate(u"  A line with no comment") == True
	assert candidate(line="  # comment") == False
	assert candidate("  # ") == False
	assert candidate("#") == False
	assert candidate(
    "def test():") == True
	assert candidate("") is True
	assert candidate("test") == True
	assert candidate(u'    # This is a comment') == False
	assert candidate(line="a # comment") == False
	assert candidate("  # something") == False
	assert candidate(
    "This is not a comment"
) is True
	assert candidate(r"a = 1  # comment") == False
	assert candidate("  # comment") == False
	assert candidate("foo") == True
	assert candidate("# foo") == False
	assert candidate(line="  # This is a comment") == False
	assert candidate(u'    This is not a comment') == True
	assert not candidate(u"1\t2\t#3")
	assert candidate("  # foo") == False
	assert candidate(line="  # this is a comment") == False
	assert candidate(u"") == True
	assert candidate(r"a = 1 # comment") == False
	assert candidate("  # This is a comment") == False
	assert candidate(r"a = 1") == True
	assert candidate(u"  # A comment") == False
	assert candidate(
    "  # This is a comment"
) is False
	assert candidate("  # ") is False
	assert candidate("  # comment") is False
	assert candidate("    # something") == False
	assert candidate("  #") == False
	assert candidate("   ") is True
	assert candidate(" ") == True
	assert candidate( "this is a line" ) == True
	assert candidate("This is a line") == True
	assert candidate("test2") == True
	assert candidate("") == True
	assert candidate(line="this is a line") == True
	assert candidate(line="  ") == True
	assert candidate(line="This is not a comment") == True
	assert candidate("  #  ") == False
	assert candidate( " # comment" ) == False
	assert candidate(line="  #  ") == False
	assert candidate("  # foo  ") == False
	assert candidate(u"1\t2\t3")
	assert candidate(
    "This line has no comment"
) is True
	assert candidate("  foo") == True
	assert candidate(line="  # this is a line") == False
def test_check():
	check(predicate)
