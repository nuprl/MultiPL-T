def flat_list(l):
    """ Convert a nested list to a flat list """
	### Canonical solution below ###    
    try:
        return [item for sublist in l for item in sublist]
    except:
        return l

### Unit tests below ###
def check(candidate):
	assert candidate([[], []]) == []
	assert candidate( [[1,2],[3,4],[5,6]] ) == [1,2,3,4,5,6]
	assert candidate([]) == []
	assert candidate([[1,2,3], [4,5,6], [7,8,9]]) == [1,2,3,4,5,6,7,8,9]
	assert candidate([[1,2,3,4],[5,6],[7]]) == [1,2,3,4,5,6,7]
	assert candidate(1) == 1
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9]] ) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([[1,2,3,4],[5,6],[7],[8,9,10]]) == [1,2,3,4,5,6,7,8,9,10]
	assert candidate([2]) == [2]
	assert candidate( [[1,2,3],[4,5,6],[7,8,9]] ) == [1,2,3,4,5,6,7,8,9]
	assert candidate(list(range(3))) == [0, 1, 2]
	assert candidate([1,2,3]) == [1,2,3]
	assert candidate( [[1, 2, 3, 4], [5, 6]] ) == [1, 2, 3, 4, 5, 6]
	assert candidate( [[1, 2], [3, 4]] ) == [1, 2, 3, 4]
	assert candidate([[1,2,3,4]]) == [1,2,3,4]
	assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(
    [["a", "b"], ["c", "d"], ["e", "f"]]
) == ["a", "b", "c", "d", "e", "f"]
	assert candidate([[1,2,3],[4,5,6]]) == [1,2,3,4,5,6]
	assert candidate( [[1,2], [3,4], [5,6]] ) == [1, 2, 3, 4, 5, 6]
	assert candidate([[1, 2, 3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate([[1,2,3,4],[5,6]]) == [1,2,3,4,5,6]
	assert candidate(
    []
) == []
	assert candidate([[1, 2, 3], [4, 5]]) == [1, 2, 3, 4, 5]
	assert candidate( [] ) == []
	assert candidate([[1, 2], [3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate([[1, 2], [3, 4]]) == [1, 2, 3, 4]
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]] ) == [1,2,3,4,5,6,7,8,9]
	assert candidate(list(range(5))) == list(range(5))
	assert candidate([1]) == [1]
	assert candidate([list(range(10)), list(range(10))]) == list(range(10)) * 2
	assert candidate([list(range(10)), list(range(10, 20))]) == list(range(20))
	assert candidate([2, 3]) == [2, 3]
	assert candidate([[1]]) == [1]
	assert candidate(
    [1, 2, 3]
) == [1, 2, 3]
	assert candidate([[]]) == []
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]] ) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
	assert candidate( [[1,2,3],[4,5,6],[7,8,9],[10,11,12]] ) == [1,2,3,4,5,6,7,8,9,10,11,12]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate([[None, None]]) == [None, None]
	assert candidate([1, 2]) == [1, 2]
	assert candidate(None) == None
	assert candidate([[None]]) == [None]
	assert candidate(0) == 0
	assert candidate(list(range(10))) == list(range(10))
	assert candidate(2) == 2
	assert candidate( [1, 2, 3] ) == [1, 2, 3]
	assert candidate(None) is None
	assert candidate( [1,2,3] ) == [1,2,3]
	assert candidate([[1,2,3], [4,5,6]]) == [1,2,3,4,5,6]
	assert candidate([list(range(10)), list(range(5))]) == list(range(10)) + list(range(5))
	assert candidate([1,2,3,4]) == [1,2,3,4]
	assert candidate(
    [1]
) == [1]
	assert candidate(2.3) == 2.3
	assert candidate([list(range(10)), list(range(10, 20)), list(range(20, 30))]) == list(range(30))
	assert candidate([[1], [2], [3]]) == [1, 2, 3]
	assert candidate([[1,2,3],[4,5]]) == [1,2,3,4,5]
	assert candidate([[1,2,3]]) == [1,2,3]
def test_check():
	check(flat_list)
