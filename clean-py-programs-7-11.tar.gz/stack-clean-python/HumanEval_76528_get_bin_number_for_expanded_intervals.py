def get_bin_number_for_expanded_intervals(binsize_perc, expansion_factor):
    """Returns binnumber with bins being the binsize in percentage of the total interval size, before
    expanding it left and right with expansion factor. So if binsize percentage is 10, then the original
    interval contains 10 bins and after expansion with expansion factor e.g. 0.2 2 bins are added left and right
    so the total binnumber will be 14."""
    ### Canonical solution below ###
    return int((100 + expansion_factor * 100 * 2) / binsize_perc)


### Unit tests below ###
def check(candidate):
	assert candidate(10, 0.1) == 12
	assert candidate(10, 0.2) == 14
	assert candidate(10, 0.3) == 16
	assert candidate(50, 0.2) == 2
	assert candidate(100, 0.1) == 1
	assert candidate(10, 0.0) == 10
	assert candidate(10, 0.9) == 28
	assert candidate(10, 0.6) == 22
	assert candidate(50, 0.1) == 2
	assert candidate(10, 0.7) == 24
	assert candidate(10, 1.0) == 30
	assert candidate(10, 0.8) == 26
	assert candidate(10, 1) == 30
	assert candidate(10, 0) == 10
	assert candidate(5, 2) == 100
	assert candidate(10, 0.4) == 18
	assert candidate(10, 0.5) == 20
def test_check():
	check(get_bin_number_for_expanded_intervals)
