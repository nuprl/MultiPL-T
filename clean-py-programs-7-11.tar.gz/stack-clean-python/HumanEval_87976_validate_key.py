def validate_key(key, keyname='Key'):
    """ 
     Check input is valid key (Experiment id, metric name...)
     """
	### Canonical solution below ###    
    if not isinstance(key, str):
        msg = '{} must be str, given: {}{}'
        raise ValueError(msg.format(keyname, key, type(key)))
    if ':' in key:
        msg = '{} cannot contain colon (:): {}'
        raise ValueError(msg.format(keyname, key))
    return key

### Unit tests below ###
def check(candidate):
	assert candidate('a', 'key') == 'a'
	assert candidate('hello-world') == 'hello-world'
	assert candidate('1') == '1'
	assert candidate('hello_world') == 'hello_world'
	assert candidate('a') == 'a'
	assert candidate('test') == 'test'
	assert candidate('key with space') == 'key with space'
	assert candidate('123') == '123'
	assert candidate('123', 'key') == '123'
	assert candidate(key='a') == 'a'
	assert candidate('foo') == 'foo'
	assert candidate('hello.world') == 'hello.world'
	assert candidate('hello world') == 'hello world'
	assert candidate('a_key') == 'a_key'
	assert candidate('key') == 'key'
	assert candidate('123_abc') == '123_abc'
	assert candidate('hello') == 'hello'
	assert candidate('abc') == 'abc'
	assert candidate('0') == '0'
def test_check():
	check(validate_key)
