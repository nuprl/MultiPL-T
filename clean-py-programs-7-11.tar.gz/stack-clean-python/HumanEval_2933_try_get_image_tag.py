def try_get_image_tag(image):
    """ Tries to get an image tag. If there is no tag, returns an empty string."""
	### Canonical solution below ###    

    try:
        return image.tags[0]
    except:
        return ""

### Unit tests below ###
def check(candidate):
	assert candidate("") == ""
	assert candidate(None) == ""
	assert candidate(True) == ""
def test_check():
	check(try_get_image_tag)
