def safename(name):
    """Make name filesystem-safe."""
    ### Canonical solution below ###
    name = name.replace(u'/', u'-')
    name = name.replace(u':', u'-')
    return name


### Unit tests below ###
def check(candidate):
	assert candidate(u'foo-bar') == u'foo-bar'
	assert candidate(u'foo/bar/baz') == u'foo-bar-baz'
	assert candidate(u'a/b:c') == u'a-b-c'
	assert candidate(u'abc:def:ghi:jkl') == u'abc-def-ghi-jkl'
	assert candidate(u"foo/bar") == u"foo-bar"
	assert candidate(u'a') == u'a'
	assert candidate(u'abc/') == u'abc-'
	assert candidate(u'a:b/c:d/e') == u'a-b-c-d-e'
	assert candidate(u'123/45/67') == u'123-45-67'
	assert candidate(u'foo:bar/baz/qux') == u'foo-bar-baz-qux'
	assert candidate(u'foo:bar:baz/qux') == u'foo-bar-baz-qux'
	assert candidate(u'foo:bar/baz') == u'foo-bar-baz'
	assert candidate(u'12345') == u'12345'
	assert candidate(u'a:b') == u'a-b'
	assert candidate(u'123/45/67/89/ab/cd') == u'123-45-67-89-ab-cd'
	assert candidate(u'abc/def:ghi/jkl') == u'abc-def-ghi-jkl'
	assert candidate(u'foo/bar:baz/qux:quux') == u'foo-bar-baz-qux-quux'
	assert candidate(u'a:b/c:d/e:f') == u'a-b-c-d-e-f'
	assert candidate(u'/') == u'-'
	assert candidate(u'a:b:c:d') == u'a-b-c-d'
	assert candidate(u'foo:bar') == u'foo-bar'
	assert candidate(u'foo/bar:baz/qux') == u'foo-bar-baz-qux'
	assert candidate(u'123/45/67/89') == u'123-45-67-89'
	assert candidate(u'abc/def/ghi') == u'abc-def-ghi'
	assert candidate(u'a/b:c:d') == u'a-b-c-d'
	assert candidate(u'abc/def/ghi/jkl') == u'abc-def-ghi-jkl'
	assert candidate(u'Foo') == u'Foo'
	assert candidate(u'foo/') == u'foo-'
	assert candidate(u'foo/bar/') == u'foo-bar-'
	assert candidate(u'foo.bar.baz') == u'foo.bar.baz'
	assert candidate(u'Foo/Bar') == u'Foo-Bar'
	assert candidate(u'foo') == u'foo'
	assert candidate(u'foo.bar') == u'foo.bar'
	assert candidate(u'a:b/c:d') == u'a-b-c-d'
	assert candidate(u'123/45/67/89/ab/cd/ef/gh/ij') == u'123-45-67-89-ab-cd-ef-gh-ij'
	assert candidate(u'abc/def/ghi:jkl') == u'abc-def-ghi-jkl'
	assert candidate(u'foo/bar/baz/qux') == u'foo-bar-baz-qux'
	assert candidate(u'123/45/67/89/ab/cd/ef/gh') == u'123-45-67-89-ab-cd-ef-gh'
	assert candidate(u'abc:def') == u'abc-def'
	assert candidate(u'hello/world') == u'hello-world'
	assert candidate(u'/foo') == u'-foo'
	assert candidate(u'a/b') == u'a-b'
	assert candidate(u"foo:bar") == u"foo-bar"
	assert candidate(u'123/45/67/89/ab') == u'123-45-67-89-ab'
	assert candidate(u'Foo/Bar:Baz') == u'Foo-Bar-Baz'
	assert candidate(u':') == u'-'
	assert candidate(u'abc') == u'abc'
	assert candidate(u'a/b/c:d') == u'a-b-c-d'
	assert candidate(u'abc:def/ghi/jkl') == u'abc-def-ghi-jkl'
	assert candidate(u'a:b/c') == u'a-b-c'
	assert candidate(u'foo/bar') == u'foo-bar'
	assert candidate(u'a/b/c') == u'a-b-c'
	assert candidate(u'hello:world') == u'hello-world'
	assert candidate(u'foo:bar:baz') == u'foo-bar-baz'
	assert candidate(u'abc/def') == u'abc-def'
	assert candidate(u'foo/bar:baz') == u'foo-bar-baz'
	assert candidate(u'a:b:c') == u'a-b-c'
	assert candidate(u'foo/bar/baz/qux:quux') == u'foo-bar-baz-qux-quux'
	assert candidate(u'123/45/67/89/ab/cd/ef') == u'123-45-67-89-ab-cd-ef'
	assert candidate(u'foo_bar') == u'foo_bar'
	assert candidate(u'123/45') == u'123-45'
def test_check():
	check(safename)
