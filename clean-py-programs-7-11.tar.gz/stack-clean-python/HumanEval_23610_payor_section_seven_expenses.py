def payor_section_seven_expenses(responses, derived):
    """ Return the monthly cost of section 7 expense for the identified payor """
    ### Canonical solution below ###

    if derived['child_support_payor'] == 'Claimant 1':
        return derived['claimant_1_share']
    elif derived['child_support_payor'] == 'Claimant 2':
        return derived['claimant_2_share']
    return derived['total_section_seven_expenses']


### Unit tests below ###
def check(candidate):
	assert candidate(None, {'child_support_payor': 'Claimant 2', 'claimant_1_share': 1, 'claimant_2_share': 1}) == 1
	assert candidate(None, {'child_support_payor': 'Claimant 2', 'claimant_2_share': 100}) == 100
	assert candidate(None, {'child_support_payor': 'Claimant 2', 'claimant_2_share': 1}) == 1
	assert candidate(None, {'child_support_payor': 'Claimant 1', 'claimant_1_share': 1}) == 1
	assert candidate(None, {'child_support_payor': 'Claimant 1', 'claimant_1_share': 1, 'claimant_2_share': 1}) == 1
	assert candidate(None, {'child_support_payor': 'Claimant 1', 'claimant_1_share': 100}) == 100
	assert candidate(None, {'child_support_payor': 'Both', 'claimant_1_share': 1250, 'claimant_2_share': 1250, 'total_section_seven_expenses': 2500}) == 2500
	assert candidate(None, {'child_support_payor': 'Claimant 1', 'claimant_1_share': 2500, 'claimant_2_share': 0, 'total_section_seven_expenses': 2500}) == 2500
	assert candidate(
    [
        {'payor_name': 'Claimant 1', 'amount': 500},
        {'payor_name': 'Claimant 2', 'amount': 1000},
        {'payor_name': 'Claimant 3', 'amount': 2000},
    ],
    {'child_support_payor': 'Claimant 1', 'claimant_1_share': 500, 'claimant_2_share': 1000, 'total_section_seven_expenses': 2000}
) == 500
	assert candidate(None, {'child_support_payor': 'Claimant 2', 'claimant_1_share': 0, 'claimant_2_share': 2500, 'total_section_seven_expenses': 2500}) == 2500
	assert candidate(
    [
        {'payor_name': 'Claimant 1', 'amount': 500},
        {'payor_name': 'Claimant 2', 'amount': 1000},
        {'payor_name': 'Claimant 3', 'amount': 2000},
    ],
    {'child_support_payor': 'Claimant 2', 'claimant_1_share': 500, 'claimant_2_share': 1000, 'total_section_seven_expenses': 2000}
) == 1000
	assert candidate(None, {'child_support_payor': 'Claimant 2', 'claimant_2_share': 200}) == 200
	assert candidate(None, {'child_support_payor': 'Both', 'claimant_1_share': 50, 'claimant_2_share': 50, 'total_section_seven_expenses': 100}) == 100
	assert candidate(None, {'child_support_payor': 'Claimant 1', 'claimant_1_share': 0, 'claimant_2_share': 0}) == 0
def test_check():
	check(payor_section_seven_expenses)
