def escape_html(unescaped_html_data):
    """ This functions escapes an unescaped HTML string.
     
     Args:
     unescaped_html_data: str. Unescaped HTML string to be escaped.
     
     Returns:
     str. Escaped HTML string.
     """
	### Canonical solution below ###    
    # Replace list to escape html strings.
    replace_list_for_escaping = [
        ('&', '&amp;'),
        ('"', '&quot;'),
        ('\'', '&#39;'),
        ('<', '&lt;'),
        ('>', '&gt;')
    ]
    escaped_html_data = unescaped_html_data
    for replace_tuple in replace_list_for_escaping:
        escaped_html_data = escaped_html_data.replace(
            replace_tuple[0], replace_tuple[1])

    return escaped_html_data

### Unit tests below ###
def check(candidate):
	assert candidate('hello world!') == 'hello world!'
	assert candidate('The quick brown fox jumps over the lazy dog') == 'The quick brown fox jumps over the lazy dog'
	assert candidate(
    '<script>alert("Hello World!");</script>') == (
        '&lt;script&gt;alert(&quot;Hello World!&quot;);&lt;/script&gt;')
	assert candidate(
    '<div>Hello</div>') == '&lt;div&gt;Hello&lt;/div&gt;'
	assert candidate(
    'The following string needs to be escaped: <script>alert(1)</script>') == (
        'The following string needs to be escaped: &lt;script&gt;alert(1)&lt;/script&gt;')
	assert candidate(
    '<b>Hello, <i>World!</i></b>') == (
        '&lt;b&gt;Hello, &lt;i&gt;World!&lt;/i&gt;&lt;/b&gt;')
	assert candidate(
    '<h1>Hello <b>World</b>!</h1>') == (
    '&lt;h1&gt;Hello &lt;b&gt;World&lt;/b&gt;!&lt;/h1&gt;')
	assert candidate(
    '<h1>Hello, XSS<script>alert(\'This is an XSS attempt.\');</script></h1>') == (
        '&lt;h1&gt;Hello, XSS&lt;script&gt;alert(&#39;This is an XSS attempt.&#39;);'
        '&lt;/script&gt;&lt;/h1&gt;')
	assert candidate(
    '<p>Hello</p>') == '&lt;p&gt;Hello&lt;/p&gt;'
	assert candidate(
    'Hello, <b>World!</b>') == (
        'Hello, &lt;b&gt;World!&lt;/b&gt;')
	assert candidate(
    '<script>alert("hello world");</script>') == (
        '&lt;script&gt;alert(&quot;hello world&quot;);&lt;/script&gt;')
	assert candidate('Hello World!') == 'Hello World!'
	assert candidate(
    'This is a test of <em>html</em> escaping.') == (
        'This is a test of &lt;em&gt;html&lt;/em&gt; escaping.')
	assert candidate(
    '<a href="http://www.google.com">Click Here</a>') == (
        '&lt;a href=&quot;http://www.google.com&quot;&gt;Click Here&lt;/a&gt;')
	assert candidate(
    '<b>Hello, World!</b>') == (
        '&lt;b&gt;Hello, World!&lt;/b&gt;')
	assert candidate(
    '<p>This is a paragraph</p>') == '&lt;p&gt;This is a paragraph&lt;/p&gt;'
	assert candidate(
    'abc') == 'abc', 'Error: candidate(abc) does not return abc'
	assert candidate(
    '<a href="http://www.google.com">Google</a>') == (
        '&lt;a href=&quot;http://www.google.com&quot;&gt;Google&lt;/a&gt;')
	assert candidate(
    '<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>') == (
        '&lt;script src=&quot;https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js&quot;&gt;&lt;/script&gt;')
	assert candidate(
    'abc<def') == 'abc&lt;def', 'Error: candidate(abc<def) does not return abc&lt;def'
	assert candidate(
    'abc>def') == 'abc&gt;def', 'Error: candidate(abc>def) does not return abc&gt;def'
	assert candidate(
    'The <a href="https://www.google.com">link</a> to google') == (
        'The &lt;a href=&quot;https://www.google.com&quot;&gt;link&lt;/a&gt; '
        'to google')
	assert candidate(
    'Hey <em>how</em> are you?') == 'Hey &lt;em&gt;how&lt;/em&gt; are you?'
	assert candidate('Hello, XSS') == 'Hello, XSS'
	assert candidate(
    '<p>This is a test string for &quot;testing&quot; '
    '&lt;b&gt;html&lt;/b&gt; &lt;script&gt;tags&lt;/script&gt;.</p>') == (
    '&lt;p&gt;This is a test string for &amp;quot;testing&amp;quot; '
    '&amp;lt;b&amp;gt;html&amp;lt;/b&amp;gt; '
    '&amp;lt;script&amp;gt;tags&amp;lt;/script&amp;gt;.&lt;/p&gt;')
	assert candidate(
    'Hey <script>alert(1);</script>') == 'Hey &lt;script&gt;alert(1);&lt;/script&gt;'
	assert candidate(
    'hello <a href="https://www.google.com">world</a>!') == (
        'hello &lt;a href=&quot;https://www.google.com&quot;&gt;world&lt;/a&gt;!')
	assert candidate(
    'This is an unescaped html string with & < > " \' characters.') == (
        'This is an unescaped html string with &amp; &lt; &gt; &quot; &#39; '
        'characters.')
	assert candidate(
    'abc <em>123</em>') == 'abc &lt;em&gt;123&lt;/em&gt;'
	assert candidate('hello\tworld!') == 'hello\tworld!'
	assert candidate(
    'abc\'def') == 'abc&#39;def', 'Error: candidate(abc\'def) does not return abc&#39;def'
	assert candidate(
    '<script>alert("Hello, World!");</script>') == (
        '&lt;script&gt;alert(&quot;Hello, World!&quot;);&lt;/script&gt;')
	assert candidate(
    '<script>alert(\'This is an XSS attempt.\');</script>') == (
        '&lt;script&gt;alert(&#39;This is an XSS attempt.&#39;);&lt;/script&gt;')
	assert candidate(
    'This string contains an unescaped html string & a string without html tags.') == (
        'This string contains an unescaped html string &amp; a string without html tags.'
    )
	assert candidate(
    'The quick brown fox jumps over the lazy dog') == 'The quick brown fox jumps over the lazy dog'
	assert candidate(
    'This is a test string with <, &, > and " characters.') == (
        'This is a test string with &lt;, &amp;, &gt; and &quot; characters.')
	assert candidate('<script>alert("hello")</script>') == '&lt;script&gt;alert(&quot;hello&quot;)&lt;/script&gt;'
	assert candidate(
    'The <em>cat</em> sat on the <strong>mat</strong>.') == (
    'The &lt;em&gt;cat&lt;/em&gt; sat on the &lt;strong&gt;mat&lt;/strong&gt;.')
	assert candidate(
    'This string contains an unescaped html string &amp; a string without html tags.') == (
        'This string contains an unescaped html string &amp;amp; a string without html tags.'
    )
	assert candidate('<h1>Hello, XSS</h1>') == (
    '&lt;h1&gt;Hello, XSS&lt;/h1&gt;')
	assert candidate(
    'abc&def') == 'abc&amp;def', 'Error: candidate(abc&def) does not return abc&amp;def'
	assert candidate(
    '<p>This is a paragraph</p><a href="http://google.com">Link</a>') == (
        '&lt;p&gt;This is a paragraph&lt;/p&gt;'
        '&lt;a href=&quot;http://google.com&quot;&gt;Link&lt;/a&gt;')
	assert candidate(
    'Hello, World!') == (
        'Hello, World!')
	assert candidate(
    '<p>Hello</p>') == '&lt;p&gt;Hello&lt;/p&gt;', (
    'Failed to escape HTML string')
	assert candidate(
    'This is a test string for &quot;testing&quot; &lt;b&gt;html&lt;/b&gt; '
    '&lt;script&gt;tags&lt;/script&gt;.') == (
    'This is a test string for &amp;quot;testing&amp;quot; '
    '&amp;lt;b&amp;gt;html&amp;lt;/b&amp;gt; '
    '&amp;lt;script&amp;gt;tags&amp;lt;/script&amp;gt;.')
	assert candidate(
    '<a href="https://www.google.com/search?q=python+string+escape">Google</a>') == (
    '&lt;a href=&quot;https://www.google.com/search?q=python+string+escape&quot;&gt;Google&lt;/a&gt;')
	assert candidate('hello\nworld!') == 'hello\nworld!'
	assert candidate('Hello, <b>World</b>') == 'Hello, &lt;b&gt;World&lt;/b&gt;'
	assert candidate(
    '<a href="https://www.google.com">world</a>!') == (
        '&lt;a href=&quot;https://www.google.com&quot;&gt;world&lt;/a&gt;!')
	assert candidate(
    'abc"def') == 'abc&quot;def', 'Error: candidate(abc"def) does not return abc&quot;def'
	assert candidate(
    '<p>This is some text.</p> <p>This is more text.</p>') == (
        '&lt;p&gt;This is some text.&lt;/p&gt; &lt;p&gt;This is more '
        'text.&lt;/p&gt;')
	assert candidate(
    '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>') == (
    '&lt;script src=&quot;https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js&quot;&gt;&lt;/script&gt;')
	assert candidate(
    '<p>This is a test for &quot;escaped html string&quot;.</p>') == (
        '&lt;p&gt;This is a test for &amp;quot;escaped html string&amp;quot;'
        '.&lt;/p&gt;')
def test_check():
	check(escape_html)
