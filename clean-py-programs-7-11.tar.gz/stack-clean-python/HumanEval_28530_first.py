def first(collection, match_function):
    """ Returns the first item in the collection that satisfies the match function """
	### Canonical solution below ###  
  return next((item for item in collection if match_function(item)), None)

### Unit tests below ###
def check(candidate):
	assert candidate(range(10), lambda x: x == 3) == 3
	assert candidate( [1,2,3,4], lambda x: x % 2 == 1 ) == 1
	assert candidate( [1,2,3,4], lambda x: x % 4 == 0 ) == 4
	assert candidate( [], lambda x: x > 0) == None
	assert candidate(list(range(10)), lambda x: x == 5) == 5
	assert candidate(list(range(10)), lambda x: x > 10) == None
	assert candidate(range(1, 1000000), lambda x: x == 1000000) is None
	assert candidate(range(10), lambda x: x % 3 == 1) == 1
	assert candidate(range(10), lambda x: x == 5) == 5
	assert candidate(range(1, 100), lambda x: x > 1000) is None
	assert candidate(range(10), lambda x: x > 100) == None
	assert candidate(collection=[1,2,3], match_function=lambda x: x == 4) == None
	assert candidate([], lambda i: i > 100) is None
	assert candidate(range(10), lambda i: i > 4 and i % 2 == 0) == 6
	assert candidate(range(10), lambda x: x % 3 == 2) == 2
	assert candidate(collection=[1,2,3], match_function=lambda x: x == 2) == 2
	assert candidate( [1,2,3,4], lambda x: x > 2) == 3
	assert candidate(range(1, 1000000), lambda x: x == 100000) == 100000
	assert candidate(list(range(0)), lambda x: x > -1) == None
	assert candidate( [1,2,3,4], lambda x: x % 3 == 0 ) == 3
	assert candidate(range(1, 10), lambda x: x % 2 == 1) == 1
	assert candidate( [1,2,3,4], lambda x: x > 5) == None
	assert candidate(list(range(10)), lambda x: x > 5) == 6
	assert candidate(['3/11/2020', '3/12/2020', '3/13/2020'], lambda x: x.startswith('4')) == None
	assert candidate(range(10), lambda i: i > 10) is None
	assert candidate(list(range(10)), lambda x: x % 2 == 0) == 0
	assert candidate(range(10), lambda x: x % 2 == 0) == 0
	assert candidate( [1,2,3,4], lambda x: x > 0) == 1
	assert candidate( [1,2,3,4], lambda x: x % 2 == 0 ) == 2
	assert candidate( [1,2,3], lambda x: x == 4) == None
	assert candidate(range(1, 100), lambda x: x % 3 == 0) == 3
	assert candidate(range(10), lambda x: x > 1000) is None
	assert candidate(range(100), lambda x: x > 100) is None
	assert candidate(range(5), lambda x: x % 2 == 0) == 0
	assert candidate(range(5), lambda x: x > 5) is None
	assert candidate(range(1, 10), lambda x: x > 10) == None
	assert candidate(list(range(10)), lambda x: x == 100) == None
	assert candidate(range(10), lambda x: x > 100) is None
	assert candidate(range(1, 100), lambda x: x % 10 == 0) == 10
	assert candidate( [], lambda x: x % 5 == 0 ) == None
	assert candidate(range(10), lambda x: x > 1000) == None
	assert candidate(list(range(10)), lambda x: x > 100) == None
	assert candidate(range(10), lambda i: i > 100) is None
	assert candidate(list(range(10)), lambda x: x > -1) == 0
	assert candidate(range(10), lambda x: x > 5) == 6
	assert candidate(range(5), lambda x: x % 2 == 1) == 1
	assert candidate(range(1, 100), lambda x: x > 100) == None
	assert candidate(range(10), lambda x: x % 3 == 3) == None
	assert candidate(range(10), lambda x: x > 10) is None
	assert candidate(range(1, 10), lambda x: x % 2 == 0) == 2
	assert candidate(range(10), lambda i: i > 5) == 6
	assert candidate(range(10), lambda x: x % 3 == 0) == 0
	assert candidate(range(10), lambda x: x > 10) == None
	assert candidate(range(10), lambda x: x % 5 == 0) == 0
	assert candidate(range(10), lambda x: x == 100) == None
	assert candidate(range(10), lambda x: x == 100) is None
	assert candidate(list(range(0)), lambda x: x > 10) == None
	assert candidate(range(100), lambda x: x % 3 == 0) == 0
	assert candidate(range(10), lambda x: x == 11) is None
	assert candidate( [1,2,3,4], lambda x: x % 5 == 0 ) == None
	assert candidate( [1,2,3], lambda x: x == 2) == 2
	assert candidate(range(10), lambda x: x > 4) == 5
def test_check():
	check(first)
