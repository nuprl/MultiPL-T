def _build_custom_vocab(tokens, vocab_length):
    """ 
     Helper function for building custom vocab
     """
	### Canonical solution below ###    
    custom_vocab = {}
    cur_key = vocab_length
    for token in tokens:
        custom_vocab[token] = cur_key
        cur_key += 1
    
    return custom_vocab

### Unit tests below ###
def check(candidate):
	assert candidate(tokens=['a', 'b', 'c'], vocab_length=10) == {
    'a': 10,
    'b': 11,
    'c': 12
}
	assert candidate(tokens=['a', 'b', 'c', 'd', 'e'], vocab_length=5) == {'a': 5, 'b': 6, 'c': 7, 'd': 8, 'e': 9}
	assert candidate(tokens=["a", "b", "c"], vocab_length=5) == {
    "a": 5,
    "b": 6,
    "c": 7,
}
	assert candidate(tokens=["<UNK>"], vocab_length=1) == {
    "<UNK>": 1
}
	assert candidate(tokens=['a', 'b', 'c'], vocab_length=3) == {'a': 3, 'b': 4, 'c': 5}
	assert candidate(tokens=['a', 'b', 'c', 'd', 'e'], vocab_length=10) == {
    'a': 10,
    'b': 11,
    'c': 12,
    'd': 13,
    'e': 14,
}
	assert candidate(tokens=["a", "b", "c"], vocab_length=0) == {
    "a": 0,
    "b": 1,
    "c": 2,
}
	assert candidate(tokens=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'], vocab_length=5) == {'a': 5, 'b': 6, 'c': 7, 'd': 8, 'e': 9, 'f': 10, 'g': 11, 'h': 12, 'i': 13}
	assert candidate(tokens=["a", "b", "c"], vocab_length=1000) == {
    "a": 1000,
    "b": 1001,
    "c": 1002,
}
	assert candidate(tokens=['a', 'b', 'c'], vocab_length=5) == {
    'a': 5,
    'b': 6,
    'c': 7
}
	assert candidate(tokens=['the', 'the'], vocab_length=0) == {
    'the': 1,
}
	assert candidate(tokens=['a', 'b', 'c', 'd'], vocab_length=5) == {'a': 5, 'b': 6, 'c': 7, 'd': 8}
	assert candidate(tokens=['a', 'b', 'c'], vocab_length=100) == {
    'a': 100,
    'b': 101,
    'c': 102,
}
def test_check():
	check(_build_custom_vocab)
