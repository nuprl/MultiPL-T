def dot_product(u, v):
    """Computes the dot product of two vectors u and v, each represented 
    as a tuple or list of coordinates. Assume the two vectors are the
    same length."""
    ### Canonical solution below ###
    product = 0
    for n in range(len(u)):
        product += u[n]*v[n]
    return product


### Unit tests below ###
def check(candidate):
	assert candidate( (1, 2, 3), (4, 5, 6, 7, 8) ) == 32
	assert candidate( (1, 2, 3), (-1, -2, -3) ) == -14
	assert candidate( (0, 0, 0), (0, 0, 0) ) == 0
	assert candidate( (1,2,3), (4,5,6,7) ) == 32
	assert candidate( (0,0), (0,0) ) == 0
	assert candidate( (1, 0), (0, 1) ) == 0
	assert candidate( (1,2), (3,4) ) == 11
	assert candidate( (1, 0, 0), (0, 1, 0) ) == 0
	assert candidate( (0, 1), (0, 1) ) == 1
	assert candidate( (1,2,3), (4,5,6) ) == 32
	assert candidate( (1, 2), (3, 4) ) == 11
	assert candidate( (1, 1, 1), (2, 2, 2) ) == 6
	assert candidate( (1, 2, 3), (1, 2, 3) ) == 14
	assert candidate( (1, 1, 1), (1, 1, 1) ) == 3
	assert candidate( (0,0,0), (1,0,0) ) == 0
	assert candidate( [1,2,3], [4,5,6] ) == 32
	assert candidate( (1, 0, 0), (0, 5, 0) ) == 0
	assert candidate( (1,2,3,4), (5,6,7,8) ) == 70
	assert candidate( [1, 2, 3], [4, 5, 6] ) == 32
	assert candidate( (1, 1), (0, 0) ) == 0
	assert candidate( (1, 2, 3), (4, 5, 6, 7, 8, 9) ) == 32
	assert candidate( (1, 1), (2, 2) ) == 4
	assert candidate( (0, 0), (3, 4) ) == 0
	assert candidate( (0, 2), (2, 0) ) == 0
	assert candidate( (1, 0), (1, 0) ) == 1
	assert candidate( (1, 1), (1, 1) ) == 2
	assert candidate( (1, 2, 3), (4, 5, 6) ) == 32
	assert candidate( (1, 1), (-1, -1) ) == -2
	assert candidate( (0.5, 1.0, 3.0), (0.5, 2.0, 1.5) ) == 6.75
	assert candidate( (1, 2), (1, 2) ) == 5
	assert candidate( (), () ) == 0
	assert candidate( (1, 2, 3), (0, 0, 0) ) == 0
	assert candidate( (1, 2, 3, 4), (3, 2, 1, 1) ) == 14
	assert candidate( (), (1, 2, 3) ) == 0
	assert candidate( (1, 2, 3), (3, 2, 1) ) == 10
	assert candidate( [1, 2], [3, 4] ) == 11
	assert candidate( (1, 2, 3), (4, 5, 6, 7) ) == 32
def test_check():
	check(dot_product)
