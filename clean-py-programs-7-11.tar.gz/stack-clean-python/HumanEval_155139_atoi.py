def atoi(text):
    """
    Turn an int string into a number, but leave a non-int string alone.
    """
    ### Canonical solution below ###
    return int(text) if text.isdigit() else text


### Unit tests below ###
def check(candidate):
	assert candidate('abc') == 'abc'
	assert candidate("1234567890") == 1234567890
	assert candidate("3") == 3
	assert candidate('1234') == 1234
	assert candidate('1') == 1
	assert candidate('10') == 10
	assert candidate("abc") == "abc"
	assert candidate("100.1.1") == "100.1.1"
	assert candidate("hi") == "hi"
	assert candidate("100") == 100
	assert candidate('one') == 'one'
	assert candidate("hello") == "hello"
	assert candidate("1") == 1
	assert candidate('1,000') == '1,000'
	assert candidate("12a") == "12a"
	assert candidate("12") == 12
	assert candidate("123") == 123
	assert candidate('100') == 100
	assert candidate("456") == 456
	assert candidate('1000.00') == '1000.00'
	assert candidate('123') == 123
	assert candidate("12.5") == "12.5"
	assert candidate('00001234') == 1234
	assert candidate("10") == 10
	assert candidate("100.0") == "100.0"
	assert candidate("99") == 99
	assert candidate('hi') == 'hi'
	assert candidate('10.0') == '10.0'
	assert candidate('foo') == 'foo'
	assert candidate('1.1') == '1.1'
	assert candidate("five") == "five"
	assert candidate("100.1") == "100.1"
	assert candidate('10000') == 10000
	assert candidate("foo") == "foo"
	assert candidate('100,000') == '100,000'
	assert candidate("123456") == 123456
	assert candidate('a123') == 'a123'
	assert candidate('1000') == 1000
	assert candidate('1000000') == 1000000
	assert candidate('0') == 0
	assert candidate("5") == 5
def test_check():
	check(atoi)
