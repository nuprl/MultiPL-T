def parse_blob_connection_str(conn_str):
    """ 
     :param conn_str: A Blob Storage connection str
     :type conn_str: str
     Returns a dict of the components making up the string
     """
	### Canonical solution below ###    
    conn_str = conn_str.rstrip(";")
    conn_settings = [s.split("=", 1) for s in conn_str.split(";")]
    if any(len(tup) != 2 for tup in conn_settings):
        raise ValueError("Connection string is either blank or malformed.")
    return dict(conn_settings)

### Unit tests below ###
def check(candidate):
	assert candidate(
    "AccountName=accountName;AccountKey=accountKey;EndpointSuffix=core.windows.net") == {
        'AccountName': 'accountName',
        'AccountKey': 'accountKey',
        'EndpointSuffix': 'core.windows.net'
    }
	assert candidate(
    "AccountName=account;AccountKey=key;EndpointSuffix=core.windows.net;") == \
    {
        "AccountName": "account",
        "AccountKey": "key",
        "EndpointSuffix": "core.windows.net"
    }
	assert candidate(
    "AccountName=account;AccountKey=key;EndpointSuffix=core.windows.net") == \
    {
        "AccountName": "account",
        "AccountKey": "key",
        "EndpointSuffix": "core.windows.net"
    }
	assert candidate(
    "AccountName=devstoreaccount1;"
    "AccountKey=<KEY>"
    "Z6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;"
    "BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"
) == {
    "AccountName": "devstoreaccount1",
    "AccountKey": "<KEY>"
    "Z6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==",
    "BlobEndpoint": "http://127.0.0.1:10000/devstoreaccount1",
}
	assert candidate(
    "AccountName=foo;AccountKey=bar;DefaultEndpointsProtocol=https;EndpointSuffix=baz"
) == {
    "AccountName": "foo",
    "AccountKey": "bar",
    "DefaultEndpointsProtocol": "https",
    "EndpointSuffix": "baz",
}
	assert candidate("AccountName=accountName;AccountKey=accountKey;EndpointSuffix=core.windows.net;") == {
        'AccountName': 'accountName',
        'AccountKey': 'accountKey',
        'EndpointSuffix': 'core.windows.net'
    }
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=account;AccountKey=key;EndpointSuffix=core.windows.net") == {
    'AccountName': 'account',
    'AccountKey': 'key',
    'DefaultEndpointsProtocol': 'https',
    'EndpointSuffix': 'core.windows.net'}
	assert candidate("AccountKey=accountKey") == {
        'AccountKey': 'accountKey'
    }
	assert candidate(
    "AccountName=testaccount;AccountKey=testkey;DefaultEndpointsProtocol=https;EndpointSuffix=core.windows.net") == {
        "DefaultEndpointsProtocol": "https",
        "AccountName": "testaccount",
        "AccountKey": "testkey",
        "EndpointSuffix": "core.windows.net"
    }
	assert candidate(
    "AccountName=accountname;AccountKey=accountkey;EndpointSuffix=core.windows.net;"
) == {
    "AccountName": "accountname",
    "AccountKey": "accountkey",
    "EndpointSuffix": "core.windows.net",
}
	assert candidate(
    "AccountName=foo;DefaultEndpointsProtocol=https;AccountKey=bar;EndpointSuffix=baz"
) == {
    "AccountName": "foo",
    "AccountKey": "bar",
    "DefaultEndpointsProtocol": "https",
    "EndpointSuffix": "baz",
}
	assert candidate(
    "AccountName=foo;AccountKey=bar;DefaultEndpointsProtocol=https;EndpointSuffix=core.windows.net") == {
        "AccountName": "foo",
        "AccountKey": "bar",
        "DefaultEndpointsProtocol": "https",
        "EndpointSuffix": "core.windows.net",
    }
	assert candidate("AccountName=accountName;EndpointSuffix=core.windows.net") == {
        'AccountName': 'accountName',
        'EndpointSuffix': 'core.windows.net'
    }
	assert candidate(
    "DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=<KEY>;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;") == {
    'DefaultEndpointsProtocol': 'http',
    'AccountName': 'devstoreaccount1',
    'AccountKey': '<KEY>',
    'BlobEndpoint': 'http://127.0.0.1:10000/devstoreaccount1',
}
	assert candidate(
    "AccountName=foo;AccountKey=bar;EndpointSuffix=baz;DefaultEndpointsProtocol=https"
) == {
    "AccountName": "foo",
    "AccountKey": "bar",
    "DefaultEndpointsProtocol": "https",
    "EndpointSuffix": "baz",
}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=devstoreaccount1;AccountKey=<KEY>;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;QueueEndpoint=http://127.0.0.1:10001/devstoreaccount1;TableEndpoint=http://127.0.0.1:10002/devstoreaccount1;"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "devstoreaccount1",
    "AccountKey": "<KEY>",
    "BlobEndpoint": "http://127.0.0.1:10000/devstoreaccount1",
    "QueueEndpoint": "http://127.0.0.1:10001/devstoreaccount1",
    "TableEndpoint": "http://127.0.0.1:10002/devstoreaccount1",
}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountKey=key;AccountName=account;EndpointSuffix=core.windows.net") == {
    'AccountName': 'account',
    'AccountKey': 'key',
    'DefaultEndpointsProtocol': 'https',
    'EndpointSuffix': 'core.windows.net'}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=foo;AccountKey=bar;EndpointSuffix=baz"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "foo",
    "AccountKey": "bar",
    "EndpointSuffix": "baz",
}
	assert candidate("AccountName=accountName;AccountKey=accountKey") == {
        'AccountName': 'accountName',
        'AccountKey': 'accountKey'
    }
	assert candidate(
    "AccountName=account;AccountKey=key;DefaultEndpointsProtocol=https;EndpointSuffix=core.windows.net") == {
    'AccountName': 'account',
    'AccountKey': 'key',
    'DefaultEndpointsProtocol': 'https',
    'EndpointSuffix': 'core.windows.net'}
	assert candidate("AccountName=accountName") == {
        'AccountName': 'accountName'
    }
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountKey=bar;AccountName=foo;EndpointSuffix=baz"
) == {
    "AccountName": "foo",
    "AccountKey": "bar",
    "DefaultEndpointsProtocol": "https",
    "EndpointSuffix": "baz",
}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=foo;EndpointSuffix=baz;AccountKey=bar"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "foo",
    "AccountKey": "bar",
    "EndpointSuffix": "baz",
}
	assert candidate(
    "AccountName=testaccount;EndpointSuffix=core.windows.net;AccountKey=testkey;DefaultEndpointsProtocol=https") == {
        "DefaultEndpointsProtocol": "https",
        "AccountName": "testaccount",
        "AccountKey": "testkey",
        "EndpointSuffix": "core.windows.net"
    }
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=accountname;AccountKey=accountkey;EndpointSuffix=core.windows.net"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "accountname",
    "AccountKey": "accountkey",
    "EndpointSuffix": "core.windows.net",
}
	assert candidate(
    "AccountName=foo;DefaultEndpointsProtocol=https;EndpointSuffix=baz;AccountKey=bar"
) == {
    "AccountName": "foo",
    "AccountKey": "bar",
    "DefaultEndpointsProtocol": "https",
    "EndpointSuffix": "baz",
}
	assert candidate(
    "AccountName=name;AccountKey=key;DefaultEndpointsProtocol=http;BlobEndpoint=http://url.com;QueueEndpoint=http://url.com;TableEndpoint=http://url.com;FileEndpoint=http://url.com;"
) == {
    "AccountName": "name",
    "AccountKey": "key",
    "DefaultEndpointsProtocol": "http",
    "BlobEndpoint": "http://url.com",
    "QueueEndpoint": "http://url.com",
    "TableEndpoint": "http://url.com",
    "FileEndpoint": "http://url.com",
}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=accountname;AccountKey=accountkey;EndpointSuffix=core.windows.net;"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "accountname",
    "AccountKey": "accountkey",
    "EndpointSuffix": "core.windows.net",
}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=devstoreaccount1;AccountKey=<KEY>;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "devstoreaccount1",
    "AccountKey": "<KEY>",
    "BlobEndpoint": "http://127.0.0.1:10000/devstoreaccount1",
}
	assert candidate("AccountName=account;AccountKey=key;") == \
    {
        "AccountName": "account",
        "AccountKey": "key"
    }
	assert candidate("AccountName=accountName;AccountKey=accountKey;") == {
        'AccountName': 'accountName',
        'AccountKey': 'accountKey'
    }
	assert candidate(
    "AccountName=name;AccountKey=key;EndpointSuffix=suffix;") == {
        "AccountName": "name",
        "AccountKey": "key",
        "EndpointSuffix": "suffix"
    }
	assert candidate("AccountName=devstoreaccount1;AccountKey=<KEY>;") == {
    "AccountName": "devstoreaccount1",
    "AccountKey": "<KEY>",
}
	assert candidate("AccountName=foo;AccountKey=bar;DefaultEndpointsProtocol=https;EndpointSuffix=core.windows.net") == {
    "AccountName": "foo",
    "AccountKey": "bar",
    "DefaultEndpointsProtocol": "https",
    "EndpointSuffix": "core.windows.net",
}
	assert candidate("AccountName=accountName;EndpointSuffix=core.windows.net;") == {
        'AccountName': 'accountName',
        'EndpointSuffix': 'core.windows.net'
    }
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=accountName;AccountKey=accountKey;EndpointSuffix=core.windows.net"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "accountName",
    "AccountKey": "accountKey",
    "EndpointSuffix": "core.windows.net",
}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=foo;AccountKey=bar") == {
        "DefaultEndpointsProtocol": "https",
        "AccountName": "foo",
        "AccountKey": "bar"
    }
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=account;AccountKey=key;EndpointSuffix=core.windows.net;") == {
    'AccountName': 'account',
    'AccountKey': 'key',
    'DefaultEndpointsProtocol': 'https',
    'EndpointSuffix': 'core.windows.net'}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=foo;AccountKey=bar;EndpointSuffix=baz"
) == {
    "AccountName": "foo",
    "AccountKey": "bar",
    "DefaultEndpointsProtocol": "https",
    "EndpointSuffix": "baz",
}
	assert candidate("AccountName=name;AccountKey=key") == {
    "AccountName": "name",
    "AccountKey": "key",
}
	assert candidate(
    "AccountName=testaccount;AccountKey=testkey;EndpointSuffix=core.windows.net"
) == {
    "AccountName": "testaccount",
    "AccountKey": "testkey",
    "EndpointSuffix": "core.windows.net",
}
	assert candidate("BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;") == {
    "BlobEndpoint": "http://127.0.0.1:10000/devstoreaccount1",
}
	assert candidate(
    "AccountName=accountname;AccountKey=accountkey;EndpointSuffix=core.windows.net"
) == {
    "AccountName": "accountname",
    "AccountKey": "accountkey",
    "EndpointSuffix": "core.windows.net",
}
	assert candidate("DefaultEndpointsProtocol=https;AccountName=devstoreaccount1;AccountKey=<KEY>;") == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "devstoreaccount1",
    "AccountKey": "<KEY>",
}
	assert candidate(
    "AccountName=foo;AccountKey=bar;") == {
        "AccountName": "foo",
        "AccountKey": "bar",
    }
	assert candidate("AccountName=account;AccountKey=key") == \
    {
        "AccountName": "account",
        "AccountKey": "key"
    }
	assert candidate(
    "AccountName=name;AccountKey=key;EndpointSuffix=suffix") == {
        "AccountName": "name",
        "AccountKey": "key",
        "EndpointSuffix": "suffix"
    }
	assert candidate("AccountName=name;AccountKey=key;") == {
    "AccountName": "name",
    "AccountKey": "key",
}
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=devstoreaccount1;"
    "AccountKey=<KEY>"
    "Z6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;"
    "BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;"
) == {
    "DefaultEndpointsProtocol": "https",
    "AccountName": "devstoreaccount1",
    "AccountKey": "<KEY>"
    "Z6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==",
    "BlobEndpoint": "http://127.0.0.1:10000/devstoreaccount1",
}
	assert candidate("EndpointSuffix=core.windows.net") == {
        'EndpointSuffix': 'core.windows.net'
    }
	assert candidate(
    "AccountName=foo;AccountKey=bar;EndpointSuffix=baz") == {
        "AccountName": "foo",
        "AccountKey": "bar",
        "EndpointSuffix": "baz",
    }
	assert candidate(
    "DefaultEndpointsProtocol=https;AccountName=testaccount;AccountKey=testkey;EndpointSuffix=core.windows.net") == {
        "DefaultEndpointsProtocol": "https",
        "AccountName": "testaccount",
        "AccountKey": "testkey",
        "EndpointSuffix": "core.windows.net"
    }
def test_check():
	check(parse_blob_connection_str)
