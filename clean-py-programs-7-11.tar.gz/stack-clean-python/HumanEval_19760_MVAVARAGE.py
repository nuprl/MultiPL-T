def MVAVARAGE(List, N):
    """ 
     input:
     List- a list
     N- N point avarage
     Returns:
     N point avarage of the List
     
     """
	### Canonical solution below ###    
    cumsum, moving_aves = [0], []
    
    for i, x in enumerate(List, 1):
        cumsum.append(cumsum[i-1] + x)
        if i>=N:
            moving_ave = (cumsum[i] - cumsum[i-N])/N
        else:
            moving_ave = 0
        moving_aves.append(moving_ave)
    return(moving_aves)

### Unit tests below ###
def check(candidate):
	assert candidate([1,1,1,1,1,1,1,1,1,1], 3)
	assert candidate( [1,2,3,4,5], 1) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1) == [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]
	assert candidate(List=[1,2,3,4,5], N=1) == [1,2,3,4,5]
	assert candidate([1,1,1,1,1,1,1,1,1,1], 1) == [1,1,1,1,1,1,1,1,1,1], "mvavarage test5"
def test_check():
	check(MVAVARAGE)
