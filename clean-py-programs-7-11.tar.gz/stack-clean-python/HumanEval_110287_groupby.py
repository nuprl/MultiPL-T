def groupby(entities, dxfattrib='', key=None):
    """
    Groups a sequence of DXF entities by an DXF attribute like 'layer', returns the result as dict. Just specify
    argument `dxfattrib` OR a `key` function.

    Args:
        entities: sequence of DXF entities to group by a key
        dxfattrib: grouping DXF attribute like 'layer'
        key: key function, which accepts a DXFEntity as argument, returns grouping key of this entity or None for ignore
             this object. Reason for ignoring: a queried DXF attribute is not supported by this entity

    Returns:
        dict
    """
    ### Canonical solution below ###
    if all((dxfattrib, key)):
        raise ValueError('Specify a dxfattrib or a key function, but not both.')
    if dxfattrib != '':
        key = lambda entity: entity.get_dxf_attrib(dxfattrib, None)
    if key is None:
        raise ValueError('no valid argument found, specify a dxfattrib or a key function, but not both.')

    result = dict()
    for dxf_entity in entities:
        try:
            group_key = key(dxf_entity)
        except AttributeError:  # ignore DXF entities, which do not support all query attributes
            continue
        if group_key is not None:
            group = result.setdefault(group_key, [])
            group.append(dxf_entity)
    return result


### Unit tests below ###
def check(candidate):
	assert candidate(list(), 'layer') == dict()
	assert candidate(list(), key=lambda entity: entity.dxftype()) == dict()
	assert candidate(list(), key=lambda entity: entity.layer) == dict()
	assert candidate([], key=lambda e: 0) == dict()
	assert candidate(list(), key=lambda e: e.dxftype()) == dict()
	assert candidate(list(), dxfattrib='layer') == dict()
def test_check():
	check(groupby)
