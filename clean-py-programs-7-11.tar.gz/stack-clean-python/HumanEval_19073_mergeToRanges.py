def mergeToRanges(ls):
    """ Takes a list like ['1', '2', '3', '5', '8', 9'] and returns a list like
    ['1-3', '5', '8', '9'] """
    ### Canonical solution below ###
    if len(ls) < 2:
        return ls
    i = 0
    while i < len(ls)-1 and \
        ((ls[i].isdigit() and ls[i+1].isdigit() and \
          int(ls[i])+1 == int(ls[i+1])) or \
         (len(ls[i]) == 1 and len(ls[i+1]) == 1 and \
          ord(ls[i])+1 == ord(ls[i+1]))):
        i += 1
    if i < 2:
        return ls[0:i+1]+mergeToRanges(ls[i+1:])
    else:
        return [ls[0]+'-'+ls[i]]+mergeToRanges(ls[i+1:])


### Unit tests below ###
def check(candidate):
	assert candidate(['1', '2', '3', '5', '8', '9', '11', '12', '13']) == ['1-3', '5', '8', '9', '11-13']
	assert candidate( ['1', '2', '3', '5', '8', '9', '10', '11', '12'] ) == ['1-3', '5', '8-12']
	assert candidate(list('1')) == list('1')
	assert candidate( ['1', '2', '3', '5', '8', '9', '10', '11', '12', '13'] ) == ['1-3', '5', '8-13']
	assert candidate(['1', '2', '3', '4', '5', '6', '7', '8', '9']) == ['1-9']
	assert candidate( ['1', '2', '3', '5', '8', '9', '10'] ) == ['1-3', '5', '8-10']
	assert candidate(['1', '2', '3', '5', '6', '7', '9', '10', '11']) == ['1-3', '5-7', '9-11']
	assert candidate(list('123456789')) == ['1-9']
	assert candidate(list('1234567890a'))
	assert candidate(['1', '2', '3', '5', '8', '9']) == \
    ['1-3', '5', '8', '9']
	assert candidate( ['1', '2', '3', '5', '8', '9', '10', '11', '12', '13', '14'] ) == ['1-3', '5', '8-14']
	assert candidate(['1', '2', '3', '5', '6', '7', '9', '10', '11', '12']) == ['1-3', '5-7', '9-12']
	assert candidate(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l','m', 'n', 'o', 'p', 'q', 'r','s', 't', 'u', 'v', 'w', 'x', 'y', 'z']) == ['a-z']
	assert candidate(list('12')) == list('12')
	assert candidate(['1', '2', '3', '5', '8', '9', '11']) == \
    ['1-3', '5', '8', '9', '11']
	assert candidate(['1', '2', '3', '5', '8', '9']) == ['1-3', '5', '8', '9']
	assert candidate(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l','m', 'n', 'o', 'p', 'q', 'r','s', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']) == ['a-z', '0-9']
	assert candidate(['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']) == \
    ['1-10']
	assert candidate(['1', '2', '3', '4', '5', '6', '7', '8', '9', '11']) == ['1-9', '11']
	assert candidate( ['1', '2', '3', '5', '8', '9', '10', '11', '12', '13', '14', '15'] ) == ['1-3', '5', '8-15']
	assert candidate( ['1', '2', '3', '5', '8', '9'] ) == \
    ['1-3', '5', '8', '9']
	assert candidate(['1', '2', '3', '4', '5', '6', '7', '8', '9']) == \
    ['1-9']
	assert candidate(list('')) == list('')
	assert candidate( ['1', '2', '3', '5', '8', '9'] ) == ['1-3', '5', '8', '9']
	assert candidate( ['1', '2', '3', '5', '8', '9', '10', '11'] ) == ['1-3', '5', '8-11']
	assert candidate(['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11']) == \
    ['1-11']
	assert candidate(['1', '2', '3', '5', '6', '7', '8', '10']) == ['1-3', '5-8', '10']
def test_check():
	check(mergeToRanges)
