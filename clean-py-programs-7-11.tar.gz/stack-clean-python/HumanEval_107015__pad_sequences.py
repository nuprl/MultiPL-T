def _pad_sequences(maxlen, seq, pad_x=0, pad_y=0, pad_v=0):
    """Removes sequences that exceed the maximum length.

    # Arguments
        maxlen: Int, maximum length of the output sequences.
        seq: List of lists, where each sublist is a sequence.
        label: List where each element is an integer.

    # Returns
        new_seq, new_label: shortened lists for `seq` and `label`.
    """
    ### Canonical solution below ###
    new_seq, new_label, new_ner = [], [], []
    for x in seq:
        x = list(x)
        if len(x) < maxlen:
            pads_x = x + [pad_x] * (maxlen - len(x))
            new_seq.append(pads_x)
        else:
            new_seq.append(x[0:maxlen])

    return new_seq


### Unit tests below ###
def check(candidate):
	assert candidate(2, [[1, 2], [3, 4, 5]]) == [[1, 2], [3, 4]]
	assert candidate(3, [[1, 2], [3, 4, 5]]) == [[1, 2, 0], [3, 4, 5]]
	assert candidate(3, [[1, 2, 3], [4, 5]]) == [[1, 2, 3], [4, 5, 0]], "candidate does not work"
	assert candidate(3, [[1, 2], [1, 2, 3], [1, 2]]) == [[1, 2, 0], [1, 2, 3], [1, 2, 0]]
	assert candidate(maxlen=2, seq=[[1, 2, 3], [4, 5]], pad_x=0, pad_y=1) == [[1, 2], [4, 5]]
	assert candidate(10, [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5]]) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 0, 0, 0, 0, 0]]
	assert candidate(2, [[1, 1], [2, 2], [3, 3]]) == [[1, 1], [2, 2], [3, 3]]
	assert candidate(2, [[1, 1, 1], [2, 2]], 0, 0) == [[1, 1], [2, 2]]
	assert candidate(2, [[1, 1], [1, 1, 1, 1]]) == [[1, 1], [1, 1]]
	assert candidate(2, [[1, 2], [1, 2, 3], [1, 2]]) == [[1, 2], [1, 2], [1, 2]]
	assert candidate(10, [[1, 2, 3, 4, 5], [5, 6], [7], [8, 9]], 0, 0, 0) == [[1, 2, 3, 4, 5, 0, 0, 0, 0, 0], [5, 6, 0, 0, 0, 0, 0, 0, 0, 0], [7, 0, 0, 0, 0, 0, 0, 0, 0, 0], [8, 9, 0, 0, 0, 0, 0, 0, 0, 0]]
	assert candidate(maxlen=2, seq=[[1, 2, 3], [4, 5]], pad_y=1) == [[1, 2], [4, 5]]
	assert candidate(3, [[1, 2], [3, 4, 5], [6, 7, 8, 9]], pad_x=0, pad_y=0) == \
       [[1, 2, 0], [3, 4, 5], [6, 7, 8]]
	assert candidate(10, [[1, 2, 3], [1, 2], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]], 0, 0, 0) == [[1, 2, 3, 0, 0, 0, 0, 0, 0, 0], [1, 2, 0, 0, 0, 0, 0, 0, 0, 0], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]]
	assert candidate(3, [[1, 1, 1], [2, 2]], 0, 0, 0) == [[1, 1, 1], [2, 2, 0]]
	assert candidate(3, [[1, 1, 1], [2, 2]], 0) == [[1, 1, 1], [2, 2, 0]]
	assert candidate(1, [[1, 1], [1, 1, 1, 1]]) == [[1], [1]]
	assert candidate(maxlen=2, seq=[[1, 1], [2, 2, 2]], pad_x=10, pad_y=10, pad_v=10) == [[1, 1], [2, 2]]
	assert candidate(10, [[1, 2, 3, 4, 5], [2, 3]]) == [[1, 2, 3, 4, 5, 0, 0, 0, 0, 0], [2, 3, 0, 0, 0, 0, 0, 0, 0, 0]]
	assert candidate(10, [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]]) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]]
	assert candidate(1, [[1, 2, 3], [2, 3]]) == [[1], [2]]
	assert candidate(3, [[1, 2], [3], [4, 5, 6]], 0) == [[1, 2, 0], [3, 0, 0], [4, 5, 6]]
	assert candidate(2, [[1, 2], [3, 4]], 10) == [[1, 2], [3, 4]]
	assert candidate(10, [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9]]) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]]
	assert candidate(10, [[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]], 0, 0, 1) == [[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]]
	assert candidate(3, [[1, 2, 3], [4, 5]], 10) == [[1, 2, 3], [4, 5, 10]], "candidate does not work"
	assert candidate(3, [[1, 2, 3, 4, 5], [2, 3]]) == [[1, 2, 3], [2, 3, 0]]
	assert candidate(3, [[1, 1, 1], [2, 2]]) == [[1, 1, 1], [2, 2, 0]]
	assert candidate(10, [[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]], 0, 0, 0) == [[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]]
	assert candidate(maxlen=2, seq=[[1, 2, 3], [4, 5]]) == [[1, 2], [4, 5]]
	assert candidate(maxlen=2, seq=[[1, 1], [2, 2, 2]], pad_x=10, pad_y=10) == [[1, 1], [2, 2]]
	assert candidate(4, [[1, 2], [1, 2, 3], [1, 2]]) == [[1, 2, 0, 0], [1, 2, 3, 0], [1, 2, 0, 0]]
	assert candidate(3, [[1, 2, 3], [1, 2], [1, 2, 3, 4, 5, 6]], 0, 0, 0) == [[1, 2, 3], [1, 2, 0], [1, 2, 3]]
	assert candidate(maxlen=2, seq=[[1, 1], [2, 2, 2]], pad_y=10) == [[1, 1], [2, 2]]
	assert candidate(maxlen=2, seq=[[1, 2, 3], [4, 5]], pad_x=0) == [[1, 2], [4, 5]]
	assert candidate(10, [[1, 2, 3, 4, 5], [5, 6], [7], [8, 9]], 1, 0, 0) == [[1, 2, 3, 4, 5, 1, 1, 1, 1, 1], [5, 6, 1, 1, 1, 1, 1, 1, 1, 1], [7, 1, 1, 1, 1, 1, 1, 1, 1, 1], [8, 9, 1, 1, 1, 1, 1, 1, 1, 1]]
	assert candidate(maxlen=2, seq=[[1, 1], [2, 2, 2]]) == [[1, 1], [2, 2]]
	assert candidate(10, [[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]], 0, 0) == [[1,2,3,4,5,6,7,8,9,10],[1,2,3,4,5,6,7,8,9,10]]
	assert candidate(3, [[1, 1, 1], [2, 2]], 0, 0) == [[1, 1, 1], [2, 2, 0]]
	assert candidate(2, [[1, 1], [2, 2]]) == [[1, 1], [2, 2]]
	assert candidate(2, [[1, 1, 1], [2, 2]], 0, 0, 0) == [[1, 1], [2, 2]]
	assert candidate(10, [[1, 2, 3], [2, 3]]) == [[1, 2, 3, 0, 0, 0, 0, 0, 0, 0], [2, 3, 0, 0, 0, 0, 0, 0, 0, 0]]
	assert candidate(3, [[1, 2, 3], [2, 3]]) == [[1, 2, 3], [2, 3, 0]]
	assert candidate(10, [[1, 2, 3], [4, 5], [5, 6, 7, 8, 9, 10]]) == \
    [[1, 2, 3, 0, 0, 0, 0, 0, 0, 0], [4, 5, 0, 0, 0, 0, 0, 0, 0, 0], [5, 6, 7, 8, 9, 10, 0, 0, 0, 0]]
def test_check():
	check(_pad_sequences)
