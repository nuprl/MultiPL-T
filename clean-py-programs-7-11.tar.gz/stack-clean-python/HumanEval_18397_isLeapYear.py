def isLeapYear(year):
    """Checks that a year is a leap year

    Args:
        year: user input year
    Returns:
        Boolean depending if it is a leap year or not.
    """
    ### Canonical solution below ###
    if ((year % 4 == 0) & (year % 100 != 0) | (
        0
    )):
        return True
    else:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate(20000) == False
	assert candidate(2035) == False
	assert candidate(2005) == False
	assert candidate(1992) == True, "1992 was not a leap year"
	assert not candidate(1902)
	assert candidate(1990) == False
	assert candidate(2100) == False
	assert candidate(1900) == False
	assert candidate(2053) == False
	assert candidate(2057) == False
	assert candidate(2006) == False, "2006 was a leap year"
	assert candidate(2048) == True
	assert candidate(1984) == True
	assert candidate(1980) == True
	assert not candidate(2005)
	assert candidate(1700) == False
	assert not candidate(1900)
	assert candidate(2004)
	assert not candidate(2403)
	assert not candidate(2100)
	assert not candidate(2105)
	assert not candidate(2006)
	assert candidate(2034) == False
	assert not candidate(2401)
	assert candidate(2056) == True
	assert not candidate(2001)
	assert candidate(2002) == False, "2002 was a leap year"
	assert candidate(2001) == False, "2001 was a leap year"
	assert candidate(1996) == True
	assert candidate(2008) == True
	assert candidate(1991) == False, "1991 was a leap year"
	assert not candidate(2103)
	assert candidate(2030) == False
	assert candidate(2054) == False
	assert candidate(2027) == False
	assert not candidate(2007)
	assert candidate(2010) == False, "2010 was a leap year"
	assert candidate(2015) == False
	assert not candidate(1700)
	assert not candidate(2101)
	assert candidate(2005) == False, "2005 was a leap year"
	assert candidate(2028) == True
	assert not candidate(2003)
	assert candidate(2013) == False
	assert not candidate(2017)
	assert candidate(2050) == False
	assert candidate(2049) == False
	assert candidate(1997) == False
	assert candidate(2038) == False
	assert not candidate(2002)
	assert not candidate(1999)
	assert candidate(2025) == False
	assert candidate(2031) == False
	assert candidate(2044) == True
	assert candidate(2018) == False
	assert candidate(2043) == False
	assert candidate(2046) == False
	assert candidate(2007) == False, "2007 was a leap year"
	assert candidate(2023) == False
	assert candidate(2026) == False
	assert candidate(2032) == True
	assert not candidate(2402)
	assert candidate(2020) == True
	assert not candidate(1800)
	assert candidate(1993) == False
	assert candidate(2009) == False, "2009 was a leap year"
	assert candidate(2001) == False
	assert candidate(2017) == False
	assert candidate(2020)
	assert not candidate(1905)
	assert candidate(2047) == False
	assert candidate(1999) == False
	assert candidate(2052) == True
	assert candidate(2012) == True
	assert candidate(2029) == False
	assert candidate(2042) == False
	assert candidate(2003) == False, "2003 was a leap year"
	assert candidate(2045) == False
	assert candidate(2024) == True
	assert candidate(2016) == True
	assert not candidate(1903)
	assert not candidate(2102)
	assert candidate(2004) == True
	assert candidate(2008) == True, "2008 was not a leap year"
	assert not candidate(2405)
	assert candidate(2039) == False
	assert candidate(2004) == True, "2004 was not a leap year"
	assert candidate(2019) == False
	assert candidate(2033) == False
	assert candidate(2037) == False
	assert candidate(1993) == False, "1993 was a leap year"
	assert candidate(2040) == True
	assert candidate(2036) == True
	assert not candidate(1901)
	assert candidate(2021) == False
	assert candidate(1904) == True
	assert candidate(2022) == False
	assert candidate(2041) == False
	assert candidate(1985) == False
def test_check():
	check(isLeapYear)
