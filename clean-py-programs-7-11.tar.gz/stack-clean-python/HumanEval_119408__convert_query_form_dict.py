def _convert_query_form_dict(query_form_dict):
    """Converts raw output from ``form.to_dict()`` to a format that is
    more useable for ``acsql`` database queries.

    Parameters
    ----------
    query_form_dict : dict
        The dictionary returned by ``form.to_dict()``.

    Returns
    -------
    query_form_dict : dict
        A new dictionary with blank entried removed and operator key
        entries reformatted.
    """
    ### Canonical solution below ###

    # Keys that allow operators (e.g. greater than)
    operator_keys = ['date_obs', 'exptime']

    # Remove blank entries from form data
    query_form_dict = {key: value for key, value in list(query_form_dict.items()) if value != ['']}

    # Combine data returned from fields with operator dropdowns
    for operator_key in operator_keys:
        operator_dict = {}
        for key, value in list(query_form_dict.items()):
            if key == operator_key + '-op':
                operator_dict['op'] = value[0]
            elif key == operator_key + '-val1':
                operator_dict['val1'] = value[0]
            elif key == operator_key + '-val2':
                operator_dict['val2'] = value[0]
        if len(operator_dict) > 1:
            query_form_dict[operator_key] = operator_dict

    return query_form_dict


### Unit tests below ###
def check(candidate):
	assert candidate({}) == {}
	assert candidate({'date_obs': [''], 'exptime': ['']}) == dict()
	assert candidate({'date_obs': [''], 'exptime-op': [''], 'exptime-val1': [''], 'exptime-val2': [''], 'instrument': ['WFC']}) == {'instrument': ['WFC']}
	assert candidate({'a': [''], 'b': [''], 'c': [''], 'd': ['']}) == dict()
	assert candidate({'date_obs-op': [''], 'exptime-op': [''], 'date_obs-val1': [''], 'exptime-val1': [''], 'date_obs-val2': [''], 'exptime-val2': ['']}) == dict()
	assert candidate(dict()) == dict()
	assert candidate(dict(
    instrument=['wfc3'],
    date_obs={'op': '>', 'val1': '2015-01-01', 'val2': None},
    exptime={'op': '<', 'val1': '1000', 'val2': None}
)) == dict(
    instrument=['wfc3'],
    date_obs={'op': '>', 'val1': '2015-01-01', 'val2': None},
    exptime={'op': '<', 'val1': '1000', 'val2': None}
)
	assert candidate({'': ['']}) == dict()
	assert candidate({'a-op': [''], 'a-val1': [''], 'b-op': [''], 'b-val1': [''], 'c-op': [''], 'c-val1': [''], 'd-op': [''], 'd-val1': ['']}) == dict()
	assert candidate({'date_obs': [''], 'exptime-op': [''], 'exptime-val1': [''], 'exptime-val2': [''], 'instrument': ['WFC'], 'telescope': ['JWST'], 'instrument-op': [''], 'instrument-val1': [''], 'instrument-val2': ['']}) == {'instrument': ['WFC'], 'telescope': ['JWST']}
	assert candidate({'date_obs': [''], 'exptime': [''],
                                'date_obs-op': [''], 'exptime-op': [''],
                                'date_obs-val1': [''], 'exptime-val1': [''],
                                'date_obs-val2': [''], 'exptime-val2': ['']}) == {}
	assert candidate({'date_obs': [''], 'exptime-op': [''], 'exptime-val1': [''], 'exptime-val2': [''], 'instrument': ['WFC'], 'telescope': ['JWST']}) == {'instrument': ['WFC'], 'telescope': ['JWST']}
	assert candidate({'date_obs-op': [''], 'exptime-op': [''], 'date_obs-val1': [''], 'exptime-val1': ['']}) == dict()
	assert candidate({'date_obs': [''], 'exptime-op': [''], 'exptime-val1': [''], 'exptime-val2': ['']}) == dict()
def test_check():
	check(_convert_query_form_dict)
