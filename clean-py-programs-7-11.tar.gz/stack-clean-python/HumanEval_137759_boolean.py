def boolean(value):
    """ OpenEmbedded 'boolean' type
     
     Valid values for true: 'yes', 'y', 'true', 't', '1'
     Valid values for false: 'no', 'n', 'false', 'f', '0'
     """
	### Canonical solution below ###    

    if not isinstance(value, str):
        raise TypeError("boolean accepts a string, not '%s'" % type(value))

    value = value.lower()
    if value in ('yes', 'y', 'true', 't', '1'):
        return True
    elif value in ('no', 'n', 'false', 'f', '0'):
        return False
    raise ValueError("Invalid boolean value '%s'" % value)

### Unit tests below ###
def check(candidate):
	assert candidate('f') == False
	assert candidate("1") is True
	assert candidate('1')
	assert candidate('Y') == True
	assert candidate("true") is True
	assert candidate("FALSE") == False
	assert not candidate('false')
	assert candidate('YES') == True
	assert candidate("y") == True
	assert candidate("N") == False
	assert candidate('T') == True
	assert candidate('True') == True
	assert candidate('yes')
	assert candidate("false") == False
	assert not candidate('no')
	assert candidate("t") == True
	assert candidate("yes") == True
	assert candidate('0') is False
	assert candidate('True') is True
	assert candidate('N') == False
	assert candidate('y') is True
	assert candidate('y')
	assert candidate("0") == False
	assert candidate('yes') == True
	assert candidate("n") is False
	assert candidate('TRUE') == True
	assert candidate('no') is False
	assert candidate("f") is False
	assert candidate('0') == False
	assert candidate("f") == False
	assert not candidate('f')
	assert candidate("n") == False
	assert candidate("TRUE") == True
	assert candidate('1') is True
	assert candidate("0") is False
	assert candidate('False') == False
	assert candidate('true')
	assert candidate('F') == False
	assert candidate("Y") == True
	assert candidate("Yes") is True
	assert candidate("T") == True
	assert candidate("F") == False
	assert candidate('1') == True
	assert candidate("1") == True
	assert candidate('false') is False
	assert candidate('no') == False
	assert candidate('y') == True
	assert candidate('false') == False
	assert candidate('True')
	assert candidate('n') == False
	assert candidate('t')
	assert candidate("True") is True
	assert not candidate('0')
	assert not candidate('n')
	assert candidate('t') == True
	assert candidate("false") is False
	assert candidate("no") == False
	assert candidate("No") is False
	assert candidate("t") is True
	assert candidate("NO") == False
	assert candidate('NO') == False
	assert candidate("yes") is True
	assert candidate('yes') is True
	assert candidate('FALSE') == False
	assert candidate('true') == True
	assert candidate('False') is False
	assert candidate("true") == True
	assert candidate('true') is True
	assert candidate("False") is False
	assert candidate('n') is False
	assert candidate("y") is True
	assert candidate("no") is False
	assert candidate("YES") == True
def test_check():
	check(boolean)
