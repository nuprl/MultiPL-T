def generate_numbers(count, mean, stdDev, ordering="Random"):
   """Generates a series of number according to the parameters with a uniform
   distribution.
   
   Possible orderings are: 'Random' (default), 'Sorted', 'Reverse Sorted'"""
    ### Canonical solution below ###

   if (ordering != "Random" and ordering != "Sorted" and
           ordering != "Reverse Sorted"):
      return float("NaN")

   from random import random

   numbers = []

   while count > 0:

      # uniform distribution with a = 0 and b = 1 has mean = 0.5 and stdDev = 0.2887
      # doesn't handle high mean and low stdDev well
      numbers.append((random() - 0.5)*stdDev/0.2887 + mean)

      count -= 1

   if ordering == "Sorted":
      numbers.sort()
   elif ordering == "Reverse Sorted":
      numbers.sort()
      numbers.reverse()

   return numbers


### Unit tests below ###
def check(candidate):
	assert candidate(0, 0, 0) == []
	assert candidate(10, 0, 0, "Random") == [0,0,0,0,0,0,0,0,0,0]
	assert candidate(0, 0, 0, "Reverse Sorted") == []
	assert candidate(1, 0, 0, "Random") == [0]
	assert candidate(0, 0, 0, "Random") == []
	assert candidate(1, 1, 0) == [1]
	assert candidate(0, 1, 1) == []
	assert candidate(1, 0, 0, "Reverse Sorted") == [0]
	assert candidate(1, 0, 0, "Sorted") == [0]
	assert candidate(0, 0, 0, "Sorted") == []
	assert candidate(0, 0, 1, "Random") == []
	assert candidate(0, 10, 1) == []
	assert candidate(1, 0, 0) == [0]
	assert candidate(0, 0, 1) == []
	assert candidate(0, 10, 5, "Random") == []
	assert candidate(10, 10, 0) == [10, 10, 10, 10, 10, 10, 10, 10, 10, 10]
	assert candidate(10, 1, 0) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
	assert candidate(10, 0, 0) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
def test_check():
	check(generate_numbers)
