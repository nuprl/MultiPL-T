def odd_man_out(inp):
    """If input looks like an odd integer, return
        twice its value; otherwise, return None"""
    ### Canonical solution below ###

    try: #If it's a number, can it be cast as an integer?
        inp = int(inp)
    except:
        return None
    #try: #Is it a number at all?  If not, give up.
        #inp/1
    #except:
        #return None

    #If it's a number, is it odd?
    if inp % 2:  #returns 0 if even
        return(inp*2)


### Unit tests below ###
def check(candidate):
	assert candidate('5.0') == None
	assert candidate(12) == None
	assert candidate(10.1) == None
	assert candidate(25) == 50
	assert candidate("10.000001") == None
	assert candidate('10.5') == None
	assert candidate("10.01") == None
	assert candidate(10.5) is None
	assert candidate('2.1') == None
	assert candidate(20) == None
	assert candidate(123) == 246
	assert candidate("bar") == None
	assert candidate('1a') == None
	assert candidate(0) == None
	assert candidate("10.0000001") == None
	assert candidate('10') == None
	assert candidate("14") is None
	assert candidate(12.0) == None
	assert candidate("10.5") is None
	assert candidate('4') == None
	assert candidate("10.001") == None
	assert candidate('foo') == None
	assert candidate('four') == None
	assert candidate('a') == None
	assert candidate('7') == 14
	assert candidate('10.0001') == None
	assert candidate('10.001') == None
	assert candidate(1000000001) == 2000000002
	assert candidate('5') == 10
	assert candidate('1.2') == None
	assert candidate(3) == 6
	assert candidate(9) == 18
	assert candidate('1') == 2
	assert candidate("11") == 22
	assert candidate(7) == 14
	assert candidate('10a') == None
	assert candidate(1000000000) == None
	assert candidate("10.1") == None
	assert candidate('abc') == None
	assert candidate(10.000000001) == None
	assert candidate(1) == 2
	assert candidate(10.00000001) == None
	assert candidate(10.000001) == None
	assert candidate(1000) == None
	assert candidate('1.1') == None
	assert candidate("20") == None
	assert candidate(4) == None
	assert candidate('21') == 42
	assert candidate(10) == None
	assert candidate('1.0') == None
	assert candidate(10.01) == None
	assert candidate("12") == None
	assert candidate('hi') == None
	assert candidate(5) == 10
	assert candidate('3') == 6
	assert candidate('3.0') == None
	assert candidate('11') == 22
	assert candidate("5") == 10
	assert candidate('25') == 50
	assert candidate("4") == None
	assert candidate(10.00001) == None
	assert candidate('10.1') == None
	assert candidate(1.0) == 2
	assert candidate("10.00001") == None
	assert candidate(10.0001) == None
	assert candidate(2) == None
	assert candidate(2.5) == None
	assert candidate("1.5") == None
	assert candidate('10.01') == None
	assert candidate(10.001) == None
	assert candidate(11) == 22
	assert candidate('2') == None
	assert candidate(None) == None
	assert candidate('hello') == None
	assert candidate(21) == 42
	assert candidate(100) == None
	assert candidate("10.0001") == None
	assert candidate("10.00000001") == None
	assert candidate("foo") == None
	assert candidate("10") == None
	assert candidate('1.5') == None
	assert candidate("a") == None
	assert candidate(10.0000001) == None
	assert candidate('7.0') == None
	assert candidate(2) is None
def test_check():
	check(odd_man_out)
