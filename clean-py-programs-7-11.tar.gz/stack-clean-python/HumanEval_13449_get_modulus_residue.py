def get_modulus_residue(value, modulus):
    """
    Computes the canonical residue of value mod modulus.

    Parameters:
        value (int): The value to compute the residue of
        modulus (int): The modulus used to calculate the residue

    Returns:
        An integer "r" between 0 and modulus - 1, where value - r is divisible
        by the modulus.

    Remarks:
        See the Q# source for the "Modulus" function at 
        https://github.com/Microsoft/QuantumLibraries/blob/master/Canon/src/Math/Functions.qs
    """
    ### Canonical solution below ###

    if modulus <= 0:
        raise ValueError(f"Modulus {modulus} must be positive.")

    r = value % modulus
    if r < 0:
        return r + modulus
    else:
        return r


### Unit tests below ###
def check(candidate):
	assert candidate(4, 4) == 0
	assert candidate(9, 2) == 1
	assert candidate(28, 29) == 28
	assert candidate(8, 5) == 3
	assert candidate(6, 1) == 0
	assert candidate(1, 5) == 1
	assert candidate(-1, 1) == 0
	assert candidate(-3, 1) == 0
	assert candidate(11, 10) == 1
	assert candidate(0, 7) == 0
	assert candidate(14, 3) == 2
	assert candidate(10, 4) == 2
	assert candidate(0, 3) == 0
	assert candidate(15, 2) == 1
	assert candidate(8, 3) == 2
	assert candidate(-1234, 5) == 1
	assert candidate(0, 10) == 0
	assert candidate(17, 11) == 6
	assert candidate(12345, 19) == 14
	assert candidate(9, 10) == 9
	assert candidate(7, 1) == 0
	assert candidate(22, 2) == 0
	assert candidate(-12345, 5) == 0
	assert candidate(10, 5) == 0
	assert candidate(22, 3) == 1
	assert candidate(15, 5) == 0
	assert candidate(-1, 3) == 2
	assert candidate(8, 7) == 1
	assert candidate(17, 41) == 17
	assert candidate(17, 37) == 17
	assert candidate(3, 1) == 0
	assert candidate(15, 4) == 3
	assert candidate(-1, 4) == 3
	assert candidate(21, 3) == 0
	assert candidate(9, 3) == 0
	assert candidate(-1, 2) == 1
	assert candidate(4, 2) == 0
	assert candidate(7, 4) == 3
	assert candidate(9, 5) == 4
	assert candidate(101, 10) == 1
	assert candidate(-4, 3) == 2
	assert candidate(0, 4) == 0
	assert candidate(200, 10) == 0
	assert candidate(-3, 3) == 0
	assert candidate(7, 7) == 0
	assert candidate(-3, 5) == 2
	assert candidate(1, 2) == 1
	assert candidate(2, 5) == 2
	assert candidate(10, 3) == 1
	assert candidate(-1, 8) == 7
	assert candidate(-8, 3) == 1
	assert candidate(17, 19) == 17
	assert candidate(-1, 7) == 6
	assert candidate(19, 2) == 1
	assert candidate(0, 1) == 0
	assert candidate(16, 3) == 1
	assert candidate(-2, 5) == 3
	assert candidate(8, 1) == 0
	assert candidate(-3, 2) == 1
	assert candidate(-6, 3) == 0
	assert candidate(19, 10) == 9
	assert candidate(4, 1) == 0
	assert candidate(20, 4) == 0
	assert candidate(18, 2) == 0
	assert candidate(201, 10) == 1
	assert candidate(12, 2) == 0
	assert candidate(-5, 1) == 0
	assert candidate(4, 3) == 1
	assert candidate(1, 7) == 1
	assert candidate(11, 13) == 11
	assert candidate(-1, 6) == 5
	assert candidate(6, 7) == 6
	assert candidate(11, 3) == 2
	assert candidate(0, 2) == 0
	assert candidate(10, 10) == 0
	assert candidate(17, 4) == 1
	assert candidate(-7, 3) == 2
	assert candidate(-5, 5) == 0
	assert candidate(8, 4) == 0
	assert candidate(13, 2) == 1
	assert candidate(1, 8) == 1
	assert candidate(123, 5) == 3
	assert candidate(-123, 5) == 2
	assert candidate(9, 4) == 1
	assert candidate(5, 1) == 0
	assert candidate(7, 3) == 1
	assert candidate(1, 10) == 1
	assert candidate(-5, 3) == 1
	assert candidate(2, 2) == 0
	assert candidate(6, 3) == 0
	assert candidate(0, 8) == 0
	assert candidate(-7, 7) == 0
	assert candidate(5, 4) == 1
	assert candidate(-4, 4) == 0
	assert candidate(13, 5) == 3
	assert candidate(7, 2) == 1
	assert candidate(1, 4) == 1
	assert candidate(-5, 2) == 1
	assert candidate(16, 2) == 0
	assert candidate(-3, 4) == 1
	assert candidate(10, 2) == 0
	assert candidate(1, 3) == 1
	assert candidate(-1, 5) == 4
	assert candidate(11, 4) == 3
	assert candidate(14, 4) == 2
	assert candidate(5, 5) == 0
	assert candidate(12345, 10) == 5
	assert candidate(15, 3) == 0
	assert candidate(19, 4) == 3
	assert candidate(4, 5) == 4
	assert candidate(12, 3) == 0
	assert candidate(-2, 3) == 1
	assert candidate(2, 1) == 0
	assert candidate(6, 2) == 0
	assert candidate(-5, 7) == 2
	assert candidate(-12345, 10) == 5
	assert candidate(20, 10) == 0
	assert candidate(21, 10) == 1
	assert candidate(9, 1) == 0
	assert candidate(5, 3) == 2
	assert candidate(7, 5) == 2
	assert candidate(1, 6) == 1
	assert candidate(11, 2) == 1
	assert candidate(17, 2) == 1
	assert candidate(17, 23) == 17
	assert candidate(0, 6) == 0
	assert candidate(19, 3) == 1
	assert candidate(-3, 7) == 4
	assert candidate(12345, 5) == 0
	assert candidate(22, 4) == 2
	assert candidate(3, 4) == 3
	assert candidate(2, 3) == 2
	assert candidate(100, 10) == 0
	assert candidate(199, 10) == 9
	assert candidate(2, 4) == 2
	assert candidate(0, 5) == 0
	assert candidate(-4, 5) == 1
	assert candidate(3, 2) == 1
	assert candidate(-4, 7) == 3
	assert candidate(11, 5) == 1
	assert candidate(123456, 5) == 1
	assert candidate(18, 4) == 2
	assert candidate(3, 5) == 3
	assert candidate(99, 10) == 9
	assert candidate(21, 2) == 1
	assert candidate(1, 1) == 0
	assert candidate(21, 4) == 1
	assert candidate(8, 2) == 0
	assert candidate(18, 3) == 0
	assert candidate(-6, 7) == 1
	assert candidate(6, 4) == 2
	assert candidate(17, 3) == 2
	assert candidate(16, 4) == 0
	assert candidate(14, 5) == 4
	assert candidate(13, 3) == 1
	assert candidate(-2, 2) == 0
	assert candidate(6, 5) == 1
	assert candidate(3, 7) == 3
	assert candidate(12, 4) == 0
	assert candidate(-2, 7) == 5
	assert candidate(-2, 1) == 0
	assert candidate(17, 29) == 17
	assert candidate(20, 3) == 2
	assert candidate(5, 2) == 1
	assert candidate(12, 5) == 2
	assert candidate(20, 2) == 0
	assert candidate(13, 4) == 1
	assert candidate(3, 3) == 0
	assert candidate(14, 2) == 0
	assert candidate(1234, 5) == 4
def test_check():
	check(get_modulus_residue)
