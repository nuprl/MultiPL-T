def _normalizeLineEnds(text,desired='\r\n',unlikely='\x00\x01\x02\x03'):
    """Normalizes different line end character(s).

    Ensures all instances of CR, LF and CRLF end up as
    the specified one."""
    ### Canonical solution below ###
    
    return (text
            .replace('\r\n', unlikely)
            .replace('\r', unlikely)
            .replace('\n', unlikely)
            .replace(unlikely, desired))


### Unit tests below ###
def check(candidate):
	assert candidate(r'a\nb\r',desired='\r\n') == r'a\nb\r'
	assert candidate(text='a\r\nb\r\nc',desired='\r\n') == 'a\r\nb\r\nc'
	assert candidate("This is a test.\r\r\r\r\r", desired='\n') == (
    "This is a test.\n\n\n\n\n")
	assert candidate(r'a\rb\n',desired='\n') == r'a\rb\n'
	assert candidate(
    'foo\nbar\r\nbaz\rquux\n',
    desired='\r\n') == 'foo\r\nbar\r\nbaz\r\nquux\r\n'
	assert candidate(
    "Here's a line\r\nAnd another\rAnd another\nAnd last one\r\n",
    desired='\n') == (
    "Here's a line\nAnd another\nAnd another\nAnd last one\n")
	assert candidate(
    'foo\nbar\r\nbaz\rquux\n', '\r\n', '\n') == 'foo\r\nbar\r\nbaz\r\nquux\r\n'
	assert candidate(r'foo\rbar\r\r\r') == r'foo\rbar\r\r\r'
	assert candidate(u'foo\nbar\r\nbaz\rquux\n', '\n') == u'foo\nbar\nbaz\nquux\n'
	assert candidate(u'\r\n') == u'\r\n'
	assert candidate(u'foo\nbar\r\n\r\nbaz\n', '\n') == u'foo\nbar\n\nbaz\n'
	assert candidate(r'a\r\nb\r\nc\r\n') == r'a\r\nb\r\nc\r\n'
	assert candidate(r'foo\r\nbar\r\n\r\n\r\n') == r'foo\r\nbar\r\n\r\n\r\n'
	assert candidate(r'foo\r\nbar\r\nbaz\r\n') == r'foo\r\nbar\r\nbaz\r\n'
	assert candidate(u'foo\nbar\r\nbaz\rquux\n') == u'foo\r\nbar\r\nbaz\r\nquux\r\n'
	assert candidate(u'abc\r\n\r\n') == u'abc\r\n\r\n'
	assert candidate(r'a\rb\r\n',desired='\n') == r'a\rb\r\n'
	assert candidate(
    "abc\ndef\r\nghi\rklm\n", desired='\r') == "abc\rdef\rghi\rklm\r"
	assert candidate('Hello\r\nWorld\r\n\r\n') == 'Hello\r\nWorld\r\n\r\n'
	assert candidate(r'a\r\nb\nc\r\n',desired='\r\n',unlikely='\n') == r'a\r\nb\nc\r\n'
	assert candidate(text='a\nb') == 'a\r\nb'
	assert candidate(u'abc\r\n\r\n', desired='\r\n') == u'abc\r\n\r\n'
	assert candidate(
    "abc\ndef\r\nghi\rklm\n", desired='\n') == "abc\ndef\nghi\nklm\n"
	assert candidate(text='a\rb') == 'a\r\nb'
	assert candidate(r'a\rb\n') == r'a\rb\n'
	assert candidate(r'a\r\nb\r\nc\n') == r'a\r\nb\r\nc\n'
	assert candidate("This is a test.\r\n\r\r\n\r\n") == (
    "This is a test.\r\n\r\n\r\n\r\n")
	assert candidate(u'abc') == u'abc'
	assert candidate(u'abc\r\n\r\n\r\n\r\n', desired='\r\n') == u'abc\r\n\r\n\r\n\r\n'
	assert candidate(r'a\nb') == r'a\nb'
	assert candidate(text='a\nb',desired='\n') == 'a\nb'
	assert candidate("This is a test.\r\n\r\n\r\r\n") == (
    "This is a test.\r\n\r\n\r\n\r\n")
	assert candidate(u'abc\r\n\r\n\r\n', desired='\r\n') == u'abc\r\n\r\n\r\n'
	assert candidate(r'a\nb\r\n') == r'a\nb\r\n'
	assert candidate(r"foo\nbar\r\nbaz\rquux",'\r\n') == r"foo\nbar\r\nbaz\rquux"
	assert candidate("This is a test.\r\n\n\n\n\n", desired='\r') == (
    "This is a test.\r\r\r\r\r")
	assert candidate(u'\r') == u'\r\n'
	assert candidate(r'foo\nbar\nbaz\n') == r'foo\nbar\nbaz\n'
	assert candidate(
    'foo\nbar\r\nbaz\rquux\n') == 'foo\r\nbar\r\nbaz\r\nquux\r\n'
	assert candidate('Hello\nWorld\r\n\r\n') == 'Hello\r\nWorld\r\n\r\n'
	assert candidate(
    'foo\nbar\r\nbaz\rquux\n',
    desired='\n') == 'foo\nbar\nbaz\nquux\n'
	assert candidate(u'abc\r\n\r\n', desired='\n') == u'abc\n\n'
	assert candidate(r'a\rb\r\n') == r'a\rb\r\n'
	assert candidate(text='a\r\nb',desired='\r\n') == 'a\r\nb'
	assert candidate(r'a\rb\r\n',desired='\r\n') == r'a\rb\r\n'
	assert candidate(r'a\nb\nc\n') == r'a\nb\nc\n'
	assert candidate(text='a\r\nb',desired='\n') == 'a\nb'
	assert candidate(
    'abc\ndef\r\nghi\rklm\n', desired='\n') == 'abc\ndef\nghi\nklm\n'
	assert candidate(u'abc\r\n') == u'abc\r\n'
	assert candidate(u'abc\r\n\r\n\r\n', desired='\n') == u'abc\n\n\n'
	assert candidate(r'a\rb') == r'a\rb'
	assert candidate("This is a test.\r\n\r\n\r\r\n", desired='\n') == (
    "This is a test.\n\n\n\n")
	assert candidate(
    'Hello\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n'
    'World\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n') \
    == 'Hello\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n' \
    'World\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n'
	assert candidate(r'a\nb\nc\r\n') == r'a\nb\nc\r\n'
	assert candidate(r'foo\nbar\n\n\n',desired='\n') == r'foo\nbar\n\n\n'
	assert candidate("This is a test.\n\r\n\r\n\r\n") == (
    "This is a test.\r\n\r\n\r\n\r\n")
	assert candidate(text='a\r\nb\r\nc',desired='\n') == 'a\nb\nc'
	assert candidate(r'a\r\nb\nc\r\n',desired='\r\n') == r'a\r\nb\nc\r\n'
	assert candidate(r'a\nb\r\n',desired='\r\n') == r'a\nb\r\n'
	assert candidate('Hello\rWorld\r\n\r\n') == 'Hello\r\nWorld\r\n\r\n'
	assert candidate(r'a\nb\r') == r'a\nb\r'
def test_check():
	check(_normalizeLineEnds)
