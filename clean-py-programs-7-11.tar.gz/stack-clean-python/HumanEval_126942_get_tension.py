def get_tension(s, d):
    """Calculate the interfacial tension.

    Args:
        s: A float (or numpy array): the spreading coefficient.
        d: A float (or numpy array): the drying coefficient.

    Returns:
        The interfacial tension in the appropriate units.
    """
    ### Canonical solution below ###
    return -0.5 * (s + d)


### Unit tests below ###
def check(candidate):
	assert candidate(0.1, 0.2)!= -0.7
	assert candidate(s=0.1, d=0) == -0.05
	assert candidate(0.1, 0.05)!= candidate(0.1, 0.06)
	assert candidate(1, 1) == -1
	assert candidate(0.1, 0.2)!= -0.4
	assert candidate(0.2, 0.5)!= 0.6
	assert candidate(2, 3) == -2.5
	assert candidate(0.1, 0.2)!= 0.8
	assert candidate(0.1, 0.2)!= 0.2
	assert candidate(0, 0) == 0
	assert candidate(0.5, -0.5) == 0.0
	assert candidate(0.1, 0.2)!= 0.3
	assert candidate(2, 2) == -2
	assert candidate(0.1, 0.05)!= candidate(0.05, 0.05)
	assert candidate(0.1, 0.2)!= 0.5
	assert candidate(0.1, 0.2)!= 0.7
	assert candidate(0.1, 0.2)!= -0.9
	assert candidate(0.1, 0.2)!= 0.9
	assert candidate(0.2, 0.5)!= 0.7
	assert candidate(0.1, 0.2)!= -0.2
	assert candidate(0.1, 0.2)!= 0.1
	assert candidate(1, 2) == candidate(1, 2)
	assert candidate(3, 2) == -2.5
	assert candidate(0, 1) == -0.5
	assert candidate(0.1, 0.2)!= -0.8
	assert candidate(1.0, 0.0) == -0.5
	assert candidate(0.1, 0.05)!= 0.1
	assert candidate(0.0, 0.0) == 0.0
	assert candidate(0.1, 0.2)!= -0.3
	assert candidate(0.1, 0.2)!= 0.6
	assert candidate(1, 2) == -1.5
	assert candidate(0.1, 0.2)!= -0.6
	assert candidate(-0.1, 0.2)
	assert candidate(0.1, 0.2)!= -0.1
	assert candidate(1, 0) == -0.5
	assert candidate(1.0, -1.0) == 0.0
	assert candidate(1, 2)!= candidate(1, 3)
	assert candidate(0.5, 0) == -0.25
	assert candidate(0.1, 0.2)!= -0.5
	assert candidate(0.1, 0.2)!= 1.0
	assert candidate(0.0, 1.0) == -0.5
	assert candidate(1, 2)!= candidate(2, 2)
	assert candidate(0.1, 0.2)!= 0.4
	assert candidate(0.0, 1.0) == candidate(1.0, 0.0)
	assert candidate(-0.5, 0.5) == 0.0
	assert candidate(1.0, 1.0) == -1.0
	assert candidate(0.1, 0.05) == candidate(0.1, 0.05)
	assert candidate(2, 1) == -1.5
	assert candidate(1, 2)!= candidate(1, 2) + 1
	assert candidate(3, 3) == -3
def test_check():
	check(get_tension)
