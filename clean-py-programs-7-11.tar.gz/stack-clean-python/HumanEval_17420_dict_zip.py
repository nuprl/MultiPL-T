def dict_zip(*dicts):
    """ 
     Take a series of dicts that share the same keys, and reduce the values
     for each key as if folding an iterator.
     """
	### Canonical solution below ###    
    keyset = set(dicts[0])
    for d in dicts:
        if set(d) != keyset:
            raise KeyError(f"Mismatched keysets in fold_dicts: {sorted(keyset)}, {sorted(set(d))}")

    return { key: [d[key] for d in dicts] for key in keyset }

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 3, 'b': 4},
    {'a': 5, 'b': 6},
    {'a': 7, 'b': 8},
) == {'a': [1, 3, 5, 7], 'b': [2, 4, 6, 8]}
	assert candidate(dict(a=1, b=2), dict(a=10, b=20)) == dict(a=[1, 10], b=[2, 20])
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 3, 'b': 4},
    {'a': 5, 'b': 6},
) == {
    'a': [1, 3, 5],
    'b': [2, 4, 6],
}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a': 4, 'b': 5, 'c': 6}
) == {
    'a': [1, 4],
    'b': [2, 5],
    'c': [3, 6]
}
	assert candidate(dict(a=1), dict(a=2), dict(a=3)) == dict(a=[1,2,3])
	assert candidate(dict(a=1, b=2), dict(a=3, b=4)) == dict(a=[1, 3], b=[2, 4])
	assert candidate( { 'a': 1, 'b': 2 }, { 'b': 3, 'a': 4 } ) == { 'a': [1, 4], 'b': [2, 3] }
	assert candidate(
    {'a':1, 'b':2},
    {'a':3, 'b':4},
    {'a':5, 'b':6}
) == {
    'a':[1,3,5],
    'b':[2,4,6]
}
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 3, 'b': 4},
    {'a': 5, 'b': 6}
) == {'a': [1, 3, 5], 'b': [2, 4, 6]}
	assert candidate(
    {'a':1, 'b':2},
    {'a':3, 'b':4}
) == {
    'a':[1,3],
    'b':[2,4]
}
	assert candidate(dict(a=1, b=2), dict(a=3, b=4)) == dict(a=[1,3], b=[2,4])
	assert candidate(dict(a=1, b=2), dict(a=2, b=3)) == dict(a=[1, 2], b=[2, 3])
	assert candidate(
    { 'a': 1, 'b': 2 },
    { 'a': 2, 'b': 3 },
    { 'a': 3, 'b': 4 },
) == { 'a': [1, 2, 3], 'b': [2, 3, 4] }
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 3, 'b': 4},
    {'a': 5, 'b': 6}
) == {
    'a': [1, 3, 5],
    'b': [2, 4, 6]
}
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 2, 'b': 3},
    {'a': 3, 'b': 4}
) == {'a': [1, 2, 3], 'b': [2, 3, 4]}
	assert candidate(
    {1: 10, 2: 20},
    {1: 11, 2: 21},
    {1: 12, 2: 22},
) == {
    1: [10, 11, 12],
    2: [20, 21, 22],
}
	assert candidate(
    { "a": 1, "b": 2, "c": 3 },
    { "a": 4, "b": 5, "c": 6 },
    { "a": 7, "b": 8, "c": 9 }
) == {
    "a": [1, 4, 7],
    "b": [2, 5, 8],
    "c": [3, 6, 9]
}
	assert candidate(
    { 'a': 1, 'b': 2 },
    { 'a': 10, 'b': 20 },
    { 'a': 100, 'b': 200 },
    { 'a': 1000, 'b': 2000 },
    { 'a': 10000, 'b': 20000 },
) == {
    'a': [1, 10, 100, 1000, 10000],
    'b': [2, 20, 200, 2000, 20000],
}
	assert candidate(dict(a=1, b=2), dict(a=2, b=3), dict(a=3, b=4)) == dict(a=[1,2,3], b=[2,3,4])
	assert candidate(
    { 'a': 1, 'b': 2 },
    { 'a': 10, 'b': 20 },
    { 'a': 100, 'b': 200 },
    { 'a': 1000, 'b': 2000 },
) == {
    'a': [1, 10, 100, 1000],
    'b': [2, 20, 200, 2000],
}
	assert candidate(
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6},
        {'a': 7, 'b': 8},
    ) == {
        'a': [1, 3, 5, 7],
        'b': [2, 4, 6, 8],
    }
	assert candidate(
    { 'a': 1, 'b': 2 },
    { 'a': 10, 'b': 20 },
    { 'a': 100, 'b': 200 },
) == {
    'a': [1, 10, 100],
    'b': [2, 20, 200],
}
	assert candidate(dict(a=1,b=2), dict(a=2,b=3), dict(a=3,b=4)) == dict(a=[1,2,3], b=[2,3,4])
	assert candidate(dict(a=1, b=2), dict(a=3, b=4), dict(a=6, b=7)) == dict(a=[1,3,6], b=[2,4,7])
	assert candidate(
    {1: "one", 2: "two", 3: "three"},
    {1: "uno", 2: "dos", 3: "tres"},
    {1: "un", 2: "deux", 3: "trois"},
) == {
    1: ["one", "uno", "un"],
    2: ["two", "dos", "deux"],
    3: ["three", "tres", "trois"],
}
	assert candidate(dict(a=1, b=2), dict(a=3, b=4), dict(a=5, b=6)) == dict(a=[1, 3, 5], b=[2, 4, 6])
	assert candidate(
    {'a': 1, 'b': 2},
    {'a': 2, 'b': 3}
) == {'a': [1, 2], 'b': [2, 3]}
	assert candidate(dict(a=1), dict(a=3), dict(a=5)) == dict(a=[1, 3, 5])
def test_check():
	check(dict_zip)
