def measure_type(x):
    """ Takes Numeric Code and returns String API code
     
     Input Values: 1:"Base", 2:"Advanced", 3:"Misc", 4:"Four Factors", 5:"Scoring", 6:"Opponent", 7:"Usage"
     
     Used in:
     
     """
	### Canonical solution below ###    
    measure = {1: "Base", 2: "Advanced", 3: "Misc", 4: "Four Factors", 5: "Scoring", 6: "Opponent", 7: "Usage"}
    try:
        return measure[x]
    except:
        raise ValueError("Please enter a number between 1 and " + str(len(measure)))

### Unit tests below ###
def check(candidate):
	assert candidate(3) == "Misc", "Failed Test 3"
	assert candidate(7) == "Usage", "Usage is not Usage"
	assert candidate(2) == "Advanced", "candidate(2) should be 'Advanced'"
	assert candidate(5) == "Scoring", "Error Scoring"
	assert candidate(3) == "Misc", "Error Misc"
	assert candidate(3) == "Misc", "3 failed"
	assert candidate(5) == "Scoring"
	assert candidate(1) == "Base", "Base is not Base"
	assert candidate(6) == "Opponent", "Opponent is not Opponent"
	assert candidate(6) == "Opponent", "Error Opponent"
	assert candidate(6) == "Opponent"
	assert candidate(3) == "Misc", "3 is Misc"
	assert candidate(1) == "Base", "Entering 1 should return Base"
	assert candidate(2) == "Advanced", "2 is Advanced"
	assert candidate(1) == "Base", "Base"
	assert candidate(7) == "Usage", "Failed Test 7"
	assert candidate(7) == "Usage", "Error Usage"
	assert candidate(2) == "Advanced", "Advanced is not Advanced"
	assert candidate(5) == "Scoring", "5 failed"
	assert candidate(6) == "Opponent", "Failed Test 6"
	assert candidate(4) == "Four Factors", "Four Factors is not Four Factors"
	assert candidate(6) == "Opponent", "candidate(6) should be 'Opponent'"
	assert candidate(2) == "Advanced", "Failed Test 2"
	assert candidate(5) == "Scoring", "Scoring is not Scoring"
	assert candidate(1) == "Base", "Failed Test 1"
	assert candidate(4) == "Four Factors", "candidate(4) should be 'Four Factors'"
	assert candidate(2) == "Advanced", "2 failed"
	assert candidate(4) == "Four Factors", "4 failed"
	assert candidate(7) == "Usage", "7 is Usage"
	assert candidate(4) == "Four Factors", "Failed Test 4"
	assert candidate(1) == "Base"
	assert candidate(3) == "Misc", "candidate(3) should be 'Misc'"
	assert candidate(6) == "Opponent", "6 is Opponent"
	assert candidate(6) == "Opponent", "6 failed"
	assert candidate(1) == "Base", "1 is Base"
	assert candidate(1) == "Base", "1 failed"
	assert candidate(4) == "Four Factors", "Error Four Factors"
	assert candidate(4) == "Four Factors", "4 is Four Factors"
	assert candidate(5) == "Scoring", "candidate(5) should be 'Scoring'"
	assert candidate(7) == "Usage", "Usage"
	assert candidate(5) == "Scoring", "Failed Test 5"
	assert candidate(1) == "Base", "Error Base"
	assert candidate(2) == "Advanced"
	assert candidate(6) == "Opponent", "Opponent"
	assert candidate(7) == "Usage", "7 failed"
	assert candidate(4) == "Four Factors"
	assert candidate(5) == "Scoring", "5 is Scoring"
	assert candidate(1) == "Base", "candidate(1) should be 'Base'"
	assert candidate(7) == "Usage", "candidate(7) should be 'Usage'"
	assert candidate(3) == "Misc", "Misc is not Misc"
	assert candidate(2) == "Advanced", "Advanced"
	assert candidate(2) == "Advanced", "Error Advanced"
	assert candidate(3) == "Misc", "Misc"
	assert candidate(3) == "Misc"
	assert candidate(7) == "Usage"
	assert candidate(4) == "Four Factors", "Four Factors"
	assert candidate(5) == "Scoring", "Scoring"
def test_check():
	check(measure_type)
