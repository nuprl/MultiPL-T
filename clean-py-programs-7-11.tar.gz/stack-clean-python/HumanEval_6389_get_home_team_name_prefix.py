def get_home_team_name_prefix(league: str) -> str:
    """
    get prefix for home team name
    @param league: league name
    """
    ### Canonical solution below ###
    league = league.replace("Ligacup ", "")
    league = league.replace("Schweizer Cup ", "")
    league = league.replace(" Regional", "")

    if league.startswith("Herren"):
        return "Herren"
    if league.startswith("Damen"):
        return "Damen"
    return league


### Unit tests below ###
def check(candidate):
	assert candidate(league="Ligacup H") == "H"
	assert candidate(league="Damen Oberliga") == "Damen"
	assert candidate(league="Herren Ligacup 2019") == "Herren"
	assert candidate(league="Herren Ligacup 3") == "Herren"
	assert candidate(
    "Damen Schweizer Cup") == "Damen"
	assert candidate(
    "Damen Liga 2") == "Damen"
	assert candidate(league="Herren 4. DFB-Pokal") == "Herren"
	assert candidate(
    "Damen 1. Bundesliga Damen") == "Damen", "candidate failed"
	assert candidate(
    "Damen 2. Bundesliga 2020") == "Damen", "candidate test 8 failed"
	assert candidate(league="Herren 5. Bundesliga") == "Herren"
	assert candidate(
    "Ligue 1") == "Ligue 1", "test failed"
	assert candidate(
    "Damen 1. Bundesliga 2020") == "Damen", "candidate test 7 failed"
	assert candidate(league="Herren Regional 2021") == "Herren"
	assert candidate(league="Herren Ligacup 2018") == "Herren"
	assert candidate(league="Damen 3. Bundesliga") == "Damen"
	assert candidate(
    "Ligue 2") == "Ligue 2", "test failed"
	assert candidate(
    "Ligue 2 Regional") == "Ligue 2", "test failed"
	assert candidate(league="Herren Ligacup 10") == "Herren"
	assert candidate(league="Damen 5. DFB-Pokal") == "Damen"
	assert candidate(
    "Premier League") == "Premier League"
	assert candidate(
    "Herren Ligacup 2018/2019") == "Herren"
	assert candidate(
    "Herren Ligabundesliga") == "Herren"
	assert candidate(
    "Damen Ligacup 2") == "Damen", "candidate: test 2 failed"
	assert candidate(league="Ligacup A") == "A"
	assert candidate(
    "Herren 1. Bundesliga Regional") == "Herren", "candidate failed"
	assert candidate(
    "Herren Liga 6") == "Herren"
	assert candidate(league="Herren Liga 3") == "Herren"
	assert candidate(
    "1. Bundesliga Regional") == "1. Bundesliga", "candidate failed"
	assert candidate(
    "Herren 1. Bundesliga") == "Herren", "candidate: incorrect prefix for Herren 1. Bundesliga"
	assert candidate(league="Herren Ligacup F") == "Herren"
	assert candidate(league="Damen Liga 6. Liga") == "Damen"
	assert candidate(league="Damen Liga 3. Liga") == "Damen"
	assert candidate(
    "Damen Women's Liga") == "Damen", "candidate: incorrect prefix for Damen Women's Liga"
	assert candidate(league="Ligacup G") == "G"
	assert candidate(
    "Herren Ligacup 2") == "Herren", "candidate: test 1 failed"
	assert candidate(league="Herren Ligacup B") == "Herren"
	assert candidate(league="Herren Ligacup 2020 Regional") == "Herren"
	assert candidate(league="Herren Ligacup G") == "Herren"
	assert candidate(league="Ligue 1") == "Ligue 1"
	assert candidate(
    "Damen Liga 2020 Regional") == "Damen", "candidate test 6 failed"
	assert candidate(league="Damen Liga 1. Liga") == "Damen"
	assert candidate("Damen Ligabasketball 2. Bundesliga Regional") == "Damen"
	assert candidate(league="Schweizer Cup") == "Schweizer Cup"
	assert candidate(
    "Championship") == "Championship", "test failed"
	assert candidate(league="Herren 5. DFB-Pokal") == "Herren"
	assert candidate(league="Herren Ligacup 11") == "Herren"
	assert candidate(
    "Damenliga Bayern München") == "Damen"
	assert candidate(league="Herren Ligacup 14") == "Herren"
	assert candidate(league="Damen 4. Bundesliga") == "Damen"
	assert candidate(
    "Damen Bundesliga") == "Damen", "candidate: incorrect prefix for Damen Bundesliga"
	assert candidate(league="Herren Ligacup I") == "Herren"
	assert candidate(
    "Herrenliga Bayern München") == "Herren"
	assert candidate(
    "RFPL") == "RFPL", "test failed"
	assert candidate(league="Damen Bundesliga 1") == "Damen"
	assert candidate(league="Herren Bundesliga") == "Herren"
	assert candidate(league="Damen Ligacup 2018 Schweizer Cup") == "Damen"
	assert candidate(league="Herren Ligacup 2018 Schweizer Cup 2") == "Herren"
	assert candidate(
    "Herren Ligamax") == "Herren"
	assert candidate(league="Damen 2. Bundesliga Regional") == "Damen"
	assert candidate(league="Herren Ligacup 7") == "Herren"
	assert candidate(
    "Herren Bundesliga") == "Herren", "candidate: incorrect prefix for Herren Bundesliga"
	assert candidate(league="Damen Liga 9. Liga") == "Damen"
	assert candidate(league="Herren Ligacup 2013 Regional") == "Herren"
	assert candidate(
    "Herren Schweizer Cup 2018/2019") == "Herren"
	assert candidate(
    "Herren Ligaviertel") == "Herren"
	assert candidate("Schweizer Cup") == "Schweizer Cup"
	assert candidate(league="Herren Ligacup M") == "Herren"
	assert candidate(league="Damen Ligacup 2021") == "Damen"
	assert candidate(league="Herren Ligacup 5") == "Herren"
	assert candidate(league="Damen Liga 10. Liga") == "Damen"
	assert candidate(
    "Herren Liga 2") == "Herren"
	assert candidate(league="Damen 5. Bundesliga") == "Damen"
	assert candidate(league="Damen Liga 5. Liga") == "Damen"
	assert candidate(league="Ligacup D") == "D"
	assert candidate(
    "Herren Bundesliga") == "Herren"
	assert candidate(
    "Damen 1. Bundesliga") == "Damen", "candidate failed"
	assert candidate(
    "Ligue 3 Regional") == "Ligue 3", "test failed"
	assert candidate(league="Damen Liga") == "Damen"
	assert candidate(league="Herren Schweizer Cup 2021 Regional") == "Herren"
	assert candidate(league="Herren") == "Herren"
	assert candidate(league="Damen 3. Liga") == "Damen"
	assert candidate(
    "Damen 1. Bundesliga") == "Damen", "candidate: incorrect prefix for Damen 1. Bundesliga"
	assert candidate(league="Herren 1. Bundesliga Regional") == "Herren"
	assert candidate(league="Herren Ligacup 2018 Regional") == "Herren"
	assert candidate("Herren Ligabasketball 2. Bundesliga") == "Herren"
	assert candidate(league="Damen Bundesliga Regional") == "Damen"
	assert candidate(league="Herren Ligacup 1992 Regional") == "Herren"
	assert candidate(league="Herren Ligacup 2019 Regional") == "Herren"
	assert candidate(
    "Damen Liga") == "Damen"
	assert candidate(league="Damen Ligacup 2021 Regional") == "Damen"
	assert candidate(league="Herren Ligacup D") == "Herren"
	assert candidate(league="Damen Ligacup 1992") == "Damen"
	assert candidate(
    "Damen Ligacup 2018/2019") == "Damen"
	assert candidate(
    "Herren Ligacup 2021") == "Herren", "test failed"
	assert candidate(league="Herren Ligacup N") == "Herren"
	assert candidate(league="Herren Ligacup 1") == "Herren"
	assert candidate(
    "Herren Liga 1 Regional") == "Herren", "candidate failed"
	assert candidate(league="Damen Liga 2") == "Damen"
	assert candidate(league="Ligacup C") == "C"
	assert candidate(league="Herren Liga 2") == "Herren"
	assert candidate("Herren Ligabasketball 2. Bundesliga Regional") == "Herren"
	assert candidate(
    "Herren Liga 2020 Regional") == "Herren", "candidate test 3 failed"
	assert candidate(
    "Herren Schweizer Cup 2018/2019 Regional") == "Herren"
	assert candidate(league="Damen Regional 2021") == "Damen"
	assert candidate(league="Damen Ligue 1") == "Damen"
	assert candidate(league="Ligacup") == "Ligacup"
	assert candidate(
    "Damen Ligacup") == "Damen"
	assert candidate(league="Herren Liga 2. Liga") == "Herren"
	assert candidate(league="Damen 4. DFB-Pokal") == "Damen"
	assert candidate(
    "Herren 1. Bundesliga") == "Herren", "candidate failed"
	assert candidate(league="Damen Liga 1") == "Damen"
	assert candidate(league="Ligacup J") == "J"
	assert candidate(
    "Herren Ligacup 2021/22 Regional") == "Herren", "candidate() failed"
	assert candidate(league="Damen Liga 4. Liga") == "Damen"
	assert candidate(league="Herren Oberliga") == "Herren"
	assert candidate(league="Herren 3. Liga") == "Herren"
	assert candidate(league="Herren Ligacup K") == "Herren"
	assert candidate(
    "Herren Liga 3") == "Herren"
	assert candidate(league="Herren Bundesliga 1") == "Herren"
	assert candidate(
    "Ligue 1 Regional") == "Ligue 1", "test failed"
	assert candidate(league="Herren Ligacup C") == "Herren"
	assert candidate(
    "Herren Ligue 1") == "Herren"
	assert candidate(league="Damen Bundesliga 2") == "Damen"
	assert candidate(league="Damen 2. Bundesliga") == "Damen"
	assert candidate(
    "Herren Ligabasketball 2. Bundesliga") == "Herren"
	assert candidate(league="Herren Bundesliga 2") == "Herren"
	assert candidate(league="Damen Ligacup 2013") == "Damen"
	assert candidate(league="Herren Ligacup 6") == "Herren"
	assert candidate(
    "Herren Liga 9") == "Herren"
	assert candidate(league="Herren Ligacup O") == "Herren"
	assert candidate(league="Herren Schweizer Cup 2021") == "Herren"
	assert candidate(league="Herren 2. Liga") == "Herren"
	assert candidate(league="Ligacup K")
	assert candidate(league="Damen Liga 4") == "Damen"
	assert candidate(
    "Herren Ligasim") == "Herren"
	assert candidate(league="Herren 3. DFB-Pokal") == "Herren"
	assert candidate(
    "Herren Ligabasketball 2. Bundesliga Regional") == "Herren"
	assert candidate(league="Damen Ligacup 2018 Schweizer Cup 2") == "Damen"
	assert candidate(league="Damen 1. Bundesliga Regional") == "Damen"
	assert candidate(league="Damen Liga 7. Liga") == "Damen"
	assert candidate(league="Ligacup F") == "F"
	assert candidate(league="Herren 3. Oberliga") == "Herren"
	assert candidate(league="Herren Ligacup 2") == "Herren"
	assert candidate(
    "Herren Ligacup 2018/2019 Regional") == "Herren"
	assert candidate(
    "Herren Liga 5") == "Herren"
	assert candidate(league="Herren Ligue 1") == "Herren"
	assert candidate(league="Damen Liga 8. Liga") == "Damen"
	assert candidate(
    "Herren Women's Liga") == "Herren", "candidate: incorrect prefix for Herren Women's Liga"
	assert candidate(league="Damen Schweizer Cup 2021 Regional") == "Damen"
	assert candidate(
    "Ligue 3") == "Ligue 3", "test failed"
	assert candidate(league="Herren Ligacup 9") == "Herren"
	assert candidate(
    "Herren Liga 2020") == "Herren", "candidate test 1 failed"
	assert candidate(
    "Herren Eredivisie") == "Herren"
	assert candidate(league="Damen Ligue 3") == "Damen"
	assert candidate(league="Ligacup E") == "E"
	assert candidate(league="Herren Liga 4") == "Herren"
	assert candidate(league="Damen Ligacup 2018") == "Damen"
	assert candidate(league="Herren Ligacup 8") == "Herren"
	assert candidate(
    "Damen Ligacup 2021/22 Regional") == "Damen", "candidate() failed"
	assert candidate(league="Herren 4. Bundesliga") == "Herren"
	assert candidate(league="Herren Ligacup 2013") == "Herren"
	assert candidate(
    "Herren Liga 8") == "Herren"
	assert candidate(
    "Herren Ligacup 2021/22") == "Herren", "candidate() failed"
	assert candidate(league="Damen 1. Bundesliga") == "Damen"
	assert candidate(
    "Damen Bundesliga 2020") == "Damen", "candidate test 5 failed"
	assert candidate("Damen Liga 1") == "Damen", "candidate failed"
	assert candidate(league="Damen Ligue 4") == "Damen"
	assert candidate(league="Herren Ligacup 2021") == "Herren"
	assert candidate(
    "Herren Liga 1") == "Herren", "candidate failed"
	assert candidate(league="Herren Ligacup 12") == "Herren"
	assert candidate(league="Herren 1. Bundesliga") == "Herren"
	assert candidate(league="Damen Ligue 2") == "Damen"
	assert candidate(league="Damen Schweizer Cup 2021") == "Damen"
	assert candidate(league="Damen Bundesliga") == "Damen"
	assert candidate(
    "Herren Ligapremiere") == "Herren"
	assert candidate(league="Herren Ligacup 2020") == "Herren"
	assert candidate(
    "Damen Ligacup 2 Regional") == "Damen", "candidate: test 3 failed"
	assert candidate(league="Damen Ligacup 2018 Regional") == "Damen"
	assert candidate(
    "Bundesliga") == "Bundesliga"
	assert candidate(league="Herren 2. Bundesliga") == "Herren"
	assert candidate(
    "Herren Bundesliga 2020") == "Herren", "candidate test 2 failed"
	assert candidate(
    "Herren Liga 4") == "Herren"
	assert candidate(league="Herren Ligacup H") == "Herren"
	assert candidate(league="Ligacup B") == "B"
	assert candidate("Damen Ligacup 2021") == "Damen", "test failed"
	assert candidate(league="Herren 3. Bundesliga") == "Herren"
	assert candidate("Ligacup") == "Ligacup", "candidate failed"
	assert candidate(
    "Damen Schweizer Cup 2018/2019") == "Damen"
	assert candidate(
    "Herren Liga 1") == "Herren"
	assert candidate(
    "DFL Bayern München") == "DFL Bayern München"
	assert candidate(league="Herren Ligue 2") == "Herren"
	assert candidate(league="Damen 3. Oberliga") == "Damen"
	assert candidate(league="Damen Liga 3") == "Damen"
	assert candidate(
    "Damen Bundesliga 2") == "Damen"
	assert candidate(league="Herren Ligacup 1992") == "Herren"
	assert candidate(league="Damen") == "Damen"
	assert candidate(league="Herren Ligacup 4") == "Herren"
	assert candidate(league="Bundesliga") == "Bundesliga"
	assert candidate(
    "Damen Bundesliga") == "Damen"
	assert candidate(league="Herren Ligacup 2021 Regional") == "Herren"
	assert candidate(league="Herren 2. DFB-Pokal") == "Herren"
	assert candidate(league="Damen Ligacup 2018 Schweizer Cup 1") == "Damen"
	assert candidate(
    "Damen Ligacup 2018/2019 Regional") == "Damen"
	assert candidate(
    "Herren Liga") == "Herren"
	assert candidate(
    "Herren Bundesliga 1") == "Herren"
	assert candidate(
    "Herren Liga") == "Herren", "candidate: incorrect prefix for Herren Liga"
	assert candidate(league="Damen 1. DFB-Pokal") == "Damen"
	assert candidate(
    "Damen 1. Bundesliga Regional") == "Damen", "candidate failed"
	assert candidate(league="Damen Ligacup 2018 Schweizer Cup Regional") == "Damen"
	assert candidate("Schweizer Cup") == "Schweizer Cup", "candidate failed"
	assert candidate(
    "Herren Liga 7") == "Herren"
	assert candidate("Damen Ligabasketball 2. Bundesliga") == "Damen"
	assert candidate(league="Herren Liga") == "Herren"
	assert candidate("Damen Liga 1 Regional") == "Damen", "candidate failed"
	assert candidate(
    "Damen Ligacup 2021/22") == "Damen", "candidate() failed"
	assert candidate(league="Herren Bundesliga Regional") == "Herren"
	assert candidate(league="Damen Ligacup 2018 Schweizer Cup 2 Regional") == "Damen"
	assert candidate(league="Damen Liga 2. Liga") == "Damen"
	assert candidate(
    "EFL Championship") == "EFL Championship", "test failed"
	assert candidate(league="Herren Ligacup L") == "Herren"
	assert candidate(
    "Damen Ligue 2") == "Damen"
	assert candidate(league="Damen Ligacup 2019") == "Damen"
	assert candidate(league="Ligacup I") == "I"
	assert candidate(
    "Herren Ligacup") == "Herren"
	assert candidate(league="Herren Ligacup E") == "Herren"
	assert candidate(
    "Herren Schweizer Cup") == "Herren"
	assert candidate(league="Herren Ligacup A") == "Herren"
	assert candidate(
    "Damen Liga") == "Damen", "candidate: incorrect prefix for Damen Liga"
	assert candidate(league="Damen 3. DFB-Pokal") == "Damen"
	assert candidate(
    "Herren 1. Bundesliga Herren") == "Herren", "candidate failed"
	assert candidate(
    "Damen Liga 2020") == "Damen", "candidate test 4 failed"
	assert candidate(
    "Damen Schweizer Cup 2018/2019 Regional") == "Damen"
	assert candidate(league="Damen Ligacup 2020") == "Damen"
	assert candidate(
    "1. Bundesliga") == "1. Bundesliga", "candidate failed"
	assert candidate(league="Herren Ligacup 13") == "Herren"
	assert candidate(league="Herren Liga 1") == "Herren"
	assert candidate(league="Herren Ligacup J") == "Herren"
	assert candidate(
    "Herren Liga A") == "Herren"
	assert candidate(league="Damen Ligacup 2018 Schweizer Cup 1 Regional") == "Damen"
def test_check():
	check(get_home_team_name_prefix)
