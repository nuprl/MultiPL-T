def porezi(val,min,max):
    """Zagotovimo da je vrednost med 0(min) in 100(max) """
    ### Canonical solution below ###
    if val < min:
       return min
    elif val > max:
       return max
    return val


### Unit tests below ###
def check(candidate):
	assert candidate(10,11,19) == 11
	assert candidate(11, 1, 10) == 10
	assert candidate(10, 0, 100) == 10
	assert candidate(1000, 0, 100) == 100
	assert candidate(2,100,100) == 100
	assert candidate(101,0,100) == 100
	assert candidate(-10, 0, 100) == 0
	assert candidate(100, 0, 10) == 10
	assert candidate(15, 10, 20) == 15
	assert candidate(-100,0,100) == 0
	assert candidate(100, 100, 300) == 100
	assert candidate(2,1,100) == 2
	assert candidate(0, 0, 100) == 0
	assert candidate(100, 0, 100) == 100
	assert candidate(0,0,100) == 0
	assert candidate(10, 2, 10) == 10
	assert candidate(-15, 0, 100) == 0
	assert candidate(-1000, 10, 100) == 10
	assert candidate(50, 100, 100) == 100
	assert candidate(2,1,2) == 2
	assert candidate(-1000, 0, 100) == 0
	assert candidate(100, 10, 100) == 100
	assert candidate(0, 100, 100) == 100
	assert candidate(101, 1, 100) == 100
	assert candidate(1,0,100) == 1
	assert candidate(0, 1, 10) == 1
	assert candidate(100,0,99) == 99
	assert candidate(0, 1, 100) == 1
	assert candidate(11, 2, 10) == 10
	assert candidate(-10,0,100) == 0
	assert candidate(0, 0, 50) == 0
	assert candidate(100, 100, 100) == 100
	assert candidate(10,0,9) == 9
	assert candidate(50,0,0) == 0
	assert candidate(10,10,100) == 10
	assert candidate(1,0,0) == 0
	assert candidate(0,100,100) == 100
	assert candidate(1000,0,100) == 100
	assert candidate(-100, 0, 100) == 0
	assert candidate(0, 50, 100) == 50
	assert candidate(0,1,100) == 1
	assert candidate(-1, 2, 10) == 2
	assert candidate(100, 50, 100) == 100
	assert candidate(20, 10, 20) == 20
	assert candidate(-10, 10, 100) == 10
	assert candidate(10, 10, 20) == 10
	assert candidate(100, 0, 50) == 50
	assert candidate(5, 2, 10) == 5
	assert candidate(100, 1, 100) == 100
	assert candidate(50,1,100) == 50
	assert candidate(30,0,40) == 30
	assert candidate(10, 10, 100) == 10
	assert candidate(-50,0,100) == 0
	assert candidate(100,100,100) == 100
	assert candidate(150,0,100) == 100
	assert candidate(5, 1, 10) == 5
	assert candidate(-100, 10, 100) == 10
	assert candidate(10,1,100) == 10
	assert candidate(10,0,100) == 10
	assert candidate(50, 0, 100) == 50
	assert candidate(100, 200, 300) == 200
	assert candidate(200,0,100) == 100
	assert candidate(15, 0, 100) == 15
	assert candidate(10, 0, 10) == 10
	assert candidate(100,1,100) == 100
	assert candidate(-10, 0, 10) == 0
	assert candidate(300, 200, 300) == 300
	assert candidate(30,-10,40) == 30
	assert candidate(50, 0, 50) == 50
	assert candidate(-1,0,100) == 0
	assert candidate(15,0,100) == 15
	assert candidate(110, 0, 100) == 100
	assert candidate(500,0,100) == 100
	assert candidate(30,0,20) == 20
	assert candidate(50, 10, 100) == 50
	assert candidate(30, 0, 100) == 30
	assert candidate(100,0,100) == 100
	assert candidate(1,100,100) == 100
	assert candidate(10, 1, 100) == 10
	assert candidate(2,2,2) == 2
	assert candidate(50,0,100) == 50
	assert candidate(150, 0, 100) == 100
	assert candidate(5, 1, 100) == 5
	assert candidate(2,0,1) == 1
	assert candidate(30,-10,10) == 10
	assert candidate(2,2,3) == 2
	assert candidate(3,0,100) == 3
def test_check():
	check(porezi)
