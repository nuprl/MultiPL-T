def prepend_non_digit(string):
    """ 
     Prepends non-digit-containing string.
     Useful in combination with built-in slugify in order to create strings
     from titles that can be used as HTML IDs, which cannot begin with digits.
     """
	### Canonical solution below ###    
    if string[:1].isdigit():
        string = "go-to-{0}".format(string)
    return string

### Unit tests below ###
def check(candidate):
	assert candidate(u"123456789") == u"go-to-123456789"
	assert candidate(u"go-to-the-moon") == u"go-to-the-moon"
	assert candidate("1234-5678.9012") == "go-to-1234-5678.9012"
	assert candidate(u"hello") == u"hello"
	assert candidate("go-to-123") == "go-to-123"
	assert candidate("1234") == "go-to-1234"
	assert candidate(u"3") == u"go-to-3"
	assert candidate(u"1a1") == u"go-to-1a1"
	assert candidate(u"1234-5678-v2") == u"go-to-1234-5678-v2"
	assert candidate(u'go-to-0123456789') == u'go-to-0123456789'
	assert candidate(u"123a") == "go-to-123a"
	assert candidate(u"12345") == u"go-to-12345"
	assert candidate(u"This is a test") == u"This is a test"
	assert candidate(u"1234") == u"go-to-1234"
	assert candidate(u"1234-5678-v2.html") == u"go-to-1234-5678-v2.html"
	assert candidate(u"1234567hello") == u"go-to-1234567hello"
	assert candidate("123") == "go-to-123"
	assert candidate(u"1a") == u"go-to-1a"
	assert candidate("a123a") == "a123a"
	assert candidate("123abc") == "go-to-123abc"
	assert candidate(u"12a3") == "go-to-12a3"
	assert candidate(u"12hello") == u"go-to-12hello"
	assert candidate("111") == "go-to-111"
	assert candidate(u"100%") == u"go-to-100%"
	assert candidate(u"101-ways-to-fail") == u"go-to-101-ways-to-fail"
	assert candidate(u"a1") == u"a1"
	assert candidate("1") == "go-to-1"
	assert candidate("11") == "go-to-11"
	assert candidate(u'0') == u'go-to-0'
	assert candidate(u"Python") == u"Python"
	assert candidate(u"1") == u"go-to-1"
	assert candidate("1234.5678") == "go-to-1234.5678"
	assert candidate(u"") == u""
	assert candidate("hello") == "hello"
	assert candidate(u"123456hello") == u"go-to-123456hello"
	assert candidate("") == ""
	assert candidate(u"1a23") == "go-to-1a23"
	assert candidate("abc") == "abc"
	assert candidate("abc123") == "abc123"
	assert candidate(u'go-to-0') == u'go-to-0'
	assert candidate(u"a12") == u"a12"
	assert candidate(u"1234hello") == u"go-to-1234hello"
	assert candidate(u"3-things-1") == u"go-to-3-things-1"
	assert candidate(u"12345hello") == u"go-to-12345hello"
	assert candidate("a") == "a"
	assert candidate("1foo") == "go-to-1foo"
	assert candidate('1234') == 'go-to-1234'
	assert candidate(u"a123") == u"a123"
	assert candidate("a123") == "a123"
	assert candidate(u"a") == u"a"
	assert candidate("123foo") == "go-to-123foo"
	assert candidate("123a") == "go-to-123a"
	assert candidate(u"2go-to-me") == u"go-to-2go-to-me"
	assert candidate("foo1") == "foo1"
	assert candidate("123a 123") == "go-to-123a 123"
	assert candidate(u"go-to-me") == u"go-to-me"
	assert candidate("hello1234") == "hello1234"
	assert candidate(u"1hello") == u"go-to-1hello"
	assert candidate(u"12345678hello") == u"go-to-12345678hello"
	assert candidate("foo") == "foo"
	assert candidate(u"123hello") == u"go-to-123hello"
def test_check():
	check(prepend_non_digit)
