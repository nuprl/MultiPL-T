def projection_type_validator(x):
    """
    Property: Projection.ProjectionType
    """
    ### Canonical solution below ###
    valid_types = ["KEYS_ONLY", "INCLUDE", "ALL"]
    if x not in valid_types:
        raise ValueError("ProjectionType must be one of: %s" % ", ".join(valid_types))
    return x


### Unit tests below ###
def check(candidate):
	assert candidate("KEYS_ONLY") == "KEYS_ONLY"
	assert candidate('KEYS_ONLY') == 'KEYS_ONLY'
	assert candidate("ALL") == "ALL"
	assert candidate('ALL') == 'ALL'
	assert candidate('INCLUDE') == 'INCLUDE'
	assert candidate("INCLUDE") == "INCLUDE"
def test_check():
	check(projection_type_validator)
