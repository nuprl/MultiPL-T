def function_named(fn, name):
    """ Return a function with a given __name__.
     
     Will assign to __name__ and return the original function if possible on
     the Python implementation, otherwise a new function will be constructed.
     
     """
	### Canonical solution below ###    
    fn.__name__ = name
    return fn

### Unit tests below ###
def check(candidate):
	assert candidate(lambda x: x, 'hello').__name__ == 'hello'
	assert candidate(lambda: None, 'foo').__name__ == 'foo'
	assert candidate(lambda: None,'my_func').__name__ =='my_func'
	assert candidate(lambda x: x, 'f').__name__ == 'f'
	assert candidate(lambda x: None, "foo").__name__ == "foo"
	assert candidate(lambda x, y: x + y, "baz")(1, 2) == 3
	assert candidate(lambda: None, u"bar").__name__ == "bar"
	assert candidate(lambda x: x, "foo")("bar") == "bar"
	assert candidate(lambda x: x, 'new_name').__name__ == 'new_name'
	assert candidate(lambda: None, 'a').__name__ == 'a'
	assert candidate(lambda: None, 'test').__name__ == 'test'
	assert candidate(lambda: None, u'foo').__name__ == 'foo'
	assert candidate(lambda x: x, 'bar').__name__ == 'bar'
	assert candidate(lambda x: x, 'new_name')(1) == 1
	assert candidate(lambda x: x, "x").__name__ == "x"
	assert candidate(lambda: 1, 'foo').__name__ == 'foo'
	assert candidate(lambda: 0, "baz").__name__ == "baz"
	assert candidate(lambda x: x, "bar")("baz") == "baz"
	assert candidate(lambda: 0,'my_function').__name__ =='my_function'
	assert candidate(lambda x: x, 'foo').__name__ == 'foo'
	assert candidate(lambda: None,'myname').__name__ =='myname'
	assert candidate(lambda x: x, 'f')('x') == 'x'
	assert candidate(lambda x: x, 'baz').__name__ == 'baz'
	assert candidate(lambda: None, "bar").__name__ == "bar"
	assert candidate(lambda x: x, "x") is not candidate(lambda x: x, "x")
	assert candidate(lambda x, y, z: None, "foo").__name__ == "foo"
	assert candidate(lambda: None, 'f')() is None
	assert candidate(lambda: None, "foo").__name__ == "foo"
	assert candidate(lambda x: x, u'hello')('world') == 'world'
	assert candidate(lambda x: x, 'x').__name__ == 'x'
	assert candidate(lambda x: x, 'hello')('world') == 'world'
	assert candidate(lambda x, y: None, "foo").__name__ == "foo"
	assert candidate(lambda x: x, "foo").__name__ == "foo"
	assert candidate(lambda: None, "f\xe9e").__name__ == "f\xe9e"
	assert candidate(lambda x: x, "x")("y") == "y"
	assert candidate(lambda x: x, 'test').__name__ == 'test'
	assert candidate(lambda: None, u"foo").__name__ == "foo"
	assert candidate(lambda: None, 'test_candidate').__name__ == 'test_candidate'
	assert candidate(lambda: 0, 'foo').__name__ == 'foo'
	assert candidate(lambda: 0, "bar").__name__ == "bar"
	assert candidate(lambda x: x, 'foo')('bar') == 'bar'
	assert candidate(lambda: None, 'f').__name__ == 'f'
	assert candidate(lambda: None, 'foobar').__name__ == 'foobar'
	assert candidate(lambda: 0,'my_function')() == 0
def test_check():
	check(function_named)
