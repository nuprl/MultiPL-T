def is_json_merge_patch(data):
    """
    :param dict data: JSON data
    :returns: whether the JSON data is a JSON Merge Patch
    :rtype: bool
    """
    ### Canonical solution below ###
    return '$schema' not in data and ('definitions' in data or 'properties' in data)


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'definitions': {'A': {'type':'string'}}, 'properties': {'a': {'type':'string'}}}
) == True
	assert candidate(dict(foo='bar', definitions=dict(a='b'))) is True
	assert candidate({'a': 1}) is False
	assert candidate(
    {
        'definitions': {}
    }
) == True
	assert not candidate(
    {
        'name': 'foo',
        'properties': {'a': {'type':'string'}},
        '$schema': 'http://json-schema.org/draft-07/schema#',
    }
)
	assert candidate(
    {
        'properties': {},
        'definitions': {},
        '$schema': 'http://json-schema.org/draft-04/schema#'
    }
) == False
	assert candidate(
    {'$schema': 'https://json-schema.org/draft/2020-12/schema', 'properties': {'a': {'type':'string'}}}
) == False
	assert candidate([]) is False
	assert candidate(
    {
        'name': 'foo',
        'properties': {'a': {'type':'string'}},
    }
)
	assert candidate({}) == False
	assert candidate(
    {'$schema': 'https://json-schema.org/draft/2020-12/schema', 'definitions': {'A': {'type':'string'}}}
) == False
	assert candidate(
    {
        'properties': {},
        '$schema': 'http://json-schema.org/draft-04/schema#'
    }
) == False
	assert not candidate([1, 2, 3])
	assert not candidate(
    {
        'owner': {
            'name': 'Bob'
        }
    }
)
	assert candidate({'properties': {'foo': 'bar'}}) == True
	assert candidate({'$schema': 'http://json-schema.org/draft-04/schema#'}) is False
	assert candidate(
    {
        'definitions': {
            'Pet': {
                'properties': {
                    'name': {
                        'type':'string'
                    }
                }
            }
        },
        'properties': {
            'owner': {
                '$ref': '#/definitions/Pet'
            }
        }
    }
)
	assert candidate(dict(foo='bar', properties=dict(a='b'))) is True
	assert candidate(
    {
        'properties': {}
    }
) == True
	assert candidate({'definitions': {}}) is True
	assert candidate({'properties': {}}) is True
	assert candidate(
    {
        'definitions': {},
        'properties': {}
    }
) == True
	assert not candidate({'foo': 'bar'})
	assert candidate({'properties': 1}) is True
	assert candidate({'definitions': 1}) is True
	assert not candidate({})
	assert candidate(dict(foo='bar')) is False
	assert candidate(
    {
        '$schema': 'http://json-schema.org/draft-04/schema#'
    }
) == False
	assert candidate({}) is False
def test_check():
	check(is_json_merge_patch)
