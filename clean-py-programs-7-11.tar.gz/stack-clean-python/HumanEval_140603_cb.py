def cb(function, n=1):  # pylint: disable=invalid-name
    """Create a callback whose first n argument are ignored

    Returns a function whose first n arguments are ignored, and which returns
    the result of the function passed in parameters :
    cb(f)(ignored, *args) == f(*args)
    cb(f, 2)(i1, i2, *args) == f(*args)
    """
    ### Canonical solution below ###
    return lambda *args: function(*args[n:])


### Unit tests below ###
def check(candidate):
	assert candidate(lambda a: a, 0)(1) == 1
	assert candidate(lambda a, b: a + b, 0)(1, 2) == 3
	assert candidate(lambda a, b: (a, b), 2)(1, 2, 3, 4) == (3, 4)
	assert candidate(lambda x: x + 1, 0)(1) == 2
	assert candidate(lambda x: x, 0)(1) == 1
	assert candidate(lambda x: x, 1)(1, 2) == 2
	assert candidate(lambda: 1)() == 1
	assert candidate(lambda x, y: x + y, 0)(1, 2) == 3
def test_check():
	check(cb)
