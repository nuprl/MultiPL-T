def _websafe_component(c, alt=False):
  """Convert a color component to its web safe equivalent.

  Parameters:
    :c:
      The component value [0...1]
    :alt:
      If True, return the alternative value instead of the nearest one.

  Returns:
    The web safe equivalent of the component value.

  """
    ### Canonical solution below ###
  # This sucks, but floating point between 0 and 1 is quite fuzzy...
  # So we just change the scale a while to make the equality tests
  # work, otherwise it gets wrong at some decimal far to the right.
  sc = c * 100.0

  # If the color is already safe, return it straight away
  d = sc % 20
  if d==0: return c

  # Get the lower and upper safe values
  l = sc - d
  u = l + 20

  # Return the 'closest' value according to the alt flag
  if alt:
    if (sc-l) >= (u-sc): return l/100.0
    else: return u/100.0
  else:
    if (sc-l) >= (u-sc): return u/100.0
    else: return l/100.0


### Unit tests below ###
def check(candidate):
	assert candidate(0.41) == 0.4
	assert candidate(0.9999999) == 1.0
	assert candidate(1.0, True) == 1.0
	assert candidate(0.0009) == 0.0
	assert candidate(0.01) == 0.0
	assert candidate(0.9, alt=True) == 0.8
	assert candidate(0.20) == 0.20
	assert candidate(0.000001) == 0.0
	assert candidate(0.21) == 0.20
	assert candidate(0.00001) == 0.0
	assert candidate(0.6, True) == 0.6
	assert candidate(1.0) == 1.0
	assert candidate(0.2, alt=True) == 0.2
	assert candidate(0.8, alt=True) == 0.8
	assert candidate(0.0000001) == 0.0
	assert candidate(0.0, alt=True) == 0.0
	assert candidate(0.00) == 0.00
	assert candidate(0.8) == 0.8
	assert candidate(0.61) == 0.6
	assert candidate(0.0001) == 0.0
	assert candidate(0.9999) == 1.0
	assert candidate(0.49) == 0.4
	assert candidate(0.6, alt=True) == 0.6
	assert candidate(0.99) == 1.0
	assert candidate(0.00) == 0.0
	assert candidate(0.000000000, False) == 0.000000000
	assert candidate(0.80) == 0.80
	assert candidate(0.000000000, True) == 0.000000000
	assert candidate(0.2, True) == 0.2
	assert candidate(1.0, alt=True) == 1.0
	assert candidate(0.9) == 1.0
	assert candidate(1.00) == 1.00
	assert candidate(0.21) == 0.2
	assert candidate(0.001) == 0.0
	assert candidate(0.4, alt=True) == 0.4
	assert candidate(0.999) == 1.0
	assert candidate(0.81) == 0.8
	assert candidate(0.0) == 0.0
	assert candidate(0.2) == 0.2
	assert candidate(0.000000001) == 0.0
	assert candidate(0.999999) == 1.0
	assert candidate(0.0, True) == 0.0
	assert candidate(0.29) == 0.2
	assert candidate(0.40) == 0.40
	assert candidate(0.69) == 0.6
	assert candidate(0.60) == 0.60
	assert candidate(0.8, True) == 0.8
	assert candidate(0.99999999) == 1.0
	assert candidate(0.4) == 0.4
	assert candidate(0.9, alt=True) == 0.80
	assert candidate(0.4, True) == 0.4
	assert candidate(0.19) == 0.2
	assert candidate(0.1, alt=True) == 0.0
	assert candidate(0.3) == 0.4
	assert candidate(0.79) == 0.8
	assert candidate(0.00000001) == 0.0
	assert candidate(0.0, alt=False) == 0.0
	assert candidate(0.6) == 0.6
	assert candidate(0.99999) == 1.0
def test_check():
	check(_websafe_component)
