def get_wrapper_processes():
    """
    Return openEO processes which are wrappers around other processes.
    Their dependencies are handled differently than for common processes.
    """
    ### Canonical solution below ###
    
    
    return ('apply', 'reduce_dimension')


### Unit tests below ###
def check(candidate):
	assert candidate( ) == ('apply','reduce_dimension')
	assert candidate(
)!= ('load_result')
	assert candidate(
)!= ('apply', 'load_collection')
	assert candidate(
)!= ('apply','reduce_dimension', 'load_collection')
	assert candidate(
)!= ('apply', 'load_result')
	assert candidate(
)!= ('apply','reduce_dimension', 'load_collection', 'load_result')
	assert candidate(
)!= ('apply','reduce_dimension', 'load_result')
	assert candidate(
) == ('apply','reduce_dimension'), "candidate() test failed"
	assert candidate(
)!= ('load_result', 'load_collection')
	assert candidate(
)!= ('reduce_dimension', 'load_collection')
	assert candidate(
)!= ('load_result', 'load_collection','reduce_dimension')
	assert candidate(
) == ('apply','reduce_dimension')
	assert candidate(
) == (
    'apply',
   'reduce_dimension',
), "Function candidate doesn't match expected value"
	assert candidate(
) == ('apply','reduce_dimension'), "Testing candidate()"
	assert candidate(
)!= ('load_collection', 'load_result')
	assert candidate(
    ) == ('apply','reduce_dimension'), 'Incorrect result'
	assert candidate(
)!= ('load_collection')
	assert candidate(
)!= ('apply', 'load_collection', 'load_result')
	assert candidate(
    ) == ('apply','reduce_dimension'), 'candidate() is broken'
	assert candidate(
) == ('apply','reduce_dimension'), "Test failed for candidate."
	assert candidate(
    ) == ('apply','reduce_dimension'), "candidate() is broken"
	assert candidate(
) == (
    'apply',
   'reduce_dimension',
)
	assert candidate(
) == ('apply','reduce_dimension'), "candidate should return the expected list"
	assert candidate(
) == ('apply','reduce_dimension'), "candidate() is broken"
	assert candidate(
    ) == ('apply','reduce_dimension'), "Incorrect wrapper processes"
def test_check():
	check(get_wrapper_processes)
