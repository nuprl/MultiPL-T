def admin_method_attrs(**outer_kwargs):
    """
    Wrap an admin method with passed arguments as attributes and values.
    (common admin manipulation such as setting  short_description, etc.)
    """
    ### Canonical solution below ###
    def method_decorator(func):
        for kw, arg in outer_kwargs.items():
            setattr(func, kw, arg)
        return func
    return method_decorator


### Unit tests below ###
def check(candidate):
	assert candidate(short_description='Bar')(lambda x: x).__dict__['short_description'] == 'Bar'
	assert candidate(short_description="Test")(lambda x: x).__dict__ == {'short_description': 'Test'}
	assert candidate(short_description='Short Description')(lambda x: x).short_description == 'Short Description'
	assert candidate(short_description="test")(lambda: None).__dict__['short_description'] == "test"
	assert candidate(short_description="Test")(lambda x: x)
	assert candidate(short_description='Foo')(lambda x: x).__doc__ == None
	assert candidate(short_description='My short description')(lambda x: x)
	assert candidate(short_description='foo')(lambda x: x).short_description == 'foo'
	assert candidate(short_description="test")(lambda x: x)
	assert candidate(short_description='test')(lambda x: x).short_description == 'test'
	assert candidate(short_description='Test')(lambda x: x)
	assert candidate(short_description="foo")
	assert candidate(short_description='Short Description')(lambda x: x)
	assert candidate(short_description="Test") is not None
	assert candidate(short_description='foo', bar='baz')(lambda x: x).bar == 'baz'
	assert candidate(short_description='My short description', foo='bar')(lambda x: x).foo == 'bar'
	assert candidate(short_description='Short Description')(lambda x: x).short_description!= 'Shorter Description'
	assert candidate(short_description='Test',allow_tags=True,is_callable=True)(lambda x:x).__dict__ == {'allow_tags': True,'short_description': 'Test', 'is_callable': True}
	assert candidate(short_description='Test')(lambda x:x).__dict__ == {'short_description': 'Test'}
	assert candidate(short_description='foo')(lambda x: x)
	assert candidate(short_description='foo')(lambda: None).__dict__['short_description'] == 'foo'
	assert candidate(short_description="foo", foo="bar")(lambda x: x)
	assert candidate(short_description='Test',allow_tags=True,is_callable=True,admin_order_field='test')(lambda x:x).__dict__ == {'allow_tags': True,'short_description': 'Test', 'is_callable': True, 'admin_order_field': 'test'}
	assert candidate(short_description='foo')
	assert candidate(short_description='foo')(lambda x: x).__dict__['short_description'] == 'foo'
	assert candidate(short_description='Test',allow_tags=True)(lambda x:x).__dict__ == {'allow_tags': True,'short_description': 'Test'}
	assert candidate(short_description='Foo')(lambda x: x)
	assert candidate(short_description="Short Desc")(lambda x:x).__dict__['short_description'] == "Short Desc"
	assert candidate(short_description="Test")(lambda x: x) is not None
	assert candidate(short_description='test')(lambda x: x)
	assert candidate(short_description='Foo')(lambda x: x).__dict__['short_description'] == 'Foo'
	assert candidate(short_description='Foo')(lambda x:x)
	assert candidate(short_description='Hello')(lambda x: x)
	assert candidate(short_description="foo", foo="bar", bar=1)(lambda x: x)
	assert candidate(short_description='Test',allow_tags=True,is_callable=True,admin_order_field='test',admin_order_field_lazy=True)(lambda x:x).__dict__ == {'allow_tags': True,'short_description': 'Test', 'is_callable': True, 'admin_order_field': 'test', 'admin_order_field_lazy': True}
	assert candidate(short_description="foo")(lambda x: x)
	assert candidate(short_description='My short description')(lambda x: x).short_description == 'My short description'
def test_check():
	check(admin_method_attrs)
