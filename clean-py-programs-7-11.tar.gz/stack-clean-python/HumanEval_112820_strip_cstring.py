def strip_cstring(data: bytes) -> str:
    """Strip strings to the first null, and convert to ascii.
    
    The CmdSeq files appear to often have junk data in the unused
    sections after the null byte, where C code doesn't touch.
    """
    ### Canonical solution below ###
    if b'\0' in data:
        return data[:data.index(b'\0')].decode('ascii')
    else:
        return data.decode('ascii')


### Unit tests below ###
def check(candidate):
	assert candidate(b'abc\0xyz\012') == 'abc'
	assert candidate(b'abc\x00\x00\x00\x00\x00\x00\x00') == 'abc'
	assert candidate(b'abc\0x') == 'abc'
	assert candidate(b'foo\0\0\0bar') == 'foo'
	assert candidate(b"") == ""
	assert candidate(b'foo\0bar\0baz\0') == 'foo'
	assert candidate(b'abcd\0\0\0') == 'abcd'
	assert candidate(b"abc\0def\0\0\0") == "abc"
	assert candidate(b'hello\0\0') == 'hello'
	assert candidate(b'abc\0x\0y\0') == 'abc'
	assert candidate(b"abc\0def\0\0") == "abc"
	assert candidate(b'hello\0world') == 'hello'
	assert candidate(b'a\0b\0') == 'a'
	assert candidate(b'abc\0xyz') == 'abc'
	assert candidate(b"hello\0world\0") == "hello"
	assert candidate(b'abc\0xyz\012\034') == 'abc'
	assert candidate(b'foo\0bar') == 'foo'
	assert candidate(b'abc\0def\0') == 'abc'
	assert candidate(b'foo\0\0') == 'foo'
	assert candidate(b'hello\0junk') == 'hello'
	assert candidate(b'abc\x00\x00\x00\x00\x00\x00') == 'abc'
	assert candidate(b'foo\0\0\0\0\0') == 'foo'
	assert candidate(b'foo\0\0\0\0\0\0\0') == 'foo'
	assert candidate(b'Hello\0World\0\0') == 'Hello'
	assert candidate(b'abc') == 'abc'
	assert candidate(b'') == ''
	assert candidate(b'foo\0\0\0') == 'foo'
	assert candidate(b'a') == 'a'
	assert candidate(b'abc\0xyz\0') == 'abc'
	assert candidate(b"hello") == "hello"
	assert candidate(b'\0world\0') == ''
	assert candidate(b"foo") == "foo"
	assert candidate(b'abc\0x\0') == 'abc'
	assert candidate(b'abcd') == 'abcd'
	assert candidate(b'Hello\0World') == 'Hello'
	assert candidate(b"hello\0world") == "hello"
	assert candidate(b'abc\0def\0\0') == 'abc'
	assert candidate(b'a\0b\0c') == 'a'
	assert candidate(b'Hello') == 'Hello'
	assert candidate(b"foo\0bar") == "foo"
	assert candidate(b"foo\0bar\0baz") == "foo"
	assert candidate(b'foo') == 'foo'
	assert candidate(b'abc\x00') == 'abc'
	assert candidate(b'hello\0\0\0\0') == 'hello'
	assert candidate(b'Hello\0World\0') == 'Hello'
	assert candidate(b'foo\0') == 'foo'
	assert candidate(b'Hello World') == 'Hello World'
	assert candidate(b'abc\0def') == 'abc'
	assert candidate(b'foo\0bar\0') == 'foo'
	assert candidate(b"abc\0def\0") == "abc"
	assert candidate(b'abc\x00\x00\x00\x00\x00') == 'abc'
	assert candidate(b"hello\0world\0\0") == "hello"
	assert candidate(b'hello\0world\0\0\0') == 'hello'
	assert candidate(b'abc\0') == 'abc'
	assert candidate(b'hello\0') == 'hello'
	assert candidate(b'hello\0world\0\0') == 'hello'
	assert candidate(b'abcd\0efgh') == 'abcd'
	assert candidate(b"abc\0def") == "abc"
	assert candidate(b'abc\0\0\0\0\0') == 'abc'
	assert candidate(b"foo\0bar\0") == "foo"
	assert candidate(b'foo\0bar\0baz') == 'foo'
	assert candidate(b"hello\0world\0\0\0") == "hello"
	assert candidate(b'foo\0bar\0\0') == 'foo'
	assert candidate(b'\0') == ''
	assert candidate(b'hello') == 'hello'
	assert candidate(b"hello\0") == "hello"
	assert candidate(b'hello\0\0\0') == 'hello'
	assert candidate(b'hello\0world\0') == 'hello'
	assert candidate(b'abc\0\0\0') == 'abc'
	assert candidate(b"abc\0def\0\0\0\0") == "abc"
	assert candidate(b'a\0b') == 'a'
	assert candidate(b'abc\0xyz\012\0') == 'abc'
	assert candidate(b'hello world') == 'hello world'
def test_check():
	check(strip_cstring)
