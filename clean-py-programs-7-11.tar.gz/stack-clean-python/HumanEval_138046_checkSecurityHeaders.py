def checkSecurityHeaders(headers):
    """ 
     Check for Security Headers.
     
     Parameters:
     headers (dict): HTTP Headers
     
     Returns:
     headersPresent (dict): HTTP security headers present with it's values
     headersNotPresent (list): HTTP security headers not present
     """
	### Canonical solution below ###    
    headersPresent = {}
    headersNotPresent = []
    security_headers = [
                        'Referrer-Policy',
                        'X-XSS-Protection',
                        'Content-Security-Policy',
                        'X-Frame-Options',
                        'Strict-Transport-Security',
                        'X-Content-Type-Options',
                        'X-Permitted-Cross-Domain-Policies',
                        'Public-Key-Pins',
                        'Expect-CT',
                        'Feature-Policy',
                        'Report-To',
                        'NEL'
                       ]
    for security_header in security_headers:
        if security_header in headers:
            headersPresent[security_header] = headers[security_header]
        else:
            headersNotPresent.append(security_header)
    return headersPresent, headersNotPresent

### Unit tests below ###
def check(candidate):
	assert candidate(headers={"Referrer-Policy": "strict-origin-when-cross-origin"}) == ({"Referrer-Policy": "strict-origin-when-cross-origin"}, ["X-XSS-Protection", "Content-Security-Policy", "X-Frame-Options", "Strict-Transport-Security", "X-Content-Type-Options", "X-Permitted-Cross-Domain-Policies", "Public-Key-Pins", "Expect-CT", "Feature-Policy", "Report-To", "NEL"]), "Incorrect headers"
	assert candidate(headers={"X-XSS-Protection": "1; mode=block"}) == ({"X-XSS-Protection": "1; mode=block"}, ["Referrer-Policy", "Content-Security-Policy", "X-Frame-Options", "Strict-Transport-Security", "X-Content-Type-Options", "X-Permitted-Cross-Domain-Policies", "Public-Key-Pins", "Expect-CT", "Feature-Policy", "Report-To", "NEL"]), "Incorrect headers"
	assert candidate(headers={'X-XSS-Protection': '1; mode=block'}) == ({'X-XSS-Protection': '1; mode=block'}, ['Referrer-Policy', 'Content-Security-Policy', 'X-Frame-Options', 'Strict-Transport-Security', 'X-Content-Type-Options', 'X-Permitted-Cross-Domain-Policies', 'Public-Key-Pins', 'Expect-CT', 'Feature-Policy', 'Report-To', 'NEL'])
	assert candidate(headers={'Referrer-Policy': 'no-referrer', 'X-XSS-Protection': '1; mode=block'}) == ({'Referrer-Policy': 'no-referrer', 'X-XSS-Protection': '1; mode=block'}, ['Content-Security-Policy', 'X-Frame-Options', 'Strict-Transport-Security', 'X-Content-Type-Options', 'X-Permitted-Cross-Domain-Policies', 'Public-Key-Pins', 'Expect-CT', 'Feature-Policy', 'Report-To', 'NEL'])
	assert candidate(headers={'Referrer-Policy': 'no-referrer'}) == ({'Referrer-Policy': 'no-referrer'}, ['X-XSS-Protection', 'Content-Security-Policy', 'X-Frame-Options', 'Strict-Transport-Security', 'X-Content-Type-Options', 'X-Permitted-Cross-Domain-Policies', 'Public-Key-Pins', 'Expect-CT', 'Feature-Policy', 'Report-To', 'NEL'])
	assert candidate({}) == ({}, ['Referrer-Policy', 'X-XSS-Protection', 'Content-Security-Policy', 'X-Frame-Options', 'Strict-Transport-Security', 'X-Content-Type-Options', 'X-Permitted-Cross-Domain-Policies', 'Public-Key-Pins', 'Expect-CT', 'Feature-Policy', 'Report-To', 'NEL']), "No security headers present"
	assert candidate(headers={}) == ({}, ['Referrer-Policy', 'X-XSS-Protection', 'Content-Security-Policy', 'X-Frame-Options', 'Strict-Transport-Security', 'X-Content-Type-Options', 'X-Permitted-Cross-Domain-Policies', 'Public-Key-Pins', 'Expect-CT', 'Feature-Policy', 'Report-To', 'NEL'])
	assert candidate(headers={'X-XSS-Protection': '1; mode=block', 'Content-Security-Policy': "default-src'self'"}) == ({'X-XSS-Protection': '1; mode=block', 'Content-Security-Policy': "default-src'self'"}, ['Referrer-Policy', 'X-Frame-Options', 'Strict-Transport-Security', 'X-Content-Type-Options', 'X-Permitted-Cross-Domain-Policies', 'Public-Key-Pins', 'Expect-CT', 'Feature-Policy', 'Report-To', 'NEL'])
	assert candidate({'X-XSS-Protection': '1; mode=block'}) == ({'X-XSS-Protection': '1; mode=block'}, ['Referrer-Policy', 'Content-Security-Policy', 'X-Frame-Options', 'Strict-Transport-Security', 'X-Content-Type-Options', 'X-Permitted-Cross-Domain-Policies', 'Public-Key-Pins', 'Expect-CT', 'Feature-Policy', 'Report-To', 'NEL']), "X-XSS-Protection header present"
def test_check():
	check(checkSecurityHeaders)
