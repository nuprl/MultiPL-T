def getDecoToAttachSectionParserToCpoutParser(pattern, parseFunction, handleParsedDictFunct=None):
	""" Attaches a function to inpCls (which should be CpoutFileParser INSTANCE) for parsing a section of the output file
	
	Args:
		pattern: (str) The pattern to search for in a single line of a cpout file. Finding the pattern should trigger the parse function
		parseFunction: Function with interface parsedDict, lineIdx = parseFunction(fileAsList, lineIdx). lineIdx is the index in the file where the initial arg is passed (when inp-arg) and where the section is over (when it appears as outArg). ParsedDict is simply a dictionary containing key:val pairs for this section; this is used to update the main dictionary the parser outputs.
		handleParsedDictFunct: f(instance, parsedDict) Default of None means we simply update the output dict with the dict parsed from this section (usual desired behaviour). But setting this function explicitly allows for things such as parsing a series of values (e.g. temperature at each MD step) and saving ALL of them into the outptu dict (instance.outDict)
 
	Returns
		parseSectionDeco: Decorator for attaching this section parser to the overall CpoutFileParser. After calling parseSectionDeco(CpoutFileParser) any parser instances should be apply "parseFunction" upon finding "pattern" in any file its passed. Thus, this is essentially acting as a hook function for the parser behaviour.

	"""
    ### Canonical solution below ###
	def decoFunct(inpCls):
		inpCls.extraSingleLinePatterns.append(pattern)
		inpCls.extraFunctsToParseFromSingleLine.append(parseFunction)
		inpCls.extraHandleParsedOutputFuncts.append(handleParsedDictFunct)
	return decoFunct


### Unit tests below ###
def check(candidate):
	assert candidate(
	"TEST_PATTERN_2",
	lambda x,y: "test"
)!= candidate(
	"TEST_PATTERN_1",
	lambda x,y: "test"
)
	assert candidate(
	pattern="Step",
	parseFunction=lambda fileAsList, lineIdx: {"Step": fileAsList[lineIdx]}
)
	assert candidate(
	pattern="Step",
	parseFunction=lambda fileAsList, lineIdx: {"Step": fileAsList[lineIdx]},
	handleParsedDictFunct=lambda inpInstance, parsedDict: inpInstance.outDict.update(parsedDict)
)
	assert candidate(pattern="foo", parseFunction=lambda x,y:None) is not None
	assert candidate(
	"^Step\s+(\d+):\s+Time\s+=\s+(\d+\.\d+)\s+fs\s+([\w]+)",
	lambda fileAsList, lineIdx: ({"step":int(fileAsList[lineIdx][0]), "time":float(fileAsList[lineIdx][1])}, lineIdx+1)
) is not None
	assert candidate(pattern='a', parseFunction=None, handleParsedDictFunct=None)
	assert candidate(r'A', lambda x,y: (x,y))
	assert candidate(pattern="TEST", parseFunction=lambda fileAsList, lineIdx:None, handleParsedDictFunct=None)
	assert candidate(r'(.*)', lambda x,y:None) is not None
	assert candidate(r'C', lambda x,y: (x,y))
	assert candidate(r'B', lambda x,y: (x,y))
	assert candidate(
	"The electronic density",
	lambda fileAsList, lineIdx: {"electronicDensity": fileAsList[lineIdx+1]}
)
def test_check():
	check(getDecoToAttachSectionParserToCpoutParser)
