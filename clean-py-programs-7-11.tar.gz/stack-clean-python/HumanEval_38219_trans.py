def trans(M):
    """ Calcula la matriz transpuesta de M"""
	### Canonical solution below ###	

	n = len(M)
	return [[ M[i][j] for i in range(n)] for j in range(n)]

### Unit tests below ###
def check(candidate):
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]]) == [[1,4,7],[2,5,8],[3,6,9]]
	assert candidate( [[1,2,3]]) == [[1]]
	assert candidate( [[1,2],[3,4]] ) == [[1,3],[2,4]]
	assert candidate( [[1,2,3],[4,5,6],[7,8,9]]) == [[1,4,7],[2,5,8],[3,6,9]]
	assert candidate( [[1,2,3],[4,5,6],[7,8,9]] ) == [[1,4,7],[2,5,8],[3,6,9]]
	assert candidate( [ ] ) == [ ]
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]] ) == [[1,4,7],[2,5,8],[3,6,9]]
	assert candidate( [[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]] ) == [[1,5,9,13],[2,6,10,14],[3,7,11,15],[4,8,12,16]]
	assert candidate( [[1,2],[3,4]]) == [[1,3],[2,4]]
	assert candidate(
	[[1, 2, 3],
	 [4, 5, 6],
	 [7, 8, 9]]) == [[1, 4, 7],
					[2, 5, 8],
					[3, 6, 9]]
	assert candidate([[1,2,3],[4,5,6],[7,8,9]]) == [[1,4,7],[2,5,8],[3,6,9]]
	assert candidate(
	[[1, 2, 3],
	[4, 5, 6]])
	assert candidate( [[1, 2], [3, 4]] ) == [[1, 3], [2, 4]]
	assert candidate( [[1]] ) == [[1]]
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9]] ) == [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
	assert candidate( [[1,2,3]] ) == [[1]]
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]] ) == [[1,4,7], [2,5,8], [3,6,9]]
	assert candidate( [[1]]) == [[1]]
def test_check():
	check(trans)
