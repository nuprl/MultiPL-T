def taxicab_ship_distance(loc1, loc2):
    """ 
     Calculates taxicab distance between two locations on ship. Assumes cables run to centerline first.
     :param loc1: list of length 3
     :param loc2: list of length 3
     :return: distance
     """
	### Canonical solution below ###    

    # This finds the longitudinal distance in meters between the parent and child of the cable
    long_distance = loc2[0] - loc1[0]

    # This find the transverse length of cable in meters assuming the
    # cable will run from the child and parent all the way to centerline before running longitudinally
    tran_distance = abs(loc2[1]) + abs(loc1[1])

    # This finds the longitudinal distance in meters between the parent and child of the cable
    vert_distance = loc2[2] - loc1[2]

    return abs(long_distance) + abs(tran_distance) + abs(vert_distance)

### Unit tests below ###
def check(candidate):
	assert candidate(
    [100, 0, 0], [100, 0, 0]) == 0
	assert candidate([0, 0, 1], [0, 0, 0]) == 1
	assert candidate(loc1=[0, 0, 0], loc2=[5, -5, -5]) == 15
	assert candidate(
    [0, 0, 100], [0, 0, 99]) == 1
	assert candidate(
    [0, 0, 0], [1, 0, 0]) == 1, "Correct distance for points at same height"
	assert candidate(loc1=[0, 0, 0], loc2=[5, 5, 5]) == 15
	assert candidate(loc1=[0, 0, 0], loc2=[-5, -5, -5]) == 15
	assert candidate(
    [0, 0, 0],
    [0, 0, 1]
) == 1, "Distance between two locations on same axis"
	assert candidate(
    [0, 0, 0], [0, 0, 0]) == 0
	assert candidate(loc1=[1, 1, 1], loc2=[0, 1, -1]) == 5
	assert candidate( [0, 0, 0], [1, 1, 0] ) == 2
	assert candidate(
    [0, 0, 0],
    [0, 0, 0]
) == 0, "No distance between two identical locations"
	assert candidate(
    [0, 0, 0], [0, 0, 10000]) == 10000
	assert candidate(loc1=[1, 0, 0], loc2=[-1, 0, 0]) == 2
	assert candidate(loc1=[0, 0, 0], loc2=[10, 0, 10]) == 20
	assert candidate(
    [0, 0, 0],
    [100, 0, 0]) == 100
	assert candidate(loc1=[1, 1, 1], loc2=[-1, -1, -1]) == 6
	assert candidate(loc1=[0,0,0], loc2=[0,0,0]) == 0
	assert candidate(loc1=[1, 1, 1], loc2=[0, -1, -1]) == 5
	assert candidate([0, 0, 0], [0, 0, 0]) == 0
	assert candidate([1, 0, 0], [0, 0, 0]) == 1
	assert candidate(
    [0, 0, 0],
    [0, 0, 100]) == 100
	assert candidate(loc1=[0, 1, 0], loc2=[1, 0, 0]) == 2
	assert candidate(
    [0, 0, 0], [1, 1, 1]) == 3
	assert candidate(loc1=[0, 0, 0], loc2=[5, 5, -5]) == 15
	assert candidate(
    [0, 0, 0], [1, 0, 0]) == 1
	assert candidate(loc1=[0, 0, 0], loc2=[0, 0, 0]) == 0
	assert candidate(loc1=[0,0,0], loc2=[0,0,10]) == 10
	assert candidate(
    [0, 0, 0], [-1, 1, 1]) == 3
	assert candidate(loc1=[1, 1, 1], loc2=[2, 2, 2]) == 5
	assert candidate(loc1 = [0, 0, 0], loc2 = [1, 1, 1]) == 3
	assert candidate(
    [0, 0, 0], [1, 1, 0]) == 2
	assert candidate(
    [0, 0, 0], [1, 1, 0]) == 2, "Correct distance for points at same height"
	assert candidate(
    [0, 0, 100], [0, 0, 100]) == 0
	assert candidate(
    [0, 2, 0],
    [4, 5, 0]) == 11
	assert candidate(loc1=[0, 0, 0], loc2=[0, 0, 10]) == 10
	assert candidate(loc1=[0, -1, -1], loc2=[1, 1, 1]) == 5
	assert candidate([0, 1, 0], [0, 0, 0]) == 1
	assert candidate(loc1=[1, 1, 1], loc2=[0, 0, 0]) == 3
	assert candidate( [0, 0, 0], [0, 0, 0] ) == 0
	assert candidate(
    [0, 0, 0],
    [0, 1, 0]
) == 1, "Distance between two locations on same axis"
	assert candidate(loc1=[0, 0, 0], loc2=[1, 1, 1]) == 3
	assert candidate(
    [0, 0, 0], [1, 1, 1]) == 3, "Correct distance for points at same height"
	assert candidate(loc1=[0, 0, 0], loc2=[0, 10, 0]) == 10
	assert candidate(loc1=[0,0,0], loc2=[0,0,-10]) == 10
	assert candidate(loc1=[0,0,0], loc2=[0,10,0])
	assert candidate([0, -1, 0], [0, 0, 0]) == 1
	assert candidate(loc1=[-1, -1, -1], loc2=[1, 1, 1]) == 6
	assert candidate( [0, 0, 0], [1, 0, 0] ) == 1
	assert candidate(
    [0, 0, 0],
    [0, 100, 0]) == 100
	assert candidate(loc1=[0, 0, 0], loc2=[-5, 5, 5]) == 15
	assert candidate(
    [0, 0, 100], [0, 0, 101]) == 1
	assert candidate(loc1=[0,0,0], loc2=[0,1,0]) == 1
	assert candidate(
    [0, 0, 0],
    [0, 0, 0]) == 0
	assert candidate(loc1=[0,0,0], loc2=[1,0,0]) == 1
	assert candidate(loc1=[0,0,0], loc2=[0,0,1]) == 1
	assert candidate(
    [0, 0, 0],
    [4, 5, 0]) == 9
	assert candidate(
    [0, 0, 0],
    [1, 0, 0]
) == 1, "Distance between two locations on same axis"
	assert candidate(
    [100, 0, 0], [100, 0, -1]) == 1
	assert candidate( [0, 0, 0], [1, 1, 1] ) == 3
	assert candidate(loc1 = [0, 0, 0], loc2 = [1, 0, 0]) == 1
	assert candidate(loc1=[1, 1, 1], loc2=[1, 1, 0]) == 3
	assert candidate(
    [100, 0, 0], [100, 0, 1]) == 1
	assert candidate([0, 0, -1], [0, 0, 0]) == 1
	assert candidate(loc1=[1, 0, 0], loc2=[0, 1, 0]) == 2
	assert candidate(
    [0, 0, 0], [0, 0, 0]) == 0, "Zero distance between zero points"
	assert candidate(loc1=[0, 0, 0], loc2=[10, 0, 0]) == 10
	assert candidate(
    [0, 0, 0], [1, 2, 0]) == 3, "Correct distance for points at same height"
	assert candidate(loc1=[-1, 0, 0], loc2=[1, 0, 0]) == 2
	assert candidate([-1, 0, 0], [0, 0, 0]) == 1
def test_check():
	check(taxicab_ship_distance)
