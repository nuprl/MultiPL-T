def keyValueList(d, key=None): 
    """ 
     This function iterates over all the key-value pairs of a dictionary and returns a list of tuple (key, value) where the key contain only primitive value (i.e., no list or dict), e.g., string, number etc.
     d -- a dictionary to iterate through
     """
	### Canonical solution below ###    
    if not isinstance(d, dict) and not isinstance(d, list):
        return []
    
    keyvalues = []
    
    if isinstance(d, list):
        for entry in d:
            if isinstance(entry, dict):
                keyvalues.extend(keyValueList(entry))
            else:
                keyvalues.append((key, entry))
    else:
        for k, v in d.items():
            if k is None or v is None:
                continue
            if not isinstance(v, dict) and type(v) != list:
                keyvalues.append((k,v))
            elif isinstance(v, list):
                keyvalues.extend(keyValueList(v, k))
            else:
                keyvalues.extend(keyValueList(v))
                
    return keyvalues

### Unit tests below ###
def check(candidate):
	assert candidate({"a":1, "b":2, "c":3}) == [("a",1), ("b",2), ("c",3)]
	assert candidate([{'a':1, 'b':2}, {'c':3, 'd':4}]) == [('a',1), ('b',2), ('c',3), ('d',4)]
	assert candidate({"a":1, "b":2}) == [("a", 1), ("b", 2)]
	assert candidate([dict(a=1,b=2),dict(c=3,d=4)]) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate(5) == []
	assert candidate(None) == []
	assert candidate([{'a':1, 'b':2}, {'a':3, 'b':4}]) == [('a', 1), ('b', 2), ('a', 3), ('b', 4)]
	assert candidate({"a":1}) == [("a",1)]
	assert candidate({'a': 1, 'b': {'c': 3, 'd': 4}}) == [('a', 1), ('c', 3), ('d', 4)]
	assert candidate(dict(a=1,b=2,c=3)) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate({1: [1, 2, 3], 2: [2, 3, 4], 3: [3, 4, 5]}) == [(1, 1), (1, 2), (1, 3), (2, 2), (2, 3), (2, 4), (3, 3), (3, 4), (3, 5)]
	assert candidate("a") == []
	assert candidate([1,2,3],'key') == [('key',1),('key',2),('key',3)]
	assert candidate([{'a':1, 'b':2}, {'a':3, 'b':[4, 5]}]) == [('a', 1), ('b', 2), ('a', 3), ('b', 4), ('b', 5)]
	assert candidate(True) == []
	assert candidate([1, 2, 3]) == [(None, 1), (None, 2), (None, 3)]
	assert candidate({'a':1, 'b':2}) == [('a', 1), ('b', 2)]
	assert candidate([{"a":"b"}]) == [("a", "b")]
	assert candidate({"a":{"b":{"c":{"d":1}}}}) == [("d",1)]
	assert candidate({"a":[1,2,3], "b":[4,5,6]}) == [("a",1), ("a",2), ("a",3), ("b",4), ("b",5), ("b",6)]
	assert candidate({'a':1}) == [('a', 1)]
	assert candidate([]) == []
	assert candidate(False) == []
	assert candidate(list()) == []
	assert candidate({"a": 1, "b": 2}) == [("a", 1), ("b", 2)]
	assert candidate("hello") == []
	assert candidate({"a":1, "b":2, "c":{"d":3}}) == [("a",1), ("b",2), ("d",3)]
	assert candidate({"a": 1, "b": 2}) == [('a', 1), ('b', 2)]
	assert candidate([1,2,{"a": 3}]) == [(None, 1), (None, 2), ('a', 3)]
	assert candidate([1,2,3]) == [(None,1),(None,2),(None,3)]
	assert candidate([1,2,3]) == [(None, 1), (None, 2), (None, 3)]
	assert candidate("string") == []
	assert candidate({"a": 1, "b": {"c": 3}}) == [('a', 1), ('c', 3)]
	assert candidate(dict(a=1, b=2)) == [('a', 1), ('b', 2)]
	assert candidate({'a':1, 'b':2}) == [('a',1), ('b',2)]
	assert candidate({"a":1, "b":2}) == [("a",1), ("b",2)]
	assert candidate('hello') == []
	assert candidate(d=[{'a': 1}, {'b': 2}]) == [('a', 1), ('b', 2)]
	assert candidate({"a":"b"}) == [("a", "b")]
	assert candidate({'a':1, 'b':[2,3]}) == [('a',1), ('b',2), ('b',3)]
	assert candidate(1) == []
	assert candidate({"a": 1}) == [('a', 1)]
	assert candidate({"a": 1}) == [("a", 1)]
	assert candidate([dict(a=1, b=2), dict(c=3, d=4)]) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate(dict(a=1)) == [('a', 1)]
	assert candidate({'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
	assert candidate({'a': 1}) == [('a', 1)]
	assert candidate({'a': 1, 'b': {'c': 3, 'd': {'e': 5, 'f': 6}}}) == [('a', 1), ('c', 3), ('e', 5), ('f', 6)]
	assert candidate(1.0) == []
	assert candidate([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate({"a":1, "b":2, "c":{"d":3}, "e":{"f":4}}) == [("a",1), ("b",2), ("d",3), ("f",4)]
	assert candidate("test") == []
	assert candidate(d=[{'a': [1, 2, 3]}, {'b': [4, 5, 6]}]) == [('a', 1), ('a', 2), ('a', 3), ('b', 4), ('b', 5), ('b', 6)]
	assert candidate({1: 1, 2: 2, 3: 3}) == [(1, 1), (2, 2), (3, 3)]
	assert candidate({}) == []
	assert candidate({'a':1, 'b':2, 'c':3}) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate({'a':1}) == [('a',1)]
	assert candidate({'k1':1,'k2':2}) == [('k1',1),('k2',2)]
	assert candidate('abc') == []
	assert candidate(dict()) == []
	assert candidate({'a':1, 'b':2, 'c':{'d':3, 'e':4}}) == [('a', 1), ('b', 2), ('d', 3), ('e', 4)]
	assert candidate(d={'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
	assert candidate("") == []
def test_check():
	check(keyValueList)
