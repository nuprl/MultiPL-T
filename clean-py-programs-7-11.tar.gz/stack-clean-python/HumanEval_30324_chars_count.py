def chars_count(word: str):
    """
    :param word: string to count the occurrences of a character symbol for.
    :return: a dictionary mapping each character found in word to the number of times it appears in it.
    """
    ### Canonical solution below ###
    res = dict()

    for c in word:
        res[c] = res.get(c, 0) + 1

    return res


### Unit tests below ###
def check(candidate):
	assert candidate(word="aa") == {'a': 2}
	assert candidate(word="abracadabra") == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
	assert candidate(word="aaaaa") == {'a': 5}
	assert candidate(word='abc') == {'a': 1, 'b': 1, 'c': 1}
	assert candidate(word='banana') == {'b': 1, 'a': 3, 'n': 2}
	assert candidate(word="aaab") == {'a': 3, 'b': 1}
	assert candidate(word='123') == {'1': 1, '2': 1, '3': 1}
	assert candidate(word="code") == {'c': 1, 'o': 1, 'd': 1, 'e': 1}
	assert candidate('') == {}
	assert candidate(word="abracadabra") == {"a": 5, "b": 2, "r": 2, "c": 1, "d": 1}
	assert candidate(word="12345") == {'1': 1, '2': 1, '3': 1, '4': 1, '5': 1}
	assert candidate(word="a") == {'a': 1}
	assert candidate("") == {}
	assert candidate('a') == {'a': 1}
	assert candidate(word="aaabb") == {'a': 3, 'b': 2}
	assert candidate(word="aaaabbb") == {'a': 4, 'b': 3}
	assert candidate(
    "a") == {'a': 1}
	assert candidate(word="") == {}
	assert candidate(
    "code") == {'c': 1, 'o': 1, 'd': 1, 'e': 1}
	assert candidate(word="aaabbb") == {'a': 3, 'b': 3}
	assert candidate(word="aaabbc") == {'a': 3, 'b': 2, 'c': 1}
	assert candidate(word="aaa") == {'a': 3}
	assert candidate(word="banana") == {"b": 1, "a": 3, "n": 2}
	assert candidate(word='a') == {'a': 1}
	assert candidate(word="aaba") == {'a': 3, 'b': 1}
	assert candidate(word="hi") == {'h': 1, 'i': 1}
	assert candidate(word="banana") == {'b': 1, 'a': 3, 'n': 2}
	assert candidate(word="abcde") == {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'e': 1}
	assert candidate(word="1234567890") == {'1': 1, '2': 1, '3': 1, '4': 1, '5': 1, '6': 1, '7': 1, '8': 1, '9': 1, '0': 1}
	assert candidate(word='abracadabra') == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
	assert candidate(
    "abracadabra") == {"a": 5, "b": 2, "r": 2, "c": 1, "d": 1}
	assert candidate(word="aabb") == {"a": 2, "b": 2}
	assert candidate(word="123") == {'1': 1, '2': 1, '3': 1}
	assert candidate(word="CodeWars") == {"C": 1, "o": 1, "d": 1, "e": 1, "W": 1, "a": 1, "r": 1, "s": 1}
	assert candidate(word='banana') == {'a': 3, 'b': 1, 'n': 2}
	assert candidate(word="ab") == {"a": 1, "b": 1}
	assert candidate(word='') == {}
	assert candidate(word='aaaaa') == {'a': 5}
	assert candidate('aaaaa') == {'a': 5}
	assert candidate(word='12213') == {'1': 2, '2': 2, '3': 1}
	assert candidate(word="abracadabra") == {'a': 5, 'b': 2, 'c': 1, 'd': 1, 'r': 2}
	assert candidate(word="Hello") == {'H': 1, 'e': 1, 'l': 2, 'o': 1}
	assert candidate(
    "a" * 1000000) == {'a': 1000000}
	assert candidate(
    'abracadabra') == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
	assert candidate(word="aaaabb") == {'a': 4, 'b': 2}
	assert candidate(word="abc") == {'a': 1, 'b': 1, 'c': 1}
	assert candidate(word="b") == {'b': 1}
	assert candidate(word='aaa') == {'a': 3}
	assert candidate(word="ab") == {'a': 1, 'b': 1}
	assert candidate(
    "abracadabra") == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
	assert candidate(word="hello") == {'h': 1, 'e': 1, 'l': 2, 'o': 1}
	assert candidate("abcb") == {"a": 1, "b": 2, "c": 1}
	assert candidate(word="a") == {"a": 1}
def test_check():
	check(chars_count)
