def get_browsing_options():#MUST be defined
    """ 
     Returns a list of dicts. Each dict represents a different method of browsing
     this index. The following keys MUST be provided:
     'name': Label to display to the user to represent this browsing method
     'function': A function (defined in this index) which will be executed when
     the user selects this browsing method. This function should describe
     and add the list items to the directory, and assume flow control from
     this point on.
     Once the user indicates the content they would like to search the providers
     for (usually via selecting a list item), plugin.video.waldo should be called
     with the following parameters (again usually via listitem):
     mode = 'GetAllResults'
     type = either 'movie', 'tvshow', 'season', or 'episode'
     title = The title string to look for
     year = The release year of the desired movie, or premiere date of the
     desired tv show.
     imdb = The imdb id of the movie or tvshow to find sources for
     tvdb = The tvdb id of the movie or tvshow to find sources for
     season = The season number for which to return results.
     If season is supplied, but not episode, all results for that season
     should be returned
     episode: The episode number for which to return results
     """
	### Canonical solution below ###    
    option_1 = {'name': 'Tv Shows', 'function': 'BrowseListMenu', 'kwargs': {'section': 'tv'}}

    option_2 = {'name': 'Movies', 'function': 'BrowseListMenu', 'kwargs': {'section': 'movies'}}

    return [option_1, option_2]

### Unit tests below ###
def check(candidate):
	assert len(candidate( )) > 0
	assert all(['name' in option for option in candidate( )])
	assert candidate()
	assert candidate(
) == [{'name': 'Tv Shows', 'function': 'BrowseListMenu', 'kwargs': {'section': 'tv'}}, {'name': 'Movies', 'function': 'BrowseListMenu', 'kwargs': {'section':'movies'}}], 'candidate() does not return a list of dicts'
	assert candidate()[0]['name'] == 'Tv Shows', 'candidate() does not return a list of dicts, or one of the dicts does not have the key "name"'
	assert candidate(
) == [
    {
        'name': 'Tv Shows',
        'function': 'BrowseListMenu',
        'kwargs': {'section': 'tv'}
    },
    {
        'name': 'Movies',
        'function': 'BrowseListMenu',
        'kwargs': {'section':'movies'}
    }
]
	assert type(candidate( )) == list
	assert candidate()[0]['function'] == 'BrowseListMenu', 'candidate() does not return a list of dicts, or one of the dicts does not have the key "function"'
	assert all([type(option) == dict for option in candidate( )])
	assert candidate()[0]['name'] == 'Tv Shows'
	assert candidate( )
	assert candidate()[0]['kwargs']['section'] == 'tv', 'candidate() does not return a list of dicts, or one of the dicts does not have the key "kwargs" with the key "section"'
	assert all(['function' in option for option in candidate( )])
	assert all(['kwargs' in option for option in candidate( )])
	assert candidate()[1]['name'] == 'Movies'
def test_check():
	check(get_browsing_options)
