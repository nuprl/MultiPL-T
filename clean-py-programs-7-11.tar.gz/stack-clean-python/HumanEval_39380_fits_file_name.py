def fits_file_name(rerun, run, camcol, field, band):
    """ 
     SDSS FITS files are named, e.g., 'frame-g-001000-1-0027.fits.bz2'.
     We will uncompress this and save it as 'frame-g-001000-1-0027.fits'.
     
     This function returns 'frame-g-001000-1-0027.fits' in this case
     (without the '.bz2' extension).
     """
	### Canonical solution below ###    

    return "frame-{4}-{1:06d}-{2}-{3:04d}.fits".format(
        rerun, run, camcol, field, band
    )

### Unit tests below ###
def check(candidate):
	assert candidate(rerun="g", run=1000, camcol=1, field=27, band="g") == "frame-g-001000-1-0027.fits"
	assert candidate(rerun='g', run=1000, camcol=1, field=27, band='g') == 'frame-g-001000-1-0027.fits'
	assert candidate(rerun=0, run=1000, camcol=1, field=27, band='g') == "frame-g-001000-1-0027.fits"
	assert candidate(rerun='123', run=1000, camcol=1, field=27, band='r') == 'frame-r-001000-1-0027.fits'
	assert candidate(1, 1000, 1, 27, "z") == "frame-z-001000-1-0027.fits"
	assert candidate(rerun='r12', run=1000, camcol=1, field=27, band='i') == 'frame-i-001000-1-0027.fits'
	assert candidate(rerun="123", run=1, camcol=2, field=3, band="z") == "frame-z-000001-2-0003.fits"
	assert candidate(rerun="123", run=1, camcol=2, field=3, band="r") == "frame-r-000001-2-0003.fits"
	assert candidate(1, 2, 3, 4, 'u') == "frame-u-000002-3-0004.fits"
	assert candidate(1, 2, 3, 4, 'r') == "frame-r-000002-3-0004.fits"
	assert candidate(rerun='123', run=1000, camcol=1, field=27, band='y') == 'frame-y-001000-1-0027.fits'
	assert candidate(
    rerun="g", run=1000, camcol=1, field=27, band="g"
) == "frame-g-001000-1-0027.fits"
	assert candidate(1, 2, 3, 4, 'i') == "frame-i-000002-3-0004.fits"
	assert candidate(rerun="123", run=1, camcol=2, field=3, band="u") == "frame-u-000001-2-0003.fits"
	assert candidate(rerun="g", run=1000, camcol=1, field=27, band="g") == \
    "frame-g-001000-1-0027.fits"
	assert candidate(1, 2, 3, 4, "r") == "frame-r-000002-3-0004.fits"
	assert candidate(rerun="z", run=1000, camcol=1, field=27, band="z") == "frame-z-001000-1-0027.fits"
	assert candidate(rerun='123', run=1000, camcol=1, field=27, band='i') == 'frame-i-001000-1-0027.fits'
	assert candidate(1, 2, 3, 4, "z") == "frame-z-000002-3-0004.fits"
	assert candidate(1, 2, 3, 4, 'z') == "frame-z-000002-3-0004.fits"
	assert candidate(rerun='r12', run=1000, camcol=1, field=27, band='g') == 'frame-g-001000-1-0027.fits'
	assert candidate(rerun="123", run=1, camcol=2, field=3, band="Y") == "frame-Y-000001-2-0003.fits"
	assert candidate(rerun='123', run=1000, camcol=1, field=27, band='z') == 'frame-z-001000-1-0027.fits'
	assert candidate(1, 2, 3, 4, "u") == "frame-u-000002-3-0004.fits"
	assert candidate(
    rerun="r12", run=1000, camcol=1, field=27, band="g"
) == "frame-g-001000-1-0027.fits"
	assert candidate(rerun='123', run=1000, camcol=1, field=27, band='g') == 'frame-g-001000-1-0027.fits'
	assert candidate(
    'r21', 1000, 1, 27, 'g'
) == 'frame-g-001000-1-0027.fits'
	assert candidate(1, 1000, 1, 27, "y") == "frame-y-001000-1-0027.fits"
	assert candidate(rerun="y", run=1000, camcol=1, field=27, band="y") == "frame-y-001000-1-0027.fits"
	assert candidate(1, 2, 3, 4, 'g') == "frame-g-000002-3-0004.fits"
	assert candidate(rerun="123", run=1, camcol=2, field=3, band="i") == "frame-i-000001-2-0003.fits"
	assert candidate(rerun="r", run=1000, camcol=1, field=27, band="r") == "frame-r-001000-1-0027.fits"
	assert candidate(rerun='163', run=1000, camcol=1, field=27, band='g') == 'frame-g-001000-1-0027.fits'
	assert candidate(1, 2, 3, 4, 'Y') == "frame-Y-000002-3-0004.fits"
	assert candidate(rerun='r12', run=1000, camcol=1, field=27, band='r') == 'frame-r-001000-1-0027.fits'
	assert candidate(rerun='g', run=1000, camcol=1, field=27, band='g') == \
    "frame-g-001000-1-0027.fits"
	assert candidate(1, 1000, 1, 27, "g") == "frame-g-001000-1-0027.fits"
	assert candidate(1, 1000, 1, 27, "r") == "frame-r-001000-1-0027.fits"
	assert candidate(1, 2, 3, 4, "g") == "frame-g-000002-3-0004.fits"
	assert candidate(1, 2, 3, 4, "i") == "frame-i-000002-3-0004.fits"
	assert candidate(rerun="i", run=1000, camcol=1, field=27, band="i") == "frame-i-001000-1-0027.fits"
	assert candidate(1, 1000, 1, 27, "i") == "frame-i-001000-1-0027.fits"
	assert candidate(rerun="123", run=1, camcol=2, field=3, band="g") == "frame-g-000001-2-0003.fits"
	assert candidate(rerun=1, run=1000, camcol=1, field=27, band='g') == 'frame-g-001000-1-0027.fits'
def test_check():
	check(fits_file_name)
