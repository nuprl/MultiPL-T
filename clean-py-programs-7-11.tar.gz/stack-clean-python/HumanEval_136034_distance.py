def distance(strand_a, strand_b):
    """Calculates the Hamming distance between two strands.

    Args:
        strand_a: A string representing a DNA strand.
        strand_b: A string representing a DNA strand.

    Returns:
        An integer representing the Hamming Distance between the two strands.
    """
    ### Canonical solution below ###
    if len(strand_a) != len(strand_b):
        raise ValueError("left and right strands must be of equal length")

    hamming_distance = 0
    for idx, elem in enumerate(strand_a):
        if elem != strand_b[idx]:
            hamming_distance += 1

    return hamming_distance


### Unit tests below ###
def check(candidate):
	assert candidate(strand_a="GAGCCTACTAACGGGAT", strand_b="CATCGTAATGACGGCCT") == 7
	assert candidate(strand_a='GGACTGA', strand_b='GGACTGB') == 1
	assert candidate(strand_a="GGACGGATTCTG", strand_b="AGGACGGATTCT") == 9
	assert candidate(strand_a='', strand_b='') == 0
	assert candidate(strand_a="GGACTGA", strand_b="GGACGGA") == 1
	assert candidate(strand_a='A', strand_b='A') == 0
	assert candidate(strand_a="G", strand_b="A") == 1
	assert candidate(strand_a="123", strand_b="122") == 1
	assert candidate(strand_a="A", strand_b="A") == 0
	assert candidate(strand_a='GGACTGA', strand_b='GGACGGA') == 1
	assert candidate(strand_a="GGACTGA", strand_b="GGACTGA") == 0
	assert candidate(strand_a='GGACTGA', strand_b='GGACGTA') == 2
	assert candidate(strand_a="GGACTGA", strand_b="GGACTGC") == 1
	assert candidate(strand_a="A", strand_b="G") == 1
	assert candidate(strand_a='GGACTGA', strand_b='GGACTGA') == 0
	assert candidate(strand_a="GGACTGA", strand_b="GGACGAA") == 2
	assert candidate(strand_a="123", strand_b="123") == 0
	assert candidate(strand_a="", strand_b="") == 0
	assert candidate(strand_a='GAGCCTACTAACGGGAT', strand_b='CATCGTAATGACGGCCT') == 7, "candidate failed"
	assert candidate(strand_a="GGACTGA", strand_b="GGACGTT") == 3
	assert candidate(strand_a='GAGCCTACTAACGGGAT', strand_b='CATCGTAATGACGGCCT') == 7, "candidate function is broken"
	assert candidate(strand_a="1", strand_b="1") == 0
	assert candidate(strand_a="1", strand_b="2") == 1
	assert candidate(strand_a="GGACTGA", strand_b="GGACTGB") == 1
	assert candidate(strand_a="12345", strand_b="54321") == 4
	assert candidate(strand_a="1234", strand_b="1234") == 0
	assert candidate(strand_a='A', strand_b='T') == 1
	assert candidate(strand_a="GAGCCTACTAACGGGAT", strand_b="GAGCCTACTAACGGGAT") == 0
	assert candidate(strand_a="1234", strand_b="1235") == 1
	assert candidate(strand_a="A", strand_b="T") == 1
	assert candidate(strand_a="GGACTGA", strand_b="GGACGAC") == 3
	assert candidate(strand_a='A', strand_b='A') == 0, "candidate function is broken"
	assert candidate(strand_a='AG', strand_b='CT') == 2
	assert candidate(strand_a="G", strand_b="T") == 1
	assert candidate(strand_a='GGACGGATTCTG', strand_b='GGTCGGATTCTG') == 1
	assert candidate(strand_a="1234", strand_b="1244") == 1
	assert candidate(strand_a='GAGCCTACTAACGGGAT', strand_b='CATCGTAATGACGGCCT') == candidate(strand_a='CATCGTAATGACGGCCT', strand_b='GAGCCTACTAACGGGAT'), "candidate failed"
	assert candidate(strand_a='GAGCCTACTAACGGGAT', strand_b='CATCGTAATGACGGCCT') == 7
	assert candidate(strand_a="123", strand_b="124") == 1
def test_check():
	check(distance)
