def set_safe_attr(instance, attr, val):
    """ Sets the attribute in a thread safe manner.
     
     Returns if new val was set on attribute.
     If attr already had the value then False.
     """
	### Canonical solution below ###    

    if not instance or not attr:
        return False
    old_val = getattr(instance, attr, None)
    if val is None and old_val is None:
        return False
    elif val == old_val:
        return False
    else:
        setattr(instance, attr, val)
        return True

### Unit tests below ###
def check(candidate):
	assert candidate(None, None, 'foo') is False
	assert candidate(object(), "foo", None) == False
	assert candidate(object(), 'attr', None) == False
	assert candidate(None, 'a', 'b') == False
	assert candidate(object(), None, None) == False
	assert candidate(None, 'foo', 'bar') is False
	assert candidate(None, 'a', None) == False
	assert candidate(None, 'test', 'val') == False
	assert candidate(object(), None, 'val') == False
	assert candidate(None, None, None) == False
	assert candidate(object(), None, 'bar') is False
	assert candidate(object(), 'a', None) == False
	assert candidate(None, 'foo', 'bar') == False
	assert candidate(object(), 'foo', None) == False
	assert candidate(None, "a", "b") == False
	assert candidate(None, 'foo', None) is False
	assert candidate(None, 1, 1) == False
	assert candidate(None, "a", None) == False
	assert candidate(object(), 'foo', None) is False
	assert candidate(None, "foo", "bar") is False
	assert candidate(None, 'attr', 'val') == False
	assert candidate(None, None, 1) == False
	assert candidate(None, 1, None) == False
	assert candidate(None, 'test', 'test') is False
	assert candidate(object(), None, None) is False
	assert candidate(object(), 'attr', None) is False
	assert candidate('test', None, 'test') is False
	assert candidate(None, 'test', 'test') == False
	assert candidate(object(), 'x', None) == False
	assert candidate(None, "a", 1) == False
	assert candidate(None, 'a', 1) == False
	assert candidate('test', None, None) is False
	assert candidate(None, None, 'test') is False
	assert candidate(None, 'attr', None) == False
	assert candidate(object(), None, 'bar') == False
	assert candidate(None, None, None) is False
	assert candidate(object(), None, 1) == False
	assert candidate(None, 'test', None) == False
	assert candidate(dict(), "foo", None) is False
	assert candidate(None, 'attr', 1) == False
	assert candidate(dict(), "foo", "bar") is False
	assert candidate(None, "foo", 1) == False
	assert candidate('test', 'test', None) is False
	assert candidate(None, 'test', None) is False
def test_check():
	check(set_safe_attr)
