def praw_object_type(praw_obj):
    """ Return the type of the praw object (comment/submission) as a
     lowercase string."""
	### Canonical solution below ###    
    return type(praw_obj).__name__.lower()

### Unit tests below ###
def check(candidate):
	assert candidate(tuple()) == "tuple"
	assert candidate([1,2,3]) == 'list'
	assert candidate(list()) == 'list'
	assert candidate(object()) == "object"
	assert candidate(candidate) == "function"
	assert candidate(1.0) == 'float'
	assert candidate(1.1) == 'float'
	assert candidate(list()) == "list"
	assert candidate(tuple()) == 'tuple'
	assert candidate(1.0) == "float"
	assert candidate(dict()) == 'dict'
	assert candidate('abc') =='str'
	assert candidate(1) == "int"
	assert candidate(True) == 'bool'
	assert candidate(123) == 'int'
	assert candidate(set()) =='set'
	assert candidate(set()) == "set"
	assert candidate('hi') =='str'
	assert candidate(dict()) == "dict"
	assert candidate('string') =='str'
	assert candidate(Exception()) == 'exception'
	assert candidate({'a': 1}) == 'dict'
	assert candidate("hello") == "str"
	assert candidate(1) == 'int'
def test_check():
	check(praw_object_type)
