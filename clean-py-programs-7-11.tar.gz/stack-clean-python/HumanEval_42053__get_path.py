def _get_path(location):
    """If a string starts with "<protocol>://"", return the rest of the string.
    Otherwise, return the entire string.
    """
    ### Canonical solution below ###
    separator = "://"
    if separator in location:
        return location[location.index(separator) + len(separator) :]
    else:
        return location


### Unit tests below ###
def check(candidate):
	assert candidate("s3://bucket/tmp/file.txt?param=value")
	assert candidate("gs://foo/bar") == "foo/bar"
	assert candidate(
    "/home/user/sample_service/SampleService.spec") == "/home/user/sample_service/SampleService.spec"
	assert candidate("s3://my-bucket") == "my-bucket"
	assert candidate("some/path") == "some/path"
	assert candidate(
    "https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png"
) == "www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png"
	assert candidate(
    "home/user/file.txt"
) == "home/user/file.txt"
	assert candidate("s3://bucket") == "bucket"
	assert candidate("some/path#fragment") == "some/path#fragment"
	assert candidate("s3a://bucket/key") == "bucket/key"
	assert candidate("s3://tmp/file") == "tmp/file"
	assert candidate(r"file://C:\Users\username\Documents") == r"C:\Users\username\Documents"
	assert candidate("abc://def") == "def"
	assert candidate("some-bucket") == "some-bucket"
	assert candidate("s3://bucket/tmp/file.txt") == "bucket/tmp/file.txt"
	assert candidate("path/to/file.ext") == "path/to/file.ext"
	assert candidate(
    "ssh://git@github.com:some/path/to/repo.git"
) == "git@github.com:some/path/to/repo.git"
	assert candidate("s3://path") == "path"
	assert candidate("my-bucket/my-folder/my-file.csv") == "my-bucket/my-folder/my-file.csv"
	assert candidate("file://C:\\Users\\username\\Documents") == r"C:\Users\username\Documents"
	assert candidate("some-bucket/some/path/to/object.ext") == "some-bucket/some/path/to/object.ext"
	assert candidate(
    "s3://bucket/path/to/file"
) == "bucket/path/to/file"
	assert candidate(
    "gs://some-bucket/some/path/to/object.ext"
) == "some-bucket/some/path/to/object.ext"
	assert candidate("file://bucket/key") == "bucket/key"
	assert candidate("abc") == "abc"
	assert candidate("s3://") == ""
	assert candidate("some/path?query#fragment") == "some/path?query#fragment"
	assert candidate("file://some/path?query#fragment") == "some/path?query#fragment"
	assert candidate("C:/Users/foo/Documents/GitHub/jupyter-forward/jupyter_forward/tests/test_jupyter_forward.py") == "C:/Users/foo/Documents/GitHub/jupyter-forward/jupyter_forward/tests/test_jupyter_forward.py"
	assert candidate("file://") == ""
	assert candidate("gs://some-bucket") == "some-bucket"
	assert candidate(
    "https://www.github.com/some/path/to/repo.git"
) == "www.github.com/some/path/to/repo.git"
	assert candidate(
    "file:///path/to/file.txt"
) == "/path/to/file.txt", "Test failed for file path"
	assert candidate("my_object") == "my_object"
	assert candidate("file:///path/to/file") == "/path/to/file"
	assert candidate("s3://bucket/") == "bucket/"
	assert candidate(
    "bucket/path/to/file"
) == "bucket/path/to/file"
	assert candidate("local://tmp/file") == "tmp/file"
	assert candidate("http://somewhere/else") == "somewhere/else"
	assert candidate("s3://tmp") == "tmp"
	assert candidate("file://some/path#fragment") == "some/path#fragment"
	assert candidate(
    "https://github.com/kbase/sample_service/raw/master/SampleService.spec") == "github.com/kbase/sample_service/raw/master/SampleService.spec"
	assert candidate("my_bucket/my_object") == "my_bucket/my_object"
	assert candidate(
    "hdfs://path/to/file.txt"
) == "path/to/file.txt", "Test failed for hdfs path"
	assert candidate("foo/bar") == "foo/bar"
	assert candidate("file://some/path?query") == "some/path?query"
	assert candidate(r"\\Server\Share\Folder\File.ext") == r"\\Server\Share\Folder\File.ext"
	assert candidate("file://some/path") == "some/path"
	assert candidate("www.python.org/static/img/python-logo.png") == "www.python.org/static/img/python-logo.png"
	assert candidate("C:\\Users\\foo\\Documents\\GitHub\\jupyter-forward\\jupyter_forward\\tests\\test_jupyter_forward.py") == "C:\\Users\\foo\\Documents\\GitHub\\jupyter-forward\\jupyter_forward\\tests\\test_jupyter_forward.py"
	assert candidate("local:///tmp") == "/tmp"
	assert candidate("file.txt") == "file.txt"
	assert candidate(
    "s3://my-bucket/my-folder/my-file.csv"
) == "my-bucket/my-folder/my-file.csv"
	assert candidate("file://foo/bar") == "foo/bar"
	assert candidate("path/to/file") == "path/to/file"
	assert candidate("s3://bucket/key/key/") == "bucket/key/key/"
	assert candidate("file:///tmp/foo") == "/tmp/foo"
	assert candidate(
    "s3n://bucket/prefix/file.txt"
) == "bucket/prefix/file.txt", "Test failed for s3n path"
	assert candidate("s3://some-bucket/some/path/to/object.ext") == "some-bucket/some/path/to/object.ext"
	assert candidate("/home/foo/Documents/GitHub/jupyter-forward/jupyter_forward/tests/test_jupyter_forward.py") == "/home/foo/Documents/GitHub/jupyter-forward/jupyter_forward/tests/test_jupyter_forward.py"
	assert candidate("base/_typography.scss") == "base/_typography.scss"
	assert candidate("bucket/key") == "bucket/key"
	assert candidate(r"C:\Users\User\Desktop") == r"C:\Users\User\Desktop"
	assert candidate(
    "file:///home/user/file.txt"
) == "/home/user/file.txt"
	assert candidate("somewhere/else") == "somewhere/else"
	assert candidate("s3n://bucket/key") == "bucket/key"
	assert candidate("file://path") == "path"
	assert candidate("local://") == ""
	assert candidate("local://tmp/file.txt") == "tmp/file.txt"
	assert candidate(
    "/path/to/file.txt"
) == "/path/to/file.txt", "Test failed for file path"
	assert candidate("file:///tmp/foo/bar") == "/tmp/foo/bar"
	assert candidate(
    "s3://bucket/prefix/file.txt"
) == "bucket/prefix/file.txt", "Test failed for s3 path"
	assert candidate(
    "https://raw.githubusercontent.com/gvwilson/mccole/main/mccole/bib.py"
) == "raw.githubusercontent.com/gvwilson/mccole/main/mccole/bib.py"
	assert candidate("local://tmp") == "tmp"
	assert candidate("s3://bucket/key/subkey") == "bucket/key/subkey"
	assert candidate(
    "/home/user/file.txt"
) == "/home/user/file.txt"
	assert candidate("") == ""
	assert candidate("s3://tmp/file.txt") == "tmp/file.txt"
	assert candidate("abc://def/") == "def/"
	assert candidate("s3://bucket/key/key") == "bucket/key/key"
	assert candidate("s3://some-bucket") == "some-bucket"
	assert candidate("bucket") == "bucket"
	assert candidate("some/path/to/repo.git") == "some/path/to/repo.git"
	assert candidate("s3://bucket/key/subkey/") == "bucket/key/subkey/"
	assert candidate("file:///foo/bar") == "/foo/bar"
	assert candidate("s3://foo/bar") == "foo/bar"
	assert candidate("s3://bucket/key") == "bucket/key"
	assert candidate("some/path?query") == "some/path?query"
	assert candidate("static/img/python-logo.png") == "static/img/python-logo.png"
	assert candidate("s3://foo") == "foo"
	assert candidate(r"file://Server/Share/Folder/File.ext") == r"Server/Share/Folder/File.ext"
	assert candidate("s3://bucket/key/") == "bucket/key/"
	assert candidate("gs://path") == "path"
	assert candidate(
    "https://www.python.org/static/img/python-logo.png"
) == "www.python.org/static/img/python-logo.png"
	assert candidate("gs://my_bucket/my_object") == "my_bucket/my_object"
	assert candidate(r"C:\Users\Joe\Desktop\file.txt") == r"C:\Users\Joe\Desktop\file.txt"
	assert candidate("s3:///tmp") == "/tmp"
	assert candidate(r"C:\Users\username\Documents") == r"C:\Users\username\Documents"
	assert candidate(
    "https://github.com/mozilla/bedrock/blob/master/assets/scss/base/_typography.scss"
) == "github.com/mozilla/bedrock/blob/master/assets/scss/base/_typography.scss"
def test_check():
	check(_get_path)
