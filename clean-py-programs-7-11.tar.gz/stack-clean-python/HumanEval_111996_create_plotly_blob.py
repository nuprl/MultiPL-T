def create_plotly_blob(data_list, xlabel, ylabel, title):
    """ 
     Create plotly line plot object, useful for jupyter plots or generation of interactive html plots
     E.G.
     import plotly.graph_objects as go
     blob = create_plotly_blob([(xdata1, ydata1, label1, True), (xdata2, ydata2, label2, False)], 'x', 'y', 'title')
     fig = go.Figure(blob)
     fig.show()
     
     4 element tuples in data_list must follow (xdata, ydata, label, visible):
     xdata: 1d array of x-axis data
     ydata: 1d array of y-axis data
     label: str label description
     visible: bool, if False plot is only given in legend but not turned on
     :param data_list: list of 4 element tuples (xdata, ydata, label, visible)
     :param xlabel: str x-axis label
     :param ylabel: str y-axis label
     :param title: str plot title
     :return: dict
     """
	### Canonical solution below ###    
    # Convert title
    title = title.replace('\n', '<br>')

    # Create json blob
    auto_blob = {
        'data': [],
        'layout': {'font': {'family': 'Courier New, monospace', 'size': 18},
                   'legend': {'title': {'text': 'Scannables'}},
                   'title': {'text': title},
                   'xaxis': {'title': {'text': xlabel}},
                   'yaxis': {'title': {'text': ylabel}}}
    }

    for item in data_list:
        if not item[3]:
            vis = 'legendonly'
        else:
            vis = True
        trace = {
            'mode': 'markers+lines',
            'name': item[2],
            'type': 'scatter',
            'visible': vis,
            'x': list(item[0]),
            'y': list(item[1]),

        }
        auto_blob['data'] += [trace]
    return auto_blob

### Unit tests below ###
def check(candidate):
	assert candidate([], 'x', 'y', 'title') == {'data': [], 'layout': {'font': {'family': 'Courier New, monospace','size': 18}, 'legend': {'title': {'text': 'Scannables'}}, 'title': {'text': 'title'}, 'xaxis': {'title': {'text': 'x'}}, 'yaxis': {'title': {'text': 'y'}}}}
	assert candidate(data_list=[], xlabel='x', ylabel='y', title='title') == \
       {'data': [],
        'layout': {'font': {'family': 'Courier New, monospace','size': 18},
                   'legend': {'title': {'text': 'Scannables'}},
                   'title': {'text': 'title'},
                   'xaxis': {'title': {'text': 'x'}},
                   'yaxis': {'title': {'text': 'y'}}}}
	assert candidate([], 'x', 'y', 'title') == {
    'data': [],
    'layout': {'font': {'family': 'Courier New, monospace','size': 18},
               'legend': {'title': {'text': 'Scannables'}},
               'title': {'text': 'title'},
               'xaxis': {'title': {'text': 'x'}},
               'yaxis': {'title': {'text': 'y'}}}}
	assert candidate([('a', 'b', 'c', True)], 'x', 'y', 'title') == {
    'data': [{'mode':'markers+lines', 'name': 'c', 'type':'scatter', 'visible': True, 'x': ['a'], 'y': ['b']}],
    'layout': {'font': {'family': 'Courier New, monospace','size': 18},
               'legend': {'title': {'text': 'Scannables'}},
               'title': {'text': 'title'},
               'xaxis': {'title': {'text': 'x'}},
               'yaxis': {'title': {'text': 'y'}}}}
def test_check():
	check(create_plotly_blob)
