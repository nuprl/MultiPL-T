def gcd(a, b):
    """ The greatest common divisor of ``a`` and ``b``"""
	### Canonical solution below ###    
    # Euclidean algorithm
    while b > 0:
        b, a = a % b, b
    return a

### Unit tests below ###
def check(candidate):
	assert candidate(12, 9) == 3
	assert candidate(3, 6) == 3
	assert candidate(-100, 200) == 100
	assert candidate(34, 19) == 1
	assert candidate(16, 17) == 1
	assert candidate(2, 5) == 1
	assert candidate(25, 15) == 5
	assert candidate(2, 0) == 2
	assert candidate(10, 0) == 10
	assert candidate(20, 16) == 4
	assert candidate(3, 3) == 3
	assert candidate(20, 8) == 4
	assert candidate(12, 3) == 3
	assert candidate(39, 91) == 13
	assert candidate(10, 20) == 10
	assert candidate(15, 15) == 15
	assert candidate(0, 0) == 0
	assert candidate(12, 16) == 4
	assert candidate(7, 8) == 1
	assert candidate(6, 2) == 2
	assert candidate(200, 100) == 100
	assert candidate(17, 12) == 1
	assert candidate(8, 9) == 1
	assert candidate(2, 4) == 2
	assert candidate(100, 1000) == 100
	assert candidate(0, 15) == 15
	assert candidate(3, 9) == 3
	assert candidate(12, 13) == 1
	assert candidate(0, 3) == 3
	assert candidate(100, 200) == 100
	assert candidate(100, 100) == 100
	assert candidate(3, 12) == 3
	assert candidate(5, 6) == 1
	assert candidate(-10, 20) == 10
	assert candidate(13, 14) == 1
	assert candidate(3, 5) == 1
	assert candidate(3, 15) == 3
	assert candidate(9, 2) == 1
	assert candidate(2, 6) == 2
	assert candidate(9, 10) == 1
	assert candidate(11, 12) == 1
	assert candidate(30, 45) == 15
	assert candidate(12, 18) == 6
	assert candidate(8, 12) == 4
	assert candidate(1, 2) == 1
	assert candidate(6, 7) == 1
	assert candidate(15, 6) == 3
	assert candidate(3*5*7*11, 2*3*5*7*13) == 3*5*7
	assert candidate(20, 20) == 20
	assert candidate(-200, 100) == 100
	assert candidate(10, -10) == 10
	assert candidate(20, 12) == 4
	assert candidate(2, 2) == 2
	assert candidate(14, 15) == 1
	assert candidate(2, 1) == 1
	assert candidate(100, -200) == 100
	assert candidate(12, 8) == 4
	assert candidate(6, 3) == 3
	assert candidate(20, 30) == 10
	assert candidate(3, 2) == 1
	assert candidate(6, 15) == 3
	assert candidate(1337, 0) == 1337
	assert candidate(3*5*7, 2*3*5*7) == 3*5*7
	assert candidate(1, 1) == 1
	assert candidate(24, 36) == 12
	assert candidate(6, 12) == 6
	assert candidate(1, 3) == 1
	assert candidate(2, 3) == 1
	assert candidate(-1, 1) == 1
	assert candidate(18, 19) == 1
	assert candidate(14, 8) == 2
	assert candidate(3*5*7, 3*5*11) == 3*5
	assert candidate(1, 0) == 1
	assert candidate(15, 21) == 3
	assert candidate(9, 6) == 3
	assert candidate(99, 12) == 3
	assert candidate(9, 12) == 3
	assert candidate(0, 42) == 42
	assert candidate(17, 18) == 1
	assert candidate(9, 3) == 3
	assert candidate(10, 11) == 1
	assert candidate(2, 9) == 1
	assert candidate(2, 12) == 2
	assert candidate(15, 16) == 1
	assert candidate(19, 20) == 1
	assert candidate(15, 3) == 3
	assert candidate(10, 100) == 10
	assert candidate(3, 0) == 3
	assert candidate(3*5*7*11, 2*3*5*7*11) == 3*5*7*11
def test_check():
	check(gcd)
