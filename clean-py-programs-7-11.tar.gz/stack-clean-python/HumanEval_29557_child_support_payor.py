def child_support_payor(responses, derived):
    """ Return the payor phrased for the affidavit """
    ### Canonical solution below ###

    payor = responses.get('child_support_payor', '')
    if payor == 'Myself (Claimant 1)':
        return 'Claimant 1'
    elif payor == 'My Spouse (Claimant 2)':
        return 'Claimant 2'
    elif payor == 'Both myself and my spouse':
        return 'both Claimant 1 and Claimant 2'

    return ''


### Unit tests below ###
def check(candidate):
	assert candidate({'candidate': 'Myself (Claimant 1)'}, dict()) == 'Claimant 1'
	assert candidate(
    {'candidate': 'Both myself and my spouse'},
    True) == 'both Claimant 1 and Claimant 2'
	assert candidate(
    {'candidate': 'My Spouse (Claimant 2)'},
    True) == 'Claimant 2'
	assert candidate({'candidate': 'My Spouse (Claimant 2)'}, dict()) == 'Claimant 2'
	assert candidate({'candidate': 'Both myself and my spouse'}, dict()) == 'both Claimant 1 and Claimant 2'
	assert candidate(
    {'candidate': 'My Spouse (Claimant 2)'},
    {
        'claimant_1_last_name': 'Smith',
        'claimant_2_last_name': 'Jones',
    }
) == 'Claimant 2'
	assert candidate(
    {'candidate': 'Myself (Claimant 1)'},
    True) == 'Claimant 1'
	assert candidate(
    {'candidate': 'My Spouse (Claimant 2)'},
    derived={}) == 'Claimant 2'
	assert candidate(
    {'candidate': 'Myself (Claimant 1)'},
    {
        'claimant_1_last_name': 'Smith',
        'claimant_2_last_name': 'Jones',
    }
) == 'Claimant 1'
	assert candidate(
    responses={'candidate': 'Both myself and my spouse'},
    derived={}
) == 'both Claimant 1 and Claimant 2'
	assert candidate(
    {'candidate': 'Both myself and my spouse'},
    derived={}) == 'both Claimant 1 and Claimant 2'
	assert candidate(
    {'candidate': 'None of these'},
    derived={}) == ''
	assert candidate(
    {'candidate': 'Both myself and my spouse'},
    {
        'claimant_1_last_name': 'Smith',
        'claimant_2_last_name': 'Jones',
    }
) == 'both Claimant 1 and Claimant 2'
	assert candidate(
    responses={'candidate': 'Myself (Claimant 1)'},
    derived={}
) == 'Claimant 1'
	assert candidate(
    {'candidate': 'Neither myself nor my spouse'},
    'candidate') == ''
	assert candidate(dict(), dict()) == ''
	assert candidate(
    {'candidate': 'My Spouse (Claimant 2)'},
    {'candidate': 'My Spouse (Claimant 2)'}
) == 'Claimant 2'
	assert candidate(
    {'candidate': 'Both myself and my spouse'},
    'candidate') == 'both Claimant 1 and Claimant 2'
	assert candidate(
    {'candidate': 'Myself (Claimant 1)'},
    {'candidate': 'Myself (Claimant 1)'}
) == 'Claimant 1'
	assert candidate(
    responses={'candidate': 'My Spouse (Claimant 2)'},
    derived={}
) == 'Claimant 2'
	assert candidate(
    {'candidate': 'Both myself and my spouse'},
    {'candidate': 'Both myself and my spouse'}
) == 'both Claimant 1 and Claimant 2'
	assert candidate(
    {'candidate': 'Myself (Claimant 1)'},
    'candidate') == 'Claimant 1'
	assert candidate(
    {'candidate': 'Myself (Claimant 1)'},
    derived={}) == 'Claimant 1'
	assert candidate(
    {'candidate': 'My Spouse (Claimant 2)'},
    'candidate') == 'Claimant 2'
def test_check():
	check(child_support_payor)
