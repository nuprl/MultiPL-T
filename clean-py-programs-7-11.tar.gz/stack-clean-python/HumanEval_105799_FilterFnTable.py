def FilterFnTable(fn_table, symbol):
    """ Remove a specific symbol from a fn_table."""
	### Canonical solution below ###  
  new_table = list()
  for entry in fn_table:
    # symbol[0] is a str with the symbol name
    if entry[0] != symbol:
      new_table.append(entry)
  return new_table

### Unit tests below ###
def check(candidate):
	assert candidate(
    [
        ['symbol1', 0x10000000, 0x20000000],
        ['symbol2', 0x20000000, 0x30000000],
    ],
   'symbol1') == [['symbol2', 0x20000000, 0x30000000]]
	assert candidate(
    [("a", 0), ("b", 1), ("c", 2)], "b") == [("a", 0), ("c", 2)]
	assert candidate(
    [
      ['A', 0x0000000000000000, 0x0000000000000000],
      ['B', 0x0000000000000000, 0x0000000000000000],
      ['C', 0x0000000000000000, 0x0000000000000000],
      ['D', 0x0000000000000000, 0x0000000000000000],
    ],
    'B'
    ) == [
      ['A', 0x0000000000000000, 0x0000000000000000],
      ['C', 0x0000000000000000, 0x0000000000000000],
      ['D', 0x0000000000000000, 0x0000000000000000],
    ]
	assert candidate(
  [
    [ "Foo", 123, 123 ],
    [ "Bar", 123, 123 ],
  ],
  "Foo"
) == [
  [ "Bar", 123, 123 ],
]
	assert candidate(
    [["foo", 0], ["bar", 0], ["baz", 0]], "bar") == [["foo", 0], ["baz", 0]]
	assert candidate(
    fn_table=[('A', 'A'), ('B', 'B'), ('C', 'C')],
    symbol='B') == [('A', 'A'), ('C', 'C')]
	assert candidate(
    [["foo", "bar"], ["baz", "boo"]], "boo") == [["foo", "bar"], ["baz", "boo"]]
	assert candidate(
    [("foo", 1, 2), ("bar", 2, 3), ("baz", 3, 4)], "baz") == [("foo", 1, 2), ("bar", 2, 3)]
	assert candidate(
  [
    [ "Foo", 123, 123 ],
    [ "Bar", 123, 123 ],
  ],
  "Bar"
) == [
  [ "Foo", 123, 123 ],
]
	assert candidate(
    [("a", 1), ("b", 2), ("c", 3)], "b") == [("a", 1), ("c", 3)]
	assert candidate(
    [
        ['symbol1', 0x10000000, 0x20000000],
        ['symbol2', 0x20000000, 0x30000000],
    ],
   'symbol3') == [
        ['symbol1', 0x10000000, 0x20000000],
        ['symbol2', 0x20000000, 0x30000000]
    ]
	assert candidate(
    [["foo", "bar"], ["baz", "boo"]], "baz") == [["foo", "bar"]]
	assert candidate(
    [("a", 0), ("b", 1), ("c", 2)], "a") == [("b", 1), ("c", 2)]
	assert candidate(
    [(1, 2), ('foo', 'bar'), ('baz', 'quux')], 'foo') == [(1, 2), ('baz', 'quux')]
	assert candidate(
    [("foo", 1, 2), ("bar", 2, 3), ("baz", 3, 4)], "foo") == [("bar", 2, 3), ("baz", 3, 4)]
	assert candidate(
    [["foo", "bar"], ["baz", "boo"]], "foo") == [["baz", "boo"]]
	assert candidate(
    [
        ['symbol1', 0x10000000, 0x20000000],
        ['symbol2', 0x20000000, 0x30000000],
    ],
   'symbol2') == [['symbol1', 0x10000000, 0x20000000]]
	assert candidate(
  [
    [ "Foo", 123, 123 ],
    [ "Bar", 123, 123 ],
  ],
  "Baz"
) == [
  [ "Foo", 123, 123 ],
  [ "Bar", 123, 123 ],
]
	assert candidate(
    [["a", 1], ["b", 2]], "c") == [["a", 1], ["b", 2]]
	assert candidate(
    [
        ('Symbol1', 0x10000000, 0x10000000),
        ('Symbol2', 0x10000000, 0x10000000),
        ('Symbol3', 0x10000000, 0x10000000),
    ],
    'Symbol2') == [
        ('Symbol1', 0x10000000, 0x10000000),
        ('Symbol3', 0x10000000, 0x10000000),
    ]
	assert candidate(
    [["a", 1], ["b", 2]], "a") == [["b", 2]]
def test_check():
	check(FilterFnTable)
