def eosToLFN( path ):
    """Converts a EOS PFN to an LFN.

    Just strip out /eos/cms from path.
    If this string is not found, return path.
    ??? Shouldn't we raise an exception instead?"""
    ### Canonical solution below ###
    return path.replace('root://eoscms.cern.ch/', '').replace('/eos/cms','')


### Unit tests below ###
def check(candidate):
	assert candidate( '/eos/cms/store/whatever' ) == '/store/whatever'
	assert candidate( 'whatever' ) == 'whatever'
	assert candidate('store/whatever/file.root' ) =='store/whatever/file.root'
	assert candidate( 'root://eoscms.cern.ch/a/b/c' ) == 'a/b/c'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/data/Run2012A/SingleElectron/AOD/PromptReco-v1/000/193/913/FEF03C93-9446-E111-8272-003048679178.root' ) == '/store/data/Run2012A/SingleElectron/AOD/PromptReco-v1/000/193/913/FEF03C93-9446-E111-8272-003048679178.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/relval/CMSSW_3_1_0_pre1/RelValSingleMuPt100/GEN-SIM-DIGI-RAW-HLTDEBUG/STARTUP31X_V1-v1/0001/002E155A-10F7-DD11-9135-0018F3D09624.root' ) == '/store/relval/CMSSW_3_1_0_pre1/RelValSingleMuPt100/GEN-SIM-DIGI-RAW-HLTDEBUG/STARTUP31X_V1-v1/0001/002E155A-10F7-DD11-9135-0018F3D09624.root'
	assert candidate( 'root://eoscms.cern.ch/a/b/c/d.root?a=1&b=2#fragment' ) == 'a/b/c/d.root?a=1&b=2#fragment'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/data/Run2011A/MinimumBias/RAW/v1/000/170/556/00000/008070F7-5475-E011-8253-0030487A18F2.root' ) == '/store/data/Run2011A/MinimumBias/RAW/v1/000/170/556/00000/008070F7-5475-E011-8253-0030487A18F2.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/whatever/file.root') == '/store/whatever/file.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/whatever' ) == '/store/whatever'
	assert candidate( 'root://eoscms.cern.ch/a/b/c/d.root#fragment' ) == 'a/b/c/d.root#fragment'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/group/dpg_tracker_strip/tracker/SiStripDQM/DQMIO/000/200/134/DQMIO_DQMIO_R000200f134_F00000000_C00000000.root' ) == '/store/group/dpg_tracker_strip/tracker/SiStripDQM/DQMIO/000/200/134/DQMIO_DQMIO_R000200f134_F00000000_C00000000.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/group/phys_egamma/l1egamma/L1EGamma_2016_v1/000/277/311/00000/08348258-8974-E611-A936-02163E014400.root' ) == '/store/group/phys_egamma/l1egamma/L1EGamma_2016_v1/000/277/311/00000/08348258-8974-E611-A936-02163E014400.root'
	assert candidate( "root://eoscms.cern.ch//eos/cms/store/whatever/foo" ) == "/store/whatever/foo"
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/mc/RunIISpring16MiniAODv2/TTJets_TuneCUETP8M1_13TeV-madgraphMLM-pythia8/MINIAODSIM/PUMoriond17_80X_mcRun2_asymptotic_2016_TrancheIV_v6-v1/80000/1A9E2712-860E-E611-A2C8-0025905A611A.root' ) == '/store/mc/RunIISpring16MiniAODv2/TTJets_TuneCUETP8M1_13TeV-madgraphMLM-pythia8/MINIAODSIM/PUMoriond17_80X_mcRun2_asymptotic_2016_TrancheIV_v6-v1/80000/1A9E2712-860E-E611-A2C8-0025905A611A.root'
	assert candidate( 'root://eoscms.cern.ch/a/b/c/d.root?a=1&b=2' ) == 'a/b/c/d.root?a=1&b=2'
	assert candidate( 'root://eoscms.cern.ch/store/whatever/file.root' ) =='store/whatever/file.root'
	assert candidate( 'root://eoscms.cern.ch/a/b/c/d/e/f.root' ) == 'a/b/c/d/e/f.root'
	assert candidate( 'root://eoscms.cern.ch/store/data/Run2010A/MinimumBias/RECO/v1/000/166/134/00000/1E9835B0-B127-DF11-A56F-0030487A18F2.root' ) =='store/data/Run2010A/MinimumBias/RECO/v1/000/166/134/00000/1E9835B0-B127-DF11-A56F-0030487A18F2.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/group/phys_egamma/l1t/L1Trigger/L1TMuonEndCap/v6.0/000/001/725/run_1725_ls_1725_index_0_event_1028910445-1.root' ) == '/store/group/phys_egamma/l1t/L1Trigger/L1TMuonEndCap/v6.0/000/001/725/run_1725_ls_1725_index_0_event_1028910445-1.root'
	assert candidate( "root://eoscms.cern.ch//eos/cms/store/whatever/foo/bar" ) == "/store/whatever/foo/bar"
	assert candidate( '/eos/cms/store/relval/CMSSW_7_2_0/RelValQCD_Pt_80_120/GEN-SIM-RECO/MCRUN2_71_V7-v1/00000/4845033E-B585-E411-A93D-0025905B85A2.root' ) == '/store/relval/CMSSW_7_2_0/RelValQCD_Pt_80_120/GEN-SIM-RECO/MCRUN2_71_V7-v1/00000/4845033E-B585-E411-A93D-0025905B85A2.root'
	assert candidate( 'root://eoscms.cern.ch/store/data/Run2012B/SingleMu/AOD/PromptReco-v1/000/206/697/00000/52769400-53D6-E111-A8B8-0025901D5D88.root' ) =='store/data/Run2012B/SingleMu/AOD/PromptReco-v1/000/206/697/00000/52769400-53D6-E111-A8B8-0025901D5D88.root'
	assert candidate('store/whatever' ) =='store/whatever'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/data/Run2016B/SingleMuon/MINIAOD/PromptReco-v1/000/291/610/00000/125B517E-653C-E611-A128-02163E014440.root' ) == '/store/data/Run2016B/SingleMuon/MINIAOD/PromptReco-v1/000/291/610/00000/125B517E-653C-E611-A128-02163E014440.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/group/phys_egamma/comm_phys/2018/06/12/EGAMMA_PhaseIIFall17D_V2_RAW_600_1200_Run2018A-02Aug2018-v1/00000/00915020-68C9-E811-A499-FA163E51E3A8.root' ) == '/store/group/phys_egamma/comm_phys/2018/06/12/EGAMMA_PhaseIIFall17D_V2_RAW_600_1200_Run2018A-02Aug2018-v1/00000/00915020-68C9-E811-A499-FA163E51E3A8.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/data/Run2012C/MinimumBias/RAW/v1/000/196/173/00000/10345B17-907F-E111-8E44-0025905A6090.root' ) == '/store/data/Run2012C/MinimumBias/RAW/v1/000/196/173/00000/10345B17-907F-E111-8E44-0025905A6090.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/whatever') == '/store/whatever'
	assert candidate( 'root://eoscms.cern.ch/a/b/c/d.root' ) == 'a/b/c/d.root'
	assert candidate( 'root://eoscms.cern.ch//eos/cms/store/unmerged/Run2012A/SingleElectron/RECO/PromptReco-v1/000/193/913/FEF03C93-9446-E111-8272-003048679178.root' ) == '/store/unmerged/Run2012A/SingleElectron/RECO/PromptReco-v1/000/193/913/FEF03C93-9446-E111-8272-003048679178.root'
def test_check():
	check(eosToLFN)
