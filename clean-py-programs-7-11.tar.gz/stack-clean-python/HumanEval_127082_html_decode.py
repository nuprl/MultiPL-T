def html_decode(s):
    """ 
     Returns the ASCII decoded version of the given HTML string. This does
     NOT remove normal HTML tags like <p>.
     """
	### Canonical solution below ###    
    for code in (
        ("'", '&#39;'),
        ('"', '&quot;'),
        ('>', '&gt;'),
        ('<', '&lt;'),
        ('&', '&amp;')
        ):                                 # noqa
        s = s.replace(code[1], code[0])    # noqa
    return s

### Unit tests below ###
def check(candidate):
	assert candidate(
    '&#39;test&#39; &quot;test&quot; &lt;test&gt; &amp;test&amp;') == \
    '\'test\' "test" <test> &test&'
	assert candidate(
    "&#39;") == "'"
	assert candidate(
    "&quot;") == '"'
	assert candidate(
    '&lt;') == '<'
	assert candidate(u'&quot;') == u'"'
	assert candidate(
    "&gt;") == '>'
	assert candidate(
    '"foo"'
    ) == '"foo"'
	assert candidate(
    '&amp;') == '&'
	assert candidate(
    "&lt;") == '<'
	assert candidate(
    '&#39; &quot; > < &amp;') == "' \" > < &"
	assert candidate(
    '&gt;') == '>'
	assert candidate(
    '&#39;foo&#39;'
    ) == "'foo'"
	assert candidate(
    '&quot;Hello, world!&quot;') == '"Hello, world!"'
	assert candidate(u'&lt;') == u'<'
	assert candidate(
    '&amp;'
    ) == '&'
	assert candidate(
    '&lt;p&gt;This is a paragraph.&lt;/p&gt;') == \
    '<p>This is a paragraph.</p>'
	assert candidate(u'&gt;') == u'>'
	assert candidate(
    '&lt;script&gt;alert(&#39;hi&#39;);&lt;/script&gt;'
    ) == '<script>alert(\'hi\');</script>'
	assert candidate(
    '&lt;a href=&quot;foo&quot;&gt;bar&lt;/a&gt;'
    ) == '<a href="foo">bar</a>'
	assert candidate('nothing to decode') == 'nothing to decode'
	assert candidate(
    "&amp;") == '&'
	assert candidate(
    '&lt;a href=&quot;foo&quot; class=&quot;bar&quot;&gt;baz&lt;/a&gt;'
    ) == '<a href="foo" class="bar">baz</a>'
	assert candidate(u'\'"<>') == u"'" + u'"' + u'<>'
	assert candidate(
    '<p id="foo">this is a test</p>'
    ) == '<p id="foo">this is a test</p>'
	assert candidate(
    '&gt;'
    ) == '>'
	assert candidate(
    '&lt;Hello&gt;world&lt;/Hello&gt;') == '<Hello>world</Hello>'
	assert candidate(u'&#39;') == u"'"
	assert candidate(
    '&#39; &quot; &lt; &gt; &amp;') == "' \" < > &"
	assert candidate(
    '&#39;Hello World&#39; &lt;a href=&quot;http://www.google.com&quot;&gt;Google&lt;/a&gt;'
    ) == "'Hello World' <a href=\"http://www.google.com\">Google</a>"
	assert candidate(
    '&quot; &amp; &#39;') == '" & \''
	assert candidate(
    '&lt;'
    ) == '<'
	assert candidate(
    '&lt;script&gt;alert(&quot;foo&quot;);&lt;/script&gt;'
    ) == '<script>alert("foo");</script>'
	assert candidate(
    '&quot;') == '"'
	assert candidate(
    '&#39;') == "'"
	assert candidate(
    '<script>alert("foo");</script>'
    ) == '<script>alert("foo");</script>'
	assert candidate(u'&amp;') == u'&'
	assert candidate(
    "This &quot;thing&quot; &lt;looks&gt; like &gt; 1 &amp; 2.") == (
    'This "thing" <looks> like > 1 & 2.')
	assert candidate(
    "Damien &#39;Danny&#39; Rice is a DJ and record producer.") == (
    "Damien 'Danny' Rice is a DJ and record producer.")
def test_check():
	check(html_decode)
