def poly_learning_rate(base_lr, curr_iter, max_iter, power=0.9):
    """poly learning rate policy"""
    ### Canonical solution below ###
    lr = base_lr * (1 - float(curr_iter) / max_iter) ** power
    return lr


### Unit tests below ###
def check(candidate):
	assert candidate(1e-3, 0, 1000, power=0.9) == 1e-3
	assert candidate(1.0, 0, 1000, power=2.0) == 1.0
	assert candidate(1.0, 2.0, 2.0, 1.0) == 0.0
	assert candidate(0.1, 1000, 1000, power=2.0) == 0.00
	assert candidate(1.0, 0, 1000, power=0.9) == 1.0
	assert candidate(0.01, 0, 100) == 0.01
	assert candidate(0.1, 0, 1000, power=2.0) == 0.1
	assert candidate(0.01, 0, 100, power=0.1) == 0.01
	assert candidate(0.1, 0, 1000, power=1.0) == 0.1
	assert candidate(0.1, 0, 100, 0.9) == 0.1
	assert candidate(1e-4, 0, 100000, 0.9) == 1e-4
	assert candidate(0.1, 0, 100000, power=0.9) == 0.1
	assert candidate(1, 0, 100) == 1
	assert candidate(0.1, 0, 100000, 0.9) == 0.1
	assert candidate(0.01, 0, 1000) == 0.01
	assert candidate(1.0, 0, 1000, 0.9) == 1.0
	assert candidate(1, 0, 1000, power=0.9) == 1
	assert candidate(0.001, 0, 100, power=0.9) == 0.001
	assert candidate(1.0, 0, 100000, power=0.9) == 1.0
	assert candidate(0.01, 0, 100, power=0.5) == 0.01
	assert candidate(0.01, 100, 100) == 0
	assert candidate(1, 0, 1000, 0.9) == 1
	assert candidate(1.0, 2.0, 2.0) == 0.0
	assert candidate(0.001, 0, 100000, power=0.9) == 0.001
	assert candidate(1.0, 0, 1000, power=1.0) == 1.0
	assert candidate(0.1, 0, 1000, power=0.9) == 0.1
def test_check():
	check(poly_learning_rate)
