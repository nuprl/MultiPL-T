def marker_pulse_width(session, Type='Real64', RepCap='', AttrID=1150064, buffsize=0, action=['Get', '']):
    """ [Marker Pulse Width]
     """
	### Canonical solution below ###    
    return session, Type, RepCap, AttrID, buffsize, action

### Unit tests below ###
def check(candidate):
	assert candidate(1, Type='Real64', RepCap='', AttrID=1150064, buffsize=0, action=['Get', ''])[2] == ''
	assert candidate(0, 'Real64', 'Dev1/port0/line1', 1150064, 0, ['Get', '']) == (0, 'Real64', 'Dev1/port0/line1', 1150064, 0, ['Get', ''])
	assert candidate(1, Type='Real64', RepCap='', AttrID=1150064, buffsize=0, action=['Get', ''])[1] == 'Real64'
	assert candidate(1) == (1, 'Real64', '', 1150064, 0, ['Get', ''])
	assert candidate(0.01) == (0.01, 'Real64', '', 1150064, 0, ['Get', ''])
	assert candidate(0, 'Real64', '', 1150064, 0, ['Get', ''])!= (0, 'Real64', '', 1150064, 1, ['Get', ''])
	assert candidate(0) == (0, 'Real64', '', 1150064, 0, ['Get', ''])
	assert candidate(0, 'Real64', '', 1150064, 0, ['Set', '']) == (0, 'Real64', '', 1150064, 0, ['Set', ''])
	assert candidate(1, 'Real64', 'cDAQ1Mod1/ao0', 1150064, 0, ['Set']) == (1, 'Real64', 'cDAQ1Mod1/ao0', 1150064, 0, ['Set'])
	assert candidate(1, Type='Real64', RepCap='', AttrID=1150064, buffsize=0, action=['Get', ''])[3] == 1150064
	assert candidate(1, 'Real64', '', 1150064, 0, ['Get', '']) == (1, 'Real64', '', 1150064, 0, ['Get', ''])
	assert candidate(589824, 'Real64', 'Dev1/ai0', 1150064, 0, ['Get', '']) == \
    (589824, 'Real64', 'Dev1/ai0', 1150064, 0, ['Get', ''])
	assert candidate(1, Type='Real64', RepCap='', AttrID=1150064, buffsize=0, action=['Get', ''])[5] == ['Get', '']
	assert candidate(0, 'Real64', '', 1150064, 0, ['Get', '']) == (0, 'Real64', '', 1150064, 0, ['Get', ''])
	assert candidate(1, 'Real64', 'cDAQ1Mod1/ao0', 1150064, 0, ['Get', 'Set']) == (1, 'Real64', 'cDAQ1Mod1/ao0', 1150064, 0, ['Get', 'Set'])
	assert candidate(5)
	assert candidate(1, 'Real64', 'Dev1/ai0', 1150064, 0, ['Get', '']) == (1, 'Real64', 'Dev1/ai0', 1150064, 0, ['Get', ''])
	assert candidate(0, 'Real64', '', 1150064, 0, ['Get', ''])!= (0, 'Real64', '', 1150064, 0, ['Get', 'Set'])
	assert candidate(1, Type='Real64', RepCap='', AttrID=1150064, buffsize=0, action=['Get', ''])[4] == 0
	assert candidate(0, 'Real64', '', 1150064, 0, ['Get', ''])!= (0, 'Real64', '', 1150063, 0, ['Get', ''])
	assert candidate(0, 'Real64', '', 1150064, 0, ['Get', ''])!= (0, 'Real64', '', 1150064, 0, ['Get'])
	assert candidate(0, 'Real64', '', 1150064, 0, ['Get', ''])!= (0, 'Int32', '', 1150064, 0, ['Get', ''])
	assert candidate(1, 'Real64', 'cDAQ1Mod1/ao0', 1150064, 0, ['Get']) == (1, 'Real64', 'cDAQ1Mod1/ao0', 1150064, 0, ['Get'])
def test_check():
	check(marker_pulse_width)
