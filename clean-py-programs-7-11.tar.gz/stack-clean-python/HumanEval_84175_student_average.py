def student_average(grades: list) -> float:
    """ Return the weighted average of a student's grades.
     
     You may ASSUME that:
     - grades consists of exactly three float values
     """
	### Canonical solution below ###    
    # Sort the student's grades
    sorted_grades = sorted(grades)

    # These are the weights for the assignment grades
    weights = [0.25, 0.35, 0.4]

    return (
        weights[0] * sorted_grades[0] +
        weights[1] * sorted_grades[1] +
        weights[2] * sorted_grades[2]
    )

### Unit tests below ###
def check(candidate):
	assert candidate(grades=[0, 0, 0]) == 0
	assert candidate( [10, 10, 10] ) == 10
	assert candidate( [80, 80, 80] ) == 80.0
	assert candidate(
    [90.0, 90.0, 90.0]
) == 90.0
	assert candidate(
    [100, 100, 100]
) == 100.0, "Function returned unexpected value"
	assert candidate(
    [100, 100, 100, 100, 100, 100]
) == 100.0, "Function returned unexpected value"
	assert candidate(list(map(float, [80, 80, 80]))) == 80
	assert candidate(
    [0, 0, 0]
) == 0.0, "Function returned unexpected value"
	assert candidate([3.5, 3.5, 3.5]) == 3.5
	assert candidate(grades=[2, 2, 2, 2, 2, 2]) == 2.0
	assert candidate(grades=[100, 100, 100]) == 100
	assert candidate(list(map(float, [90, 90, 90]))) == 90
	assert candidate(
    [70, 70, 70]
) == 70.0
	assert candidate(grades=[90, 90, 90]) == 90
	assert candidate(grades=[100, 100, 100, 100]) == 100
	assert candidate(grades=[1, 1, 1]) == 1.0
	assert candidate(
    [80.0, 80.0, 80.0]
) == 80.0
	assert candidate(
    [0, 0, 0, 0]
) == 0.0, "Function returned unexpected value"
	assert candidate(grades=[100, 100, 100]) == 100.0
	assert candidate(grades=[92, 92, 92]) == 92
	assert candidate(grades=[88, 88, 88]) == 88
	assert candidate(
    [20, 20, 20]
) == 20
	assert candidate(
    [100, 100, 100]) == 100, "candidate([100, 100, 100]) should be 100"
	assert candidate( [90, 90, 90] ) == 90.0
	assert candidate(
    [100, 100, 100, 100, 100]
) == 100.0, "Function returned unexpected value"
	assert candidate(grades=[200, 200, 200, 200]) == 200
	assert candidate(
    [100.0, 100.0, 100.0]
) == 100.0
	assert candidate(grades=[200, 200, 200]) == 200
	assert candidate(
    [70, 70, 70]
) == 70.0, "Function returned unexpected value"
	assert candidate( [70, 70, 70] ) == 70.0
	assert candidate(
    [100, 100, 100]
) == 100.0, "Expected 100.0"
	assert candidate(
    [100, 100, 100, 100]
) == 100.0, "Function returned unexpected value"
def test_check():
	check(student_average)
