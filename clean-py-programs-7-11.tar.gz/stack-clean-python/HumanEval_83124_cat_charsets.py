def cat_charsets(cs):
    """ Combine a set into an alphabetically sorted list in written English,
     using commas and 'and'. """
	### Canonical solution below ###  
  d = sorted(cs)
  if len(d) > 2:
    d[-1] = "and " + d[-1]
    d = ", ".join(d)
  else:
    d = " and ".join(d)
  return d

### Unit tests below ###
def check(candidate):
	assert candidate(set("abcde")) == candidate(set("deabc"))
	assert candidate(set([u"a"])) == "a"
	assert candidate({"a", "b", "c"}) == "a, b, and c"
	assert candidate(set(['a', 'b', 'c'])) == 'a, b, and c'
	assert candidate(set("01234")) == "0, 1, 2, 3, and 4"
	assert candidate({"a"}) == "a"
	assert candidate(set("abc")) == "a, b, and c"
	assert candidate(set("ab")) == "a and b"
	assert candidate({"a", "b", "c", "d"}) == "a, b, c, and d"
	assert candidate(set(["latin1", "latin2", "latin3"])) == "latin1, latin2, and latin3"
	assert candidate(set(['a', 'b'])) == 'a and b'
	assert candidate(set(["latin1"])) == "latin1"
	assert candidate(set(['a'])) == 'a'
	assert candidate(set([u"a", u"b"])) == "a and b"
	assert candidate(set("012345")) == "0, 1, 2, 3, 4, and 5"
	assert candidate(set(["latin1", "latin2", "latin3", "latin4"])) == "latin1, latin2, latin3, and latin4"
	assert candidate(set("a")) == "a"
	assert candidate({"a", "b"}) == "a and b"
	assert candidate(set()) == ""
	assert candidate(set(["latin1", "latin2"])) == "latin1 and latin2"
def test_check():
	check(cat_charsets)
