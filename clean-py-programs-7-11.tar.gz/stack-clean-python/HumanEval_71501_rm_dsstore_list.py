def rm_dsstore_list(list):
		"""
		** Intended for macOS users who sorted files in Finder in any special way **
		Removes the directories (strings) from an input list that contain
		.DS_Store in the string (therefore removes the directory to .DS_Store files)

		:param: list of directories
		:return: list of directories without directories to any .DS_Store files
		"""
    ### Canonical solution below ###
		for directory in list:
			if ".DS_Store" in directory:
				list.remove(directory)
		return list


### Unit tests below ###
def check(candidate):
	assert candidate(["1.txt", "2.txt", "3.txt"]) == ["1.txt", "2.txt", "3.txt"]
	assert candidate(list=["a", "b", "c", "d", "e", "f", "g", "h"]) == ["a", "b", "c", "d", "e", "f", "g", "h"]
	assert candidate(list=[]) == []
	assert candidate(
	['/Users/test/Desktop/test.py', '/Users/test/Desktop/test.DS_Store', '/Users/test/Desktop/test.txt']) == ['/Users/test/Desktop/test.py', '/Users/test/Desktop/test.txt']
	assert candidate(
	['/Users/test/Desktop/test.py', '/Users/test/Desktop/test.DS_Store', '/Users/test/Desktop/test.txt', '/Users/test/Desktop/test.DS_Store']) == ['/Users/test/Desktop/test.py', '/Users/test/Desktop/test.txt']
	assert candidate(list=["/Users/user/Desktop/test", "/Users/user/Desktop/test/test2", "/Users/user/Desktop/test/.DS_Store"]) == ["/Users/user/Desktop/test", "/Users/user/Desktop/test/test2"]
	assert candidate(list=[".DS_Store", "dir1", "dir2", "dir3"]) == ["dir1", "dir2", "dir3"]
	assert candidate(list=["folder1", "folder2", "folder3", "folder4", "folder5", "folder6", "folder7", "folder8", "folder9"]) == ["folder1", "folder2", "folder3", "folder4", "folder5", "folder6", "folder7", "folder8", "folder9"]
	assert candidate(list=["a", "b", "c"]) == ["a", "b", "c"]
	assert candidate(list=["/home/user/Downloads/.DS_Store"]) == []
	assert candidate(list=["folder1", "folder2", "folder3", "folder4"]) == ["folder1", "folder2", "folder3", "folder4"]
	assert candidate(
		[
		"~/Desktop",
		"~/Desktop/folder",
		"~/Desktop/folder/.DS_Store",
		"~/Desktop/folder/file.txt",
		"~/Desktop/folder/file2.txt"
		]
		) == ["~/Desktop", "~/Desktop/folder", "~/Desktop/folder/file.txt", "~/Desktop/folder/file2.txt"]
	assert candidate(list=["dir1", "dir2", "dir3", "dir4"]) == ["dir1", "dir2", "dir3", "dir4"], "Test 1 failed"
	assert candidate(list=["dir1", "dir2", "dir3", "dir4"]) == ["dir1", "dir2", "dir3", "dir4"]
	assert candidate(list=["/Users/user/Desktop/test"]) == ["/Users/user/Desktop/test"]
	assert candidate(list=["a", "b", "c", "a.DS_Store"]) == ["a", "b", "c"]
	assert candidate(list=["folder1", "folder2", "folder3", "folder4", "folder5", "folder6", "folder7"]) == ["folder1", "folder2", "folder3", "folder4", "folder5", "folder6", "folder7"]
	assert candidate(list=["/", "/home", "/home/user", "/home/user/Downloads", "/home/user/Downloads/Documents"]) == ["/", "/home", "/home/user", "/home/user/Downloads", "/home/user/Downloads/Documents"]
	assert candidate(list=["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]) == ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
	assert candidate(list=["/Users/user/Desktop/test", "/Users/user/Desktop/test/.DS_Store"]) == ["/Users/user/Desktop/test"]
	assert candidate(list=["dir1", "dir2", "dir3", "dir4", "dir5", ".DS_Store"]) == ["dir1", "dir2", "dir3", "dir4", "dir5"]
	assert candidate(list(["/Users/username/Desktop/Folder1", "/Users/username/Desktop/Folder2", "/Users/username/Desktop/Folder3/.DS_Store"])) == list(["/Users/username/Desktop/Folder1", "/Users/username/Desktop/Folder2"])
	assert candidate(list(["a", "b", "c", "d", "e", "f"])) == ["a", "b", "c", "d", "e", "f"]
	assert candidate(list=["/", "/home"]) == ["/", "/home"]
	assert candidate(list=["/Users/test/Desktop/.DS_Store"]) == []
	assert candidate(list=["folder1", "folder2", "folder3", "folder4", "folder5"]) == ["folder1", "folder2", "folder3", "folder4", "folder5"]
	assert candidate(list=["folder1", "folder2", "folder3", "folder4", "folder5", "folder6", "folder7", "folder8"]) == ["folder1", "folder2", "folder3", "folder4", "folder5", "folder6", "folder7", "folder8"]
	assert candidate(list=["dir1", "dir2", "dir3", ".DS_Store"]) == ["dir1", "dir2", "dir3"]
	assert candidate(list=["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k"]) == ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k"]
	assert candidate(list=["/", "/home", "/home/user", "/home/user/Downloads", "/home/user/Downloads/.DS_Store", "/home/user/Downloads/Documents"]) == ["/", "/home", "/home/user", "/home/user/Downloads", "/home/user/Downloads/Documents"]
	assert candidate(list=["/Users/user/Desktop/test", "/Users/user/Desktop/test/test2"]) == ["/Users/user/Desktop/test", "/Users/user/Desktop/test/test2"]
	assert candidate(list=["dir1", "dir2", "dir3"]) == ["dir1", "dir2", "dir3"]
	assert candidate(list(["a", "b", "c.DS_Store", "d", "e", "f.DS_Store"])) == ["a", "b", "d", "e"]
	assert candidate(list=["/", "/home", "/home/user"]) == ["/", "/home", "/home/user"]
	assert candidate(list=["folder1", "folder2", "folder3", "folder4", "folder5", "folder6"]) == ["folder1", "folder2", "folder3", "folder4", "folder5", "folder6"]
	assert candidate(list=["test", "test2", ".DS_Store"]) == ["test", "test2"]
	assert candidate(["1.txt", "2.txt", "3.txt", ".DS_Store"]) == ["1.txt", "2.txt", "3.txt"]
	assert candidate(list=["/", "/home", "/home/user", "/home/user/Downloads"]) == ["/", "/home", "/home/user", "/home/user/Downloads"]
	assert candidate(list=["/"]) == ["/"]
	assert candidate(list=["/home/user/Downloads", "/home/user/Downloads/.DS_Store", "/home/user/Downloads/more_stuff"]) == ["/home/user/Downloads", "/home/user/Downloads/more_stuff"]
	assert candidate(list=["dir1", "dir2", "dir3", "dir4", ".DS_Store"]) == ["dir1", "dir2", "dir3", "dir4"], "Test 2 failed"
	assert candidate(list=["test","test/test","test/.DS_Store"]) == ["test","test/test"]
	assert candidate(list=["/Users/user/Desktop/test", "/Users/user/Desktop/test/test2", "/Users/user/Desktop/test/test3", "/Users/user/Desktop/test/.DS_Store"]) == ["/Users/user/Desktop/test", "/Users/user/Desktop/test/test2", "/Users/user/Desktop/test/test3"]
	assert candidate(list=["/home/user/Downloads", "/home/user/Downloads/more_stuff"]) == ["/home/user/Downloads", "/home/user/Downloads/more_stuff"]
	assert candidate(list=["test", "test2", ".DS_Store", "test.DS_Store"]) == ["test", "test2", "test.DS_Store"]
	assert candidate(list=["dir1", "dir2", "dir3", "dir4", "dir5", "dir6", "dir7", "dir8", ".DS_Store"]) == ["dir1", "dir2", "dir3", "dir4", "dir5", "dir6", "dir7", "dir8"], "Test 3 failed"
	assert candidate(["1.txt", "2.txt", "3.txt", "4.txt"]) == ["1.txt", "2.txt", "3.txt", "4.txt"]
def test_check():
	check(rm_dsstore_list)
