def climbing_stairs(n):
    """Find how many ways to reach."""
    ### Canonical solution below ###
    # import pdb; pdb.set_trace()
    if n <= 2:
        return n
    dp = [0 for __ in range(n)]
    dp[0] = 1
    dp[1] = 2
    for i in range(2, n):
        dp[i] = dp[i - 1] + dp[i - 2]
    return dp[n - 1]


### Unit tests below ###
def check(candidate):
	assert candidate(6) == 13
	assert candidate(1) == 1
	assert candidate(7) == 21
	assert candidate(17) == 2584
	assert candidate(0) == 0
	assert candidate(11) == 144
	assert candidate(16) == 1597
	assert candidate(10) == 89
	assert candidate(8) == 34
	assert candidate(9) == 55
	assert candidate(22) == 28657
	assert candidate(14) == 610
	assert candidate(4) == 5
	assert candidate(18) == 4181
	assert candidate(19) == 6765
	assert candidate(15) == 987
	assert candidate(23) == 46368
	assert candidate(12) == 233
	assert candidate(3) == 3
	assert candidate(21) == 17711
	assert candidate(13) == 377
	assert candidate(5) == 8
	assert candidate(20) == 10946
	assert candidate(2) == 2
def test_check():
	check(climbing_stairs)
