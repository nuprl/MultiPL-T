def normalize_url(url):
    """Normalize the url by removing the final "/" if it exists

    :param url: The given url
    :type url: str
    :return: The normalized url
    :rtype: str
    """
    ### Canonical solution below ###
    if url.endswith("/"):
        return url.rpartition("/")[0]


### Unit tests below ###
def check(candidate):
	assert candidate(
    "http://www.example.com/path/"
) == "http://www.example.com/path"
	assert candidate(
    "https://api.github.com/users/octocat/orgs/github/") == "https://api.github.com/users/octocat/orgs/github"
	assert candidate(
    "https://www.example.com/test/"
) == "https://www.example.com/test"
	assert candidate(
    "https://www.google.com/search?q=hello%20world&tbm=isch/"
) == "https://www.google.com/search?q=hello%20world&tbm=isch"
	assert candidate(
    "https://www.google.com/"
) == "https://www.google.com"
	assert candidate(
    "https://www.example.com/") == "https://www.example.com"
	assert candidate(
    "https://www.example.com/index.php?search=test&page=1/") == \
    "https://www.example.com/index.php?search=test&page=1"
	assert candidate(
    "https://www.google.com/search?q=test/") == "https://www.google.com/search?q=test"
	assert candidate("https://google.com/") == "https://google.com"
	assert candidate(url="https://www.example.com/test/test/test/") == "https://www.example.com/test/test/test"
	assert candidate(
    "https://api.github.com/users/octocat/orgs/") == "https://api.github.com/users/octocat/orgs"
	assert candidate(
    "https://www.example.com/path/to/somewhere/") == "https://www.example.com/path/to/somewhere"
	assert candidate("http://example.com/") == "http://example.com"
	assert candidate(url="https://www.example.com/") == "https://www.example.com"
	assert candidate("a/") == "a"
	assert candidate("http://example.com/test/") == "http://example.com/test"
	assert candidate(
    "https://www.example.com/") == "https://www.example.com", \
    "https://www.example.com/"
	assert candidate("https://www.google.com/") == "https://www.google.com"
	assert candidate(
    "https://www.example.com/index.php?search=test&page=1/test.html/") == \
    "https://www.example.com/index.php?search=test&page=1/test.html"
	assert candidate(
    "http://www.example.com/"
) == "http://www.example.com"
	assert candidate(url="https://github.com/user/repo/") == "https://github.com/user/repo"
	assert candidate("https://www.wikipedia.org/wiki/Python_(programming_language)/") == "https://www.wikipedia.org/wiki/Python_(programming_language)"
	assert candidate(
    "http://www.example.com/path/to/resource/") == "http://www.example.com/path/to/resource"
	assert candidate("http://www.google.com/path/") == "http://www.google.com/path"
	assert candidate(
    "https://www.example.com/path/to/resource/"
) == "https://www.example.com/path/to/resource"
	assert candidate(
    "http://www.example.com/index.html/"
) == "http://www.example.com/index.html"
	assert candidate(url="https://www.google.com/test/test2/") == "https://www.google.com/test/test2"
	assert candidate(
    "https://www.example.com/index.php?search=test&page=1&test=test/") == \
    "https://www.example.com/index.php?search=test&page=1&test=test"
	assert candidate(url="https://www.google.com/") == "https://www.google.com"
	assert candidate(
    "https://api.github.com/repos/octocat/Hello-World/issues/"
) == "https://api.github.com/repos/octocat/Hello-World/issues"
	assert candidate("https://www.example.com/test/") == "https://www.example.com/test"
	assert candidate(url="https://www.example.com/test/test/") == "https://www.example.com/test/test"
	assert candidate(
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ/") == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
	assert candidate(url="https://www.google.com/test/") == "https://www.google.com/test"
	assert candidate(
    "https://www.google.com/") == "https://www.google.com"
	assert candidate(
    "http://www.example.com/a/b/c/"
) == "http://www.example.com/a/b/c"
	assert candidate(
    "https://api.github.com/repos/octocat/Hello-World/issues/comments/1/") == "https://api.github.com/repos/octocat/Hello-World/issues/comments/1"
	assert candidate("http://www.google.com/") == "http://www.google.com"
	assert candidate("http://www.example.com/") == "http://www.example.com"
	assert candidate(
    "https://www.google.com/test/"
) == "https://www.google.com/test"
	assert candidate("http://www.example.com/foo/bar/") == "http://www.example.com/foo/bar"
	assert candidate(
    "http://www.google.com/"
) == "http://www.google.com", "Incorrect url"
	assert candidate(url="https://www.example.com/test/") == "https://www.example.com/test"
	assert candidate("a/b/") == "a/b"
def test_check():
	check(normalize_url)
