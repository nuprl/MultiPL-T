def _is_no_rec_name(info_name):
    """
    helper method to see if we should not provide any recommendation
    """
    ### Canonical solution below ###
    if info_name == "last_boot_time":
        return True


### Unit tests below ###
def check(candidate):
	assert not candidate("not_last_boot_time")
	assert candidate("last_boot_time")
	assert candidate("last_boot_time") == True
	assert not candidate("last_shutdown_time")
	assert not candidate("some_other_name")
	assert candidate("last_boot_time") is True
def test_check():
	check(_is_no_rec_name)
