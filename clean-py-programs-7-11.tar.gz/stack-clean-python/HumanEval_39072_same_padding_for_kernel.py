def same_padding_for_kernel(shape, corr, strides_up=None):
    """ 
     Taken verbatim from tensorflow_compression.ops.padding_ops
     """
	### Canonical solution below ###  
  rank = len(shape)
  if strides_up is None:
    strides_up = rank * (1,)

  if corr:
    padding = [(s // 2, (s - 1) // 2) for s in shape]
  else:
    padding = [((s - 1) // 2, s // 2) for s in shape]

  padding = [((padding[i][0] - 1) // strides_up[i] + 1,
              (padding[i][1] - 1) // strides_up[i] + 1) for i in range(rank)]
  return padding

### Unit tests below ###
def check(candidate):
	assert candidate(shape=[16, 16, 16], corr=True) == [(8, 7), (8, 7), (8, 7)]
	assert candidate(shape=(4, 3), corr=False) == [(1, 2), (1, 1)]
	assert candidate(shape=(3, 3, 3), corr=True) == [(1, 1), (1, 1), (1, 1)]
	assert candidate(shape=(4, 4), corr=False, strides_up=(2, 2)) == [(1, 1), (1, 1)]
	assert candidate(shape=[3, 5, 5], corr=False) == [(1, 1), (2, 2), (2, 2)]
	assert candidate(shape=(5, 5, 5, 5), corr=False, strides_up=(1, 2, 3, 4)) == [(2, 2), (1, 1), (1, 1), (1, 1)]
	assert candidate(shape=(3, 3, 3), corr=False) == [(1, 1), (1, 1), (1, 1)]
	assert candidate(shape=(3, 4, 5), corr=True, strides_up=(2, 2, 2)) == [(1, 1), (1, 1), (1, 1)]
	assert candidate(shape=[3, 5, 5], corr=True) == [(1, 1), (2, 2), (2, 2)]
	assert candidate(shape=(3, 3), corr=True) == [(1, 1), (1, 1)]
	assert candidate(shape=[3, 3, 3], corr=True, strides_up=(3, 3, 3)) == [(1, 1), (1, 1), (1, 1)]
	assert candidate(shape=(3, 3), corr=True, strides_up=(2, 2)) == [(1, 1), (1, 1)]
	assert candidate(shape=(4, 4), corr=True, strides_up=(2, 2)) == [(1, 1), (1, 1)]
	assert candidate(shape=(1, 1, 1, 1), corr=False) == [(0, 0), (0, 0), (0, 0), (0, 0)]
	assert candidate(shape=[3, 3, 3], corr=True, strides_up=(2, 2, 2)) == [(1, 1), (1, 1), (1, 1)]
	assert candidate(shape=(3, 3), corr=False) == [(1, 1), (1, 1)]
	assert candidate(shape=[16, 16], corr=True) == [(8, 7), (8, 7)]
	assert candidate(shape=(3, 4), corr=False) == [(1, 1), (1, 2)]
	assert candidate(shape=(1, 1, 1), corr=True) == [(0, 0), (0, 0), (0, 0)]
	assert candidate(shape=(5, 5), corr=False) == [(2, 2), (2, 2)]
	assert candidate(shape=(3, 3), corr=True, strides_up=(1, 1)) == [(1, 1), (1, 1)]
	assert candidate(shape=(4, 4), corr=False, strides_up=(3, 3)) == [(1, 1), (1, 1)]
	assert candidate(shape=[3, 3, 3], corr=True) == [(1, 1), (1, 1), (1, 1)]
	assert candidate(shape=(5, 5), corr=False, strides_up=(2, 2)) == [(1, 1), (1, 1)]
	assert candidate(shape=(1, 1, 1), corr=False) == [(0, 0), (0, 0), (0, 0)]
	assert candidate(shape=(5, 5), corr=True) == [(2, 2), (2, 2)]
	assert candidate(shape=[3, 3, 3], corr=False) == [(1, 1), (1, 1), (1, 1)]
	assert candidate(shape=(5, 5), corr=True, strides_up=(2, 2)) == [(1, 1), (1, 1)]
	assert candidate(shape=(1, 1, 1, 1), corr=False, strides_up=(2, 2, 2, 2)) == [(0, 0), (0, 0), (0, 0), (0, 0)]
	assert candidate(shape=(1, 1, 1, 1), corr=True, strides_up=(2, 2, 2, 2)) == [(0, 0), (0, 0), (0, 0), (0, 0)]
	assert candidate(shape=(5, 5, 5), corr=False) == [(2, 2), (2, 2), (2, 2)]
	assert candidate(shape=(1, 1, 1, 1), corr=True) == [(0, 0), (0, 0), (0, 0), (0, 0)]
	assert candidate(shape=(4, 4), corr=True, strides_up=(3, 3)) == [(1, 1), (1, 1)]
	assert candidate(shape=[3, 3, 3], corr=False, strides_up=(3, 3, 3)) == [(1, 1), (1, 1), (1, 1)]
def test_check():
	check(same_padding_for_kernel)
