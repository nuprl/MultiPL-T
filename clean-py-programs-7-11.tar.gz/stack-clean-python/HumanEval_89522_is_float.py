def is_float(value, return_value=False):
    """ Return value as float, if possible """
	### Canonical solution below ###    
    try:
        value = float(value)
    except ValueError:
        if not return_value:
            return False

    if return_value:
        return value

    return True

### Unit tests below ###
def check(candidate):
	assert candidate("123.456", return_value=True) == 123.456
	assert not candidate('10.0.0')
	assert candidate('5')
	assert candidate("123.456.789") == False
	assert candidate("1,0") == False
	assert not candidate('a')
	assert not candidate("1.0a")
	assert candidate("1.1") is True
	assert not candidate('1.0.0.0')
	assert candidate("a1.0") == False
	assert candidate('1.0') is True
	assert not candidate('5.1a')
	assert candidate(123.456, True) == 123.456
	assert candidate(123.45) == True
	assert candidate(1)
	assert candidate("1.0") is True
	assert candidate('1', True) == 1
	assert candidate("1.a") is False
	assert candidate(1.5)
	assert candidate('123.456') is True
	assert candidate("123.45") == True
	assert candidate("1.234", return_value=True) == 1.234
	assert candidate("1.0", return_value=True) == 1.0
	assert candidate(5.0, True) == 5.0
	assert candidate(0.0)
	assert candidate('123.456.789') is False
	assert not candidate('1,1,1')
	assert candidate("a") == False
	assert candidate("1.23")
	assert candidate(1, return_value=True) == 1.0
	assert candidate("False") == False
	assert not candidate('5.1.1')
	assert candidate('123') is True
	assert candidate(10.0, True) == 10.0
	assert candidate('1', return_value=True) == 1.0
	assert candidate('1.5')
	assert candidate("123abc") == False
	assert candidate(0.0, return_value=True) == 0.0
	assert candidate('1.1')
	assert candidate('1') is True
	assert not candidate("None")
	assert candidate(5.0) == True
	assert candidate(123.456)
	assert candidate(5)
	assert candidate("1.0") == True
	assert candidate('1.0', return_value=True) == 1.0
	assert not candidate('1.1.1')
	assert not candidate('1.5.1')
	assert candidate(10.0)
	assert candidate('123.456.789.123', return_value=True) == '123.456.789.123'
	assert candidate("a") is False
	assert candidate('123.456')
	assert not candidate('1.0.0')
	assert candidate(0.1)
	assert candidate('5.1')
	assert candidate(123) == True
	assert candidate("1.0", True) == 1.0
	assert candidate(1.2, return_value=True) == 1.2
	assert candidate("123", return_value=True) == 123.0
	assert candidate('10.0', True) == 10.0
	assert candidate("abc") is False
	assert candidate(1.1)
	assert candidate("Hello") == False
	assert candidate(-1)
	assert candidate('a') is False
	assert candidate('10.0')
	assert candidate(5.1)
	assert candidate(123) is True
	assert candidate(1.0) is True
	assert candidate(0)
	assert candidate('123.456', return_value=True) == 123.456
	assert candidate("123.45", return_value=True) == 123.45
	assert candidate("1.0.0.0") == False
	assert candidate('10')
	assert candidate('123.456', True) == 123.456
	assert not candidate('one')
	assert candidate("1", return_value=True) == 1.0
	assert not candidate('1.1.1.1')
	assert candidate('5.0')
	assert candidate("1.0a") == False
	assert not candidate("abc")
	assert candidate('1', True) == 1.0
	assert not candidate('5.a')
	assert candidate(1.234)
	assert candidate(1) == True
	assert candidate("123") == True
	assert candidate(123.456, return_value=True) == 123.456
	assert candidate("5", True) == 5
	assert candidate(123.456) is True
	assert candidate("a1") == False
	assert candidate("abc") == False
	assert candidate('10', True) == 10.0
	assert candidate("1") is True
	assert candidate(1.0)
	assert candidate("True") == False
	assert candidate("1")
	assert candidate("abc123") == False
	assert not candidate('1.1,1')
	assert candidate("1.1", return_value=True) == 1.1
	assert candidate("1.23", return_value=True) == 1.23
	assert candidate('1.1', True) == 1.1
	assert candidate(5.0)
	assert candidate("1") == True
	assert candidate(5) == True
	assert not candidate("a")
	assert not candidate('abc')
	assert candidate(1.5, True) == 1.5
	assert candidate("abc123.456") == False
	assert not candidate('1,1,1,1')
	assert not candidate('1,1.1')
	assert candidate("1.0,0") == False
	assert candidate(1.23)
	assert candidate("123.456")
	assert candidate("1.0.1") == False
	assert candidate("1.0")
	assert candidate("1.0.0") == False
	assert candidate(1.23, return_value=True) == 1.23
	assert candidate('x', True) == 'x'
	assert candidate(1, return_value=True) == 1
	assert candidate(1, True) == 1
	assert candidate(1.0, return_value=True) == 1.0
	assert not candidate('5.1.1a')
	assert candidate("123", return_value=True) == 123
	assert candidate('1.a') is False
	assert candidate(1.0) == True
	assert not candidate('5a')
	assert candidate(1) is True
	assert candidate('1.0')
def test_check():
	check(is_float)
