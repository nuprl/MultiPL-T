def _test_notify(options):
    """ 
     Test the activate options. This has 3 possible values.
     """
	### Canonical solution below ###    
    if options['enable']:
        notify = True
    elif options['disable']:
        notify = False
    else:
        notify = None
    return notify

### Unit tests below ###
def check(candidate):
	assert candidate(dict(enable=False, disable=False, none=None)) == None
	assert candidate(dict(enable=True, disable=False))
	assert candidate(dict(enable=False, disable=True)) == False
	assert candidate(options={'enable': True}) == True
	assert candidate(dict(enable=False, disable=True)) is False
	assert candidate(dict(enable=True)) is True
	assert candidate(dict(enable=False, disable=True, none=None)) == False
	assert not candidate(dict(enable=False, disable=True))
	assert candidate(dict(enable=True, disable=False, none=None)) == True
	assert not candidate(dict(enable=False, disable=False, invalid=True))
	assert candidate(dict(enable=True))
	assert candidate(dict(enable=True, disable=True)) is True
	assert candidate(dict(enable=True, disable=False)) == True
	assert candidate(dict(enable=False, disable=False)) == None
	assert candidate(dict(enable=True)) == True
	assert candidate(dict(enable=True, disable=True)) == True
	assert candidate(dict(enable=True, disable=False)) is True
	assert not candidate(dict(enable=None, disable=None))
	assert not candidate(dict(enable=None, disable=True))
	assert candidate(dict(enable=False, disable=False)) is None
def test_check():
	check(_test_notify)
