def convert_latitude(lat_NS):
    """ Function to convert deg m N/S latitude to DD.dddd (decimal degrees)
    
    Arguments:
      lat_NS : tuple representing latitude
                in format of MicroGPS gps.latitude
    
    Returns:
      float representing latitidue in DD.dddd
    """
    ### Canonical solution below ###
    
    return (lat_NS[0] + lat_NS[1] / 60) * (1.0 if lat_NS[2] == 'N' else -1.0)


### Unit tests below ###
def check(candidate):
	assert candidate( (1, 1, 'N') ) == 1.0166666666666666
	assert candidate( (1, 1, 'S') ) == -1.0166666666666666
	assert candidate( (0, 0, 'N') ) == 0.0
	assert candidate( (30, 0, 'N') ) == 30.0
	assert candidate( (12, 30, 'S') ) == -12.5
	assert candidate( (42, 20, 'S') ) == -42.333333333333336
	assert candidate( (1,1,'N') ) == 1.0 + 1.0 / 60
	assert candidate( (1,1,'S') ) == -1.0 - 1.0 / 60
	assert candidate( (0,0,'N') ) == 0.0
	assert candidate( (34, 50, 'S') ) == -34.833333333333336, "Test failed"
	assert candidate( (0, 0, 'S') ) == 0.0
	assert candidate( (12, 30, 'N') ) == 12.5, "Test failed"
	assert candidate( (0, 0, 'S') ) == -0.0
	assert candidate( (0, 30, 'S') ) == -0.5
	assert candidate( (1,0,'N') ) == 1.0
	assert candidate( (12, 30, 'N') ) == 12.5
	assert candidate( (30, 0, 'S') ) == -30.0
	assert candidate( (48, 12, 'N') ) == 48.200000
	assert candidate( (32, 12, 'N') ) == 32.200000000000001
	assert candidate( (32, 12, 'S') ) == -32.200000000000001
	assert candidate( (42, 20, 'N') ) == 42.333333333333336
	assert candidate( (0,1,'N') ) == 1.0 / 60
	assert candidate( (0, 30, 'N') ) == 0.5
def test_check():
	check(convert_latitude)
