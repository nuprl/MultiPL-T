def to_hex_str(data_bytes: bytes) -> str:
    """
    Converts bytes into its string hex representation.

    :param data_bytes: data to represent as hex.
    :type data_bytes: bytearray or bytes

    :return: the hex representation of the data
    :rtype: str
    """
    ### Canonical solution below ###
    if isinstance(data_bytes, bytes):
        data_bytes = bytearray(data_bytes)
    data_bytes.reverse()
    return '0x' + data_bytes.hex()


### Unit tests below ###
def check(candidate):
	assert candidate(b'\x00\x01\x02') == '0x020100'
	assert candidate(bytearray([0x01])) == '0x01'
	assert candidate(bytes([0x01, 0x02, 0x03])) == '0x030201'
	assert candidate(b'\x0a') == '0x0a'
	assert candidate(b'\x01\x02\x03\x04\x05') == '0x0504030201'
	assert candidate(bytes.fromhex('0000000000000000')) == '0x0000000000000000'
	assert candidate(b'A') == '0x41'
	assert candidate(bytearray([0x12, 0x34, 0x56, 0x78, 0x90, 0xab])) == '0xab9078563412'
	assert candidate(bytes.fromhex('00000000000000')) == '0x00000000000000'
	assert candidate(bytes.fromhex('00')) == '0x00'
	assert candidate(bytes([0x00, 0x01, 0x02, 0x03])) == candidate(bytearray([0x00, 0x01, 0x02, 0x03]))
	assert candidate(bytes.fromhex('000000')) == '0x000000'
	assert candidate(b'\x07') == '0x07'
	assert candidate(bytearray.fromhex('11223344')) == '0x44332211'
	assert candidate(bytes.fromhex('0000000000')) == '0x0000000000'
	assert candidate(bytes([0x00, 0x01, 0x02, 0x03])) == '0x03020100'
	assert candidate(b'\x0f') == '0x0f'
	assert candidate(b'\x01\x02') == '0x0201'
	assert candidate(b'\x08') == '0x08'
	assert candidate(bytes([0x00, 0x01, 0x02, 0x03]))!= candidate(bytes([0x03, 0x02, 0x01, 0x00]))
	assert candidate(b'\x0b') == '0x0b'
	assert candidate(bytearray([0x12, 0x34, 0x56, 0x78])) == '0x78563412'
	assert candidate(bytes.fromhex('00000000')) == '0x00000000'
	assert candidate(bytearray([0x00])) == '0x00'
	assert candidate(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09') == '0x09080706050403020100'
	assert candidate(b'\x03') == '0x03'
	assert candidate(b'\x00\x01\x02\x03') == '0x03020100'
	assert candidate(bytes([0xff, 0xff])) == "0xffff"
	assert candidate(bytes([0x01, 0x02])) == '0x0201'
	assert candidate(bytearray([0, 0, 0, 0])) == '0x00000000'
	assert candidate(bytes([0x00, 0x00])) == "0x0000"
	assert candidate(bytearray([1, 2, 3, 4])) == '0x04030201'
	assert candidate(b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10') == '0x100f0e0d0c0b0a090807060504030201'
	assert candidate(bytearray([0x12, 0x34])) == '0x3412'
	assert candidate(bytearray([0x12])) == '0x12'
	assert candidate(bytearray.fromhex('1122334455667788')) == '0x8877665544332211'
	assert candidate(bytes([0x00])) == '0x00'
	assert candidate(bytes.fromhex('000000000000')) == '0x000000000000'
	assert candidate(b'\x0e') == '0x0e'
	assert candidate(b'\x06') == '0x06'
	assert candidate(b'\x11') == '0x11'
	assert candidate(bytearray([0x01, 0x02, 0x03])) == '0x030201'
	assert candidate(b'') == '0x'
	assert candidate(b'\x01\x02\x03\x04') == '0x04030201'
	assert candidate(bytearray([0x12, 0x34, 0x56])) == '0x563412'
	assert candidate(b'\x12') == '0x12'
	assert candidate(bytes.fromhex('000000000000000000')) == '0x000000000000000000'
	assert candidate(bytearray.fromhex('')) == '0x'
	assert candidate(bytes([0x01])) == '0x01'
	assert candidate(b'\x00') == '0x00'
	assert candidate(b'\x0c') == '0x0c'
	assert candidate(bytearray([0x12, 0x34, 0x56, 0x78, 0x90])) == '0x9078563412'
	assert candidate(bytes.fromhex('00000000000000000000')) == '0x00000000000000000000'
	assert candidate(bytearray(b'')) == '0x'
	assert candidate(b'\x01\x00') == '0x0001'
	assert candidate(bytearray([1, 2, 3])) == '0x030201'
	assert candidate(b'\x01\x02\x03') == '0x030201'
	assert candidate(b'\x01') == '0x01'
	assert candidate(b'\x05') == '0x05'
	assert candidate(b'\x00\x01') == '0x0100'
	assert candidate(b'\x10') == '0x10'
	assert candidate(b'\x0d') == '0x0d'
	assert candidate(b'\x04') == '0x04'
	assert candidate(bytes([0x00, 0x00, 0x00, 0x00])) == "0x00000000"
	assert candidate(b'1') == '0x31'
	assert candidate(b'\x09') == '0x09'
	assert candidate(bytearray([0x00, 0x01, 0x02, 0x03])) == '0x03020100'
	assert candidate(b'\x02') == '0x02'
	assert candidate(bytes([1, 2, 3])) == '0x030201'
	assert candidate(bytes([0x00, 0x01, 0x02, 0x03]))!= candidate(bytearray([0x03, 0x02, 0x01, 0x00]))
def test_check():
	check(to_hex_str)
