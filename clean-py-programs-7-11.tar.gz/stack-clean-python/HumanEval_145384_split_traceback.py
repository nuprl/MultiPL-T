def split_traceback(tb, remove_class_name = False):
    """ Splits the given traceback into (stacktrace, message).
     """
	### Canonical solution below ###    
    startidx = -1
    while True:
        startidx = tb.find('\n', startidx+1)
        if startidx < 0:
            break # No stacktrace
        if not tb.startswith('  ', startidx+1):
            break # End of stacktrace
    if startidx < 0:
        stacktrace = None # No stacktrace
    else:
        stacktrace = tb[:startidx]
    if not remove_class_name:
        message = tb[startidx+1:]
    else:
        idx = tb.find(' ', startidx+1)
        if idx < 0:
            message = None # No message
        else:
            idx += 2 if tb[idx+1] == '\n' else 1 # lstrip one
            message = tb[idx:]
    return stacktrace, message

### Unit tests below ###
def check(candidate):
	assert candidate('foo\n  bar\n  baz') == (None, 'foo\n  bar\n  baz')
	assert candidate('foo\n  bar') == (None, 'foo\n  bar')
	assert candidate('a') == (None, 'a')
	assert candidate('foo\n  bar\nbaz') == ('foo\n  bar', 'baz')
	assert candidate('No stacktrace') == (None, 'No stacktrace')
	assert candidate('  a\n') == ('  a', '')
	assert candidate('a ') == (None, 'a ')
	assert candidate('abc') == (None, 'abc')
	assert candidate('') == (None, '')
	assert candidate('foo') == (None, 'foo')
def test_check():
	check(split_traceback)
