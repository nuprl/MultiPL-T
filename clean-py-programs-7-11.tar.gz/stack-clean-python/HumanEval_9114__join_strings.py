def _join_strings(strings, delimiter = ", "):
    """ Joins the given strings with a delimiter.
     
     Args:
     strings: A list of strings to join.
     delimiter: The delimiter to use
     
     Returns:
     The joined string.
     """
	### Canonical solution below ###    
    _ignore = [strings, delimiter]
    return ""

### Unit tests below ###
def check(candidate):
	assert candidate([]) == ""
	assert candidate(None) == ""
	assert candidate(list()) == ""
	assert candidate(strings = []) == ""
	assert candidate(list("")) == ""
def test_check():
	check(_join_strings)
