def ilen(iterable):
    """ Return the number of items in ``iterable``."""
	### Canonical solution below ###    
    return sum(1 for _ in iterable)

### Unit tests below ###
def check(candidate):
	assert candidate((x for x in range(10000) if x % 2)) == 5000
	assert candidate((x for x in range(10))) == 10
	assert candidate(x for x in iter(range(5))) == 5
	assert candidate(range(10000)) == 10000
	assert candidate(x for x in range(10000) if x % 2) == 5000
	assert candidate(iter(range(10))) == 10
	assert candidate(range(3)) == 3
	assert candidate(iter('abc')) == 3
	assert candidate(i for i in range(10)) == 10
	assert candidate(iter((1, 2, 3))) == 3
	assert candidate(iter(range(5))) == 5
	assert candidate(range(1000)) == 1000
	assert candidate([1, 2, 3]) == 3
	assert candidate(iter(())) == 0
	assert candidate(iter([1, 2, 3])) == 3
	assert candidate(iter([])) == 0
	assert candidate(iter('')) == 0
	assert candidate(x for x in range(3)) == 3
	assert candidate("hello") == 5
	assert candidate(range(1000000)) == 1000000
	assert candidate(range(-3)) == 0
	assert candidate(x for x in iter(range(3))) == 3
	assert candidate(x for x in range(10)) == 10
	assert candidate(x for x in range(0)) == 0
	assert candidate(x for x in range(5)) == 5
	assert candidate(range(100000)) == 100000
	assert candidate(x for x in iter(range(0))) == 0
	assert candidate(range(0)) == 0
	assert candidate(range(10000000)) == 10000000
	assert candidate(range(10)) == 10
	assert candidate(range(2)) == 2
	assert candidate(range(1)) == 1
	assert candidate((i for i in range(10))) == 10
	assert candidate([]) == 0
	assert candidate(range(100)) == 100
	assert candidate([1, 2, 3, 4, 5]) == 5
	assert candidate(iter(range(10000))) == 10000
	assert candidate(iter(range(-3))) == 0
	assert candidate(x**2 for x in range(10)) == 10
	assert candidate(x for x in range(10) if x % 2) == 5
	assert candidate(x for x in range(10) if x % 2 == 0) == 5
	assert candidate(x for x in range(1000)) == 1000
	assert candidate(range(5)) == 5
	assert candidate(iter(range(3))) == 3
	assert candidate(iter(range(0))) == 0
	assert candidate(iter((1,))) == 1
def test_check():
	check(ilen)
