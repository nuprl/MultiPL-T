def split_array(arr, n):
    """
    Split an input array into multiple sub-arrays of maximum length n

    :return: Array of arrays with maximum length n

    >>> split_array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 13)
    [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], [14]]
    """
    ### Canonical solution below ###

    return [arr[i:i+n] for i in range(0, len(arr), n)]


### Unit tests below ###
def check(candidate):
	assert candidate(list(range(1, 15)), 1) == [[1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14]]
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 3) == [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14]]
	assert candidate(list(range(1, 15)), 5) == [[1, 2, 3, 4, 5], [6, 7, 8, 9, 10], [11, 12, 13, 14]]
	assert candidate(list(range(1, 15)), 3) == [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14]]
	assert candidate(list(range(1, 15)), 14) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]
	assert candidate([1], 1) == [[1]]
	assert candidate(list(range(15)), 2) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9], [10, 11], [12, 13], [14]]
	assert candidate(list(range(14)), 15) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]]
	assert candidate(list(range(10)), 8) == [[0, 1, 2, 3, 4, 5, 6, 7], [8, 9]]
	assert candidate(list(range(10)), 2) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
	assert candidate(list(range(10)), 3) == [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
	assert candidate(list(range(10)), 6) == [[0, 1, 2, 3, 4, 5], [6, 7, 8, 9]]
	assert candidate(list(range(10)), 9) == [[0, 1, 2, 3, 4, 5, 6, 7, 8], [9]]
	assert candidate(list(range(10)), 10) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
	assert candidate(list(range(1, 15)), 7) == [[1, 2, 3, 4, 5, 6, 7], [8, 9, 10, 11, 12, 13, 14]]
	assert candidate(list(range(10)), 1) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 13) == [
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], [14]]
	assert candidate(list(range(14)), 14) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]]
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 1) == [[1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14]]
	assert candidate([], 1) == []
	assert candidate(list(range(15)), 7) == [[0, 1, 2, 3, 4, 5, 6], [7, 8, 9, 10, 11, 12, 13], [14]]
	assert candidate(list(range(10)), 10) == [[i for i in range(10)]]
	assert candidate(list(range(1, 15)), 16) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]
	assert candidate(list(range(1, 15)), 13) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], [14]]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 13) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], [14]]
	assert candidate(list(range(10)), 4) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
	assert candidate(list(range(1, 15)), 15) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]
	assert candidate(list(range(14)), 13) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], [13]]
	assert candidate(list(range(15)), 6) == [[0, 1, 2, 3, 4, 5], [6, 7, 8, 9, 10, 11], [12, 13, 14]]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3) == [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10]]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1) == [[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]]
	assert candidate(list(range(15)), 1) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14]]
	assert candidate(list(range(10)), 5) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
	assert candidate(list(range(15)), 5) == [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13, 14]]
	assert candidate(list(range(15)), 15) == [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]
	assert candidate(list(range(10)), 7) == [[0, 1, 2, 3, 4, 5, 6], [7, 8, 9]]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 1000) == [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]
def test_check():
	check(split_array)
