def format(dict):
    """
    itype: Dict
    rtype: String, formatted dict
    """
    ### Canonical solution below ###
    res = ['\t\t<object>']
    for (key, val) in dict.items():
        line = '\t\t\t<{}>"{}"</{}>'.format(key, val, key)
        res.append(line)
    res.append('\t\t</object>\n')

    return '\n'.join(res)


### Unit tests below ###
def check(candidate):
	assert candidate(dict(a=1, b=2, c=3)) == '\t\t<object>\n\t\t\t<a>"1"</a>\n\t\t\t<b>"2"</b>\n\t\t\t<c>"3"</c>\n\t\t</object>\n'
	assert candidate(dict(a='b')) == '\t\t<object>\n\t\t\t<a>"b"</a>\n\t\t</object>\n'
	assert candidate({'a': '1', 'b': '2'}) == '\t\t<object>\n\t\t\t<a>"1"</a>\n\t\t\t<b>"2"</b>\n\t\t</object>\n'
	assert candidate(dict(name='name', value='value')) == '\t\t<object>\n\t\t\t<name>"name"</name>\n\t\t\t<value>"value"</value>\n\t\t</object>\n'
	assert candidate(dict(name='foo', age=12)) == '\t\t<object>\n\t\t\t<name>"foo"</name>\n\t\t\t<age>"12"</age>\n\t\t</object>\n'
	assert candidate(dict(name='bob', age=32)) == '\t\t<object>\n\t\t\t<name>"bob"</name>\n\t\t\t<age>"32"</age>\n\t\t</object>\n'
	assert candidate(dict(name='name')) == '\t\t<object>\n\t\t\t<name>"name"</name>\n\t\t</object>\n'
	assert candidate({'id': '1'}) == '\t\t<object>\n\t\t\t<id>"1"</id>\n\t\t</object>\n'
	assert candidate(dict(a='a', b='b')) == '\t\t<object>\n\t\t\t<a>"a"</a>\n\t\t\t<b>"b"</b>\n\t\t</object>\n'
	assert candidate(dict(name='name', x='1', y='2', z='3')) == '\t\t<object>\n\t\t\t<name>"name"</name>\n\t\t\t<x>"1"</x>\n\t\t\t<y>"2"</y>\n\t\t\t<z>"3"</z>\n\t\t</object>\n'
	assert candidate(dict(name='Alfred', age='20', extra='extra')) == """\
\t\t<object>
\t\t\t<name>"Alfred"</name>
\t\t\t<age>"20"</age>
\t\t\t<extra>"extra"</extra>
\t\t</object>
"""
	assert candidate(dict(a=1, b=2)) == '\t\t<object>\n\t\t\t<a>"1"</a>\n\t\t\t<b>"2"</b>\n\t\t</object>\n'
	assert candidate(
    {'name': 'John', 'age': 36, 'city': 'New York'}
) == '\t\t<object>\n\t\t\t<name>"John"</name>\n\t\t\t<age>"36"</age>\n\t\t\t<city>"New York"</city>\n\t\t</object>\n'
	assert candidate(
    {'name': 'John', 'age': 36}
) == '\t\t<object>\n\t\t\t<name>"John"</name>\n\t\t\t<age>"36"</age>\n\t\t</object>\n'
	assert candidate(dict(type='a', name='b', value='c')) == '\t\t<object>\n\t\t\t<type>"a"</type>\n\t\t\t<name>"b"</name>\n\t\t\t<value>"c"</value>\n\t\t</object>\n'
	assert candidate(
    {}
) == '\t\t<object>\n\t\t</object>\n'
	assert candidate(dict()) == '\t\t<object>\n\t\t</object>\n'
	assert candidate(dict(name='Alfred', age='20')) == """\
\t\t<object>
\t\t\t<name>"Alfred"</name>
\t\t\t<age>"20"</age>
\t\t</object>
"""
	assert candidate(dict(name='Alfred')) == """\
\t\t<object>
\t\t\t<name>"Alfred"</name>
\t\t</object>
"""
	assert candidate(dict(a='b', b='c')) == '\t\t<object>\n\t\t\t<a>"b"</a>\n\t\t\t<b>"c"</b>\n\t\t</object>\n'
	assert candidate(dict(name="foo")) == '\t\t<object>\n\t\t\t<name>"foo"</name>\n\t\t</object>\n'
	assert candidate(
    {'name': 'John'}
) == '\t\t<object>\n\t\t\t<name>"John"</name>\n\t\t</object>\n'
	assert candidate({'name': 'John', 'age': 26}) == '\t\t<object>\n\t\t\t<name>"John"</name>\n\t\t\t<age>"26"</age>\n\t\t</object>\n'
	assert candidate(dict(a="a", b="b")) == "\t\t<object>\n\t\t\t<a>\"a\"</a>\n\t\t\t<b>\"b\"</b>\n\t\t</object>\n"
	assert candidate(dict(a="b")) == "\t\t<object>\n\t\t\t<a>\"b\"</a>\n\t\t</object>\n"
	assert candidate({'id': '1', 'name': 'A'}) == '\t\t<object>\n\t\t\t<id>"1"</id>\n\t\t\t<name>"A"</name>\n\t\t</object>\n'
	assert candidate({'a': 'b'}) == '\t\t<object>\n\t\t\t<a>"b"</a>\n\t\t</object>\n'
	assert candidate({'id': '1', 'name': 'A', 'last': 'B'}) == '\t\t<object>\n\t\t\t<id>"1"</id>\n\t\t\t<name>"A"</name>\n\t\t\t<last>"B"</last>\n\t\t</object>\n'
	assert candidate(dict(name='John', age=25)) == '''\
\t\t<object>
\t\t\t<name>"John"</name>
\t\t\t<age>"25"</age>
\t\t</object>
'''
	assert candidate(dict(a="b", c="d")) == "\t\t<object>\n\t\t\t<a>\"b\"</a>\n\t\t\t<c>\"d\"</c>\n\t\t</object>\n"
def test_check():
	check(format)
