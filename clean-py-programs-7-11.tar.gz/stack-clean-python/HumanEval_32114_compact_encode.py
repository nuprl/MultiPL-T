def compact_encode(i:int) -> bytes:
    """Encodes an integer as a compact int"""
    ### Canonical solution below ###
    if i < 0:
        raise ValueError("integer can't be negative: {}".format(i))
    order = 0
    while (i>>(8*(2**order))):
        order += 1
    if order == 0:
        if i < 0xfd:
            return bytes([i])
        order = 1
    if order > 3:
        raise ValueError("integer too large: {}".format(i))
    return bytes([0xfc+order]) + i.to_bytes(2**order, 'little')


### Unit tests below ###
def check(candidate):
	assert candidate(65536) == b'\xfe\x00\x00\x01\x00'
	assert candidate(0x100000000) == b'\xff\x00\x00\x00\x00\x01\x00\x00\x00'
	assert candidate(255) == b'\xfd\xff\x00'
	assert candidate(0x100) == b'\xfd\x00\x01'
	assert candidate(0xffff) == bytes([0xfd, 0xff, 0xff])
	assert candidate(0xfd) == bytes([0xfd, 0xfd, 0])
	assert candidate(0xffff) == b'\xfd\xff\xff'
	assert candidate(123) == b'\x7b'
	assert candidate(16) == b'\x10'
	assert candidate(0xffffffff) == b'\xfe\xff\xff\xff\xff'
	assert candidate(4294967295) == b'\xfe\xff\xff\xff\xff'
	assert candidate(1025) == b"\xfd\x01\x04"
	assert candidate(0) == bytes([0])
	assert candidate(252) == b'\xfc'
	assert candidate(1024) == b"\xfd\x00\x04"
	assert candidate(1) == b'\x01'
	assert candidate(0x10000) == b'\xfe\x00\x00\x01\x00'
	assert candidate(1) == bytes([1])
	assert candidate(0xfc) == b'\xfc'
	assert candidate(0) == b'\x00'
	assert candidate(253) == b'\xfd\xfd\x00'
	assert candidate(254) == b'\xfd\xfe\x00'
	assert candidate(0xffffffffffffffff) == b'\xff\xff\xff\xff\xff\xff\xff\xff\xff'
	assert candidate(100) == b'\x64'
	assert candidate(16) == bytes([0x10])
	assert candidate(256) == b'\xfd\x00\x01'
	assert candidate(127) == bytes([127])
	assert candidate(127) == b'\x7f'
	assert candidate(0xfc) == bytes([0xfc])
	assert candidate(65535) == b'\xfd\xff\xff'
	assert candidate(0xff) == b'\xfd\xff\x00'
	assert candidate(0xffffffff) == b"\xfe\xff\xff\xff\xff"
	assert candidate(127) == bytes([0x7f])
	assert candidate(0xfe) == b'\xfd\xfe\x00'
	assert candidate(2**31) == b'\xfe\x00\x00\x00\x80'
	assert candidate(0xfd) == b'\xfd\xfd\x00'
	assert candidate(18446744073709551615) == b'\xff\xff\xff\xff\xff\xff\xff\xff\xff'
	assert candidate(4294967296) == b'\xff\x00\x00\x00\x00\x01\x00\x00\x00'
	assert candidate(0xffffffffffffffff) == b"\xff\xff\xff\xff\xff\xff\xff\xff\xff"
	assert candidate(15) == bytes([15])
def test_check():
	check(compact_encode)
