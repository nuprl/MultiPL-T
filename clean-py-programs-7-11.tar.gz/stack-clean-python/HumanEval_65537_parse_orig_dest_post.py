def parse_orig_dest_post(params, keys = ['origin_code', 'destination_code']):
    """ Normalize origin and destination keys in the POST request.
     """
	### Canonical solution below ###    
    for key in keys:
        # Port code must be 5-character uppercase string
        if len(params[key]) != 5:
            raise RuntimeError()
        else:
            params[key] = str(params[key]).upper()
    return params

### Unit tests below ###
def check(candidate):
	assert candidate(dict(origin_code='12345', destination_code='67890')) == \
    dict(origin_code='12345', destination_code='67890')
	assert candidate(dict(origin_code = 'abcde', destination_code = 'fghij')) == dict(origin_code = 'ABCDE', destination_code = 'FGHIJ')
	assert candidate(dict(origin_code='abcde', destination_code='abcde')) == dict(origin_code='ABCDE', destination_code='ABCDE')
	assert candidate(dict(origin_code = 'ABCDE', destination_code = 'fghij')) == {'origin_code': 'ABCDE', 'destination_code': 'FGHIJ'}
	assert candidate(dict(origin_code = 'abcde', destination_code = 'FGHIJ')) == {'origin_code': 'ABCDE', 'destination_code': 'FGHIJ'}
	assert candidate(dict(origin_code = 'AB123', destination_code = 'CD456')) == dict(origin_code = 'AB123', destination_code = 'CD456')
	assert candidate(dict(origin_code = 'bostn', destination_code = 'amstn')) == {'origin_code': 'BOSTN', 'destination_code': 'AMSTN'}
	assert candidate(dict(origin_code='abcde', destination_code='fghij')) == \
    dict(origin_code='ABCDE', destination_code='FGHIJ')
	assert candidate(dict(origin_code='abcde', destination_code='ABCDE')) == dict(origin_code='ABCDE', destination_code='ABCDE')
	assert candidate(dict(origin_code='ABCDE', destination_code='abcde')) == dict(origin_code='ABCDE', destination_code='ABCDE')
	assert candidate(dict(origin_code = 'abcde', destination_code = 'fghij')) == {'origin_code': 'ABCDE', 'destination_code': 'FGHIJ'}
	assert candidate(dict(origin_code='12345', destination_code='67890'), \
    keys = ['origin_code', 'destination_code']) == \
    dict(origin_code='12345', destination_code='67890')
	assert candidate(dict(origin_code='ABCDE', destination_code='FGHIJ')) == \
        dict(origin_code='ABCDE', destination_code='FGHIJ')
	assert candidate(dict(origin_code='ABCDE', destination_code='FGHIJ')) == \
    dict(origin_code='ABCDE', destination_code='FGHIJ')
	assert candidate(dict(origin_code = 'ABCDE', destination_code = 'FGHIJ')) == {'origin_code': 'ABCDE', 'destination_code': 'FGHIJ'}
	assert candidate(dict(origin_code = 'ab123', destination_code = 'cd456')) == dict(origin_code = 'AB123', destination_code = 'CD456')
	assert candidate(dict(origin_code = 'abcde',
                                 destination_code = 'fghij')) == \
       dict(origin_code = 'ABCDE', destination_code = 'FGHIJ')
	assert candidate(dict(origin_code='abcde', destination_code='fghij')) == \
       dict(origin_code='ABCDE', destination_code='FGHIJ')
	assert candidate(dict(origin_code='abcde', destination_code='FGHIJ')) == \
    dict(origin_code='ABCDE', destination_code='FGHIJ')
	assert candidate(dict(origin_code='ABCDE', destination_code='fghij')) == \
    dict(origin_code='ABCDE', destination_code='FGHIJ')
	assert candidate(dict(origin_code='abcde', destination_code='fghij')) == dict(origin_code='ABCDE', destination_code='FGHIJ')
	assert candidate(dict(origin_code='abcde', destination_code='12345')) == dict(origin_code='ABCDE', destination_code='12345')
def test_check():
	check(parse_orig_dest_post)
