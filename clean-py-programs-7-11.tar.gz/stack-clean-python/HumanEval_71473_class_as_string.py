def class_as_string(obj):
    """Return the full class of an object as string"""
    ### Canonical solution below ###
    module = obj.__class__.__module__
    if module is None or module == str.__class__.__module__:
        return obj.__class__.__name__
    return module + '.' + obj.__class__.__name__


### Unit tests below ###
def check(candidate):
	assert candidate(list()) == 'list'
	assert candidate(int('1', 10)) == 'int'
	assert candidate(12345) == 'int'
	assert candidate(1.0) == 'float'
	assert candidate(candidate) == "function"
	assert candidate(int) == 'type'
	assert candidate((1, 2, 3)) == 'tuple'
	assert candidate(type(candidate)) == 'type'
	assert candidate(float()) == "float"
	assert candidate('string') =='str'
	assert candidate(int()) == 'int'
	assert candidate(1) == "int"
	assert candidate("foo") == "str"
	assert candidate([1, 2, 3]) == 'list'
	assert candidate(dict) == 'type'
	assert candidate({'a':1}) == 'dict'
	assert candidate(1.1) == 'float'
	assert candidate(list) == 'type'
	assert candidate(tuple) == 'type'
	assert candidate(dict()) == "dict"
	assert candidate(1) == 'int'
	assert candidate(type([])) == 'type'
	assert candidate(int('1', 36)) == 'int'
	assert candidate(type) == "type"
	assert candidate(list()) == "list"
	assert candidate(set()) == "set"
	assert candidate((1, 2)) == 'tuple'
	assert candidate(frozenset([1, 2])) == 'frozenset'
	assert candidate(int('1', 8)) == 'int'
	assert candidate({'a': 1}) == 'dict'
	assert candidate("1") == "str"
	assert candidate(int('1', 16)) == 'int'
	assert candidate(object) == 'type'
	assert candidate(123) == 'int'
	assert candidate(True) == "bool"
	assert candidate(set()) =='set'
	assert candidate(int) == "type"
	assert candidate(type({})) == 'type'
	assert candidate(type) == 'type'
	assert candidate({}) == 'dict'
	assert candidate('1.1') =='str'
	assert candidate(True) == 'bool'
	assert candidate(object) == "type"
	assert candidate(frozenset()) == "frozenset"
	assert candidate(candidate) == 'function'
	assert candidate(12345.12345) == 'float'
	assert candidate(int('1')) == 'int'
	assert candidate([1, 2]) == 'list'
	assert candidate([1, 2, 3]) == "list"
	assert candidate(1.0) == "float"
	assert candidate(set([1, 2])) =='set'
	assert candidate(int('1', 20)) == 'int'
	assert candidate('abc') =='str'
	assert candidate(1.) == 'float'
	assert candidate(tuple()) == 'tuple'
	assert candidate([1,2,3]) == 'list'
	assert candidate(type(Ellipsis)) == 'type'
	assert candidate(list([1])) == 'list'
	assert candidate("a") == "str"
	assert candidate(type(1.)) == 'type'
	assert candidate(False) == 'bool'
	assert candidate(None) == "NoneType"
	assert candidate({'foo': 'bar'}) == 'dict'
	assert candidate(list([])) == 'list'
	assert candidate([]) == 'list'
	assert candidate(dict()) == 'dict'
	assert candidate(tuple()) == "tuple"
	assert candidate([1,2]) == 'list'
	assert candidate(set) == 'type'
	assert candidate(str) == 'type'
	assert candidate(object()) == "object"
	assert candidate(type(object)) == 'type'
	assert candidate(int('1', 2)) == 'int'
	assert candidate('a') =='str'
	assert candidate(int(1)) == 'int'
	assert candidate(3) == 'int'
	assert candidate(type('a')) == 'type'
	assert candidate(type(1)) == 'type'
	assert candidate(1.0+0j) == 'complex'
	assert candidate(int()) == "int"
	assert candidate(type(None)) == 'type'
	assert candidate('foo') =='str'
	assert candidate(object()) == 'object'
	assert candidate(1.1) == "float"
	assert candidate(str.lower('a')) =='str'
	assert candidate(int('1', 0)) == 'int'
	assert candidate(str()) == "str"
	assert candidate(complex(1, 2)) == 'complex'
	assert candidate(None) == 'NoneType'
def test_check():
	check(class_as_string)
