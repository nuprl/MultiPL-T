def get_column_map(table_schema):
    """ 
     Return a map from column name to a tuple
     where the first element is the index and second is the spec
     """
	### Canonical solution below ###    
    column_map = {}
    for ind, col in enumerate(table_schema["columns"]):
        if "name" in col:
            column_map[col["name"]] = (ind, col)
    return column_map

### Unit tests below ###
def check(candidate):
	assert candidate(
    {"columns": [{"name": "a"}, {"name": "b"}, {"name": "c"}]}
) == {"a": (0, {"name": "a"}), "b": (1, {"name": "b"}), "c": (2, {"name": "c"})}
	assert candidate(
    { "columns": [{"name":"a"}, {"name":"b"}]}) == { "a":(0, {"name":"a"}), "b":(1, {"name":"b"}) }
	assert candidate(
    { "columns": [{"name":"a"}, {"name":"b"}, {"name":"c"}]}) == { "a":(0, {"name":"a"}), "b":(1, {"name":"b"}), "c":(2, {"name":"c"}) }
	assert candidate(
    { "columns": [] }) == {}
	assert candidate(
    {
        "columns": [
            {"name": "col1", "type": "int32"},
            {"name": "col2", "type": "int64"},
            {"name": "col3", "type": "string"}
        ]
    }
) == {
    "col1": (0, {"name": "col1", "type": "int32"}),
    "col2": (1, {"name": "col2", "type": "int64"}),
    "col3": (2, {"name": "col3", "type": "string"})
}
	assert candidate(
    {"columns": [{"type": "int"}, {"name": "bar", "type": "str"}]}
) == {"bar": (1, {"name": "bar", "type": "str"})}
	assert candidate({"columns": [{"type": "int"}, {}]}) == {}
	assert candidate({"columns": [{"name": "foo"}, {}]}) == {"foo": (0, {"name": "foo"})}
	assert candidate(
    { "columns": [
        {"name": "col1"},
        {"name": "col2"},
        {"name": "col3"}
        ]
    }
) == {
    "col1": (0, {"name": "col1"}),
    "col2": (1, {"name": "col2"}),
    "col3": (2, {"name": "col3"}),
    }
	assert candidate({"columns": [{}]}) == {}
	assert candidate(
    {"columns": [{"name": "a", "foo": "bar"}, {"name": "b"}, {"name": "c"}]}
) == {
    "a": (0, {"name": "a", "foo": "bar"}),
    "b": (1, {"name": "b"}),
    "c": (2, {"name": "c"}),
}
	assert candidate({"columns": []}) == {}
	assert candidate({"columns": [{"name": "A"}]}) == {"A": (0, {"name": "A"})}
	assert candidate(
    {"columns": [{"name": "a"}, {"name": "b"}, {"name": "c"}], "column_names": ["a", "b", "c"]}
) == {"a": (0, {"name": "a"}), "b": (1, {"name": "b"}), "c": (2, {"name": "c"})}
	assert candidate({"columns": [{"name": "A"}, {"name": "B"}]}) == {"A": (0, {"name": "A"}), "B": (1, {"name": "B"})}
	assert candidate(
    {"columns": [{"name": "a"}, {"name": "b"}, {"name": "c"}, {"name": "d"}]}
) == {
    "a": (0, {"name": "a"}),
    "b": (1, {"name": "b"}),
    "c": (2, {"name": "c"}),
    "d": (3, {"name": "d"}),
}
	assert candidate(
    {"columns": [{"name": "a"}, {"name": "b"}, {"name": "c"}]}
) == {
    "a": (0, {"name": "a"}),
    "b": (1, {"name": "b"}),
    "c": (2, {"name": "c"}),
}
	assert candidate(
    {
        "columns": [{"name": "a"}, {"name": "b"}, {"name": "c"}]
    }
) == {"a": (0, {"name": "a"}), "b": (1, {"name": "b"}), "c": (2, {"name": "c"})}
	assert candidate(
    {"columns": [{"name": "col1"}, {"name": "col2"}]}
) == {"col1": (0, {"name": "col1"}), "col2": (1, {"name": "col2"})}
	assert candidate(
    {"columns": [{"name": "foo", "type": "int"}, {"name": "bar", "type": "str"}]}
) == {
    "foo": (0, {"name": "foo", "type": "int"}),
    "bar": (1, {"name": "bar", "type": "str"}),
}
def test_check():
	check(get_column_map)
