def get_usr(msg: str) -> str:
    """ 
     Gets user from message string
     """
	### Canonical solution below ###    

    end = msg.find('!')
    return msg[1:end]

### Unit tests below ###
def check(candidate):
	assert candidate(r'@user!') == 'user'
	assert candidate(
    'PRIVMSG #example :!help')!= 'help'
	assert candidate(r'@user!@<EMAIL>') == 'user'
	assert candidate(
    ':user2!<EMAIL> PRIVMSG #channel :hello') == 'user2'
	assert candidate(
    ':user!<EMAIL> PRIVMSG #channel :hello') == 'user'
	assert candidate(r'@user!<EMAIL>') == 'user'
def test_check():
	check(get_usr)
