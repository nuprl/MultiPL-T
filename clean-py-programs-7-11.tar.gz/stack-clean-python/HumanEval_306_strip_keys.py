def strip_keys(src_dict, keys_to_strip):
    """ Removes certain keys from a dict """
	### Canonical solution below ###    
    return {key: value for key, value in src_dict.items() if key not in keys_to_strip}

### Unit tests below ###
def check(candidate):
	assert candidate(src_dict=dict(a=1, b=2, c=3), keys_to_strip=('d', 'e')) == dict(a=1, b=2, c=3)
	assert candidate(dict(a=1, b=2), ["a"]) == dict(b=2)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    ['a']
) == {'b': 2, 'c': 3}
	assert candidate(
    {'a': 'A', 'b': 'B', 'c': 'C'},
    ['a', 'c']
) == {'b': 'B'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a', 'b'}
) == {'c': 3}
	assert candidate(dict(a=1, b=2, c=3), ['a', 'c']) == dict(b=2)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    ['b']
) == {'a': 1, 'c': 3}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'b'}
) == {'a': 1, 'c': 3}
	assert candidate(
    {
        "name": "John",
        "age": 25,
        "phone": 1234567890,
        "address": {
            "street": "123 Any Street",
            "city": "New York",
            "state": "NY",
            "zip": 12345,
        },
    },
    ["phone", "address"],
) == {"name": "John", "age": 25}
	assert candidate(dict(a=1, b=2), ['b']) == dict(a=1)
	assert candidate(src_dict=dict(a=1, b=2, c=3), keys_to_strip=('a', 'b')) == dict(c=3)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    ['a', 'c']) == {'b': 2}
	assert candidate(dict(a=1, b=2, c=3), ['a', 'b']) == dict(c=3)
	assert candidate(dict(a=1, b=2), ['c', 'd']) == dict(a=1, b=2)
	assert candidate(dict(a=1, b=2), ['b', 'a']) == dict()
	assert candidate(dict(a=1, b=2, c=3), []) == dict(a=1, b=2, c=3)
	assert candidate(src_dict=dict(a=1, b=2), keys_to_strip=['b']) == dict(a=1)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    ['d']) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(a=1, b=2, c=3), ['b']) == dict(a=1, c=3)
	assert candidate(src_dict=dict(a=1, b=2, c=3), keys_to_strip=['a']) == dict(b=2, c=3)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'d'}
) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(a=1, b=2, c=3), ["a", "c"]) == dict(b=2)
	assert candidate(dict(a=1, b=2, c=3), ["d"]) == dict(a=1, b=2, c=3)
	assert candidate(
    {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4
    },
    ['b', 'd']
) == {
    'a': 1,
    'c': 3
}
	assert candidate(
    {'name': 'Jane', 'age': 25, 'occupation': 'programmer'},
    {'occupation'}
) == {'name': 'Jane', 'age': 25}
	assert candidate(src_dict=dict(a=1, b=2, c=3), keys_to_strip=['a', 'b', 'c']) == dict()
	assert candidate(dict(a=1, b=2), ["a", "b"]) == dict()
	assert candidate(
    {'name': 'Jane', 'age': 25, 'occupation': 'programmer'},
    {'occupation', 'age'}
) == {'name': 'Jane'}
	assert candidate(dict(a=1, b=2), []) == dict(a=1, b=2)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    ['a', 'c']
) == {'b': 2}
	assert candidate(src_dict=dict(a=1, b=2, c=3), keys_to_strip=['a', 'b']) == dict(c=3)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}, ['a', 'c']) == {'b': 2}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a', 'b', 'c'}
) == {}
	assert candidate(
    {
        "id": "1",
        "name": "John",
        "age": 30,
        "address": {
            "street": "123 Main St",
            "city": "Anytown",
            "state": "CA",
            "zip": 12345,
        },
    },
    ["id", "name", "address", "address.zip"],
) == {
    "age": 30,
}
	assert candidate(dict(a=1, b=2), ['a']) == dict(b=2)
	assert candidate(dict(foo=1, bar=2), ['bar']) == dict(foo=1)
	assert candidate(dict(a=1, b=2, c=3), ["a", "b"]) == dict(c=3)
	assert candidate(dict(a=1, b=2), ['c']) == dict(a=1, b=2)
	assert candidate(src_dict=dict(a=1, b=2), keys_to_strip=['a', 'b']) == dict()
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    ['a', 'b']
) == {'c': 3}
	assert candidate(dict(a=1, b=2), ['a', 'b']) == dict()
def test_check():
	check(strip_keys)
