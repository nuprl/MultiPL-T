def translate_wiredict(wd, amount, axis, inplace=False):
    """ 
     Translates a dictionary wd with points
     xw1, yw1, zw1 and xw2, yw2, zw2 
     a distance 'amount' along the specified axis 'x', 'y', or 'z'
     """
	### Canonical solution below ###    
    if not inplace:
        wd = wd.copy()

    if axis == 'x':
        wd['xw1'] += amount
        wd['xw2'] += amount
    elif axis == 'y':
        wd['yw1'] += amount
        wd['yw2'] += amount
    elif axis == 'z':
        wd['zw1'] += amount
        wd['zw2'] += amount

    return wd

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'xw1': 0.0, 'yw1': 0.0, 'zw1': 0.0, 'xw2': 1.0, 'yw2': 0.0, 'zw2': 0.0},
    1.0, 'x') == {'xw1': 1.0, 'yw1': 0.0, 'zw1': 0.0, 'xw2': 2.0, 'yw2': 0.0, 'zw2': 0.0}
	assert candidate(dict(xw1=0, yw1=0, zw1=0, xw2=10, yw2=10, zw2=10), 10, 'x')['xw1'] == 10
	assert candidate(dict(xw1=1, yw1=1, zw1=1, xw2=1, yw2=1, zw2=1), 100, 'z')['zw1'] == 101
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'x') == \
    {'xw1': 11, 'yw1': 2, 'zw1': 3, 'xw2': 14, 'yw2': 5, 'zw2': 6}
	assert candidate(
    {'xw1': 1, 'yw1': 1, 'zw1': 1, 'xw2': 2, 'yw2': 2, 'zw2': 2}, 1, 'z', True) == {
    'xw1': 1, 'yw1': 1, 'zw1': 2, 'xw2': 2, 'yw2': 2, 'zw2': 3}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 1, 'zw2': 1},
    2, 'z'
) == {'xw1': 0, 'yw1': 0, 'zw1': 2, 'xw2': 1, 'yw2': 1, 'zw2': 3}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 0, 'zw2': 0}, 1, 'x'
    ) == {'xw1': 1, 'yw1': 0, 'zw1': 0, 'xw2': 2, 'yw2': 0, 'zw2': 0}
	assert candidate(dict(xw1=1, yw1=1, zw1=1, xw2=1, yw2=1, zw2=1), 100, 'y', inplace=True)['yw1'] == 101
	assert candidate(dict(xw1=0, yw1=0, zw1=0, xw2=10, yw2=10, zw2=10), 10, 'y')['yw1'] == 10
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'z') == {
        'xw1': 1, 'yw1': 2, 'zw1': 13, 'xw2': 4, 'yw2': 5, 'zw2': 16}
	assert candidate(
    {'xw1': 1, 'yw1': 1, 'zw1': 1, 'xw2': 2, 'yw2': 2, 'zw2': 2}, 1, 'z') == {
    'xw1': 1, 'yw1': 1, 'zw1': 2, 'xw2': 2, 'yw2': 2, 'zw2': 3}
	assert candidate(dict(xw1=0, yw1=0, zw1=0, xw2=10, yw2=10, zw2=10), 10, 'z')['zw2'] == 20
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 1, 'x') == \
    {'xw1': 2, 'yw1': 2, 'zw1': 3, 'xw2': 5, 'yw2': 5, 'zw2': 6}
	assert candidate(dict(xw1=0, yw1=0, zw1=0, xw2=10, yw2=10, zw2=10), 10, 'y')['yw2'] == 20
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'x') == {
        'xw1': 11, 'yw1': 2, 'zw1': 3, 'xw2': 14, 'yw2': 5, 'zw2': 6}
	assert candidate(dict(xw1=1, yw1=1, zw1=1, xw2=1, yw2=1, zw2=1), 100, 'x')['xw1'] == 101
	assert candidate(dict(xw1=1, yw1=1, zw1=1, xw2=1, yw2=1, zw2=1), 100, 'z', inplace=True)['zw1'] == 101
	assert candidate(
    {'xw1': 1.0, 'yw1': 2.0, 'zw1': 3.0, 'xw2': 4.0, 'yw2': 5.0, 'zw2': 6.0},
    100.0, 'x') == {'xw1': 101.0, 'yw1': 2.0, 'zw1': 3.0, 'xw2': 104.0, 'yw2': 5.0, 'zw2': 6.0}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 1, 'zw2': 1}, 1, 'z') == {'xw1': 0, 'yw1': 0, 'zw1': 1, 'xw2': 1, 'yw2': 1, 'zw2': 2}
	assert candidate(
    {
        'xw1': 0,
        'yw1': 0,
        'zw1': 0,
        'xw2': 1,
        'yw2': 1,
        'zw2': 1
    },
    1,
    'z',
    inplace=False
) == {
    'xw1': 0,
    'yw1': 0,
    'zw1': 1,
    'xw2': 1,
    'yw2': 1,
    'zw2': 2
}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 1, 'zw2': 1}, 1, 'x') == {'xw1': 1, 'yw1': 0, 'zw1': 0, 'xw2': 2, 'yw2': 1, 'zw2': 1}
	assert candidate(
    {'xw1': 1, 'yw1': 1, 'zw1': 1, 'xw2': 2, 'yw2': 2, 'zw2': 2}, 1, 'y') == {
    'xw1': 1, 'yw1': 2, 'zw1': 1, 'xw2': 2, 'yw2': 3, 'zw2': 2}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 1, 'zw2': 1}, 1, 'y') == {'xw1': 0, 'yw1': 1, 'zw1': 0, 'xw2': 1, 'yw2': 2, 'zw2': 1}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 1, 'zw2': 1},
    2, 'x'
) == {'xw1': 2, 'yw1': 0, 'zw1': 0, 'xw2': 3, 'yw2': 1, 'zw2': 1}
	assert candidate(dict(xw1=1, yw1=2, zw1=3, xw2=10, yw2=20, zw2=30), 100, 'x') == {'xw1': 101, 'yw1': 2, 'zw1': 3, 'xw2': 110, 'yw2': 20, 'zw2': 30}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 0, 'zw2': 0}, -1, 'x'
    ) == {'xw1': -1, 'yw1': 0, 'zw1': 0, 'xw2': 0, 'yw2': 0, 'zw2': 0}
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'z') == \
    {'xw1': 1, 'yw1': 2, 'zw1': 13, 'xw2': 4, 'yw2': 5, 'zw2': 16}
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'y') == {'xw1': 1, 'yw1': 12, 'zw1': 3, 'xw2': 4, 'yw2': 15, 'zw2': 6}
	assert candidate(dict(xw1=1, yw1=2, zw1=3, xw2=4, yw2=5, zw2=6), 10, 'z') == dict(xw1=1, yw1=2, zw1=13, xw2=4, yw2=5, zw2=16)
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'x') == {'xw1': 11, 'yw1': 2, 'zw1': 3, 'xw2': 14, 'yw2': 5, 'zw2': 6}
	assert candidate(dict(xw1=1, yw1=1, zw1=1, xw2=1, yw2=1, zw2=1), 100, 'y')['yw1'] == 101
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'y') == \
    {'xw1': 1, 'yw1': 12, 'zw1': 3, 'xw2': 4, 'yw2': 15, 'zw2': 6}
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 1, 'y') == \
    {'xw1': 1, 'yw1': 3, 'zw1': 3, 'xw2': 4, 'yw2': 6, 'zw2': 6}
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'z') == {'xw1': 1, 'yw1': 2, 'zw1': 13, 'xw2': 4, 'yw2': 5, 'zw2': 16}
	assert candidate(dict(xw1=1, yw1=1, zw1=1, xw2=1, yw2=1, zw2=1), 100, 'x', inplace=True)['xw1'] == 101
	assert candidate(dict(xw1=0, yw1=0, zw1=0, xw2=10, yw2=10, zw2=10), 10, 'z')['zw1'] == 10
	assert candidate(dict(xw1=0, yw1=0, zw1=0, xw2=10, yw2=10, zw2=10), 10, 'x')['xw2'] == 20
	assert candidate(
    {
        'xw1': 0,
        'yw1': 0,
        'zw1': 0,
        'xw2': 1,
        'yw2': 1,
        'zw2': 1
    },
    1,
    'y',
    inplace=False
) == {
    'xw1': 0,
    'yw1': 1,
    'zw1': 0,
    'xw2': 1,
    'yw2': 2,
    'zw2': 1
}
	assert candidate(
    {'xw1': 0, 'yw1': 0, 'zw1': 0, 'xw2': 1, 'yw2': 1, 'zw2': 1},
    2, 'y'
) == {'xw1': 0, 'yw1': 2, 'zw1': 0, 'xw2': 1, 'yw2': 3, 'zw2': 1}
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 1, 'z') == \
    {'xw1': 1, 'yw1': 2, 'zw1': 4, 'xw2': 4, 'yw2': 5, 'zw2': 7}
	assert candidate(
    {'xw1': 1, 'yw1': 1, 'zw1': 1, 'xw2': 2, 'yw2': 2, 'zw2': 2}, 1, 'x') == {
    'xw1': 2, 'yw1': 1, 'zw1': 1, 'xw2': 3, 'yw2': 2, 'zw2': 2}
	assert candidate(
    {
        'xw1': 0,
        'yw1': 0,
        'zw1': 0,
        'xw2': 1,
        'yw2': 1,
        'zw2': 1
    },
    1,
    'x',
    inplace=False
) == {
    'xw1': 1,
    'yw1': 0,
    'zw1': 0,
    'xw2': 2,
    'yw2': 1,
    'zw2': 1
}
	assert candidate(
    {'xw1':0,'yw1':0,'zw1':0,'xw2':1,'yw2':0,'zw2':0}, 1, 'x') == \
    {'xw1':1,'yw1':0,'zw1':0,'xw2':2,'yw2':0,'zw2':0}
	assert candidate(
    {'xw1': 1, 'yw1': 2, 'zw1': 3, 'xw2': 4, 'yw2': 5, 'zw2': 6}, 10, 'y') == {
        'xw1': 1, 'yw1': 12, 'zw1': 3, 'xw2': 4, 'yw2': 15, 'zw2': 6}
def test_check():
	check(translate_wiredict)
