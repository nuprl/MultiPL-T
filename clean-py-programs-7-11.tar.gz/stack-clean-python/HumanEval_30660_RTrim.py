def RTrim(text):
    """Strip spaces from the right of the text"""
    ### Canonical solution below ###
    return str(text).rstrip()


### Unit tests below ###
def check(candidate):
	assert candidate(" \t abc\r\n") == " \t abc"
	assert candidate(" 1 ") == " 1", "candidate(' 1 ') does not work"
	assert candidate('1') == '1'
	assert candidate("  a  ") == "  a"
	assert candidate('Hello World!') == 'Hello World!'
	assert candidate("  ") == ""
	assert candidate("  abc") == "  abc"
	assert candidate("\tabc\r\n") == "\tabc"
	assert candidate("abc\r") == "abc"
	assert candidate(' 1  ')
	assert candidate('Hello') == 'Hello'
	assert candidate("a") == "a", "candidate('a') does not return 'a'"
	assert candidate(100) == "100"
	assert candidate('') == ''
	assert candidate(' ') == '', 'Space is not None'
	assert candidate('abc\t\t ') == 'abc', 'candidate("abc\t\t ") == "abc"'
	assert candidate("  abc  ") == "  abc"
	assert candidate('     ') == ''
	assert candidate('test  ') == 'test'
	assert candidate(" 1234 ") == " 1234"
	assert candidate("abc\r\n") == "abc"
	assert candidate("foo") == "foo"
	assert candidate("  Test  ") == "  Test"
	assert candidate("  a") == "  a"
	assert candidate("123456 ") == "123456", "candidate('123456 ') does not work"
	assert candidate(3.14) == "3.14"
	assert candidate('a') == 'a'
	assert candidate(' ') == '', 'candidate(" ") == ""'
	assert candidate("   hello   world   ") == "   hello   world"
	assert candidate("    ") == ""
	assert candidate("123456") == "123456", "candidate('123456') does not work"
	assert candidate("  a  ") == "  a", "candidate('  a  ') does not return' a'"
	assert candidate('abc\t ') == 'abc', 'candidate("abc\t ") == "abc"'
	assert candidate("") == "", "candidate('') does not return ''"
	assert candidate(" \t abc\r") == " \t abc"
	assert candidate('test   ') == 'test'
	assert candidate("   hello   ") == "   hello"
	assert candidate("  Hello, World!  ") == "  Hello, World!", "candidate('  Hello, World!  ')"
	assert candidate("foo  ") == "foo"
	assert candidate("a  ") == "a"
	assert candidate('  ') == '', 'Two spaces is not None'
	assert candidate(" \tabc\r") == " \tabc"
	assert candidate("hello  ") == "hello"
	assert candidate('') == '', 'candidate("") == ""'
	assert candidate(" abc\r\n") == " abc"
	assert candidate("  test  ") == "  test"
	assert candidate("  Hello World  ") == "  Hello World"
	assert candidate("  foo") == "  foo"
	assert candidate(" 1  ") == " 1", "candidate(' 1  ') does not work"
	assert candidate("   ") == ""
	assert candidate('   ') == ''
	assert candidate("abc ") == "abc"
	assert candidate('Hello ') == 'Hello'
	assert candidate("a b  ") == "a b"
	assert candidate("Hello, World!") == "Hello, World!", "candidate('Hello, World!')"
	assert candidate("abc") == "abc"
	assert candidate(1) == "1", "candidate(1) does not work"
	assert candidate(" 3.14 ") == " 3.14"
	assert candidate(" abc") == " abc"
	assert candidate("\t abc\r") == "\t abc"
	assert candidate("     ") == ""
	assert candidate("  hello  ") == "  hello"
	assert candidate("abc\v") == "abc"
	assert candidate("  a b  c  ") == "  a b  c"
	assert candidate('abc') == 'abc'
	assert candidate(" ") == ""
	assert candidate("  hello") == "  hello"
	assert candidate(" 1234 ") == " 1234", "candidate(' 1234 ') does not work"
	assert candidate('Hello World! ') == 'Hello World!'
	assert candidate(" 1") == " 1", "candidate(' 1') does not work"
	assert candidate('   ') == '', 'Three spaces is not None'
	assert candidate("\t abc\r\n") == "\t abc"
	assert candidate('  ') == '', 'candidate("  ") == ""'
	assert candidate("\t abc\n") == "\t abc"
	assert candidate("  foo  ") == "  foo"
	assert candidate("  a b c ") == "  a b c"
	assert candidate("1234 ") == "1234", "candidate('1234 ') does not work"
	assert candidate("  Test") == "  Test"
	assert candidate("abc\n") == "abc"
	assert candidate('Hello, World! ') == 'Hello, World!'
	assert candidate("") == ""
	assert candidate(" abc\r") == " abc"
	assert candidate(" 123456") == " 123456", "candidate(' 123456') does not work"
	assert candidate('1 ') == '1'
	assert candidate('abc\t') == 'abc', 'candidate("abc\t") == "abc"'
	assert candidate(" abc\n") == " abc"
	assert candidate("1234") == "1234", "candidate('1234') does not work"
	assert candidate("Test  ") == "Test"
	assert candidate("abc  ") == "abc"
	assert candidate("  abc ") == "  abc"
	assert candidate("abc\t") == "abc"
	assert candidate("  a b  ") == "  a b"
	assert candidate("1 ") == "1", "candidate('1 ') does not work"
	assert candidate('test') == 'test'
	assert candidate("\t\tHello, World!\t\t") == "\t\tHello, World!", "candidate('\t\tHello, World!\t\t')"
	assert candidate(" a ") == " a", "candidate(' a ') does not return'a'"
	assert candidate("Hello World") == "Hello World"
	assert candidate("Test") == "Test"
	assert candidate("  a b c") == "  a b c"
	assert candidate(" 3.14") == " 3.14"
	assert candidate('  ') == ''
	assert candidate("abc\f") == "abc"
	assert candidate("hello   ") == "hello"
	assert candidate(1) == '1'
	assert candidate(" \tabc\n") == " \tabc"
	assert candidate("1  ") == "1", "candidate('1  ') does not work"
	assert candidate("   hello") == "   hello"
	assert candidate('abc ') == 'abc', 'candidate("abc ") == "abc"'
	assert candidate(candidate.__class__) == "<class 'function'>"
	assert candidate('test ') == 'test'
	assert candidate(3) == "3"
	assert candidate("\tabc\r") == "\tabc"
	assert candidate(" a") == " a", "candidate(' a') does not return'a'"
	assert candidate('abc') == 'abc', 'candidate("abc") == "abc"'
	assert candidate(' ') == ''
	assert candidate('Hello, World!') == 'Hello, World!'
	assert candidate('abc\t\t') == 'abc', 'candidate("abc\t\t") == "abc"'
	assert candidate("hello") == "hello"
	assert candidate(" \tabc\r\n") == " \tabc"
	assert candidate(" abc ") == " abc"
	assert candidate("\tabc\n") == "\tabc"
	assert candidate(" 1234") == " 1234", "candidate(' 1234') does not work"
	assert candidate("abc\n\r\t\f\v") == "abc"
	assert candidate(" 1234  ") == " 1234"
def test_check():
	check(RTrim)
