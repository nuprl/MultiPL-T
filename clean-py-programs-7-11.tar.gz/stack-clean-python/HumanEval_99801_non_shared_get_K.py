def non_shared_get_K(Kp: int, C: int, num_params: int) -> int:
    """ Inverse of non_shared_get_Kp, get back K=number of mixtures """
    ### Canonical solution below ###
    return Kp // (num_params * C)


### Unit tests below ###
def check(candidate):
	assert candidate(8, 3, 1) == 2
	assert candidate(100, 10, 1) == 10
	assert candidate(8, 2, 2) == 2
	assert candidate(8, 10, 40) == 0
	assert candidate(8, 10, 50) == 0
	assert candidate(16, 2, 6) == 1
	assert candidate(16, 2, 8) == 1
	assert candidate(8, 2, 3) == 1
	assert candidate(8, 10, 30) == 0
	assert candidate(1000, 1, 2) == 500
	assert candidate(8, 10, 60) == 0
	assert candidate(16, 4, 1) == 4
	assert candidate(100, 3, 2) == 100 // (2 * 3)
	assert candidate(8, 10, 90) == 0
	assert candidate(10, 2, 2) == 2
	assert candidate(8, 1, 1) == 8
	assert candidate(8, 10, 80) == 0
	assert candidate(16, 4, 2) == 2
	assert candidate(10, 2, 1) == 5
	assert candidate(8, 10, 20) == 0
	assert candidate(8, 10, 70) == 0
	assert candidate(8, 10, 100) == 0
	assert candidate(8, 1, 3) == 2
	assert candidate(16, 4, 4) == 1
	assert candidate(1000, 3, 2) == 166
	assert candidate(10, 1, 1) == 10
	assert candidate(8, 2, 1) == 4
	assert candidate(8, 1, 2) == 4
	assert candidate(8, 3, 2) == 1
	assert candidate(16, 2, 3) == 2
	assert candidate(100, 10, 10) == 1
	assert candidate(100, 3, 1) == 100 // 3
	assert candidate(16, 2, 4) == 2
	assert candidate(200, 4, 10) == 5
	assert candidate(16, 2, 7) == 1
	assert candidate(100, 4, 10) == 2
	assert candidate(1000, 2, 2) == 250
	assert candidate(32, 2, 2) == 8
	assert candidate(10, 3, 5) == 0
def test_check():
	check(non_shared_get_K)
