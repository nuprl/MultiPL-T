def squared_loss(x1: float, x2: float):
    """Returns the squared difference between two numbers"""
    ### Canonical solution below ###
    return (x1 - x2) ** 2


### Unit tests below ###
def check(candidate):
	assert candidate(10, 5) == 25
	assert candidate(4, 4) == 0
	assert candidate(2, 3) == 1
	assert candidate(1, 4) == 9
	assert candidate(3, 5) == 4
	assert candidate(2.5, 2.5) == 0
	assert candidate(4, 3) == 1
	assert candidate(2, 2) == 0
	assert candidate(0, 5) == 25
	assert candidate(3, 2) == 1
	assert candidate(4, 1) == 9
	assert candidate(100, 100) == 0
	assert candidate(1, 2) == 1
	assert candidate(1, 1) == 0
	assert candidate(1, 0) == 1
	assert candidate(1.0, 1.0) == 0.0
	assert candidate(10, 12) == 4
	assert candidate(2, 1) == 1
	assert candidate(3, 3) == 0
	assert candidate(12, 12) == 0
	assert candidate(0, 0) == 0
	assert candidate(3, 4) == 1
def test_check():
	check(squared_loss)
