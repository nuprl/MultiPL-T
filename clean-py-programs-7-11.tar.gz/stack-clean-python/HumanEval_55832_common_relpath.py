def common_relpath(path_a, path_b):
    """ Returns common end-path for two identical
     filepaths with different root-directories.
     
     Args:
     path_a (str): ``(ex: '/path/src/neat/file.txt')``
     path_b (str): ``(ex: '/another/path/dst/neat/file.txt')``
     
     Returns:
     str: ``'neat/file.txt'``
     """
	### Canonical solution below ###    
    path_a = path_a.replace('\\', '/')
    path_b = path_b.replace('\\', '/')

    # nothing to do. same file.
    if path_a == path_b:
        return

    # get relpath
    relpath = ''
    for i in range(len(path_a)):
        index = (i * -1) - 1  # value should never be zero
        if path_a[index] != path_b[index]:
            break
        relpath = path_a[index] + relpath

    while relpath.startswith('/'):
        relpath = relpath[1:]

    return relpath

### Unit tests below ###
def check(candidate):
	assert candidate(
    '/path/src/neat/file.txt', '/another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt',
    '/another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt',
    '/path/src/neat/file.txt.bk'
) == ''
	assert candidate(r'/path/src/neat/file.txt',
                      r'/another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt',
    'another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(r'C:\path\src\neat\file.txt', r'D:\another\path\dst\neat\file.txt') == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt',
    '/another/path/dst/') == ''
	assert candidate(r'C:/path/src/neat/file.txt', r'C:/another/path/dst/neat/file.txt') == r'neat/file.txt'
	assert candidate(r'C:/src/neat/file.txt', r'C:/another/path/dst/neat/file.txt') == r'neat/file.txt'
	assert candidate(
    'path/src/neat/file.txt',
    'another/path/dst/neat/file.txt'
) == 'neat/file.txt'
	assert candidate(r'C:/src/neat/file.txt', r'C:/src/neat/') == r''
	assert candidate(
    'C:\\path\\src\\neat\\file.txt', 'C:\\another\\path\\dst\\neat\\file.txt'
) == 'neat/file.txt'
	assert candidate(
    'path/src/neat/file.txt',
    '/another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(
    'C:\\path\\src\\neat\\file.txt',
    'C:\\'
) == ''
	assert candidate(
    '/home/MyUser/Documents/src/neat/file.txt',
    '/home/MyUser/Documents/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(r'C:/path/src/neat/file.txt',
                      r'C:/another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(r'/path/src/neat/file.txt', r'/another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(
    'C:\\path\\src\\neat\\file.txt',
    'D:\\another\\path\\dst\\neat\\file.txt')
	assert candidate(r'C:/path/src/neat/file.txt',
                      r'C:') == ''
	assert candidate(
    'C:\\path\\src\\neat\\file.txt',
    'C:\\another\\path\\dst\\neat\\file.txt'
) == 'neat/file.txt'
	assert candidate(
    'C:\\path\\src\\neat\\file.txt',
    'C:\\another\\path\\dst\\neat\\file.txt') == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt', '/another/path/dst/neat/file.txt'
) == 'neat/file.txt'
	assert candidate(r'/path/src/neat/file.txt', r'/another/path/dst/neat/file.txt') == r'neat/file.txt'
	assert candidate(
    'path/src/neat/file.txt',
    'another/path/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt',
    '/another/path/dst/neat/file.txt'
) == candidate(
    '/another/path/dst/neat/file.txt',
    '/path/src/neat/file.txt'
)
	assert candidate(r'C:\path\src\neat\file.txt', r'C:\another\path\dst\neat\file.txt') == 'neat/file.txt'
	assert candidate(r'C:/path/src/neat/file.txt',
                      r'C:/') == ''
	assert candidate(
    'C:/Users/MyUser/Documents/src/neat/file.txt',
    'C:/Users/MyUser/Documents/dst/neat/file.txt') == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt',
    '/path/src/neat/file.json'
) == ''
	assert candidate(
    'C:/path/src/neat/file.txt',
    'C:/another/path/dst/neat/file.txt'
) == 'neat/file.txt'
	assert candidate(
    '/path/src/neat/file.txt',
    '/another/path/dst/neat/file.txt'
) == candidate(
    '/path/src/neat/file.txt',
    '/another/path/dst/neat/file.txt'
)
	assert candidate(
    '/path/src/neat/file.txt',
    '/another/path/dst/neat/file.txt'
) == 'neat/file.txt'
	assert candidate(
    'path/src/neat/file.txt',
    'path/src/file.txt'
)
def test_check():
	check(common_relpath)
