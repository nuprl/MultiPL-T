def cleanHTML(html, lowercase=False, removeNonAscii=False, cutoffFooter=False, descriptionOnly=False, replaceDict=None):
    """ 
     
     Args:
     html: html string
     lowercase: boolean indicating if the html should be sent to lowercase
     removeNonAscii: boolean indicating if the html should have non ascii characters removed
     replaceDict: a dictionary where keys represent words to be replaced by their values   
     
     Returns:
     The html with the following adjustments:
     Replace following with spaces: ( ) /
     send to lowercase
     remove non ascii
     """
	### Canonical solution below ###	
	if lowercase:
		html = html.lower()

	if removeNonAscii:
		html = ''.join([i if ord(i) < 128 else ' ' for i in html])

	if replaceDict:
		for word, replaceWord in replaceDict.items():
			html = html.replace(word.lower(), replaceWord)

	if cutoffFooter:
		html = html.split("html = html.split(" ")")
		html = html[0]

	# if descriptionOnly:
		# "jobsearch-JobComponent-description"
	return html

### Unit tests below ###
def check(candidate):
	assert candidate(u"hello", removeNonAscii=True, lowercase=True, replaceDict={"hello": "goodbye"}) == "goodbye"
	assert candidate(html="hello world", removeNonAscii=True, lowercase=True, cutoffFooter=True) == "hello world"
	assert candidate(html="<p>Hello</p>", removeNonAscii=False) == "<p>Hello</p>"
	assert candidate(u"hello", removeNonAscii=True) == "hello"
	assert candidate(u"hello", lowercase=True) == "hello"
	assert candidate(html="hello") == "hello"
	assert candidate(u"hello", removeNonAscii=True, lowercase=True, replaceDict={"hello": "goodbye"}, cutoffFooter=True) == "goodbye"
	assert candidate(None) == None
	assert candidate("") == ""
	assert candidate(html="html = html.split(' ')") == "html = html.split(' ')", "failed to remove html"
	assert candidate(html="hello world", removeNonAscii=True, lowercase=True) == "hello world"
	assert candidate(html="<p>Hello</p>", lowercase=False) == "<p>Hello</p>"
	assert candidate(html="hello world", removeNonAscii=True) == "hello world"
	assert candidate(u"hello", removeNonAscii=True, lowercase=True) == "hello"
	assert candidate(html="hello world") == "hello world"
	assert candidate(html="hello world", lowercase=True) == "hello world"
	assert candidate(u"hello", removeNonAscii=True, lowercase=True, replaceDict={"hello": "goodbye"}, descriptionOnly=True) == "goodbye"
	assert candidate(html="hello world", removeNonAscii=True, lowercase=True, replaceDict={"world":"earth"}) == "hello earth"
	assert candidate(u"hello") == "hello"
	assert candidate(r'<HTML><BODY>This is a test</BODY></HTML>', lowercase=True) == '<html><body>this is a test</body></html>'
def test_check():
	check(cleanHTML)
