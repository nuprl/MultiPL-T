def search(text, pattern):
    """ 
     Takes a string and searches if the `pattern` is substring within `text`.
     
     :param text: A string that will be searched.
     :param pattern: A string that will be searched as a substring within
     `text`.
     :rtype: The indices of all occurences of where the substring `pattern`
     was found in `text`.
     """
	### Canonical solution below ###    

    pattern_length = len(pattern)
    text_length = len(text)
    offsets = []
    if pattern_length > text_length:
        return offsets
    bmbc = [pattern_length] * 256
    for index, char in enumerate(pattern[:-1]):
        bmbc[ord(char)] = pattern_length - index - 1
    bmbc = tuple(bmbc)
    search_index = pattern_length - 1
    while search_index < text_length:
        pattern_index = pattern_length - 1
        text_index = search_index
        while text_index >= 0 and \
                text[text_index] == pattern[pattern_index]:
            pattern_index -= 1
            text_index -= 1
        if pattern_index == -1:
            offsets.append(text_index + 1)
        search_index += bmbc[ord(text[search_index])]

    return offsets

### Unit tests below ###
def check(candidate):
	assert candidate(
    "abra cadabra", "abra") == [0, 8], "Simple candidate failed"
	assert candidate(
    'abra cadabra',
    'adab') == [6]
	assert candidate(
    'abra cadabra', 'z') == []
	assert candidate(
    "abra cadabra",
    "adab") == [6]
	assert candidate(
    "abra cadabra", "z") == []
	assert candidate(text='bananana', pattern='nan') == [2, 4]
	assert candidate(text='bananana', pattern='banana') == [0]
	assert candidate("abra cadabra", "z") == [], "Pattern not found"
	assert candidate(text="ABABDABACDABABCABAB", pattern="BABAB") == []
	assert candidate('ABCD', 'BCX') == []
	assert candidate('abc', 'abc') == [0]
	assert candidate('ABCD', 'BC') == [1]
	assert candidate(
    'abra cadabra',
    'abra') == [0, 8]
	assert candidate(text='banana', pattern='nan') == [2]
	assert candidate(
    "aaaaabaaa",
    "aaad"
) == []
	assert candidate('ABCD', 'A') == [0]
	assert candidate(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ") == [0]
	assert candidate('abc', 'z') == []
	assert candidate(text='mississippi', pattern='zzz') == []
	assert candidate(
    "aaaaabaaa",
    "aaaaabaaa"
) == [0]
	assert candidate('abc', 'abcd') == []
	assert candidate(
    'abra cadabra', 'abra cadabra') == [0], "All candidate failed"
	assert candidate('ABCD', 'XCD') == []
	assert candidate(text="ABABDABACDABABCABAB", pattern="ABBA") == []
	assert candidate(text="ABABDABACDABABCABAB", pattern="ABABDABACDABABCABAB") == [0]
	assert candidate(
    "aaaaabaaa",
    "aaaa"
) == [0]
	assert candidate(
    'abababab',
    'aba'
) == [0, 2, 4], 'Simple candidate'
	assert candidate('abc', 'bc') == [1]
	assert candidate(text='banana', pattern='ana') == [1, 3]
	assert candidate(
    "abra cadabra", "abra") == [0, 8]
	assert candidate(
    "abcdabcabcdabcdeabcdeabcdabcde",
    "abcdabcdeabcdabcdeabcdabcd") == []
	assert candidate('ABCD', 'AB') == [0]
	assert candidate(
    'abra cadabra', 'abra') == [0, 8]
	assert candidate(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "A") == [0]
	assert candidate(
    "abbabbaabbbbaaaaa",
    "bbaaba"
) == []
	assert candidate(
    "abcabcabcabcabc",
    "abcabcabcabcabc") == [0]
	assert candidate(text='mississippi', pattern='pi') == [9]
	assert candidate('ABABX', 'XABAB') == []
	assert candidate(text='mississippi', pattern='issi') == [1, 4]
	assert candidate(
    "abra cadabra",
    "abra") == [0, 8]
	assert candidate("aaaaa", "bba") == []
	assert candidate('ABCD', 'BCDX') == []
	assert candidate(
    "aaaaabaaa",
    "aaac"
) == []
	assert candidate(
    "abra", "abraa") == []
	assert candidate(
    "hello world", "llo") == [2]
	assert candidate("", "z") == [], "Empty string"
	assert candidate(
    'ABABDABACDABABCABAB', 'ABABX') == []
	assert candidate(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "AA") == []
	assert candidate(text='mississippi', pattern='ss') == [2, 5]
	assert candidate(
    'abra cadabra',
    'z') == []
	assert candidate(
    "abcabcabcabcabc",
    "abcabcabcabca") == [0]
	assert candidate("", "a") == []
	assert candidate(
    "", "abra") == []
	assert candidate(
    "A quick brown fox jumps over the lazy dog",
    "A quick brown fox jumps over the lazy dog"
) == [0]
	assert candidate(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "ABCDEFGHIJKLMNOPQRSTUVW") == [0]
	assert candidate("abra cadabra", "adab") == [6], "Failed to find 'adab'"
	assert candidate(
    'abra cadabra',
    'abra'
) == [0, 8]
	assert candidate(
    "abcdabcabcdabcdeabcdeabcdabcde",
    "abcdabcdeabcdabcdeabcd") == []
	assert candidate('ABCD', 'XABCD') == []
	assert candidate(
    "abcdabcabcdabcdeabcdeabcdabcde",
    "abcdabcdabcdeabcdabcd") == []
	assert candidate(
    "abra", "abra") == [0]
	assert candidate(
    "aaaaabaaa",
    "aaaaa"
) == [0]
	assert candidate('ABCD', 'CD') == [2]
	assert candidate(
    "abra cadabra", "adab") == [6]
	assert candidate('ABCD', 'X') == []
	assert candidate('', 'A') == []
	assert candidate(
    'abra cadabra', 'adab') == [6], "Multiple candidate failed"
	assert candidate(
    "abcabcabcabcabc",
    "abcabcabcabcab") == [0]
	assert candidate(
    "abra cadabra",
    "z") == []
	assert candidate(
    "aaaaabaaa",
    "b"
) == [5]
	assert candidate('ABCD', 'XBCD') == []
	assert candidate(text='mississippi', pattern='issip') == [4]
	assert candidate(text='bananana', pattern='ananas') == []
	assert candidate('ABCD', 'ABCD') == [0]
	assert candidate(
    'abra cadabra', 'abra') == [0, 8], "Simple candidate failed"
	assert candidate(
    'abra cadabra', 'z') == [], "Nonexistent candidate failed"
	assert candidate(
    "A quick brown fox jumps over the lazy dog",
    "cat"
) == []
	assert candidate(text='banana', pattern='nana') == []
	assert candidate('ABABX', 'ABABX') == [0]
	assert candidate('ABCD', 'D') == [3]
	assert candidate(text="ABABDABACDABABCABAB", pattern="BABABA") == []
	assert candidate('ABCD', 'XBC') == []
	assert candidate(text="ABABDABACDABABCABAB", pattern="BABA") == []
	assert candidate(
    'abra cadabra', 'adab') == [6]
	assert candidate('abc', 'ab') == [0]
def test_check():
	check(search)
