def get_info_or_create(source_dict, key, default_value):
	"""
	This returns the value of the key if it exists
	else it creates the key with the default value and returns it
	"""
    ### Canonical solution below ###
	try:
		info = source_dict[key]
		return info
	except KeyError:
		info = source_dict[key] = default_value
		return info


### Unit tests below ###
def check(candidate):
	assert candidate(dict(key='value'), 'key', lambda: 'default_value') == 'value'
	assert candidate(dict(), 'key', 42) == 42
	assert candidate(dict(key='value'), 'key', 'default_value') == 'value'
	assert candidate(dict(), 'key', 'default') == 'default'
	assert candidate(dict(), "key", "value") == "value"
	assert candidate(dict(), "key1", 1) == 1
	assert candidate({"key": 10}, "key", 20) == 10
	assert candidate(dict(), 'key', 'value') == 'value'
	assert candidate(dict(), 'key', 'default_value') == 'default_value'
	assert candidate(dict(), "key", 10) == 10
	assert candidate(dict(key="value"), "otherkey", "default") == "default"
	assert candidate(dict(), "key2", 1) == 1
	assert candidate(dict(key="value"), "key", "default") == "value"
	assert candidate({"key": 10}, "key", 10) == 10
	assert candidate(dict(), "key", "default") == "default"
	assert candidate({'key': 37}, 'key', 42) == 37
	assert candidate(dict(), 'key', 10) == 10
	assert candidate(dict(key='value'), 'key', 'default') == 'value'
	assert candidate(dict(key=20), 'key', 10) == 20
def test_check():
	check(get_info_or_create)
