def similarity_score_of_word_bags(bag1, bag2):
    """A dummy similarity metric. Simply counts the common words in the two bags.

    >>> similarity_score_of_word_bags(["apple", "orange", "duck"], ["orange", "duck"])
    2
    """
    ### Canonical solution below ###
    intersect = set(bag1).intersection(set(bag2))
    return len(intersect)


### Unit tests below ###
def check(candidate):
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "cow"]
) == 2
	assert candidate({"apple", "orange"}, {"orange"}) == 1
	assert candidate({"a", "b"}, {"a", "b", "c"}) == 2
	assert candidate(
    [],
    ["pineapple", "orange", "cat"]
) == 0
	assert candidate(set(["apple", "orange", "duck"]), set(["orange", "apple", "duck"])) == 3
	assert candidate(
    ["apple", "orange", "duck"],
    []
) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["grapefruit", "pear"]
) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "apple", "carrot"]) == 3
	assert candidate(["apple", "orange", "duck"], ["orange", "duck", "banana"]) == 2
	assert candidate(["apple", "orange", "duck"], ["orange", "duck"]) == 2
	assert candidate({"apple", "orange", "duck"}, {"orange", "duck"}) == 2
	assert candidate(["apple", "orange"], ["orange", "duck"]) == 1
	assert candidate({"a", "b"}, {"a", "b"}) == 2
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "banana"]) == 2
	assert candidate(
    [], []) == 0
	assert candidate(
    ["apple", "orange", "duck"],
    ["apple", "orange", "carrot", "banana"]
) == 2
	assert candidate(
    ["apple", "orange", "duck"],
    ["apple", "orange", "carrot"]
) == 2
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "apple", "banana"]) == 3
	assert candidate(set(["apple", "orange", "duck"]), set([])) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["carrot"]) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "apple"]) == 3
	assert candidate(
    ["apple", "orange", "duck"], ["meerkat"]) == 0
	assert candidate(set(["apple", "orange", "duck"]), set(["banana", "pineapple"])) == 0
	assert candidate(
    ["apple", "orange", "duck"],
    ["apple", "orange", "carrot", "banana", "cherry"]
) == 2
	assert candidate(
    ["apple", "orange", "duck"],
    ["orange", "cat"]
) == 1
	assert candidate(
    ["apple", "orange", "duck"], ["apple", "orange", "duck", "banana"]) == 3
	assert candidate(set(["apple", "orange", "duck"]), set(["apple", "orange", "duck"])) == 3
	assert candidate(
    ["apple", "orange", "duck"], ["apple", "orange", "duck"]) == 3
	assert candidate(
    ["apple", "orange", "duck"],
    ["orange", "duck"]
) == 2
	assert candidate({"a"}, set()) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "meerkat"]) == 2
	assert candidate(["apple", "orange", "duck"], ["grape"]) == 0
	assert candidate({"a", "b"}, {"b"}) == 1
	assert candidate(["apple", "orange", "duck"], []) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "chicken", "duck"]) == 2
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "cow"]
) == 1
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "apple", "duck"]) == 3
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "carrot"]) == 1
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "apple"]) == 2
	assert candidate([], ["orange", "duck"]) == 0
	assert candidate(
    ["apple", "orange", "duck"],
    ["apple", "orange", "duck"]
) == 3
	assert candidate(set([]), set(["apple", "orange", "duck"])) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "goose"]) == 1
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck"]) == 2
	assert candidate({"a"}, {"b"}) == 0
	assert candidate(
    ["apple", "orange", "duck"],
    ["apple", "orange", "duck", "carrot"]
) == 3
	assert candidate(
    ["apple", "orange", "duck"], ["grapes", "banana"]) == 0
	assert candidate(
    ["apple", "orange", "duck", "meerkat"], ["meerkat"]) == 1
	assert candidate(
        ["apple", "orange", "duck"], ["orange", "duck", "apple"]) == 3
	assert candidate(
        [], ["orange", "duck"]) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "banana", "apple"]) == 2
	assert candidate(
    ["apple", "orange", "duck"], ["grape"]) == 0
	assert candidate({"apple"}, {"orange"}) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["apple", "orange", "duck", "cat"]
) == 3
	assert candidate(
    ["apple", "orange", "duck"], ["apple", "orange", "duck"]
) == 3
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "grapefruit"]
) == 1
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "banana", "apple"]) == 3
	assert candidate(set(), {"a"}) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "apple", "banana", "banana"]) == 3
	assert candidate(
    ["apple", "orange", "duck", "meerkat"], ["meerkat", "goose"]) == 1
	assert candidate(
    ["apple", "orange", "duck"], ["banana"]) == 0
	assert candidate(set(["apple", "orange", "duck"]), set(["orange", "duck"])) == 2
	assert candidate({"a"}, {"a"}) == 1
	assert candidate(
    [],
    []
) == 0
	assert candidate(["apple", "orange"], ["banana", "cherry"]) == 0
	assert candidate(
    [], ["orange", "duck", "apple", "grape"]) == 0
	assert candidate(["apple", "orange"], ["orange"]) == 1
	assert candidate(
        ["apple", "orange", "duck"], []) == 0
	assert candidate({"a", "b", "c"}, {"a", "b", "c"}) == 3
	assert candidate(
        ["apple", "orange", "duck"], ["orange", "duck"]) == 2
	assert candidate([], []) == 0
	assert candidate(set(), set()) == 0
	assert candidate(
    ["apple", "orange", "duck", "meerkat"], ["goose"]) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["banana", "banana", "banana"]) == 0
	assert candidate(
        ["apple", "orange", "duck"], ["orange", "duck", "dog"]) == 2
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck", "carrot"]) == 2
	assert candidate(
    ["apple", "orange", "duck"], []) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "carrot", "apple", "carrot"]) == 2
	assert candidate(
        [], []) == 0
	assert candidate(
    ["apple", "orange", "duck"], ["orange", "duck"]
) == 2
def test_check():
	check(similarity_score_of_word_bags)
