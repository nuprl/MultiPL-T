def make_rowcol(string):
    """ 
     Creates a rowcol function similar to the rowcol function of a view
     
     Arguments:
     string -- The string on which the rowcol function should hold
     
     Returns:
     A function similar to the rowcol function of a sublime text view
     """
	### Canonical solution below ###    
    rowlens = [len(x) + 1 for x in string.split("\n")]
    rowpos = []
    acc = 0
    for i in rowlens:
        acc += i
        rowpos.append(acc)

    def rowcol(pos):
        last = 0
        for i, k in enumerate(rowpos, 0):
            if pos < k:
                return (i, pos - last)
            last = k
        return (-1, -1)
    return rowcol

### Unit tests below ###
def check(candidate):
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(5) == (2, 1)
	assert candidate(u"a\nb").__call__(3) == (1, 1)
	assert candidate(
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
)(4) == (0, 4)
	assert candidate(
    "This is a test\n" +
    "of the emergency broadcast system\n" +
    "It is a test\n" +
    "It is a test"
)(0) == (0, 0)
	assert candidate(
    "a\nb\nc"
)(2) == (1, 0)
	assert candidate(
    "a\nb\nc"
)(4) == (2, 0)
	assert candidate(u"a\nb").__call__(1) == (0, 1)
	assert candidate(
    "This is a test\n" +
    "of the emergency broadcast system\n" +
    "It is a test\n" +
    "It is a test"
)(80)
	assert candidate(
    "a\nb\nc\n"
)(1) == (0, 1)
	assert candidate(u"a\nb\nc")(3) == (1, 1)
	assert candidate(
    "abc\nabc\nabc"
)(0) == (0, 0)
	assert candidate(
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
)(3) == (0, 3)
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(6) == (3, 0)
	assert candidate(u"a\nb\nc")(4) == (2, 0)
	assert candidate(
    "Hello\n\n\nWorld")(0) == (0, 0)
	assert candidate(
    "a\nb\nc\n"
)(0) == (0, 0)
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(7) == (3, 1)
	assert candidate(
    "a\nb\nc"
)(1) == (0, 1)
	assert candidate(u"asdf\nqwer")(1) == (0, 1)
	assert candidate(u"a\nb\nc")(1) == (0, 1)
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(4) == (2, 0)
	assert candidate(
    "a\nb\nc"
)(3) == (1, 1)
	assert candidate(
"""abc
def
"""
)(0) == (0, 0)
	assert candidate(
    "a\nb\nc"
)(7) == (-1, -1)
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(2) == (1, 0)
	assert candidate(
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
)(2) == (0, 2)
	assert candidate(u"a\nb").__call__(2) == (1, 0)
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(3) == (1, 1)
	assert candidate(
    "a\nb\nc"
)(0) == (0, 0)
	assert candidate(u"a\nb").__call__(0) == (0, 0)
	assert candidate(u"asdf\nqwer")(2) == (0, 2)
	assert candidate(
    "abc\nabc\nabc"
)(1) == (0, 1)
	assert candidate(u"a\nb\nc")(2) == (1, 0)
	assert candidate(
    "abc\ndef\nghi"
)(0) == (0, 0)
	assert candidate(
    "Hello\n\n\nWorld")(3) == (0, 3)
	assert candidate(
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
)(1) == (0, 1)
	assert candidate(
    "abc\ndef\nghi"
)(2) == (0, 2)
	assert candidate(u"asdf\nqwer")(0) == (0, 0)
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(1) == (0, 1)
	assert candidate(u"a\nb\nc")(0) == (0, 0)
	assert candidate(
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
    "This is a test\n"
)(0) == (0, 0)
	assert candidate(
    "abc\ndef\nghi"
)(1) == (0, 1)
	assert candidate(
    "A\n"
    "B\n"
    "C\n"
    "D"
)(0) == (0, 0)
	assert candidate(
    "abc\nabc\nabc"
)(2) == (0, 2)
def test_check():
	check(make_rowcol)
