def count_words( word, count ):
	"""
	My First Python code :)
	This function receives word as text and count as a number
	It will group words by occurency and the count limit will be used to limit the words to return
	Return: [(word1, count1)..(wordN, countN)]
	"""
    ### Canonical solution below ###
	word_array = word.split(" ")
	return_list = []
	word_count = 0
	word_array.sort()
	word_buffer = word_array[0]
	for text in word_array:
		if word_buffer != text:
			return_list.append((word_buffer,word_count))
			word_buffer = text
			word_count = 0
		word_count = word_count + 1
	return_list.append((word_buffer,word_count))
	return_list.sort(key=lambda t: t[1], reverse=True)
	index = 0
	return_final = []
	while index < count:
		return_final.append(return_list[index])
		index = index + 1
	return return_final;


### Unit tests below ###
def check(candidate):
	assert candidate( "one two three four five six seven eight nine ten eleven", 0 ) == []
	assert candidate( "one one one one one one", 1 ) == [("one", 6)], "Should be [('one', 6)]"
	assert candidate( "one two three four", 0 ) == [], "Third Test"
	assert candidate( "one two three four", 1) == [("four", 1)]
	assert candidate( "one two three one two three one two three", 0 ) == []
	assert candidate( "this is a test this is a test this is a test", 0 ) == [], "Zero count"
	assert candidate( "one two two three three three", 2) == [('three', 3), ('two', 2)], "Should be [('three', 3), ('two', 2)]"
	assert candidate( "Hello World Hello Hello Hello", 2 ) == [("Hello",4),("World",1)]
	assert candidate( "one two three four five", 4 ) == [("five", 1), ("four", 1), ("one", 1), ("three", 1)]
	assert candidate( "this is a test", 0 ) == [], "Zero count"
	assert candidate( "hi how are you", 3 ) == [('are', 1), ('hi', 1), ('how', 1)]
	assert candidate( "Hello, world!", 0 ) == [], "0 Word"
	assert candidate( "a a a a b c c c c", 1 ) == [('a', 4)], "First"
	assert candidate( "one two three four five", 3 ) == [('five', 1), ('four', 1), ('one', 1)]
	assert candidate( "one two three four five", 2 ) == [("five", 1), ("four", 1)]
	assert candidate( "a a a b b c", 0 ) == []
	assert candidate( "hi how are you", 0 ) == []
	assert candidate( "Java Python PHP", 0) == []
	assert candidate( "Hello World", 1 ) == [("Hello",1)]
	assert candidate( "one two three", 0) == []
	assert candidate( "one two three four five", 5 ) == [('five', 1), ('four', 1), ('one', 1), ('three', 1), ('two', 1)]
	assert candidate( "one two three four five", 5 ) == [("five", 1), ("four", 1), ("one", 1), ("three", 1), ("two", 1)]
	assert candidate( "one two two three three three", 0 ) == [], "Should be []"
	assert candidate( "", 0 ) == []
	assert candidate( "one two three four five", 2 ) == [('five', 1), ('four', 1)]
	assert candidate( "one two three four five", 4 ) == [('five', 1), ('four', 1), ('one', 1), ('three', 1)]
	assert candidate( "this is a test", 0) == []
	assert candidate( "one two three four", 1 ) == [('four', 1)]
	assert candidate( "", 0) == []
	assert candidate( "hi how are you", 1 ) == [('are', 1)]
	assert candidate( "one two three four five six seven eight nine ten eleven", -10 ) == []
	assert candidate( "one two three four", 1 ) == [("four", 1)], "Second Test"
	assert candidate( "one two two three three three", 3) == [('three', 3), ('two', 2), ('one', 1)], "Should be [('three', 3), ('two', 2), ('one', 1)]"
	assert candidate( "one two three", 1) == [("one", 1)]
	assert candidate( "one two three", -1) == []
	assert candidate( "one two two three three three", 1 ) == [("three", 3)], "Should be [('three', 3)]"
	assert candidate( "one two three four five six seven eight nine ten eleven", -1 ) == []
	assert candidate( "one two two three three three", 2 ) == [("three", 3), ("two", 2)], "Should be [('three', 3), ('two', 2)]"
def test_check():
	check(count_words)
