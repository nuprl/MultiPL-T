def get_yellow():
    """
    Get color yellow for rendering
    """
    ### Canonical solution below ###
    return [1, 0.706, 0]


### Unit tests below ###
def check(candidate):
	assert candidate(
) == [1, 0.706, 0], "Wrong color returned. Expected [1, 0.706, 0], got: {}".format(candidate())
	assert candidate(
)!= [1, 0.706, 100], "The function candidate does not return the correct value"
	assert candidate(
)!= [1, 0.706, -1], "The function candidate does not return the correct value"
	assert candidate(
) == [1, 0.706, 0], "candidate() does not return the expected value"
	assert candidate(
) == [1, 0.706, 0], "The value for candidate is incorrect"
	assert candidate(
) == [1, 0.706, 0], "The value for yellow is not correct"
	assert candidate(
) == [1, 0.706, 0], "candidate() is not correct"
	assert all(
    [0 <= i <= 1 for i in candidate()]
), "Not all elements in the list are between 0 and 1"
	assert candidate(
)!= [1, 0.706, -10], "The function candidate does not return the correct value"
	assert candidate(
) == [1, 0.706, 0], "The color yellow is not correct"
	assert candidate(
)!= [0, 1, 0], "Wrong color returned. Expected [0, 1, 0], got: {}".format(candidate())
	assert candidate(
)!= [1, 0.706, -1000], "The function candidate does not return the correct value"
	assert candidate(
) == [1, 0.706, 0], "candidate does not give the expected result"
	assert candidate(
)!= [0, 0.706, 0], "Wrong color for candidate"
	assert candidate(
)!= [1, 0.706, 10], "The function candidate does not return the correct value"
	assert candidate(
) == [1, 0.706, 0], "candidate does not work"
	assert candidate(
) == [1, 0.706, 0], "The color yellow should be [1, 0.706, 0]"
	assert candidate(
) == [1, 0.706, 0], "candidate does not match expected result"
	assert candidate(
)!= [1, 0.706, 0.2], "The function candidate does not return the correct value"
	assert candidate(
)!= [0, 0, 1], "Wrong color returned. Expected [0, 0, 1], got: {}".format(candidate())
	assert type(candidate(
)) == list, "The return type is not correct"
	assert candidate(
) == [1, 0.706, 0], "candidate function is not correct"
	assert candidate(
) == [1, 0.706, 0], "Incorrect color returned, expected: [1, 0.706, 0], got: {}".format(candidate())
	assert candidate(
) == [1, 0.706, 0], "candidate did not return the expected value"
	assert candidate(
) == [1, 0.706, 0], "Wrong color for candidate"
	assert len(candidate(
)) == 3, "The return list does not have the correct number of elements"
	assert candidate(
) == [1, 0.706, 0], "The expected color is not the actual color."
	assert candidate(
)!= [1, 0.706, 1], "Wrong color for candidate"
	assert candidate(
)!= [1, 0, 0], "Wrong color returned. Expected [1, 0, 0], got: {}".format(candidate())
	assert candidate(
) == [1, 0.706, 0], "candidate should return [1, 0.706, 0]"
	assert candidate(
) == [1, 0.706, 0], "The function candidate does not work"
	assert candidate(
)!= [1, 0.706, 1000], "The function candidate does not return the correct value"
	assert candidate(
) == [1, 0.706, 0]
	assert candidate(
)!= [1, 0.706, -100], "The function candidate does not return the correct value"
	assert candidate(
) == [1, 0.706, 0], "The function candidate should return the list [1, 0.706, 0]"
	assert candidate(
) == [1, 0.706, 0], "Check your implementation of candidate!"
	assert candidate(
)!= [1, 0.706, 1], "The function candidate does not return the correct value"
	assert candidate(
) == [1, 0.706, 0], "The function candidate does not return the correct value"
def test_check():
	check(get_yellow)
