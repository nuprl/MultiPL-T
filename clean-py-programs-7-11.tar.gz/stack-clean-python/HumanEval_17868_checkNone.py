def checkNone(obj):
    """Check if obj is None"""
    ### Canonical solution below ###
    if obj is None:
        return True
    else:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate(candidate) == False
	assert candidate({1: 2, 3: 4, "a": "b"}) == False
	assert not candidate(type(1).__call__)
	assert candidate(5) == False
	assert candidate([]) == False
	assert candidate('hi') == False
	assert not candidate(())
	assert not candidate(type)
	assert candidate([1, 2, 3]) == False
	assert candidate("Hello") == False
	assert candidate("5") == False
	assert not candidate(range(0))
	assert not candidate([])
	assert not candidate('test')
	assert candidate('a') == False
	assert not candidate(0)
	assert not candidate("Hello")
	assert candidate(None) == True
	assert candidate("None") == False
	assert not candidate("1")
	assert not candidate('a')
	assert candidate(None) is True
	assert not candidate({})
	assert not candidate(set())
	assert candidate(None)
	assert candidate(1) is False
	assert not candidate("0")
	assert candidate(False) == False
	assert candidate(1) == False
	assert not candidate(1)
	assert candidate(True) == False
	assert candidate((1, 2, 3)) == False
	assert candidate(0) is False
	assert not candidate(" ")
	assert not candidate("  hello  ")
	assert candidate(0) == False
	assert not candidate("None")
	assert candidate({'a': 1}) == False
	assert candidate('None') == False
	assert not candidate(True)
	assert not candidate(iter([]))
	assert not candidate("hello")
	assert not candidate("")
	assert not candidate(False)
	assert candidate({1: 2, 3: 4}) == False
	assert candidate({1, 2, 3}) == False
	assert not candidate(lambda x: x)
	assert not candidate(type(1))
	assert candidate({}) == False
def test_check():
	check(checkNone)
