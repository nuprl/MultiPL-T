def fix_child_link(parent_url, link):
    """
    Form a valid absolute link for a relative link
    :param parent_url: string or None
    :param link: string url (can be relative)
    :return: string, absolute url
    """
    ### Canonical solution below ###
    if link["url"].startswith("/") and parent_url:
        print("Parent_url: ", parent_url)
        if parent_url.endswith("/"):
            return {**link, "url": f"{parent_url[:-1]}{link['url']}"}
        else:
            return {**link, "url": f"{parent_url}{link['url']}"}
    else:
        return link


### Unit tests below ###
def check(candidate):
	assert candidate("http://localhost", {"url": "/test"})["url"] == "http://localhost/test"
	assert candidate(None, {"url": "/about"})["url"] == "/about", "test 1 failed"
	assert candidate("http://example.com", {"url": "http://example.com/foo"}) == {"url": "http://example.com/foo"}
	assert candidate(None, {"url": "https://www.example.com/about.html?a=b"}) == {"url": "https://www.example.com/about.html?a=b"}
	assert candidate("https://www.example.com/", {"url": "/test/"})["url"] == "https://www.example.com/test/"
	assert candidate(
    "https://www.google.com", {"url": "/about", "name": "About"}
) == {"url": "https://www.google.com/about", "name": "About"}
	assert candidate(None, {"url": "/some/path"}) == {"url": "/some/path"}
	assert candidate("a", {"url": "a"}) == {"url": "a"}
	assert candidate("https://example.com", {"url": "/a"}) == {"url": "https://example.com/a"}
	assert candidate("http://example.com", {"url": "/a"}) == {"url": "http://example.com/a"}
	assert candidate(None, {"url": "some/path"}) == {"url": "some/path"}
	assert candidate(None, {"url": "page.html"}) == {"url": "page.html"}
	assert candidate("a", {"url": "/b"}) == {"url": "a/b"}
	assert candidate("https://example.com/", {"url": "/about"})["url"] == "https://example.com/about", "test 2 failed"
	assert candidate("http://localhost/", {"url": "/test"})["url"] == "http://localhost/test"
	assert candidate("http://example.com/", {"url": "/a"}) == {"url": "http://example.com/a"}
	assert candidate("http://test.com", {"url": "/test"}) == {"url": "http://test.com/test"}
	assert candidate("a/b", {"url": "/c"}) == {"url": "a/b/c"}
	assert candidate("http://example.com/", {"url": "/foo"}) == {"url": "http://example.com/foo"}
	assert candidate(None, {"url": "test"}) == {"url": "test"}
	assert candidate("http://example.com/", {"url": "/about/"}) == {"url": "http://example.com/about/"}
	assert candidate(None, {"url": "foo"}) == {"url": "foo"}
	assert candidate("http://test.com", {"url": "http://test.com/test"}) == {"url": "http://test.com/test"}
	assert candidate("http://test.com", {"url": "http://test2.com/"}) == {"url": "http://test2.com/"}
	assert candidate(None, {"url": "/foo"})["url"] == "/foo"
	assert candidate(None, {"url": "https://www.example.com/about"}) == {"url": "https://www.example.com/about"}
	assert candidate("http://test.com", {"url": "/test/"}) == {"url": "http://test.com/test/"}
	assert candidate(None, {"url": "https://www.example.com"})["url"] == "https://www.example.com"
	assert candidate(None, {"url": "http://example.com"}) == {"url": "http://example.com"}
	assert candidate("http://www.test.com", {"url": "/test"})["url"] == "http://www.test.com/test"
	assert candidate("https://www.example.com/", {"url": "/test/test/"})["url"] == "https://www.example.com/test/test/"
	assert candidate("http://example.com", {"title": "Home", "url": "/"})["url"] == "http://example.com/"
	assert candidate(None, {"title": "Home", "url": "/"})["url"] == "/"
	assert candidate("http://foo.com/bar/", {"url": "http://bar.com/foo"}) == {"url": "http://bar.com/foo"}
	assert candidate("http://test.com", {"url": "http://test.com/test/"}) == {"url": "http://test.com/test/"}
	assert candidate(None, {"url": "/about"}) == {"url": "/about"}
	assert candidate(None, {"url": "about"}) == {"url": "about"}
	assert candidate("https://www.google.com", {"url": "/about"}) == {"url": "https://www.google.com/about"}
	assert candidate("http://example.com", {"url": "/foo"}) == {"url": "http://example.com/foo"}
	assert candidate("https://example.com", {"url": "/about"}) == {"url": "https://example.com/about"}
	assert candidate(None, {"url": "/page.html"}) == {"url": "/page.html"}
	assert candidate(None, {"url": "about.html"}) == {"url": "about.html"}
	assert candidate("http://www.test.com/", {"url": "http://www.test.com/test/"})["url"] == "http://www.test.com/test/"
	assert candidate(None, {"url": "/test"})["url"] == "/test"
	assert candidate("https://www.example.com/", {"url": "/test/test"})["url"] == "https://www.example.com/test/test"
	assert candidate("https://example.com/", {"title": "Home", "url": "/home"})["url"] == "https://example.com/home"
	assert candidate(None, {"url": "https://www.example.com/about.html#anchor"}) == {"url": "https://www.example.com/about.html#anchor"}
	assert candidate("http://test.com", {"url": "http://test2.com"}) == {"url": "http://test2.com"}
	assert candidate(None, {"url": "https://www.example.com"}) == {"url": "https://www.example.com"}
	assert candidate(None, {"url": "a", "title": "b"}) == {"url": "a", "title": "b"}
	assert candidate("https://example.com/", {"url": "/a"}) == {"url": "https://example.com/a"}
	assert candidate(None, {"url": "https://www.google.com"}) == {"url": "https://www.google.com"}
	assert candidate(None, {"url": "/about.html"}) == {"url": "/about.html"}
	assert candidate("https://www.example.com/", {"url": "/test"})["url"] == "https://www.example.com/test"
	assert candidate("https://www.example.com", {"url": "/test/"})["url"] == "https://www.example.com/test/"
	assert candidate(None, {"title": "title", "url": "/test"})["url"] == "/test", "Test 1"
	assert candidate(None, {"url": "https://www.example.com/about.html"}) == {"url": "https://www.example.com/about.html"}
	assert candidate("https://example.com/", {"url": "/about.html"}) == {"url": "https://example.com/about.html"}
	assert candidate("https://test.com", {"url": "/test"}) == {"url": "https://test.com/test"}
	assert candidate("http://example.com", {"url": "/some/path"}) == {"url": "http://example.com/some/path"}
	assert candidate("http://example.com", {"url": "/about"}) == {"url": "http://example.com/about"}
	assert candidate("http://example.com", {"title": "Home", "url": "/home"})["url"] == "http://example.com/home"
	assert candidate("http://example.com/", {"url": "/some/path"}) == {"url": "http://example.com/some/path"}
	assert candidate("http://example.com/", {"url": "http://example.com/foo"}) == {"url": "http://example.com/foo"}
	assert candidate("https://example.com", {"url": "/foo"}) == {"url": "https://example.com/foo"}
	assert candidate(
    None, {"url": "/", "name": "Home"}
) == {"url": "/", "name": "Home"}
	assert candidate("http://test.com", {"title": "title", "url": "/test"})["url"] == "http://test.com/test", "Test 2"
	assert candidate("http://example.com/", {"title": "Home", "url": "/"})["url"] == "http://example.com/"
	assert candidate("https://example.com", {"url": "/about.html"}) == {"url": "https://example.com/about.html"}
	assert candidate("http://www.example.com/", {"url": "/link"}) == {"url": "http://www.example.com/link"}
	assert candidate(None, {"url": "/link"}) == {"url": "/link"}
	assert candidate(None, {"title": "Home", "url": "/home"})["url"] == "/home"
	assert candidate("https://example.com/bar/", {"url": "/foo"}) == {"url": "https://example.com/bar/foo"}
	assert candidate(None, {"url": "https://example.com"}) == {"url": "https://example.com"}
	assert candidate("https://www.google.com/", {"url": "/about"}) == {"url": "https://www.google.com/about"}
	assert candidate(None, {"url": "/about.html?a=b"}) == {"url": "/about.html?a=b"}
	assert candidate(None, {"url": "relative"})["url"] == "relative"
	assert candidate("http://test.com/", {"title": "title", "url": "/test"})["url"] == "http://test.com/test", "Test 3"
	assert candidate("http://www.test.com/", {"url": "/test"})["url"] == "http://www.test.com/test"
	assert candidate(None, {"url": "https://www.example.com/"})["url"] == "https://www.example.com/"
	assert candidate("http://www.example.com", {"url": "/link"}) == {"url": "http://www.example.com/link"}
	assert candidate(None, {"url": "test.com/test"}) == {"url": "test.com/test"}
	assert candidate("https://example.com/other/", {"title": "Home", "url": "/home"})["url"] == "https://example.com/other/home"
	assert candidate("https://example.com/about/", {"url": "/about"})["url"] == "https://example.com/about/about", "test 3 failed"
	assert candidate("https://example.com", {"title": "Home", "url": "/home"})["url"] == "https://example.com/home"
	assert candidate("https://www.example.com", {"url": "/test"})["url"] == "https://www.example.com/test"
	assert candidate(None, {"url": "/test/"}) == {"url": "/test/"}
	assert candidate("https://www.google.com", {"url": "https://www.google.com"}) == {"url": "https://www.google.com"}
	assert candidate("http://example.com", {"url": "/about/"}) == {"url": "http://example.com/about/"}
	assert candidate("https://www.google.com/", {"url": "/about/"}) == {"url": "https://www.google.com/about/"}
	assert candidate(None, {"url": "/about.html#anchor"}) == {"url": "/about.html#anchor"}
	assert candidate("https://test.com/", {"url": "/test"}) == {"url": "https://test.com/test"}
	assert candidate(
    "https://www.google.com",
    {"url": "https://www.facebook.com", "name": "Facebook"},
) == {
    "url": "https://www.facebook.com",
    "name": "Facebook",
}
	assert candidate("https://example.com/about/", {"url": "/about/about"})["url"] == "https://example.com/about/about/about", "test 8 failed"
	assert candidate(
    "https://www.google.com/", {"url": "/about", "name": "About"}
) == {"url": "https://www.google.com/about", "name": "About"}
	assert candidate("http://test.com", {"title": "title", "url": "http://test.com/test"})["url"] == "http://test.com/test", "Test 4"
	assert candidate(
    "https://www.google.com", {"url": "/", "name": "Home"}
) == {"url": "https://www.google.com/", "name": "Home"}
	assert candidate(None, {"url": "/home"}) == {"url": "/home"}
	assert candidate("http://www.test.com/", {"url": "/test/"})["url"] == "http://www.test.com/test/"
	assert candidate(None, {"url": "/test.com/test"}) == {"url": "/test.com/test"}
	assert candidate(None, {"url": "/a"}) == {"url": "/a"}
	assert candidate("http://www.example.com/", {"url": "http://www.example.com/link"}) == {"url": "http://www.example.com/link"}
	assert candidate("http://example.com/", {"title": "Home", "url": "/home"})["url"] == "http://example.com/home"
	assert candidate("http://example.com", {"url": "/foo"})["url"] == "http://example.com/foo"
	assert candidate(None, {"url": "/test"}) == {"url": "/test"}
	assert candidate(None, {"url": "/foo"}) == {"url": "/foo"}
	assert candidate("https://example.com/", {"url": "/about"}) == {"url": "https://example.com/about"}
	assert candidate(None, {"url": "http://test.com"}) == {"url": "http://test.com"}
	assert candidate("http://example.com/", {"url": "/foo"})["url"] == "http://example.com/foo"
	assert candidate("http://www.example.com", {"url": "http://www.example.com/link"}) == {"url": "http://www.example.com/link"}
	assert candidate(None, {"url": "/about.html?a=b#anchor"}) == {"url": "/about.html?a=b#anchor"}
	assert candidate("a/", {"url": "/b"}) == {"url": "a/b"}
	assert candidate("https://example.com/", {"url": "/foo"}) == {"url": "https://example.com/foo"}
	assert candidate(None, {"url": "foo"})["url"] == "foo"
	assert candidate(None, {"url": "a"}) == {"url": "a"}
def test_check():
	check(fix_child_link)
