def get_workspace(repo_context):
    """
    Construct the workspace url from the given repo context

    :param repo_context: Repo context from context.py
    :return: Workspace url for known VCS or None
    """
    ### Canonical solution below ###
    if not repo_context["repositoryUri"]:
        return None
    revision = repo_context.get("revisionId", repo_context.get("branch"))
    if "github.com" in repo_context["repositoryUri"]:
        return "{}/blob/{}".format(repo_context["repositoryUri"], revision)
    if "gitlab" in repo_context["repositoryUri"]:
        return "{}/-/blob/{}".format(repo_context["repositoryUri"], revision)
    if "bitbucket" in repo_context["repositoryUri"] and repo_context.get("revisionId"):
        return "{}/src/{}".format(repo_context["repositoryUri"], revision)
    if "azure.com" in repo_context["repositoryUri"] and repo_context.get("branch"):
        return "{}?_a=contents&version=GB{}&path=".format(
            repo_context["repositoryUri"], repo_context.get("branch")
        )
    return None


### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        "repositoryUri": "https://github.com/aws/aws-cdk",
        "revisionId": "deadbeef",
        "branch": "master",
    }
) == "https://github.com/aws/aws-cdk/blob/deadbeef"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/test/test",
        "branch": "master",
        "revisionId": "123456",
    }
) == "https://gitlab.com/test/test/-/blob/123456"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-sdk-for-java",
        "revisionId": "f4f5f6",
    }
) == "https://github.com/Azure/azure-sdk-for-java/blob/f4f5f6"
	assert candidate(
    {"repositoryUri": "https://github.com/Azure/azure-sdk-for-python", "branch": "feature-branch"}
) == "https://github.com/Azure/azure-sdk-for-python/blob/feature-branch"
	assert candidate({"repositoryUri": "https://gitlab.com/foo/bar", "branch": "branch"}) == "https://gitlab.com/foo/bar/-/blob/branch"
	assert candidate(
    {"repositoryUri": "https://github.com/Azure/azure-sdk-for-python", "branch": "master"}
) == "https://github.com/Azure/azure-sdk-for-python/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-sdk-for-python",
        "branch": "master",
    }
) == "https://github.com/Azure/azure-sdk-for-python/blob/master"
	assert candidate(
    {
        "repositoryType": "gitlab",
        "repositoryUri": "https://gitlab.com/foo/bar",
        "branch": "baz",
    }
) == "https://gitlab.com/foo/bar/-/blob/baz"
	assert candidate(dict(repositoryUri="https://github.com/Azure/azure-cli", branch="dev")) == "https://github.com/Azure/azure-cli/blob/dev"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/cli/cli",
        "branch": "master"
    }
) == "https://gitlab.com/cli/cli/-/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://bitbucket.org/aws/aws-cdk",
        "revisionId": "deadbeef",
        "branch": "master",
    }
) == "https://bitbucket.org/aws/aws-cdk/src/deadbeef"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-sdk-for-python",
        "branch": "feature/foo",
    }
) == "https://github.com/Azure/azure-sdk-for-python/blob/feature/foo"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/test/test",
        "branch": "master",
    }
) == "https://gitlab.com/test/test/-/blob/master"
	assert candidate(repo_context={"repositoryUri": "https://gitlab.com/org/repo", "branch": "mybranch"}) == "https://gitlab.com/org/repo/-/blob/mybranch"
	assert candidate(repo_context={"repositoryUri": "https://github.com/org/repo", "branch": "mybranch", "revisionId": "myrev"}) == "https://github.com/org/repo/blob/myrev"
	assert candidate(
    {
        "repositoryUri": "https://bitbucket.org/azure/azure-cli",
        "revisionId": "12345"
    }
) == "https://bitbucket.org/azure/azure-cli/src/12345"
	assert candidate(
    {
        "repositoryType": "bitbucket",
        "repositoryUri": "https://bitbucket.com/foo/bar",
        "revisionId": "123456789",
    }
) == "https://bitbucket.com/foo/bar/src/123456789"
	assert candidate(
    {"repositoryUri": "https://github.com/aws/aws-cdk", "revisionId": "33c28b79399e81913802d60c36838371238907a0"}
) == "https://github.com/aws/aws-cdk/blob/33c28b79399e81913802d60c36838371238907a0"
	assert candidate(dict(repositoryUri="https://gitlab.com/Azure/azure-cli", branch="dev", revisionId="0000000")) == "https://gitlab.com/Azure/azure-cli/-/blob/0000000"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/azure/azure-cli",
        "branch": "master",
        "commitId": "12345",
    }
) == "https://gitlab.com/azure/azure-cli/-/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/aws/aws-cdk",
        "revisionId": "deadbeef",
        "branch": "master",
    }
) == "https://gitlab.com/aws/aws-cdk/-/blob/deadbeef"
	assert candidate(
    {
        "repositoryUri": "https://github.com/microsoft/vscode-python",
        "revisionId": "12345",
    }
) == "https://github.com/microsoft/vscode-python/blob/12345"
	assert candidate(dict(repositoryUri="https://github.com/Azure/azure-cli", branch="dev", revisionId="0000000")) == "https://github.com/Azure/azure-cli/blob/0000000"
	assert candidate(repo_context={"repositoryUri": "https://gitlab.com/org/repo", "branch": "mybranch", "revisionId": "myrev"}) == "https://gitlab.com/org/repo/-/blob/myrev"
	assert candidate(
    {
        "repositoryType": "github",
        "repositoryUri": "https://github.com/foo/bar",
        "branch": "baz",
    }
) == "https://github.com/foo/bar/blob/baz"
	assert candidate({"repositoryUri": "https://example.com/repo"}) is None
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-sdk-for-java",
        "branch": "feature/v2",
        "revisionId": "f4f5f6",
    }
) == "https://github.com/Azure/azure-sdk-for-java/blob/f4f5f6"
	assert candidate(
    {
        "repositoryUri": "https://github.com/org/repo",
        "branch": "main",
        "commitId": "asdf",
    }
) == "https://github.com/org/repo/blob/main"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/azure/azure-cli",
        "revisionId": "12345"
    }
) == "https://gitlab.com/azure/azure-cli/-/blob/12345"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-cli",
        "revisionId": "23234"
    }
) == "https://github.com/Azure/azure-cli/blob/23234"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/foo/bar",
        "branch": "master",
    }
) == "https://gitlab.com/foo/bar/-/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-cli",
        "branch": "master",
        "commitId": "12345",
    }
) == "https://github.com/Azure/azure-cli/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/cli/cli",
        "revisionId": "23234"
    }
) == "https://gitlab.com/cli/cli/-/blob/23234"
	assert candidate({"repositoryUri": "https://dev.azure.com/foo/bar", "branch": "dev"}) == "https://dev.azure.com/foo/bar?_a=contents&version=GBdev&path="
	assert candidate(
    {
        "repositoryUri": "https://dev.azure.com/azure-sdk/public/_git/azure-cli",
        "branch": "master"
    }
) == "https://dev.azure.com/azure-sdk/public/_git/azure-cli?_a=contents&version=GBmaster&path="
	assert candidate(repo_context={"repositoryUri": "https://gitlab.com/org/repo", "revisionId": "myrev"}) == "https://gitlab.com/org/repo/-/blob/myrev"
	assert candidate({
    "repositoryUri": "https://github.com/aws-cloudformation/aws-cloudformation-coverage-roadmap",
    "revisionId": "abcdef1234567890",
}) == "https://github.com/aws-cloudformation/aws-cloudformation-coverage-roadmap/blob/abcdef1234567890"
	assert candidate(
    {
        "repositoryType": "gitlab",
        "repositoryUri": "https://gitlab.com/foo/bar",
        "revisionId": "123456789",
    }
) == "https://gitlab.com/foo/bar/-/blob/123456789"
	assert candidate({"repositoryUri": "https://gitlab.com/foo/bar", "branch": "branch", "revisionId": "1234"}) == "https://gitlab.com/foo/bar/-/blob/1234"
	assert candidate({"repositoryUri": "https://gitlab.com/foo/bar", "branch": "dev"}) == "https://gitlab.com/foo/bar/-/blob/dev"
	assert candidate(
    {"repositoryUri": "https://github.com/user/repo", "revisionId": "123"}
) == "https://github.com/user/repo/blob/123"
	assert candidate(
    {"repositoryUri": "https://github.com/Azure/azure-sdk-for-python", "revisionId": "master"}
) == "https://github.com/Azure/azure-sdk-for-python/blob/master"
	assert candidate(
    {"repositoryUri": "https://azure.com/user/repo", "branch": "main"}
) == "https://azure.com/user/repo?_a=contents&version=GBmain&path="
	assert candidate(
    {
        "repositoryUri": "https://github.com/microsoft/vscode-python",
        "branch": "master",
    }
) == "https://github.com/microsoft/vscode-python/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-cli",
        "branch": "master",
    }
) == "https://github.com/Azure/azure-cli/blob/master"
	assert candidate(
    {"repositoryUri": "https://gitlab.com/Azure/azure-sdk-for-python", "revisionId": "master"}
) == "https://gitlab.com/Azure/azure-sdk-for-python/-/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-cli",
        "branch": "master"
    }
) == "https://github.com/Azure/azure-cli/blob/master"
	assert candidate(
    {"repositoryUri": "https://gitlab.com/user/repo", "revisionId": "123"}
) == "https://gitlab.com/user/repo/-/blob/123"
	assert candidate(
    {"repositoryUri": "https://github.com/aws/aws-cdk", "branch": "main"}
) == "https://github.com/aws/aws-cdk/blob/main"
	assert candidate({"repositoryUri": "https://github.com/foo/bar", "branch": "branch"}) == "https://github.com/foo/bar/blob/branch"
	assert candidate(
    {"repositoryUri": "https://github.com/Azure/azure-sdk-for-python", "revisionId": "feature-branch"}
) == "https://github.com/Azure/azure-sdk-for-python/blob/feature-branch"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-cli",
        "revisionId": "12345"
    }
) == "https://github.com/Azure/azure-cli/blob/12345"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/azure/azure-cli",
        "branch": "master",
    }
) == "https://gitlab.com/azure/azure-cli/-/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://gitlab.com/Azure/azure-sdk-for-java",
        "branch": "feature/v2",
    }
) == "https://gitlab.com/Azure/azure-sdk-for-java/-/blob/feature/v2"
	assert candidate(
    {"repositoryUri": "https://gitlab.com/user/repo", "branch": "main"}
) == "https://gitlab.com/user/repo/-/blob/main"
	assert candidate(
    {
        "repositoryUri": "https://github.com/test/test",
        "branch": "master",
    }
) == "https://github.com/test/test/blob/master"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-sdk-for-python",
        "revisionId": "123456",
    }
) == "https://github.com/Azure/azure-sdk-for-python/blob/123456"
	assert candidate({"repositoryUri": "https://github.com/foo/bar", "branch": "branch", "revisionId": "1234"}) == "https://github.com/foo/bar/blob/1234"
	assert candidate(
    {
        "repositoryType": "github",
        "repositoryUri": "https://github.com/foo/bar",
        "revisionId": "123456789",
    }
) == "https://github.com/foo/bar/blob/123456789"
	assert candidate(
    {
        "repositoryUri": "https://github.com/test/test",
        "branch": "master",
        "revisionId": "123456",
    }
) == "https://github.com/test/test/blob/123456"
	assert candidate(
    {"repositoryUri": "https://gitlab.com/Azure/azure-sdk-for-python", "branch": "master"}
) == "https://gitlab.com/Azure/azure-sdk-for-python/-/blob/master"
	assert candidate(
    {"repositoryUri": "https://bitbucket.org/user/repo", "revisionId": "123"}
) == "https://bitbucket.org/user/repo/src/123"
	assert candidate(dict(repositoryUri="https://gitlab.com/Azure/azure-cli", branch="dev")) == "https://gitlab.com/Azure/azure-cli/-/blob/dev"
	assert candidate(
    {
        "repositoryUri": "https://github.com/foo/bar",
        "branch": "main",
    }
) == "https://github.com/foo/bar/blob/main"
	assert candidate(
    {
        "repositoryUri": "https://dev.azure.com/test/test/_git/test",
        "branch": "master",
    }
) == "https://dev.azure.com/test/test/_git/test?_a=contents&version=GBmaster&path="
	assert candidate({
    "repositoryUri": "https://github.com/aws-cloudformation/aws-cloudformation-coverage-roadmap",
    "branch": "main",
}) == "https://github.com/aws-cloudformation/aws-cloudformation-coverage-roadmap/blob/main"
	assert candidate(repo_context={"repositoryUri": "https://github.com/org/repo", "revisionId": "myrev"}) == "https://github.com/org/repo/blob/myrev"
	assert candidate(
    {
        "repositoryUri": "https://github.com/foo/bar",
        "revisionId": "1234567890",
    }
) == "https://github.com/foo/bar/blob/1234567890"
	assert candidate({"repositoryUri": "https://github.com/foo/bar", "branch": "dev"}) == "https://github.com/foo/bar/blob/dev"
	assert candidate(
    {"repositoryUri": "https://github.com/user/repo", "branch": "main"}
) == "https://github.com/user/repo/blob/main"
	assert candidate(repo_context={"repositoryUri": "https://github.com/org/repo", "branch": "mybranch"}) == "https://github.com/org/repo/blob/mybranch"
	assert candidate(
    {
        "repositoryUri": "https://github.com/Azure/azure-sdk-for-java",
        "branch": "feature/v2",
    }
) == "https://github.com/Azure/azure-sdk-for-java/blob/feature/v2"
def test_check():
	check(get_workspace)
