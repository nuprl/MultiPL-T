def get_motif(sequences):
	"""
	Computes the motif for a given collection of sequences.
	A motif is a representative sequence for all sequences in a collection, with blank values (0) being those which are variable within the collection, and fixed values which are not.
	Motifs are related to the measure of synchrony in that synchrony is equal to the number of non-blank elements in the motif.
	
	Example
	--------
	
	>>> s1 = [1,1,2,2,3]
	>>> s2 = [1,2,2,3,3]
	>>> s3 = [1,1,2,2,2]
	>>> sequences = [s1,s2,s3]
	>>> ps.get_motif(sequences)
	[1, 0, 2, 0, 0]

	"""
    ### Canonical solution below ###
	
	shortest_sequence = min([len(s) for s in sequences])
	
	same_elements = []
	for position in range(shortest_sequence):
	
		elements_at_this_position = []
		for sequence in sequences:
			elements_at_this_position.append(sequence[position])
	
		if elements_at_this_position.count(elements_at_this_position[0]) == len(elements_at_this_position):
			same_elements.append(sequences[0][position])
		else:
			same_elements.append(0)
	
	return same_elements


### Unit tests below ###
def check(candidate):
	assert candidate(sequences=[[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate(
	[[1, 1, 1, 1, 1, 1],
	[1, 1, 1, 1, 1, 1],
	[1, 1, 1, 1, 1, 1]]) == [1, 1, 1, 1, 1, 1]
	assert candidate(
	[[1, 1, 2, 2, 3],
	 [1, 2, 2, 3, 3],
	 [1, 1, 2, 2, 2]]) == [1, 0, 2, 0, 0]
	assert candidate( [[1,1,1,1,1],[1,2,3,4,5],[1,2,3,4,5]] ) == [1, 0, 0, 0, 0]
	assert candidate(sequences=[[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,4]]) == [1, 0, 2, 0, 0]
	assert candidate(
	[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,3],[1,2,2,3,3]]) == [1, 0, 2, 0, 3]
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]]) == [1, 0, 2, 0, 0], "Test 1 failed"
	assert candidate(sequences = [[1,1,1,1,1], [1,1,1,1,1], [1,1,1,1,1]]) == [1,1,1,1,1], "Incorrect motif returned"
	assert candidate(
	[[1, 1, 1, 2, 2, 2],
	[1, 1, 1, 2, 2, 2],
	[1, 1, 1, 2, 2, 2]]) == [1, 1, 1, 2, 2, 2]
	assert candidate( [[1,1,2,2], [1,2,2,3], [1,1,2,2]] ) == [1, 0, 2, 0]
	assert candidate(sequences = [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,4]]) == [1, 0, 2, 0, 0]
	assert candidate( [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]] ) == [1, 0, 2, 0, 0]
	assert candidate(
	[[1,1,2,2,3],
	 [1,2,2,3,3],
	 [1,1,2,2,2]]
	) == [1, 0, 2, 0, 0]
	assert candidate(sequences = [[1,2,3],[1,2,3],[1,2,3]]) == [1,2,3]
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,4]]) == [1, 0, 2, 0, 0], "Test 3 failed"
	assert candidate(sequences=[[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3]]) == [1, 1, 2, 2, 3]
	assert candidate( [[1,1,1,1],[1,1,1,1],[1,1,1,1]] ) == [1,1,1,1]
	assert candidate( [[1,2,3,4,5], [1,2,3,4,5], [1,2,3,4,5]] ) == [1, 2, 3, 4, 5]
	assert candidate( [[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,2]] ) == [1, 0, 2, 0, 0]
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate( [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]]) == [1,0,2,0,0], "candidate([1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]) failed"
	assert candidate( [[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,2], [1,1,2,2,3]]) == [1, 0, 2, 0, 0]
	assert candidate(
	[[1,1,2,2,3],
	 [1,2,3,3,3],
	 [1,1,2,2,2]]
	) == [1, 0, 0, 0, 0]
	assert candidate( [[1,1,1,1], [1,1,1,1], [1,1,1,1]] ) == [1, 1, 1, 1]
	assert candidate( [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]]) == [1,0,2,0,0]
	assert candidate( [[1,2,3,4], [1,2,3,4], [1,2,3,4]] ) == [1, 2, 3, 4]
	assert candidate(
	[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,3]]) == [1, 0, 2, 0, 3]
	assert candidate(sequences=[[1,1,2,2,3], [1,2,2,3,3], [1,1,2,3,2]]) == [1,0,2,0,0]
	assert candidate( [[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3]] ) == [1, 1, 2, 3]
	assert candidate( [[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3]] ) == [1,1,2,2,3]
	assert candidate( [[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2]] ) == [1, 0, 2, 0]
	assert candidate( [[1,1,1,1,1],[1,2,3,3,3],[1,1,2,2,2],[1,1,2,2,2]] ) == [1, 0, 0, 0, 0], "candidate failed"
	assert candidate(sequences = [[1,1,1,2,2,3], [1,2,2,2,3,3], [1,1,2,2,2,2]]) == [1, 0, 0, 2, 0, 0]
	assert candidate( [[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3]] ) == [1, 1, 2, 3]
	assert candidate(sequences=[[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3]]) == [1, 1, 2, 2, 3]
	assert candidate( [[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3]] ) == [1, 1, 2, 3]
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,4]]) == [1, 0, 2, 0, 0], "Test 6 failed"
	assert candidate(
	[[1,1,2,2,3],
	[1,2,2,3,3],
	[1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,4]]) == [1, 0, 2, 0, 0], "Test 4 failed"
	assert candidate( [[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,3]]) == [1, 0, 2, 0, 3]
	assert candidate(sequences = [[1,1,2],[1,1,2],[1,2,3]]) == [1,0,0]
	assert candidate(sequences=[[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,2]]) == [1,0,2,0,0]
	assert candidate( [[1,2,2,3], [1,2,2,3], [1,2,2,3]] ) == [1, 2, 2, 3]
	assert candidate( [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]] ) == [1, 0, 2, 0, 0], "candidate failed"
	assert candidate( [[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate(sequences = [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate( [[1,1,2,2,3],[1,2,3,3,3],[1,1,2,2,2],[1,1,2,2,2]] ) == [1, 0, 0, 0, 0], "candidate failed"
	assert candidate( [[1, 1, 2, 2, 3], [1, 2, 2, 3, 3], [1, 1, 2, 2, 2]] ) == [1, 0, 2, 0, 0]
	assert candidate( [[1,2,3,4,5],[1,1,1,1,1],[1,2,3,4,5]] ) == [1, 0, 0, 0, 0]
	assert candidate( [[1,1,2,2,3],[1,2,3,3,3],[1,1,2,2,2]] ) == [1, 0, 0, 0, 0], "candidate failed"
	assert candidate( [[1,1,2,3],[1,1,2,3],[1,1,2,3]] ) == [1, 1, 2, 3]
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,4]]) == [1, 0, 2, 0, 0], "Test 5 failed"
	assert candidate(sequences = [[1,1,2],[1,1,2],[1,1,2],[1,2,3]]) == [1,0,0]
	assert candidate( [[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3],[1,1,2,3]] ) == [1, 1, 2, 3]
	assert candidate(sequences = [[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate( [[1, 1, 2, 2, 3], [1, 2, 3, 3, 3], [1, 1, 2, 2, 2]] ) == [1, 0, 0, 0, 0]
	assert candidate(sequences=[[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,3]]) == [1, 0, 2, 0, 3]
	assert candidate(
	[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate(
	[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2],[1,2,2,3,3]]) == [1, 0, 2, 0, 0]
	assert candidate( [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2]] ) == [1,0,2,0,0]
	assert candidate(sequences = [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,3]]) == [1, 0, 2, 0, 3]
	assert candidate(
	[[1, 1, 2, 2, 3],
	[1, 2, 2, 3, 3],
	[1, 1, 2, 2, 2]]) == [1, 0, 2, 0, 0]
	assert candidate(
	[[1, 1, 2, 2, 3],
	 [1, 1, 2, 2, 3],
	 [1, 1, 2, 2, 3]]) == [1, 1, 2, 2, 3]
	assert candidate(sequences=[[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3]]) == [1, 1, 2, 2, 3]
	assert candidate(sequences = [[1,1,2,2,3], [1,1,2,2,2], [1,2,2,3,3]]) == [1,0,2,0,0], "Incorrect motif returned"
	assert candidate( [[1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3]]) == [1,1,2,2,3], "candidate([1,1,2,2,3],[1,1,2,2,3],[1,1,2,2,3]) failed"
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,4]]) == [1, 0, 2, 0, 0], "Test 2 failed"
	assert candidate( [[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2],[1,1,2,2,2]] ) == [1, 0, 2, 0, 0], "candidate failed"
	assert candidate(sequences=[[1,1,2,2,3],[1,2,2,3,3],[1,1,2,2,2],[1,1,2,2,2],[1,1,2,2,2]]) == [1, 0, 2, 0, 0]
	assert candidate(sequences = [[1,1,2,2,3], [1,2,2,3,3], [1,1,2,2,2]]) == [1,0,2,0,0], "Incorrect motif returned"
def test_check():
	check(get_motif)
