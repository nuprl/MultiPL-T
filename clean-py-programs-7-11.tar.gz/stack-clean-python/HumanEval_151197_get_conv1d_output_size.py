def get_conv1d_output_size(input_length:int, 
                           kernel_size:int, 
                           stride:int, 
                           padding:int) -> int:
    """Computes the output size of a 1d convolution.

    Args:
        input_length (int): Length of the sequence
        kernel_size (int): Spatial size of the kernel
        stride (int): Stride of the convolution
        padding (int): Spacing between kernel elements

    Returns:
        int: Output size
    """
    ### Canonical solution below ###
    input_length += 2 * padding
    return int((input_length - kernel_size) // stride + 1)


### Unit tests below ###
def check(candidate):
	assert candidate(10, 5, 1, 0) == 6
	assert candidate(10, 10, 1, 0) == 1
	assert candidate(input_length=10, kernel_size=3, stride=1, padding=2) == 12
	assert candidate(input_length=10, kernel_size=3, stride=1, padding=1) == 10
	assert candidate(2, 1, 1, 0) == 2
	assert candidate(100, 3, 2, 1) == 50
	assert candidate(input_length=10, 
                              kernel_size=3, 
                              stride=2, 
                              padding=1) == 5
	assert candidate(input_length=10, 
                              kernel_size=3, 
                              stride=1, 
                              padding=0) == 8
	assert candidate(28, 5, 1, 0) == 24
	assert candidate(10, 5, 2, 2) == 5
	assert candidate(7, 3, 2, 1) == 4
	assert candidate(5, 3, 3, 1) == 2
	assert candidate(input_length=10, kernel_size=3, stride=2, padding=1) == 5
	assert candidate(100, 3, 1, 0) == 98
	assert candidate(7, 3, 1, 0) == 5
	assert candidate(5, 3, 2, 1) == 3
	assert candidate(10, 2, 2, 0) == 5
	assert candidate(7, 3, 1, 1) == 7
	assert candidate(10, 3, 3, 1) == 4
	assert candidate(10, 3, 2, 1) == 5
	assert candidate(input_length=4, kernel_size=2, stride=2, padding=1) == 3
	assert candidate(100, 2, 2, 0) == 50
	assert candidate(0, 1, 1, 0) == 0
	assert candidate(5, 3, 1, 1) == 5
	assert candidate(10, 5, 3, 2) == 4
	assert candidate(10, 5, 1, 2) == 10
	assert candidate(1, 1, 1, 0) == 1
	assert candidate(10, 3, 1, 1) == 10
	assert candidate(10, 10, 5, 2) == 1
	assert candidate(input_length=10, 
                              kernel_size=2, 
                              stride=1, 
                              padding=0) == 9
	assert candidate(input_length=3, kernel_size=2, stride=2, padding=1) == 2
	assert candidate(input_length=10, kernel_size=2, stride=2, padding=0) == 5
	assert candidate(28, 5, 1, 2) == 28
	assert candidate(10, 2, 1, 0) == 9
	assert candidate(100, 3, 1, 1) == 100
	assert candidate(100, 3, 2, 0) == 49
def test_check():
	check(get_conv1d_output_size)
