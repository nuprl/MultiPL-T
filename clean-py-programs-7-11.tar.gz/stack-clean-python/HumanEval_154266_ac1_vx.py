def ac1_vx(w, l, x):
    """Shear at x - Beam simply supported - Uniformly dist. loads
    
    Calculates the shear in the beam at any location, x, along the beam due
    to a uniformly distributed load.
    
    v = w*(l/2-x)
    
    Args:
        w (float): uniformly distributed load
        
        l (float): length of beam between supports
        
        x (float): distance along beam from left support
    
    Returns:
        v (tuple(float, str)): shear at x
    
    Notes:
        1. Consistent units are the responsibility of the user. 
        2. For the reaction at the support use x = 0.0 or x = L.
        
    """
    ### Canonical solution below ###
    
    v = w*(l/2.0-x)
    
    text = (f'v = w*(l/2.0-x) \n' +
            f'v = {w:.3f}*({l:.2f}/2.0-{x:.2f}) \n' + 
            f'v = {v:.2f}')
    
    return v, text


### Unit tests below ###
def check(candidate):
	assert candidate(1, 1, 1.0)[0] == -0.5
	assert candidate(1, 10, 10)[0] == -5.0
	assert candidate(1.0, 4.0, 2.0)[0] == 0.0
	assert candidate(1.0, 10.0, 0.0)[0] == 5.0, 'candidate test 1 failed'
	assert candidate(1, 10, 5)[0] == 0.0
	assert candidate(50, 10, 5)[0] == 0
	assert candidate(1.0, 10.0, 5.0)[0] == 0.0, 'candidate test 4 failed'
	assert candidate(10, 10, 5.0)[0] == 0.0
	assert candidate(1, 10, 0)[0] == 5.0
	assert candidate(1.0, 10.0, 5.0)[0] == 0.0, 'Incorrect shear'
	assert candidate(2.0, 10.0, 0.0)[0] == 10.0, 'candidate test 2 failed'
	assert candidate(10, 10, 5)[0] == 0, 'candidate test 2 failed'
	assert candidate(1.0, 4.0, 3.0)[0] == -1.0
def test_check():
	check(ac1_vx)
