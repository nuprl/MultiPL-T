def _bcc(recipient):
    """
    Returns a query item matching messages that have certain recipients in
    the bcc field.

    Args:
        recipient (str): The recipient in the bcc field to match.

    Returns:
        The query string.

    """
    ### Canonical solution below ###

    return f"bcc:{recipient}"


### Unit tests below ###
def check(candidate):
	assert candidate(recipient="foo") == "bcc:foo"
	assert candidate("test") == "bcc:test"
	assert candidate(recipient="<EMAIL>") == "bcc:<EMAIL>"
	assert candidate('<EMAIL>') == 'bcc:<EMAIL>'
	assert candidate(None) == "bcc:None"
	assert candidate(recipient='foo') == "bcc:foo"
	assert candidate(recipient='<EMAIL>') == 'bcc:<EMAIL>'
	assert candidate(recipient='a') == 'bcc:a'
	assert candidate(recipient="test") == "bcc:test"
	assert candidate(recipient="recipient") == "bcc:recipient"
def test_check():
	check(_bcc)
