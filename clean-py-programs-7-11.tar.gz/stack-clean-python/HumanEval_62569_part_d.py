def part_d(f, x, h):
    """ Second-order forward difference"""
	### Canonical solution below ###    
    return (-3*f(x) + 4*f(x+h) - f(x+2*h)) / (2*h)

### Unit tests below ###
def check(candidate):
	assert candidate(lambda x: x**2, 1, 1) == 2
	assert candidate(lambda x: x**2, 0, 1e-8) == 0
	assert candidate(lambda x: 3*x, 1, 1) == 3
	assert candidate(lambda x: x**2, 1, 1) == 2.0
def test_check():
	check(part_d)
