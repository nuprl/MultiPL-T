def strip_quotes(want, got):
    """ 
     Strip quotes of doctests output values:
     
     >>> strip_quotes("'foo'")
     "foo"
     >>> strip_quotes('"foo"')
     "foo"
     """
	### Canonical solution below ###    
    def is_quoted_string(s):
        s = s.strip()
        return (len(s) >= 2
                and s[0] == s[-1]
                and s[0] in ('"', "'"))

    def is_quoted_unicode(s):
        s = s.strip()
        return (len(s) >= 3
                and s[0] == 'u'
                and s[1] == s[-1]
                and s[1] in ('"', "'"))

    if is_quoted_string(want) and is_quoted_string(got):
        want = want.strip()[1:-1]
        got = got.strip()[1:-1]
    elif is_quoted_unicode(want) and is_quoted_unicode(got):
        want = want.strip()[2:-1]
        got = got.strip()[2:-1]
    return want, got

### Unit tests below ###
def check(candidate):
	assert candidate('"foo"', '"foo"') == ("foo", "foo")
	assert candidate('u"foo"', 'u"foo"') == ("foo", "foo")
	assert candidate(
    '"foo"',
    "'foo'") == ("foo", "foo")
	assert candidate(u"'foo'", u'"foo"') == (u"foo", u"foo")
	assert candidate(
    'u"foo"',
    'u"foo"') == ("foo", "foo")
	assert candidate(u"u'foo'", u"u'bar'") == (u"foo", u"bar")
	assert candidate(r"u'foo'", r"u'foo'") == ("foo", "foo")
	assert candidate(r"u'foo'", r"u'foo'") == (r"foo", r"foo")
	assert candidate(u'"foo"', u"'bar'") == (u"foo", u"bar")
	assert candidate(r"u'foo'", r" u'foo' ") == ("foo", "foo")
	assert candidate(r"'foo'", r'"foo"') == ('foo', 'foo')
	assert candidate(r'u"foo"', r'u"foo"') == ('foo', 'foo')
	assert candidate(r'u"foo"', r'u"foo" ') == ("foo", "foo")
	assert candidate(r"'foo'", r" 'foo'") == ("foo", "foo")
	assert candidate(
    "'foo'",
    " 'foo'") == (
    "foo",
    "foo")
	assert candidate(r'u"foo"', r'u"foo"') == ("foo", "foo")
	assert candidate(r"u'foo'", r"u'foo' ") == ("foo", "foo")
	assert candidate(r"'foo'", r"'foo'") == (r"foo", r"foo")
	assert candidate(u'"foo"', u'"foo"') == (u"foo", u"foo")
	assert candidate('  "foo"  ', '"foo"') == ("foo", "foo")
	assert candidate(
    '"foo"',
    '"foo"') == ("foo", "foo")
	assert candidate(u'"foo"', u"   'foo'   ") == (u"foo", u"foo")
	assert candidate(r'"foo"', r' "foo"') == ("foo", "foo")
	assert candidate(r"u'foo'", r"u'bar'") == (r"foo", r"bar")
	assert candidate(u"'foo'", u' "foo" ') == (u"foo", u"foo")
	assert candidate(r'u"foo"', r' u"foo"') == ("foo", "foo")
	assert candidate(u'"foo"', u'"foo"') == ("foo", "foo")
	assert candidate('  "foo"  ', "'foo'") == ("foo", "foo")
	assert candidate("'foo'", '"foo"') == ("foo", "foo")
	assert candidate(u'u"foo"', u'u"foo"') == (u"foo", u"foo")
	assert candidate(r"'foo'", r"'foo' ") == ("foo", "foo")
	assert candidate(u"'foo'", u"'foo'") == (u"foo", u"foo")
	assert candidate(r'"foo"', r'"foo"') == ("foo", "foo")
	assert candidate(r'u"foo"', r'u"foo"') == (r"foo", r"foo")
	assert candidate(
    "'foo'",
    " 'f'oo' ") == (
    "foo",
    "f'oo")
	assert candidate(u'"foo"', u'"bar"') == (u"foo", u"bar")
	assert candidate(
    "'foo'",
    "'foo'") == (
    "foo",
    "foo")
	assert candidate(r"'foo'", r" 'foo' ") == ("foo", "foo")
	assert candidate(r'u"foo"', r' u"foo" ') == ("foo", "foo")
	assert candidate(u"u\"foo\"", u"u'foo'") == (u"foo", u"foo")
	assert candidate(u"'foo'", u'"foo"') == ("foo", "foo")
	assert candidate(u'"foo"', u"'foo'") == ("foo", "foo")
	assert candidate(
    "u'foo'",
    'u"foo"') == ("foo", "foo")
	assert candidate(
    "'foo'",
    " 'foo' ") == (
    "foo",
    "foo")
	assert candidate(r'"foo"', r'"foo" ') == ("foo", "foo")
	assert candidate(r"u'foo'", r'u"foo"') == (r"foo", r"foo")
	assert candidate(r"'foo'", r"'foo'") == ('foo', 'foo')
	assert candidate(r'"foo"', r'"foo"') == (r"foo", r"foo")
	assert candidate(r'"foo"', r"'foo'") == (r"foo", r"foo")
	assert candidate('"foo"', "'foo'") == ("foo", "foo")
	assert candidate(u"'foo'", u"'foo'") == ("foo", "foo")
	assert candidate(r"'foo'", r'"foo"') == (r"foo", r"foo")
	assert candidate(r'"foo"', r'"foo"') == ('foo', 'foo')
	assert candidate(u"u'foo'", u"u'foo'") == ("foo", "foo")
	assert candidate(u"u'foo'", u"u'foo'") == (u"foo", u"foo")
	assert candidate(r"u'foo'", r" u'foo'") == ("foo", "foo")
	assert candidate(r"'foo'", r"'foo'") == ("foo", "foo")
	assert candidate(u"'foo'", u'"bar"') == (u"foo", u"bar")
	assert candidate(u"'foo'", u" 'foo' ") == (u"foo", u"foo")
	assert candidate(r'"foo"', r"'foo'") == ("foo", "foo")
	assert candidate(
    "'foo'",
    "'f'oo' ") == (
    "foo",
    "f'oo")
	assert candidate(u'"foo"', u" 'foo' ") == (u"foo", u"foo")
	assert candidate('  "foo"  ',' "foo"  ') == ("foo", "foo")
	assert candidate(u"u'foo'", u"u\"foo\"") == (u"foo", u"foo")
	assert candidate(u"u\"foo\"", u"u\"foo\"") == (u"foo", u"foo")
	assert candidate(u"'foo'", u"'bar'") == (u"foo", u"bar")
	assert candidate("'foo'", "'foo'") == ("foo", "foo")
	assert candidate(r'"foo"', r' "foo" ') == ("foo", "foo")
	assert candidate(
    "'foo'",
    '"foo"') == ("foo", "foo")
	assert candidate(
    "'foo'",
    "'foo' ") == (
    "foo",
    "foo")
	assert candidate(r"'foo'", r'"foo"') == ("foo", "foo")
	assert candidate(
    "'foo'",
    '"foo"') == (
    "foo",
    "foo")
	assert candidate(
    "'foo'",
    " 'f'oo'") == (
    "foo",
    "f'oo")
	assert candidate(
    "'foo'",
    "'f'oo'") == (
    "foo",
    "f'oo")
	assert candidate(u'"foo"', u"'foo'") == (u"foo", u"foo")
	assert candidate(u"'foo'", u'  "foo"  ') == (u"foo", u"foo")
	assert candidate(
    "'foo'",
    "'foo'") == ("foo", "foo")
def test_check():
	check(strip_quotes)
