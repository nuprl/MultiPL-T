def boolean_mask(columns, target_columns):
    """ Create a boolean mask indicating location of target_columns in columns.
     
     Args:
     columns: (List[string]), list of all columns considered.
     target_columns: (List[string]), columns whose position
     should be masked as 1.
     
     Returns:
     List[bool]
     """
	### Canonical solution below ###  
  target_set = set(target_columns)
  return [x in target_set for x in columns]

### Unit tests below ###
def check(candidate):
	assert candidate(
    [], ['col1', 'col4']) == []
	assert candidate(
    ['a', 'b', 'c'], ['b']) == [False, True, False]
	assert candidate(columns=['a', 'b'], target_columns=['b']) == [False, True]
	assert candidate(columns=['a', 'b', 'c'], target_columns=['b']) == [False, True, False]
	assert candidate(
    ["a", "b", "c", "d"], ["a", "c"]) == [True, False, True, False]
	assert candidate(columns=["a", "b", "c"], target_columns=["b", "c"]) == [False, True, True]
	assert candidate(
    ['a', 'b', 'c'], ['a', 'b']) == [True, True, False]
	assert candidate(
    columns=['a', 'b', 'c'],
    target_columns=['a', 'b']) == [True, True, False]
	assert candidate(columns=["a", "b", "c"], target_columns=["c"]) == [False, False, True]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a', 'b', 'c', 'd']) == [True, True, True, True]
	assert candidate(columns=["a", "b", "c"], target_columns=["a"]) == [True, False, False]
	assert candidate(columns=['a', 'b', 'c'], target_columns=['a', 'b']) == [True, True, False]
	assert candidate(
    ['col1', 'col2', 'col3'], []) == [False, False, False]
	assert candidate(
    columns=['a', 'b', 'c'],
    target_columns=['b', 'c']) == [False, True, True]
	assert candidate(columns=["a", "b", "c"], target_columns=["a", "b", "c"]) == [True, True, True]
	assert candidate(
    columns=['col1', 'col2', 'col3'],
    target_columns=['col4']) == [False, False, False]
	assert candidate(columns=['a', 'b', 'c'], target_columns=['a']) == [True, False, False]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a', 'c']) == [True, False, True, False]
	assert candidate(columns=['a', 'b', 'c'],
                    target_columns=['b']) == [False, True, False]
	assert candidate(columns=['a', 'b'], target_columns=['a']) == [True, False]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a', 'b', 'c']) == [True, True, True, False]
	assert candidate(columns=["a", "b", "c"], target_columns=["d", "e", "f"]) == [False, False, False]
	assert candidate(columns=["a", "b", "c"], target_columns=["a", "c"]) == [True, False, True]
	assert candidate(
    ['col1', 'col2', 'col3'], ['col1', 'col3']) == [True, False, True]
	assert candidate(
    ['a', 'b', 'c'], []) == [False, False, False]
	assert candidate(columns=['a', 'b', 'c'], target_columns=['a', 'b', 'c']) == [True, True, True]
	assert candidate(
    ['a', 'b', 'c'], ['a', 'c']) == [True, False, True]
	assert candidate(
    ['a', 'b', 'c'], ['b', 'c']) == [False, True, True]
	assert candidate(columns=['a', 'b', 'c'], target_columns=['a', 'c']) == [True, False, True]
	assert candidate(
    columns=['a', 'b', 'c'],
    target_columns=['a', 'c']) == [True, False, True]
	assert candidate(
    ["a", "b", "c"], ["a", "b", "c"]) == [True, True, True]
	assert candidate(
    ['a', 'b', 'c'], ['a']) == [True, False, False]
	assert candidate(
    columns=['a', 'b', 'c'], target_columns=['a']) == [True, False, False]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['b', 'c']) == [False, True, True, False]
	assert candidate(
    columns=['a', 'b', 'c'],
    target_columns=['a', 'd']) == [True, False, False]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a', 'd']) == [True, False, False, True]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a', 'c', 'd']) == [True, False, True, True]
	assert candidate(
    columns=[],
    target_columns=[]) == []
	assert candidate(
    columns=['col1', 'col2', 'col3'],
    target_columns=['col1', 'col3']) == [True, False, True]
	assert candidate(columns=['a', 'b', 'c'], target_columns=['b', 'c']) == [False, True, True]
	assert candidate(
    columns=['a', 'b', 'c'], target_columns=['a', 'b', 'c']) == [True, True, True]
	assert candidate(
    columns=['a', 'b', 'c'],
    target_columns=[]) == [False, False, False]
	assert candidate(columns=["a", "b", "c"], target_columns=["a", "b"]) == [True, True, False]
	assert candidate(
    ['a', 'b', 'c'], ['a', 'b', 'c']) == [True, True, True]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a', 'b', 'd']) == [True, True, False, True]
	assert candidate(
    ['col1', 'col2', 'col3'], ['col1', 'col4']) == [True, False, False]
	assert candidate(
    ["a", "b", "c"], ["a", "b"]) == [True, True, False]
	assert candidate(columns=["a", "b", "c"], target_columns=["b"]) == [False, True, False]
	assert candidate(
    columns=[],
    target_columns=['a', 'b']) == []
	assert candidate(
    columns=['a', 'b', 'c'],
    target_columns=['d']) == [False, False, False]
	assert candidate(
    columns=['col1', 'col2', 'col3'],
    target_columns=['col1']) == [True, False, False]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a']) == [True, False, False, False]
	assert candidate(
    ['a', 'b', 'c', 'd'], ['a', 'b']) == [True, True, False, False]
	assert candidate(columns=['a', 'b'], target_columns=['a', 'b']) == [True, True]
	assert candidate(columns=['a', 'b', 'c'], target_columns=['c']) == [False, False, True]
	assert candidate(
    ['a', 'b', 'c', 'd'], []) == [False, False, False, False]
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f'], ['a', 'c', 'e']) == [True, False, True, False, True, False]
	assert candidate(
    columns=['a', 'b', 'c'],
    target_columns=['a']) == [True, False, False]
	assert candidate(
    columns=['a', 'b', 'c'], target_columns=['a', 'c']) == [True, False, True]
	assert candidate(
    ['col1', 'col2', 'col3'], ['col1']) == [True, False, False]
	assert candidate(
    ["a", "b", "c"], ["a", "c"]) == [True, False, True]
def test_check():
	check(boolean_mask)
