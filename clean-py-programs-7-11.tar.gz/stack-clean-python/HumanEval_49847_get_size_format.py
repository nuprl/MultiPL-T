def get_size_format(b, factor=1024, suffix="B"):
    """ 
     Scale bytes to its proper byte format
     e.g:
     1253656 => '1.20MB'
     1253656678 => '1.17GB'
     """
	### Canonical solution below ###    
    for unit in ["", "K", "M", "G", "T", "P", "E", "Z"]:
        if b < factor:
            return f"{b:.2f}{unit}{suffix}"
        b /= factor
    return f"{b:.2f}Y{suffix}"

### Unit tests below ###
def check(candidate):
	assert candidate(1000000000000000) == "909.49TB"
	assert candidate(1048576) == "1.00MB"
	assert candidate(1024 ** 5) == "1.00PB"
	assert candidate(1253656) == "1.20MB"
	assert candidate(1024 ** 7) == "1.00ZB"
	assert candidate(1024 ** 3) == "1.00GB"
	assert candidate(123456789) == "117.74MB"
	assert candidate(1000000) == "976.56KB"
	assert candidate(1000000000) == "953.67MB"
	assert candidate(1000000000000) == "931.32GB"
	assert candidate(1000000000000000000000) == "867.36EB"
	assert candidate(1024) == "1.00KB"
	assert candidate(100000) == "97.66KB"
	assert candidate(1073741824) == "1.00GB"
	assert candidate(10000000000000) == "9.09TB"
	assert candidate(1024 ** 8) == "1.00YB"
	assert candidate(1024 ** 6) == "1.00EB"
	assert candidate(1000000000000000000) == "888.18PB"
	assert candidate(1253656678) == "1.17GB"
	assert candidate(100000000000) == "93.13GB"
	assert candidate(1000000000000000000000000) == "847.03ZB"
	assert candidate(1024 ** 4) == "1.00TB"
	assert candidate(10000000) == "9.54MB"
def test_check():
	check(get_size_format)
