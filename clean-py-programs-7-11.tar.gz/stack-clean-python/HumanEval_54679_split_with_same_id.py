def split_with_same_id(samples):
    """ 
     split the list samples to sublists that with the same id.
     """
	### Canonical solution below ###    
    result = []
    if len(samples)==0:
        return result

    result.append([samples[0]])
    for i in range(1, len(samples)):
        if samples[i-1]['id']==samples[i]['id']:
            result[-1].append(samples[i])
        else:
            result.append([samples[i]])

    return result

### Unit tests below ###
def check(candidate):
	assert candidate([{'id': 1}]) == [[{'id': 1}]]
	assert candidate(
    [
        {'id': 1, 'a': 1, 'b': 1},
        {'id': 1, 'a': 2, 'b': 2},
        {'id': 1, 'a': 3, 'b': 3},
        {'id': 2, 'a': 4, 'b': 4},
        {'id': 2, 'a': 5, 'b': 5},
        {'id': 2, 'a': 6, 'b': 6},
        {'id': 3, 'a': 7, 'b': 7},
        {'id': 3, 'a': 8, 'b': 8},
        {'id': 3, 'a': 9, 'b': 9},
    ]
) == [
    [{'id': 1, 'a': 1, 'b': 1}, {'id': 1, 'a': 2, 'b': 2}, {'id': 1, 'a': 3, 'b': 3}],
    [{'id': 2, 'a': 4, 'b': 4}, {'id': 2, 'a': 5, 'b': 5}, {'id': 2, 'a': 6, 'b': 6}],
    [{'id': 3, 'a': 7, 'b': 7}, {'id': 3, 'a': 8, 'b': 8}, {'id': 3, 'a': 9, 'b': 9}],
]
	assert candidate(samples=[{'id':1}, {'id':1}, {'id':2}]) == [[{'id':1}, {'id':1}], [{'id':2}]]
	assert candidate([{"id":0},{"id":0}]) == [[{"id":0},{"id":0}]]
	assert candidate(
    [
        {"id": 1, "x": 10, "y": 10},
        {"id": 1, "x": 20, "y": 20},
        {"id": 1, "x": 30, "y": 30},
        {"id": 2, "x": 10, "y": 10},
        {"id": 2, "x": 20, "y": 20},
        {"id": 2, "x": 30, "y": 30},
    ]
) == [
    [
        {"id": 1, "x": 10, "y": 10},
        {"id": 1, "x": 20, "y": 20},
        {"id": 1, "x": 30, "y": 30},
    ],
    [
        {"id": 2, "x": 10, "y": 10},
        {"id": 2, "x": 20, "y": 20},
        {"id": 2, "x": 30, "y": 30},
    ],
]
	assert candidate(
    [
        {'id': 1, 'text': 'hi'},
        {'id': 1, 'text': 'hello'},
        {'id': 2, 'text': 'bye'},
        {'id': 1, 'text': 'goodbye'},
    ]
)==[
    [{'id': 1, 'text': 'hi'}, {'id': 1, 'text': 'hello'}],
    [{'id': 2, 'text': 'bye'}],
    [{'id': 1, 'text': 'goodbye'}],
]
	assert candidate(
    [
        {
            'id': '1',
            'text': 'This is a test',
            'label': '1'
        },
        {
            'id': '1',
            'text': 'This is another test',
            'label': '1'
        },
        {
            'id': '2',
            'text': 'This is a test',
            'label': '1'
        },
        {
            'id': '2',
            'text': 'This is another test',
            'label': '1'
        }
    ]
) == [
    [
        {
            'id': '1',
            'text': 'This is a test',
            'label': '1'
        },
        {
            'id': '1',
            'text': 'This is another test',
            'label': '1'
        }
    ],
    [
        {
            'id': '2',
            'text': 'This is a test',
            'label': '1'
        },
        {
            'id': '2',
            'text': 'This is another test',
            'label': '1'
        }
    ]
]
	assert candidate([{'id': 1, 'name': 'a'}]) == [[{'id': 1, 'name': 'a'}]]
	assert candidate(
    [{'id': 1, 'text': 'text1'}, {'id': 2, 'text': 'text2'}, {'id': 3, 'text': 'text3'}]
) == [[{'id': 1, 'text': 'text1'}], [{'id': 2, 'text': 'text2'}], [{'id': 3, 'text': 'text3'}]]
	assert candidate(
    [{'id': 1, 'a': 1}, {'id': 2, 'a': 2}, {'id': 2, 'a': 3}, {'id': 3, 'a': 4}, {'id': 3, 'a': 5}, {'id': 3, 'a': 6}]) == [
    [{'id': 1, 'a': 1}], [{'id': 2, 'a': 2}, {'id': 2, 'a': 3}], [{'id': 3, 'a': 4}, {'id': 3, 'a': 5}, {'id': 3, 'a': 6}]]
	assert candidate(
    [
        {'id': 1, 'name': 'a'},
        {'id': 1, 'name': 'b'},
        {'id': 2, 'name': 'c'},
    ]
) == [
    [{'id': 1, 'name': 'a'}, {'id': 1, 'name': 'b'}],
    [{'id': 2, 'name': 'c'}]
]
	assert candidate([{'id': 1}, {'id': 2}, {'id': 2}]) == [[{'id': 1}], [{'id': 2}, {'id': 2}]]
	assert candidate(
    [{'id': 1, 'x': 0}, {'id': 2, 'x': 1}]
) == [[{'id': 1, 'x': 0}], [{'id': 2, 'x': 1}]]
	assert candidate([{'id': 0, 'name': 'a'}, {'id': 0, 'name': 'b'}]) == \
    [[{'id': 0, 'name': 'a'}, {'id': 0, 'name': 'b'}]]
	assert candidate(
    [
        {'id': 1, 'a': 1},
        {'id': 1, 'a': 2},
        {'id': 2, 'a': 3},
    ]
) == [
    [{'id': 1, 'a': 1}, {'id': 1, 'a': 2}],
    [{'id': 2, 'a': 3}],
]
	assert candidate([]) == []
	assert candidate(
    [
        {'id':1, 'a':1},
        {'id':2, 'a':2},
        {'id':3, 'a':3},
        {'id':4, 'a':4},
    ]
) == [
    [
        {'id':1, 'a':1},
    ],
    [
        {'id':2, 'a':2},
    ],
    [
        {'id':3, 'a':3},
    ],
    [
        {'id':4, 'a':4},
    ],
]
	assert candidate([{"id":0}]) == [[{"id":0}]]
	assert candidate([{'id': 1}, {'id': 2}, {'id': 2}, {'id': 2}]) == [[{'id': 1}], [{'id': 2}, {'id': 2}, {'id': 2}]]
	assert candidate([{'id': 0, 'value': 1}, {'id': 0, 'value': 2}]) == [[{'id': 0, 'value': 1}, {'id': 0, 'value': 2}]]
	assert candidate(
    [{'id': 1}, {'id': 1}, {'id': 2}, {'id': 2}, {'id': 3}, {'id': 3}]) == \
    [[{'id': 1}, {'id': 1}], [{'id': 2}, {'id': 2}], [{'id': 3}, {'id': 3}]]
	assert candidate(
    [
        {'id': '1', 'a': 1},
    ]
) == [
    [{'id': '1', 'a': 1}],
]
	assert candidate(
    [
        {'id': '1', 'a': 1},
        {'id': '1', 'a': 2},
        {'id': '2', 'a': 3},
        {'id': '2', 'a': 4},
    ]
) == [
    [{'id': '1', 'a': 1}, {'id': '1', 'a': 2}],
    [{'id': '2', 'a': 3}, {'id': '2', 'a': 4}],
]
	assert candidate(
    [{'id': 0, 'name': 'a'},
     {'id': 0, 'name': 'b'},
     {'id': 1, 'name': 'c'}]) == \
    [[{'id': 0, 'name': 'a'}, {'id': 0, 'name': 'b'}],
     [{'id': 1, 'name': 'c'}]]
	assert candidate(samples=[{'id':1}]) == [[{'id':1}]]
	assert candidate(
    [{'id': 1, 'text': 'text1'}, {'id': 2, 'text': 'text2'}, {'id': 2, 'text': 'text3'}]
) == [[{'id': 1, 'text': 'text1'}], [{'id': 2, 'text': 'text2'}, {'id': 2, 'text': 'text3'}]]
	assert candidate([{'id': 0, 'name': 'a'}]) == [[{'id': 0, 'name': 'a'}]]
	assert candidate(
    [{'id': 0, 'value': 1}, {'id': 0, 'value': 2}, {'id': 0, 'value': 3}, {'id': 1, 'value': 4}]) == \
    [[{'id': 0, 'value': 1}, {'id': 0, 'value': 2}, {'id': 0, 'value': 3}], [{'id': 1, 'value': 4}]]
	assert candidate(
    [{'id': 1, 'x': 0}]
) == [[{'id': 1, 'x': 0}]]
	assert candidate(
    []
) == []
	assert candidate([{"id":0},{"id":0},{"id":1},{"id":1}]) == [[{"id":0},{"id":0}],[{"id":1},{"id":1}]]
	assert candidate([{'id': 0, 'name': 'a'}, {'id': 1, 'name': 'b'}]) == \
    [[{'id': 0, 'name': 'a'}],
     [{'id': 1, 'name': 'b'}]]
	assert candidate(samples=[]) == []
	assert candidate(samples=[{'id':1}, {'id':1}]) == [[{'id':1}, {'id':1}]]
	assert candidate([{'id': 0, 'value': 1}]) == [[{'id': 0, 'value': 1}]]
	assert candidate(
    [
        {'id':1, 'a':1},
        {'id':1, 'a':2},
        {'id':2, 'a':3},
        {'id':2, 'a':4},
    ]
) == [
    [
        {'id':1, 'a':1},
        {'id':1, 'a':2},
    ],
    [
        {'id':2, 'a':3},
        {'id':2, 'a':4},
    ],
]
	assert candidate(
    [{'id': 1, 'a': 1}, {'id': 1, 'a': 2}, {'id': 1, 'a': 3}]
) == [[{'id': 1, 'a': 1}, {'id': 1, 'a': 2}, {'id': 1, 'a': 3}]]
	assert candidate([{'id': 1}, {'id': 2}]) == [[{'id': 1}], [{'id': 2}]]
	assert candidate(
    [
        {'id': '1', 'a': 1},
        {'id': '2', 'a': 2},
    ]
) == [
    [{'id': '1', 'a': 1}],
    [{'id': '2', 'a': 2}],
]
	assert candidate(
    [{'id': 1, 'a': 1}, {'id': 1, 'a': 2}, {'id': 2, 'a': 3}, {'id': 2, 'a': 4}, {'id': 3, 'a': 5}, {'id': 3, 'a': 6}]) == [
    [{'id': 1, 'a': 1}, {'id': 1, 'a': 2}], [{'id': 2, 'a': 3}, {'id': 2, 'a': 4}], [{'id': 3, 'a': 5}, {'id': 3, 'a': 6}]]
	assert candidate(
    [{'id': 1, 'x': 0}, {'id': 1, 'x': 1}]
) == [[{'id': 1, 'x': 0}, {'id': 1, 'x': 1}]]
	assert candidate(
    [
        {'id': 1, 'x': 1},
        {'id': 1, 'x': 2},
        {'id': 1, 'x': 3},
        {'id': 2, 'x': 4},
        {'id': 2, 'x': 5},
        {'id': 2, 'x': 6},
        {'id': 3, 'x': 7},
        {'id': 3, 'x': 8},
        {'id': 3, 'x': 9},
    ]
) == [
    [{'id': 1, 'x': 1}, {'id': 1, 'x': 2}, {'id': 1, 'x': 3}],
    [{'id': 2, 'x': 4}, {'id': 2, 'x': 5}, {'id': 2, 'x': 6}],
    [{'id': 3, 'x': 7}, {'id': 3, 'x': 8}, {'id': 3, 'x': 9}],
]
	assert candidate(list()) == list()
	assert candidate(samples=[{'id':1}, {'id':2}]) == [[{'id':1}], [{'id':2}]]
	assert candidate([{'id':0}])==[[{'id':0}]]
	assert candidate(
    [{'id': 1, 'text': 'text1'}, {'id': 1, 'text': 'text2'}, {'id': 3, 'text': 'text3'}]
) == [[{'id': 1, 'text': 'text1'}, {'id': 1, 'text': 'text2'}], [{'id': 3, 'text': 'text3'}]]
def test_check():
	check(split_with_same_id)
