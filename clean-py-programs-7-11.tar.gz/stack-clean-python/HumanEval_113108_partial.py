def partial(func, *args, **kwargs):
    """ 
     Create a partial function during processing of a filter pipeline, like in x:fun(a,b)
     - the returned function represents application of (a,b) to a `fun`; whatever argument will be supplied later,
     it will be PREPENDED to the argument list, unlike in functools.partial() which APPENDS new arguments at the end.
     """
	### Canonical solution below ###    
    def newfunc(*newargs):
        return func(*(newargs + args), **kwargs)
    return newfunc

### Unit tests below ###
def check(candidate):
	assert candidate(lambda a, b: a + b, 1, b=2)() == 3
	assert candidate(lambda x, y, z: (x, y, z), z=3)(1, 2) == (1, 2, 3)
	assert candidate(lambda x,y:x+y, 1)(2) == 3
	assert candidate(lambda x, y: x + y, 1)(2) == 3
	assert candidate(lambda a,b: a+b, 1, b=2)() == 3
	assert candidate(lambda x,y:x+y, 3, y=2)() == 5
	assert candidate(lambda x,y:x+y, y=3)(2) == 5
	assert candidate(lambda a,b,c: a+b+c, 1, c=3)(2) == 6
	assert candidate(lambda x,y,z: x+y+z, 1, z=3)(2) == 6
	assert candidate(lambda a, b: a + b, b=2, a=1)() == 3
	assert candidate(lambda x, y: x + y, 1, 2)() == 3
	assert candidate(lambda a,b: a+b, 3, b=2)() == 5
	assert candidate(lambda a, b: a+b, 1, b=2)() == 3
	assert candidate(lambda x,y:x+y)(1, 2) == 3
	assert candidate(lambda x, y, z: x * y * z, 2, z=3)(3) == 18
	assert candidate(lambda x, y, z: x + y + z, 1, z=2)(3) == 6
	assert candidate(lambda x, y: x+y, 2)(3) == 5
	assert candidate(lambda a,b: a+b, b=3)(2) == 5
	assert candidate(lambda a, b: a + b, 2)(3) == 5
	assert candidate(lambda a,b: a+b, 1, 2)() == 3
	assert candidate(lambda a, b: a + b, 1)(2) == 3
	assert candidate(lambda x, y, z: x * y * z, 2, 3)(4) == 24
	assert candidate(lambda x,y: x+y, 3)(1) == 4
	assert candidate(lambda a,b,c: a+b+c, 1)(2,3) == 6
	assert candidate(lambda a,b: a+b, b=2)(1) == 3
	assert candidate(lambda a,b: a+b, b=2, a=1)() == 3
	assert candidate(lambda x, y: x + y, y=1)(2) == 3
	assert candidate(lambda a,b: a+b, b=1)(2) == 3
	assert candidate(lambda a,b: a+b, 3)(2) == 5
	assert candidate(lambda x,y:x+y, 3)(2) == 5
	assert candidate(lambda x,y:x+y, y=2)(1) == 3
	assert candidate(lambda x, y, z: x * y * z, 2, 3, 4)() == 24
	assert candidate(lambda a, b: a+b, 1)(2) == 3
	assert candidate(lambda x,y: x+y, 2)(3) == 5
	assert candidate(lambda a,b: a+b, 1)(2) == 3
def test_check():
	check(partial)
