def production_variant(
    """ Create a production variant description suitable for use in a ``ProductionVariant`` list.
     
     This is also part of a ``CreateEndpointConfig`` request.
     
     Args:
     model_name (str): The name of the SageMaker model this production variant references.
     instance_type (str): The EC2 instance type for this production variant. For example,
     'ml.c4.8xlarge'.
     initial_instance_count (int): The initial instance count for this production variant
     (default: 1).
     variant_name (string): The ``VariantName`` of this production variant
     (default: 'AllTraffic').
     initial_weight (int): The relative ``InitialVariantWeight`` of this production variant
     (default: 1).
     accelerator_type (str): Type of Elastic Inference accelerator for this production variant.
     For example, 'ml.eia1.medium'.
     For more information: https://docs.aws.amazon.com/sagemaker/latest/dg/ei.html
     
     Returns:
     dict[str, str]: An SageMaker ``ProductionVariant`` description
     """
	### Canonical solution below ###    model_name,
    instance_type,
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
):
    
    production_variant_configuration = {
        "ModelName": model_name,
        "InstanceType": instance_type,
        "InitialInstanceCount": initial_instance_count,
        "VariantName": variant_name,
        "InitialVariantWeight": initial_weight,
    }

    if accelerator_type:
        production_variant_configuration["AcceleratorType"] = accelerator_type

    return production_variant_configuration

### Unit tests below ###
def check(candidate):
	assert candidate(
    "model-1", "ml.c4.8xlarge", 1, "AllTraffic", 1, None
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-name",
    "ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
) == {
    "ModelName": "model-name",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model-1",
    instance_type="ml.c4.xlarge",
    initial_instance_count=2,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 2,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="foo",
    instance_type="bar",
    initial_instance_count=2,
    variant_name="baz",
    initial_weight=0.5,
) == {
    "ModelName": "foo",
    "InstanceType": "bar",
    "InitialInstanceCount": 2,
    "VariantName": "baz",
    "InitialVariantWeight": 0.5,
}
	assert candidate(
    "model-1", "ml.c4.8xlarge", 1, "AllTraffic", 1
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model", "ml.m4.xlarge", 1, "AllTraffic", 1, "ml.eia1.medium"
) == {
    "ModelName": "model",
    "InstanceType": "ml.m4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "my-model", "ml.m4.xlarge", initial_instance_count=1, variant_name="Variant1", initial_weight=1, accelerator_type=None
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.m4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "Variant1",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model-1", instance_type="ml.c4.8xlarge", initial_instance_count=1
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="model-1",
    instance_type="ml.c4.xlarge",
    initial_instance_count=2,
    variant_name="variant-1",
    initial_weight=2,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 2,
    "VariantName": "variant-1",
    "InitialVariantWeight": 2,
}
	assert candidate(
    model_name="model-1",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    initial_weight=0.5,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 0.5,
}
	assert candidate(
    model_name="foo", instance_type="ml.c4.8xlarge", initial_instance_count=1
) == {
    "ModelName": "foo",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model_name",
    instance_type="instance_type",
    initial_instance_count=1,
    variant_name="variant_name",
    initial_weight=1,
    accelerator_type="accelerator_type",
) == {
    "ModelName": "model_name",
    "InstanceType": "instance_type",
    "InitialInstanceCount": 1,
    "VariantName": "variant_name",
    "InitialVariantWeight": 1,
    "AcceleratorType": "accelerator_type",
}
	assert candidate(
    "model-1",
    "ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "model-1",
    "ml.c4.xlarge",
    initial_instance_count=2,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 2,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-name",
    "ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
) == {
    "ModelName": "model-name",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-1", "ml.c4.8xlarge", initial_instance_count=1, variant_name="AllTraffic", initial_weight=1, accelerator_type=None,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-1",
    "ml.m4.xlarge",
    initial_instance_count=2,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.m4.xlarge",
    "InitialInstanceCount": 2,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "model-1", "ml.c4.8xlarge", 1, "variant-1", 1
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "variant-1",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-1",
    "ml.c4.xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=2,
    accelerator_type=None,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 2,
}
	assert candidate(
    model_name="foo",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="TestTraffic",
    initial_weight=0.2,
) == {
    "ModelName": "foo",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "TestTraffic",
    "InitialVariantWeight": 0.2,
}
	assert candidate(
    model_name="model-2",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-2",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "model-1", "ml.c4.8xlarge", 1, "variant-1", 1, "ml.eia1.medium"
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "variant-1",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "my-model",
    "ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-name",
    "ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-name",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "my-model", "ml.m4.xlarge", initial_instance_count=1, variant_name="AllTraffic", initial_weight=1, accelerator_type=None
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.m4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-name", "ml.m4.xlarge", initial_instance_count=1, variant_name="AllTraffic", initial_weight=1, accelerator_type=None
) == {
    "ModelName": "model-name",
    "InstanceType": "ml.m4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="my-model",
    instance_type="ml.c4.4xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.c4.4xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-1", "ml.c4.8xlarge", initial_instance_count=1, variant_name="AllTraffic", initial_weight=1, accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="model",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="Variant",
    initial_weight=2,
) == {
    "ModelName": "model",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "Variant",
    "InitialVariantWeight": 2,
}
	assert candidate(
    model_name="model-1",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="MyVariant",
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "MyVariant",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model-1",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="MyVariant",
    initial_weight=0.2,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "MyVariant",
    "InitialVariantWeight": 0.2,
}
	assert candidate(
    "model-1",
    "ml.c4.xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model-1", instance_type="ml.c4.xlarge", initial_instance_count=1
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "my-model", "ml.c4.4xlarge", variant_name="AllTraffic", initial_weight=0.1, accelerator_type="ml.eia1.medium"
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.c4.4xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 0.1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="my-model",
    instance_type="ml.c4.4xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.c4.4xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "my-model",
    "ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "model-name", "ml.m4.xlarge", initial_instance_count=1, variant_name="AllTraffic", initial_weight=1, accelerator_type="ml.eia1.medium"
) == {
    "ModelName": "model-name",
    "InstanceType": "ml.m4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="foo",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "foo",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="model-1",
    instance_type="ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="foo",
    instance_type="bar",
    initial_instance_count=2,
    variant_name="baz",
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "foo",
    "InstanceType": "bar",
    "InitialInstanceCount": 2,
    "VariantName": "baz",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "model-2",
    "ml.c4.8xlarge",
    initial_instance_count=2,
    variant_name="Variant-1",
    initial_weight=2,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-2",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 2,
    "VariantName": "Variant-1",
    "InitialVariantWeight": 2,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="my-model",
    instance_type="ml.c4.4xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.c4.4xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "test-model", "ml.c4.8xlarge", 1, "AllTraffic", 1, "ml.eia1.medium"
) == {
    "ModelName": "test-model",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    model_name="model-1", instance_type="ml.c4.xlarge", initial_instance_count=2,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 2,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-1",
    "ml.c4.8xlarge",
    initial_instance_count=1,
    variant_name="AllTraffic",
    initial_weight=1,
    accelerator_type=None,
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-1", "ml.c4.8xlarge", initial_instance_count=1, variant_name="AllTraffic", initial_weight=1
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model", instance_type="ml.c4.8xlarge", initial_instance_count=1
) == {
    "ModelName": "model",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="foo", instance_type="bar", initial_instance_count=2, variant_name="baz"
) == {
    "ModelName": "foo",
    "InstanceType": "bar",
    "InitialInstanceCount": 2,
    "VariantName": "baz",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model_name",
    instance_type="instance_type",
    initial_instance_count=1,
    variant_name="variant_name",
    initial_weight=1,
) == {
    "ModelName": "model_name",
    "InstanceType": "instance_type",
    "InitialInstanceCount": 1,
    "VariantName": "variant_name",
    "InitialVariantWeight": 1,
}
	assert candidate(
    "model-1", "ml.c4.8xlarge", 1, "AllTraffic", 1, "ml.eia1.medium"
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.8xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
    "AcceleratorType": "ml.eia1.medium",
}
	assert candidate(
    "my-model", "ml.m4.xlarge", initial_instance_count=2, variant_name="AllTraffic", initial_weight=1, accelerator_type=None
) == {
    "ModelName": "my-model",
    "InstanceType": "ml.m4.xlarge",
    "InitialInstanceCount": 2,
    "VariantName": "AllTraffic",
    "InitialVariantWeight": 1,
}
	assert candidate(
    model_name="model-1",
    instance_type="ml.c4.xlarge",
    initial_instance_count=1,
    variant_name="MyVariant",
    initial_weight=0.1,
    accelerator_type="ml.eia1.medium",
) == {
    "ModelName": "model-1",
    "InstanceType": "ml.c4.xlarge",
    "InitialInstanceCount": 1,
    "VariantName": "MyVariant",
    "InitialVariantWeight": 0.1,
    "AcceleratorType": "ml.eia1.medium",
}
def test_check():
	check(production_variant)
