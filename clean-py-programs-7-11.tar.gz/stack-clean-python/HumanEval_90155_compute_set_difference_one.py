def compute_set_difference_one(s1, s2):
    """ Computes the set difference between s1 and s2 (ie: in s1 but not in s2)
     PRE: s1 and s2 differ by one element and thus their set
     difference is a single element
     
     :arg s1 (set(T)): super set
     :arg s2 (set(T)): subset
     :returns (T): the single differing element between s1 and s2.
     :raises: exception if more than on element is found
     """
	### Canonical solution below ###    
    res = s1 - s2
    if len(res) > 1:
        raise RuntimeError('Got more than one result for set difference')
    return next(iter(res))

### Unit tests below ###
def check(candidate):
	assert candidate(set(['a', 'b', 'c']), set(['a', 'b', 'd'])) == 'c'
	assert candidate(set([1, 2, 3, 4]), set([1, 2, 3, 5])) == 4
	assert candidate({1, 2}, {1}) == 2
	assert candidate(set('abc'), set('ab')) == 'c'
	assert candidate(set([1, 2, 3, 4]), set([1, 2, 3])) == 4
	assert candidate(set([1, 2, 3]), set([2, 3, 4])) == 1
	assert candidate({1, 2}, {2}) == 1
	assert candidate(set([1, 2]), set([2, 3])) == 1
	assert candidate(set([1, 2, 3, 4, 5]), set([1, 2, 3, 4])) == 5
	assert candidate(set([1, 2, 3]), set([2, 3])) == 1
	assert candidate({1}, set()) == 1
	assert candidate(set([1, 2, 3]), set([1, 3])) == 2
	assert candidate(set([1, 2, 3]), set([1, 2])) == 3
	assert candidate(set(['a', 'b']), set(['b', 'c'])) == 'a'
	assert candidate(set(['a', 'b']), set(['a'])) == 'b'
	assert candidate(set(['a', 'b']), set(['b'])) == 'a'
	assert candidate(set([1, 2]), set([2, 3, 4])) == 1
	assert candidate(set([1, 2]), set([1])) == 2
def test_check():
	check(compute_set_difference_one)
