def strip_leading_secret(path):
    """Strip leading 'secret/'"""
    ### Canonical solution below ###
    if path[:7].lower() == "secret/":
        path = path[7:]
    while path[-1] == "/":
        path = path[:-1]
    if not path:
        raise ValueError("A non-root secret path must be specified.")
    return path


### Unit tests below ###
def check(candidate):
	assert candidate("secret/foo///") == "foo"
	assert candidate(path="secret/foo/bar/baz") == "foo/bar/baz"
	assert candidate(path="secret/foo/bar/") == "foo/bar"
	assert candidate("secret/path/to/") == "path/to"
	assert candidate("secret/foo/bar") == "foo/bar"
	assert candidate(
    "secret/test/test2"
) == "test/test2"
	assert candidate("secret/foo") == "foo"
	assert candidate(
    "secret"
) == "secret"
	assert candidate("SECRET") == "SECRET"
	assert candidate(
    "secret/foo/bar/baz"
) == "foo/bar/baz"
	assert candidate("SECRET/foo/bar") == "foo/bar"
	assert candidate("foo/bar") == "foo/bar"
	assert candidate(
    "secret/test/test2/"
) == "test/test2"
	assert candidate('secret/foo/bar') == 'foo/bar'
	assert candidate("secret/path/") == "path"
	assert candidate("SECRET/foo") == "foo"
	assert candidate(
    "secret/test"
) == "test"
	assert candidate("SECRET/a") == "a"
	assert candidate("secret/path/to/secret") == "path/to/secret"
	assert candidate("secret/path/to/secret/") == "path/to/secret"
	assert candidate("secret/foo/") == "foo"
	assert candidate("secret") == "secret"
	assert candidate("secret/path") == "path"
	assert candidate("secret/foo/bar///") == "foo/bar"
	assert candidate('secret/foo/') == 'foo'
	assert candidate(
    "secret/test/"
) == "test"
	assert candidate("secret/a/b/") == "a/b"
	assert candidate("SECRET/path/to") == "path/to"
	assert candidate("secret/FOO") == "FOO"
	assert candidate(path="secret/foo/bar") == "foo/bar"
	assert candidate(path="secret/foo/") == "foo"
	assert candidate('secret/foo/bar/baz/') == 'foo/bar/baz'
	assert candidate('secret/foo/bar/') == 'foo/bar'
	assert candidate("secret/a") == "a"
	assert candidate("/secret/foo/bar") == "/secret/foo/bar"
	assert candidate("secret/path/to") == "path/to"
	assert candidate("foo") == "foo"
	assert candidate('secret/foo') == 'foo'
	assert candidate("secret/foo//") == "foo"
	assert candidate(path="secret/foo") == "foo"
	assert candidate('secret/foo/bar/baz') == 'foo/bar/baz'
	assert candidate("secret/a/b") == "a/b"
	assert candidate(
    "secret/foo/bar/baz/"
) == "foo/bar/baz"
	assert candidate("secret/foo/bar/") == "foo/bar"
	assert candidate("/secret/foo") == "/secret/foo"
	assert candidate("secret/foo/bar//") == "foo/bar"
def test_check():
	check(strip_leading_secret)
