def parse_time(x):
    """ Extract hour, day, month, and year from time category."""
	### Canonical solution below ###    
    from datetime import datetime
    DD = datetime.strptime(x, "%Y-%m-%d %H:%M:%S")
    time = DD.hour
    day = DD.day
    month = DD.month
    year = DD.year
    return time, day, month, year

### Unit tests below ###
def check(candidate):
	assert candidate(
    '2019-04-01 00:00:00') == (0, 1, 4, 2019)
	assert candidate(
    '2013-01-01 03:00:00') == (3, 1, 1, 2013)
	assert candidate(
    '2019-05-01 00:00:00') == (0, 1, 5, 2019)
	assert candidate('2016-03-11 11:46:43')[2] == 3
	assert candidate(
    '2013-01-01 00:00:00')[1] == 1, "Should be 1"
	assert candidate(
    "2016-04-11 09:00:00") == (9, 11, 4, 2016)
	assert candidate(
    "2016-04-11 05:00:00") == (5, 11, 4, 2016)
	assert candidate(
    '2016-03-11 11:46:43').__class__ == tuple
	assert candidate(
    '2011-01-01 01:00:00') == (1, 1, 1, 2011)
	assert candidate( '2015-07-04 01:00:00' ) == ( 1, 4, 7, 2015 )
	assert candidate(
    "2016-04-11 06:00:00") == (6, 11, 4, 2016)
	assert candidate(
    "2016-04-11 03:00:00") == (3, 11, 4, 2016)
	assert candidate(
    '2013-01-01 00:00:00') == (0, 1, 1, 2013)
	assert candidate( '2016-04-11 15:48:00' ) == (15,11,4,2016)
	assert candidate(u'2015-09-10 04:00:00') == (4, 10, 9, 2015)
	assert candidate("2013-03-31 18:31:03") == (18, 31, 3, 2013)
	assert candidate(u'2015-09-10 05:00:00') == (5, 10, 9, 2015)
	assert candidate(
    '2011-01-01 23:00:00') == (23, 1, 1, 2011)
	assert candidate(u'2015-09-10 03:00:00') == (3, 10, 9, 2015)
	assert candidate(
    '2013-01-01 00:00:00')[3] == 2013, "Should be 2013"
	assert candidate(
    "2016-04-11 08:00:00") == (8, 11, 4, 2016)
	assert candidate(
    '2019-01-01 00:00:00') == (0, 1, 1, 2019)
	assert candidate( '2015-08-11 10:07:00' ) == (10, 11, 8, 2015)
	assert candidate(u'2015-09-10 08:00:00') == (8, 10, 9, 2015)
	assert candidate( '2016-02-29 15:48:00' ) == (15,29,2,2016)
	assert candidate(
    '2016-04-11 13:00:00') == (13, 11, 4, 2016)
	assert candidate(
    "2016-04-11 01:00:00") == (1, 11, 4, 2016)
	assert candidate(
    "2016-04-11 07:00:00") == (7, 11, 4, 2016)
	assert candidate(
    '2019-02-01 00:00:00') == (0, 1, 2, 2019)
	assert candidate(u'2015-09-10 00:00:00') == (0, 10, 9, 2015)
	assert candidate(
    "2013-01-01 00:00:00") == (0, 1, 1, 2013)
	assert candidate( '2016-04-11 23:48:00' ) == (23,11,4,2016)
	assert candidate(
    '2019-07-01 00:00:00') == (0, 1, 7, 2019)
	assert candidate(
    '2011-01-02 00:00:00') == (0, 2, 1, 2011)
	assert candidate(u'2015-09-10 01:00:00') == (1, 10, 9, 2015)
	assert candidate(
    "2016-04-11 02:00:00") == (2, 11, 4, 2016)
	assert candidate( '2015-07-04 00:00:00' ) == ( 0, 4, 7, 2015 )
	assert candidate(
    '2013-01-01 21:00:00') == (21, 1, 1, 2013)
	assert candidate('2016-03-11 11:46:43')[0] == 11
	assert candidate(
    '2013-01-02 00:00:00') == (0, 2, 1, 2013)
	assert candidate( '2015-09-17 19:53:00' ) == (19, 17, 9, 2015)
	assert candidate(
    '2019-09-01 00:00:00') == (0, 1, 9, 2019)
	assert candidate(
    '2013-01-01 00:00:00')[0] == 0, "Should be 0"
	assert candidate(
    '2016-04-11 00:00:00') == (0, 11, 4, 2016)
	assert candidate(
    '2019-08-01 00:00:00') == (0, 1, 8, 2019)
	assert candidate(u'2015-09-10 06:00:00') == (6, 10, 9, 2015)
	assert candidate(u'2015-09-10 02:00:00') == (2, 10, 9, 2015)
	assert candidate( '2015-07-04 23:00:00' ) == ( 23, 4, 7, 2015 )
	assert candidate(
    '2013-01-01 00:00:00')[2] == 1, "Should be 1"
	assert candidate(
    '2019-03-01 00:00:00') == (0, 1, 3, 2019)
	assert candidate('2016-03-11 11:46:43')[1] == 11
	assert candidate(
    '2013-01-02 03:00:00') == (3, 2, 1, 2013)
	assert candidate('2016-03-11 11:46:43')[3] == 2016
	assert candidate(
    "2016-04-11 04:00:00") == (4, 11, 4, 2016)
	assert candidate(u'2015-09-10 07:00:00') == (7, 10, 9, 2015)
	assert candidate(
    '2011-01-01 00:00:00') == (0, 1, 1, 2011)
	assert candidate(
    '2016-03-11 11:46:43') == (11, 11, 3, 2016)
	assert candidate(
    '2019-06-01 00:00:00') == (0, 1, 6, 2019)
	assert candidate( '2016-04-11 00:48:00' ) == (0,11,4,2016)
def test_check():
	check(parse_time)
