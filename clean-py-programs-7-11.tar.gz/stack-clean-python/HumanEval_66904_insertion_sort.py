def insertion_sort(list):
    """
    Complexity: Worst case O(N^2) when sorted backwards
        Best Case O(N) when sorted
    """
    ### Canonical solution below ###
    for i in range(1,len(list)):
        tmp = list[i]
        j = i - 1
        while j >= 0 and list[j] > tmp:
            list[j+1] = list[j]
            j -= 1
        list[j+1] = tmp
    return list


### Unit tests below ###
def check(candidate):
	assert candidate(list([4,1,2,3])) == list([1,2,3,4])
	assert candidate(list([2,4,6,8,10,1,3,5,7,9])) == [1,2,3,4,5,6,7,8,9,10]
	assert candidate(candidate([9,8,7,6,5,4,3,2,1,0])) == [0,1,2,3,4,5,6,7,8,9]
	assert candidate(list([4, 2, 1, 3])) == [1, 2, 3, 4]
	assert candidate(list([3, 1])) == list([1, 3])
	assert candidate(list([1, 2, 3, 4, 5, 6])) == list([1, 2, 3, 4, 5, 6])
	assert candidate(list=[9,8,7,6,5,4,3,2,1,0]) == [0,1,2,3,4,5,6,7,8,9]
	assert candidate(list([1,4,2,3])) == list([1,2,3,4])
	assert candidate(list=[1,2,3,4,5,6,7,8,9,10]) == [1,2,3,4,5,6,7,8,9,10]
	assert candidate(list=[9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [1,2,3,4,5] ) == [1,2,3,4,5]
	assert candidate( [2, 4, 1, 3, 5] ) == [1, 2, 3, 4, 5]
	assert candidate(list([0])) == list([0])
	assert candidate(list([3,2,5,4,1])) == [1,2,3,4,5]
	assert candidate(list([2, 3, 1, 4])) == [1, 2, 3, 4]
	assert candidate([2,3,1,4]) == [1,2,3,4]
	assert candidate( [2, 1, 3] ) == [1, 2, 3]
	assert candidate(list=[2,1,3,5,4]) == [1,2,3,4,5]
	assert candidate(candidate([1,2,3,4,5,6,7,8,9])) == [1,2,3,4,5,6,7,8,9]
	assert candidate([10,9,8,7,6,5,4,3,2,1]) == list(range(1,11))
	assert candidate([2,3,1]) == [1,2,3]
	assert candidate( [5,4,3,2,1] ) == [1,2,3,4,5]
	assert candidate(list([1,4,3,2])) == [1,2,3,4]
	assert candidate(list([1,2,3])) == [1,2,3]
	assert candidate(list([2,3,1,5,4])) == list([1,2,3,4,5])
	assert candidate(list([1,2])) == [1,2]
	assert candidate( [1,6,4,3,5,2] ) == [1,2,3,4,5,6]
	assert candidate(candidate([0,1,2,3,4,5,6,7])) == [0,1,2,3,4,5,6,7]
	assert candidate(list([10,9,8,7,6,5,4,3,2,1])) == list([1,2,3,4,5,6,7,8,9,10])
	assert candidate(list([3, 1, 2, 4])) == [1, 2, 3, 4]
	assert candidate(list=[1,2,5,4,3]) == [1,2,3,4,5]
	assert candidate([1,5,3,4,2]) == [1,2,3,4,5]
	assert candidate(list([1])) == [1]
	assert candidate(list([2,1])) == list([1,2])
	assert candidate( [3, 2, 1] ) == [1, 2, 3]
	assert candidate(list([4, 2, 3, 1])) == [1, 2, 3, 4]
	assert candidate(list([2, 4, 1, 3])) == [1, 2, 3, 4]
	assert candidate(list([5,4,3,2,1,1,1,1,1])) == list([1,1,1,1,1,2,3,4,5])
	assert candidate([4,2,3,1]) == [1,2,3,4]
	assert candidate([1,2,3,4,10,11,12,13,14,5]) == [1,2,3,4,5,10,11,12,13,14]
	assert candidate(list([3,2,1,5,4])) == [1,2,3,4,5]
	assert candidate([1,2,3,4,10,11,12,13,14]) == [1,2,3,4,10,11,12,13,14]
	assert candidate(list([1,1,1,1,1])) == list([1,1,1,1,1])
	assert candidate( [1, 2] ) == [1, 2]
	assert candidate(list([2,4,6,8,3,1,5,7])) == [1,2,3,4,5,6,7,8]
	assert candidate([1]) == [1]
	assert candidate(list([1,2,3,4,5])) == [1,2,3,4,5]
	assert candidate([1,2,3,4,5]) == [1,2,3,4,5]
	assert candidate([2,1]) == [1,2]
	assert candidate(list=[5, 3, 8, 2, 9, 4, 1, 7, 6]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(list([3,2,1])) == [1,2,3]
	assert candidate(list([2, 1, 4, 3])) == [1, 2, 3, 4]
	assert candidate(list([5,4,3,2,1])) == [1,2,3,4,5]
	assert candidate(list([5,4,3,2,1,1,1])) == list([1,1,1,2,3,4,5])
	assert candidate(list=[5,4,3,2,1,0]) == [0,1,2,3,4,5]
	assert candidate(list([1,2,3,4])) == [1,2,3,4]
	assert candidate([3,1,4,2]) == [1,2,3,4]
	assert candidate(list()) == []
	assert candidate(list([1,2,3,4,5,6,7,8,9,10])) == list([1,2,3,4,5,6,7,8,9,10])
	assert candidate([]) == []
	assert candidate(list([5])) == list([5])
	assert candidate( [1, 2, 3] ) == [1, 2, 3]
	assert candidate(list([1, 2, 3, 4])) == [1, 2, 3, 4]
	assert candidate(list([1, 1, 1, 1, 1, 1, 1, 1, 1, 1])) == list([1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
	assert candidate(list([1,2,3])) == list([1,2,3])
	assert candidate( [3, 2, 1, 5, 4] ) == [1, 2, 3, 4, 5]
	assert candidate(candidate([8,7,6,5,4,3,2,1,0])) == [0,1,2,3,4,5,6,7,8]
	assert candidate(list([4,3,1,2])) == list([1,2,3,4])
	assert candidate(list(range(10))) == list(range(10))
	assert candidate(list([4,3,2,1])) == list([1,2,3,4])
	assert candidate(list([4,3,1,2])) == [1,2,3,4]
	assert candidate([2,1,3]) == [1,2,3]
	assert candidate([1,2]) == [1,2]
	assert candidate(list([7, 6, 5, 4, 3, 2, 1])) == list([1, 2, 3, 4, 5, 6, 7])
	assert candidate( [1,2,3,4,5,6] ) == [1,2,3,4,5,6]
	assert candidate(list([3,2,5,1,4])) == [1,2,3,4,5]
	assert candidate([5,1,3,2,4]) == [1,2,3,4,5]
	assert candidate(list=[2,1,3,4,5]) == [1,2,3,4,5]
	assert candidate(list([1,4,2,3])) == [1,2,3,4]
	assert candidate(list([2,3,1])) == list([1,2,3])
	assert candidate( [2, 1] ) == [1, 2]
	assert candidate(list([1,3,5,2,4])) == list([1,2,3,4,5])
	assert candidate( [5, 4, 3, 2, 1] ) == [1, 2, 3, 4, 5]
	assert candidate(list([5,4,3,2,1])) == list([1,2,3,4,5])
	assert candidate([4, 3, 1, 2, 0, 10, 5]) == [0, 1, 2, 3, 4, 5, 10]
	assert candidate(list([5,4,3,2,1,1,1,1,1,1,1,1])) == list([1,1,1,1,1,1,1,1,2,3,4,5])
	assert candidate(list([2,4,6,8,3,1,5])) == list([1,2,3,4,5,6,8])
	assert candidate(list([4, 3, 2, 1])) == [1, 2, 3, 4]
	assert candidate([1,3,5,2,4]) == [1,2,3,4,5]
	assert candidate(list([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])) == list([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
	assert candidate(list([3,1,2])) == list([1,2,3])
	assert candidate([3,4,1,2]) == [1,2,3,4]
	assert candidate(list([10,8,6,4,2])) == list([2,4,6,8,10])
	assert candidate(list([5,4,3,2,1,1,1,1,1,1])) == list([1,1,1,1,1,1,2,3,4,5])
	assert candidate( [5, 4, 3, 1, 2] ) == [1, 2, 3, 4, 5]
	assert candidate(list([4,1,3,2])) == [1,2,3,4]
	assert candidate(list=[2]) == [2]
	assert candidate(list([4,1,3,2])) == list([1,2,3,4])
	assert candidate(list([1,3,2,4])) == list([1,2,3,4])
	assert candidate(list([2,4,6,8,1,3,5,7])) == [1,2,3,4,5,6,7,8]
	assert candidate(list([])) == list([])
	assert candidate( [1, 3, 2] ) == [1, 2, 3]
	assert candidate(list([2,3,1,4])) == list([1,2,3,4])
	assert candidate(list(range(100))) == list(range(100))
	assert candidate([3,2,1]) == [1,2,3]
	assert candidate(list([2,3,1])) == [1,2,3]
	assert candidate(list([3, 1, 2, 4, 5, 6, 7])) == list([1, 2, 3, 4, 5, 6, 7])
	assert candidate( [1, 2, 3, 5, 4] ) == [1, 2, 3, 4, 5]
	assert candidate( [5,4,3,1,2] ) == [1,2,3,4,5]
	assert candidate(list([1,2,3,4])) == list([1,2,3,4])
	assert candidate(list([2,4,1,3])) == list([1,2,3,4])
	assert candidate([4, 3, 1, 2, 0]) == [0, 1, 2, 3, 4]
	assert candidate(list([4,1,2,3])) == [1,2,3,4]
	assert candidate(list([1,3,2])) == list([1,2,3])
	assert candidate([1,4,2,3]) == [1,2,3,4]
	assert candidate([5,4,3,2,1]) == [1,2,3,4,5]
	assert candidate(list([3, 1, 2, 4])) == list([1, 2, 3, 4])
	assert candidate(list([5,4,3,2,1,1])) == list([1,1,2,3,4,5])
	assert candidate([1,2,3,4,5,6,7,8,9,10]) == list(range(1,11))
	assert candidate(list([1, 2, 4, 3])) == [1, 2, 3, 4]
	assert candidate(list([3,1,2])) == [1,2,3]
	assert candidate(list=[1, 3, 2, 8, 9, 4, 7, 6]) == [1, 2, 3, 4, 6, 7, 8, 9]
	assert candidate(list=[]) == []
	assert candidate([1,5,3,2,4]) == [1,2,3,4,5]
	assert candidate(list([3, 2, 1])) == [1, 2, 3]
	assert candidate(list([1, 3])) == list([1, 3])
	assert candidate( [1, 2, 3, 4, 5, 6] ) == [1, 2, 3, 4, 5, 6]
	assert candidate(list=[0,1,2,3,4,5,6,7,8,9]) == [0,1,2,3,4,5,6,7,8,9]
	assert candidate(list([5,4,3,2,1,1,1,1])) == list([1,1,1,1,2,3,4,5])
	assert candidate(list([3,2,1])) == list([1,2,3])
	assert candidate(list([2, 3, 4, 1])) == [1, 2, 3, 4]
	assert candidate(list=[1,2,3,4,5]) == [1,2,3,4,5]
	assert candidate(candidate([1,2,3,4,5,6,7,8,9,0])) == [0,1,2,3,4,5,6,7,8,9]
	assert candidate( [1, 3, 5, 2, 4] ) == [1, 2, 3, 4, 5]
	assert candidate(candidate([9,8,7,6,5,4,3,2,1])) == [1,2,3,4,5,6,7,8,9]
	assert candidate(list([1])) == list([1])
	assert candidate(list([2, 4, 3, 1])) == [1, 2, 3, 4]
	assert candidate(list=[5,4,3,2,1]) == [1,2,3,4,5]
	assert candidate( [2, 1, 3, 5, 4] ) == [1, 2, 3, 4, 5]
	assert candidate(list([2,4,6,8,10])) == list([2,4,6,8,10])
	assert candidate(list([4,3,2,1,5])) == list([1,2,3,4,5])
	assert candidate(candidate([0,1,2,3,4,5,6,7,8,9])) == [0,1,2,3,4,5,6,7,8,9]
	assert candidate( [5, 3, 2, 1, 4] ) == [1, 2, 3, 4, 5]
	assert candidate(candidate([0,1,2,3,4,5,6,7,8])) == [0,1,2,3,4,5,6,7,8]
	assert candidate(list([2,1,3])) == [1,2,3]
	assert candidate(list([5,2,4,6,1,3])) == [1,2,3,4,5,6]
	assert candidate(list([1,2,3,4,5])) == list([1,2,3,4,5])
	assert candidate(list([4, 2, 1, 3])) == list([1, 2, 3, 4])
	assert candidate([1,2,3,4,5,6,7,8,9,10]) == [1,2,3,4,5,6,7,8,9,10]
	assert candidate(list(range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(list([2,1])) == [1,2]
	assert candidate(list([2,1,3])) == list([1,2,3])
	assert candidate([3,4,1,2,10,11,12,13,14]) == [1,2,3,4,10,11,12,13,14]
	assert candidate(list([4,3,2,1])) == [1,2,3,4]
	assert candidate(list([5, 4, 3, 2, 1, 1, 1])) == list([1, 1, 1, 2, 3, 4, 5])
	assert candidate( [4, 5, 3, 2, 1] ) == [1, 2, 3, 4, 5]
	assert candidate([4,3,1,2]) == [1,2,3,4]
	assert candidate( [1] ) == [1]
	assert candidate(list([2,1,3,4,5])) == [1,2,3,4,5]
	assert candidate(list([1,2])) == list([1,2])
	assert candidate(list([1,3,2])) == [1,2,3]
	assert candidate([1,3,2]) == [1,2,3]
	assert candidate( [2,1,5,4,3] ) == [1,2,3,4,5]
	assert candidate(list(reversed(range(5)))) == [0, 1, 2, 3, 4]
	assert candidate(list([1,2,4,3])) == [1,2,3,4]
	assert candidate(list(reversed(range(10)))) == list(range(10))
	assert candidate(list=[1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [6,5,4,3,2,1] ) == [1,2,3,4,5,6]
	assert candidate([4,2,1,3]) == [1,2,3,4]
	assert candidate(list([6, 5, 4, 3, 2, 1])) == list([1, 2, 3, 4, 5, 6])
	assert candidate(list([3,1,4,2])) == list([1,2,3,4])
	assert candidate( [1, 2, 3, 4, 5] ) == [1, 2, 3, 4, 5]
	assert candidate(list()) == list()
	assert candidate(list([4,2,3,1])) == list([1,2,3,4])
	assert candidate(list([5,4,3,2,1,1,1,1,1,1,1])) == list([1,1,1,1,1,1,1,2,3,4,5])
	assert candidate(list(range(5))) == [0, 1, 2, 3, 4]
	assert candidate( [6,2,4,3,5,1] ) == [1,2,3,4,5,6]
	assert candidate(list([1,4,3,2])) == list([1,2,3,4])
	assert candidate([3,1,2]) == [1,2,3]
	assert candidate(list([3,1,2,4])) == list([1,2,3,4])
def test_check():
	check(insertion_sort)
