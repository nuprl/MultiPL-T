def isogram(word):
    """ Determine if word is isogram.
     
     :param: word - string.
     :return: True word is isogram and False otherwise.
     """
	### Canonical solution below ###    
    word_list = [l for l in word.lower() if l.isalpha()]
    return len(set(word_list)) == len(word_list)

### Unit tests below ###
def check(candidate):
	assert candidate(u"isIsogram") == False
	assert candidate(u"Dermatoglyphics") == True
	assert candidate(u"" ) == True
	assert candidate(u'') == True
	assert candidate(u'moOse') == False
	assert candidate('') == True
	assert candidate(u"aba") == False
	assert candidate(u"candidate") == True
	assert candidate(u"moOse123") == False
	assert candidate('aba') == False
	assert candidate(u"moOse" ) == False
	assert candidate(u"aba" ) == False
	assert candidate('moOse') == False
	assert candidate(u"isIsogram" ) == False
	assert candidate(u"aba123") == False
	assert candidate(u"isIsogram123") == False
	assert candidate(u"Dermatoglyphics" ) == True
	assert candidate('candidate') == True
	assert candidate(u'isIsogram') == False
	assert candidate(u'candidate') == True
	assert candidate(u"") == True
	assert candidate(u'aba') == False
	assert candidate(u'Dermatoglyphics') == True
	assert candidate(u"moOse") == False
def test_check():
	check(isogram)
