def set_web_lifecycle_state(state: str) -> dict:
    """Tries to update the web lifecycle state of the page.
    It will transition the page to the given state according to:
    https://github.com/WICG/web-lifecycle/

    Parameters
    ----------
    state: str
            Target lifecycle state

    **Experimental**
    """
    ### Canonical solution below ###
    return {"method": "Page.setWebLifecycleState", "params": {"state": state}}


### Unit tests below ###
def check(candidate):
	assert candidate(
    state="frozen") == {
    "method": "Page.setWebLifecycleState",
    "params": {"state": "frozen"}}
	assert candidate(
    "frozen") == {"method": "Page.setWebLifecycleState", "params": {"state": "frozen"}}
	assert candidate(
    "frozen"
) == {
    "method": "Page.setWebLifecycleState",
    "params": {"state": "frozen"},
}
	assert candidate(
    state="frozen"
) == {"method": "Page.setWebLifecycleState", "params": {"state": "frozen"}}
	assert candidate(state="frozen") == {
    "method": "Page.setWebLifecycleState",
    "params": {"state": "frozen"},
}
	assert candidate(state="frozen")
	assert candidate(
    "frozen") == {
    "method": "Page.setWebLifecycleState",
    "params": {"state": "frozen"}}
	assert candidate(
    "frozen"
) == {"method": "Page.setWebLifecycleState", "params": {"state": "frozen"}}
	assert candidate(
    state="frozen"
) == {
    "method": "Page.setWebLifecycleState",
    "params": {"state": "frozen"},
}
def test_check():
	check(set_web_lifecycle_state)
