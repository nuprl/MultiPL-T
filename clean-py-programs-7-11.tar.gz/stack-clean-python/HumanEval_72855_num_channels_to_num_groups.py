def num_channels_to_num_groups(num_channels):
    """Returns number of groups to use in a GroupNorm layer with a given number
    of channels. Note that these choices are hyperparameters.

    Args:
        num_channels (int): Number of channels.
    """
    ### Canonical solution below ###
    if num_channels < 8:
        return 1
    if num_channels < 32:
        return 2
    if num_channels < 64:
        return 4
    if num_channels < 128:
        return 8
    if num_channels < 256:
        return 16
    else:
        return 32


### Unit tests below ###
def check(candidate):
	assert candidate(1024) == 32
	assert candidate(33) == 4
	assert candidate(65) == 8
	assert candidate(4) == 1
	assert candidate(2) == 1
	assert candidate(1023) == 32
	assert candidate(128) == 16
	assert candidate(256) == 32
	assert candidate(8) == 2
	assert candidate(127) == 8
	assert candidate(63) == 4
	assert candidate(16) == 2
	assert candidate(255) == 16
	assert candidate(1) == 1
	assert candidate(512) == 32
	assert candidate(6) == 1
	assert candidate(3) == 1
	assert candidate(1025) == 32
	assert candidate(32) == 4
	assert candidate(5) == 1
	assert candidate(257) == 32
	assert candidate(31) == 2
	assert candidate(511) == 32
	assert candidate(129) == 16
	assert candidate(64) == 8
	assert candidate(1000) == 32
	assert candidate(9) == 2
	assert candidate(7) == 1
def test_check():
	check(num_channels_to_num_groups)
