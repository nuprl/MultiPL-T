def capitalize(str):
    """ 
     Capitalizes first character of the String
     """
	### Canonical solution below ###    
    return str.capitalize()

### Unit tests below ###
def check(candidate):
	assert candidate('HELLO WORLD') == 'Hello world'
	assert candidate('Abc') == 'Abc'
	assert candidate("abc def") == "Abc def"
	assert candidate('abc') == 'Abc'
	assert candidate('Abcdef') == 'Abcdef'
	assert candidate("abc\ndef") == "Abc\ndef"
	assert candidate('word') == 'Word'
	assert candidate("TEST STRING") == "Test string"
	assert candidate("Ab") == "Ab"
	assert candidate('A123') == 'A123'
	assert candidate('123abc') == '123abc'
	assert candidate("FOO") == "Foo"
	assert candidate("abc") == "Abc"
	assert candidate('cat ') == 'Cat '
	assert candidate( "capiTaliZation" ) == "Capitalization"
	assert candidate('12345') == '12345'
	assert candidate('!@#$%^&*()') == '!@#$%^&*()'
	assert candidate('PIEPIEPIE') == 'Piepiepie'
	assert candidate('a') == 'A'
	assert candidate("abc\tdef") == "Abc\tdef"
	assert candidate('ABCDEF') == 'Abcdef'
	assert candidate('abc123') == 'Abc123'
	assert candidate("12345") == "12345"
	assert candidate('cat') == 'Cat'
	assert candidate('A1b2c3d4') == 'A1b2c3d4'
	assert candidate('bat') == 'Bat'
	assert candidate('1cat') == '1cat'
	assert candidate("HELLO WORLD") == "Hello world"
	assert candidate("") == ""
	assert candidate("hello world") == "Hello world"
	assert candidate('t') == 'T'
	assert candidate("Foo") == "Foo"
	assert candidate('FOO BAR') == 'Foo bar'
	assert candidate("another test string") == "Another test string"
	assert candidate(
    "hello world") == "Hello world", "String was not candidated correctly"
	assert candidate("def") == "Def"
	assert candidate("bat") == "Bat"
	assert candidate('a!') == 'A!'
	assert candidate('i like pie') == 'I like pie'
	assert candidate("fOO") == "Foo"
	assert candidate("foo bar") == "Foo bar"
	assert candidate(
    "c") == "C", "String was not candidated correctly"
	assert candidate('i') == 'I'
	assert candidate('hello world!') == 'Hello world!'
	assert candidate('foo bar') == 'Foo bar'
	assert candidate('foo') == 'Foo'
	assert candidate('Bat') == 'Bat'
	assert candidate('a word') == 'A word'
	assert candidate("a") == "A"
	assert candidate("abc\rdef") == "Abc\rdef"
	assert candidate('a1b2c3d4') == 'A1b2c3d4'
	assert candidate( "hello" ) == "Hello"
	assert candidate('!a') == '!a'
	assert candidate('abc def') == 'Abc def'
	assert candidate('cat!') == 'Cat!'
	assert candidate('Foo') == 'Foo'
	assert candidate('PIE') == 'Pie'
	assert candidate("1a2b3c4d5e") == "1a2b3c4d5e"
	assert candidate('Abc def 123') == 'Abc def 123'
	assert candidate("foo") == "Foo"
	assert candidate('cat and dog') == 'Cat and dog'
	assert candidate("XYZ") == "Xyz"
	assert candidate("ABC") == "Abc"
	assert candidate("") == "", "Empty string was not returned empty"
	assert candidate('matt') == 'Matt'
	assert candidate('abc def 123') == 'Abc def 123'
	assert candidate('') == ''
	assert candidate('abcdef') == 'Abcdef'
	assert candidate(
    'word') == 'Word'
	assert candidate("c") == "C", "String was not candidated correctly"
	assert candidate("hello") == "Hello"
	assert candidate('hello world') == 'Hello world'
	assert candidate('hello WORLD') == 'Hello world'
def test_check():
	check(capitalize)
