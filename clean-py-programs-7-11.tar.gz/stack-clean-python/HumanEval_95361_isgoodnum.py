def isgoodnum(n):
    """ determine if an argument is actually a scalar number, and not boolean
    """
    ### Canonical solution below ###
    return (not isinstance(n,bool)) and isinstance(n,(int,float))


### Unit tests below ###
def check(candidate):
	assert candidate(3.0) == True
	assert not candidate('0')
	assert not candidate([1,2,3])
	assert not candidate({"a":1})
	assert candidate(1.0) == True
	assert candidate(3.0)
	assert not candidate('1.0')
	assert not candidate((1,))
	assert candidate(1.1)
	assert not candidate("hello")
	assert not candidate("bad")
	assert not candidate("True")
	assert not candidate('1.0+1.0j')
	assert not candidate(1+1j)
	assert not candidate([True])
	assert not candidate([0])
	assert not candidate(None)
	assert not candidate('1+1j')
	assert not candidate([1+1j])
	assert candidate(False) == False
	assert not candidate(complex(1))
	assert not candidate('True')
	assert candidate('3') == False
	assert candidate(3)
	assert not candidate('a')
	assert candidate(1.0)
	assert not candidate("1.0")
	assert candidate([1,2]) == False
	assert candidate(2.0)
	assert not candidate(False)
	assert candidate((1,2)) == False
	assert candidate(0)
	assert not candidate([1.0])
	assert candidate("True") == False
	assert not candidate((1,2))
	assert not candidate('')
	assert candidate("string") == False
	assert not candidate([1])
	assert candidate(1) == True
	assert not candidate(complex(1,1))
	assert not candidate("a")
	assert candidate(2.3)
	assert candidate(True) == False
	assert candidate(None) == False
	assert candidate(3) == True
	assert candidate(1.)
	assert not candidate([1,2])
	assert not candidate(1.0+1.0j)
	assert not candidate(lambda x: x)
	assert not candidate("1")
	assert not candidate("False")
	assert candidate(2)
	assert candidate(1)
	assert not candidate('False')
	assert candidate(1+1j) == False
	assert not candidate(True)
	assert not candidate([False])
	assert not candidate('1')
def test_check():
	check(isgoodnum)
