def parse_svg_color_hex(hex_string):
    """ Parse SVG Color by Hex String"""
	### Canonical solution below ###    
    h = hex_string.lstrip('#')
    size = len(h)
    if size == 8:
        return int(h[:8], 16)
    elif size == 6:
        return int(h[:6], 16)
    elif size == 4:
        return int(h[3] + h[3] + h[2] + h[2] + h[1] + h[1] + h[0] + h[0], 16)
    elif size == 3:
        return int(h[2] + h[2] + h[1] + h[1] + h[0] + h[0], 16)
    return 0xFF000000

### Unit tests below ###
def check(candidate):
	assert candidate('#FFFFFFFF') == 0xFFFFFFFF
	assert candidate("") == 0xFF000000
	assert candidate('#000000000000') == 0xFF000000
	assert candidate( '#12345678' ) == 0x12345678
	assert candidate('FFFFFFFF') == 0xFFFFFFFF
	assert candidate("#12345678") == 0x12345678
	assert candidate( "#12345678" ) == 0x12345678
	assert candidate('#00000000') == 0
	assert candidate('#ffffFfFF') == 0xFFFFFFFF
	assert candidate('#12345678') == 0x12345678
	assert candidate('#ffffffff') == 0xFFFFFFFF
	assert candidate("#000000000") == 0xFF000000
	assert candidate("0x000") == 0xFF000000
	assert candidate("0x0000000") == 0xFF000000
	assert candidate('#000000000') == 0xFF000000
	assert candidate('#00000') == 0xFF000000
	assert candidate('#ff0000000') == 0xFF000000
	assert candidate( "#112233FF" ) == 0x112233FF
	assert candidate("0x00000000") == 0xFF000000
	assert candidate('#0000000000') == 0xFF000000
	assert candidate('#ffff0000') == 0xFFFF0000
	assert candidate( "#1122337F" ) == 0x1122337F
	assert candidate("#0") == 0xFF000000
	assert candidate("#00000000000") == 0xFF000000
	assert candidate('#00000000') == 0x00000000
	assert candidate("0x00000") == 0xFF000000
	assert candidate("#0000000000") == 0xFF000000
	assert candidate('#') == 0xFF000000
	assert candidate('') == 0xFF000000
	assert candidate("#000000000000") == 0xFF000000
	assert candidate('#0000000') == 0xFF000000
	assert candidate('#000000ff0') == 0xFF000000
	assert candidate(u'#00') == 0xFF000000
	assert candidate('#ff000000f') == 0xFF000000
	assert candidate("#") == 0xFF000000
	assert candidate("#1") == 0xFF000000
	assert candidate("#00000") == 0xFF000000
	assert candidate('#00000000000') == 0xFF000000
	assert candidate( '#11223344' ) == 0x11223344
	assert candidate('#0') == 0xFF000000
	assert candidate("#0000000") == 0xFF000000
	assert candidate("#FF0000FF") == 0xFF0000FF
	assert candidate("#00") == 0xFF000000
	assert candidate('#f00f') == 0xFF0000FF
	assert candidate(u'#0') == 0xFF000000
	assert candidate('##') == 0xFF000000
	assert candidate('#00') == 0xFF000000
	assert candidate('#ff000000') == 0xFF000000
def test_check():
	check(parse_svg_color_hex)
