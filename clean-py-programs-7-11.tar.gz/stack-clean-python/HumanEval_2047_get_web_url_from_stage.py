def get_web_url_from_stage(stage):
    """ Return the full URL of given web environment.
     
     :param stage: environment name. Can be one of 'preview', 'staging',
     'production' or 'dev' (aliases: 'local', 'development').
     """
	### Canonical solution below ###    
    if stage in ['local', 'dev', 'development']:
        return 'http://localhost'

    stage_domains = {
        'preview': 'https://www.preview.marketplace.team',
        'staging': 'https://www.staging.marketplace.team',
        'production': 'https://www.digitalmarketplace.service.gov.uk',
    }
    return stage_domains[stage]

### Unit tests below ###
def check(candidate):
	assert candidate('development') == 'http://localhost'
	assert candidate(stage='preview') == 'https://www.preview.marketplace.team'
	assert candidate(
    'development'
) == 'http://localhost'
	assert candidate('production') == 'https://www.digitalmarketplace.service.gov.uk'
	assert candidate('local') == 'http://localhost'
	assert candidate(
    'dev'
) == 'http://localhost'
	assert candidate('staging') == 'https://www.staging.marketplace.team'
	assert candidate('dev') == 'http://localhost'
	assert candidate(
    'production'
) == 'https://www.digitalmarketplace.service.gov.uk'
	assert candidate(stage='local') == 'http://localhost'
	assert candidate(
    'local'
) == 'http://localhost'
	assert candidate(
    'preview'
) == 'https://www.preview.marketplace.team'
	assert candidate('preview') == 'https://www.preview.marketplace.team'
	assert candidate(stage='development') == 'http://localhost'
	assert candidate(
   'staging'
) == 'https://www.staging.marketplace.team'
	assert candidate(stage='dev') == 'http://localhost'
	assert candidate(stage='production') == 'https://www.digitalmarketplace.service.gov.uk'
	assert candidate(stage='staging') == 'https://www.staging.marketplace.team'
def test_check():
	check(get_web_url_from_stage)
