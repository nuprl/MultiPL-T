def empty(width=None):
    """Creates empty separator block.

    :param width: specify block width, defaults to None
    :type width: int, optional
    """
    ### Canonical solution below ###

    def template(max_width, *args, **kwargs):
        # empty cell
        return f'<div style="min-width: {max_width if not width else width}px;"></div>'

    return template


### Unit tests below ###
def check(candidate):
	assert candidate(10)('') == '<div style="min-width: 10px;"></div>'
	assert candidate(12)('123') == '<div style="min-width: 12px;"></div>'
	assert candidate()(5)
	assert candidate(width=12)([]) == '<div style="min-width: 12px;"></div>'
	assert candidate(width=12)('123') == '<div style="min-width: 12px;"></div>'
	assert candidate(width=5)(5)
	assert candidate(width=100)(1000, align='left') == '<div style="min-width: 100px;"></div>'
	assert candidate(width=10)('') == '<div style="min-width: 10px;"></div>'
	assert candidate(width=50)('') == '<div style="min-width: 50px;"></div>'
	assert candidate(width=12)(123) == '<div style="min-width: 12px;"></div>'
	assert candidate(width=5)
	assert candidate(width=12)('') == '<div style="min-width: 12px;"></div>'
	assert candidate()(1000, align='left') == '<div style="min-width: 1000px;"></div>'
	assert candidate(width=30)('<div style="min-width: 20px;"></div>', 30) == '<div style="min-width: 30px;"></div>'
	assert candidate(100)(1000, align='left') == '<div style="min-width: 100px;"></div>'
	assert candidate(width=20)('<div style="min-width: 20px;"></div>', 20) == '<div style="min-width: 20px;"></div>'
	assert candidate(100)('') == '<div style="min-width: 100px;"></div>'
	assert candidate(5)
	assert candidate(width=12)({'a': 1, 'b': 2}) == '<div style="min-width: 12px;"></div>'
	assert candidate(width=12)(None) == '<div style="min-width: 12px;"></div>'
	assert candidate(width=12)([1, 2, 3]) == '<div style="min-width: 12px;"></div>'
def test_check():
	check(empty)
