def _attrgetter(attr):
    """
    Return a callable object that fetches attr from its operand.

    Unlike operator.attrgetter, the returned callable supports an extra two
    arg form for a default.
    """
    ### Canonical solution below ###
    def fn(obj, *args):
        return getattr(obj, attr, *args)

    return fn


### Unit tests below ###
def check(candidate):
	assert candidate('__class__')(1, object) == int
	assert candidate("x")({"y": 10}, 20) == 20
	assert candidate('__class__')(1) is int
	assert candidate('__class__')(1) == int
	assert candidate('x')(object(), 42) == 42
	assert candidate('__class__')(1, 2) is int
	assert candidate('__call__')(None, 23) == 23
	assert candidate('a')(dict(), 2) == 2
	assert candidate('foo')(object(), 42) == 42
	assert candidate('attr')(object(), 1) == 1
def test_check():
	check(_attrgetter)
