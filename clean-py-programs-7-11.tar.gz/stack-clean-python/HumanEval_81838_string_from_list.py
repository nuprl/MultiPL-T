def string_from_list(l):
    """
    Construct a string from a list of strings
    :param l: list of strings
    :return: string containing elements of list l separated by a comma
    """
    ### Canonical solution below ###
    s = l[0]
    if len(l) > 1:
        for i in range(len(l)-1):
            # only add this string to the list if it is different from the previous strings
            e = l[i+1]
            if e not in l[0:i+1]:
                s += ',\t\t' + e
    return s


### Unit tests below ###
def check(candidate):
	assert candidate(['a', 'a']) == "a"
	assert candidate(list(['a', 'a'])) == 'a'
	assert candidate(l=['a']) == 'a'
	assert candidate(["a","b","c"]) == "a,		b,		c"
	assert candidate(list('a')) == 'a'
	assert candidate(l=["a", "b", "c"]) == "a,		b,		c"
	assert candidate(["a","a","b","b","c","c"]) == "a,		b,		c"
	assert candidate(['a']) == 'a'
	assert candidate(['a']) == "a"
	assert candidate(["a","b"]) == "a,		b"
	assert candidate(["a"]) == "a"
	assert candidate(['a', 'a']) == 'a'
	assert candidate(list(['a'])) == 'a'
	assert candidate(l=["a", "a", "a"]) == "a"
	assert candidate(["a","a","b","b","c"]) == "a,		b,		c"
def test_check():
	check(string_from_list)
