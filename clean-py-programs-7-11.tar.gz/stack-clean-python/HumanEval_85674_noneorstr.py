def noneorstr(s):
    """ Turn empty or 'none' string to None."""
	### Canonical solution below ###    
    if s.lower() in ('', 'none'):
        return None
    else:
        return s

### Unit tests below ###
def check(candidate):
	assert candidate('') == None
	assert candidate('none') == None
	assert candidate('None') == None
	assert candidate('s') =='s'
	assert candidate('a') == 'a'
	assert candidate('something') =='something'
	assert candidate('x') == 'x'
	assert candidate("") == None
	assert candidate('None') is None
	assert candidate('a string') == 'a string'
	assert candidate("foo") == "foo"
	assert candidate("none") == None
	assert candidate('abc') == 'abc'
	assert candidate('none') is None
	assert candidate('') is None
	assert candidate('SOMETHING') == 'SOMETHING'
	assert candidate('hello') == 'hello'
	assert candidate('foo') == 'foo'
	assert candidate('NONE') is None
	assert candidate("None") == None
	assert candidate('test') == 'test'
	assert candidate('1') == '1'
def test_check():
	check(noneorstr)
