def _smvhash(text):
    """ Python's hash function will return different numbers from run to
     from, starting from 3.  Provide a deterministic hash function for
     use to calculate sourceCodeHash.
     """
	### Canonical solution below ###    
    import binascii
    return binascii.crc32(text.encode())

### Unit tests below ###
def check(candidate):
	assert candidate("abc")!= candidate("ABC")
	assert candidate("a") == candidate("a")
	assert candidate(u"abc")!= candidate(u"123")
	assert candidate("abc") == candidate("abc")
	assert candidate("abc")!= candidate("abcd")
	assert candidate(u"abc") == candidate(u"abc")
	assert candidate("a")!= candidate("b")
	assert candidate("") == candidate("")
	assert candidate(u'abc') == 0x352441c2
	assert candidate('') == 0
	assert candidate(u"") == 0
	assert candidate("abc")!= candidate("acb")
	assert candidate("") == 0
	assert candidate("abc")!= candidate("aBc")
	assert candidate(u"abc")!= candidate(u"ABC")
def test_check():
	check(_smvhash)
