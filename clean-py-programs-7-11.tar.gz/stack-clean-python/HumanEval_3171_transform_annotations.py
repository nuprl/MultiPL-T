def transform_annotations(annotations):
    """ Transform annotations dumbly, asserting it is a sequence of strs."""
	### Canonical solution below ###    
    assert isinstance(annotations, (list, tuple))
    for annotation in annotations:
        assert isinstance(annotation, str)
    return annotations

### Unit tests below ###
def check(candidate):
	assert candidate(['foo', '123.456']) == ['foo', '123.456']
	assert candidate(["foo", "bar"]) == ["foo", "bar"]
	assert candidate(['A', 'B']) == ['A', 'B']
	assert candidate(['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(('foo', 'bar')) == ('foo', 'bar')
	assert candidate([]) == []
	assert candidate(['a', 'b']) == ['a', 'b']
	assert candidate(['foo']) == ['foo']
	assert candidate(("a", "b")) == ("a", "b")
	assert candidate(["a", "b", "c"]) == ["a", "b", "c"]
	assert candidate(['', '']) == ['', '']
	assert candidate(["hello", "world"]) == ["hello", "world"]
	assert candidate(["", "hello"]) == ["", "hello"]
	assert candidate([""]) == [""]
	assert candidate(["a"]) == ["a"]
	assert candidate(['foo', 'bar']) == ['foo', 'bar']
	assert candidate(["a", "b"]) == ["a", "b"]
	assert candidate(["hello"]) == ["hello"]
	assert candidate(["Hello", "World"]) == ["Hello", "World"]
	assert candidate(['']) == ['']
	assert candidate(['a']) == ['a']
def test_check():
	check(transform_annotations)
