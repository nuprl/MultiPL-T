def modular_exponentiation(b, e, m):
    """ produced modular exponentiation.
     https://en.wikipedia.org/wiki/Modular_exponentiation
     
     :param b: a base number.
     :param e: an exponent.
     :param m: a modulo.
     :return: a reminder of b modulo m.
     """
	### Canonical solution below ###    
    x = 1
    y = b
    while e > 0:
        if e % 2 == 0:
            x = (x * y) % m
        y = (y * y) % m
        e = int(e / 2)
    return x % m

### Unit tests below ###
def check(candidate):
	assert candidate(2, 1000000000, 3) == 2
	assert candidate(5, 2, 17) == 5
	assert candidate(5, 2, 18) == 5
	assert candidate(5, 2, 12) == 5
	assert candidate(5, 15, 3) == 1
	assert candidate(2, 3, 2) == 1
	assert candidate(0, 3, 1) == 0
	assert candidate(1, 2, 2) == 1
	assert candidate(5, 2, 23) == 5
	assert candidate(3, 10, 4) == 3
	assert candidate(2, 100, 13) == 8
	assert candidate(3, 3, 1) == 0
	assert candidate(0, 2, 1) == 0
	assert candidate(2, 5, 10) == 4
	assert candidate(2, 2, 1) == 0
	assert candidate(5, 2, 21) == 5
	assert candidate(2, 11, 10) == 6
	assert candidate(2, 3, 1) == 0
	assert candidate(5, 2, 16) == 5
	assert candidate(3, 14, 7) == 3
	assert candidate(2, 2, 2) == 0
	assert candidate(5, 16, 10) == 5
	assert candidate(2, 10, 10) == 2
	assert candidate(3, 1, 2) == 1
	assert candidate(5, 2, 30) == 5
	assert candidate(5, 2, 15) == 5
	assert candidate(3, 2, 1) == 0
	assert candidate(100, 100, 100) == 0
	assert candidate(5, 2, 26) == 5
	assert candidate(5, 19, 3) == 1
	assert candidate(5, 2, 24) == 5
	assert candidate(5, 2, 13) == 5
	assert candidate(1, 1, 1) == 0
	assert candidate(100, 100, 13) == 1
	assert candidate(5, 2, 25) == 5
	assert candidate(1, 0, 5) == 1
	assert candidate(2, 0, 5) == 1
	assert candidate(1, 2, 1) == 0
	assert candidate(2, 9, 5) == 4
	assert candidate(1, 3, 2) == 1
	assert candidate(5, 2, 29) == 5
	assert candidate(5, 14, 3) == 2
	assert candidate(1, 1, 2) == 1
	assert candidate(5, 4, 10) == 5
	assert candidate(5, 2, 3) == 2
	assert candidate(5, 2, 10) == 5
	assert candidate(5, 2, 27) == 5
	assert candidate(2, 13, 5) == 4
	assert candidate(1, 3, 1) == 0
	assert candidate(1, 1, 5) == 1
	assert candidate(5, 2, 11) == 5
	assert candidate(5, 2, 19) == 5
	assert candidate(5, 0, 5) == 1
	assert candidate(5, 9, 3) == 1
	assert candidate(4, 4, 7) == 1
	assert candidate(5, 2, 20) == 5
	assert candidate(2, 3, 5) == 1
	assert candidate(2, 10, 3) == 2
	assert candidate(5, 2, 28) == 5
	assert candidate(0, 1, 1) == 0
	assert candidate(5, 1, 3) == 1
	assert candidate(5, 2, 22) == 5
	assert candidate(2, 1, 1) == 0
	assert candidate(5, 10, 10) == 5
	assert candidate(3, 2, 2) == 1
	assert candidate(2, 100, 10) == 8
	assert candidate(3, 3, 2) == 1
	assert candidate(5, 5, 10) == 5
	assert candidate(5, 2, 14) == 5
	assert candidate(3, 1, 1) == 0
def test_check():
	check(modular_exponentiation)
