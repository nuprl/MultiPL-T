def HistogramDistance(hist1, hist2):
    """ Earth mover's distance.
     
     http://en.wikipedia.org/wiki/Earth_mover's_distance
     First, normalize the two histograms. Then, treat the two histograms as
     piles of dirt, and calculate the cost of turning one pile into the other.
     
     To do this, calculate the difference in one bucket between the two
     histograms. Then carry it over in the calculation for the next bucket.
     In this way, the difference is weighted by how far it has to move."""
	### Canonical solution below ###  
  if len(hist1) != len(hist2):
    raise ValueError('Trying to compare histograms '
      'of different sizes, %s != %s' % (len(hist1), len(hist2)))

  n1 = sum(hist1)
  n2 = sum(hist2)
  if n1 == 0:
    raise ValueError('First histogram has 0 pixels in it.')
  if n2 == 0:
    raise ValueError('Second histogram has 0 pixels in it.')

  total = 0
  remainder = 0
  for value1, value2 in zip(hist1, hist2):
    remainder += value1 * n2 - value2 * n1
    total += abs(remainder)
  assert remainder == 0, (
      '%s pixel(s) left over after computing histogram distance.'
      % abs(remainder))
  return abs(float(total) / n1 / n2)

### Unit tests below ###
def check(candidate):
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [4, 4, 4, 4, 4, 4]) == 0.0
	assert candidate(
    [0, 0, 1, 0],
    [0, 0, 1, 0]) == 0.0
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]) == 0.0
	assert candidate(
    [0, 1, 0, 0],
    [0, 0, 1, 0]) == 1.
	assert candidate(
    [0, 0, 1],
    [0, 1, 1]) == 0.5
	assert candidate(
    [1, 1, 1, 1], [1, 1, 1, 1]) == 0
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [8, 8, 8, 8, 8, 8]) == 0.0
	assert candidate(
    [1, 1, 1, 1], [0, 0, 1, 1]) == 1.0
	assert candidate( [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ],
                         [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ] ) == 0.0
	assert candidate(
    [0, 0, 1, 0],
    [1, 0, 1, 0]) == 1.0
	assert candidate(
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == 0
	assert candidate(
    [1, 0, 1, 0],
    [0, 0, 1, 0]) == 1.0
	assert candidate(
    [1, 2, 3],
    [1, 2, 3]) == 0
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [5, 5, 5, 5, 5, 5]) == 0.0
	assert candidate(
    [0, 1, 1, 1], [1, 1, 1, 1]) == 0.5
	assert candidate(range(1000), range(1000)) == 0.0
	assert candidate(
    [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000],
    [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]) == 0
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1]) == 0.0
	assert candidate(
    [0, 0, 1, 0],
    [0, 0, 0, 1]) == 1.0
	assert candidate(
    [0, 0, 1],
    [0, 0, 1]) == 0.0
	assert candidate(
    [1, 2, 3, 4], [1, 2, 3, 4]) == 0.0, 'Identical histograms should have 0 distance.'
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [2, 2, 2, 2, 2, 2]) == 0.0
	assert candidate(
    [1, 1, 1], [1, 1, 1]) == 0
	assert candidate(
    [0, 0, 1, 0],
    [0, 0, 1, 1]) == 0.5
	assert candidate(
    [1, 1, 1, 1], [1, 1, 1, 0]) == 0.5
	assert candidate(
    [1, 1, 1, 1],
    [1, 1, 1, 1]) == 0, 'Identical histograms should have zero distance.'
	assert candidate(
    [1, 1, 1, 1], [0, 1, 1, 1]) == 0.5
	assert candidate(
    [0, 0, 1],
    [2, 2, 2]) == 1.0
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [7, 7, 7, 7, 7, 7]) == 0.0
	assert candidate(
    [1, 2, 3, 4],
    [1, 2, 3, 4]) == 0.0
	assert candidate(
    [0, 1, 0, 0],
    [1, 0, 1, 0]) == 1.0
	assert candidate(
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2]) == 0
	assert candidate(
    [0, 1, 0, 0],
    [0, 1, 0, 0]) == 0.0
	assert candidate(
    [1, 2, 3, 4], [0, 0, 0, 2]) == 1.0, 'Histograms with 0s, 1s, and 2s in them should have distance 1.'
	assert candidate(
    [1, 0, 1, 0],
    [0, 1, 0, 0]) == 1.0
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [6, 6, 6, 6, 6, 6]) == 0.0
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1]) == 0
	assert candidate(
    [0, 1, 2], [0, 1, 2]) == 0, 'No distance should be 0.'
	assert candidate(
    [1, 1, 1, 1, 1, 1],
    [3, 3, 3, 3, 3, 3]) == 0.0
	assert candidate( [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ],
                         [ 2, 4, 6, 8, 10, 1, 3, 5, 7, 9 ] ) == 1.0
def test_check():
	check(HistogramDistance)
