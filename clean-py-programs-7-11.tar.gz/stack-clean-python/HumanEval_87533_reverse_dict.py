def reverse_dict(dct):
    """ Reverse the {key:val} in dct to
        {val:key}
    """
    ### Canonical solution below ###
    newmap = {}
    for (key, val) in dct.items():
        newmap[val] = key
    return newmap


### Unit tests below ###
def check(candidate):
	assert candidate(dict(a=1, b=2, c=3, d=4)) == {1:'a', 2:'b', 3:'c', 4:'d'}
	assert candidate(dict()) == {}
	assert candidate(dict(a=1)) == {1: 'a'}
	assert candidate(dict(zip([1, 2, 3], ["a", "b", "c"]))) == {"a": 1, "b": 2, "c": 3}
	assert candidate(dict(zip(range(10), range(10)))) == dict(zip(range(10), range(10)))
	assert candidate(dict(one=1, two=2, three=3)) == {1:'one', 2:'two', 3:'three'}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == {1:'a', 2:'b', 3:'c', 4:'d', 5:'e', 6:'f'}
	assert candidate(dict(zip(range(3), 'abc'))) == {'a': 0, 'b': 1, 'c': 2}
	assert candidate(dict(one=1, two=2)) == {1: 'one', 2: 'two'}
	assert candidate(dict(one=1, two=2, three=3)) == {1: 'one', 2: 'two', 3: 'three'}
	assert candidate(dict(a=1, b=2)) == {1: 'a', 2: 'b'}
	assert candidate(dict(a=1, b=2, c=2)) == {1: 'a', 2: 'c'}
	assert candidate(dict(a=1, b=2, c=3, d=4)) == {1: 'a', 2: 'b', 3: 'c', 4: 'd'}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7)) == {1:'a', 2:'b', 3:'c', 4:'d', 5:'e', 6:'f', 7:'g'}
	assert candidate(
    {'a': 1, 'b': 1, 'c': 2, 'd': 2, 'e': 3}
) == {
    1: 'b',
    2: 'd',
    3: 'e'
}
	assert candidate(dict(zip(["a", "b", "c"], [1, 2, 3]))) == {1: "a", 2: "b", 3: "c"}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4}
) == {
    1: 'a',
    2: 'b',
    3: 'c',
    4: 'd'
}
	assert candidate( {1:2, 3:4} ) == {2:1, 4:3}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == {1:'a', 2:'b', 3:'c', 4:'d', 5:'e'}
	assert candidate(dict(a=1, b=2)) == {1:'a', 2:'b'}
	assert candidate(dict(a=1, b=2, c=3)) == {1: 'a', 2: 'b', 3: 'c'}
	assert candidate(dict(a=2,b=3,c=4)) == {2:'a', 3:'b', 4:'c'}
	assert candidate( {'a': 1, 'b': 2} ) == {1:'a', 2:'b'}
	assert candidate( {'a': 1, 'b': 2} ) == {1: 'a', 2: 'b'}
	assert candidate(dict(a=1,b=2,c=3)) == {1:'a',2:'b',3:'c'}
	assert candidate(dict(zip(range(5), range(5)))) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4}
	assert candidate(dict(a=1,b=2,c=3)) == {1:'a', 2:'b', 3:'c'}
	assert candidate( {} ) == {}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8)) == {1:'a', 2:'b', 3:'c', 4:'d', 5:'e', 6:'f', 7:'g', 8:'h'}
	assert candidate({'a': 1, 'b': 2}) == {1: 'a', 2: 'b'}
	assert candidate(dict(a=1, b=2, c=3)) == {1:'a', 2:'b', 3:'c'}
	assert candidate(dict(zip(range(10), range(10)))) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate( {'a':1, 'b':2} ) == {1:'a', 2:'b'}
	assert candidate(dict(uno=1, dos=2, tres=3)) == {1:'uno', 2:'dos', 3:'tres'}
def test_check():
	check(reverse_dict)
