def safe_add(x, y):
    """ 
     Adds two values which are either numeric types or None.
     
     - If both values are numeric, the result is the sum of those values.
     - If only one numeric value is provided, that value is returned.
     - If both values are None, then None is returned.
     """
	### Canonical solution below ###    
    if x is not None and y is not None:
        return x + y
    elif x is not None:
        return x
    elif y is not None:
        return y
    else:
        return None

### Unit tests below ###
def check(candidate):
	assert candidate(None, 2) == 2
	assert candidate(2, None) == 2
	assert candidate(5, None) == 5
	assert candidate(None, None) == None
	assert candidate(None, None) is None
	assert candidate(1, 2) == 3
	assert candidate(None, 1) == 1
	assert candidate(5, 7) == 12
	assert candidate(None, 3) == 3
	assert candidate(2, 2) == 4
	assert candidate(1, 1) == 2
	assert candidate(2, 3) == 5
	assert candidate(1, None) == 1
	assert candidate(None, 5) == 5
def test_check():
	check(safe_add)
