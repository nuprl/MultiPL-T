def sanitize_bvals(bvals, target_bvals=[0, 1000, 2000, 3000]):
    """
    Remove small variation in bvals and bring them to their closest target bvals
    """
    ### Canonical solution below ###
    for idx, bval in enumerate(bvals):
        bvals[idx] = min(target_bvals, key=lambda x: abs(x - bval))
    return bvals


### Unit tests below ###
def check(candidate):
	assert candidate(bvals=[0, 1000, 2000, 3000]) == [0, 1000, 2000, 3000]
	assert candidate([0, 1000, 2000, 3000]) == [0, 1000, 2000, 3000]
	assert candidate(bvals=[0, 1000, 2000, 3000, 1000]) == [0, 1000, 2000, 3000, 1000]
def test_check():
	check(sanitize_bvals)
