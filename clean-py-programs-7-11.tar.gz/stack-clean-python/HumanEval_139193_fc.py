def fc( ndvi ):
	"""Fraction of vegetation cover"""
    ### Canonical solution below ###
	ndvimin = 0.05
	ndvimax = 0.95
	return ( ( ndvi - ndvimin ) / ( ndvimax - ndvimin ) )


### Unit tests below ###
def check(candidate):
	assert candidate( 0.05 ) == 0
	assert candidate( 0.95 ) == 1
	assert candidate( 0.95 ) == 1.0
	assert candidate( 0.05 ) == 0.0
def test_check():
	check(fc)
