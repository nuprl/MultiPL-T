def for_all_methods(decorator, exclude=None):
    """
        Decorator which wraps all methods of the object.
        However, it is possible not to wrap exactly all
        methods using `exclude` argument.
    """
    ### Canonical solution below ###
    if not exclude:
        # By default is empty list, so, decorate all methods
        exclude = list()

    def decorate(cls):
        for attr in cls.__dict__:
            if callable(getattr(cls, attr)) and attr not in exclude:
                setattr(cls, attr, decorator(getattr(cls, attr)))
        return cls
    return decorate


### Unit tests below ###
def check(candidate):
	assert candidate(lambda x: x)(lambda x: x)(1) == 1
	assert candidate(lambda x: x, exclude=['foo'])(lambda x: x)(1) == 1
	assert candidate(lambda x: x, exclude=['foo', 'bar'])(lambda x: x)(1) == 1
def test_check():
	check(for_all_methods)
