def get_quadrant(x, y):
    """
    Returns the quadrant as an interger in a mathematical positive system:
    1 => first quadrant
    2 => second quadrant
    3 => third quadrant
    4 => fourth quadrant
    None => either one or both coordinates are zero

    Parameters
    ----------
    x : float
        x coordinate.
    y : float
        y coordinate.

    Returns
    -------
    int or None
        Quadrant number.

    """
    ### Canonical solution below ###

    if x > 0 and y > 0:
        return 1
    elif x < 0 and y > 0:
        return 2
    elif x < 0 and y < 0:
        return 3
    elif x > 0 and y < 0:
        return 4
    else:
        return None


### Unit tests below ###
def check(candidate):
	assert candidate(0.1, 1) == 1
	assert candidate(0, -1) == None
	assert candidate(0, 0) == None
	assert candidate(-3, -4) == 3
	assert candidate(1, 1) == 1
	assert candidate(0, 1) == None
	assert candidate(-1.5, 1.5) == 2
	assert candidate(1, 0) == None
	assert candidate(0, 2) == None
	assert candidate(0, 1) is None
	assert candidate(2, -2) == 4
	assert candidate(0, -1) is None
	assert candidate(2, 2) == 1
	assert candidate(0, -4) is None
	assert candidate(-1, 1) == 2
	assert candidate(1.5, -1.5) == 4
	assert candidate(1, 0.1) == 1
	assert candidate(1.5, 1.5) == 1
	assert candidate(3, 0) is None
	assert candidate(-1, 0) is None
	assert candidate(3, 4) == 1
	assert candidate(-2, 2) == 2
	assert candidate(-2, -2) == 3
	assert candidate(-1, 0) == None
	assert candidate(2, 0) == None
	assert candidate(1, 0) is None
	assert candidate(0, 0) is None
	assert candidate(0, 4) is None
	assert candidate(1, -1) == 4
	assert candidate(-1.5, -1.5) == 3
	assert candidate(-1, -1) == 3
def test_check():
	check(get_quadrant)
