def parse_struct_stat(stats):
    """Parse the structure of stats values in influencer data in order
    to return a pandas-compatible object.
    """
    ### Canonical solution below ###
    data = dict()
    for stat in stats:
        for item in stats[stat]:
            for metric in item['counts']:
                data.setdefault(metric, dict())
                data[metric].update({
                    (stat, item['term']): item['counts'][metric]
                })
    return data


### Unit tests below ###
def check(candidate):
	assert candidate(dict()) == dict()
	assert candidate(
    {'statuses': [
        {'term': 'A', 'counts': {'replies': 10}},
        {'term': 'B', 'counts': {'replies': 20}},
        {'term': 'C', 'counts': {'replies': 30}},
    ]}) == {
       'replies': {
            ('statuses', 'A'): 10,
            ('statuses', 'B'): 20,
            ('statuses', 'C'): 30,
        }
    }
	assert candidate(
    {
       'statuses': [{
            'term': 'test',
            'counts': {'likes': 1}
        }, {
            'term': 'test2',
            'counts': {'likes': 2}
        }]
    }
) == {'likes': {('statuses', 'test'): 1, ('statuses', 'test2'): 2}}
	assert candidate(stats={}) == {}
	assert candidate(
    {
       'statuses': [
            {
                'term': 'a',
                'counts': {
                    'followers_count': 1,
                    'friends_count': 2,
                    'listed_count': 3,
                    'favourites_count': 4,
                },
            },
            {
                'term': 'b',
                'counts': {
                    'followers_count': 5,
                    'friends_count': 6,
                    'listed_count': 7,
                    'favourites_count': 8,
                },
            },
        ]
    }
) == {
    'followers_count': {
        ('statuses', 'a'): 1,
        ('statuses', 'b'): 5,
    },
    'friends_count': {
        ('statuses', 'a'): 2,
        ('statuses', 'b'): 6,
    },
    'listed_count': {
        ('statuses', 'a'): 3,
        ('statuses', 'b'): 7,
    },
    'favourites_count': {
        ('statuses', 'a'): 4,
        ('statuses', 'b'): 8,
    },
}
	assert candidate(
    {
       'statuses': [{
            'term': 'test',
            'counts': {'likes': 1}
        }]
    }
) == {'likes': {('statuses', 'test'): 1}}
	assert candidate(dict(
    a=[
        {'term': 'b', 'counts': {'c': 1}},
        {'term': 'd', 'counts': {'e': 2}}
    ],
    f=[
        {'term': 'g', 'counts': {'h': 3}}
    ]
)) == {
    'c': {('a', 'b'): 1},
    'e': {('a', 'd'): 2},
    'h': {('f', 'g'): 3}
}
def test_check():
	check(parse_struct_stat)
