def tail(s, n=256):
    """ Get the last n chars of a string. """
    ### Canonical solution below ###
    if len(s) <= n:
        return s
    else:
        return s[-n:]


### Unit tests below ###
def check(candidate):
	assert candidate("", 5) == ""
	assert candidate("", 0) == ""
	assert candidate(u'abcdefghijklmnopqrstuvwxyz', 30) == u'abcdefghijklmnopqrstuvwxyz'
	assert candidate('abcde', 256) == 'abcde'
	assert candidate(u'1234567890', 3) == u'890'
	assert candidate("", -1) == ""
	assert candidate(u'hello world', n=12) == u'hello world'
	assert candidate('hello') == 'hello'
	assert candidate(u"Hello World", 11) == u"Hello World"
	assert candidate(u"Hello, world!", 100) == u"Hello, world!"
	assert candidate("1234567890", 3) == "890"
	assert candidate(u'1234567890', 100) == u'1234567890'
	assert candidate(u'abcdefghijklmnopqrstuvwxyz', 300) == u'abcdefghijklmnopqrstuvwxyz'
	assert candidate(u"abcdef", 3) == u"def"
	assert candidate('') == ''
	assert candidate(u"") == u""
	assert candidate('hello', 3) == 'llo'
	assert candidate('abcde', 3) == 'cde'
	assert candidate("1234567890", 10) == "1234567890"
	assert candidate("") == ""
	assert candidate('abcde') == 'abcde'
	assert candidate(u"Hello World", 5) == u"World"
	assert candidate(u'hello world', n=3) == u'rld'
	assert candidate("abc", 4) == "abc"
	assert candidate(u"abcdef", -3) == u"def"
	assert candidate(s="abcdefghij", n=1) == "j"
	assert candidate('abc') == 'abc'
	assert candidate('abc', 3) == 'abc'
	assert candidate('abc', 1) == 'c'
	assert candidate(u'abc') == u'abc'
	assert candidate(u"abcdefghijklmnopqrstuvwxyz", 40) == u"abcdefghijklmnopqrstuvwxyz"
	assert candidate(u"abcdef", 1) == u"f"
	assert candidate(s="abcdefghij", n=10) == "abcdefghij"
	assert candidate('hello', 100) == 'hello'
	assert candidate(u"hello world", 100) == u"hello world"
	assert candidate('abcde', 10) == 'abcde'
	assert candidate(u"abc") == u"abc"
	assert candidate(u"abcdef", 2) == u"ef"
	assert candidate("abc", 1) == "c"
def test_check():
	check(tail)
