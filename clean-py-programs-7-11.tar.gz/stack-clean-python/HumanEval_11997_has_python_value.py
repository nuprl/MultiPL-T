def has_python_value(var, value):
    """Used during typing to check that variable var was resolved as Python type and has specific value"""
    ### Canonical solution below ###

    if not isinstance(var, type(value)):
        return False

    if value is None or isinstance(value, type(bool)):
        return var is value
    else:
        return var == value


### Unit tests below ###
def check(candidate):
	assert not candidate(True, 3)
	assert candidate(123, 123)
	assert not candidate(5, 6)
	assert not candidate(False, 3)
	assert candidate(5.5, 5.5)
	assert candidate(1, 2) is False
	assert not candidate(False, "True")
	assert not candidate(False, 1)
	assert not candidate(1, 1.0)
	assert not candidate(2, True)
	assert candidate(1, 1)
	assert not candidate(1.0, False)
	assert not candidate(1, False)
	assert not candidate(1.0, True)
	assert not candidate(1, True)
	assert not candidate(None, 1.0)
	assert not candidate(False, "False")
	assert candidate(1, None) is False
	assert candidate(3, 3)
	assert candidate(3.14, 3.14)
	assert candidate(1.0, 1.0)
	assert not candidate(None, True)
	assert not candidate(False, True)
	assert not candidate(3, None)
	assert not candidate(1.0, None)
	assert not candidate(None, 5)
	assert candidate(None, True) is False
	assert not candidate(0, True)
	assert candidate(True, False) is False
	assert candidate(1, True) is False
	assert not candidate(False, "None")
	assert candidate(1.0+2.0j, 1.0+2.0j)
	assert not candidate(True, "none")
	assert not candidate(True, 0)
	assert candidate(b"a", b"a")
	assert not candidate(b"a", b"b")
	assert candidate(123.0, 123.0)
	assert candidate(False, True) is False
	assert not candidate(True, "True")
	assert candidate("string", True) is False
	assert not candidate(False, "2")
	assert not candidate(True, "false")
	assert candidate(True, True)
	assert not candidate(None, 1)
	assert candidate("abc", "abc")
	assert not candidate("abc", "def")
	assert candidate(1.1, 1.2) is False
	assert not candidate(1.1, 2.2)
	assert not candidate(5.5, 5.6)
	assert candidate("string", False) is False
	assert not candidate(1, None)
	assert not candidate(1, "1")
	assert candidate("string", None) is False
	assert not candidate(123.0, 124)
	assert candidate(None, None)
	assert candidate(5, 5)
	assert not candidate(False, "1")
	assert not candidate(3, 4)
	assert not candidate(True, "1")
	assert not candidate("a", "b")
	assert not candidate(1.0, 2.0)
	assert not candidate(True, False)
	assert candidate(1.1, False) is False
	assert candidate("string", "string")
	assert not candidate(False, None)
	assert not candidate(True, None)
	assert not candidate(True, "None")
	assert not candidate(1.0, "a")
	assert not candidate(1, 1 + 0j)
	assert not candidate(True, 2)
	assert not candidate(1.0, 1)
	assert not candidate(None, False)
	assert not candidate(False, 2)
	assert not candidate(True, "2")
	assert not candidate(1, "a")
	assert candidate("a", "a")
	assert not candidate(True, "3")
	assert candidate(None, 1) is False
	assert candidate('abc', 'abc')
	assert not candidate(True, "False")
	assert candidate("string", "another string") is False
	assert not candidate(123, 124.0)
	assert not candidate(True, "true")
	assert not candidate(True, 1.0)
	assert candidate(1.1, 1.1)
	assert not candidate(1.0, 1.1)
	assert not candidate('abc', 'def')
	assert candidate(None, False) is False
	assert candidate(1.1, True) is False
	assert not candidate(None, 3)
	assert candidate(False, False)
	assert candidate(1 + 0j, 1 + 0j)
	assert candidate(False, 1) is False
	assert not candidate(123.0, 124.0)
	assert candidate(1, False) is False
	assert candidate(1.1, None) is False
	assert not candidate(1, 2)
	assert not candidate(123, 124)
def test_check():
	check(has_python_value)
