def to_chars(str_list):
    """ 
     Convert str list to char list
     """
	### Canonical solution below ###    
    chars = []
    for sstr in str_list:
        chars += list(sstr)
    return chars

### Unit tests below ###
def check(candidate):
	assert candidate(list("ghi")) == ['g', 'h', 'i']
	assert candidate(list("tuv")) == ['t', 'u', 'v']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
	assert candidate(
    ['abc', 'def', 'ghi']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
	assert candidate(
    ["The", "quick", "brown", "fox", "jumps", "over", "the", "lazy", "dog"]) == [
    'T', 'h', 'e', 'q', 'u', 'i', 'c', 'k', 'b', 'r', 'o', 'w', 'n', 'f', 'o', 'x', 'j', 'u','m', 'p','s', 'o', 'v', 'e', 'r', 't', 'h', 'e', 'l', 'a', 'z', 'y', 'd', 'o', 'g']
	assert candidate(
    ["hello", "world", "how", "are", "you"]
) == ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd', 'h', 'o', 'w', 'a', 'r', 'e', 'y', 'o', 'u']
	assert candidate(
    ['a', 'b', 'c', 'd']
) == ['a', 'b', 'c', 'd']
	assert candidate(list("abc")) == ['a', 'b', 'c']
	assert candidate(list("mno")) == ['m', 'n', 'o']
	assert candidate(list("jkl")) == ['j', 'k', 'l']
	assert candidate(
    ['a', 'b', 'c']) == ['a', 'b', 'c']
	assert candidate(list("wxyz")) == ['w', 'x', 'y', 'z']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f']
) == ['a', 'b', 'c', 'd', 'e', 'f']
	assert candidate( ['hello', 'world'] ) == ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd']
	assert candidate(list('ab')) == list('ab')
	assert candidate(['ab', 'c']) == list('abc')
	assert candidate(["a", "b", "c"]) == list("abc")
	assert candidate(
    ["abc", "def", "ghi", "jkl", "mno", "pqr", "stu", "vwx", "yz"]) == list(
    "abcdefghijklmnopqrstuvwxyz")
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
	assert candidate(list('')) == []
	assert candidate(
    ['a', 'b', 'c']
) == ['a', 'b', 'c']
	assert candidate(
    ["abc", "def", "ghi"]) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
	assert candidate(list("def")) == ['d', 'e', 'f']
	assert candidate(["ab", "c"]) == list("abc")
	assert candidate(list('abc')) == ['a', 'b', 'c']
	assert candidate( ["hello", "world"]) == list("helloworld")
	assert candidate(list('abc')) == list('abc')
	assert candidate(
    ['abc', 'de', 'f']) == ['a', 'b', 'c', 'd', 'e', 'f']
	assert candidate(
    ['This', 'is', 'a', 'test','string']
) == ['T', 'h', 'i','s', 'i','s', 'a', 't', 'e','s', 't','s', 't', 'r', 'i', 'n', 'g']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g']
) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
	assert candidate(list("hello")) == ['h', 'e', 'l', 'l', 'o']
	assert candidate(list('ab')) == ['a', 'b']
	assert candidate(
    ['a', 'b', 'c', 'd', 'e']
) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(list("abc")) == list("abc")
	assert candidate(list("pqrs")) == ['p', 'q', 'r','s']
	assert candidate(
    ['How', 'now', 'brown', 'cow']) == [
        'H', 'o', 'w', 'n', 'o', 'w', 'b', 'r', 'o', 'w', 'n', 'c', 'o', 'w']
	assert candidate(
    ['this', 'is', 'a', 'test']
) == ['t', 'h', 'i','s', 'i','s', 'a', 't', 'e','s', 't']
	assert candidate(
    ["a", "b", "c", "d", "e"]) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(list('abc'))!= ['a', 'b', 'c', 'd']
def test_check():
	check(to_chars)
