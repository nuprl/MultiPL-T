def is_ipv6(hosts):
    """
    Function to validate IPv6 Addresses
    :param hosts: Takes a single host or subnet
    :return: Boolean True or False
    """
    ### Canonical solution below ###
    hosts = hosts.strip()
    if "/" not in hosts:
        # Assume that if no mask is specified, use a single host mask
        hosts = hosts + "/128"
    if ":" in hosts:
        mask = int(hosts.split("/")[-1])
        groups = hosts.split("/")[0].split(":")
        for group in groups:
            if len(group) is not 0 and len(group) <= 4:
                try:
                    group = int(group, 16)
                except Exception as e:
                    return False
            else:
                return False
        return True
    else:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate(hosts="2001:db8::1:1") is False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b") is True
	assert candidate(hosts='192.168.127.12/64') == False
	assert candidate(
    '192.168.1.1/255.255.255.0') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(hosts="127.0.0.1/125") == False
	assert candidate(hosts="127.0.0.1/129") == False
	assert candidate(
    "2001:0db8:0000:0000:0000:ff00:0042:8329/128") == True, "IPv6 with mask"
	assert candidate(hosts="127.0.0.1/123") == False
	assert candidate(hosts="127.0.0.1") == False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b/128") == True
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334/127") is True
	assert candidate(hosts="172.16.31.10") is False
	assert candidate(hosts="127.0.0.1/0") == False
	assert candidate(u'fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b') is True
	assert candidate(hosts='2001:0db8:85a3:0000:0000:8a2e:0370:7334') == True
	assert candidate(hosts="192.168.1.1/32") is False
	assert candidate(hosts="1:1:1:1::1") == False
	assert candidate(hosts='2001:0db8:85a3:0000:0000:8a2e:0370:7334') is True
	assert candidate(hosts="127.0.0.1/126") == False
	assert candidate(hosts="1.1.1.1") is False
	assert candidate(
    '192.168.1.1/24') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(hosts="1:1:1:1:1:1::1") == False
	assert candidate(
    '192.168.1.1/32') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(hosts="192.168.1.1/255.255.255.255.256") == False
	assert candidate(hosts="2001:db8:0:0:0:ff00:42:8329")
	assert candidate(hosts="fd00:a516:7c1b:17cd:6d81:2137:bd2a:2c5b/32") == True
	assert not candidate(hosts="192.168.1.1")
	assert candidate(hosts='192.168.1.1/abc') is False
	assert candidate(hosts="1:1:1:1:1::1") == False
	assert candidate(hosts="127.0.0.1/129") is False
	assert candidate(hosts="172.16.31.10/32") is False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b/128") is True
	assert candidate(hosts="::1/32") is False
	assert candidate(hosts="::1/6") is False
	assert candidate(hosts="2001:0db8:0000:85a3:0000:0000:ac1f:8001/64") is True
	assert candidate(hosts="2001:0db8:0000:85a3:0000:0000:ac1f:8001/128") is True
	assert candidate("2001:0db8:85a3:0000:0000:8a2e:0370:7334/64") is True, "IPv6 subnet failed"
	assert candidate(hosts="2001:db8:85a3:8d3:1319:8a2e:370:7348/64") is True
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334/64") is True
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334") is True
	assert candidate(hosts="192.168.1.1") is False
	assert candidate(hosts='192.168.1.1/128') is False
	assert candidate(hosts="2001:db8::1:1/64") is False
	assert candidate(hosts="::1/127") is False
	assert candidate(hosts='127.0.0.1:80') is False
	assert candidate(hosts='192.168.127.12/24') == False
	assert candidate(hosts="1:1:1:1:1:1:1::1") == False
	assert candidate(u'fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b/24') is True
	assert candidate(hosts="1:1:1:1:1:1:1:1:1:1::1") == False
	assert candidate(u"10.10.10.10/128") is False
	assert candidate(hosts='127.0.0.1') is False
	assert candidate(hosts="2001:db8:85a3:8d3:1319:8a2e:370:7348/128") is True
	assert candidate(hosts="192.168.1.1/128") is False
	assert candidate(hosts="192.168.1.1/32") == False
	assert candidate(
    "2001:0db8:85a3:0000:0000:8a2e:0370:7334") is True, "Simple IPv6 address failed"
	assert candidate(hosts="192.168.1.1/33") == False
	assert candidate(hosts="192.168.1.1/255.255.255.255") == False
	assert candidate(hosts="2001:0db8:0000:85a3:0000:0000:ac1f:8001") is True
	assert candidate(hosts="10.0.0.0") == False
	assert candidate(hosts="192.168.1.1/255.255.255.255.255") == False
	assert candidate(
    '192.168.1.0/24') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(hosts="2001:0db8:0000:0000:0000:ff00:0042:8329")
	assert candidate(hosts="192.168.0.1/24") == False
	assert candidate(hosts="192.168.1.1/256") == False
	assert candidate(
    "2001:0db8:0000:0000:0000:ff00:0042:8329/127")
	assert candidate(u'fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b/128') is True
	assert candidate(hosts='192.168.127.12/128/128/128/128/128') == False
	assert candidate(hosts="127.0.0.1/24") == False
	assert candidate(hosts="::1/5") is False
	assert candidate(
    '192.168.1.1') == False, "candidate failed to validate IPv4 Address"
	assert candidate(hosts='192.168.1.1') is False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b/32") is True
	assert candidate(
    "2001:0db8:0000:0000:0000:ff00:0042:8329") == True, "Simple IPv6 test"
	assert candidate(hosts="10.0.0.0/24") == False
	assert candidate(hosts="127.0.0.1/124") == False
	assert candidate(hosts='192.168.1.1/256') is False
	assert candidate(u"10.10.10.10") is False
	assert candidate(u"fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b") is True
	assert candidate(hosts="::1/4") is False
	assert candidate(hosts="192.168.1.1/255.255.255.255") is False
	assert candidate(
    '192.168.1.1/129') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334") == True
	assert candidate(hosts="::1/9") is False
	assert not candidate(hosts="2001:db8::ff00:42:8329/129")
	assert candidate(hosts="1:1:1:1:1:1:1:1::1") == False
	assert candidate(hosts="fd00:a516:7c1b:17cd:6d81:2137:bd2a:2c5b/64") == True
	assert candidate(hosts="::1/2") is False
	assert candidate(hosts="fd00:a516:7c1b:17cd:6d81:2137:bd2a:2c5b/128") is True
	assert candidate(hosts="10.1.1.1/16") is False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b") == True
	assert candidate(hosts="1.1.1.1/24") is False
	assert candidate(hosts="::1/11") is False
	assert candidate(hosts="::1/1") is False
	assert candidate(hosts="1:1:1:1:1:1:1:1:1::1") == False
	assert candidate(hosts="127.0.0.1/999") is False
	assert candidate(
    '192.168.1.1/0.0.0.255') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(hosts='192.168.127.12/128') == False
	assert candidate(hosts="192.168.1.1/255.255.255.255.255.255") == False
	assert candidate(hosts="127.0.0.1/128") is False
	assert candidate(hosts="192.168.1.1/255.255.255.256") == False
	assert candidate("2001:0db8:85a3:0000:0000:8a2e:0370:7334/128") is True, "IPv6 single host failed"
	assert candidate(hosts='192.168.1.1/128/128') is False
	assert candidate(hosts='192.168.1.1/128/0') is False
	assert candidate(hosts="::1/24") == False
	assert candidate(hosts='2001:0db8:85a3:0000:0000:8a2e:0370:7334/64') == True
	assert candidate(hosts='127.0.0.1:80:80') is False
	assert candidate(hosts="192.168.1.1/24") == False
	assert candidate(hosts="::1/7") is False
	assert candidate(hosts='192.168.1.1/24') is False
	assert candidate(hosts='192.168.127.12/128/128') == False
	assert candidate(hosts='192.168.127.12/128/128/128') == False
	assert candidate(hosts="1:1:1::1") == False
	assert candidate(hosts="127.0.0.1/127") == False
	assert candidate(hosts="127.0.0.1/122") == False
	assert candidate(hosts="::1/10") is False
	assert candidate(hosts="127.0.0.1") is False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b/64") == True
	assert candidate(hosts='192.168.1.1/123') is False
	assert candidate(hosts="192.168.1.1/0") == False
	assert candidate(hosts='192.168.1.1/0') is False
	assert candidate(hosts='127.0.0.1:80:80/32') is False
	assert candidate(hosts='192.168.1.1/32') is False
	assert candidate(hosts="1:1::1") == False
	assert candidate(hosts="fd00:a516:7c1b:17cd:6d81:2137:bd2a:2c5b") == True
	assert candidate(hosts="fd00:a516:7c1b:17cd:6d81:2137:bd2a:2c5b/120") == True
	assert candidate(hosts="192.168.1.1/24") is False
	assert candidate(hosts="fd00:a516:7c1b:17cd:6d81:2137:bd2a:2c5b") is True
	assert candidate(hosts="2001:db8::1/24") == False
	assert candidate(hosts="1.1.1.1/32") is False
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334/128") == True
	assert candidate(hosts="::1/12") is False
	assert candidate(hosts="192.168.1.1/123") == False
	assert candidate(hosts='192.168.127.12/128/128/128/128') == False
	assert not candidate(hosts="192.168.1.1/32")
	assert candidate(hosts='192.168.1.1/128/128/128') is False
	assert candidate(hosts="::1/0") is False
	assert candidate(hosts="1:2:3:4:5:6:7:8:9/128") == True
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334/24") == True
	assert candidate(hosts="192.168.1.1") == False
	assert candidate(hosts='192.168.127.12') == False
	assert candidate(hosts="fd00:a516:7c1b:17cd:6d81:2137:bd2a:2c5b/128") == True
	assert candidate(hosts='127.0.0.1:80/32') is False
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334/128") is True
	assert candidate(hosts="2001:db8::1:1/128") is False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b:1:1:1:1:1:1:1:1") is True
	assert candidate(hosts="2001:db8:85a3:8d3:1319:8a2e:370:7348") is True
	assert candidate(
    '192.168.1.1/255.255.255.255') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(hosts="::1/3") is False
	assert candidate(hosts="192.168.0.1") == False
	assert candidate(hosts="10.1.1.1") is False
	assert candidate(hosts="::1/8") is False
	assert candidate(
    '192.168.1.1/33') == False, "candidate failed to validate IPv4 Subnet"
	assert candidate(
    "2001:0db8:0000:0000:0000:ff00:0042:8329/64") == True, "IPv6 with mask"
	assert candidate(hosts='192.168.1.1/128/32') is False
	assert candidate(hosts="192.168.0.1/24/24") == False
	assert candidate(hosts="fd00:c2b6:b24b:be67:2827:688d:e6a1:6a3b/64") is True
	assert candidate(hosts='192.168.1.1/32/32') is False
	assert candidate(hosts="192.168.1.1/255.255.255.0") is False
	assert candidate(hosts="172.16.31.10/255.255.255.255/32") is False
	assert candidate(hosts="172.16.31.10/255.255.255.255") is False
	assert candidate(hosts='127.0.0.1/32') is False
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334/64") == True
	assert candidate(hosts="127.0.0.1/32") is False
	assert candidate(hosts="2001:0db8:85a3:0000:0000:8a2e:0370:7334/0") == True
	assert candidate(hosts='2001:0db8:85a3:0000:0000:8a2e:0370:7334/64') is True
def test_check():
	check(is_ipv6)
