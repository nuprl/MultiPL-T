def b(n, k, base_case):
    """ 
     :param n: int
     :param k: int
     :param base_case: list
     :return: int
     """
	### Canonical solution below ###    
    if k == 0 or k == n:
        print('base case!')
        base_case[0] += 1
        return 2
    else:
        return b(n-1, k-1, base_case) + b(n-1, k, base_case)

### Unit tests below ###
def check(candidate):
	assert candidate(6, 6, [0]) == 2
	assert candidate(6, 0, [0]) == 2
	assert candidate(0, 0, [0]) == 2
	assert candidate(5, 0, [0]) == 2
	assert candidate(2, 0, [0]) == 2
	assert candidate(2, 2, [0]) == 2
	assert candidate(1, 1, [0]) == 2
	assert candidate(4, 3, [0]) == 8
	assert candidate(3, 2, [0]) == 6
	assert candidate(4, 0, [0]) == 2
	assert candidate(4, 4, [0]) == 2
	assert candidate(4, 1, [0]) == 8
	assert candidate(1, 0, [0]) == 2
	assert candidate(5, 5, [0]) == 2
	assert candidate(3, 0, [0]) == 2
	assert candidate(3, 3, [0]) == 2
def test_check():
	check(b)
