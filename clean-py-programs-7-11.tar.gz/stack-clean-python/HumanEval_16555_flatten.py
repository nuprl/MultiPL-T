def flatten(iterable):
    """Flatten a given nested iterable."""
    ### Canonical solution below ###
    return (x for e in iterable for x in e)


### Unit tests below ###
def check(candidate):
	assert candidate(range(3))
	assert list(candidate([[1, 2], [3, 4]])) == [1, 2, 3, 4]
	assert candidate([[1, 2, 3], [4, 5, 6]])
def test_check():
	check(flatten)
