def quota_parse(quota_dict):
    """ 
     Parse the output of ``SESConnection.get_send_quota()`` to just the results.
     """
	### Canonical solution below ###    
    return quota_dict['GetSendQuotaResponse']['GetSendQuotaResult']

### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        'GetSendQuotaResponse': {
            'GetSendQuotaResult': {
                'Max24HourSend': 1000.0,
                'MaxSendRate': 1000.0,
                'SentLast24Hours': 1000.0,
            }
        }
    }
) == {
    'Max24HourSend': 1000.0,
    'MaxSendRate': 1000.0,
    'SentLast24Hours': 1000.0,
}
	assert candidate(
    {'GetSendQuotaResponse': {'GetSendQuotaResult': {'Max24HourSend': 1000.0, 'SentLast24Hours': 1000.0, 'MaxSendRate': 1000.0, 'MaxSendRate': 1000.0}}}) == {
    'Max24HourSend': 1000.0, 'SentLast24Hours': 1000.0, 'MaxSendRate': 1000.0}
	assert candidate(
    {'GetSendQuotaResponse': {'GetSendQuotaResult': {'Max24HourSend': 1000.0, 'SentLast24Hours': 1000.0, 'MaxSendRate': 1000.0}}}) == {
    'Max24HourSend': 1000.0, 'SentLast24Hours': 1000.0, 'MaxSendRate': 1000.0}
	assert candidate(dict(
    GetSendQuotaResponse=dict(
        GetSendQuotaResult=dict(
            Max24HourSend=1,
            MaxSendRate=2,
            SentLast24Hours=3
        )
    )
)) == dict(
    Max24HourSend=1,
    MaxSendRate=2,
    SentLast24Hours=3
)
	assert candidate(
    {'GetSendQuotaResponse': {'GetSendQuotaResult': {'Max24HourSend': 1000, 'MaxSendRate': 2000}}}
) == {'Max24HourSend': 1000, 'MaxSendRate': 2000}
	assert candidate(
    {
        'GetSendQuotaResponse': {
            'GetSendQuotaResult': {
                'Max24HourSend': '123',
                'MaxSendRate': '456',
                'SentLast24Hours': '789',
            },
        },
    },
) == {
    'Max24HourSend': '123',
    'MaxSendRate': '456',
    'SentLast24Hours': '789',
}
	assert candidate(dict(
    GetSendQuotaResponse=dict(
        GetSendQuotaResult=dict(
            Max24HourSend=1000,
            MaxSendRate=200,
            SentLast24Hours=100,
        ),
    ),
)) == dict(
    Max24HourSend=1000,
    MaxSendRate=200,
    SentLast24Hours=100,
)
	assert candidate(
    {'GetSendQuotaResponse': {
        'GetSendQuotaResult': {'Max24HourSend': 100000, 'MaxSendRate': 1.5,
                              'SentLast24Hours': 100},
        'ResponseMetadata': {'RequestId': '1234567890'}}}) == {
        'Max24HourSend': 100000, 'MaxSendRate': 1.5, 'SentLast24Hours': 100}
	assert candidate(
    {'GetSendQuotaResponse': {'GetSendQuotaResult': {'Max24HourSend': 1000.0, 'SentLast24Hours': 1000.0}}}) == {
    'Max24HourSend': 1000.0, 'SentLast24Hours': 1000.0}
def test_check():
	check(quota_parse)
