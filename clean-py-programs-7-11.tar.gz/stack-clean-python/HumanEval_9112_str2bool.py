def str2bool(string):
    """Quick function that converts a string to bool

    Args:
        string (str): The string to be converted to a bool

    Raises:
        TypeError: Raises an error if string is not of type bool or str

    Returns:
        bool: the converted string
    """
    ### Canonical solution below ###
    if isinstance(string,str):
        if string.lower() in ["true", "on", "yes", "1", "t"]:
            return True
        elif string.lower() in ["false", "off", "no", "0", "f"]:
            return False
    elif isinstance(string,bool):
        return string
    else:
        raise TypeError


### Unit tests below ###
def check(candidate):
	assert candidate("F") == False
	assert candidate("Yes") == True
	assert candidate(True) == True
	assert candidate("On") == True
	assert candidate("No") == False
	assert candidate("no") == False
	assert candidate("TRUE") == True
	assert candidate("nO") == False
	assert candidate("YES") == True
	assert candidate("yES") == True
	assert candidate(False) == False
	assert candidate("Off") == False
	assert candidate("t") == True
	assert candidate("1") == True
	assert candidate("ON") == True
	assert candidate("tRue") == True
	assert candidate("yEs") == True
	assert candidate("off") == False
	assert candidate("OFF") == False
	assert candidate("f") == False
	assert candidate("False") == False
	assert candidate("NO") == False
	assert candidate("yes") == True
	assert candidate("FALSE") == False
	assert candidate("oFF") == False
	assert candidate("0") == False
	assert candidate("T") == True
	assert candidate("oFf") == False
	assert candidate("false") == False
	assert candidate("oN") == True
	assert candidate("fALse") == False
	assert candidate("on") == True
	assert candidate("True") == True
	assert candidate("true") == True
def test_check():
	check(str2bool)
