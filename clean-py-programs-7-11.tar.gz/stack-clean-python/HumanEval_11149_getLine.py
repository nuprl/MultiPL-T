def getLine(x1, y1, x2, y2):
    """Returns a list of (x, y) tuples of every point on a line between
    (x1, y1) and (x2, y2). The x and y values inside the tuple are integers.

    Line generated with the Bresenham algorithm.

    Args:
      x1 (int, float): The x coordinate of the line's start point.
      y1 (int, float): The y coordinate of the line's start point.
      x2 (int, float): The x coordinate of the line's end point.
      y2 (int, float): The y coordiante of the line's end point.

    Returns:
      [(x1, y1), (x2, y2), (x3, y3), ...]

    Example:
    >>> getLine(0, 0, 6, 6)
    [(0, 0), (1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)]
    >>> getLine(0, 0, 3, 6)
    [(0, 0), (0, 1), (1, 2), (1, 3), (2, 4), (2, 5), (3, 6)]
    >>> getLine(3, 3, -3, -3)
    [(3, 3), (2, 2), (1, 1), (0, 0), (-1, -1), (-2, -2), (-3, -3)]
    """
    ### Canonical solution below ###
    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
    points = []
    issteep = abs(y2-y1) > abs(x2-x1)
    if issteep:
        x1, y1 = y1, x1
        x2, y2 = y2, x2
    rev = False
    if x1 > x2:
        x1, x2 = x2, x1
        y1, y2 = y2, y1
        rev = True
    deltax = x2 - x1
    deltay = abs(y2-y1)
    error = int(deltax / 2)
    y = y1
    ystep = None
    if y1 < y2:
        ystep = 1
    else:
        ystep = -1
    for x in range(x1, x2 + 1):
        if issteep:
            points.append((y, x))
        else:
            points.append((x, y))
        error -= deltay
        if error < 0:
            y += ystep
            error += deltax
    # Reverse the list if the coordinates were reversed
    if rev:
        points.reverse()
    return points


### Unit tests below ###
def check(candidate):
	assert candidate(0, 0, 3, 6) == [(0, 0), (0, 1), (1, 2), (1, 3), (2, 4), (2, 5), (3, 6)]
	assert candidate(-3, -3, 3, 3) == [(-3, -3), (-2, -2), (-1, -1), (0, 0), (1, 1), (2, 2), (3, 3)]
	assert candidate(0, 0, 0, 6) == [(0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6)]
	assert candidate(3.0, 3.0, -3.0, -3.0) == [(3, 3), (2, 2), (1, 1), (0, 0), (-1, -1), (-2, -2), (-3, -3)]
	assert candidate(0, 0, 1, -1) == [(0, 0), (1, -1)]
	assert candidate(0, 0, 6, 6) == [(0, 0), (1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)]
	assert candidate(3, 3, -3, -3) == [(3, 3), (2, 2), (1, 1), (0, 0), (-1, -1), (-2, -2), (-3, -3)]
	assert candidate(0.0, 0.0, 3.0, 6.0) == [(0, 0), (0, 1), (1, 2), (1, 3), (2, 4), (2, 5), (3, 6)]
	assert candidate(0, 0, 1, 1) == [(0, 0), (1, 1)]
	assert candidate(0, 0, 0, 0) == [(0, 0)]
	assert candidate(0, 0, 0, 1) == [(0, 0), (0, 1)]
	assert candidate(0.0, 0.0, 6.0, 6.0) == [(0, 0), (1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)]
	assert candidate(0, 0, -1, 0) == [(0, 0), (-1, 0)]
	assert candidate(0, 0, 1, 0) == [(0, 0), (1, 0)]
	assert candidate(0, 0, 6, 0) == [(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0)]
	assert candidate(0, 0, 0, -1) == [(0, 0), (0, -1)]
	assert candidate(0, 0, -1, 1) == [(0, 0), (-1, 1)]
def test_check():
	check(getLine)
