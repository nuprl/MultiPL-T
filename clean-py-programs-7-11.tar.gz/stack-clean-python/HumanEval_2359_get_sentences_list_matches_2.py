def get_sentences_list_matches_2(text, keysentence):
    """
    Check which key-sentences from occurs within a string
    and return the list of matches.

    :param text: text
    :type text: str or unicode
    :param keysentence: sentences
    :type: list(str or uniocde)
    :return: Set of sentences
    :rtype: set(str or unicode)
    """
    ### Canonical solution below ###
    match = set()
    for sentence in keysentence:
        if sentence in text:
            match.add(sentence)
    return sorted(list(match))


### Unit tests below ###
def check(candidate):
	assert candidate(
    'The quick brown fox jumps over the lazy dog.',
    ['The quick brown fox jumps over the lazy dog.']) == ['The quick brown fox jumps over the lazy dog.']
	assert candidate(
    'I am a happy person', ['sad']) == []
	assert candidate(u"This is a short sentence.", [u"This is a short sentence."]) == [u"This is a short sentence."]
	assert candidate(
    'I want to buy a car.',
    ['I want to buy a car.', 'I want to buy a house.']
) == ['I want to buy a car.']
	assert candidate(u"This is a test. This is another test. This is a third test.",
                                   [u"This is a test.", u"This is a third test.", u"This is a fourth test.", u"This is a fifth test.", u"This is a sixth test."]) == [u"This is a test.",
                                                                                                                                                        u"This is a third test."]
	assert candidate(
    "This is a test sentence. This is a test sentence.",
    ["This is a test sentence."]
) == ["This is a test sentence."]
	assert candidate(
    "This is a test sentence. This is another test sentence.",
    ["This is a test sentence.", "This is another test sentence."]
) == ["This is a test sentence.", "This is another test sentence."]
	assert candidate(
    "Hello, World! This is a test. This is a test.",
    ["Hello, World!", "This is a test."]
) == ["Hello, World!", "This is a test."]
	assert candidate(u"This is a sentence", [u"This is a sentence"]) == [u"This is a sentence"]
	assert candidate(
    'I want to buy a car. I want to buy a house.',
    ['I want to buy a car.', 'I want to buy a house.']
) == ['I want to buy a car.', 'I want to buy a house.']
	assert candidate(
    'This is a sentence. This is another sentence.',
    ['This is a sentence. This is another sentence.']
) == ['This is a sentence. This is another sentence.']
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ['The', 'fox']) == ['The', 'fox']
	assert candidate(
    "Hello, World! This is a test. This is a test.",
    []
) == []
	assert candidate(
    'I am a happy person', ['I am a happy person', 'happy']) == ['I am a happy person', 'happy']
	assert candidate(
    'I want to buy a car. I want to buy a house.',
    ['I want to buy a house.', 'I want to buy a car.']
) == ['I want to buy a car.', 'I want to buy a house.']
	assert candidate(
    "Hello, World! This is a test. This is a test.",
    ["Hello, World!", "This is a test.", "This is another test."]
) == ["Hello, World!", "This is a test."]
	assert candidate(
    "This is a test sentence. This is another test sentence.",
    ["This is a test sentence.", "This is not a test sentence."]
) == ["This is a test sentence."]
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ['brown', 'fox']) == ['brown', 'fox']
	assert candidate(
    'This is a sentence. This is another sentence. This is a sentence.',
    ['This is a sentence.', 'This is another sentence.']
) == ['This is a sentence.', 'This is another sentence.']
	assert candidate(u"This is a short sentence. This is a short sentence.", [u"This is a long sentence."]) == []
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ["The quick brown fox jumps over the lazy dog."]
) == ['The quick brown fox jumps over the lazy dog.']
	assert candidate(u"This is a short sentence. This is a short sentence.", [u"This is a long sentence.", u"This is a long sentence."]) == []
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ["The quick brown fox", "fox jumps"]) == ['The quick brown fox', 'fox jumps']
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ["The quick brown fox", "over the lazy dog"]) == ['The quick brown fox', 'over the lazy dog']
	assert candidate(
    'I am a happy person', ['I am a happy person', 'happy', 'person','sad','man']) == ['I am a happy person', 'happy', 'person']
	assert candidate(u"This is a test. This is another test. This is a third test.",
                                   [u"This is a test.", u"This is a third test."]) == [u"This is a test.",
                                                                                   u"This is a third test."]
	assert candidate(
    'This is a cat. This is a dog. This is a cat.',
    ['This is a cat.', 'This is a dog.']) == ['This is a cat.', 'This is a dog.']
	assert candidate(u"This is a test text",
                                    [u"This is a test text"]) == [u"This is a test text"]
	assert candidate(
    'I have a dog, I have a cat.',
    ['I have a dog']) == ['I have a dog']
	assert candidate(
    "The quick brown fox jumps over the lazy dog",
    ["The dog jumps over the fox", "The fox jumps over the dog"]) == []
	assert candidate(
    'I want to buy a car. I want to buy a house.',
    ['I want to buy a car.', 'I want to buy a house.', 'I want to go shopping.']
) == ['I want to buy a car.', 'I want to buy a house.']
	assert candidate(
    'This is a sentence. This is another sentence. This is a sentence.',
    ['This is a sentence. This is another sentence. This is a sentence.']
) == ['This is a sentence. This is another sentence. This is a sentence.']
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ["The quick brown fox jumps over the lazy dog."]) == ["The quick brown fox jumps over the lazy dog."]
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ["The quick brown fox", "over the lazy"]) == ['The quick brown fox', 'over the lazy']
	assert candidate(
    """
    This is a sentence.
    This is a sentence too.
    This is another sentence.
    """,
    []
) == []
	assert candidate(
    'I am a happy person', ['I am a happy person', 'happy', 'person','sad']) == ['I am a happy person', 'happy', 'person']
	assert candidate(u"This is a sentence. This is another sentence.", [u"This is a sentence.", u"This is another sentence."]) == [u"This is a sentence.", u"This is another sentence."]
	assert candidate(
    'This is a sentence. This is another sentence. This is a sentence.',
    ['This is a sentence. This is another sentence.']
) == ['This is a sentence. This is another sentence.']
	assert candidate(
    "Hello, World! This is a test. This is a test.",
    ["Hello, World!"]
) == ["Hello, World!"]
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ["The quick brown fox jumps over the lazy dog."]) == [
        "The quick brown fox jumps over the lazy dog."]
	assert candidate(
    'I am a happy person', ['I am a happy person', 'happy', 'person']) == ['I am a happy person', 'happy', 'person']
	assert candidate(
    "This is a test string. This is a second test string.",
    ["This is a third test string.", "This is a test string."]
) == ["This is a test string."]
	assert candidate(
    """
    This is a sentence.
    This is a sentence too.
    This is another sentence.
    """,
    ["This is a sentence.", "This is another sentence.", "This is a sentence."]
) == ["This is a sentence.", "This is another sentence."]
	assert candidate(
    'I am a happy person', ['I am', 'happy']) == ['I am', 'happy']
	assert candidate(u"This is a sentence. This is another sentence.", [u"This is a sentence"]) == [u"This is a sentence"]
	assert candidate(
    'I am a happy person', []) == []
	assert candidate(u"This is a short sentence. This is a short sentence.", [u"This is a long sentence.", u"This is a short sentence."]) == [u"This is a short sentence."]
	assert candidate(
    'I am a happy person', ['happy', 'person']) == ['happy', 'person']
	assert candidate(
    "The cat was stolen. The dog was stolen.",
    ["The cat was stolen.", "The dog was stolen."]
) == ['The cat was stolen.', 'The dog was stolen.']
	assert candidate(
    "The quick brown fox jumps over the lazy dog.",
    ["The quick brown fox", "over the"]) == ['The quick brown fox', 'over the']
	assert candidate(u"This is a short sentence.", [u"This is a long sentence."]) == []
	assert candidate(
    'This is a cat. This is a dog.',
    ['This is a cat.', 'This is a dog.', 'This is a mouse.']) == ['This is a cat.', 'This is a dog.']
	assert candidate(
    "Hello, World! This is a test. This is a test.",
    ["Hello, World!", "This is another test."]
) == ["Hello, World!"]
	assert candidate(
    "This is a test string. This is a second test string.",
    ["This is a test string.", "This is a third test string."]
) == ["This is a test string."]
	assert candidate(
    'I am a happy person', ['happy']) == ['happy']
	assert candidate(
    'This is a sentence. This is another sentence.',
    ['This is a sentence.']
) == ['This is a sentence.']
	assert candidate(
    "The quick brown fox jumps over the lazy dog",
    ["The quick brown fox jumps over the lazy dog"]) == ["The quick brown fox jumps over the lazy dog"]
	assert candidate(
    'I want to buy a car.',
    ['I want to buy a car.']
) == ['I want to buy a car.']
	assert candidate(
    "This is a test sentence. This is another test sentence.",
    ["This is a test sentence.", "This is another test sentence.", "This is not a test sentence."]
) == ["This is a test sentence.", "This is another test sentence."]
	assert candidate(
    'I am a happy person', ['I am a happy person']) == ['I am a happy person']
	assert candidate(u"This is a test. This is another test. This is a third test.",
                                   [u"This is a test.", u"This is a third test.", u"This is a fourth test.", u"This is a fifth test."]) == [u"This is a test.",
                                                                                                                                              u"This is a third test."]
	assert candidate(
    'I want to buy a car. I want to buy a house.',
    ['I want to buy a car.']
) == ['I want to buy a car.']
	assert candidate(
    'This is a cat. This is a dog.',
    ['This is a cat.', 'This is a dog.']) == ['This is a cat.', 'This is a dog.']
	assert candidate(
    "a b c d e f g h i j k l m n o p q r s t u v w x y z",
    ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
) == ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
	assert candidate(
    "This is a test sentence. This is another test sentence.",
    ["This is a test sentence."]
) == ["This is a test sentence."]
	assert candidate(
    'This is a cat. This is a dog.',
    ['This is a mouse.', 'This is a cat.', 'This is a dog.', 'This is a mouse.']) == ['This is a cat.', 'This is a dog.']
	assert candidate(
    'This is a cat. This is a dog.',
    ['This is a mouse.', 'This is a cat.', 'This is a dog.']) == ['This is a cat.', 'This is a dog.']
	assert candidate(
    """
    This is a sentence.
    This is a sentence too.
    This is another sentence.
    """,
    ["This is a sentence.", "This is another sentence."]
) == ["This is a sentence.", "This is another sentence."]
	assert candidate(u"This is a short sentence. This is a short sentence.", [u"This is a short sentence.", u"This is a long sentence."]) == [u"This is a short sentence."]
	assert candidate(u"This is a test. This is another test. This is a third test.",
                                   [u"This is a test.", u"This is a third test.", u"This is a fourth test."]) == [u"This is a test.",
                                                                                                            u"This is a third test."]
	assert candidate(
    "The cat in the hat sat on the flat mat.",
    ["The cat", "the hat"]
) == ["The cat", "the hat"]
	assert candidate(
    """
    This is a sentence.
    This is a sentence too.
    This is another sentence.
    """,
    ["This is a sentence."]
) == ["This is a sentence."]
def test_check():
	check(get_sentences_list_matches_2)
