def copy_item(item, **kwargs):
    """Return a copy of the item."""
    ### Canonical solution below ###
    item_copy = item.copy()
    for key, value in kwargs.items():
        item_copy[key] = value
    return item_copy


### Unit tests below ###
def check(candidate):
	assert candidate(frozenset({1, 2})) == frozenset({1, 2})
	assert candidate(
    {"id": "1", "title": "foo"},
    id="2",
    author="bar",
) == {"id": "2", "title": "foo", "author": "bar"}
	assert candidate(
    {'a': 1, 'b': 2},
    b=20
)['b'] == 20
	assert candidate(
    {'type': 'file', 'name': 'foo.txt','size': 42}
) == {
    'type': 'file', 'name': 'foo.txt','size': 42
}
	assert candidate({'a': 1}, b=2) == {'a': 1, 'b': 2}
	assert candidate({"x": 1, "y": 2}, name="foo") == {"x": 1, "y": 2, "name": "foo"}
	assert candidate([1, 2]) == [1, 2]
	assert candidate(
    {'type': 'item', 'name': 'a'},
    name='b',
    description='c',
    price=100) == {'type': 'item', 'name': 'b', 'description': 'c', 'price': 100}
	assert candidate(dict(x=1), y=2) == dict(x=1, y=2)
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(
    {'a': 1, 'b': 2},
    c=3,
) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(name='spam', price=10), price=20) == dict(name='spam', price=20)
	assert candidate({'a': 1}) == {'a': 1}
	assert candidate(
    {'a': 1, 'b': 2},
    b=20,
    c=30
)['c'] == 30
	assert candidate({1, 2}) == {1, 2}
	assert candidate(
    {'a': 1},
    b=2,
    c=3) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(
    {'name': 'foo', 'description': 'bar', 'price': 10},
    discount=0.1) == {
        'name': 'foo',
        'description': 'bar',
        'price': 10,
        'discount': 0.1,
    }
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    a=10,
    c=30,
) == {
    'a': 10,
    'b': 2,
    'c': 30,
}
	assert candidate(dict(x=1)) == dict(x=1)
	assert candidate(dict(x=1), x=2) == dict(x=2)
	assert candidate(
    {'a': 1, 'b': 2},
    c=3) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(
    {'a': 1, 'b': 2},
    b=20
)['a'] == 1
	assert candidate({"x": 1, "y": 2}) == {"x": 1, "y": 2}
	assert candidate(dict(a=1, b=2), c=3)['c'] == 3
	assert candidate({}) == {}
	assert candidate(
    {'type': 'file', 'name': 'foo.txt','size': 42},
    size=100
) == {
    'type': 'file', 'name': 'foo.txt','size': 100
}
	assert candidate(dict(x=1), x=2, y=3) == dict(x=2, y=3)
	assert candidate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
def test_check():
	check(copy_item)
