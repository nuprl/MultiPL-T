def get_line_token(lines, startswith):
    """Consumes iterator until it finds a line starting with startswith,
    and returns that line."""
    ### Canonical solution below ###
    while lines:
        line = next(lines)
        if line.startswith(startswith):
            return line[len(startswith):].strip()


### Unit tests below ###
def check(candidate):
	assert candidate(iter(['foo']), 'foo') == ''
	assert candidate(iter(['first line','second line', 'third line']),'second') == 'line'
	assert candidate(iter(['# Comment', 'not a comment']), '#') == 'Comment'
	assert candidate(iter(['abc', 'def']), 'd') == 'ef'
	assert candidate(iter(['foo', 'bar', 'baz']), 'f') == 'oo'
	assert candidate(iter(['foo', 'bar', 'baz']), 'b') == 'ar'
	assert candidate(iter(['a\n', 'b\n']), 'a') == ''
	assert candidate(iter(['foo', 'bar', 'baz']), 'baz') == ''
	assert candidate(iter(["foo", "bar", "baz"]), "b") == "ar"
	assert candidate(iter(["foo"]), "foo") == ""
	assert candidate(iter(['abc', 'def']), 'de') == 'f'
	assert candidate(iter(["foo", "bar"]), "b") == "ar"
	assert candidate(iter(['#hello', 'world']), '#') == 'hello'
	assert candidate(iter(['abc', 'def']), 'a') == 'bc'
	assert candidate(iter(['abc', 'def']), 'ab') == 'c'
	assert candidate(iter(
    """
foo
bar
baz
""".splitlines()), 'baz') == ''
	assert candidate(iter(["foo", "bar"]), "f") == "oo"
	assert candidate(iter(['foo', 'bar']), 'bar') == ''
	assert candidate(iter(["# Comment\n"]), "#") == "Comment"
	assert candidate(iter(['a\n', 'b\n']), 'b') == ''
	assert candidate(iter(["line one", "line two"]), "line") == "one"
	assert candidate(iter(
    ["# Comment\n", "line\n", "more\n"]), "#") == "Comment"
	assert candidate(iter(["#foo", "bar", ""]), "#") == "foo"
	assert candidate(iter(['# Comment',' # Comment', 'a']), '#') == 'Comment'
def test_check():
	check(get_line_token)
