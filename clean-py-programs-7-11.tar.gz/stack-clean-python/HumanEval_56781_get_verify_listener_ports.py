def get_verify_listener_ports(module, listener_ports=None):
    """
    Validate and get listener ports

    :param module: Ansible module object
    :param listener_ports: list of ports to for which backend server health status is required
    :return: formatted listener ports
    """
    ### Canonical solution below ###

    if listener_ports:
        if len(listener_ports) > 0:
            for port in listener_ports:

                try:
                    port = int(port)
                except Exception as ex:
                    module.fail_json(msg='Invalid port value')
        else:
            listener_ports = None

    return listener_ports


### Unit tests below ###
def check(candidate):
	assert candidate(None, []) == []
	assert candidate(None, None) is None
	assert candidate(module=None, listener_ports=[80, 443]) == [80, 443]
	assert candidate(module=None, listener_ports=None) is None
	assert candidate(None, listener_ports=[80]) == [80]
	assert candidate(module=None, listener_ports=[]) == []
	assert candidate(None, [1, 2]) == [1, 2]
	assert candidate(
    None, listener_ports=[80, 8080, 443, 8081]) == [80, 8080, 443, 8081]
	assert candidate(None, [80]) == [80]
	assert candidate(None, [80, 443, 8080]) == [80, 443, 8080]
	assert candidate(None, [80, 81]) == [80, 81]
	assert candidate(None, None) == None
	assert candidate(module=None, listener_ports=[8080, 8081]) == [8080, 8081]
	assert candidate(None, listener_ports=[80, 8080, 443]) == [80, 8080, 443]
	assert candidate(None, listener_ports=[80, 443]) == [80, 443]
	assert candidate(None, listener_ports=[1234, 4567, 8901]) == [1234, 4567, 8901]
	assert candidate(None, [80, 443]) == [80, 443]
	assert candidate(module=None, listener_ports=[80]) == [80]
	assert candidate(None, listener_ports=None) == None
	assert candidate(None, [80, 8080]) == [80, 8080]
	assert candidate(module=None, listener_ports=[1, 2]) == [1, 2]
	assert candidate(None, listener_ports=[]) == []
	assert candidate(None, [80, 443, 10000]) == [80, 443, 10000]
	assert candidate(module=None, listener_ports=[8080]) == [8080]
	assert candidate(module=None, listener_ports=None) == None
	assert candidate(module=None, listener_ports=[1, 2, 3]) == [1, 2, 3]
	assert candidate(None, [80]) == [80], "candidate Failed"
def test_check():
	check(get_verify_listener_ports)
