def to_platform(os_name):
    """ Convert an os-name string into a Kotlin-Native platform.
     
     Args:
     os_name: name of the host OS from the repository ctx.
     
     Returns:
     Option from PLATFORMS.
     """
	### Canonical solution below ###    
    os_name = os_name.lower().replace(" ", "")
    if os_name.startswith("macos"):
        return "macos"
    elif os_name.startswith("windows"):
        return "windows"
    else:
        return "linux"

### Unit tests below ###
def check(candidate):
	assert candidate("linux") == "linux"
	assert candidate(
    "Windows-x86_64") == "windows", "Windows-x86_64 should be windows"
	assert candidate("windows") == "windows", candidate("windows")
	assert candidate("Windows") == candidate("Windows")
	assert candidate("macos_x64") == "macos", candidate("macos_x64")
	assert candidate(
    "linux-x86_64") == "linux", "Expected linux-x86_64 to be linux"
	assert candidate(
    "windows") == "windows"
	assert candidate("Mac OS X") == "macos"
	assert candidate("macos-x86_64-arm64") == "macos"
	assert candidate(
    "macos") == "macos"
	assert candidate("macOS") == candidate("macos")
	assert candidate("linux_x86_64") == "linux"
	assert candidate("linux-x86_64") == "linux"
	assert candidate("macOS") == "macos"
	assert candidate("Linux") == candidate("Linux")
	assert candidate("windows_x64") == "windows", candidate("windows_x64")
	assert candidate("macos-arm64") == "macos"
	assert candidate(
    "linux-x86_64") == "linux", "linux-x86_64 should be linux"
	assert candidate(
    "windows-x86_64") == "windows"
	assert candidate(
    "windows-x86_64") == "windows", "Expected windows-x86_64 to be windows"
	assert candidate(
    "windows-x86") == "windows"
	assert candidate(
    "macos-arm64") == "macos"
	assert candidate("windows") == "windows"
	assert candidate(
    "macOS-x86_64") == "macos", "macOS-x86_64 should be macos"
	assert candidate("macos-x64") == "macos", candidate("macos-x64")
	assert candidate("windows-x86_64") == "windows"
	assert candidate("macOS") == candidate("macOS")
	assert candidate("Windows") == "windows"
	assert candidate("Windows") == candidate("windows")
	assert candidate(
    "linux-arm") == "linux"
	assert candidate(
    "linux") == "linux"
	assert candidate(
    "macos-x86_64") == "macos"
	assert candidate("windows-x64") == "windows", candidate("windows-x64")
	assert candidate(
    "linux-x86") == "linux"
	assert candidate(
    "macos-x86_64") == "macos", "Expected macos-x86_64 to be macos"
	assert candidate("Linux") == "linux"
	assert candidate("macos") == "macos", candidate("macos")
	assert candidate("macos-aarch64") == "macos"
	assert candidate("macos") == "macos"
	assert candidate("macos-x86_64") == "macos"
	assert candidate("Linux") == candidate("linux")
	assert candidate(
    "linux-x86_64") == "linux"
	assert candidate(
    "linux-arm64") == "linux"
	assert candidate("macos_x86_64") == "macos"
	assert candidate("windows_x86_64") == "windows"
def test_check():
	check(to_platform)
