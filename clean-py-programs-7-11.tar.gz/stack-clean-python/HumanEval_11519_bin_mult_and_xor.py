def bin_mult_and_xor(a, b):
    """ 
     Return mutliply a and b bit by bit and return the xor of all the bits.
     """
	### Canonical solution below ###    
    a_binary = format(a, "b")
    b_binary = format(b, "b")
    max_bin_len = max(len(a_binary), len(b_binary))
    a_binary = format(a,"0" + str(max_bin_len) +"b")
    b_binary = format(b,"0" + str(max_bin_len) +"b")

    mult_and_xor = 0
    for i in range(max_bin_len):
        mult_and_xor ^= int(a_binary[i]) * int(b_binary[i])

    return mult_and_xor

### Unit tests below ###
def check(candidate):
	assert candidate(5, 7) == 0, "5*7 = 35 but candidate(5,7) = {}".format(candidate(5,7))
	assert candidate(11, 13) == 0, "11*13 = 143 but candidate(11,13) = {}".format(candidate(11,13))
	assert candidate(2, 0) == 0
	assert candidate(10, 13) == 1, "10 * 13 should be 1"
	assert candidate(123, 456) == 0
	assert candidate(3, 1) == 1
	assert candidate(0, 2) == 0
	assert candidate(3, 10) == 1
	assert candidate(2, 3) == 1, "candidate(2, 3) must be 1"
	assert candidate(2, 3) == 1
	assert candidate(1, 1) == 1
	assert candidate(123, 123) == 0
	assert candidate(4, 5) == 1
	assert candidate(1, 0) == 0
	assert candidate(2, 1) == 0
	assert candidate(12,13) == 0
	assert candidate(3, 2) == 1
	assert candidate(2**31-2, 2**31-2) == 0
	assert candidate(5, 4) == 1
	assert candidate(123456789, 123456789) == 0, "candidate(123456789, 123456789) should be 0"
	assert candidate(6, 6) == 0
	assert candidate(255, 255) == 0
	assert candidate(15, 17) == 1
	assert candidate(2, 4) == 0
	assert candidate(255, 253) == 1
	assert candidate(111, 111) == 0
	assert candidate(5, 5) == 0
	assert candidate(3, 3) == 0
	assert candidate(123456, 123456) == 0
	assert candidate(0, 0) == 0
	assert candidate(1000, 1001) == 0
	assert candidate(10, 3) == 1
	assert candidate(255, 254) == 1
	assert candidate(5, 2) == 0
	assert candidate(3, 5) == 1
	assert candidate(15, 15) == 0
	assert candidate(2,3) == 1
	assert candidate(10, 10) == 0
	assert candidate(9, 9) == 0
	assert candidate(1, 3) == 1
	assert candidate(5, 3) == 1
	assert candidate(17, 17) == 0
	assert candidate(0, 1) == 0
	assert candidate(12, 12) == 0
def test_check():
	check(bin_mult_and_xor)
