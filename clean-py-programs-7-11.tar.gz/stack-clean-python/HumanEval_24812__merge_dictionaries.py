def _merge_dictionaries(dict1, dict2):
    """ 
     Recursive merge dictionaries.
     
     :param dict1: Base dictionary to merge.
     :param dict2: Dictionary to merge on top of base dictionary.
     :return: Merged dictionary
     """
	### Canonical solution below ###    
    for key, val in dict1.items():
        if isinstance(val, dict):
            dict2_node = dict2.setdefault(key, {})
            _merge_dictionaries(val, dict2_node)
        else:
            if key not in dict2:
                dict2[key] = val

    return dict2

### Unit tests below ###
def check(candidate):
	assert candidate(dict1={'a': 1, 'b': {'c': 2}}, dict2={'a': 2, 'b': {'c': 3}}) == {'a': 2, 'b': {'c': 3}}
	assert candidate(
    {'a': 1, 'b': {'b1': 1, 'b2': 2}},
    {'b': {'b2': 3, 'b3': 4}}
) == {'a': 1, 'b': {'b1': 1, 'b2': 3, 'b3': 4}}
	assert candidate(
    {"a": {"b": 1, "c": 2}},
    {"a": {"b": 3}}
) == {"a": {"b": 3, "c": 2}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'c': 4, 'e': 5}}) == {
        'a': {'b': 1, 'c': 4, 'e': 5},
        'd': 3}
	assert candidate(
    {
        'a': {
            'b': 1,
            'c': 2
        },
        'd': 4
    },
    {
        'a': {
            'b': 3,
            'd': 5
        },
        'e': 6
    }
) == {
    'a': {
        'b': 3,
        'c': 2,
        'd': 5
    },
    'd': 4,
    'e': 6
}
	assert candidate(dict1={'a': 1, 'b': {'c': 2}}, dict2={'a': 2, 'b': {'d': 3}}) == {'a': 2, 'b': {'c': 2, 'd': 3}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'b': 4, 'e': 5}, 'd': 6, 'f': 7}
) == {
    'a': {'b': 4, 'c': 2, 'e': 5},
    'd': 6,
    'f': 7
}
	assert candidate(
    {"a": {"b": 1, "c": 2}},
    {"a": {"b": 3, "c": 4, "d": 5}}
) == {"a": {"b": 3, "c": 4, "d": 5}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'b': 10, 'e': 5}, 'd': 4, 'f': 6}
) == {
    'a': {'b': 10, 'c': 2, 'e': 5},
    'd': 4,
    'f': 6
}
	assert candidate(
    {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}},
    {'a': 3, 'c': {'b': 3}}
) == {'a': 3, 'b': 2, 'c': {'a': 1, 'b': 3}}
	assert candidate(
    {'foo': {'bar': {'baz': 'qux','spam': 'eggs'}, 'baz': 'bar'}},
    {'foo': {'bar': {'baz': 'quux', 'bacon': 'eggs'}, 'baz': 'qux'}}) == \
       {'foo': {'bar': {'baz': 'quux','spam': 'eggs', 'bacon': 'eggs'}, 'baz': 'qux'}}
	assert candidate(
    {'a': 1, 'b': 2, 'c': {'c1': 1, 'c2': 2}},
    {'c': {'c2': 10, 'c3': 20}, 'd': 30}
) == {
    'a': 1,
    'b': 2,
    'c': {'c1': 1, 'c2': 10, 'c3': 20},
    'd': 30
}
	assert candidate(
    {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}},
    {'c': {'f': 6}, 'g': 7}
) == {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}, 'g': 7}
	assert candidate(
    {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}},
    {'a': 10, 'f': 6, 'c': {'d': 30}}) == {'a': 10, 'b': 2, 'c': {'d': 30, 'e': 4}, 'f': 6}
	assert candidate(
    {"a": 1, "b": {"b1": 1, "b2": 2}},
    {"c": 3, "b": {"b2": 3, "b3": 4}}
) == {
    "a": 1,
    "b": {
        "b1": 1,
        "b2": 3,
        "b3": 4
    },
    "c": 3
}
	assert candidate(
    {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': {'f': 6}},
    {'a': 2, 'b': {'c': 3, 'e': 5}, 'e': {'g': 7}}) == \
    {'a': 2, 'b': {'c': 3, 'd': 3, 'e': 5}, 'e': {'f': 6, 'g': 7}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'b': 4, 'e': 5}, 'd': 6}) == {'a': {'b': 4, 'c': 2, 'e': 5}, 'd': 6}
	assert candidate(
    {"a": {"b": 1, "c": 2}},
    {"a": {"b": 3, "d": 4}}
) == {"a": {"b": 3, "c": 2, "d": 4}}
	assert candidate(
    {'foo': 'bar', 'bar': {'baz': 'qux', 'qux': {'foo': 'bar'}}},
    {'bar': {'qux': {'bar': 'baz'}}}) == {
    'foo': 'bar',
    'bar': {'baz': 'qux', 'qux': {'foo': 'bar', 'bar': 'baz'}}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'b': 4, 'e': 5}, 'd': 6}
) == {
    'a': {'b': 4, 'c': 2, 'e': 5},
    'd': 6
}
	assert candidate(
    {'foo': {'bar': 1, 'baz': 2}, 'qux': 3},
    {'foo': {'baz': 4, 'quux': 5}}) == {
        'foo': {'bar': 1, 'baz': 4, 'quux': 5},
        'qux': 3}
	assert candidate(
    {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': {'f': 4, 'g': 5}},
    {'a': 6, 'b': {'c': 7, 'h': 8}, 'e': {'f': 9, 'i': 10}}) == \
    {'a': 6, 'b': {'c': 7, 'd': 3, 'h': 8}, 'e': {'f': 9, 'g': 5, 'i': 10}}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'c': 10, 'd': 20, 'e': 30}
) == {
    'a': 1,
    'b': 2,
    'c': 10,
    'd': 20,
    'e': 30
}
	assert candidate(dict1={'a': 1, 'b': {'c': 2}}, dict2={'a': 2, 'b': {'d': 3}, 'e': {'f': 5}}) == {'a': 2, 'b': {'c': 2, 'd': 3}, 'e': {'f': 5}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'b': 4, 'e': 5}}) == {'a': {'b': 4, 'c': 2, 'e': 5}, 'd': 3}
	assert candidate(
    {'a': 1, 'b': {'c': 2, 'd': 4}},
    {'a': 3, 'b': {'c': 3, 'e': 5}}
) == {'a': 3, 'b': {'c': 3, 'd': 4, 'e': 5}}
	assert candidate(
    {
        'a': {
            'b': 1,
            'c': 2
        },
        'd': 4
    },
    {
        'a': {
            'b': 3,
            'd': 5
        }
    }
) == {
    'a': {
        'b': 3,
        'c': 2,
        'd': 5
    },
    'd': 4
}
	assert candidate(
    {'a': 1, 'b': {'c': 2, 'd': 3}},
    {'a': 10, 'b': {'c': 20, 'e': 5}}
) == {'a': 10, 'b': {'c': 20, 'd': 3, 'e': 5}}
	assert candidate(
    {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5
            }
        }
    },
    {
        'c': {
            'd': 6,
            'f': {
                'g': 7,
                'h': 8
            }
        }
    }
) == {
    'a': 1,
    'b': 2,
    'c': {
        'd': 6,
        'e': 4,
        'f': {
            'g': 7,
            'h': 8
        }
    }
}
	assert candidate(
    {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': {'f': {'g': 4, 'h': 5}}},
    {'a': 6, 'b': {'c': 7}, 'e': {'f': {'h': 8}}}) == \
    {'a': 6, 'b': {'c': 7, 'd': 3}, 'e': {'f': {'g': 4, 'h': 8}}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': {'e': 3}},
    {'a': {'b': 10, 'f': 20}, 'd': {'e': 30}}
) == {
    'a': {'b': 10, 'c': 2, 'f': 20},
    'd': {'e': 30}
}
	assert candidate(
    {"a": {"b": 1, "c": 2}},
    {"a": {"b": 3, "c": 4}}
) == {"a": {"b": 3, "c": 4}}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'c': 4, 'e': 5}}) == candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'c': 4, 'e': 5}})
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'b': 10, 'e': 5}, 'd': 4}
) == {
    'a': {'b': 10, 'c': 2, 'e': 5},
    'd': 4
}
	assert candidate(
    {'a': {'b': 1, 'c': 2}, 'd': 3},
    {'a': {'b': 4, 'e': 5}, 'd': 6, 'f': 7}) == {'a': {'b': 4, 'c': 2, 'e': 5}, 'd': 6, 'f': 7}
	assert candidate(
    {"a": {"b": 1, "c": 2}},
    {"a": {"d": 3, "c": 4}}
) == {"a": {"b": 1, "c": 4, "d": 3}}
	assert candidate(
    {'a': 1, 'b': {'c': 3, 'd': 4, 'e': {'f': 6}}},
    {'a': 2, 'b': {'c': 5, 'd': 4, 'e': {'g': 7}}}) == \
    {'a': 2, 'b': {'c': 5, 'd': 4, 'e': {'f': 6, 'g': 7}}}
	assert candidate(dict1={'a': 1, 'b': {'c': 2}}, dict2={'a': 2, 'b': {'d': 3}, 'e': 4}) == {'a': 2, 'b': {'c': 2, 'd': 3}, 'e': 4}
	assert candidate(dict1={'a': 1, 'b': {'c': 2}}, dict2={'a': 2, 'b': {'c': 3, 'd': 4}}) == {'a': 2, 'b': {'c': 3, 'd': 4}}
	assert candidate(
    {
        'a': 'b',
        'c': 'd',
        'e': {
            'f': 'g',
            'h': 'i',
            'j': {
                'k': 'l',
               'm': 'n',
            },
        },
    },
    {
        'a': 'b2',
        'c': 'd2',
        'e': {
            'h': 'i2',
            'j': {
               'm': 'n2',
            },
        },
    }
) == {
    'a': 'b2',
    'c': 'd2',
    'e': {
        'f': 'g',
        'h': 'i2',
        'j': {
            'k': 'l',
           'm': 'n2',
        },
    },
}
	assert candidate(
    {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}},
    {'a': 10, 'c': {'d': 30}}
) == {'a': 10, 'b': 2, 'c': {'d': 30, 'e': 4}}
	assert candidate(
    {
        'a': {
            'b': 1,
            'c': 2
        },
        'd': 4
    },
    {
        'a': {
            'b': 3,
            'd': 5
        },
        'e': {
            'f': 6
        }
    }
) == {
    'a': {
        'b': 3,
        'c': 2,
        'd': 5
    },
    'd': 4,
    'e': {
        'f': 6
    }
}
	assert candidate(
    {'a': 1, 'b': 2, 'c': {'x': 5, 'y': 10}},
    {'a': 2, 'b': 3, 'c': {'x': 7, 'z': 3}}
) == {'a': 2, 'b': 3, 'c': {'x': 7, 'y': 10, 'z': 3}}
	assert candidate(
    {
        "a": 1,
        "b": {
            "c": 3,
            "d": 4
        }
    },
    {
        "b": {
            "c": 5,
            "e": 6
        }
    }
) == {
    "a": 1,
    "b": {
        "c": 5,
        "d": 4,
        "e": 6
    }
}
def test_check():
	check(_merge_dictionaries)
