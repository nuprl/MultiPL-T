def remove_headers(headers, name):
    """Remove all headers with name *name*.

    The list is modified in-place and the updated list is returned.
    """
    ### Canonical solution below ###
    i = 0
    name = name.lower()
    for j in range(len(headers)):
        if headers[j][0].lower() != name:
            if i != j:
                headers[i] = headers[j]
            i += 1
    del headers[i:]
    return headers


### Unit tests below ###
def check(candidate):
	assert candidate(
    [("Accept", "text/plain"), ("Accept-Encoding", "gzip")],
    "accept-encoding"
) == [("Accept", "text/plain")]
	assert candidate(
    [("Content-Type", "text/html"), ("content-length", "1234")], "content-length") == [
        ("Content-Type", "text/html")]
	assert candidate(
    [("Content-Type", "text/html"), ("content-length", "1234")], "content-type") == [
        ("content-length", "1234")]
	assert candidate(
    [("Foo", "bar"), ("foo", "baz"), ("quux", "spam")], "FOO") == \
    [("quux", "spam")]
	assert candidate(
    [('a', 'b'), ('c', 'd'), ('a', 'e')],
    'b') == [('a', 'b'), ('c', 'd'), ('a', 'e')]
	assert candidate([], 'accept') == []
	assert candidate(
    [("content-type", "text/plain")], "CONTENT-TYPE") == []
	assert candidate(
    [("Content-Length", "123"), ("content-type", "text/html")],
    "content-length",
) == [("content-type", "text/html")]
	assert candidate(
    [("Content-Length", "100"), ("content-type", "text/plain")],
    "Content-Type") == [("Content-Length", "100")]
	assert candidate([], "Content-Type") == []
	assert candidate(
    [("Accept", "text/html"), ("Accept", "application/xml")],
    "CONTENT-type") == [("Accept", "text/html"), ("Accept", "application/xml")]
	assert candidate(
    [("Content-Type", "text/html"), ("content-length", "1234")], "CONTENT-TYPE") == [
        ("content-length", "1234")]
	assert candidate(
    [("a", "b"), ("c", "d"), ("a", "e")],
    "b",
) == [("a", "b"), ("c", "d"), ("a", "e")]
	assert candidate(
    [("a", "b"), ("c", "d"), ("a", "e")],
    "a",
) == [("c", "d")]
	assert candidate(
    [("Content-Length", "100"), ("content-type", "text/plain")],
    "content-type") == [("Content-Length", "100")]
	assert candidate(
    [("content-type", "text/plain")], "Content-Type") == []
	assert candidate(
    [("Content-Type", "text/html"), ("content-length", "1234")], "Content-type") == [
        ("content-length", "1234")]
	assert candidate(
    [
        ('Content-Type', 'text/plain'),
        ('Content-Length', '123'),
        ('ETag', '456'),
    ],
    'Content-Type',
) == [
    ('Content-Length', '123'),
    ('ETag', '456'),
]
	assert candidate(
    [("Content-Type", "text/html"), ("Content-Length", "100")], "content-type") == [("Content-Length", "100")]
	assert candidate(
    [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('k', 'l'), ('m', 'n')],
    'k') == [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('m', 'n')]
	assert candidate(
    [
        (b'Content-Length', b'123'),
        (b'Content-Type', b'text/html'),
        (b'Set-Cookie', b'foo'),
        (b'Set-Cookie', b'bar'),
    ],
    b'content-length'
) == [
    (b'Content-Type', b'text/html'),
    (b'Set-Cookie', b'foo'),
    (b'Set-Cookie', b'bar'),
]
	assert candidate(
    [("a", "b"), ("A", "c"), ("a", "d")], "z") == [("a", "b"), ("A", "c"), ("a", "d")]
	assert candidate(
    [
        ('X-Foo', 'bar'),
        ('X-Bar', 'baz'),
    ],
    'x-bar'
) == [
    ('X-Foo', 'bar'),
]
	assert candidate([('Accept', 'text/plain')], 'accept-language') == \
    [('Accept', 'text/plain')]
	assert candidate(
    [("a", "b"), ("c", "d"), ("a", "e")], "a") == [("c", "d")]
	assert candidate(
    [("Content-Type", "text/html"), ("content-length", "1234")], "CoNtEnT-tyPe") == [
        ("content-length", "1234")]
	assert candidate(
    [("x", "1"), ("y", "2"), ("x", "3")], "x") == [("y", "2")]
	assert candidate(
    [
        ('Content-Type', 'text/plain'),
        ('Content-Length', '123'),
        ('ETag', '456'),
    ],
    'Content-Length',
) == [
    ('Content-Type', 'text/plain'),
    ('ETag', '456'),
]
	assert candidate(
    [("a", "b"), ("c", "d"), ("a", "e")], "x") == [("a", "b"), ("c", "d"), ("a", "e")]
	assert candidate(
    [('a', 'b'), ('c', 'd'), ('a', 'e')],
    'x') == [('a', 'b'), ('c', 'd'), ('a', 'e')]
	assert candidate(
    [
        ("Host", "example.com"),
        ("host", "example.org"),
        ("X-Foo", "bar"),
        ("x-foo", "baz"),
    ],
    "host"
) == [
    ("X-Foo", "bar"),
    ("x-foo", "baz"),
]
	assert candidate(
    [('Accept', 'text/plain'), ('Accept', 'text/html')], 'accept-language') == \
    [('Accept', 'text/plain'), ('Accept', 'text/html')]
	assert candidate(
    [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('k', 'l'), ('m', 'n')],
   'm') == [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('k', 'l')]
	assert candidate(
    [
        ('Content-Type', 'text/plain'),
        ('Content-Length', '123'),
        ('ETag', '456'),
    ],
    'ETag',
) == [
    ('Content-Type', 'text/plain'),
    ('Content-Length', '123'),
]
	assert candidate(
    [("a", "b"), ("c", "d"), ("a", "e")],
    "c",
) == [("a", "b"), ("a", "e")]
	assert candidate(
    [("a", "b"), ("c", "d"), ("a", "e")],
    "d",
) == [("a", "b"), ("c", "d"), ("a", "e")]
	assert candidate(
    [("Foo", "bar"), ("foo", "baz"), ("quux", "spam")], "bar") == \
    [("Foo", "bar"), ("foo", "baz"), ("quux", "spam")]
	assert candidate(
    [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('k', 'l'), ('m', 'n')],
    'e') == [('a', 'b'), ('c', 'd'), ('g', 'h'), ('i', 'j'), ('k', 'l'), ('m', 'n')]
	assert candidate(
    [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('k', 'l'), ('m', 'n')],
    'x') == [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('k', 'l'), ('m', 'n')]
	assert candidate(
    [("content-length", "1234"), ("content-type", "text/plain")],
    "content-length") == [("content-type", "text/plain")]
	assert candidate(
    [("Content-Length", "100"), ("content-type", "text/plain")],
    "Content-Length") == [("content-type", "text/plain")]
	assert candidate(
    [
        (b'Content-Type', b'text/html'),
        (b'Content-Length', b'0'),
        (b'Set-Cookie', b'foo=bar'),
        (b'Set-Cookie', b'baz=qux'),
        (b'Server', b'Apache'),
        (b'Content-Type', b'application/xml'),
    ], b'Content-Type'
) == [
    (b'Content-Length', b'0'),
    (b'Set-Cookie', b'foo=bar'),
    (b'Set-Cookie', b'baz=qux'),
    (b'Server', b'Apache'),
]
	assert candidate(
    [("Foo", "bar"), ("foo", "baz"), ("quux", "spam")], "foo") == \
    [("quux", "spam")]
	assert candidate(
    [("content-type", "text/plain")], "content-type") == []
	assert candidate(
    [("Content-Length", "100"), ("content-type", "text/plain")],
    "content-length") == [("content-type", "text/plain")]
	assert candidate(
    [('a', 'b'), ('c', 'd'), ('a', 'e')],
    'a') == [('c', 'd')]
	assert candidate([("X-Foo", "foo")], "Content-Type") == [("X-Foo", "foo")]
def test_check():
	check(remove_headers)
