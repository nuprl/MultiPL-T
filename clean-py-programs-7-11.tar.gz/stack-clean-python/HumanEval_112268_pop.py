def pop(obj, key=0, *args, **kwargs):
    """ Pop an element from a mutable collection.
     
     Parameters
     ----------
     obj : dict or list
     Collection
     key : str or int
     Key or index
     default : optional
     Default value. Raise error if not provided.
     
     Returns
     -------
     elem
     Popped element
     
     """
	### Canonical solution below ###    
    if isinstance(obj, dict):
        return obj.pop(key, *args, **kwargs)
    else:
        try:
            val = obj[key]
            del obj[key]
            return val
        except:
            if len(args) > 0:
                return args[0]
            else:
                return kwargs.get('default')

### Unit tests below ###
def check(candidate):
	assert candidate(list(range(10)), 15, default=16) == 16
	assert candidate(list(range(10)), 100, 1000, default=2000) == 1000
	assert candidate({'a': 1, 'b': 2}, 'c', 3) == 3
	assert candidate(list(range(10)), 5) == 5
	assert candidate(dict(a=1, b=2), 'a', 3) == 1
	assert candidate({'a': 1, 'b': 2}, 'a') == 1
	assert candidate([1, 2, 3], 10, 2) == 2
	assert candidate([1, 2], 10, 0) == 0
	assert candidate(list(range(10)), 15, 16) == 16
	assert candidate([1, 2, 3], 2) == 3
	assert candidate([1, 2, 3], 100, 4) == 4
	assert candidate([1, 2, 3], 100) == None
	assert candidate([1,2,3], 10, 2) == 2
	assert candidate(list(range(10)), 2) == 2
	assert candidate(list(range(5)), 0) == 0
	assert candidate(dict(a=1, b=2), 'a') == 1
	assert candidate(dict(a=1, b=2, c=3), 'a', 42) == 1
	assert candidate([1, 2, 3], 4, default=4) == 4
	assert candidate([1, 2, 3], 100, 'default') == 'default'
	assert candidate([1,2,3], 1) == 2
	assert candidate([1, 2, 3], 4) == None
	assert candidate([1, 2, 3], 0, 'default') == 1
	assert candidate(list(range(5)), 5) == None
	assert candidate(None, 'a', default=0) == 0
	assert candidate([1, 2, 3], 4, 4) == 4
	assert candidate(dict(a=1, b=2), 'b') == 2
	assert candidate(dict(a=1, b=2), 'c', 1000) == 1000
	assert candidate(['a', 'b', 'c'], 3) is None
	assert candidate(dict(a=1, b=2), 'c', 0) == 0
	assert candidate(list(range(3)), 4, 5) == 5
	assert candidate(list(range(3)), 2) == 2
	assert candidate(list(range(10)), 100, 100) == 100
	assert candidate(list(range(10)), 100) is None
	assert candidate(dict(a=1), 'b', 'default') == 'default'
	assert candidate(dict(a=1, b=2), 'c', 10) == 10
	assert candidate(list(range(10)), -100, 100) == 100
	assert candidate(None, 0, 1) == 1
	assert candidate([1, 2, 3], 0, 5) == 1
	assert candidate([1, 2], 0) == 1
	assert candidate(dict(a=1), 'a') == 1
	assert candidate([1, 2], 3) is None
	assert candidate([1, 2, 3], 10, default=2) == 2
	assert candidate(list(range(3)), 10) is None
	assert candidate(list(range(10)), -1, 100) == 9
	assert candidate([1, 2, 3], 1, 3) == 2
	assert candidate([1, 2, 3], 4, default=3) == 3
	assert candidate(list(range(10)), 15) is None
	assert candidate([1, 2, 3], 4, 5) == 5
	assert candidate([1, 2, 3], 0) == 1
	assert candidate([1, 2, 3], 4, 3) == 3
	assert candidate(set([1, 2, 3]), 10, 20) == 20
	assert candidate(dict(a=1, b=2, c=3), 'a', 'default') == 1
	assert candidate(dict(a=1, b=2), 'c', 3) == 3
	assert candidate([1, 2, 3], 100) is None
	assert candidate(dict(a=1), 'b', 2) == 2
	assert candidate([1, 2, 3], 0, 42) == 1
	assert candidate(list(range(3)), 3, 3) == 3
	assert candidate(dict(a=1), 'a', 2) == 1
	assert candidate([0, 1], 0) == 0
	assert candidate(dict(a=1, b=2), 'c', 100) == 100
	assert candidate([1, 2], 3, default=0) == 0
	assert candidate(list('abc'), 3, default='d') == 'd'
	assert candidate({'a': 1}, 'a') == 1
	assert candidate(dict(a=1, b=2, c=3), 'd', 4) == 4
	assert candidate(list(range(5)), 0, 3) == 0
	assert candidate(list(range(10)), 3, 100) == 3
	assert candidate([1, 2, 3], 1) == 2
	assert candidate(dict(a=1, b=2, c=3), 'a') == 1
	assert candidate(dict(a=1, b=2, c=3), 'd', 42) == 42
	assert candidate(['a', 'b', 'c'], 3, 'd') == 'd'
	assert candidate([1, 2, 3], 10, 20) == 20
	assert candidate(list(range(3)), 0) == 0
	assert candidate([0, 1], 2) is None
	assert candidate(list(range(10)), -1) == 9
	assert candidate([1,2,3], 10) is None
	assert candidate(list(range(3)), 3, default=3) == 3
	assert candidate(None) is None
	assert candidate(list(range(10)), 2, default=100) == 2
	assert candidate(None, default=1) == 1
	assert candidate([1, 2, 3], 4, default=5) == 5
	assert candidate(list(range(3)), 10, default=11) == 11
	assert candidate([1, 2], 1) == 2
	assert candidate([1, 2, 3], 4) is None
	assert candidate(None, 0, 'default') == 'default'
	assert candidate(list(range(10)), 3) == 3
	assert candidate(list(range(10)), -100) is None
	assert candidate(list(range(10)), 100, default=100) == 100
	assert candidate(dict(a=1, b=2, c=3), 'd', 'default') == 'default'
	assert candidate(['a', 'b', 'c'], 1) == 'b'
	assert candidate(list('abc'), 1) == 'b'
	assert candidate([1, 2, 3], 0, 2) == 1
	assert candidate(list(range(5)), 5, 3) == 3
	assert candidate([1, 2], 10, default=0) == 0
	assert candidate(list(range(10)), 100, 1000) == 1000
	assert candidate(list('abc'), 3) is None
	assert candidate([1, 2, 3], -1) == 3
	assert candidate([1, 2, 3], 4, 42) == 42
	assert candidate(list(range(10)), 100) == None
	assert candidate([1, 2, 3], 100, default=4) == 4
	assert candidate([1, 2, 3], 0, 4) == 1
	assert candidate(list(range(3)), 10, 11) == 11
	assert candidate(['a', 'b', 'c'], 3, default='d') == 'd'
	assert candidate([1, 2, 3], 1, 4) == 2
def test_check():
	check(pop)
