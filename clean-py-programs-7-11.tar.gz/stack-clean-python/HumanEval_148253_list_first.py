def list_first(rs):
    """ Get the first item in a list, or None if list empty."""
	### Canonical solution below ###    
    return rs[0] if len(rs) == 1 else None

### Unit tests below ###
def check(candidate):
	assert candidate(range(0)) is None
	assert candidate(list([1])) == 1
	assert candidate([]) is None
	assert candidate( [1] ) == 1
	assert candidate(range(1)) == 0
	assert candidate([]) == None
	assert candidate(range(100, 1)) == None
	assert candidate(list()) is None
	assert candidate([None]) is None
	assert candidate([None, None]) is None
	assert candidate([1]) == 1
	assert candidate([0]) == 0
	assert candidate( [] ) == None
	assert candidate(['a']) == 'a'
	assert candidate(list()) == None
def test_check():
	check(list_first)
