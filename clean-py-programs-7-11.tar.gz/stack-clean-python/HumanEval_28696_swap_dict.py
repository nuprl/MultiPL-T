def swap_dict(input_dict):
    """
    Swap keys and values of the provided dictionary so that the returned
    dictionary has the values as keys and the keys as values.

    Args:
        input_dict (dict): Input dictionary

    Returns:
        dict: swapped dictionary
    """
    ### Canonical solution below ###
    return {k: v for v, k in input_dict.items()}


### Unit tests below ###
def check(candidate):
	assert candidate(
    {1: 1, 2: 2, 3: 3}
) == {
    1: 1,
    2: 2,
    3: 3
}
	assert candidate(
    {
        "a": "A",
        "b": "B",
        "c": "C",
    }
) == {"A": "a", "B": "b", "C": "c"}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == {1: 'a', 2: 'b', 3: 'c', 4: 'd'}
	assert candidate(dict(one=1, two=2, three=3, four=4)) == {1: 'one', 2: 'two', 3: 'three', 4: 'four'}
	assert candidate(
    {
        "a": "b",
        "c": "d",
        "e": "f"
    }
) == {
    "b": "a",
    "d": "c",
    "f": "e"
}
	assert candidate(
    {
        "a": 1,
        "b": 2,
        "c": 3,
    }
) == {1: "a", 2: "b", 3: "c"}
	assert candidate({'a': 1, 'b': 2}) == {1: 'a', 2: 'b'}
	assert candidate(dict(a=1)) == {1: 'a'}
	assert candidate(
    {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
    }
) == {1: "a", 2: "b", 3: "c", 4: "d"}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}
) == {
    1: 'a',
    2: 'b',
    3: 'c',
}
	assert candidate({1: 'a', 2: 'b', 3: 'c'}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(
    {
        "a": "b",
        "c": "d",
        "e": "f",
        "g": "h"
    }
) == {
    "b": "a",
    "d": "c",
    "f": "e",
    "h": "g"
}
	assert candidate(
    {"a": 1, "b": 2, "c": 3, "d": 4}
) == {
    1: "a",
    2: "b",
    3: "c",
    4: "d",
}
	assert candidate(
    {1: 1, 2: 1, 3: 1}
) == {
    1: 3
}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
) == {
    1: 'a',
    2: 'b',
    3: 'c',
    4: 'd',
    5: 'e',
}
	assert candidate({'a': 1}) == {1: 'a'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}) == {1: 'a', 2: 'b', 3: 'c'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}
) == {
    1: 'a',
    2: 'b',
    3: 'c'
}
	assert candidate(dict(a=1, b=2)) == {1: 'a', 2: 'b'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
) == {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'}
	assert candidate(dict(a=1, b=2, c=3, d=4)) == {1: 'a', 2: 'b', 3: 'c', 4: 'd'}
	assert candidate(
    {1: "a", 2: "b", 3: "c", 4: "d"}
) == {
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4}
) == {
    1: 'a',
    2: 'b',
    3: 'c',
    4: 'd'
}
	assert candidate(
    {}
) == {}
	assert candidate(
    {1: 'a', 2: 'b', 3: 'c', 4: 'd'}
) == {
    'a': 1,
    'b': 2,
    'c': 3,
    'd': 4
}
	assert candidate(
    {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h', 'i': 'j'}
) == {'b': 'a', 'd': 'c', 'f': 'e', 'h': 'g', 'j': 'i'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}
) == {1: 'a', 2: 'b', 3: 'c'}
	assert candidate(dict()) == dict()
	assert candidate(dict()) == {}
	assert candidate(dict(a=1, b=2, c=3)) == {1: 'a', 2: 'b', 3: 'c'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}) == {1: 'a', 2: 'b', 3: 'c'},'candidate'
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8)) == {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f', 7: 'g', 8: 'h'}
	assert candidate(dict(zip(range(10), range(10)))) == {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f'}
	assert candidate(dict(one=1, two=2, three=3)) == {1: 'one', 2: 'two', 3: 'three'}
	assert candidate({1: 'a', 2: 'b', 3: 'c'}) == dict(a=1, b=2, c=3)
	assert candidate({'a': 1, 'b': 2, 'c': 3}) == {1: 'a', 2: 'b', 3: 'c'}
	assert candidate(
    {'a': 1, 'b': 1, 'c': 1}
) == {
    1: 'c'
}
	assert candidate(
    {'a': 'b'}
) == {'b': 'a'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'}
	assert candidate({}) == {}
	assert candidate(
    {1: 'a', 2: 'b', 3: 'c'}
) == {
    'a': 1,
    'b': 2,
    'c': 3
}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'}
	assert candidate(
    {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}
) == {'b': 'a', 'd': 'c', 'f': 'e', 'h': 'g'}
	assert candidate(
    {"a": 1, "b": 2, "c": 3}
) == {1: "a", 2: "b", 3: "c"}
def test_check():
	check(swap_dict)
