def _as_list(x):
    """ Converts an object to a list."""
	### Canonical solution below ###    

    if x is None:
        return []
    elif isinstance(x, (list, tuple, set)):
        return list(x)
    else:
        return [x]

### Unit tests below ###
def check(candidate):
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(set([1, 2, 3])) == [1, 2, 3]
	assert candidate((1, 2)) == [1, 2]
	assert candidate({"foo"}) == ["foo"]
	assert candidate(("foo", "bar")) == ["foo", "bar"]
	assert candidate({1, 2}) == [1, 2]
	assert candidate({1}) == [1]
	assert candidate(["foo", "bar"]) == ["foo", "bar"]
	assert candidate(("foo",)) == ["foo"]
	assert candidate("hello") == ["hello"]
	assert candidate({1, 2, 3}) == [1, 2, 3]
	assert candidate((1, 2, 3)) == [1, 2, 3]
	assert candidate(None) == []
	assert candidate("foo") == ["foo"]
	assert candidate([1]) == [1]
	assert candidate([1, 2]) == [1, 2]
	assert candidate((1,)) == [1]
	assert candidate(["foo"]) == ["foo"]
	assert candidate(()) == []
	assert candidate(set(range(10))) == list(range(10))
	assert candidate(set()) == []
	assert candidate([]) == []
	assert candidate(1) == [1]
def test_check():
	check(_as_list)
