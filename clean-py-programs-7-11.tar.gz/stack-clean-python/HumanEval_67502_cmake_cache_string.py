def cmake_cache_string(name, string, comment=""):
    """ Generate a string for a cmake cache variable"""
	### Canonical solution below ###    

    return 'set(%s "%s" CACHE STRING "%s")\n\n' % (name, string, comment)

### Unit tests below ###
def check(candidate):
	assert candidate(
    "FOO", "BAR", "A simple test") =='set(FOO "BAR" CACHE STRING "A simple test")\n\n'
	assert candidate(
    "name",
    "string",
    comment="comment"
) =='set(name "string" CACHE STRING "comment")\n\n'
	assert candidate(
    'foo', 'bar') =='set(foo "bar" CACHE STRING "")\n\n'
	assert candidate(
    "FOO",
    "bar",
    "This is a test") =='set(FOO "bar" CACHE STRING "This is a test")\n\n'
	assert candidate(
    "TEST_VAR", "TEST_STRING", "TEST_COMMENT") == \
   'set(TEST_VAR "TEST_STRING" CACHE STRING "TEST_COMMENT")\n\n'
	assert candidate(
    "foo", "bar", "This is a comment") == \
'set(foo "bar" CACHE STRING "This is a comment")\n\n'
	assert candidate(
    "TEST_VAR", "test string", "test comment") =='set(TEST_VAR "test string" CACHE STRING "test comment")\n\n'
	assert candidate(
    "my_string", "a string with spaces", "this is a comment") == \
"""set(my_string "a string with spaces" CACHE STRING "this is a comment")

"""
	assert candidate(
    "test", "foo bar", "bar") =='set(test "foo bar" CACHE STRING "bar")\n\n'
	assert candidate(
    "FOO", "BAR", "this is a comment") =='set(FOO "BAR" CACHE STRING "this is a comment")\n\n'
	assert candidate(
    "FOO", "bar", "Some comment") == \
   'set(FOO "bar" CACHE STRING "Some comment")\n\n'
	assert candidate(
    "TEST_VAR", "This is a test string.", "This is a test comment.") == \
   'set(TEST_VAR "This is a test string." CACHE STRING "This is a test comment.")\n\n'
	assert candidate(name="test", string="hello", comment="hello") =='set(test "hello" CACHE STRING "hello")\n\n'
	assert candidate(
    "SOME_VARIABLE", "SOME_VALUE", "SOME_COMMENT") =='set(SOME_VARIABLE "SOME_VALUE" CACHE STRING "SOME_COMMENT")\n\n'
	assert candidate(name="FOO", string="bar", comment="baz") == \
   'set(FOO "bar" CACHE STRING "baz")\n\n'
	assert candidate(name="var", string="test") == "set(var \"test\" CACHE STRING \"\")\n\n"
	assert candidate(
    'name',
   'string',
    'comment'
) =='set(name "string" CACHE STRING "comment")\n\n'
	assert candidate(
    "test",
    "Hello World",
    "This is a test") =='set(test "Hello World" CACHE STRING "This is a test")\n\n'
	assert candidate(
    "var", "value", "comment") =='set(var "value" CACHE STRING "comment")\n\n'
	assert candidate(
    "var",
    "string",
    comment="comment",
) =='set(var "string" CACHE STRING "comment")\n\n'
	assert candidate(
    "foo", "bar", "baz") =='set(foo "bar" CACHE STRING "baz")\n\n'
	assert candidate(
    "test", "foo\nbar", "bar") =='set(test "foo\nbar" CACHE STRING "bar")\n\n'
	assert candidate(
    "test", "foo", "bar") =='set(test "foo" CACHE STRING "bar")\n\n'
	assert candidate(
    "FOO",
    "bar",
    "A string") =='set(FOO "bar" CACHE STRING "A string")\n\n'
	assert candidate(
    "TEST_NAME", "TEST_VALUE", "TEST_COMMENT") == \
   'set(TEST_NAME "TEST_VALUE" CACHE STRING "TEST_COMMENT")\n\n'
	assert candidate(name="var", string="test", comment="test") == "set(var \"test\" CACHE STRING \"test\")\n\n"
	assert candidate(
    "test", "hello world", "A test string") =='set(test "hello world" CACHE STRING "A test string")\n\n'
	assert candidate(
    "FOO", "BAR") =='set(FOO "BAR" CACHE STRING "")\n\n'
	assert candidate(
    "test",
    "Hello World",
    "") =='set(test "Hello World" CACHE STRING "")\n\n'
	assert candidate(
    "FOO", "bar", "This is a comment") =='set(FOO "bar" CACHE STRING "This is a comment")\n\n'
	assert candidate(
    "test",
    "string with spaces",
    "This is a comment") == \
'set(test "string with spaces" CACHE STRING "This is a comment")\n\n'
	assert candidate(
    'foo', 'bar', comment='hello') =='set(foo "bar" CACHE STRING "hello")\n\n'
	assert candidate(
    "CMAKE_CXX_COMPILER",
    "/usr/local/bin/clang++",
    "C++ compiler used by CMake."
) =='set(CMAKE_CXX_COMPILER "/usr/local/bin/clang++" CACHE STRING "C++ compiler used by CMake.")\n\n'
	assert candidate(name="var", string="test", comment="test test test") == "set(var \"test\" CACHE STRING \"test test test\")\n\n"
	assert candidate(
    "foo", "bar", "comment") =='set(foo "bar" CACHE STRING "comment")\n\n'
	assert candidate(
    "TEST_VAR", "This is a test string", "This is a test comment") == \
   'set(TEST_VAR "This is a test string" CACHE STRING "This is a test comment")\n\n'
def test_check():
	check(cmake_cache_string)
