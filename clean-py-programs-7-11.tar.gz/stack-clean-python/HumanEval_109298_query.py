def query():
    """Simple empty query"""
    ### Canonical solution below ###
    return {'rawQuery': 'empty',
            'logicalRa': 'empty',
            'fragments': []}


### Unit tests below ###
def check(candidate):
	assert candidate( ) == {'rawQuery': 'empty',
                    'logicalRa': 'empty',
                    'fragments': []}
	assert candidate() == {'rawQuery': 'empty',
                       'logicalRa': 'empty',
                       'fragments': []}
	assert candidate() == {'rawQuery': 'empty', 'logicalRa': 'empty', 'fragments': []}
	assert candidate(
    ) == {'rawQuery': 'empty',
           'logicalRa': 'empty',
           'fragments': []}
	assert candidate(
) == {'rawQuery': 'empty',
      'logicalRa': 'empty',
      'fragments': []}
	assert candidate( ) == {'rawQuery': 'empty', 'logicalRa': 'empty', 'fragments': []}
	assert candidate(
) == {
    'rawQuery': 'empty',
    'logicalRa': 'empty',
    'fragments': []
}
def test_check():
	check(query)
