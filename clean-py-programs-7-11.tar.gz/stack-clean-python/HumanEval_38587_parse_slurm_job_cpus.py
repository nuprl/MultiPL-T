def parse_slurm_job_cpus(cpus):
    """Return number of cores allocated on each node in the allocation.

    This method parses value of Slurm's SLURM_JOB_CPUS_PER_NODE variable's value.

    Args:
        cpus (str): the value of SLURM_JOB_CPUS_PER_NODE

    Returns:
        list (int): the number of cores on each node
    """
    ### Canonical solution below ###
    result = []

    for part in cpus.split(','):
        if part.find('(') != -1:
            cores, times = part.rstrip(')').replace('(x', 'x').split('x')
            for _ in range(0, int(times)):
                result.append(int(cores))
        else:
            result.append(int(part))

    return result


### Unit tests below ###
def check(candidate):
	assert candidate('24(x3)') == [24, 24, 24]
	assert candidate('16') == [16]
	assert candidate('24(x1)') == [24]
	assert candidate('1(x2),2(x2)') == [1, 1, 2, 2]
	assert candidate('24(x4)') == [24, 24, 24, 24]
	assert candidate('1,2(x2),3,4(x2)') == [1, 2, 2, 3, 4, 4]
	assert candidate(
    '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32') == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
	assert candidate('2,4(x2)') == [2, 4, 4]
	assert candidate('123') == [123]
	assert candidate('1(x2),2(x1)') == [1, 1, 2]
	assert candidate('1(x3),2(x3)') == [1, 1, 1, 2, 2, 2]
	assert candidate('1,2,3(x2)') == [1, 2, 3, 3]
	assert candidate('2') == [2]
	assert candidate('24(x1),20(x3)') == [24, 20, 20, 20]
	assert candidate('1,2(x2)') == [1, 2, 2]
	assert candidate('123,456') == [123, 456]
	assert candidate('1(x2),2(x3)') == [1, 1, 2, 2, 2]
	assert candidate('1(x2)') == [1, 1]
	assert candidate('1(x1)') == [1]
	assert candidate('24(x1),20(x4)') == [24, 20, 20, 20, 20]
	assert candidate('123,456(x2)') == [123, 456, 456]
	assert candidate('24(x1),20(x2)') == [24, 20, 20]
	assert candidate('1(x2),3') == [1, 1, 3]
	assert candidate('2,1') == [2, 1]
	assert candidate('24(x2),20(x2)') == [24, 24, 20, 20]
	assert candidate('1,2,4') == [1, 2, 4]
	assert candidate('1(x2),2') == [1, 1, 2]
	assert candidate('24(x3),20(x3)') == [24, 24, 24, 20, 20, 20]
	assert candidate('1,2(x1)') == [1, 2]
	assert candidate('123,456(x2),789(x3)') == [123, 456, 456, 789, 789, 789]
	assert candidate('1(x3),2(x2)') == [1, 1, 1, 2, 2]
	assert candidate(
    '12(x2),36(x2),72(x2),144(x2),288(x2),576(x2),1152(x2)') == [
        12, 12, 36, 36, 72, 72, 144, 144, 288, 288, 576, 576, 1152, 1152
    ]
	assert candidate('1') == [1]
	assert candidate('2(x2)') == [2, 2]
	assert candidate('1,2') == [1, 2]
	assert candidate('24(x4),20(x4)') == [24, 24, 24, 24, 20, 20, 20, 20]
	assert candidate('24') == [24]
	assert candidate('24(x2)') == [24, 24]
	assert candidate('1,2,3') == [1, 2, 3]
	assert candidate('2,4') == [2, 4]
	assert candidate('1(x2),3(x4)') == [1, 1, 3, 3, 3, 3]
	assert candidate('2,4,8,16') == [2, 4, 8, 16]
def test_check():
	check(parse_slurm_job_cpus)
