def merge_reduce(function, data, chunk=48):
    """ Apply function cumulatively to the items of data,
        from left to right in binary tree structure, so as to
        reduce the data to a single value.
    :param function: function to apply to reduce data
    :param data: List of items to be reduced
    :param chunk: Number of elements per reduction
    :return: result of reduce the data to a single value
    """
    ### Canonical solution below ###
    while(len(data)) > 1:
        dataToReduce = data[:chunk]
        data = data[chunk:]
        data.append(function(*dataToReduce))
    return data[0]


### Unit tests below ###
def check(candidate):
	assert candidate(lambda x, y: x*y, [1, 2]) == 2
	assert candidate(max, [1]) == 1
	assert candidate(lambda x, y: x*y, [1]) == 1
	assert candidate(min, [1]) == 1
	assert candidate(lambda x, y: x+y, [1]) == 1
	assert candidate(lambda x, y: x + y, [1, 2, 3, 4, 5], 2) == 15
	assert candidate(min, [1, 2, 3, 4, 5]) == 1
	assert candidate(max, [1, 2, 3, 4, 5]) == 5
	assert candidate(lambda x, y: x+y, [1, 2]) == 3
	assert candidate(lambda x, y: x * y, [1]) == 1
	assert candidate(lambda x, y: x + y, [1]) == 1
	assert candidate(lambda x, y: x + y, [1, 2, 3, 4, 5, 6, 7], chunk=2) == 28
def test_check():
	check(merge_reduce)
