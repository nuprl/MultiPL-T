def extended_gcd(a, b):
    """ 
     I don't claim any copyright on this. I copied it from the internet somewhere.
     
     Extended Greatest Common Divisor Algorithm.
     
     Returns:
     gcd: The greatest common divisor of a and b.
     s, t: Coefficients such that s*a + t*b = gcd
     
     Reference:
     https://en.wikipedia.org/wiki/Extended_Euclidean_algorithmPseudocode
     """
	### Canonical solution below ###    
    old_r, r = a, b
    old_s, s = 1, 0
    old_t, t = 0, 1
    while r:
        quotient, remainder = divmod(old_r, r)
        old_r, r = r, remainder
        old_s, s = s, old_s - quotient * s
        old_t, t = t, old_t - quotient * t

    return old_r, old_s, old_t

### Unit tests below ###
def check(candidate):
	assert candidate(6, 8) == (2, -1, 1)
	assert candidate(98, 100) == (2, -1, 1)
	assert candidate(15, 15) == (15, 0, 1)
	assert candidate(100, 300) == (100, 1, 0)
	assert candidate(12, 8) == (4, 1, -1)
	assert candidate(4, 6) == (2, -1, 1)
	assert candidate(3, 7) == (1, -2, 1)
	assert candidate(10, 10) == (10, 0, 1)
	assert candidate(100, 200) == (100, 1, 0)
	assert candidate(2, 1) == (1, 0, 1)
	assert candidate(10, 0) == (10, 1, 0)
	assert candidate(1, 1) == (1, 0, 1)
	assert candidate(0, 10) == (10, 0, 1)
	assert candidate(2, 4) == (2, 1, 0)
	assert candidate(4, 2) == (2, 0, 1)
	assert candidate(100, 400) == (100, 1, 0)
	assert candidate(3, 5) == (1, 2, -1)
	assert candidate(5, 1) == (1, 0, 1)
	assert candidate(1, 0) == (1, 1, 0)
	assert candidate(6, 15) == (3, -2, 1)
def test_check():
	check(extended_gcd)
