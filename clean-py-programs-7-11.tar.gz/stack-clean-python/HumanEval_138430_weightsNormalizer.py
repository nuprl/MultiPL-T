def weightsNormalizer(destinations):
    """ Normalizes each vertex's out-going weight sum to one."""
	### Canonical solution below ###    

    destinations = list(destinations)
    newDestinations = []
    sum = 0

    for destination, weight in destinations:
        sum += weight

    for destination, weight in destinations:
        newDestinations.append((destination, weight / sum))

    return newDestinations

### Unit tests below ###
def check(candidate):
	assert candidate(
    []
) == []
	assert candidate(iter([(0, 1), (1, 1)])) == [(0, 0.5), (1, 0.5)]
	assert candidate(set()) == []
	assert candidate(iter([(0, 1), (1, 1), (2, 1)])) == [(0, 1/3), (1, 1/3), (2, 1/3)]
	assert candidate(
    [("A", 1), ("B", 1), ("C", 1), ("D", 1)]
) == [("A", 0.25), ("B", 0.25), ("C", 0.25), ("D", 0.25)]
	assert candidate(iter([('A', 1), ('B', 2), ('C', 3)])) == [('A', 0.16666666666666666), ('B', 0.3333333333333333), ('C', 0.5)]
	assert candidate(
    [(0, 1), (1, 2), (2, 3)]
) == [(0, 1/6), (1, 2/6), (2, 3/6)]
	assert candidate(iter([('A', 3), ('B', 1)])) == [('A', 0.75), ('B', 0.25)]
	assert candidate( [("A", 1)] ) == [("A", 1)]
	assert candidate(
    [(0, 1), (1, 1), (2, 1)]
) == [(0, 1/3), (1, 1/3), (2, 1/3)]
	assert candidate(
    [("a", 5), ("b", 3), ("c", 2)]
) == [("a", 0.5), ("b", 0.3), ("c", 0.2)]
	assert candidate(
    [("A", 2), ("B", 2), ("C", 2), ("D", 2)]
) == [("A", 0.25), ("B", 0.25), ("C", 0.25), ("D", 0.25)]
	assert candidate(
    [(0, 2), (1, 2), (2, 2)]
) == [(0, 1/3), (1, 1/3), (2, 1/3)]
	assert candidate({(1, 1), (2, 1)}) == [(1,.5), (2,.5)]
	assert candidate(
    [("a", 2), ("b", 2), ("c", 6)]
) == [("a", 0.2), ("b", 0.2), ("c", 0.6)]
	assert candidate(
    [("A", 1), ("B", 1)]) == [("A", 0.5), ("B", 0.5)]
	assert candidate(
    [(0, 2), (1, 2), (2, 2), (3, 2), (4, 2)]
) == [(0, 1/5), (1, 1/5), (2, 1/5), (3, 1/5), (4, 1/5)]
	assert candidate(iter([('A', 2), ('B', 2), ('C', 2)])) == [('A', 1/3), ('B', 1/3), ('C', 1/3)]
	assert candidate(
    [(0, 10), (1, 10), (2, 10), (3, 10)]) == [(0, 0.25), (1, 0.25), (2, 0.25), (3, 0.25)]
	assert candidate(
    [("a", 1), ("b", 1), ("c", 1), ("d", 1)]) == [("a", 0.25), ("b", 0.25), ("c", 0.25), ("d", 0.25)]
	assert candidate(
    [(0, 1), (1, 1), (2, 1)]
) == [(0, 0.3333333333333333), (1, 0.3333333333333333), (2, 0.3333333333333333)]
	assert candidate(
    [(0, 2), (1, 2), (2, 2), (3, 2)]
) == [(0, 1/4), (1, 1/4), (2, 1/4), (3, 1/4)]
	assert candidate(
    [(1, 3)]
) == [(1, 1.0)]
	assert candidate(
    [("a", 5), ("b", 3), ("c", 2)]) == [("a", 0.5), ("b", 0.3), ("c", 0.2)]
	assert candidate({(1, 1)}) == [(1, 1)]
def test_check():
	check(weightsNormalizer)
