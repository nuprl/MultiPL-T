def get_dimension_array(array):
    """ 
     Get dimension of an array getting the number of rows and the max num of
     columns.
     """
	### Canonical solution below ###    
    if all(isinstance(el, list) for el in array):
        result = [len(array), len(max([x for x in array], key=len,))]

    # elif array and isinstance(array, list):
    else:
        result = [len(array), 1]

    return result

### Unit tests below ###
def check(candidate):
	assert candidate(
    [1, 2, 3, 4, 5, 6]
) == [6, 1]
	assert candidate(
    [[1], [2], [3]]) == [3, 1]
	assert candidate([[1, 2, 3], [4, 5, 6]]) == [2, 3]
	assert candidate(
    [[1, 2, 3, 4]]) == [1, 4]
	assert candidate(
    [[1], [2], [3], [4], [5]]
) == [5, 1]
	assert candidate(array=[1, 2, 3, 4, 5, 6]) == [6, 1]
	assert candidate(array=[[]]) == [1, 0]
	assert candidate(array=[[1], [6]]) == [2, 1]
	assert candidate([[[1], [2]], [[3]]]) == [2, 2]
	assert candidate([[1], [2, 3]]) == [2, 2]
	assert candidate(array=[[1, 2, 3, 4, 5]]) == [1, 5]
	assert candidate([[[1, 2], [3, 4]], [[5, 6], [7, 8]]]) == [2, 2]
	assert candidate(array=[1, 2, 3]) == [3, 1]
	assert candidate(array=[1, 2, 3, 4, 5]) == [5, 1]
	assert candidate(
    [[1, 2], [3, 4]]) == [2, 2]
	assert candidate(array=[[[1], [2]], [[3], [4], [5]]]) == [2, 3]
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9]
) == [9, 1]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8]) == [8, 1]
	assert candidate(
    [[1, 2], []]
) == [2, 2]
	assert candidate(
    [[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]]) == [4, 4]
	assert candidate(
    [
        [1, 2, 3, 4, 5, 6],
        [7, 8, 9, 10, 11, 12],
        [13, 14, 15, 16, 17, 18],
        [19, 20, 21, 22, 23, 24],
    ]
) == [4, 6]
	assert candidate([[1, 2], [3, 4], [5, 6]]) == [3, 2]
	assert candidate([1, 2, 3, 4, 5, 6]) == [6, 1]
	assert candidate(
    [
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
    ]
) == [13, 3]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12, 13]]) == [4, 4]
	assert candidate([[1]]) == [1, 1]
	assert candidate(
    [
        [1, 2, 3],
        [4, 5, 6],
    ]
) == [2, 3]
	assert candidate([[1, 2, 3], [1, 2, 3]]) == [2, 3]
	assert candidate([["a", "b", "c"], ["d", "e", "f"], ["g", "h", "i"]]) == [3, 3]
	assert candidate(array=[[1, 2, 3], [4, 5, 6]]) == [2, 3]
	assert candidate([[1], [2], [3], [4]]) == [4, 1]
	assert candidate(
    [[1, 2, 3, 4, 5]]) == [1, 5]
	assert candidate([[1, 2], [3, 4, 5], [6]]) == [3, 3]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [15, 1]
	assert candidate(array=[[1], [2], [3], [4], [5], [6], [7], [8], [9]]) == [9, 1]
	assert candidate(
    [1, 2, 3, 4]) == [4, 1]
	assert candidate(
    [[1, 2, 3], [1, 2, 3], [1, 2, 3], [1, 2, 3], [1, 2, 3]]) == [5, 3]
	assert candidate(array=[[], []]) == [2, 0]
	assert candidate([["a"], ["b"], ["c"]]) == [3, 1]
	assert candidate(
    [['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c']]) == [3, 3]
	assert candidate(
    [[1, 2, 3, 4, 5], [6, 7, 8, 9, 10], [11, 12, 13, 14, 15]]) == [3, 5]
	assert candidate([1, 2]) == [2, 1]
	assert candidate(array=[[1, 2, 3]]) == [1, 3]
	assert candidate(array=[[1, 2], [3, 4], [5, 6]]) == [3, 2]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [9, 1]
	assert candidate(array=[[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [3, 3]
	assert candidate([[1, 2, 3, 4]]) == [1, 4]
	assert candidate(
    [[], []]
) == [2, 0]
	assert candidate([[1, 2, 3], [1, 2, 3], [1, 2, 3]]) == [3, 3]
	assert candidate(
    [[1, 2, 3], [4, 5, 6]]) == [2, 3]
	assert candidate([["a", "b", "c"], ["d", "e", "f"]]) == [2, 3]
	assert candidate([[1, 2, 3]]) == [1, 3]
	assert candidate(array=[[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]]) == [3, 4]
	assert candidate([[1, 2], [3, 4, 5]]) == [2, 3]
	assert candidate([1, 2, 3, 4]) == [4, 1]
	assert candidate(
    [[1, 2, 3, 4, 5, 6]]) == [1, 6]
	assert candidate(
    [[]]
) == [1, 0]
	assert candidate([["a", "b", "c"]]) == [1, 3]
	assert candidate(
    [[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]]) == [2, 2]
	assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [3, 3]
	assert candidate([[1], [2], [3]]) == [3, 1]
	assert candidate([1]) == [1, 1]
	assert candidate([[[1]]]) == [1, 1]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]) == [13, 1]
	assert candidate(
    [
        [1, 2, 3],
        [4, 5, 6]
    ]
) == [2, 3]
	assert candidate([[[1, 2, 3], [4, 5, 6], [7, 8, 9]],
                            [[10, 11, 12], [13, 14, 15], [16, 17, 18]]]) == [2, 3]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]]) == [4, 3]
	assert candidate(
    [
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
    ]
) == [6, 3]
	assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]]) == [4, 3]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8]]) == [3, 3]
	assert candidate(array=[1, 2, 3, 4, 5, 6, 7]) == [7, 1]
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8]
) == [8, 1]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [3, 3]
	assert candidate([['a', 'b', 'c']]) == [1, 3]
	assert candidate(array=[[1, 2], [3, 4]]) == [2, 2]
	assert candidate(
    [[], [1, 2]]
) == [2, 2]
	assert candidate(array=[[[1], [2]], [[3], [4]], [[5], [6]]]) == [3, 2]
	assert candidate(array=[1, 2, 3, 4, 5, 6, 7, 8]) == [8, 1]
	assert candidate(['a', 'b', 'c']) == [3, 1]
	assert candidate([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]) == [2, 5]
	assert candidate(array=[[[1], [2]], [[3], [4]]]) == [2, 2]
	assert candidate(
    [
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
    ]
) == [10, 3]
	assert candidate(
    [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
    ]
) == [3, 3]
	assert candidate(array=[[[1], [2]], [[3], [4]], [[5], [6]], [[7], [8]]]) == [4, 2]
	assert candidate([1, 2, 3]) == [3, 1]
	assert candidate(
    [[1, 2], [3, 4], [5, 6], [7, 8]]) == [4, 2]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]]) == [5, 3]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [10, 1]
	assert candidate([1, 2, 3, 4, 5]) == [5, 1]
	assert candidate([1, 2, 3, 4, 5, 6, 7]) == [7, 1]
	assert candidate(
    [
        [1, 2, 3],
        [1, 2, 3],
        [1, 2, 3],
    ]
) == [3, 3]
	assert candidate(
    [["a", "b", "c"], ["d", "e", "f"], ["g", "h", "i"]]) == [3, 3]
	assert candidate(
    [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
        [10, 11, 12],
    ]
) == [4, 3]
	assert candidate(array=[[[1], [2], [3]], [[4], [5], [6]]]) == [2, 3]
	assert candidate([["a"], ["b"]]) == [2, 1]
	assert candidate(array=[[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]) == [2, 5]
	assert candidate(array=[1, 2, 3, 4, 5, 6, 7, 8, 9]) == [9, 1]
	assert candidate(array=[[1, 2, 3], [4, 5, 6, 7]]) == [2, 4]
	assert candidate(array=[[], [], []]) == [3, 0]
def test_check():
	check(get_dimension_array)
