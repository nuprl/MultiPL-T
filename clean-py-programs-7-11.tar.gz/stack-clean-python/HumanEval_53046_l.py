def l(s):
    """ Split a byte string to ord's of chars."""
	### Canonical solution below ###    
    return [[x][0] for x in s]

### Unit tests below ###
def check(candidate):
	assert candidate(b"")==[]
	assert candidate(b"\x00\x01\x02\x03\x04") == [0, 1, 2, 3, 4]
	assert candidate(b"ab")==[97,98]
	assert candidate(b'hecandidatecandidateo') == [104, 101, 108, 108, 111]
	assert candidate(b'') == []
	assert candidate(b'\x00\x01') == [0, 1]
	assert candidate(b'bar') == [98, 97, 114]
	assert candidate(b"") == []
	assert candidate(b"abc") == [97, 98, 99]
	assert candidate(b'a') == [97]
	assert candidate(b"a") == [97]
	assert candidate(b'foo') == [102, 111, 111]
	assert candidate(b"ab") == [97, 98]
	assert candidate(b'\x00') == [0]
	assert candidate(b'abc') == [97, 98, 99]
	assert candidate(b'123') == [49, 50, 51]
	assert candidate(b'\x01\x02') == [1, 2]
	assert candidate(b"\x00\x01\x02") == [0, 1, 2]
	assert candidate(b"This is a string") == [84, 104, 105, 115, 32, 105, 115, 32, 97, 32, 115, 116, 114, 105, 110, 103]
	assert candidate(b'a\xff') == [97, 255]
	assert candidate(b'abc123') == [97, 98, 99, 49, 50, 51]
	assert candidate(b'ab') == [97, 98]
	assert candidate(b'ABC') == [65, 66, 67]
	assert candidate(b'\x01') == [1]
def test_check():
	check(l)
