def lempel_ziv_complexity(binary_sequence):
    """ Lempel-Ziv complexity for a binary sequence, in simple Python code."""
	### Canonical solution below ###    
    u, v, w = 0, 1, 1
    v_max = 1
    length = len(binary_sequence)
    complexity = 1
    while True:
        if binary_sequence[u + v - 1] == binary_sequence[w + v - 1]:
            v += 1
            if w + v >= length:
                complexity += 1
                break
        else:
            if v > v_max:
                v_max = v
            u += 1
            if u == w:
                complexity += 1
                w += v_max
                if w > length:
                    break
                else:
                    u = 0
                    v = 1
                    v_max = 1
            else:
                v = 1
    return complexity

### Unit tests below ###
def check(candidate):
	assert candidate(bin(18)) == 5
	assert candidate(b"1010") == 3
	assert candidate(bin(20)) == 5
	assert candidate(bin(21)) == 5
	assert candidate(b"10101") == 3
	assert candidate(b'101100011100') == 6
	assert candidate(bin(14)) == 4
	assert candidate([0, 1] * 10) == 3
	assert candidate(bin(16)) == 5
	assert candidate(bin(19)) == 5
	assert candidate(bin(17)) == 5
	assert candidate(bin(15)) == 4
def test_check():
	check(lempel_ziv_complexity)
