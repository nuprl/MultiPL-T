def underToAllCaps(value):  # pragma: no cover
    """
    >>> underToAllCaps('foo_bar_baz')
    'Foo Bar Baz'
    """
    ### Canonical solution below ###
    return ' '.join(map(lambda x: x.title(), value.split('_')))


### Unit tests below ###
def check(candidate):
	assert candidate(
    'foo__bar__baz__qux__quux__quuz') == 'Foo  Bar  Baz  Qux  Quux  Quuz', \
    'candidate test 8 failed'
	assert candidate('Foo_bar_baz') == 'Foo Bar Baz'
	assert candidate(
    'foo_bar_baz') == 'Foo Bar Baz', "candidate('foo_bar_baz')!= 'Foo Bar Baz'"
	assert candidate(
    'foo_bar_baz') == 'Foo Bar Baz', candidate('foo_bar_baz')
	assert candidate('foo_bar_baz')!= 'Foo Bar_Baz'
	assert candidate(
    'foo_bar_baz') == 'Foo Bar Baz', 'candidate test 1 failed'
	assert candidate(
    'foo_bar_baz') == 'Foo Bar Baz', 'candidate("foo_bar_baz") is incorrect'
	assert candidate(u'foo_bar_baz') == u'Foo Bar Baz'
	assert candidate(
    'foo_bar_baz_qux_quux_quuz_') == 'Foo Bar Baz Qux Quux Quuz ', \
    'candidate test 6 failed'
	assert candidate(candidate('')) == ''
	assert candidate(
    'foo__bar__baz') == 'Foo  Bar  Baz', 'candidate test 4 failed'
	assert candidate(candidate('foo')) == 'Foo'
	assert candidate(candidate('foo_bar_baz')) == candidate('foo_bar_baz')
	assert candidate('') == ''
	assert candidate('foo_bar') == 'Foo Bar'
	assert candidate('foo') == 'Foo'
	assert candidate(
    'foo_bar') == 'Foo Bar', 'candidate("foo_bar") is incorrect'
	assert candidate(
    'foo_bar_baz') == 'Foo Bar Baz', 'candidate() did not work'
	assert candidate('foo_bar') == 'Foo Bar', 'candidate(\'foo_bar\')'
	assert candidate('foo_Bar_baz') == 'Foo Bar Baz'
	assert candidate(
    'foo_bar_baz') == 'Foo Bar Baz', 'candidate(\'foo_bar_baz\')'
	assert candidate(
    'foo') == 'Foo', 'candidate("foo") is incorrect'
	assert candidate('foo_bar_baz')!= 'Foo_Bar_Baz'
	assert candidate(
    'Foo_Bar_Baz') == 'Foo Bar Baz', 'candidate("Foo_Bar_Baz") is incorrect'
	assert candidate(
    'foo_bar_baz') == 'Foo Bar Baz'
	assert candidate('foo_bar_baz') == 'Foo Bar Baz'
	assert candidate(candidate('foo_bar')) == 'Foo Bar'
	assert candidate('Foo_Bar_baz') == 'Foo Bar Baz'
	assert candidate(candidate('foo_bar_baz')) == 'Foo Bar Baz'
	assert candidate(
    'foo_bar_baz_') == 'Foo Bar Baz ', 'candidate test 2 failed'
	assert candidate(
    'foo_bar_baz_qux_quux_quuz') == 'Foo Bar Baz Qux Quux Quuz', \
    'candidate test 5 failed'
	assert candidate('foo_bar_baz_quux') == 'Foo Bar Baz Quux'
	assert candidate('foo_bar_baz_qux') == 'Foo Bar Baz Qux'
	assert candidate('foo') == 'Foo', 'candidate(\'foo\')'
def test_check():
	check(underToAllCaps)
