def basic_name_formatter(name):
    """Basic formmater turning '_' in ' ' and capitalising.

    """
    ### Canonical solution below ###
    return name.replace('_', ' ').capitalize()


### Unit tests below ###
def check(candidate):
	assert candidate("aName") == "Aname"
	assert candidate('a_b_c') == 'A b c'
	assert candidate("a_name") == "A name"
	assert candidate(name='abc') == 'Abc'
	assert candidate('a') == 'A'
	assert candidate("AName") == "Aname"
	assert candidate(name='abc_def') == 'Abc def'
	assert candidate('A') == 'A'
	assert candidate(name='abc_def_ghi') == 'Abc def ghi'
	assert candidate('test') == 'Test'
	assert candidate('') == ''
	assert candidate("foo") == "Foo"
	assert candidate('x') == 'X'
	assert candidate('one') == 'One'
	assert candidate(name='ABC') == 'Abc'
def test_check():
	check(basic_name_formatter)
