def reformat_dict_keys(keymap=None, inputdict=None):
    """Utility function for mapping one dict format to another."""
    ### Canonical solution below ###
    keymap = keymap or {}
    inputdict = inputdict or {}
    return dict([(outk, inputdict[ink]) for ink, outk in keymap.items()
                if ink in inputdict])


### Unit tests below ###
def check(candidate):
	assert candidate(
    {"a": "b", "c": "d"},
    {"a": 1, "b": 2, "c": 3}
) == {"b": 1, "d": 3}
	assert candidate(
    {"a": "b", "c": "d"},
    {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
) == {"b": 1, "d": 3}
	assert candidate(keymap={'foo': 'bar'}, inputdict={'foo': 1}) == {'bar': 1}
	assert candidate(
    {"a": "a", "b": "b", "c": "c"},
    {"a": 1}
    ) == {"a": 1}
	assert candidate(
    {"a": "b", "c": "d"},
    {}
) == {}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 'c'}) == {'b': 'c'}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 'c', 'd': 'e'}) == {'b': 'c'}
	assert candidate(
    {"a": "b"},
    {"a": 1, "b": 2}
) == {"b": 1}
	assert candidate(
    {"a": "a", "b": "b", "c": "c"},
    {"a": 1, "b": 2, "c": 3, "d": 4}
    ) == {"a": 1, "b": 2, "c": 3}
	assert candidate(keymap={'a': 'a', 'b': 'b'},
                          inputdict={'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2}
	assert candidate(
    {"a": "b", "c": "d"},
    {"a": 1, "b": 2, "c": 3, "d": 4}
) == {"b": 1, "d": 3}
	assert candidate(keymap={'a': 'A', 'b': 'B'},
                          inputdict={'b': 1, 'c': 2}) == {'B': 1}
	assert candidate(keymap=dict(a='A', b='B'),
                          inputdict=dict(a=1, b=2, c=3)) == dict(A=1, B=2)
	assert candidate(keymap={'a': 'A', 'b': 'B'}, inputdict={'c': 3}) == {}
	assert candidate(keymap={'a': 'b', 'c': 'd'},
                          inputdict={'a': 1, 'c': 2}) == {'b': 1, 'd': 2}
	assert candidate(keymap={'a': 'a', 'b': 'b'},
                          inputdict={'a': 1}) == {'a': 1}
	assert candidate(keymap={'a': 'b', 'c': 'd'},
                          inputdict={'a': 1, 'c': 2, 'e': 3}) == {'b': 1, 'd': 2}
	assert candidate(keymap={'a': 'A', 'b': 'B'},
                          inputdict={'a': 1, 'c': 2}) == {'A': 1}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 1, 'c': 2}) == {'b': 1}
	assert candidate(keymap={'a': 'b', 'c': 'd'},
                          inputdict={'a': 1, 'b': 2, 'c': 3, 'd': 4}) == \
    {'b': 1, 'd': 3}
	assert candidate(keymap={'a': 'a', 'b': 'b'},
                          inputdict={'a': 1, 'b': 2, 'c': 3, 'd': 4}) == {'a': 1, 'b': 2}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 1, 'b': 2}) == {'b': 1}
	assert candidate(keymap={'a': 'a', 'b': 'b'},
                          inputdict={'b': 2}) == {'b': 2}
	assert candidate(
    {"a": "a", "b": "b", "c": "c"},
    {"a": 1, "b": 2, "c": 3}
    ) == {"a": 1, "b": 2, "c": 3}
	assert candidate(keymap={'a': 'b', 'c': 'd'}, inputdict={'a': 1, 'b': 2}) == {'b': 1}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 'c', 'b': 'd'}) == {'b': 'c'}
	assert candidate(keymap=dict(a='A', b='B'),
                          inputdict=dict(a=1, b=2)) == dict(A=1, B=2)
	assert candidate(keymap={"a": "b", "c": "d"},
                          inputdict={"a": 1, "b": 2, "c": 3, "d": 4}) == {"b": 1, "d": 3}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 1}) == {'b': 1}
	assert candidate(keymap=dict(a='A', b='B'),
                          inputdict=dict(c=1, b=2)) == dict(B=2)
	assert candidate(keymap={'a': 'A', 'b': 'B'},
                          inputdict={'a': 1, 'b': 2, 'c': 3}) == \
    {'A': 1, 'B': 2}
	assert candidate(keymap={'a': 'A', 'b': 'B'}, inputdict={'a': 1, 'b': 2}) == {'A': 1, 'B': 2}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 'c', 'b': 'd', 'd': 'e'}) == {'b': 'c'}
	assert candidate(keymap={'a': 'A', 'b': 'B'},
                          inputdict={'a': 1, 'b': 2}) == {'A': 1, 'B': 2}
	assert candidate(keymap={'x': 'y'},
                          inputdict={'x': 1, 'z': 2}) == {'y': 1}
	assert candidate(
    {"a": "b", "c": "d"},
    {"a": 1, "b": 2}
) == {"b": 1}
	assert candidate(keymap={'a': 'a', 'b': 'b'},
                          inputdict={'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
	assert candidate(keymap={'a': 'b'}, inputdict={'d': 'e'}) == {}
	assert candidate(
    {"a": "a", "b": "b", "c": "c"},
    {}
    ) == {}
	assert candidate(keymap={'a': 'a', 'b': 'b'},
                          inputdict={'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}) == {'a': 1, 'b': 2}
	assert candidate(keymap={'a': 'b'}, inputdict={'c': 1}) == {}
	assert candidate(keymap={'a': 'b'}, inputdict={'a': 'x', 'c': 'y'}) == {'b': 'x'}
	assert candidate(
    {"a": "a", "b": "b", "c": "c"},
    {"a": 1, "b": 2}
    ) == {"a": 1, "b": 2}
	assert candidate(keymap={'a': 'b'}, inputdict={}) == {}
	assert candidate(keymap={"a": "b", "c": "d"},
                          inputdict={"a": 1, "b": 2, "c": 3}) == {"b": 1, "d": 3}
	assert candidate(keymap={'a': 'a', 'b': 'b'},
                          inputdict={'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == {'a': 1, 'b': 2}
	assert candidate(
    {"a": "b", "c": "d"},
    {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6}
) == {"b": 1, "d": 3}
	assert candidate(keymap={'a': 'A', 'b': 'B'}, inputdict={'a': 1, 'b': 2, 'c': 3}) == {'A': 1, 'B': 2}
	assert candidate(keymap={'a': 'A', 'b': 'B'},
                          inputdict={'a': 1, 'b': 2, 'c': 3}) == {'A': 1, 'B': 2}
	assert candidate(keymap={'a': 'b'}, inputdict={'c': 2}) == {}
	assert candidate(keymap={'a': 'A'}, inputdict={'a': '1'}) == {'A': '1'}
def test_check():
	check(reformat_dict_keys)
