def zero_if_none(item):
    """If item exists, return id, otherwise return 0."""
    ### Canonical solution below ###
    result_id = 0
    # import pdb; pdb.set_trace()
    if item:
        result_id = item.id
    return result_id


### Unit tests below ###
def check(candidate):
	assert candidate(False) == 0
	assert candidate(0) == 0
	assert candidate(None) == 0
	assert candidate("") == 0
def test_check():
	check(zero_if_none)
