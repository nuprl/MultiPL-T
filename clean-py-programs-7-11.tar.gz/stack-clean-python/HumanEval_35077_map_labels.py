def map_labels(tree, fn):
    """ Returns a tree in which every node's label is mapped by fn"""
	### Canonical solution below ###    
    

    if isinstance(tree, list):
        return [fn(tree[0])]+[map_labels(child,fn) for child in tree[1:]]
    else:
        return tree

### Unit tests below ###
def check(candidate):
	assert candidate([1,2,3], lambda x: x) == [1,2,3]
	assert candidate([1,[2,[3,4],5],6], lambda x: x) == [1,[2,[3,4],5],6]
	assert candidate(None, lambda x: x) == None
	assert candidate(1, lambda x: x) == 1
def test_check():
	check(map_labels)
