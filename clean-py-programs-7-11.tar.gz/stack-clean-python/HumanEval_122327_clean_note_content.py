def clean_note_content(content):
    """ Removes unwanted characters from note content."""
	### Canonical solution below ###    
    return content.strip().replace('"', "'")

### Unit tests below ###
def check(candidate):
	assert candidate(
    'This is a note. It has a lot of whitespace.  \n\t\n\n') == \
    'This is a note. It has a lot of whitespace.'
	assert candidate("a") == "a"
	assert candidate("a  ") == "a"
	assert candidate('a b') == 'a b'
	assert candidate(
    "This is a note with a \"quote\" in it.") == \
    "This is a note with a 'quote' in it."
	assert candidate(u'"a"') == u"'a'"
	assert candidate(u'This is a note') == u'This is a note'
	assert candidate(
    '"This is a test note" \n \n ') == "'This is a test note'"
	assert candidate('a') == 'a'
	assert candidate(
    "  This is a test note.") == "This is a test note."
	assert candidate(u'"') == u"'"
	assert candidate(
    '"This is a test note" \n') == "'This is a test note'"
	assert candidate(u'"a b c" d e"f"g"h"') == u"'a b c' d e'f'g'h'"
	assert candidate(u'"a b c"') == u"'a b c'"
	assert candidate(' a') == 'a'
	assert candidate(r'foo') == 'foo'
	assert candidate("Hello") == "Hello"
	assert candidate('a\nb') == 'a\nb'
	assert candidate(
    "This is a note about something I want to remember about something. "
    "I can also write things like \"This is a quote\".") == (
    "This is a note about something I want to remember about something. "
    "I can also write things like 'This is a quote'.")
	assert candidate(u'"a b c" d e"') == u"'a b c' d e'"
	assert candidate("") == ""
	assert candidate(r' "foo" bar') == "'foo' bar"
	assert candidate(r'"foo" ') == "'foo'"
	assert candidate("Hello\nWorld") == "Hello\nWorld"
	assert candidate('') == ''
	assert candidate(
    "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words.  ") == "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words."
	assert candidate(u'"a b"') == u"'a b'"
	assert candidate(
   'This is a test note ') == 'This is a test note'
	assert candidate("  a") == "a"
	assert candidate(
    "  This is a test note.  ") == "This is a test note."
	assert candidate(u'"This is a \'note\'"') == u"'This is a 'note''"
	assert candidate(' ') == ''
	assert candidate("a b c") == "a b c"
	assert candidate(u'"a b c" d e"f"') == u"'a b c' d e'f'"
	assert candidate(
    '"This is a test note" \n ') == "'This is a test note'"
	assert candidate(
    '"This is a test note" ') == "'This is a test note'"
	assert candidate('a\rb') == 'a\rb'
	assert candidate(u'"a b c" d e"f"g') == u"'a b c' d e'f'g"
	assert candidate("Hello \"World\"") == "Hello 'World'"
	assert candidate(
    "Hello World! I am a note, I am so excited! I have "
    "lots of content and I like to share it with others. I am "
    "so excited about this content! I am going to share this "
    "content with a friend!") == \
    "Hello World! I am a note, I am so excited! I have lots of content and I like to share it with others. I am so excited about this content! I am going to share this content with a friend!"
	assert candidate(r'foo"bar') == r"foo'bar"
	assert candidate("  a  ") == "a"
	assert candidate(
    "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words. ") == "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words."
	assert candidate('a ') == 'a'
	assert candidate(u" \t\n") == ""
	assert candidate(
    '"This is a test note"') == "'This is a test note'"
	assert candidate(
    "Hello World! I am a note, I am so excited! I have "
    "lots of content and I like to share it with others.") == \
    "Hello World! I am a note, I am so excited! I have lots of content and I like to share it with others."
	assert candidate(
    "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words.   ") == "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words."
	assert candidate(
    '"This is a test note" \n \n \n ') == "'This is a test note'"
	assert candidate(r'"foo"') == "'foo'"
	assert candidate(u'"a b c" d e"f"g"') == u"'a b c' d e'f'g'"
	assert candidate(
   '   This is some text!  '
    ) == 'This is some text!'
	assert candidate("Hello World") == "Hello World"
	assert candidate(u"") == ""
	assert candidate("  ") == ""
	assert candidate(r' "foo"') == "'foo'"
	assert candidate(u'"This is a note"') == u"'This is a note'"
	assert candidate(u"a b") == u"a b"
	assert candidate(
    'This is a test note') == 'This is a test note'
	assert candidate(u'"a b c" d e') == u"'a b c' d e"
	assert candidate(u'"a b c" d e"f"g"h') == u"'a b c' d e'f'g'h"
	assert candidate(r'foo"bar"') == r"foo'bar'"
	assert candidate(u'"This is a "note""') == u"'This is a 'note''"
	assert candidate(r'"foo" bar') == "'foo' bar"
	assert candidate(r' "foo" ') == "'foo'"
	assert candidate(
    "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words.") == "This is a note. It has a number of paragraphs. Each paragraph has a number of sentences. Each sentence has a number of words."
	assert candidate(r'This is a "test".') == r"This is a 'test'."
	assert candidate('a\nb\rc') == 'a\nb\rc'
	assert candidate(
    "Hello World! I am a note, I am so excited! I have "
    "lots of content and I like to share it with others. I am "
    "so excited about this content!") == \
    "Hello World! I am a note, I am so excited! I have lots of content and I like to share it with others. I am so excited about this content!"
	assert candidate(u'This is a "note"') == u"This is a 'note'"
	assert candidate(
    "This is a test note.  ") == "This is a test note."
	assert candidate(u'"a b c" d') == u"'a b c' d"
def test_check():
	check(clean_note_content)
