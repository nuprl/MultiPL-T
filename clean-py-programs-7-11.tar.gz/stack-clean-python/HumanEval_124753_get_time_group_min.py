def get_time_group_min(time_group):
    """Return dictionary with min values for each time group."""
    ### Canonical solution below ###
    dict_time_min = {'year': 0,   
                     'season': 1,    
                     'quarter': 1,
                     'month': 1, 
                     'weekofyear': 1, 
                     'dayofweek': 0,
                     'dayofyear': 1,
                     'day': 1,
                     'hour': 0,
                     'minute': 0,
                     'second': 0
                     }
    return dict_time_min[time_group]


### Unit tests below ###
def check(candidate):
	assert candidate(time_group='month') == 1
	assert candidate(time_group='day') == 1
	assert candidate(time_group='quarter') == 1
	assert candidate(time_group='weekofyear') == 1
	assert candidate(time_group='dayofweek') == 0
	assert candidate(time_group='dayofyear') == 1
	assert candidate(time_group='season') == 1
	assert candidate(time_group='year') == 0
	assert candidate(time_group='hour') == 0
	assert candidate(time_group='minute') == 0
	assert candidate(time_group='second') == 0
def test_check():
	check(get_time_group_min)
