def _clean_up_path(path):
    """ Strips an initial "./" and any trailing slashes from 'path'."""
	### Canonical solution below ###    
    if path.startswith("./"):
        path = path[2:]
    return path.rstrip("/")

### Unit tests below ###
def check(candidate):
	assert candidate("a/b") == "a/b"
	assert candidate(r"./a/b/c/") == r"a/b/c"
	assert candidate("a/") == "a"
	assert candidate("a/b/") == "a/b"
	assert candidate(r"a/b/c") == r"a/b/c"
	assert candidate("./a/b") == "a/b"
	assert candidate("foo/bar/baz") == "foo/bar/baz"
	assert candidate("./foo/bar/baz//") == "foo/bar/baz"
	assert candidate("foo/bar/") == "foo/bar"
	assert candidate("./foo/bar/baz/") == "foo/bar/baz"
	assert candidate("./a/") == "a"
	assert candidate("./foo/bar") == "foo/bar"
	assert candidate("./foo/bar/baz") == "foo/bar/baz"
	assert candidate("./a/b/c") == "a/b/c"
	assert candidate("./a/b/") == "a/b"
	assert candidate("./a/b/c/") == "a/b/c"
	assert candidate("a/b/c") == "a/b/c"
	assert candidate("foo//") == "foo"
	assert candidate("foo/bar") == "foo/bar"
	assert candidate("./foo/") == "foo"
	assert candidate(r"a/b/c/") == r"a/b/c"
	assert candidate(".") == "."
	assert candidate("a/b/c/") == "a/b/c"
	assert candidate("foo/") == "foo"
	assert candidate("./foo//") == "foo"
	assert candidate("a") == "a"
	assert candidate("foo") == "foo"
	assert candidate("./foo/bar/") == "foo/bar"
	assert candidate("./") == ""
	assert candidate(r"a/b/c///") == r"a/b/c"
	assert candidate("") == ""
	assert candidate("./foo/bar//") == "foo/bar"
	assert candidate(r"./a/b/c") == r"a/b/c"
	assert candidate(r"./a/b/c///") == r"a/b/c"
	assert candidate("./foo") == "foo"
	assert candidate("./a") == "a"
	assert candidate("/") == ""
def test_check():
	check(_clean_up_path)
