def get_parameter_list_and_par_to_name_dict_from_parameter_dict(pd):
    """Same as get_parameter_list_from_parameter_dict; but also returns a dictionary which keeps track of the keys
    based on memory id.

    :param pd: parameter dictionary
    :return: tuple of (parameter_list, name_dictionary)
    """
    ### Canonical solution below ###

    par_to_name_dict = dict()
    pl = []
    for key in pd:
        pl.append(pd[key])
        par_to_name_dict[pd[key]] = key
    return pl, par_to_name_dict


### Unit tests below ###
def check(candidate):
	assert candidate({'a': 1, 'b': 2, 'c': 3}) == ([1, 2, 3], {1: 'a', 2: 'b', 3: 'c'})
	assert candidate({'a': 1, 'b': 2}) == ([1, 2], {1: 'a', 2: 'b'})
	assert candidate(
    {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
    }
) == ([1, 2, 3, 4], {1: "a", 2: "b", 3: "c", 4: "d"})
	assert candidate({"a": 1, "b": 2, "c": 3}) == ([1, 2, 3], {1: "a", 2: "b", 3: "c"})
	assert candidate({"a": 1}) == ([1], {1: "a"})
	assert candidate(
    {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
        "e": 5,
        "f": 6,
    }
) == ([1, 2, 3, 4, 5, 6], {1: "a", 2: "b", 3: "c", 4: "d", 5: "e", 6: "f"})
	assert candidate({"a": 1, "b": 2}) == ([1, 2], {1: "a", 2: "b"})
	assert candidate({'a': 1}) == ([1], {1: 'a'})
	assert candidate(dict()) == ([], dict())
	assert candidate(
    {
        "a": 1,
        "b": 2,
        "c": 3,
    }
) == ([1, 2, 3], {1: "a", 2: "b", 3: "c"})
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == ([1, 2, 3, 4, 5], {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'})
	assert candidate(
    {'a': 1, 'b': 2}) == ([1, 2], {1: 'a', 2: 'b'})
	assert candidate(dict(a=1, b=2, c=3, d=4)) == ([1, 2, 3, 4], {1: 'a', 2: 'b', 3: 'c', 4: 'd'})
	assert candidate(dict(a=1, b=2, c=3)) == ([1, 2, 3], {1: 'a', 2: 'b', 3: 'c'})
	assert candidate(dict(a=1, b=2)) == ([1, 2], {1: 'a', 2: 'b'})
	assert candidate(
    {"a": 1, "b": 2, "c": 3}) == ([1, 2, 3], {1: "a", 2: "b", 3: "c"})
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}) == ([1, 2, 3], {1: 'a', 2: 'b', 3: 'c'})
	assert candidate(pd={1:'a', 2:'b', 3:'c'})[0] == ['a', 'b', 'c']
	assert candidate(dict()) == ([], {})
def test_check():
	check(get_parameter_list_and_par_to_name_dict_from_parameter_dict)
