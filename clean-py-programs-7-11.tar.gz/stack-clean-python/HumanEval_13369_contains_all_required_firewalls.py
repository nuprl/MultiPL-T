def contains_all_required_firewalls(firewall, topology):
    """
    Check that the list of firewall settings contains all necessary firewall settings
    """
    ### Canonical solution below ###
    for src, row in enumerate(topology):
        for dest, col in enumerate(row):
            if src == dest:
                continue
            if col == 1 and (str((src, dest)) not in firewall or str((dest, src)) not in firewall):
                return False
    return True


### Unit tests below ###
def check(candidate):
	assert not candidate(
    {'0,1': 1, '1,0': 1, '1,2': 1, '2,1': 1, '3,2': 1},
    [[0, 1, 1], [1, 0, 1], [1, 1, 0], [1, 1, 1]]
)
	assert not candidate(
    {'1,2': 'open', '2,3': 'open', '3,1': 'closed'},
    [[0, 1, 0],
     [0, 0, 1],
     [0, 0, 0]])
	assert not candidate(set(['0,1', '1,2', '2,0']), [[0,1,0],[0,0,1],[1,0,0]])
	assert candidate(
    {'0,1': '0', '0,2': '1', '0,3': '2', '1,2': '1', '1,3': '3', '2,3': '3'},
    [[0, 0, 0, 0], [0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
) == False
	assert candidate({'0,1'}, [[0, 1, 0], [0, 0, 1], [1, 1, 0]]) == False
	assert not candidate(set(), [[1, 1, 1], [0, 1, 0]])
	assert not candidate(
    ["0, 1, ALLOW", "1, 2, ALLOW"],
    [[0, 1, 1],
     [0, 0, 1],
     [0, 0, 0]]
)
	assert candidate(set(), [[0]])
	assert not candidate(set(['0,1', '1,2']), [[0,1,0],[0,0,1],[0,0,0]])
	assert not candidate({"0,1"}, [[0, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 0], [0, 0, 0, 0]])
	assert not candidate(
    ["0, 1, ALLOW"],
    [[0, 1, 0],
     [0, 0, 1],
     [0, 0, 0]]
)
	assert not candidate(set(["0,0", "1,1", "2,2", "0,2"]), [[0, 1, 0], [1, 1, 1], [0, 1, 0]])
	assert candidate({'0,1', '1,0', '2,1'}, [[1, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 1]]) == True
	assert not candidate(
    ["0, 1, ALLOW", "1, 2, ALLOW"],
    [[0, 1, 0],
     [0, 0, 1],
     [0, 1, 0]]
)
	assert not candidate(
    {'0,1': 'open', '1,0': 'closed', '1,2': 'closed'},
    [[0, 1, 0],
     [0, 0, 0],
     [0, 0, 0]])
	assert candidate(
    ["0,1,1", "1,0,1", "2,3,1", "3,2,1"],
    [[0, 1, 0], [0, 0, 0], [0, 0, 0], [1, 0, 0]]
) == False
	assert not candidate(
    {'1,2': 'closed', '2,3': 'open', '3,1': 'open'},
    [[0, 1, 0],
     [0, 0, 1],
     [0, 0, 0]])
	assert candidate(set(), [[0, 0, 0], [0, 0, 0]])
	assert not candidate(set(['0,1', '1,2', '2,0']), [[0,1,0],[0,0,1],[0,1,1]])
	assert not candidate({str((0, 1)), str((1, 2))}, [[0, 1, 0], [0, 0, 1]])
	assert not candidate(
    {'0,1': 1, '1,0': 1, '1,2': 1, '2,1': 1, '3,2': 1},
    [[0, 1, 1], [1, 0, 1], [1, 1, 0], [1, 0, 0]]
)
	assert not candidate(set(['0,1', '1,2', '2,0']), [[0,1,0],[0,0,1],[1,1,1]])
	assert not candidate({str((0, 1))}, [[0, 1]])
	assert not candidate(set(), [[1, 0, 1], [0, 1, 0]])
	assert candidate(
    {
        "0,2": 1,
        "1,0": 1,
        "2,0": 1,
        "1,2": 1,
        "2,1": 1,
    },
    [
        [0, 1, 1],
        [0, 0, 1],
        [0, 0, 0],
    ],
) == False
	assert not candidate(set(), [[0, 0, 0], [1, 0, 1]])
	assert not candidate({str((0, 1))}, [[0, 1], [1, 1]])
	assert candidate(set(), [[0, 0, 0], [0, 0, 0], [0, 0, 0]])
	assert candidate(
    ["0,1,1", "1,0,1", "2,3,1", "3,2,1"],
    [[0, 1, 0], [0, 0, 0], [1, 0, 0], [0, 0, 0]]
) == False
	assert not candidate(set(), [[0, 0, 0], [1, 0, 0]])
	assert candidate(
    {'0,1': 'open', '0,2': 'closed', '0,3': 'closed', '0,4': 'closed', '1,2': 'closed', '1,3': 'closed', '1,4': 'closed', '2,3': 'closed', '2,4': 'closed', '3,4': 'closed'},
    [[0, 1, 0, 0, 0],
     [0, 0, 0, 0, 0],
     [0, 0, 0, 0, 0],
     [0, 0, 0, 0, 0]]) == False
	assert candidate({str((0, 1)), str((1, 2))}, [[1, 0, 0], [0, 1, 0]])
	assert not candidate(set(['0,1', '1,2', '2,0']), [[0,1,0],[0,0,1],[1,1,0]])
	assert candidate({str((0, 1)), str((1, 0))}, [[0, 1], [1, 0]])
	assert not candidate({str((0, 1))}, [[0, 1], [1, 0]])
	assert not candidate(
    {'0,1': 1},
    [[0, 0, 0],
     [0, 0, 1],
     [0, 0, 0]]
)
	assert not candidate(set(['0,1', '1,2', '2,0']), [[0,1,0],[0,0,1],[1,0,1]])
	assert candidate({str((0, 1))}, [[0]])
	assert not candidate({str((0, 1)), str((1, 2)), str((2, 0))}, [[0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
	assert not candidate(set(["0,0", "1,1", "2,2", "0,2"]), [[0, 1, 0], [1, 1, 1], [0, 0, 0]])
	assert not candidate(
    {'0,1': 'DROP', '0,2': 'DROP'},
    [[1, 1, 0], [1, 1, 0], [0, 0, 0]]
)
	assert not candidate(
    {'0,1': 'open', '1,0': 'closed', '1,2': 'closed'},
    [[0, 1, 0],
     [0, 0, 1],
     [0, 0, 1]])
	assert not candidate({"0,1", "1,2", "2,3", "3,0"}, [[0, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 0], [0, 0, 0, 1]])
	assert not candidate(
    {'0,1': 1},
    [[0, 1, 0],
     [0, 0, 0],
     [0, 0, 1]]
)
	assert candidate(set(), [[1, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 1]]) == True
	assert candidate({str((0, 1)), str((1, 2)), str((2, 0))}, [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]])
	assert not candidate({str((0, 1))}, [[1, 1], [0, 1]])
	assert not candidate(set(), [[1, 1, 0], [0, 1, 0]])
	assert candidate(set(), [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]])
	assert not candidate(
    {'0,1': 'open', '1,0': 'closed', '1,2': 'closed'},
    [[0, 1, 1],
     [0, 0, 1],
     [0, 0, 0]])
	assert not candidate(
    {'0,1': 1, '1,0': 1, '1,2': 1},
    [[0, 1, 1], [1, 0, 1], [1, 1, 0]]
)
	assert candidate({str((0, 1))}, [[0, 0], [0, 0]])
	assert not candidate(
    {'1,2': 'closed', '2,3': 'closed', '3,1': 'open'},
    [[0, 1, 0],
     [0, 0, 1],
     [0, 0, 0]])
	assert not candidate(set(), [[0, 0, 1], [1, 0, 0]])
	assert candidate({str((0, 1))}, [[1, 0]])
	assert candidate({"0,1"}, [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]])
	assert not candidate(
    {'0,1': 1, '1,0': 1, '1,2': 1, '2,1': 1, '3,2': 1},
    [[0, 1, 1], [1, 0, 1], [1, 1, 0]]
)
	assert not candidate(set(["0,0", "1,1", "2,2"]), [[0, 1, 0], [0, 1, 1], [0, 0, 0]])
	assert candidate(
    ["0,1,1", "1,0,1", "2,3,1", "3,2,1"],
    [[0, 1, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]]
) == False
	assert candidate(
    {'0,1': '0.0.0.0/0', '0,2': '0.0.0.0/0', '0,3': '0.0.0.0/0', '1,2': '0.0.0.0/0', '1,3': '0.0.0.0/0', '2,3': '0.0.0.0/0'},
    [[1, 1, 1],
     [1, 0, 1],
     [1, 1, 1]]) == False
	assert not candidate(set(), [[0, 1, 0], [1, 0, 0]])
	assert not candidate(set(["0,0", "1,1", "2,2", "0,2"]), [[0, 1, 0], [1, 0, 1], [0, 0, 0]])
	assert not candidate(
    {'1,2': 'open', '2,3': 'closed', '3,1': 'open'},
    [[0, 1, 0],
     [0, 0, 1],
     [0, 0, 0]])
	assert not candidate(
    {'0,1': 'DROP', '0,2': 'DROP', '1,2': 'DROP'},
    [[1, 1, 0], [1, 1, 0], [1, 1, 0]]
)
def test_check():
	check(contains_all_required_firewalls)
