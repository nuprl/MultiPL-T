def flatten(l):
    """Flatten a list of lists."""
    ### Canonical solution below ###
    return [item for sublist in l for item in sublist]


### Unit tests below ###
def check(candidate):
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[1, 2, 3], [], [7, 8, 9]] ) == [1, 2, 3, 7, 8, 9]
	assert candidate( [[1, 2], [3], [4, 5, 6]] ) == [1, 2, 3, 4, 5, 6]
	assert candidate( [[1,2,3], [4,5,6]]) == [1,2,3,4,5,6]
	assert candidate( [[1,2,3], [], [5,6]] ) == [1,2,3,5,6]
	assert candidate(l=[[1], [2, 3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]] ) == [1,2,3,4,5,6,7,8,9]
	assert candidate([[1, 2], [3, 4, [5, 6]]]) == [1, 2, 3, 4, [5, 6]]
	assert candidate(
    [[1, 2], [3, 4], [5, 6, 7]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate( [[1, 2, 3], [4, 5, 6]] ) == [1, 2, 3, 4, 5, 6]
	assert candidate(
    [[1, 2], [3, 4], [5, 6], [7, 8]]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate( [[1,2,3], [4,5], [6], [7,8,9,10]] ) == [1,2,3,4,5,6,7,8,9,10]
	assert candidate( [] ) == []
	assert candidate( [[1, 2, 3], [4, 5]] ) == [1, 2, 3, 4, 5]
	assert candidate( [[1,2,3], [4,5], [6], [7,8,9,10]] )!= [1,2,3,4,5,7,8,9,10]
	assert candidate([[1,2,3], [4,5,6], [7,8,9]]) == [1,2,3,4,5,6,7,8,9]
	assert candidate([[1, 2], [3, 4]]) == [1, 2, 3, 4]
	assert candidate([[0, 1], [2, 3]]) == [0, 1, 2, 3]
	assert candidate( [[1,2,3],[4,5],[6,7,8,9]] ) == [1,2,3,4,5,6,7,8,9]
	assert candidate(l=[[1, 2, 3], [4, 5]]) == [1, 2, 3, 4, 5]
	assert candidate([[0, 1], [2, 3], [4, 5]]) == [0, 1, 2, 3, 4, 5]
	assert candidate( [[1]] ) == [1]
	assert candidate(l=[[1], [2, 3]]) == [1, 2, 3]
	assert candidate(l=[[1, 2, 3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate( [[1, 2], [3, 4]] ) == [1, 2, 3, 4]
	assert candidate(l=[[1, 2, 3], [4, 5, 6], [7, 8]]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(
    [[], [], []]) == []
	assert candidate(l=[[1, 2, 3], [4, 5], [6, 7, 8]]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate( [[1], [2], [3]] ) == [1, 2, 3]
	assert candidate([[1, 2], [3, 4], [5, 6], [7, 8]]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(
    [[1, 2, 3], [4, 5], [6, 7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [["a", "b"], ["c", "d"]] ) == ["a", "b", "c", "d"]
	assert candidate( [[1,2,3], [4], [5,6]] ) == [1,2,3,4,5,6]
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9], []] ) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[1,2,3], [], [7,8,9]] ) == [1,2,3,7,8,9]
	assert candidate( [[], [], []] ) == []
	assert candidate( [[], []] ) == []
	assert candidate(
    [[1, 2], [3, 4, 5], [6, 7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[]] ) == []
	assert candidate(
    [[]]) == []
	assert candidate(l=[[1, 2, 3], [4, 5], [6, 7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[1, 2], [3, 4], [5, 6]] ) == [1, 2, 3, 4, 5, 6]
	assert candidate(
    [[1, 2, 3], [4, 5], [6], [7, 8, 9, 10]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9]] ) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate( [[1,2], [3,4], [5,6]] ) == [1,2,3,4,5,6]
def test_check():
	check(flatten)
