def bold(msg: str):
    """Format to bold markdown text"""
    ### Canonical solution below ###
    return f'**{msg}**'


### Unit tests below ###
def check(candidate):
	assert candidate('Hello world') == candidate('Hello world')
	assert candidate('HELLO WORLD') == candidate('HELLO WORLD')
	assert candidate(msg="Hello world") == '**Hello world**'
	assert candidate(msg="hello")!= '**hello'
	assert candidate(1)!= candidate('2')
	assert candidate('hello world') == candidate('hello world')
	assert candidate('Hello\nWorld') == '**Hello\nWorld**'
	assert candidate(1) == '**1**'
	assert candidate('Hello') == '**Hello**'
	assert candidate('test') == '**test**'
	assert candidate('1')!= candidate('2')
	assert candidate('1') == candidate('1')
	assert candidate(msg='test')!= 'test'
	assert candidate(msg='hi') == '**hi**'
	assert candidate(
    'this is candidate'
) == '**this is candidate**'
	assert candidate('a') == '**a**'
	assert candidate(msg='test')!= 'test**'
	assert candidate('Hello World') == candidate('Hello World')
	assert candidate(None) == '**None**'
	assert candidate(msg='test')!= '**test'
	assert candidate('hello') == '**hello**'
	assert candidate(msg='Hello') == '**Hello**'
	assert candidate('Hello world') == '**Hello world**'
	assert candidate(msg='test') == '**test**'
	assert candidate(msg='foo') == '**foo**'
	assert candidate(msg="hello") == '**hello**'
	assert candidate(1) == candidate('1')
	assert candidate('foo') == '**foo**'
	assert candidate('foo') == candidate('foo')
def test_check():
	check(bold)
