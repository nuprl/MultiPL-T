def compute_classification_accuracy(correctly_classified, incorrectly_classified):
    """ 
     Computes the accuracy of the model based on the number of correctly and incorrectly classified points.
     Expresses accuracy as a percentage value.
     
     :param correctly_classified: count of correctly classified data points
     :param incorrectly_classified: count of incorrectly classified data points
     :return: accuracy score
     """
	### Canonical solution below ###    
    accuracy = (correctly_classified / (correctly_classified + incorrectly_classified)) * 100
    return accuracy

### Unit tests below ###
def check(candidate):
	assert candidate(0, 5) == 0.0
	assert candidate(30, 0) == 100
	assert candidate(0, 100) == 0
	assert candidate(10, 10) == 50, "Incorrect value returned by candidate."
	assert candidate(0, 10) == 0
	assert candidate(100, 0) == 100, "Incorrect accuracy calculation"
	assert candidate(10, 10) == 50
	assert candidate(0, 1) == 0
	assert candidate(99, 1) == 99
	assert candidate(25, 25) == 50, "Incorrect classification accuracy."
	assert candidate(1, 1) == 50
	assert candidate(50, 50) == 50.0
	assert candidate(10, 0) == 100
	assert candidate(200, 0) == 100
	assert candidate(1, 0) == 100
	assert candidate(1, 0) == 100, "Should be 100"
	assert candidate(100, 0) == 100
	assert candidate(100, 100) == 50
	assert candidate(0, 1) == 0, "Should be 0"
	assert candidate(10, 0) == 100.0
	assert candidate(0, 10) == 0.0
	assert candidate(10, 10) == 50, "Incorrect classification accuracy."
	assert candidate(1, 1) == 50, "50% accuracy for 2 points"
	assert candidate(99, 1) == 99.0
	assert candidate(100, 0) == 100, "Should be 100"
	assert candidate(0, 100) == 0, "Incorrect accuracy calculation"
	assert candidate(0, 100) == 0, "Should be 0"
	assert candidate(0, 100) == 0.0
	assert candidate(100, 0) == 100.0
	assert candidate(0, 200) == 0
def test_check():
	check(compute_classification_accuracy)
