def get_args(dsl_args):
    """return args, kwargs"""
    ### Canonical solution below ###
    args = []
    kwargs = {}
    for dsl_arg in dsl_args:
        if '=' in dsl_arg:
            k, v = dsl_arg.split('=', 1)
            kwargs[k] = v
        else:
            args.append(dsl_arg)
    return args, kwargs


### Unit tests below ###
def check(candidate):
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l','m', 'n', 'o']) == (
        ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l','m', 'n', 'o'],
        {})
	assert candidate(
    ['a', 'b=c', 'd', 'e=f', 'g=h=i', 'j=k=l']
) == (
    ['a', 'd'],
    {'b': 'c', 'e': 'f', 'g': 'h=i', 'j': 'k=l'}
)
	assert candidate(
    ['a', 'b', 'c', 'd=4', 'e=5', 'f=6', 'g=7']
) == (
    ['a', 'b', 'c'],
    {'d': '4', 'e': '5', 'f': '6', 'g': '7'}
)
	assert candidate(['a=b', 'c']) == (['c'], {'a': 'b'})
	assert candidate(
    ['a', 'b', 'c', 'd=4', 'e=5', 'f=6', 'g=7', 'h=8', 'i=9']
) == (
    ['a', 'b', 'c'],
    {'d': '4', 'e': '5', 'f': '6', 'g': '7', 'h': '8', 'i': '9'}
)
	assert candidate(
    ['a', 'b', 'c=d', 'e=f', 'g', 'h=i', 'j=k=l']) == (
    ['a', 'b', 'g'],
    {'c': 'd', 'e': 'f', 'h': 'i', 'j': 'k=l'})
	assert candidate(
    'arg1=123 arg2=456'.split(' ')
) == (
    [],
    {'arg1': '123', 'arg2': '456'}
)
	assert candidate(
    ['a', 'b', 'c', 'd=4', 'e=5', 'f=6', 'g=7', 'h=8', 'i=9', 'j=10']
) == (
    ['a', 'b', 'c'],
    {'d': '4', 'e': '5', 'f': '6', 'g': '7', 'h': '8', 'i': '9', 'j': '10'}
)
	assert candidate('a') == (['a'], {})
	assert candidate(['arg1']) == (['arg1'], {})
	assert candidate(['x']) == (['x'], {})
	assert candidate(['arg=val', 'arg2=val2', 'arg3']) == (['arg3'], {'arg': 'val', 'arg2': 'val2'})
	assert candidate(
    'arg1 arg2 arg3=123 arg4=456'.split(' ')
) == (
    ['arg1', 'arg2'],
    {'arg3': '123', 'arg4': '456'}
)
	assert candidate(['arg=val', 'arg2=val2']) == ([], {'arg': 'val', 'arg2': 'val2'})
	assert candidate(['arg', 'arg2']) == (['arg', 'arg2'], {})
	assert candidate(['a', 'b']) == (['a', 'b'], {})
	assert candidate(
    ['a', 'b=c', 'd', 'e=f', 'g=h=i', 'j=k=l=m=n']
) == (
    ['a', 'd'],
    {'b': 'c', 'e': 'f', 'g': 'h=i', 'j': 'k=l=m=n'}
)
	assert candidate(
    'arg1=123 arg2=456 arg3=789'.split(' ')
) == (
    [],
    {'arg1': '123', 'arg2': '456', 'arg3': '789'}
)
	assert candidate(['a', 'b=c']) == (['a'], {'b': 'c'})
	assert candidate(['arg=val']) == ([], {'arg': 'val'})
	assert candidate(['arg1=val1', 'arg2=val2']) == ([], {'arg1': 'val1', 'arg2': 'val2'})
	assert candidate('') == ([], {})
	assert candidate(
    ['a', 'b', 'c=d', 'e=f=g']) == (['a', 'b'], {'c': 'd', 'e': 'f=g'})
	assert candidate(
    ['a', 'b=c', 'd', 'e=f', 'g=h=i']
) == (
    ['a', 'd'],
    {'b': 'c', 'e': 'f', 'g': 'h=i'}
)
	assert candidate(
    'arg1 arg2 arg3=123 arg4=456 arg5=567'.split(' ')
) == (
    ['arg1', 'arg2'],
    {'arg3': '123', 'arg4': '456', 'arg5': '567'}
)
	assert candidate(['arg1=val1']) == ([], {'arg1': 'val1'})
	assert candidate(['a', 'b', 'c=1']) == (['a', 'b'], {'c': '1'})
	assert candidate(
    'arg1 arg2 arg3=123 arg4=456 arg5=567 arg6=678'.split(' ')
) == (
    ['arg1', 'arg2'],
    {'arg3': '123', 'arg4': '456', 'arg5': '567', 'arg6': '678'}
)
	assert candidate(['arg1', 'arg2']) == (['arg1', 'arg2'], {})
	assert candidate(
    ['a', 'b', 'c=d', 'e=f', 'g', 'h=i', 'j=k=l','m=n=o']) == (
    ['a', 'b', 'g'],
    {'c': 'd', 'e': 'f', 'h': 'i', 'j': 'k=l','m': 'n=o'})
	assert candidate(['a=b']) == ([], {'a': 'b'})
	assert candidate(
    ['a', 'b', 'c=1', 'd=2', 'e=3', 'f=4', 'g=5', 'h=6', 'i=7', 'j=8', 'k=9']) \
    == (['a', 'b'],
        {'c': '1', 'd': '2', 'e': '3', 'f': '4', 'g': '5', 'h': '6',
         'i': '7', 'j': '8', 'k': '9'})
	assert candidate(
    ['a', 'b', 'c', 'd', 'e=f', 'g=h', 'i=j=k', 'l=m=n', 'o=p=q=r']) == (
    ['a', 'b', 'c', 'd'],
    {'e': 'f', 'g': 'h', 'i': 'j=k', 'l':'m=n', 'o': 'p=q=r'})
	assert candidate(
    ['a', 'b', 'c=d', 'e=f', 'g', 'h=i', 'j=k=l','m=n=o', 'p=q=r']) == (
    ['a', 'b', 'g'],
    {'c': 'd', 'e': 'f', 'h': 'i', 'j': 'k=l','m': 'n=o', 'p': 'q=r'})
	assert candidate(
    ['a', 'b', 'c', 'd=1', 'e=2']) == (['a', 'b', 'c'], {'d': '1', 'e': '2'})
	assert candidate(
    ['a', 'b=c', 'd', 'e=f', 'g=h=i', 'j=k=l=m']
) == (
    ['a', 'd'],
    {'b': 'c', 'e': 'f', 'g': 'h=i', 'j': 'k=l=m'}
)
	assert candidate(['a', 'b=c', 'd']) == (['a', 'd'], {'b': 'c'})
	assert candidate(['arg']) == (['arg'], {})
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l','m', 'n', 'o=p']) == (
        ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l','m', 'n'],
        {'o': 'p'})
	assert candidate(
    ['a', 'b', 'c', 'd=4', 'e=5', 'f=6', 'g=7', 'h=8']
) == (
    ['a', 'b', 'c'],
    {'d': '4', 'e': '5', 'f': '6', 'g': '7', 'h': '8'}
)
	assert candidate(['x', 'y']) == (['x', 'y'], {})
	assert candidate(['arg1', 'arg2=val2']) == (['arg1'], {'arg2': 'val2'})
	assert candidate([]) == ([], {})
	assert candidate(['a', 'b', 'c=d', 'e=f=g']) == (
        ['a', 'b'], {'c': 'd', 'e': 'f=g'})
	assert candidate(
    ['a', 'b', 'c=d', 'e=f', 'g=h', 'i', 'j=k=l']) == (
        ['a', 'b', 'i'], {'c': 'd', 'e': 'f', 'g': 'h', 'j': 'k=l'})
	assert candidate(['a', 'b', 'c']) == (['a', 'b', 'c'], {})
	assert candidate(['a']) == (['a'], {})
def test_check():
	check(get_args)
