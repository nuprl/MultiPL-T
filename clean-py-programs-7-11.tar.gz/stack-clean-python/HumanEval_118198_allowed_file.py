def allowed_file(filename):
    """ Check whether filetype should be accepted.
     
     Args:
     filename ([str]): string representation of filename, e.g. test.py
     
     Returns:
     [bool]: true or false
     """
	### Canonical solution below ###    
    return "." in filename and filename.rsplit(".", 1)[1].lower() in {
        "py",
        "java",
        "js",
        "json",
        "xml",
        "lock",
        "gradle",
        "kts",
        "sbt",
        "txt",
        "sum",
        "csproj",
    }

### Unit tests below ###
def check(candidate):
	assert candidate(
    "test.sum"
), "test.sum should be accepted, but it's not."
	assert not candidate(
    "test.html"
), "Filetype should not be accepted, but is. Check filename."
	assert candidate(
    "test.py"
), "File test.py not accepted. Check candidate function"
	assert candidate(
    "test.lock"
) == True, "Lock file should be accepted, but isn't"
	assert candidate(
    "test.sbt"
), "test.sbt should be accepted as a valid file, but is not"
	assert candidate(
    "test.csproj"
), "C# files should be accepted but aren't."
	assert candidate(
    "test.txt"
), "test.txt should be accepted as a valid file, but is not"
	assert candidate(
    "test.py"
), "filename with.py should be accepted, test.py was not"
	assert candidate("test.java") == True, "Allowed file returns false when it should be true"
	assert candidate("test.xml") is True
	assert not candidate(
    "test.exe"
), "Filetype should be rejected but isn't"
	assert candidate("test.java") == True
	assert not candidate(
    "test.tar"
), "Filetype should not be accepted for test.tar"
	assert candidate("") == False
	assert candidate(
    "test.js"
), "Filetype should be accepted for test.js"
	assert candidate(
    "test.lock"
) == True, "candidate should return True for file with.lock extension"
	assert candidate("test.sbt") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.json"
), "JSON files should be accepted, test.json should be accepted."
	assert candidate("test.py") == True
	assert candidate(
    "test.py"
), "Filetype should be accepted but isn't"
	assert candidate(
    "test.py"
), "Filename test.py should be allowed but isn't"
	assert candidate(
    "test.sum"
), "Filetype should be accepted for test.sum"
	assert candidate(
    "test.sbt"
), "Scala Build Tool files should be accepted, test.sbt should be accepted."
	assert candidate(
    "test.py"
), "Allowed file.py should be accepted"
	assert not candidate(
    "test"
), "test should not be accepted, but it is."
	assert not candidate(
    "test.pdf"
), "PDF files should not be accepted"
	assert not candidate(
    "test.pyc"
), "Only Python, Java, Javascript, JSON, XML, Lock, Gradle, KTS, SBT, TXT, SUM, and CSPROJ files are allowed."
	assert candidate(
    "test.sum"
), "Checksum files should be accepted, test.sum should be accepted."
	assert candidate(
    "test.sum"
), "Allowed file test.sum is not accepted by candidate function"
	assert candidate(
    "test.py"
), "Python files should be accepted but aren't."
	assert candidate(
    "test.py"
), "Filetype should be accepted, but is not. Check filename."
	assert not candidate("test"), "Only Python, Java, Javascript, JSON, XML, Lock, Gradle, KTS, SBT, TXT, SUM, and CSPROJ files are allowed."
	assert candidate(
    "test.js"
) == True, "Allowed file test.js is not returning True"
	assert candidate(
    "test.txt"
) == True, "Allowed file test.txt is not returning True"
	assert candidate(
    "test.sum"
), "Allowed file.sum should be accepted"
	assert candidate("test.csproj") == True
	assert candidate(
    "test.csproj"
), "Filetype should be accepted for test.csproj"
	assert candidate("test.sbt.bak") == False
	assert candidate(
    "test.sum"
), "Filename test.sum not recognized as checksum file. Filename: test.sum"
	assert candidate(
    "test.py"
) == True, "Python file should be accepted, but isn't"
	assert candidate(
    "test.gradle"
) == True, "Gradle file should be accepted, but isn't"
	assert candidate("test.java.bak") == False
	assert not candidate(
    "test.rb"
), "Filetype test.rb is in the list of accepted filetypes"
	assert candidate(
    "test.java"
), "filename with.java should be accepted, test.java was not"
	assert candidate(
    "test.txt"
), "test.txt should be accepted, but it's not."
	assert candidate(
    "test.sum"
), "Should return true for a sum file"
	assert candidate(
    "test.js"
), "Filename test.js not recognized as JavaScript file. Filename: test.js"
	assert candidate(
    "test.sbt"
) == True, "SBT file should be accepted, but isn't"
	assert candidate(
    "test.txt"
), "Text files should be accepted but aren't."
	assert candidate("test.csproj") is True
	assert candidate(
    "test.csproj"
), "Allowed file.csproj should be accepted"
	assert candidate(
    "test.js"
), "Javascript files should be accepted, but are not"
	assert candidate(
    "test.txt"
) == True, "TXT file should be accepted, but isn't"
	assert candidate("test.sum.bak") == False
	assert candidate(
    "test.kts"
) == True, "candidate should return True for file with.kts extension"
	assert not candidate(
    "test.not_allowed"
), "Filetype should not be accepted, but is recognized as such"
	assert candidate(
    "test.csproj"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate("test.sum") == True
	assert candidate("test.gradle") == True
	assert candidate(
    "test.xml"
), "Should return true for a xml file"
	assert not candidate(
    "test.rb"
), "filename with.rb should not be accepted, test.rb was accepted"
	assert candidate(
    "test.sum"
) == True, "candidate should return True for file with.sum extension"
	assert candidate(
    "test.json"
), "Json files should be accepted, but are not"
	assert not candidate(
    "test"
), "Filetype should not be accepted for test"
	assert candidate(
    "test.txt"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate(
    "test.json"
) == True, "JSON file should be accepted, but isn't"
	assert candidate(
    "test.xml"
) == True, "Allowed file test.xml is not returning True"
	assert candidate(
    "test.gradle"
) == True, "candidate should return True for file with.gradle extension"
	assert candidate(
    "test.csproj"
), "Should return true for a csproj file"
	assert candidate(
    "test.kts"
), "Filetype should be accepted for test.kts"
	assert candidate(
    "test.csproj"
) == True, "CSProj file should be accepted, but isn't"
	assert candidate(
    "test.js"
), "Allowed file test.js is not accepted by candidate function"
	assert candidate(
    "test.json"
), "filename with.json should be accepted, test.json was not"
	assert candidate(
    "test.csproj"
), "C# files should be accepted, but are not"
	assert candidate(
    "test.kts"
), "Allowed file.kts should be accepted"
	assert candidate(
    "test.sbt"
), "Allowed file.sbt should be accepted"
	assert candidate("test") == False, "Allowed file returns true when it should be false"
	assert candidate(
    "test.json"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate("test.json") == True
	assert not candidate(
    "test.cpp"
), "Only Python, Java, Javascript, JSON, XML, Lock, Gradle, KTS, SBT, TXT, SUM, and CSPROJ files are allowed."
	assert candidate(
    "test.java"
), "Allowed file.java should be accepted"
	assert candidate("test.lock") is True
	assert candidate("test.xml.bak") == False
	assert not candidate(
    "test.zip"
), "Filetype should not be accepted for test.zip"
	assert candidate(
    "test.lock"
), "Allowed file test.lock is not accepted by candidate function"
	assert candidate(
    "test.java"
), "Filename test.java not recognized as Java file. Filename: test.java"
	assert candidate(
    "test.py"
) == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.csproj"
) == True, "Allowed file test.csproj is not returning True"
	assert candidate("test.kts.bak") == False
	assert candidate(
    "test.xml.exe"
) == False, "Allowed file test.xml.exe is not returning False"
	assert candidate("test.json") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.gradle"
), "Allowed file test.gradle is not accepted by candidate function"
	assert candidate(
    "test.txt"
), "Filename test.txt not recognized as text file. Filename: test.txt"
	assert candidate("test.lock") == True, "Allowed file returns false when it should be true"
	assert candidate("test.cpp") == False, "Allowed file returns true when it should be false"
	assert candidate("test.lock.bak") == False
	assert candidate("test.js") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.java"
), "Java files should be accepted, but are not"
	assert candidate(
    "test.txt"
), "filename with.txt should be accepted, test.txt was not"
	assert candidate(
    "test.json"
), "Filetype should be accepted for test.json"
	assert not candidate(
    "test.pdf"
), "Filetype should not be accepted for test.pdf"
	assert candidate(
    "test.xml"
), "Allowed file test.xml is not accepted by candidate function"
	assert not candidate(
    "test"
), "Should not be allowed filetype, since it does not have an extension"
	assert candidate(
    "test.xml"
), "test.xml should be accepted, but it's not."
	assert candidate(
    "test.lock"
), "test.lock should be accepted as a valid file, but is not"
	assert candidate(
    "test.sbt"
), "Should return true for a sbt file"
	assert not candidate(
    "test.exe"
), "Disallowed file should have been rejected"
	assert candidate(
    "test.js"
) == True, "Javascript file should be accepted, but isn't"
	assert candidate(
    "test.sum"
) == True, "SUM file should be accepted, but isn't"
	assert candidate(
    "test.kts"
), "test.kts should be accepted, but it's not."
	assert candidate(
    "test.sbt"
), "test.sbt should be accepted, but it's not."
	assert candidate("") is False
	assert candidate(
    "test.sum"
), "filename with.sum should be accepted, test.sum was not"
	assert candidate(
    "test.js"
), "filename with.js should be accepted, test.js was not"
	assert candidate(
    "test.py"
), "test.py should be accepted as a valid file, but is not"
	assert not candidate(
    "test.pyt"
), "Should return false for a file with invalid extension"
	assert candidate(
    "test.kts"
), "Allowed file test.kts is not accepted by candidate function"
	assert candidate("test.kts") == True
	assert not candidate(
    "test.tar"
), "Only Python, Java, Javascript, JSON, XML, Lock, Gradle, KTS, SBT, TXT, SUM, and CSPROJ files are allowed."
	assert candidate("test.java") is True
	assert not candidate(
    "test"
), "Filetype should be rejected but isn't"
	assert candidate(
    "test.sh"
) == False, "Shell file should not be accepted, but is"
	assert candidate("test.c") == False, "Allowed file returns true when it should be false"
	assert candidate(
    "test.py"
), "Filetype should be accepted for test.py"
	assert (
    not candidate(
        "test.py.bak"
    )
), "Not allowed file test.py.bak is accepted by candidate function"
	assert candidate(
    "test.sum"
), "Checksum files should be accepted but aren't."
	assert candidate(
    "test.xml"
), "filename with.xml should be accepted, test.xml was not"
	assert candidate(
    "test.json"
), "Allowed file.json should be accepted"
	assert not candidate(
    "test"
), "Filename should not be accepted because it has no filetype"
	assert candidate(
    "test.xml"
), "XML files should be accepted but aren't."
	assert candidate("test.gradle.bak") == False
	assert not candidate(
    "test.exe"
), "Executable files should not be accepted"
	assert candidate("test.csproj.bak") == False
	assert candidate(
    "test.txt"
), "Filetype should be accepted for test.txt"
	assert candidate("test.lock") == True
	assert not candidate(
    ".gitignore"
), "File with only an extension should have been rejected"
	assert candidate(
    "test.sbt"
), "Allowed file test.sbt is not accepted by candidate function"
	assert not candidate(
    "test.exe"
), "Should not be allowed filetype, since it is an executable"
	assert candidate("test.sum") is True
	assert candidate(
    "test.sbt"
), "Filetype should be accepted for test.sbt"
	assert candidate(
    "test.txt"
) == True, "candidate should return True for file with.txt extension"
	assert candidate(
    "test.lock"
) == True, "Allowed file test.lock is not returning True"
	assert candidate(
    "test.js"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate(
    "test.csproj"
), "test.csproj should be accepted as a valid file, but is not"
	assert candidate(
    "test.xml"
), "Allowed file.xml should be accepted"
	assert candidate(
    "test.gradle"
), "Should return true for a gradle file"
	assert candidate(
    "test.gradle"
), "Gradle files should be accepted, test.gradle should be accepted."
	assert candidate("test.js") == True
	assert candidate(
    "test.sbt"
), "Sbt files should be accepted, but are not"
	assert candidate(
    "test.csproj"
) == True, "candidate should return True for file with.csproj extension"
	assert candidate(
    "test.gradle"
), "test.gradle should be accepted, but it's not."
	assert candidate(
    "test.lock"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate(
    "test.js"
), "Javascript files should be accepted but aren't."
	assert candidate(
    "test.py"
), "Filename should be accepted because it has an accepted filetype"
	assert candidate("test.py") is True
	assert candidate(
    "test.py"
) == True, "Allowed file test.py is not returning True"
	assert candidate(
    "test.kts"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate("test.kts") is True
	assert candidate(
    "test.xml"
) == True, "XML file should be accepted, but isn't"
	assert candidate(
    "test.lock"
), "Should return true for a lock file"
	assert candidate(
    "test.lock"
), "Allowed file test.lock failed. Did you use the correct method?"
	assert candidate("test.gradle") is True
	assert candidate(
    "test.js"
), "Allowed file.js should be accepted"
	assert not candidate(
    "test"
), "Should return false for a file with no extension"
	assert candidate("test.xml") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.py"
), "Filename test.py not recognized as Python file. Filename: test.py"
	assert candidate(
    "test.sum"
) == True, "Allowed file test.sum is not returning True"
	assert candidate("test.json") is True
	assert candidate(
    "test.kts"
), "Kotlin files should be accepted but aren't."
	assert candidate(
    "test.json"
), "Should return true for a json file"
	assert candidate(
    "test.js"
) == True, "candidate should return True for file with.js extension"
	assert candidate(
    "test.js"
), "test.js should be accepted, but it's not."
	assert candidate(
    "test.gradle"
), "Filename test.gradle not recognized as Gradle file. Filename: test.gradle"
	assert candidate(
    "test.kts"
), "Kotlin DSL files should be accepted, test.kts should be accepted."
	assert candidate(
    "test.kts"
) == True, "Allowed file test.kts is not returning True"
	assert candidate(
    "test.gradle"
), "Gradle files should be accepted but aren't."
	assert candidate(
    "test.py"
), "Allowed file test.py is not accepted by candidate function"
	assert not candidate(
    "test.go"
), "Filetype should not be accepted, but is. Check filename."
	assert candidate(
    "test.csproj"
), "test.csproj should be accepted, but it's not."
	assert candidate(
    "test.gradle"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate("test") is False
	assert candidate(
    "test.py"
), "Python files should be accepted, but are not"
	assert candidate(
    "test.sbt"
), "Sbt files should be accepted but aren't."
	assert candidate(
    "test.gradle"
), "Filetype should be accepted for test.gradle"
	assert candidate(
    "test.csproj"
), "filename with.csproj should be accepted, test.csproj was not"
	assert candidate(
    "test.sbt"
), "Filename test.sbt not recognized as Scala file. Filename: test.sbt"
	assert candidate(
    "test.py"
), "Allowed file should have been accepted"
	assert candidate(
    "test.xml"
), "XML files should be accepted, test.xml should be accepted."
	assert candidate(
    "test.lock"
), "Lock files should be accepted but aren't."
	assert candidate(
    "test.py"
) == True, "candidate should return True for file with.py extension"
	assert candidate("test.txt") is True
	assert candidate(
    "test.json"
), "test.json should be accepted, but it's not."
	assert candidate(
    "test.xml"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate(
    "test.csproj"
), "C# project files should be accepted, test.csproj should be accepted."
	assert candidate("test.txt.bak") == False
	assert candidate("test.csproj") == True, "Allowed file returns false when it should be true"
	assert not candidate(
    "test.exe"
), "Disallowed file test.exe failed. Did you use the correct method?"
	assert candidate(
    "test.json"
), "Filename test.json not recognized as JSON file. Filename: test.json"
	assert candidate(
    "test.gradle"
), "Allowed file.gradle should be accepted"
	assert not candidate(
    "test.pyc"
), "Python bytecode files should not be accepted, test.pyc should not be accepted."
	assert candidate(
    "test.sbt"
) == True, "Allowed file test.sbt is not returning True"
	assert candidate("test.js.bak") == False
	assert candidate(
    "test.kts"
) == True, "KTS file should be accepted, but isn't"
	assert candidate("test.sbt") == True
	assert candidate("test.kts") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.py"
), "Filetype should be accepted, but is not recognized as such"
	assert candidate(
    "test.py"
), "Python files should be accepted, test.py should be accepted."
	assert candidate(
    "test.kts"
), "Filename test.kts not recognized as Kotlin file. Filename: test.kts"
	assert candidate(
    "test.java"
), "test.java should be accepted, but it's not."
	assert candidate(
    "test.lock"
), "Allowed file.lock should be accepted"
	assert not candidate(
    "test"
), "Filename test should not be allowed but is"
	assert candidate(
    "test.csproj"
), "Filename test.csproj not recognized as C# file. Filename: test.csproj"
	assert not candidate(
    "test"
), "File without extension should not be accepted"
	assert candidate(
    "test.sbt"
), "Filetype should be accepted, but is not. Check filename."
	assert not candidate(
    "test.exe"
), "test.exe should not be accepted as a valid file, but is"
	assert candidate("test.js") is True
	assert (
    not candidate(
        "test.pyc"
    )
), "Not allowed file test.pyc is accepted by candidate function"
	assert candidate(
    "test.kts"
), "filename with.kts should be accepted, test.kts was not"
	assert candidate("test.gradle") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.java"
), "Should return true for a java file"
	assert candidate(
    "test"
) == False, "File with no extension should not be accepted, but is"
	assert candidate("test.other") == False
	assert candidate("test.json.bak") == False
	assert not candidate(
    "test.exe"
), "Filename should not be accepted because it has an unaccepted filetype"
	assert candidate(
    "test.lock"
), "Filetype should be accepted for test.lock"
	assert candidate(
    "test.json"
) == True, "Allowed file test.json is not returning True"
	assert candidate(
    "test.txt"
), "Allowed file test.txt is not accepted by candidate function"
	assert candidate(
    "test.lock"
), "Lock files should be accepted, test.lock should be accepted."
	assert candidate("test.sbt") is True
	assert candidate(
    "test.java"
), "Allowed file test.java is not accepted by candidate function"
	assert candidate(
    "test.java"
) == True, "Allowed file test.java is not returning True"
	assert candidate(
    "test.java"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate(
    "test.lock"
), "Lock files should be accepted, but are not"
	assert candidate(
    "test.json"
), "JSON files should be accepted but aren't."
	assert candidate(
    "test.lock"
), "Filename test.lock not recognized as lock file. Filename: test.lock"
	assert candidate(
    "test.gradle"
), "test.gradle should be accepted as a valid file, but is not"
	assert candidate(
    "test.py"
), "Filetype test.py is not in the list of accepted filetypes"
	assert candidate(
    "test.xml"
), "Xml files should be accepted, but are not"
	assert candidate(
    "test.xml"
), "Filetype should be accepted for test.xml"
	assert candidate(
    "test.py"
), "Should be allowed filetype, since it has a period and a py extension"
	assert candidate(
    "test.json"
), "test.json should be accepted as a valid file, but is not"
	assert candidate(
    "test.gradle"
), "filename with.gradle should be accepted, test.gradle was not"
	assert candidate(
    "test.gradle"
), "Gradle files should be accepted, but are not"
	assert candidate(
    "test.kts"
), "test.kts should be accepted as a valid file, but is not"
	assert candidate(
    "test.py"
), "Allowed file test.py failed. Did you use the correct method?"
	assert not candidate(
    "test.py.exe"
), "Filetype should be rejected but isn't"
	assert candidate(
    "test.py"
), "Only Python, Java, Javascript, JSON, XML, Lock, Gradle, KTS, SBT, TXT, SUM, and CSPROJ files are allowed."
	assert (
    not candidate("test.exe")
), "Executables should not be accepted, but are"
	assert candidate(
    "test.txt"
), "Text files should be accepted, but are not"
	assert candidate(
    "test.txt"
), "Should return true for a txt file"
	assert candidate(
    "test.gradle"
) == True, "Allowed file test.gradle is not returning True"
	assert not candidate(
    "test"
), "File without an extension should have been rejected"
	assert candidate(
    "test.kts"
), "Should return true for a kts file"
	assert candidate(
    "test.sbt"
), "filename with.sbt should be accepted, test.sbt was not"
	assert candidate(
    "test.xml"
), "Filename test.xml not recognized as XML file. Filename: test.xml"
	assert candidate(
    "test.json"
) == True, "candidate should return True for file with.json extension"
	assert candidate("test.txt") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.txt"
), "Allowed file.txt should be accepted"
	assert candidate(
    "test.py"
), "Should return true for a python file"
	assert candidate(
    "test.sum"
), "Filetype should be accepted, but is not. Check filename."
	assert candidate(
    "test.xml"
) == True, "candidate should return True for file with.xml extension"
	assert candidate(
    "test.sum"
), "test.sum should be accepted as a valid file, but is not"
	assert candidate("test.txt") == True
	assert candidate("test.sum") == True, "Allowed file returns false when it should be true"
	assert candidate(
    "test.kts"
), "Kotlin files should be accepted, but are not"
	assert candidate(
    "test.js"
), "test.js should be accepted as a valid file, but is not"
	assert candidate(
    "test.js"
), "Should return true for a javascript file"
	assert candidate(
    "test.sbt"
) == True, "candidate should return True for file with.sbt extension"
	assert candidate(
    "test.java"
), "test.java should be accepted as a valid file, but is not"
	assert candidate(
    "test.csproj"
), "Allowed file test.csproj is not accepted by candidate function"
	assert candidate(
    "test.xml"
), "test.xml should be accepted as a valid file, but is not"
	assert candidate("test.xml") == True
	assert candidate(
    "test.lock"
), "filename with.lock should be accepted, test.lock was not"
	assert candidate(
    "test.lock"
), "test.lock should be accepted, but it's not."
	assert candidate(
    "test.txt"
), "Text files should be accepted, test.txt should be accepted."
	assert candidate(
    "test.java"
) == True, "Java file should be accepted, but isn't"
	assert candidate(
    "test.java"
) == True, "candidate should return True for file with.java extension"
	assert candidate(
    "test.lock.exe"
) == False, "Allowed file test.lock.exe is not returning False"
	assert candidate(
    "test.sum"
), "Checksum files should be accepted, but are not"
	assert candidate(
    "test.py"
), "test.py should be accepted, but it's not."
	assert candidate("test.py.bak") == False
	assert candidate(
    "test.java"
), "Filetype should be accepted for test.java"
def test_check():
	check(allowed_file)
