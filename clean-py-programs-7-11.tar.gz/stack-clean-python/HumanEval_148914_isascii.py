def isascii(s):
    """Return True if there are no non-ASCII characters in s, False otherwise.

    Note that this function differs from the str.is* methods in that
    it returns True for the empty string, rather than False.

    >>> from bridgedb.util import isascii
    >>> isascii('\x80')
    False
    >>> isascii('foo\tbar\rbaz\n')
    True
    >>> isascii('foo bar')
    True

    :param str s: The string to check for non-ASCII characters.
    """
    ### Canonical solution below ###
    return all(map((lambda ch: ord(ch) < 128), s))


### Unit tests below ###
def check(candidate):
	assert not candidate(u"foo\u2019bar")
	assert candidate(u''), "Empty string is ASCII"
	assert candidate(u"\u2014 foo bar") == False
	assert candidate(u'foo\u0080bar\u0080') is False
	assert candidate(u"foo\tbar\rbaz\n") == True
	assert candidate(u'foo bar\n')
	assert candidate(u'\x80') is False
	assert candidate("foo\tbar\rbaz\n")
	assert not candidate(u'\x80\x80\x80\x80\x80')
	assert not candidate('\x80')
	assert candidate(u'\n\n\n\n')
	assert not candidate(u'foo\u2011bar')
	assert not candidate("foo\x80bar")
	assert candidate('foo') is True
	assert candidate(u"") == True
	assert not candidate('foo\u2011bar')
	assert candidate(u'foo bar') is True
	assert not candidate(u'\x80\x80\x80')
	assert candidate(''.encode('iso-8859-1'))
	assert candidate(u'foo bar\n\n\n')
	assert candidate(u''.encode('ascii'))
	assert candidate(u'foo\u0080bar') is False
	assert candidate(u'foo bar'), "ASCII string is ASCII"
	assert candidate(u'foo')
	assert candidate("foo bar")
	assert candidate(u'\u0080') is False
	assert candidate(u'foo bar\n\n\n\n\n')
	assert candidate(u'\n\n\n')
	assert candidate(u'') is True
	assert not candidate(u'\x80' + u'foo bar'), "Non-ASCII string is not ASCII"
	assert candidate(u'foo bar\n\n\n\n')
	assert candidate('foo\x80') is False
	assert candidate(u"foo\tbar\rbaz\n")
	assert not candidate(u"\u2019")
	assert not candidate(u"\x80")
	assert candidate(u'')
	assert candidate(u'\n\n\n\n\n')
	assert candidate(u''.join([chr(i) for i in range(128)]))
	assert candidate('foo bar')
	assert not candidate(u"foo\tbar\rbaz\n\x80")
	assert candidate(u"\u2014") == False
	assert candidate('')
	assert not candidate(u'\u0080')
	assert not candidate(u'foo\x80bar')
	assert candidate(u'\n\n')
	assert not candidate(u'\x80'), "Non-ASCII string is not ASCII"
	assert not candidate(u'\x80')
	assert candidate(u'foo\tbar\rbaz\n')
	assert candidate(u'foo bar\n\n')
	assert not candidate(u'foo\u2000bar')
	assert candidate(u"foo bar \u2014") == False
	assert candidate(u'\n')
	assert not candidate(u'foo \u2661 \u203d bar')
	assert candidate(b'')
	assert candidate(u"foobar")
	assert candidate(u'foo bar')
	assert candidate(u"foo bar")
	assert candidate('') is True
	assert not candidate(u'\x80\x80\x80\x80')
	assert not candidate(u'foo bar\x80'), "Non-ASCII string is not ASCII"
	assert not candidate(u'foo\tbar\rbaz\n' + u'\x80'), "Non-ASCII string is not ASCII"
	assert candidate(u''.encode('iso-8859-1'))
	assert not candidate(u"foo\u2660bar")
	assert candidate(''.encode('ascii'))
	assert candidate(u"foo bar") == True
	assert candidate(u'foo\tbar\rbaz\n') is True
	assert not candidate(u'\x80\x80')
	assert not candidate(u'\u2019')
	assert candidate(u'foo\u0080bar\u0080baz') is False
	assert candidate(u"foo \u2014 bar") == False
	assert not candidate(u''.join([chr(i) for i in range(128)] + [chr(256)]))
	assert candidate(u"\x80") == False
	assert candidate(u"")
def test_check():
	check(isascii)
