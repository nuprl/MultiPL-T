def compareThresh(value,threshold,mode,inclusive, *, default=False):
    """ Returns a boolean only if value satisfies the threshold test. In case of failure of any sort, returns the default value (which defaults to 'False').
     
     Accepted mode values are '<', '>', '<=' and '>='."""
	### Canonical solution below ###    
    
    #normalizing input
    if inclusive:
        if mode == ">":
            mode = ">="
        elif mode == "<":
            mode = "<="

    if mode == "<": return value < threshold
    elif mode == ">": return value > threshold
    elif mode == "<=": return value <= threshold
    elif mode == ">=": return value >= threshold

    return default

### Unit tests below ###
def check(candidate):
	assert candidate(5,10,">",True) == False
	assert candidate(1,2,">=",False) == False
	assert candidate(3,5,"<",True) == True
	assert candidate(5, 5, '>=', False, default=True) == True
	assert candidate(2,3,'>',True) == False
	assert candidate(0,0,'>=',False) == True
	assert candidate(1,2,'<=',True) == True
	assert candidate(0,0,">",False) == False
	assert candidate(1, 2, ">", False) == False
	assert candidate(0,1,'<',False) == True
	assert candidate(1,0,">=",False) == True
	assert candidate(2,3,'<=',True) == True
	assert candidate(10,10,">",False) == False
	assert candidate(2, 1, '<', False) == False
	assert candidate(0,1,">=",True) == False
	assert candidate(10, 10, ">", False) == False
	assert candidate(2,1,'>=',True) == True
	assert candidate(5,10,">=",False) == False
	assert candidate(10,10,">=",True) == True
	assert candidate(2,2,">=",False) == True
	assert candidate(2,3,'<=',False) == True
	assert candidate(10,11,">",True) == False
	assert candidate(1, 2, ">=", False) == False
	assert candidate(2, 1, '<', True) == False
	assert candidate(10,10,"<=",False) == True
	assert candidate(10,11,">",False) == False
	assert candidate(10,10.1,">=",True) == False
	assert candidate(1,0,"<",False) == False
	assert candidate(5, 5, ">", True, default=True) == True
	assert candidate(1,2,'<',False) == True
	assert candidate(0,0,'<=',False) == True
	assert candidate(2,2,"<",True) == True
	assert candidate(2,1,"<=",False) == False
	assert candidate(0,0,'<',False) == False
	assert candidate(2,1,">=",True) == True
	assert candidate(10,5,">=",True) == True
	assert candidate(10,10.1,">",False) == False
	assert candidate(1,2,'>',False) == False
	assert candidate(10, 15, ">=", True) == False
	assert candidate(10,5,"<=",False,default=False) == False
	assert candidate(3, 3, '>=', True) == True
	assert candidate(5, 5, "<=", False, default=True) == True
	assert candidate(2,1,'>',True) == True
	assert candidate(10,5,"<",True) == False
	assert candidate(1, 2, '>=', True) == False
	assert candidate(1,0,"<",True) == False
	assert candidate(10,5,"<",False,default=False) == False
	assert candidate(3,4,">",True,default=True) == False
	assert candidate(10,10.1,"=",True) == False
	assert candidate(5, 5, ">=", False) == True
	assert candidate(2, 1, '<=', False) == False
	assert candidate(1,1,">",True) == True
	assert candidate(10, 5, ">", True) == True
	assert candidate(0,1,">=",False) == False
	assert candidate(2,3,'<',False) == True
	assert candidate(2,1,"<",True) == False
	assert candidate(1,2,'>',True) == False
	assert candidate(10, 10, "<=", False) == True
	assert candidate(2,2,'<=',True) == True
	assert candidate(1, 1, '>', False) == False
	assert candidate(0,1,'<',True) == True
	assert candidate(2,1,'<',True) == False
	assert candidate(10, 10, "<=", True) == True
	assert candidate(3,3,"<=",False) == True
	assert candidate(1, 1, '>', True) == True
	assert candidate(1,1,"<=",False) == True
	assert candidate(5, 5, '<=', False, default=True) == True
	assert candidate(5, 5, "<=", True) == True
	assert candidate(1,1,"<",False,default=False) == False
	assert candidate(3,3,"<",True) == True
	assert candidate(1, 2, "<", True) == True
	assert candidate(1, 1, '<=', False) == True
	assert candidate(3,3,">",False,default=True) == False
	assert candidate(3, 3, '<=', True) == True
	assert candidate(3,3,">",False) == False
	assert candidate(1, 2, "<=", True) == True
	assert candidate(1,2,"<",True) == True
	assert candidate(1,1,'>',False) == False
	assert candidate(1,1,"<=",False,default=True) == True
	assert candidate(2, 1, '<=', True) == False
	assert candidate(3,4,">",False,default=True) == False
	assert candidate(1, 1, "<", False) == False
	assert candidate(10,10,">=",False) == True
	assert candidate(2,1,">",False) == True
	assert candidate(5,10,"<",False) == True
	assert candidate(3,3,"<",False,default=True) == False
	assert candidate(1, 1, '>=', False) == True
	assert candidate(1, 1, ">=", True, default=True) == True
	assert candidate(3, 3, '<=', False) == True
	assert candidate(1,2,">",False) == False
	assert candidate(2,1,'<=',True) == False
	assert candidate(10,10,">",True) == True
	assert candidate(3,3,"<",False) == False
	assert candidate(10,11,">=",False) == False
	assert candidate(5, 10, '<', False, default=True) == True
	assert candidate(10,5,"<",False) == False
	assert candidate(10,10,"<",True,default=True) == True
	assert candidate(0,0,"<=",True) == True
	assert candidate(10,10.1,"<=",True) == True
	assert candidate(5, 5, ">", False) == False
	assert candidate(1, 1, '<', False) == False
	assert candidate(10,10,"<=",True) == True
	assert candidate(10,10,"<",True,default=False) == True
	assert candidate(10, 5, "<=", True) == False
	assert candidate(0,0,">=",True) == True
	assert candidate(5,5,"<=",True) == True
	assert candidate(5, 5, '>=', False, default=False) == True
	assert candidate(10, 10, ">=", False) == True
	assert candidate(10,10,"<",False) == False
	assert candidate(1,1,'<',False) == False
	assert candidate(2,1,'>',False) == True
	assert candidate(1,2,"=",True) == False
	assert candidate(1,2,"<=",False) == True
	assert candidate(3,2,'>',False) == True
	assert candidate(3,2,'>',True) == True
	assert candidate(3,4,"<",True,default=True) == True
	assert candidate(1,1,">",False,default=False) == False
	assert candidate(10,11,"=",False) == False
	assert candidate(5, 5, '>=', True, default=False) == True
	assert candidate(3,3,"<=",True) == True
	assert candidate(10,10.1,"=",False) == False
	assert candidate(3,4,"<",False) == True
	assert candidate(5,5,"<",True) == True
	assert candidate(5, 5, '<=', True, default=True) == True
	assert candidate(1,1,'>=',False) == True
	assert candidate(1,1,"=",False) == False
	assert candidate(2,2,"<=",False, default=True) == True
	assert candidate(10,10.1,">",True) == False
	assert candidate(0,1,"<",True) == True
	assert candidate(5, 5, '<=', True, default=False) == True
	assert candidate(10,5,">",False) == True
	assert candidate(1,0,">",True) == True
	assert candidate(1,1,"<",False) == False
	assert candidate(3, 3, '<', False) == False
	assert candidate(1, 2, "<", False) == True
	assert candidate(10, 5, "<", True) == False
	assert candidate(3,2,'<',True) == False
	assert candidate(1, 1, "<", True, default=True) == True
	assert candidate(0,0,"<",False) == False
	assert candidate(10,10,"<",True) == True
	assert candidate(1,1,"<",True) == True
	assert candidate(1,2,"<=",True) == True
	assert candidate(10,10.1,"<",True) == True
	assert candidate(10,5,">",True) == True
	assert candidate(0,1,"<",False) == True
	assert candidate(0,1,">",False) == False
	assert candidate(3,2,'>=',True) == True
	assert candidate(3, 3, '>=', False) == True
	assert candidate(5,10,">=",True) == False
	assert candidate(10,11,"=",True) == False
	assert candidate(2,2,"<=",True) == True
	assert candidate(1,1,'<=',False) == True
	assert candidate(1,1,">=",True) == True
	assert candidate(10,10,"<",False,default=False) == False
	assert candidate(2,2,">=",True) == True
	assert candidate(1,2,">=",True) == False
	assert candidate(1,1,"<=",True) == True
	assert candidate(2,2,'>',False) == False
	assert candidate(3,3,"<",False,default=False) == False
	assert candidate(1,1,"<=",False, default=True) == True
	assert candidate(2,2,'>=',False) == True
	assert candidate(5, 5, '>', True, default=True) == True
	assert candidate(5,5,">=",False) == True
	assert candidate(1,2,'<',True) == True
	assert candidate(1, 2, "<=", False) == True
	assert candidate(1,1,"<",True,default=True) == True
	assert candidate(5, 5, '>', False, default=True) == False
	assert candidate(2,1,'>=',False) == True
	assert candidate(10,10,"<",False,default=True) == False
	assert candidate(5, 5, '>=', True, default=True) == True
	assert candidate(5, 5, '<=', False, default=False) == True
	assert candidate(10,9,"<",False) == False
	assert candidate(2,2,'>=',True) == True
	assert candidate(1,1,">=",False, default=True) == True
	assert candidate(2,1,">",True) == True
	assert candidate(1,1,'<=',True) == True
	assert candidate(10,11,"<",False) == True
	assert candidate(1, 2, ">", True) == False
	assert candidate(5, 5, "<=", True, default=True) == True
	assert candidate(0,1,'>=',True) == False
	assert candidate(1,2,"<",False) == True
	assert candidate(5,10,"<=",False) == True
	assert candidate(10,5,"<=",True,default=True) == False
	assert candidate(2,2,"<",False) == False
	assert candidate(1,0,">=",True) == True
	assert candidate(5,5,">=",True) == True
	assert candidate(3,3,">=",True) == True
	assert candidate(1, 1, ">", False) == False
	assert candidate(1,1,"<=",False,default=False) == True
	assert candidate(10,10,"<=",True,default=True) == True
	assert candidate(10,5,">",True,default=False) == True
	assert candidate(3,3,"<=",True,default=True) == True
	assert candidate(1, 1, '<', True) == True
	assert candidate(3, 3, '>', False) == False
	assert candidate(1, 1, ">=", False, default=True) == True
	assert candidate(10,11,"<=",False) == True
	assert candidate(10, 10, ">=", True) == True
	assert candidate(1,1,'>=',True) == True
	assert candidate(5, 5, '>', False, default=False) == False
	assert candidate(2,1,'<=',False) == False
	assert candidate(0,1,'>',False) == False
	assert candidate(2,2,'<=',False) == True
	assert candidate(3,3,">=",True,default=True) == True
	assert candidate(10,5,">=",False) == True
	assert candidate(10,5,"<=",True,default=False) == False
	assert candidate(5, 5, "<=", False) == True
	assert candidate(1,2,'<=',False) == True
	assert candidate(1, 1, "<=", False, default=True) == True
	assert candidate(1,1,">=",False) == True
	assert candidate(3,5,">",True) == False
	assert candidate(1, 1, ">=", True) == True
	assert candidate(5,5,">",False) == False
	assert candidate(5, 5, "<", True, default=True) == True
	assert candidate(2,2,"<=",False) == True
	assert candidate(2,2,'<',False) == False
	assert candidate(1, 1, "<=", True) == True
	assert candidate(10,5,"<",True,default=False) == False
	assert candidate(5,5,"<",False) == False
	assert candidate(0,1,'<=',True) == True
	assert candidate(3,3,">",False,default=False) == False
	assert candidate(2,1,">=",False) == True
	assert candidate(1,1,">",False) == False
	assert candidate(2,3,'>',False) == False
	assert candidate(3,2,'>=',False) == True
	assert candidate(5,5,"<=",False) == True
	assert candidate(1,2,'>=',True) == False
	assert candidate(10,11,">=",True) == False
	assert candidate(3,4,"<",False,default=True) == True
	assert candidate(1,0,">",False) == True
	assert candidate(1,2,"=",False) == False
	assert candidate(10,10,"<=",True,default=False) == True
	assert candidate(0,1,'>',True) == False
	assert candidate(1, 1, '<=', True) == True
	assert candidate(0,1,"<=",False) == True
	assert candidate(1,0,"<=",True) == False
	assert candidate(0,1,">",True) == False
	assert candidate(1, 1, '>=', True) == True
	assert candidate(5, 5, ">=", True) == True
	assert candidate(3,2,'<=',True) == False
	assert candidate(1,0,"<=",False) == False
	assert candidate(1,1,">=",False,default=True) == True
	assert candidate(1, 2, '>', True) == False
	assert candidate(3, 5, '>', True) == False
	assert candidate(0,0,'>=',True) == True
	assert candidate(3,3,">=",False) == True
	assert candidate(1, 1, ">", True, default=True) == True
	assert candidate(5, 5, ">=", False, default=True) == True
	assert candidate(5,10,"<",True) == True
	assert candidate(1,1,">=",False,default=False) == True
	assert candidate(10,10.1,">=",False) == False
	assert candidate(5, 5, "<", False) == False
	assert candidate(2,1,'<',False) == False
	assert candidate(1,2,">",True) == False
	assert candidate(10, 15, ">", True) == False
	assert candidate(5,10,">",False) == False
	assert candidate(10.1,10,"<",True) == False
	assert candidate(3,4,">",False) == False
	assert candidate(2,1,"<",False) == False
	assert candidate(0,0,'>',False) == False
	assert candidate(5,2,"<",True) == False
	assert candidate(5, 5, ">=", True, default=True) == True
	assert candidate(1,1,"<",True,default=False) == True
	assert candidate(1,2,'>=',False) == False
	assert candidate(10,9,"=",False) == False
	assert candidate(10,5,"<=",True) == False
	assert candidate(10,5,"<=",False) == False
	assert candidate(10, 10, "<", False) == False
	assert candidate(1, 1, "<=", True, default=True) == True
	assert candidate(2,3,'>=',True) == False
	assert candidate(1,1,'<',True) == True
	assert candidate(2,1,"<=",True) == False
	assert candidate(2,2,">",False) == False
	assert candidate(0,1,"<=",True) == True
	assert candidate(0,0,'<=',True) == True
def test_check():
	check(compareThresh)
