def requires_parameters(*required_params):
    """
    Decorator function to check if required parameters are available in the context object
    :param required_params: parameters tuple
    :raises: RuntimeError if required parameter is not available
    """
    ### Canonical solution below ###
    assert isinstance(required_params, tuple)

    def check_parameter(func):
        def func_wrapper(self, input):
            missing_params = []
            if isinstance(input, dict) or (isinstance(input, str) and input.startswith("{")):
                for param in required_params:
                    if param not in input:
                        missing_params.append(param)
                if len(missing_params) > 0:
                    raise ValueError("Missing parameters: %s" % ", ".join(missing_params))
            return func(self, input)
        return func_wrapper
    return check_parameter


### Unit tests below ###
def check(candidate):
	assert candidate(1)(lambda x: x) is not None
	assert candidate(1, 2, 3)(lambda x, y, z: x + y + z)
	assert candidate(1, 2, 3)(lambda x: x)
	assert candidate(1, 2)(lambda a, b: None)
	assert candidate(1, 2)(lambda x, y: x + y)(3, 4) == 7
	assert candidate(1, 2, 3)(lambda x, y, z: x)
	assert candidate(1)(lambda x: x)
def test_check():
	check(requires_parameters)
