def remove_negative_sum(arr):
    """ 
     recursive funtion to find and remove starting sequence that yeilds negative
     value
     """
	### Canonical solution below ###    
    _sum = 0
    for idx, num in enumerate(arr):
        _sum += num
        if _sum < 0:
            return remove_negative_sum(arr[idx + 1:])
    return arr

### Unit tests below ###
def check(candidate):
	assert candidate(
    [-1, -2, -3, -4, -5, -6, -7, -8, -9, -10]) == []
	assert candidate(arr=[-1,2,3,4,5]) == [2,3,4,5]
	assert candidate(arr=[-5, -3, -2, -1, -5, -5, -5, 0]) == [0]
	assert candidate(arr=[-1, -2, -3, -4, -5, -6]) == []
	assert candidate([-1, -2, -3, -4, -5, -6]) == []
	assert candidate(list(range(10))) == list(range(10))
	assert candidate(arr=[1,2,3,4,5]) == [1,2,3,4,5]
	assert candidate(
    [-1, 2, 3, 4, 5, 6, 7, -8, 9, 10]) == [2, 3, 4, 5, 6, 7, -8, 9, 10]
	assert candidate([-1, 1]) == [1]
	assert candidate([-1, -2, -3, -4, -5]) == []
	assert candidate(arr=[1, 2, 3]) == [1, 2, 3]
	assert candidate(arr=[-1, -1, -1, -1]) == []
	assert candidate([1, 2, 3, 1, 2, 3]) == [1, 2, 3, 1, 2, 3]
	assert candidate(arr=[-1]) == []
	assert candidate(arr=[-1, 2, 3, 4, 5]) == [2, 3, 4, 5]
	assert candidate(
    [-1, -2, -3, -4, -5, 6, 7, -8, 9, 10]) == [6, 7, -8, 9, 10]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(arr=[-1, -2, -3, -4, -5]) == []
	assert candidate(arr=[-1,-2,-3,-4,5]) == [5]
	assert candidate([1]) == [1]
	assert candidate([-1, 2, 3]) == [2, 3]
	assert candidate([]) == []
	assert candidate(arr=[]) == []
	assert candidate([1, -2, 3, 4, 5]) == [3, 4, 5]
	assert candidate(arr=[-5, -4, -3, -2, -1]) == []
	assert candidate(arr=[-4, -3, -2, -1, 4, 3, 2]) == [4, 3, 2]
	assert candidate(arr=[1]) == [1]
	assert candidate(
    [3, 4, 7, 8, 9, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6]
    ) == [3, 4, 7, 8, 9, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6]
	assert candidate(arr=[-5, -3, -2, -1, -5, -5, -5, 0, 0]) == [0, 0]
	assert candidate([-5, -4, -3, -2, -1]) == []
	assert candidate([-1, 1, 1, -1, 1]) == [1, 1, -1, 1]
	assert candidate([1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(arr=[1, 2]) == [1, 2]
	assert candidate(
    [1, 2, 3, -4, 5]) == [1, 2, 3, -4, 5], "All positive"
	assert candidate(arr=[-5, -5, 10]) == [10]
	assert candidate(arr=[-1,-2,-3,-4,-5]) == []
	assert candidate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate(arr=[-5, -3, -2, -1, 0, 1, 2]) == [0, 1, 2]
	assert candidate(arr=[-5, -3, -2, -1, 0, 1]) == [0, 1]
	assert candidate([-1, -2, -3, -4, -5, -6, -7]) == []
	assert candidate(arr=[1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([-1, -2, -3]) == []
def test_check():
	check(remove_negative_sum)
