def class_size(cls):
    """Get the number of bytes per element for a given data type.

    Parameters:
    cls (str): Name of the data type

    Returns:
    int: Number of byte per element

   """
    ### Canonical solution below ###

    if cls in ['float64', 'int64', 'uint64']:
        n_byte = 8
    elif cls in ['float32', 'int32', 'uint32']:
        n_byte = 4
    elif cls in ['bool', 'str', 'int8', 'uint8']:
        n_byte = 1
    else:
        raise TypeError('invalid data type')

    return n_byte


### Unit tests below ###
def check(candidate):
	assert candidate('bool') == 1
	assert candidate(cls='uint8') == 1
	assert candidate('int32') == 4
	assert candidate(cls='uint32') == 4
	assert candidate('int64') == 8
	assert candidate('str') == 1
	assert candidate('int8') == 1
	assert candidate('float64') == 8
	assert candidate(cls='float64') == 8
	assert candidate(cls='int64') == 8
	assert candidate(cls='bool') == 1
	assert candidate(cls='str') == 1
	assert candidate('uint64') == 8
	assert candidate(cls='float32') == 4
	assert candidate('float32') == 4
	assert candidate(cls='int8') == 1
	assert candidate(cls='uint64') == 8
	assert candidate('uint8') == 1
	assert candidate('uint32') == 4
	assert candidate(cls='int32') == 4
def test_check():
	check(class_size)
