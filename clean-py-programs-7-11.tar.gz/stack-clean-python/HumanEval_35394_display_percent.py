def display_percent(chunk_size, chunk_percent, last_percent, progress):
    
    """
    Used to monitor progress of a process. Example useage:
        
        Progress = 0
        chunk_percent = 10.0
        chunk_size = int(math.ceil(all_files*(chunk_percent/100)))
        
        for x in all_files:
            Progress += 1 
            last_percent = display_percent(chunk_size, chunk_percent, last_percent, Progress)
    """
    ### Canonical solution below ###
    
    percent = int(progress / chunk_size)
    
    if percent > last_percent:
        print("{0}%".format(percent * chunk_percent))
        
    return percent


### Unit tests below ###
def check(candidate):
	assert candidate(10, 10, 0, 0) == 0
	assert candidate(10, 10, 0, 10) == 1
	assert candidate(2, 10, 0, 0) == 0
	assert candidate(100, 10, 0, 0) == 0
	assert candidate(100, 10, -1, 9) == 0
def test_check():
	check(display_percent)
