def decorator(expr):
    """Function returning decorator."""
    ### Canonical solution below ###
    def func(function):
        """Pass-thru decorator."""
        return function
    # use expr
    expr(0)
    return func


### Unit tests below ###
def check(candidate):
	assert candidate(lambda n: n * 2)(lambda x: x + 1)(0) == 1
	assert candidate(lambda x: x)(4) == 4
	assert candidate(lambda x: x)(2) == 2
	assert candidate(lambda x: x)(5) == 5
	assert candidate(lambda x: x)(0) == 0
	assert candidate(lambda x: x+1)(10) == 10
	assert candidate(lambda x: x)(10) == 10
	assert candidate(lambda x: None)(lambda x: None) is not None
	assert candidate(lambda x: x)
	assert candidate(lambda x: x)(1) == 1
	assert candidate(lambda x: 0)(lambda x: 0)(0) == 0
	assert candidate(lambda x: x)(3) == 3
	assert candidate(lambda x: x)(lambda x: x)(5) == 5
	assert candidate(lambda x: x+1)
def test_check():
	check(decorator)
