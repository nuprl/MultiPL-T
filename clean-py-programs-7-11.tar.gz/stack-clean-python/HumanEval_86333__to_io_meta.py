def _to_io_meta(shape_meta, valid_keys, key_mappings):
    """ 
     Make metadata compatible with a specific IO by filtering and mapping
     to its valid keys.
     
     Parameters
     ----------
     shape_meta : dict
     A meta attribute of a `regions.Region` object.
     
     valid_keys : list
     The valid keys of a particular file format.
     
     key_mappings : dict
     A dictionary mapping of the actual name of the key in the
     format.
     
     Returns
     -------
     meta : dict
     An IO compatible meta dictionary according to ``valid_keys`` and
     ``key_mappings``.
     """
	### Canonical solution below ###    
    meta = dict()

    for key in shape_meta:
        if key in valid_keys:
            meta[key_mappings.get(key, key)] = shape_meta[key]

    return meta

### Unit tests below ###
def check(candidate):
	assert candidate(dict(a=1, b=2, c=3), ['a', 'b'], {'b': 'b'}) == dict(a=1, b=2)
	assert candidate(dict(name='test'), ['name', 'test'], {}) == dict(name='test')
	assert candidate(dict(name='test'), ['name'], dict()) == dict(name='test')
	assert candidate(
    shape_meta={'name': 'foo','meta': {'bar': 'baz'}},
    valid_keys=['name','meta'],
    key_mappings={'name': 'title','meta':'meta'}) == {'title': 'foo','meta': {'bar': 'baz'}}
	assert candidate(
    shape_meta={'name': 'foo','meta': {'bar': 'baz'}},
    valid_keys=['name','meta'],
    key_mappings={'name': 'title','meta': 'foo'}) == {'title': 'foo', 'foo': {'bar': 'baz'}}
	assert candidate(dict(foo=1, bar=2), ['foo', 'bar'], dict(foo='hello')) == dict(hello=1, bar=2)
	assert candidate(dict(name='test', meta=dict(a=1, b=2)), ['name'], dict()) == dict(name='test')
	assert candidate(
    shape_meta={'name': 'foo','meta': {'bar': 'baz'}},
    valid_keys=['name','meta'],
    key_mappings={'name': 'title'}) == {'title': 'foo','meta': {'bar': 'baz'}}
	assert candidate(dict(name='test'), ['name'], dict(name='test2')) == dict(test2='test')
	assert candidate(dict(
    some_key='some_value',
    other_key='other_value',
    another_key='another_value',
), ['some_key', 'other_key'], dict(some_key='some_key')) == \
    dict(some_key='some_value', other_key='other_value')
	assert candidate(dict(name='test', other='test'), ['name'], dict(name='other')) == dict(other='test')
	assert candidate(dict(a=1, b=2), ['a', 'b'], dict()) == dict(a=1, b=2)
	assert candidate(
    shape_meta={'name': 'foo','meta': {'bar': 'baz'}},
    valid_keys=['name'],
    key_mappings={'name': 'title'}) == {'title': 'foo'}
	assert candidate(dict(foo=1, bar=2), ['foo'], dict()) == dict(foo=1)
	assert candidate(dict(a=1, b=2, c=3), ['a', 'b'], dict()) == dict(a=1, b=2)
	assert candidate(dict(color='red', width=3), ['color'], dict()) == \
    {'color':'red'}
	assert candidate(dict(), ['a', 'b'], dict()) == dict()
	assert candidate(dict(a=1, b=2, c=3), ['a', 'b'], {'b': 'bb'}) == dict(a=1, bb=2)
	assert candidate(dict(name='test', comments=['comment']), ['name'],
                   dict()) == dict(name='test')
	assert candidate(dict(color='red'), ['color', 'name'], dict()) == \
    dict(color='red')
	assert candidate(
    {'comment': 'A test comment',
     'name': 'Test Region',
     'color': 'green',
    'meta1': 1,
    'meta2': 2},
    ['comment', 'name', 'color'],
    {'name': 'title'}
) == {'comment': 'A test comment',
     'title': 'Test Region',
     'color': 'green'}
	assert candidate(dict(name='test'), ['name'], {'name': 'name'}) == \
    dict(name='test')
	assert candidate(dict(
    some_key='some_value',
    other_key='other_value',
    another_key='another_value',
), ['some_key', 'other_key'], dict(other_key='other_key')) == \
    dict(some_key='some_value', other_key='other_value')
	assert candidate(dict(name='test'), ['name', 'test'], dict(name='test2')) == dict(test2='test')
	assert candidate(dict(label='test', meta=dict(color='red')), ['label'], dict()) == dict(label='test')
	assert candidate(dict(
    some_key='some_value',
    other_key='other_value',
    another_key='another_value',
), ['some_key'], dict()) == dict(some_key='some_value')
	assert candidate(dict(color='red', label='test'),
                   ['color', 'label'],
                   {'color': 'Color', 'label': 'Label'}) == \
    dict(Color='red', Label='test')
	assert candidate(dict(color='red', name='test'), ['color', 'name'], dict()) == \
    dict(color='red', name='test')
	assert candidate(dict(), ['a', 'b'], {'a': 'A'}) == dict()
	assert candidate(dict(color='blue'), ['color'], {}) == dict(color='blue')
	assert candidate(dict(c="a", d="b"), ["a", "b", "c", "d"],
                   dict(c="a", d="d")) == dict(a="a", d="b")
	assert candidate(dict(name='test'), ['name'], {'name': 'NAME'}) == dict(NAME='test')
	assert candidate(dict(name='a', comment='b'), ['name'], dict()) == dict(name='a')
	assert candidate(dict(label='test', color='red'), ['label'], dict()) == dict(label='test')
	assert candidate(dict(color='blue'),
                   ['coordsys', 'color'],
                   dict(color='fillcolor')) == dict(fillcolor='blue')
	assert candidate(dict(name='Test', a=1),
                   ['name'],
                   dict(name='NAME')) == dict(NAME='Test')
	assert candidate(dict(a=1, b=2, c=3), ['a', 'b'], dict(b='B')) == dict(a=1, B=2)
	assert candidate(
    shape_meta={'name': 'foo','meta': {'bar': 'baz'}},
    valid_keys=['name','meta'],
    key_mappings={'name': 'title','meta': 'bar'}) == {'title': 'foo', 'bar': {'bar': 'baz'}}
	assert candidate(dict(name='test'), ['name'], dict(name='other')) == dict(other='test')
	assert candidate(dict(name='a', comment='b'), ['name', 'comment'], dict()) == dict(name='a', comment='b')
	assert candidate(dict(c="a", d="b"), ["a", "b", "c", "d"],
                   dict(c="a", d="b")) == dict(a="a", b="b")
	assert candidate(dict(name='a', comment='b'), ['name', 'comment'], dict(name='NAME')) == dict(NAME='a', comment='b')
	assert candidate(dict(name='Test', a=1),
                   ['name', 'a'],
                   dict(name='NAME', a='A')) == dict(NAME='Test', A=1)
	assert candidate(dict(meta_a=1, meta_b=2, meta_c=3),
                   ['meta_a','meta_b'],
                   dict(meta_a='a', meta_b='b', meta_c='c')) == {'a': 1, 'b': 2}
	assert candidate(
    dict(
        a='b',
        c='d',
    ),
    ['a', 'c'],
    dict(
        a='A',
        b='B',
        c='C',
    )
) == dict(
    A='b',
    C='d',
)
	assert candidate(dict(name='test'), ['name'], {'name': 'new_name'}) == \
    dict(new_name='test')
	assert candidate(dict(foo=1, bar=2), ['foo', 'bar'], dict(foo='hello', bar='world')) == dict(hello=1, world=2)
	assert candidate(dict(name='Test', a=1),
                   ['name', 'a'],
                   dict(name='NAME')) == dict(NAME='Test', a=1)
	assert candidate(
    dict(
        a='b',
        c='d',
    ),
    ['a', 'c'],
    dict(
        a='A',
        c='C',
    )
) == dict(
    A='b',
    C='d',
)
	assert candidate(dict(color='red'), ['color'], dict()) == {'color':'red'}
	assert candidate(dict(a=1, b=2, c=3), ['a', 'b'], {'b': 'c'}) == dict(a=1, c=2)
	assert candidate(dict(comment='a comment', group_id='1234'),
                   ['comment', 'group_id'],
                   dict(comment='comment', group_id='id')) == dict(comment='a comment', id='1234')
	assert candidate(
    dict(
        a='b',
        c='d',
    ),
    ['c', 'a'],
    dict(
        a='A',
        c='C',
    )
) == dict(
    C='d',
    A='b',
)
	assert candidate(dict(a=1, b=2), ['a', 'b'], {'b': 'c'}) == dict(a=1, c=2)
	assert candidate(dict(foo=1, bar=2), ['foo', 'bar'], dict()) == dict(foo=1, bar=2)
	assert candidate(dict(name='test'), ['name'], {}) == dict(name='test')
	assert candidate(dict(name='Test', a=1),
                   ['name', 'a'],
                   dict(a='A', name='NAME')) == dict(NAME='Test', A=1)
	assert candidate(dict(color='blue'), ['color'], {'color': 'colour'}) == dict(colour='blue')
	assert candidate(dict(
    some_key='some_value',
    other_key='other_value',
    another_key='another_value',
), ['some_key', 'other_key'], dict(other_key='other_key', some_key='some_key')) == \
    dict(some_key='some_value', other_key='other_value')
	assert candidate(dict(label='test'), ['label'], dict()) == dict(label='test')
	assert candidate(dict(a=1, b=2, c=3), ['a', 'b'], {'a': 'A'}) == dict(A=1, b=2)
	assert candidate(dict(name='test', color='blue'), ['name'], {'name': 'NAME'}) == dict(NAME='test')
	assert candidate(dict(name='Test', a=1),
                   ['name', 'a'],
                   dict(a='A')) == dict(name='Test', A=1)
	assert candidate(dict(name='test'), ['name'], {'name': 'NAME', 'color': 'COLOR'}) == dict(NAME='test')
	assert candidate(dict(meta_a=1, meta_b=2, meta_c=3),
                   ['meta_a','meta_b'],
                   dict(meta_a='a', meta_b='b')) == {'a': 1, 'b': 2}
def test_check():
	check(_to_io_meta)
