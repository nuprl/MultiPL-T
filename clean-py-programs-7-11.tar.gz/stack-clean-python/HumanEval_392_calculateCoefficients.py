def calculateCoefficients( c1=0, 
                           c2=0, 
                           c3=0, 
                           c4=0,
                           r2=0,
                           r3=0,
                           r4=0,
                           flt_type='passive'):
    """ return loop filter coeffiencients as list
    a[0] = a0, a[1] = a1, etc.
    """
    ### Canonical solution below ###
    a = []
    if flt_type == 'passive':
        a.append( c1 + c2 + c3 + c4 )
        a.append( c2*r2*(c1 + c3 + c4) + r3*(c1 + c2)*(c3 + c4) +\
                  c4*r4*(c1 + c2 + c3) )
        a.append( c1*c2*r2*r3*(c3 + c4) +\
                  c4*r4*(c2*c3*r3 + c1*c3*r3 + c1*c2*r2 + c2*c3*r2) )
    else:
        a.append(c1 + c2)
        a.append( (c1*c2*r2) + (c1 + c2) * (c3*r3 + c4*r4 + c4*r3) )
        a.append( c3*c4*r3*r4 * (c1 + c2) + c1*c2*r2*(c3*r3 + c4*r4 + c4*r3) )
    a.append(c1*c2*c3*c4*r2*r3*r4)
    return a


### Unit tests below ###
def check(candidate):
	assert candidate( 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0) == [1.0, 0.0, 0.0, 0.0]
	assert candidate(1,0,0,0) == [1,0,0,0]
	assert candidate(1,0,0,0,0,0,0,'passive') == [1, 0, 0, 0]
	assert candidate( 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 'active') == [1.0, 0.0, 0.0, 0.0]
	assert candidate(1,0,0,0,0,0,0,'active') == [1, 0, 0, 0]
	assert candidate( c1=0, c2=0, c3=0, c4=0, r2=0, r3=0, r4=0, flt_type='active') == [0, 0, 0, 0]
	assert candidate(0,0,0,0,0,0,0, 'passive') == [0,0,0,0]
	assert candidate( 1.0, 0.0, 0.0, 0.0, 0.0, 0.0) == [1.0, 0.0, 0.0, 0.0]
	assert candidate(0,0,0,0) == [0,0,0,0]
	assert candidate(0,0,0,0,1,0,0,'active') == [0, 0, 0, 0]
	assert candidate(0,0,0,0,0,0,0,'passive') == [0, 0, 0, 0]
	assert candidate(1, 0, 0, 0) == [1, 0, 0, 0]
	assert candidate( 1.0, 0.0, 0.0, 0.0, 0.0) == [1.0, 0.0, 0.0, 0.0]
	assert candidate(0,0,1,0,0,0,0) == [1.0, 0.0, 0.0, 0.0]
	assert candidate(c1=0, c2=0, c3=0, c4=0, r2=0, r3=0, r4=0) == [0, 0, 0, 0], "candidate: 0,0,0,0,0,0,0"
	assert candidate(c1=0, c2=0, c3=0, c4=0, r2=0, r3=0, r4=0, flt_type='passive') == [0, 0, 0, 0]
	assert candidate(c1=0,c2=0,c3=0,c4=0,r2=0,r3=0,r4=0) == [0,0,0,0], \
        "Failed test for candidate"
	assert candidate( 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 'passive') == [1.0, 0.0, 0.0, 0.0]
	assert candidate(0,0,0,0,1,0,0,'passive') == [0, 0, 0, 0]
	assert candidate(0,0,0,1,0,0,0) == [1.0, 0.0, 0.0, 0.0]
	assert candidate(0,1,0,0,0,0,0) == [1.0, 0.0, 0.0, 0.0]
	assert candidate(c1=1, c2=0, c3=0, c4=0, r2=0, r3=0, r4=0, flt_type='passive') == [1, 0, 0, 0]
	assert candidate(0,0,0,0,0,0,0) == [0, 0, 0, 0]
	assert candidate(1,0,0,0,0,0,0) == [1.0, 0.0, 0.0, 0.0]
	assert candidate( 1.0, 0.0, 0.0, 0.0) == [1.0, 0.0, 0.0, 0.0]
def test_check():
	check(calculateCoefficients)
