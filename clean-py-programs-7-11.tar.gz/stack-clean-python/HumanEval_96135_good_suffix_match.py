def good_suffix_match(small_l_prime):
    """ Given a full match of P to T, return amount to shift as
     determined by good suffix rule. """
	### Canonical solution below ###    
    return len(small_l_prime) - small_l_prime[1]

### Unit tests below ###
def check(candidate):
	assert candidate( ('AB', 2) ) == 0
	assert candidate( ('ABA', 1) ) == 1
	assert candidate( ('A', 2) ) == 0
	assert candidate( ('ABA', 2) ) == 0
	assert candidate( ('AA', 2) ) == 0
	assert candidate( ('AA', 1) ) == 1
	assert candidate( ('ABA', 0) ) == 2
	assert candidate( ('ABAB', 0) ) == 2
	assert candidate( ('AB', 1) ) == 1
	assert candidate( ('B', 2) ) == 0
def test_check():
	check(good_suffix_match)
