def mean(numbers):
    """Find the mean using an iterable of numbers
    Return None if the iterable is empty
    """
    ### Canonical solution below ###
    if not numbers:
        return None
    total = 0
    count = 0
    for number in numbers:
        total += number
        count += 1
    return total / count


### Unit tests below ###
def check(candidate):
	assert candidate(range(100)) == 49.5
	assert candidate([1, 5]) == 3
	assert candidate([1, 3, 5]) == 3
	assert candidate(range(1, 11)) == 5.5
	assert candidate([1, 2, 3, 4, 5]) == 3
	assert candidate(range(1, 8)) == 4.0
	assert candidate([1, 2, 3]) == 2.0
	assert candidate(range(10)) == 4.5
	assert candidate( [1, 2, 3, 4] ) == 2.5
	assert candidate([1, 3]) == 2
	assert candidate( [] ) == None
	assert candidate(range(1, 6)) == 3.0
	assert candidate( [1] ) == 1
	assert candidate(range(1, 101)) == 50.5
	assert candidate(iter([1, 2, 3, 4, 5])) == 3
	assert candidate(range(1, 5)) == 2.5
	assert candidate(range(1, 7)) == 3.5
	assert candidate([1, 3, 5, 7]) == 4
	assert candidate([1, 2, 3]) == 2
	assert candidate([]) == None
	assert candidate(None) is None
	assert candidate( [1, 2, 3, 4, 5] ) == 3
	assert candidate( [1, 2, 3] ) == 2
	assert candidate([]) is None
	assert candidate(range(1, 1001)) == 500.5
	assert candidate([1, 2, 3, 4]) == 2.5
	assert candidate( [1, 2] ) == 1.5
def test_check():
	check(mean)
