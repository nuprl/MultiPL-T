def get_transitions(sequence):
    """ 
     Extracts a list of transitions from a sequence, returning a list of lists containing each transition.
     
     Example
     --------
     >>> sequence = [1,2,2,1,2,3,2,3,1]
     >>> ps.get_transitions(sequence)
     [[1, 2], [2, 1], [1, 2], [2, 3], [3, 2], [2, 3], [3, 1]]
     
     """
	### Canonical solution below ###	

	transitions = []
	for position in range(len(sequence) - 1):
		if sequence[position] != sequence[position + 1]:
			transitions.append([sequence[position], sequence[position + 1]])

	return transitions

### Unit tests below ###
def check(candidate):
	assert candidate(sequence=[1,1,2,3,4,5,6,7,8,9]) == [[1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8], [8, 9]]
	assert candidate([1,2,3,4,1,2,3,4,1,2,3,4]) == [[1, 2], [2, 3], [3, 4], [4, 1], [1, 2], [2, 3], [3, 4], [4, 1], [1, 2], [2, 3], [3, 4]]
	assert candidate(sequence=[1,1,1,1,1,1,1,1,1,1]) == []
	assert candidate(sequence=[1,2,3,4,5,6,7,8,9]) == [[1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8], [8, 9]]
	assert candidate(sequence=[1, 2, 2, 1, 2, 3, 2, 3, 1]) == [[1, 2], [2, 1], [1, 2], [2, 3], [3, 2], [2, 3], [3, 1]]
	assert candidate(
	[1, 1, 1, 1, 1, 1, 1, 1, 1]) == []
	assert candidate([1, 2, 3]) == [[1, 2], [2, 3]]
	assert candidate(sequence=[1,2,3,2,1]) == [[1,2], [2,3], [3,2], [2,1]]
	assert candidate(sequence=[1,2,2,1,2,3,2,3,1]) == [[1, 2], [2, 1], [1, 2], [2, 3], [3, 2], [2, 3], [3, 1]]
	assert candidate([1,2,2,1,2,3,2,3,1]) == [[1, 2], [2, 1], [1, 2], [2, 3], [3, 2], [2, 3], [3, 1]]
	assert candidate([1, 2, 3, 4, 5, 6]) == [[1, 2], [2, 3], [3, 4], [4, 5], [5, 6]]
	assert candidate([1, 2, 3, 4]) == [[1, 2], [2, 3], [3, 4]]
	assert candidate(
	[1, 2, 2, 1, 2, 3, 2, 3, 1]) == [[1, 2], [2, 1], [1, 2], [2, 3], [3, 2], [2, 3], [3, 1]]
	assert candidate(sequence = [1,2,2,1,2,3,2,3,1]) == [[1, 2], [2, 1], [1, 2], [2, 3], [3, 2], [2, 3], [3, 1]]
	assert candidate(sequence=[1,2,1,2,3,4,5,6,7,8,9]) == [[1, 2], [2, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8], [8, 9]]
	assert candidate([1, 2, 3, 4, 5]) == [[1, 2], [2, 3], [3, 4], [4, 5]]
	assert candidate(sequence=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [[1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8], [8, 9], [9, 10]]
	assert candidate(list(range(10))) == [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8], [8, 9]]
	assert candidate(sequence=[1,2,1,2,1,2,1,2,1,2]) == [[1, 2], [2, 1], [1, 2], [2, 1], [1, 2], [2, 1], [1, 2], [2, 1], [1, 2]]
	assert candidate(sequence=[1,2,3,4,5,6,7,8,9,10]) == [[1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8], [8, 9], [9, 10]]
def test_check():
	check(get_transitions)
