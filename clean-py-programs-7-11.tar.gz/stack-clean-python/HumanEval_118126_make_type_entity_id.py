def make_type_entity_id(type_id=None, entity_id=None):
    """ 
     Assemble a type_id and entity_id and return a composite identifier.
     
     If the entity Id is blank, ignore the supplied type id
     
     >>> make_type_entity_id(type_id="type_id", entity_id="entity_id") == "type_id/entity_id"
     True
     >>> make_type_entity_id(type_id="type_id", entity_id="") == ""
     True
     """
	### Canonical solution below ###    
    assert type_id is not None,   "make_type_entity_id: no type id (%s, %s)"%(type_id, entity_id)
    assert entity_id is not None, "make_type_entity_id: no entity id (%s, %s)"%(type_id, entity_id)
    if entity_id != "":
        return type_id + "/" + entity_id
    return ""

### Unit tests below ###
def check(candidate):
	assert candidate(type_id="type_id", entity_id="") == ""
	assert candidate(type_id="type_id", entity_id=" ") == "type_id/ "
	assert candidate(type_id="type_id", entity_id="entity_id") == "type_id/entity_id"
	assert candidate(type_id="type_id", entity_id="  ") == "type_id/  "
	assert candidate(type_id="", entity_id="") == ""
def test_check():
	check(make_type_entity_id)
