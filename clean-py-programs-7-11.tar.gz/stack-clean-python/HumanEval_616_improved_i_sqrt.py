def improved_i_sqrt(n):
    """ taken from 
     http://stackoverflow.com/questions/15390807/integer-square-root-in-python 
     Thanks, mathmandan """
	### Canonical solution below ###    
    assert n >= 0
    if n == 0:
        return 0
    i = n.bit_length() >> 1    # i = floor( (1 + floor(log_2(n))) / 2 )
    m = 1 << i    # m = 2^i
    #
    # Fact: (2^(i + 1))^2 > n, so m has at least as many bits
    # as the floor of the square root of n.
    #
    # Proof: (2^(i+1))^2 = 2^(2i + 2) >= 2^(floor(log_2(n)) + 2)
    # >= 2^(ceil(log_2(n) + 1) >= 2^(log_2(n) + 1) > 2^(log_2(n)) = n. QED.
    #
    while (m << i) > n: # (m<<i) = m*(2^i) = m*m
        m >>= 1
        i -= 1
    d = n - (m << i) # d = n-m^2
    for k in range(i-1, -1, -1):
        j = 1 << k
        new_diff = d - (((m<<1) | j) << k) # n-(m+2^k)^2 = n-m^2-2*m*2^k-2^(2k)
        if new_diff >= 0:
            d = new_diff
            m |= j
    return m

### Unit tests below ###
def check(candidate):
	assert candidate(8) == 2
	assert candidate(34) == 5
	assert candidate(18) == 4
	assert candidate(10) == 3
	assert candidate(13) == 3
	assert candidate(2) == 1
	assert candidate(15) == 3
	assert candidate(26) == 5
	assert candidate(33) == 5
	assert candidate(11) == 3
	assert candidate(1) == 1
	assert candidate(6) == 2
	assert candidate(0) == 0
	assert candidate(16) == 4
	assert candidate(4) == 2
	assert candidate(102) == 10
	assert candidate(32) == 5
	assert candidate(28) == 5
	assert candidate(22) == 4
	assert candidate(35) == 5
	assert candidate(20) == 4
	assert candidate(14) == 3
	assert candidate(100) == 10
	assert candidate(21) == 4
	assert candidate(9) == 3
	assert candidate(27) == 5
	assert candidate(5) == 2
	assert candidate(30) == 5
	assert candidate(31) == 5
	assert candidate(25) == 5
	assert candidate(1024) == 32
	assert candidate(12) == 3
	assert candidate(3) == 1
	assert candidate(23) == 4
	assert candidate(30)
	assert candidate(19) == 4
	assert candidate(101) == 10
	assert candidate(24) == 4
	assert candidate(7) == 2
	assert candidate(17) == 4
	assert candidate(29) == 5
def test_check():
	check(improved_i_sqrt)
