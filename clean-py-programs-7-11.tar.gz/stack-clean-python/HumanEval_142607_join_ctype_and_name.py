def join_ctype_and_name(ctype, name):
    """
    Utility method that joins a C type and a variable name into
    a single string

    >>> join_ctype_and_name('void*', 'foo')
    'void *foo'
    >>> join_ctype_and_name('void *', 'foo')
    'void *foo'
    >>> join_ctype_and_name("void**", "foo")
    'void **foo'
    >>> join_ctype_and_name("void **", "foo")
    'void **foo'
    >>> join_ctype_and_name('C*', 'foo')
    'C *foo'
    """
    ### Canonical solution below ###
    if ctype[-1] == '*':
        for i in range(-1, -len(ctype) - 1, -1):
            if ctype[i] != '*':
                if ctype[i] == ' ':
                    return "".join([ctype[:i+1], ctype[i+1:], name])
                else:
                    return "".join([ctype[:i+1], ' ', ctype[i+1:], name])
        raise ValueError((ctype, name))
    else:
        return " ".join([ctype, name])


### Unit tests below ###
def check(candidate):
	assert candidate( "C**", "foo") == "C **foo"
	assert candidate("void**", "a") == "void **a"
	assert candidate("C *", "foo ***") == "C *foo ***"
	assert candidate(
    "C*", "foo") == "C *foo"
	assert candidate("void *", "foo ***") == "void *foo ***"
	assert candidate('foo bar','baz foo') == 'foo bar baz foo'
	assert candidate( 'C *', 'foo') == 'C *foo'
	assert candidate('C*', 'foo') == 'C *foo'
	assert candidate(
    'C*',
    'foo',
) == 'C *foo'
	assert candidate( "void*", "foo") == "void *foo"
	assert candidate(ctype="void**", name="foo") == 'void **foo'
	assert candidate("C *", "foo * *") == "C *foo * *"
	assert candidate(
    "void **", "foo") == 'void **foo'
	assert candidate('void*', 'a') == 'void *a'
	assert candidate("void *", "foo") == "void *foo"
	assert candidate("void*", "foo") == "void *foo"
	assert candidate("void **", "foo") == "void **foo"
	assert candidate('C *', 'foo * bar') == 'C *foo * bar'
	assert candidate("void**", "foo") == 'void **foo'
	assert candidate('C*', 'foo * bar') == 'C *foo * bar'
	assert candidate('foo bar baz', 'foo bar baz') == 'foo bar baz foo bar baz'
	assert candidate( "C *", "foo") == "C *foo"
	assert candidate(ctype='void **', name='foo bar') == 'void **foo bar'
	assert candidate('int *', 'foo') == 'int *foo'
	assert candidate('void', 'foo') == 'void foo'
	assert candidate("void", "foo") == "void foo"
	assert candidate('a', 'b') == 'a b'
	assert candidate(ctype='C *', name='foo') == 'C *foo'
	assert candidate('foo bar','baz foo bar') == 'foo bar baz foo bar'
	assert candidate("void *", "foo * *") == "void *foo * *"
	assert candidate( "C*", "foo") == "C *foo"
	assert candidate( 'void *', 'foo') == 'void *foo'
	assert candidate(
    "void*", "foo") == "void *foo"
	assert candidate(
    "void **", "foo") == "void **foo"
	assert candidate('foo','bar') == 'foo bar'
	assert candidate("void**", "foo") == "void **foo"
	assert candidate('C*', 'foo *bar') == 'C *foo *bar'
	assert candidate('int', 'foo') == 'int foo'
	assert candidate('int * *', 'foo') == 'int * *foo'
	assert candidate("void **", "a") == "void **a"
	assert candidate(
    'void *', 'foo') == 'void *foo'
	assert candidate('C *', 'foo *bar') == 'C *foo *bar'
	assert candidate(
    'C*', 'foo') == 'C *foo'
	assert candidate("C*", "foo") == "C *foo"
	assert candidate("void *", "foo **") == "void *foo **"
	assert candidate(ctype='void *', name='foo') == 'void *foo'
	assert candidate("void **", "foo") == 'void **foo'
	assert candidate(ctype="void **", name="foo") == 'void **foo'
	assert candidate('foo bar', 'baz') == 'foo bar baz'
	assert candidate(ctype='C*', name='foo') == 'C *foo'
	assert candidate(ctype='void', name='foo') == 'void foo'
	assert candidate(ctype='void *', name='foo bar') == 'void *foo bar'
	assert candidate(
    "void**", "foo") == "void **foo"
	assert candidate('void *', 'a') == 'void *a'
	assert candidate('int**', 'foo') == 'int **foo'
	assert candidate(ctype='C *', name='foo bar') == 'C *foo bar'
	assert candidate('int * * *', 'foo') == 'int * * *foo'
	assert candidate(
    'void*', 'foo') == 'void *foo'
	assert candidate('foo bar','baz') == 'foo bar baz'
	assert candidate("void *", "foo *") == "void *foo *"
	assert candidate(
    "void **",
    "foo",
) == 'void **foo'
	assert candidate( "void", "foo") == "void foo"
	assert candidate("C *", "foo **") == "C *foo **"
	assert candidate("C *", "foo *") == "C *foo *"
	assert candidate('foo', 'bar') == 'foo bar'
	assert candidate("C *", "foo") == "C *foo"
	assert candidate('void', 'foo bar') == 'void foo bar'
	assert candidate(
    'void*',
    'foo',
) == 'void *foo'
	assert candidate(ctype='void **', name='foo') == 'void **foo'
	assert candidate(
    "void**", "foo") == 'void **foo'
	assert candidate(ctype='void', name='foo bar') == 'void foo bar'
	assert candidate('C*', 'a') == 'C *a'
	assert candidate('void*', 'foo') == 'void *foo'
	assert candidate(
    "void *", "foo") == "void *foo"
	assert candidate(ctype='void*', name='foo') == 'void *foo'
	assert candidate('void', 'a') == 'void a'
	assert candidate( "C **", "foo") == "C **foo"
	assert candidate('void *', 'foo') == 'void *foo'
	assert candidate('int * * * *', 'foo') == 'int * * * *foo'
	assert candidate(
    'void *',
    'foo',
) == 'void *foo'
	assert candidate(
    "void**",
    "foo",
) == 'void **foo'
def test_check():
	check(join_ctype_and_name)
