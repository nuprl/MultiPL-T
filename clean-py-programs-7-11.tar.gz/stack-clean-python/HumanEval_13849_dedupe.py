def dedupe(items: list, only_neighbors: bool = False) -> list:
    """
    Deduplicate a list while keeping order
    
    If only_neighbors is True, dedupe will only check neighboring values
    """
    ### Canonical solution below ###
    ret = []
    for item in items:
        if (only_neighbors and ret and ret[-1] != item) or item not in ret:
            ret.append(item)
    return ret


### Unit tests below ###
def check(candidate):
	assert candidate([1, 2, 2, 3, 3, 3]) == [1, 2, 3]
	assert candidate(candidate([1, 2, 3], True)) == [1, 2, 3]
	assert candidate(list("abbbcde")) == list("abcde")
	assert candidate([1, 1, 1, 2, 2, 2, 3, 3]) == [1, 2, 3]
	assert candidate([1, 2, 3, 2, 1]) == [1, 2, 3]
	assert candidate([1, 2, 3, 3, 3, 4, 4, 4, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 8, 9, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([0, 1, 2, 3, 4, 0, 6, 7, 8, 9]) == [0, 1, 2, 3, 4, 6, 7, 8, 9]
	assert candidate(candidate([1, 2, 3, 3, 4, 4, 5])) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], only_neighbors=True) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(range(1000), only_neighbors=True) == list(range(1000))
	assert candidate(list('abc')) == list('abc')
	assert candidate(list(range(0, 10))) == list(range(0, 10))
	assert candidate(candidate([1, 2, 3, 4, 5, 6, 6, 6])) == [1, 2, 3, 4, 5, 6]
	assert candidate(candidate([1, 1, 1, 2, 3])) == [1, 2, 3]
	assert candidate([1, 1, 1, 2, 2, 3, 3, 3]) == [1, 2, 3]
	assert candidate(list("abba")) == ["a", "b"]
	assert candidate(['a', 'a', 'a', 'a', 'a']) == ['a']
	assert candidate(candidate([1, 2, 3, 4])) == [1, 2, 3, 4]
	assert candidate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], only_neighbors=True) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]
	assert candidate([1, 1, 1, 1, 2, 2, 2, 3, 3, 3]) == [1, 2, 3]
	assert candidate(list(range(3))) == [0, 1, 2]
	assert candidate(candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 11, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15])) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
	assert candidate(list('aabbc')) == list('abc')
	assert candidate([1, 2, 3, 3, 3, 4, 4, 4, 4, 5, 6, 6, 6, 6], only_neighbors=True) == [1, 2, 3, 4, 5, 6]
	assert candidate(list("abcdef")) == list("abcdef")
	assert candidate([1, 1, 1, 2, 2, 3, 3, 3, 4, 4, 4]) == [1, 2, 3, 4]
	assert candidate(list("abcde")) == list("abcde")
	assert candidate(range(10), True) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 1, 2, 2, 3, 3, 3, 3]) == [1, 2, 3]
	assert candidate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(candidate([1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
	assert candidate([1, 1, 1, 2, 2, 3]) == [1, 2, 3]
	assert candidate([1, 1, 2, 2, 3, 3, 3]) == [1, 2, 3]
	assert candidate(candidate([1, 2, 3, 3, 4, 4, 5], True)) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(list("aabc")) == ["a", "b", "c"]
	assert candidate(candidate([1, 2, 3, 4, 3, 2, 1], True)) == [1, 2, 3, 4]
	assert candidate([1, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(list("abbaca")) == list("abc")
	assert candidate(list("")) == list("")
	assert candidate(list("abbccc"), only_neighbors=True) == list("abc")
	assert candidate(list("a")) == list("a")
	assert candidate(list("abbcdef")) == list("abcdef")
	assert candidate([1, 2, 3, 2, 1, 2, 3, 4, 5, 6, 5, 4, 5, 6, 7, 8, 9, 8, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(candidate([1, 1, 2, 3, 3])) == [1, 2, 3]
	assert candidate(list("abccde")) == list("abcde")
	assert candidate([1, 2, 3, 3, 3, 4, 4, 4, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 8, 9, 9], only_neighbors=True) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(['a', 'a', 'a', 'a', 'b', 'b']) == ['a', 'b']
	assert candidate(list("abcabc")) == ["a", "b", "c"]
	assert candidate(candidate([1, 2, 3, 4, 3, 2, 1, 4, 5, 6, 5, 4, 3, 2, 1])) == [1, 2, 3, 4, 5, 6]
	assert candidate([0, 0, 1, 1, 1, 2, 3, 3, 3, 3]) == [0, 1, 2, 3]
	assert candidate(list(range(10))) == list(range(10))
	assert candidate(candidate([1, 2, 3, 3, 4, 4, 4], True)) == [1, 2, 3, 4]
	assert candidate(candidate([1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4])) == [1, 2, 3, 4]
	assert candidate(list("abbccc")) == list("abc")
	assert candidate(['a', 'a', 'a', 'a', 'b']) == ['a', 'b']
	assert candidate(
    ['a', 'b', 'c', 'b', 'd', 'c', 'd', 'e', 'f', 'e', 'g', 'e', 'h', 'i', 'h', 'i', 'j', 'j', 'k', 'k', 'l']) == [
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l']
	assert candidate(candidate([1, 2, 3])) == [1, 2, 3]
	assert candidate(range(10)) == list(range(10))
	assert candidate([1, 2, 3, 4, 5, 2, 2, 1, 1, 3]) == [1, 2, 3, 4, 5]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]) == [1, 2, 3]
	assert candidate([1, 1, 1, 1, 1, 2, 2, 2, 3, 3, 3]) == [1, 2, 3]
	assert candidate(['a', 'a', 'a', 'b', 'b', 'c', 'c']) == ['a', 'b', 'c']
	assert candidate([1, 2, 3, 3, 3, 4, 4, 4, 4, 5, 6, 6, 6, 6]) == [1, 2, 3, 4, 5, 6]
	assert candidate([0, 1, 0, 2, 0, 3, 0, 4, 0]) == [0, 1, 2, 3, 4]
	assert candidate(range(10), only_neighbors=True) == list(range(10))
	assert candidate(list("aabbcc")) == list("abc")
	assert candidate(range(5)) == [0, 1, 2, 3, 4]
	assert candidate(
    [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]
) == [1, 2, 3]
	assert candidate([1, 1, 2, 2, 3, 3, 3, 4]) == [1, 2, 3, 4]
	assert candidate(candidate([1, 2, 3, 4, 3, 2, 1, 4, 5, 6, 5, 4, 3, 2, 1], True)) == [1, 2, 3, 4, 5, 6]
	assert candidate([0, 0, 1, 1, 1, 2, 3, 3, 3, 3], True) == [0, 1, 2, 3]
	assert candidate(list(range(0, 10)) * 2) == list(range(0, 10))
	assert candidate(range(1000)) == list(range(1000))
	assert candidate(range(5), only_neighbors=True) == [0, 1, 2, 3, 4]
	assert candidate(list('AAAABBBCCDAABBB'), only_neighbors=True) == list('ABCDAB')
	assert candidate([1, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10], only_neighbors=True) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(list("abccdd")) == list("abcd")
	assert candidate(range(5), True) == [0, 1, 2, 3, 4]
	assert candidate(candidate([1, 2, 3, 4, 5], True)) == [1, 2, 3, 4, 5]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3], only_neighbors=True) == [1, 2, 3]
	assert candidate(list("abccba")) == list("abc")
	assert candidate(list("abba"), only_neighbors=True) == ["a", "b", "a"]
	assert candidate(list("abcabc"), only_neighbors=True) == ["a", "b", "c", "a", "b", "c"]
	assert candidate(range(5)) == list(range(5))
	assert candidate(list('AAAABBBCCDAABBB')) == list('ABCD')
	assert candidate(candidate([1, 2, 3, 4, 3, 2, 1])) == [1, 2, 3, 4]
	assert candidate([1, 2, 3, 4, 5, 2, 2, 1, 1, 3], False) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3]) == [1, 2, 3]
def test_check():
	check(dedupe)
