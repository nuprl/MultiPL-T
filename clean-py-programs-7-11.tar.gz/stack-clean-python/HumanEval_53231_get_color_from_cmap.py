def get_color_from_cmap(val, val_min, val_max, cmap):
    """ Return color.
     
     Args:
     val (float): value to get color for from colormap (mV)
     val_min (int): minimum value of voltage for colormap (mV)
     val_max (int): minimum value of voltage for colormap (mV)
     cmap (matplotlib.colors.Colormap): colormap
     
     Returns:
     tuple: tuple of RGBA values indicating a color
     """
	### Canonical solution below ###    
    if val_min >= val_max:
        return "black"
    val_range = val_max - val_min
    return cmap((min(max(val, val_min), val_max) - val_min) / (val_range))

### Unit tests below ###
def check(candidate):
	assert candidate(1, 1, 1, "viridis") == candidate(1, 1, 1, "viridis")
	assert candidate(0, 1, 1, "viridis") == candidate(1, 1, 1, "viridis")
	assert candidate(0, 0, 0, "Reds") == "black"
	assert candidate(1, 0, 0, "viridis") == candidate(0, 0, 0, "viridis")
def test_check():
	check(get_color_from_cmap)
