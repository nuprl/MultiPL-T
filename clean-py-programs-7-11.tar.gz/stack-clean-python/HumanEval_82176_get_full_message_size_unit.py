def get_full_message_size_unit(simple_unit: str) -> str:
    """Convert simple message size unit prefix to full abbreviation."""
    ### Canonical solution below ###
    return {
        'k': 'KiB',
        'm': 'MiB',
    }[simple_unit]


### Unit tests below ###
def check(candidate):
	assert candidate('m') == 'MiB'
	assert candidate(
   'm'
) == 'MiB'
	assert candidate(
   'm') == 'MiB'
	assert candidate(simple_unit='k') == 'KiB'
	assert candidate(
   'm') == 'MiB', 'MiB not returned for m'
	assert candidate(
    simple_unit='k') == 'KiB'
	assert candidate(
    'k') == 'KiB'
	assert candidate(
    'k') == 'KiB', 'KiB not returned for k'
	assert candidate(simple_unit='m') == 'MiB'
	assert candidate(
    'k'
) == 'KiB'
	assert candidate(
    simple_unit='m') == 'MiB'
	assert candidate('k') == 'KiB'
def test_check():
	check(get_full_message_size_unit)
