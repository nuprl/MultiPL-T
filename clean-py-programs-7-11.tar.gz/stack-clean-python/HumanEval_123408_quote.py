def quote(arg: object) -> object:
    """ 
     Puts quotes around a string (so it appears as a string in output). Otherwise returns
     argument unchanged.
     :param arg: argument to transform.
     :return: argument quoted if a string, otherwise unchanged.
     """
	### Canonical solution below ###    
    if isinstance(arg,str):
        return f"'{arg}'"
    else:
        return arg

### Unit tests below ###
def check(candidate):
	assert candidate('"abc"') == "'\"abc\"'"
	assert candidate(False) == False
	assert candidate(3.14) == 3.14
	assert candidate(1.1) == 1.1
	assert candidate(3) == 3
	assert candidate(5) == 5
	assert candidate("42") == "'42'"
	assert candidate('abc') == "'abc'"
	assert candidate(42.0) == 42.0
	assert candidate("hi") == "'hi'"
	assert candidate(1) == 1
	assert candidate(4) == 4
	assert candidate('hello') == "'hello'"
	assert candidate('1') == "'1'"
	assert candidate(123) == 123
	assert candidate(None) is None
	assert candidate("hello") == "'hello'"
	assert candidate("string") == "'string'"
	assert candidate("1") == "'1'"
	assert candidate(True) == True
	assert candidate(None) == None
	assert candidate(12) == 12
	assert candidate("a") == "'a'"
	assert candidate('a') == "'a'"
	assert candidate("foo") == "'foo'"
	assert candidate('abc"') == "'abc\"'"
	assert candidate("abc") == "'abc'"
	assert candidate("42.0") == "'42.0'"
	assert candidate(1.0) == 1.0
	assert candidate(1.23) == 1.23
	assert candidate(2) == 2
	assert candidate(42) == 42
	assert candidate(1.2) == 1.2
def test_check():
	check(quote)
