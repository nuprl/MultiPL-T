def families_quadrupoles():
    """ ."""
	### Canonical solution below ###    
    return ['QF1A', 'QF1B', 'QD2', 'QF2', 'QF3', 'QD4A', 'QF4', 'QD4B']

### Unit tests below ###
def check(candidate):
	assert candidate(
) == ['QF1A', 'QF1B', 'QD2', 'QF2', 'QF3', 'QD4A', 'QF4', 'QD4B']
	assert candidate(
) == ['QF1A', 'QF1B', 'QD2', 'QF2', 'QF3', 'QD4A', 'QF4', 'QD4B'], "candidate test failed"
	assert candidate(
) == ['QF1A', 'QF1B', 'QD2', 'QF2', 'QF3', 'QD4A', 'QF4', 'QD4B'], \
    'candidate()'
	assert candidate(
) == ['QF1A', 'QF1B', 'QD2', 'QF2', 'QF3', 'QD4A', 'QF4', 'QD4B'], "Error in candidate"
	assert candidate( ) == ['QF1A', 'QF1B', 'QD2', 'QF2', 'QF3', 'QD4A', 'QF4', 'QD4B']
def test_check():
	check(families_quadrupoles)
