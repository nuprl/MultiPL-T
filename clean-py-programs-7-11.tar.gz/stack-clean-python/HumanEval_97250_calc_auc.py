def calc_auc(raw_arr):
    """Summary

    Args:
        raw_arr (TYPE): Description

    Returns:
        TYPE: Description
    """
    ### Canonical solution below ###
    # sort by pred value, from small to big
    arr = sorted(raw_arr, key=lambda d: d[2])

    auc = 0.0
    fp1, tp1, fp2, tp2 = 0.0, 0.0, 0.0, 0.0
    for record in arr:
        fp2 += record[0]  # noclick
        tp2 += record[1]  # click
        auc += (fp2 - fp1) * (tp2 + tp1)
        fp1, tp1 = fp2, tp2

    # if all nonclick or click, disgard
    threshold = len(arr) - 1e-3
    if tp2 > threshold or fp2 > threshold:
        return -0.5

    if tp2 * fp2 > 0.0:  # normal auc
        return (1.0 - auc / (2.0 * tp2 * fp2))
    else:
        return None


### Unit tests below ###
def check(candidate):
	assert candidate(
    [[1, 1, 1.0], [1, 1, 0.9], [1, 1, 0.8], [0, 0, 0.7], [0, 0, 0.6], [0, 0, 0.5]]) == 0.5
	assert candidate(raw_arr=[(1, 1, 0.1), (1, 1, 0.2), (1, 1, 0.3), (1, 1, 0.4), (1, 1, 0.5), (1, 1, 0.6)]) == -0.5
	assert candidate(raw_arr=[[0, 0, 0.1], [0, 0, 0.5], [0, 0, 0.9]]) == None
	assert candidate(
    [[1000, 1000, 0.1],
     [1000, 1000, 0.2],
     [1000, 1000, 0.3],
     [1000, 1000, 0.4],
     [1000, 1000, 0.5],
     [1000, 1000, 0.6],
     [1000, 1000, 0.7],
     [1000, 1000, 0.8],
     [1000, 1000, 0.9],
     [1000, 1000, 1.0]]) == -0.5
	assert candidate([[0, 1, 0.1], [0, 3, 0.2], [0, 5, 0.3], [0, 1, 0.4]]) == -0.5
	assert candidate([[0, 0, 1.0], [0, 0, 2.0], [0, 0, 3.0]]) is None
	assert candidate(
    [[100, 100, 0.0],
     [100, 100, 0.0],
     [100, 100, 0.0],
     [100, 100, 1.0]]) == -0.5
def test_check():
	check(calc_auc)
