def quote_ident(value):
    """ Indent the quotes."""
	### Canonical solution below ###    
    return "\"{}\"".format(value
                           .replace("\\", "\\\\")
                           .replace("\"", "\\\"")
                           .replace("\n", "\\n"))

### Unit tests below ###
def check(candidate):
	assert candidate("foo\"bar\"") == "\"foo\\\"bar\\\"\""
	assert candidate(r"abc def") == "\"abc def\""
	assert candidate("hello world") == "\"hello world\""
	assert candidate(r'abc def\ghi') == r'"abc def\\ghi"'
	assert candidate("abc def") == "\"abc def\""
	assert candidate(r"a\b b\f\n\r\t\v") == "\"a\\\\b b\\\\f\\\\n\\\\r\\\\t\\\\v\""
	assert candidate(u"hello \"world\"") == u'"hello \\"world\\""'
	assert candidate(r"abc\def") == "\"abc\\\\def\""
	assert candidate(r"foo") == r'"foo"'
	assert candidate("foo\nbar") == "\"foo\\nbar\""
	assert candidate("foo bar") == "\"foo bar\""
	assert candidate(u"hello") == u'"hello"'
	assert candidate('foo\nbar') == '"foo\\nbar"'
	assert candidate("abc") == "\"abc\""
	assert candidate(r"test\n") == "\"test\\\\n\""
	assert candidate("foo\nbar\n") == "\"foo\\nbar\\n\""
	assert candidate("foo") == "\"foo\""
	assert candidate("abc\ndef") == "\"abc\\ndef\""
	assert candidate(u"hello \\n world") == u'"hello \\\\n world"'
	assert candidate(r"test\"") == "\"test\\\\\\\"\""
	assert candidate("hello \"world\"") == "\"hello \\\"world\\\"\""
	assert candidate("foo'bar'baz") == "\"foo'bar'baz\""
	assert candidate("test\ntest") == "\"test\\ntest\""
	assert candidate(r"foo\nbar") == "\"foo\\\\nbar\""
	assert candidate(r"foo\bar") == "\"foo\\\\bar\""
	assert candidate(r"foo\bar\baz") == "\"foo\\\\bar\\\\baz\""
	assert candidate(r"a b") == "\"a b\""
	assert candidate("test\"test") == "\"test\\\"test\""
	assert candidate("hello \nworld") == "\"hello \\nworld\""
	assert candidate(r"foo") == "\"foo\""
	assert candidate(r"test\n\r") == "\"test\\\\n\\\\r\""
	assert candidate(r"test\0") == "\"test\\\\0\""
	assert candidate('foo') == '"foo"'
	assert candidate(r"\a\b\f\n\r\t\v") == "\"\\\\a\\\\b\\\\f\\\\n\\\\r\\\\t\\\\v\""
	assert candidate(r"a\b\f\n\r\t\v ") == "\"a\\\\b\\\\f\\\\n\\\\r\\\\t\\\\v \""
	assert candidate(u"hello\nworld") == u'"hello\\nworld"'
	assert candidate("foo\"bar") == "\"foo\\\"bar\""
	assert candidate(r"hello world") == "\"hello world\""
	assert candidate(r"a b\f\n\r\t\v") == "\"a b\\\\f\\\\n\\\\r\\\\t\\\\v\""
	assert candidate("") == "\"\""
	assert candidate(r"a\b\f\n\r\t\v") == "\"a\\\\b\\\\f\\\\n\\\\r\\\\t\\\\v\""
	assert candidate("test\\test") == "\"test\\\\test\""
	assert candidate("test") == "\"test\""
	assert candidate("foo\\bar") == "\"foo\\\\bar\""
def test_check():
	check(quote_ident)
