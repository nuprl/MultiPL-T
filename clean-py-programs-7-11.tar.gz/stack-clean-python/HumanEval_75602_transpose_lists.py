def transpose_lists(lsts):
  """Transpose a list of lists."""
    ### Canonical solution below ###
  return [list(i) for i in zip(*lsts)]


### Unit tests below ###
def check(candidate):
	assert candidate( [[1,2],[3,4]] ) == [[1,3], [2,4]]
	assert candidate(
    [[1, 2], [3, 4], [5, 6]]) == [[1, 3, 5], [2, 4, 6]]
	assert candidate( [[1,2,3,4],[5,6,7,8]] ) == [[1,5], [2,6], [3,7], [4,8]]
	assert candidate( [[1,2,3],[4,5,6]]) == [[1,4],[2,5],[3,6]]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
	assert candidate( [[1,2,3]]) == [[1], [2], [3]]
	assert candidate( [[1, 2, 3], [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]
	assert candidate( [[1, 2, 3, 4], [5, 6, 7, 8]] ) == [[1, 5], [2, 6], [3, 7], [4, 8]]
	assert candidate([[1,2,3], [4,5,6], [7,8,9]]) == [[1,4,7], [2,5,8], [3,6,9]]
	assert candidate(
  [[1, 2, 3],
   [4, 5, 6]]) == [[1, 4], [2, 5], [3, 6]]
	assert candidate( [[1,2,3],[4,5,6]] ) == [[1,4], [2,5], [3,6]]
	assert candidate([[1, 2], [3, 4], [5, 6]]) == [[1, 3, 5], [2, 4, 6]]
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9]] ) == [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
	assert candidate(
  [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]]) == \
  [[1, 5, 9], [2, 6, 10], [3, 7, 11], [4, 8, 12]]
	assert candidate( []) == []
	assert candidate([[1]]) == [[1]]
	assert candidate(
  [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
  ]
) == [
    [1, 4, 7],
    [2, 5, 8],
    [3, 6, 9],
  ]
	assert candidate( [["a", "b"], ["c", "d"]] ) == [["a", "c"], ["b", "d"]]
	assert candidate([[]]) == []
	assert candidate( [[1,2,3],[4,5,6],[7,8,9]] ) == [[1,4,7],[2,5,8],[3,6,9]]
	assert candidate([]) == []
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
	assert candidate(
  [[1, 2, 3, 4],
   [5, 6, 7, 8]]) == [[1, 5],
                     [2, 6],
                     [3, 7],
                     [4, 8]]
	assert candidate( [[1, 2], [3, 4]] ) == [[1, 3], [2, 4]]
	assert candidate( [[1, 2, 3], [4, 5, 6]] ) == [[1, 4], [2, 5], [3, 6]]
	assert candidate( [[1]]) == [[1]]
	assert candidate( [[1], [2], [3], [4], [5], [6]] ) == [[1, 2, 3, 4, 5, 6]]
	assert candidate( [[1,2,3], [4,5,6]] ) == [[1,4], [2,5], [3,6]]
	assert candidate(
    [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]]) == [
    [1, 4, 7, 10],
    [2, 5, 8, 11],
    [3, 6, 9, 12]]
	assert candidate(
  [[1, 2],
   [3, 4],
   [5, 6]]) == [[1, 3, 5], [2, 4, 6]]
	assert candidate( [[1, 2], [3, 4], [5, 6]] ) == [[1, 3, 5], [2, 4, 6]]
	assert candidate([[1, 2], [3, 4]]) == [[1, 3], [2, 4]]
	assert candidate( [[1,2,3],[4,5,6]] ) == [[1,4],[2,5],[3,6]]
	assert candidate(
  [[1,2,3], [4,5,6], [7,8,9]]) == [[1,4,7], [2,5,8], [3,6,9]]
	assert candidate( [[1,2,3], [4,5,6]]) == [[1,4], [2,5], [3,6]]
	assert candidate(
    [['a1', 'a2', 'a3'], ['b1', 'b2', 'b3'], ['c1', 'c2', 'c3']]) == [
        ['a1', 'b1', 'c1'],
        ['a2', 'b2', 'c2'],
        ['a3', 'b3', 'c3'],
    ]
	assert candidate( [[1,2], [3,4]]) == [[1,3], [2,4]]
	assert candidate( [[1,2,3,4,5],[6,7,8,9,10]] ) == [[1,6], [2,7], [3,8], [4,9], [5,10]]
	assert candidate( [[1,2], [3,4], [5,6]]) == [[1,3,5], [2,4,6]]
	assert candidate( [[1,2,3], [4,5,6], [7,8,9]] ) == [[1,4,7], [2,5,8], [3,6,9]]
def test_check():
	check(transpose_lists)
