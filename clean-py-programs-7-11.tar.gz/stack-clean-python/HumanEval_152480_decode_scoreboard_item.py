def decode_scoreboard_item(item, with_weight=False, include_key=False):
    """
    :param item: tuple of ZSet (key, score)
    :param with_weight: keep decimal weighting of score, or return as int
    :param include_key: whether to include to raw key
    :return: dict of scoreboard item
    """
    ### Canonical solution below ###
    key = item[0].decode('utf-8')
    data = key.split(">")
    score = item[1]
    if not with_weight:
        score = int(score)
    output = {
        'name': data[0],
        'affiliation': data[1],
        'tid': data[2],
        'score': score
    }
    if include_key:
        output['key'] = key
    return output


### Unit tests below ###
def check(candidate):
	assert candidate(
    (b'1>3>4', 5)
) == {
    'name': '1',
    'affiliation': '3',
    'tid': '4',
   'score': 5
}
	assert candidate(
    (b'1>1>1', 23), with_weight=True
) == {
    'name': '1',
    'affiliation': '1',
    'tid': '1',
   'score': 23.0
}
	assert candidate(
    (b'1>3>4', 5.0000000000000009)
) == {
    'name': '1',
    'affiliation': '3',
    'tid': '4',
   'score': 5
}
	assert candidate(
    (b'player1>player>00000000000000000000000000000000', 1000),
    with_weight=False,
    include_key=True
) == {
    'name': 'player1',
    'affiliation': 'player',
    'tid': '00000000000000000000000000000000',
   'score': 1000,
    'key': 'player1>player>00000000000000000000000000000000'
}
	assert candidate(
    (b'1>1>1', 23), include_key=True
) == {
    'name': '1',
    'affiliation': '1',
    'tid': '1',
   'score': 23,
    'key': '1>1>1'
}
	assert candidate(
    (b'1>1>1', 23)
) == {
    'name': '1',
    'affiliation': '1',
    'tid': '1',
   'score': 23
}
	assert candidate(
    (b'1>3>4', 5.0000000000000009),
    with_weight=True
) == {
    'name': '1',
    'affiliation': '3',
    'tid': '4',
   'score': 5.0000000000000009
}
	assert candidate(
    (b'a>b>c>100', 10), include_key=True) == {
        'name': 'a',
        'affiliation': 'b',
        'tid': 'c',
       'score': 10,
        'key': 'a>b>c>100'
    }
	assert candidate(
    (b'player1>player>00000000000000000000000000000000', 1000),
    with_weight=True,
    include_key=True
) == {
    'name': 'player1',
    'affiliation': 'player',
    'tid': '00000000000000000000000000000000',
   'score': 1000,
    'key': 'player1>player>00000000000000000000000000000000'
}
	assert candidate(
    (b'1>3>4', 5.0000000000000009),
    include_key=True
) == {
    'name': '1',
    'affiliation': '3',
    'tid': '4',
   'score': 5,
    'key': '1>3>4'
}
def test_check():
	check(decode_scoreboard_item)
