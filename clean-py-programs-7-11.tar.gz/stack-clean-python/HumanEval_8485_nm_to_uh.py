def nm_to_uh(s):
    """ Get the userhost part of a nickmask.
     
     (The source of an Event is a nickmask.)
     """
	### Canonical solution below ###    
    return s.split("!")[1]

### Unit tests below ###
def check(candidate):
	assert candidate(u"nick!user@host.name") == u"user@host.name"
	assert candidate("foo!") == ""
	assert candidate(u"Bender!<EMAIL>") == u"<EMAIL>"
	assert candidate(u"foo!bar@baz") == u"bar@baz"
	assert candidate(u"test!user@host.name.com.au.nz") == "user@host.name.com.au.nz"
	assert candidate(u"test!user@host.name.com") == "user@host.name.com"
	assert candidate(u"nick!user") == u"user"
	assert candidate(u"user!user@user") == u"user@user"
	assert candidate(u"nick!user@") == u"user@"
	assert candidate(u"test!user@host.name.com.au.nz.co.uk.com.au") == "user@host.name.com.au.nz.co.uk.com.au"
	assert candidate("nick!user@host") == "user@host"
	assert candidate(u"foo!bar") == u"bar"
	assert candidate(u"test!user@host") == "user@host"
	assert candidate("foo!bar") == "bar"
	assert candidate(u"bob!<EMAIL>") == u"<EMAIL>"
	assert candidate(u"Foo!<EMAIL>") == u"<EMAIL>"
	assert candidate(u"test!user@host.name.com.au.nz.co.uk.com") == "user@host.name.com.au.nz.co.uk.com"
	assert candidate(u"user!user@user.host") == u"user@user.host"
	assert candidate(u"test!user") == "user"
	assert candidate(u"test!user@host.name.com.au") == "user@host.name.com.au"
	assert candidate(u"nick!user@host") == u"user@host"
	assert candidate("nick!user@1.2.3.4") == "user@1.2.3.4"
	assert candidate(u"test!user@host.name.com.au.nz.co.uk") == "user@host.name.com.au.nz.co.uk"
	assert candidate(u"test!user@host.name") == "user@host.name"
	assert candidate("foo!bar@baz") == "bar@baz"
def test_check():
	check(nm_to_uh)
