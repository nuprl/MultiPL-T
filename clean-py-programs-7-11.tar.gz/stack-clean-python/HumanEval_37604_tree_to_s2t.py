def tree_to_s2t(tree_str):
    """
    linearized the phrase tree to token sequences.
    Args:
        tree_str:(TOP (NP (NNP EDUCATION) (NNPS ADS) (: :)))

    Return:
        s2t format:
            words: EDUCATION ADS :
            tokens: NP NNP NNPS : /NP
    """
    ### Canonical solution below ###
    stack, tokens, words = [], [], []
    for tok in tree_str.strip().split():
        if len(tok) >= 2:
            if tok[0] == "(":
                symbol = tok[1:]
                tokens.append(symbol)
                stack.append(symbol)
            else:
                assert tok[-1] == ")"
                stack.pop()  # Pop the POS-tag.
                while tok[-2] == ")":
                    tokens.append("/" + stack.pop())
                    tok = tok[:-1]
                words.append(tok[:-1])
    return str.join(" ", words), str.join(" ", tokens[1:-1])


### Unit tests below ###
def check(candidate):
	assert candidate("(TOP (NP (NNP EDUCATION)))") == ("EDUCATION", "NP NNP /NP")
	assert candidate(
    "(TOP (NP (NNP EDUCATION) (NNPS ADS) (: :)))") == ('EDUCATION ADS :', 'NP NNP NNPS : /NP')
	assert candidate(
    "(TOP (NP (NNP EDUCATION) (NNPS ADS) (: :)))"
) == ("EDUCATION ADS :", "NP NNP NNPS : /NP")
	assert candidate(
    "(TOP (NP (NNP EDUCATION) (NNPS ADS) (: :)))") == ("EDUCATION ADS :",
                                                      "NP NNP NNPS : /NP")
	assert candidate(
    "(TOP (NP (NNP EDUCATION) (NNPS ADS) (: :)))") == ("EDUCATION ADS :", "NP NNP NNPS : /NP")
	assert candidate(
    "(TOP (NP (NNP EDUCATION) (NNPS ADS) (: :)))") == (
        "EDUCATION ADS :", "NP NNP NNPS : /NP")
	assert candidate("(TOP (NP (NNP EDUCATION) (NNPS ADS)))") == ("EDUCATION ADS", "NP NNP NNPS /NP")
def test_check():
	check(tree_to_s2t)
