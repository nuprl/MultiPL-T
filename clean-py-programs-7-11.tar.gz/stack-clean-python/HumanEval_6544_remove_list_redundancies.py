def remove_list_redundancies(l):
    """ 
     Used instead of list(set(l)) to maintain order
     Keeps the last occurance of each element
     """
	### Canonical solution below ###    
    reversed_result = []
    used = set()
    for x in reversed(l):
        if x not in used:
            reversed_result.append(x)
            used.add(x)
    reversed_result.reverse()
    return reversed_result

### Unit tests below ###
def check(candidate):
	assert candidate([1, 1, 2, 2, 3, 3, 4, 4, 5, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 1, 1, 2, 2, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate(list(range(5))) == [0, 1, 2, 3, 4]
	assert candidate([2, 1, 0, 2, 1, 0, 2, 1, 0]) == [2, 1, 0]
	assert candidate(
    ['a', 'b', 'c', 'a', 'b', 'c', 'b', 'c', 'd']) == \
    ['a', 'b', 'c', 'd']
	assert candidate([1, 2, 2, 2, 3, 3, 3]) == [1, 2, 3]
	assert candidate(list()) == list()
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]
	assert candidate([1, 1, 1]) == [1]
	assert candidate([1, 2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]) == [1, 2, 3, 4]
	assert candidate([1, 2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 2, 3]) == [1, 2, 3]
	assert candidate(
    [1, 2, 3, 3, 2, 1]) == [3, 2, 1]
	assert candidate(list("abc")) == ["a", "b", "c"]
	assert candidate([1, 2, 2, 3, 3, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 2, 3, 3, 3, 4, 4, 4, 4]) == [1, 2, 3, 4]
	assert candidate([1,1,1,1,1,1,1,1,1,1,1]) == [1]
	assert candidate(
    [1, 1, 2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 1, 1, 2, 2, 2, 3, 3, 3]) == [1, 2, 3]
	assert candidate(['a', 'a', 'a']) == ['a']
	assert candidate([1, 2, 3, 3, 3, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]
	assert candidate(
    [1, 1, 2, 2, 3, 3]) == [1, 2, 3]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]
	assert candidate([1, 1, 2, 3]) == [1, 2, 3]
	assert candidate(list("aabbcc")) == list("abc")
	assert candidate([1,2,3,2,3,1,3,2,1,2,3]) == [1,2,3]
	assert candidate(
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'a', 'b', 'c', 'd', 'e', 'f', 'g']) == [
        'a', 'b', 'c', 'd', 'e', 'f', 'g']
	assert candidate(
    ['a', 'b', 'c', 'a', 'b', 'c', 'd', 'a', 'b', 'c', 'd', 'a', 'b', 'c', 'd']) == [
        'a', 'b', 'c', 'd']
	assert candidate([1, 2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]
	assert candidate(
    [1, 1, 2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]
	assert candidate(
    [1, 1, 2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]
	assert candidate(list("abcabc")) == ["a", "b", "c"]
	assert candidate(list("abbcc")) == ["a", "b", "c"]
	assert candidate([1, 2, 2, 3, 3, 3, 4]) == [1, 2, 3, 4]
	assert candidate(
    [1, 1, 2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5]) == [1, 2, 3, 4, 5]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [
    1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 1, 1, 1, 1]) == [1]
	assert candidate(range(5)) == list(range(5))
	assert candidate(
    ['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'd']) == [
        'a', 'b', 'c', 'd']
	assert candidate(
    ['a', 'b', 'c', 'd', 'a', 'b', 'c', 'd', 'a', 'b', 'c', 'd']) == [
        'a', 'b', 'c', 'd']
	assert candidate(range(5)) == [0, 1, 2, 3, 4]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1]) == [1]
	assert candidate(list(range(2)) * 2) == [0, 1]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]
	assert candidate([1, 1, 2, 2, 3, 3]) == [1, 2, 3]
	assert candidate([2, 1, 0]) == [2, 1, 0]
	assert candidate(
    ['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']) == [
        'a', 'b', 'c']
	assert candidate(list("abcabcd")) == ["a", "b", "c", "d"]
	assert candidate([2, 2, 1, 1, 0, 0]) == [2, 1, 0]
	assert candidate([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1]
	assert candidate([1]) == [1]
	assert candidate(list("abbc")) == list("abc")
	assert candidate([]) == []
	assert candidate(list(range(3))) == [0, 1, 2]
	assert candidate(list("aaaaa")) == ["a"]
	assert candidate([1, 2, 2, 2, 3]) == [1, 2, 3]
	assert candidate(list(range(10))) == list(range(10))
def test_check():
	check(remove_list_redundancies)
