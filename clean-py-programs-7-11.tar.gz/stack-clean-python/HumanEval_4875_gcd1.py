def gcd1(a, b):
    """ 
     greatest common divisor
     :param a:
     :param b:
     :return:
     """
	### Canonical solution below ###    
    if b == 0:
        return a
    else:
        return gcd1(b, a % b)

### Unit tests below ###
def check(candidate):
	assert candidate(20, 11) == 1
	assert candidate(20, 0) == 20
	assert candidate(100, 10) == 10
	assert candidate(150, 100) == 50
	assert candidate(100, 150) == 50
	assert candidate(20, 16) == 4
	assert candidate(200, 500) == 100
	assert candidate(20, 9) == 1
	assert candidate(29, 91) == 1
	assert candidate(20, 1000) == 20
	assert candidate(500, 200) == 100
	assert candidate(34, 19) == 1
	assert candidate(24, 36) == 12
	assert candidate(20, 8) == 4
	assert candidate(12, 16) == 4
	assert candidate(20, 20) == 20
	assert candidate(20, 12) == 4
	assert candidate(29, 10) == 1
	assert candidate(30, 30) == 30
	assert candidate(100, 200) == 100
	assert candidate(20, 30) == 10
	assert candidate(30, 45) == 15
	assert candidate(12, 25) == 1
	assert candidate(250, 500) == 250
	assert candidate(12, 20) == 4
	assert candidate(29, 19) == 1
	assert candidate(250, 150) == 50
	assert candidate(100, 100) == 100
	assert candidate(29, 21) == 1
	assert candidate(29, 15) == 1
	assert candidate(0, 0) == 0
	assert candidate(150, 250) == 50
	assert candidate(39, 91) == 13
	assert candidate(500, 250) == 250
	assert candidate(200, 100) == 100
	assert candidate(29, 17) == 1
	assert candidate(1024, 0) == 1024
	assert candidate(12, 3) == 3
def test_check():
	check(gcd1)
