def sizeof_fmt(num, suffix='B'):
    """ Format bytes into human friendly units."""
	### Canonical solution below ###    
    for unit in ['', 'Ki', 'Mi', 'Gi', 'Ti', 'Pi', 'Ei', 'Zi']:
        if abs(num) < 1024.0:
            return "%3.1f%s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f%s%s" % (num, 'Yi', suffix)

### Unit tests below ###
def check(candidate):
	assert candidate(100001221, suffix='B') == '95.4MiB'
	assert candidate(1024**6) == '1.0EiB'
	assert candidate(1024**3) == '1.0GiB'
	assert candidate(100001221) == '95.4MiB'
	assert candidate(0) == "0.0B"
	assert candidate(1023) == '1023.0B'
	assert candidate(1) == "1.0B"
	assert candidate(1024*1024*1024*1024*1024*1024*1024*1024) == '1.0YiB'
	assert candidate(1024*1024*1024*1024*1024*1024) == '1.0EiB'
	assert candidate(1024 ** 4, suffix='iB') == '1.0TiiB'
	assert candidate(1024*1024*1024*1024*1024) == '1.0PiB'
	assert candidate(1000) == '1000.0B'
	assert candidate(1024**2) == '1.0MiB'
	assert candidate(1024) == '1.0KiB'
	assert candidate(1024*1024) == '1.0MiB'
	assert candidate(1024**4) == '1.0TiB'
	assert candidate(1024*1024*1024*1024) == '1.0TiB'
	assert candidate(1024*1024*1024) == '1.0GiB'
	assert candidate(1024**9) == '1024.0YiB'
	assert candidate(1000) == "1000.0B"
	assert candidate(1024**7) == '1.0ZiB'
	assert candidate(0) == '0.0B'
	assert candidate(1024 ** 4, suffix='iB') == "1.0TiiB"
	assert candidate(1024**5) == '1.0PiB'
	assert candidate(1) == '1.0B'
	assert candidate(10000) == '9.8KiB'
	assert candidate(1023) == "1023.0B"
	assert candidate(1024*1024*1024*1024*1024*1024*1024) == '1.0ZiB'
def test_check():
	check(sizeof_fmt)
