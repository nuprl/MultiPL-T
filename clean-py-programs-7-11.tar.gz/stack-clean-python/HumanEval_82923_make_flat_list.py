def make_flat_list(input_list):
    """ Takes a multidimensional list and returns a one dimensional list"""
	### Canonical solution below ###    
    flat_list = []

    for x in input_list:
        if type(x) != list:
            flat_list.append(x)
        elif type(x) == list:
            for y in make_flat_list(x):
                flat_list.append(y)
    
    return flat_list

### Unit tests below ###
def check(candidate):
	assert candidate( [1,[2,3],[[4]]]) == [1,2,3,4]
	assert candidate([[[['a', 'b'], ['c', 'd']]], 'e']) == ['a', 'b', 'c', 'd', 'e']
	assert candidate([[1, 2], [3, 4], [5, 6, 7]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate( [1, 2, [3, 4, [5, 6], 7], 8] ) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate([]) == []
	assert candidate( [[1, 2, 3], 4] ) == [1, 2, 3, 4]
	assert candidate(input_list=[1, 2, [3, [4, 5, [6, 7]]]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(input_list=[[[[3]],'dog'],4,5]) == [3,'dog',4,5]
	assert candidate(list(range(5))) == list(range(5))
	assert candidate(input_list=[[[1,2,3],4,5,6,[7,8,9],10,11,12]]) == [1,2,3,4,5,6,7,8,9,10,11,12]
	assert candidate( [[1, 2, 3], [4, 5, 6], [7, 8, 9]] ) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(input_list=[[1, 2], [3, 4], [5, 6, 7]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate([['a', 'b'], 'c', [['d', 'e'], 'f']]) == ['a', 'b', 'c', 'd', 'e', 'f']
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate( [1, [2, [3, [4]]]] ) == [1, 2, 3, 4]
	assert candidate(input_list=[1, [2, 3], 4]) == [1, 2, 3, 4]
	assert candidate( [1, 2, 3] ) == [1, 2, 3]
	assert candidate(input_list=[[1,2,3],[4,5,6],[7,8,9],[10,11,12]]) == [1,2,3,4,5,6,7,8,9,10,11,12]
	assert candidate(input_list=[1, [2, 3], [4, 5, [6, 7]]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate( [1,2,[3,4,[5]]]) == [1,2,3,4,5]
	assert candidate(input_list=[[1, 2], [3, 4], 5]) == [1, 2, 3, 4, 5]
	assert candidate(input_list=[[[1, 2, 3]], 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([['a', 'b'], ['c', 'd']]) == ['a', 'b', 'c', 'd']
	assert candidate([[[[[[[[[[1]]]]]]]]]]) == [1]
	assert candidate(input_list=[[[[[[[[1]]]]]]]])!= [1, 2, 3, 4, 5]
	assert candidate(input_list=[1, 2, [3, 4, [5, [6, 7]]]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate(
    [[1, 2], [3], 4, 5]
) == [1, 2, 3, 4, 5]
	assert candidate([[[]], []]) == []
	assert candidate(input_list=[[[1,2,3]],[[4,5,6]],[[7,8,9]]]) == [1,2,3,4,5,6,7,8,9]
	assert candidate(input_list=[[[[[[[1]]]]]]])!= [1, 2]
	assert candidate(
    [[1, 2, 3], ["a", "b", "c"], ["d", "e", "f"]]) == [1, 2, 3, "a", "b", "c", "d", "e", "f"]
	assert candidate([[[[[]]]]]) == []
	assert candidate(input_list=[[[1, 2]], [[3], 4], 5]) == [1, 2, 3, 4, 5]
	assert candidate([[[1, 2], [3, 4]], [[5, 6], [7, 8]]]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(input_list=[1, [2, 3, 4], 5]) == [1, 2, 3, 4, 5]
	assert candidate(input_list=[1, 2, [3, 4, [5, 6]]]) == [1, 2, 3, 4, 5, 6]
	assert candidate(input_list=[1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate(
    [["a", "b", "c"], ["d", "e", "f"], ["g", "h", "i"]]) == ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
	assert candidate([[[], []], [[], []]]) == []
	assert candidate(
    [1, [2], [[3], 4], 5]
) == [1, 2, 3, 4, 5], "Should be [1, 2, 3, 4, 5]"
	assert candidate([['a'], ['b', ['c', 'd']]]) == ['a', 'b', 'c', 'd']
	assert candidate(input_list=[1, [2, [3, 4], 5]]) == [1, 2, 3, 4, 5]
	assert candidate( [[1, 2, [3, 4, [5, 6], 7], 8], [1, 2, [3, 4, [5, 6], 7], 8]] ) == [1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(input_list=[1, 2, [3, 4, 5], 6]) == [1, 2, 3, 4, 5, 6]
	assert candidate(input_list=[[1,2,3],[4,5,6],[7,8,9]]) == [1,2,3,4,5,6,7,8,9]
	assert candidate(list('abc')) == ['a', 'b', 'c']
	assert candidate([[1, 2], [3, 4], [5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate(input_list=[[[[[[[[1]]]]]]]])!= [1, 2, 3]
	assert candidate(input_list=[[[[1,2,3]]],[[[4,5,6]]],[[[7,8,9]]]]) == [1,2,3,4,5,6,7,8,9]
	assert candidate(input_list=[1, [2, 3], 4, [5, 6]]) == [1, 2, 3, 4, 5, 6]
	assert candidate([1, [2, 3], [4, 5, [6, 7]]]) == [1, 2, 3, 4, 5, 6, 7]
	assert candidate([[[1, 2], 3], 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate(input_list=[[[[[[[[1]]]]]]]])!= [1, 2, 3, 4, 5, 6, 7]
	assert candidate(
    [1, 2, 3, 4, [5, 6, 7, [8, 9], 10], 11, 12]
) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
	assert candidate([['a', ['b', ['c', ['d', 'e']]]]]) == ['a', 'b', 'c', 'd', 'e']
	assert candidate(input_list=[[[[[[[[1]]]]]]]])!= [1, 2, 3, 4]
	assert candidate(
    [1, 2, 3, 4, 5]
) == [1, 2, 3, 4, 5], "Should be [1, 2, 3, 4, 5]"
	assert candidate(input_list=[1, 2, [3, 4, [5, [6, [7, 8]]]]]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate([[[1, 2], [3]], [4, 5]]) == [1, 2, 3, 4, 5]
	assert candidate(input_list=[[1, 2], [[3, 4], 5], 6]) == [1, 2, 3, 4, 5, 6]
	assert candidate(
    [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
	assert candidate(input_list=[[1, 2, 3], 4, 5, [6, 7, 8, [9, 10]]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(
    [["a", "b", "c"], ["d", "e", "f"]]) == ["a", "b", "c", "d", "e", "f"]
	assert candidate(
    [1, 2, 3, 4, 5]
) == [1, 2, 3, 4, 5]
	assert candidate( [1, 2, [3, 4, [5, 6, [7, 8]]]] ) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(input_list=[[1,'a',['cat'],2],[[[3]],'dog'],4,5]) == [1,'a','cat',2,3,'dog',4,5]
	assert candidate(input_list=[[[1, 2, 3], 4], 5]) == [1, 2, 3, 4, 5]
	assert candidate(list(range(4))) == [0, 1, 2, 3]
	assert candidate(input_list=[['cat'],[[[3]],'dog'],4,5]) == ['cat',3,'dog',4,5]
	assert candidate(input_list=[[[[[[[[1]]]]]]]])!= [1, 2, 3, 4, 5, 6]
	assert candidate(
    [1, 2, [3, 4], 5, [6, [7, 8, [9, [10], 11], 12], 13], 14]
) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], "Should be [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]"
	assert candidate( [1,[2],[[3]],4] ) == [1,2,3,4]
	assert candidate( [[[[1, 2], 3], 4], 5] ) == [1, 2, 3, 4, 5]
	assert candidate(input_list=[[[[1], 2], 3], 4]) == [1, 2, 3, 4]
	assert candidate(input_list=[1, [2, 3], [4, 5, [6, 7]]])!= [1, 3, 2, 4, 5, 6, 7]
	assert candidate(input_list=[[[1, 2], 3], 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate( [[1, 2], 3] ) == [1, 2, 3]
	assert candidate(input_list=[[1,2,3],4,5,6,[7,8,9],10,11,12]) == [1,2,3,4,5,6,7,8,9,10,11,12]
	assert candidate(input_list=[1,2,3]) == [1,2,3]
	assert candidate(input_list=[1, 2, 3, 4]) == [1, 2, 3, 4]
	assert candidate( [1,2,3,4] ) == [1,2,3,4]
	assert candidate([[]]) == []
	assert candidate(input_list=[[[1,'a',['cat'],2],[[[3]],'dog'],4,5]]) == [1,'a','cat',2,3,'dog',4,5]
	assert candidate( [[[1, 2], 3], 4] ) == [1, 2, 3, 4]
	assert candidate([[], []]) == []
	assert candidate(
    [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
def test_check():
	check(make_flat_list)
