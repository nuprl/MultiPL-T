def var_pyxll_function_2(x):
    """ if x return string, else a number"""
	### Canonical solution below ###    
    if x:
        return "var can be used to return different types"
    return 123.456

### Unit tests below ###
def check(candidate):
	assert candidate(0) == 123.456
	assert candidate(None) == 123.456
	assert candidate(True) == "var can be used to return different types"
	assert candidate(1) == "var can be used to return different types"
	assert candidate(False) == 123.456
def test_check():
	check(var_pyxll_function_2)
