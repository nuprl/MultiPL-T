def argToBool(x) :
    """
    convert argument of unknown type to a bool:
    """
    ### Canonical solution below ###
    class FalseStrings :
        val = ("", "0", "false", "f", "no", "n", "off")

    if isinstance(x, str) :
        return (x.lower() not in FalseStrings.val)
    return bool(x)


### Unit tests below ###
def check(candidate):
	assert candidate("10.5.5.5.5")
	assert candidate("YES") == True
	assert candidate("10.5a.5a")
	assert candidate("False") == False
	assert candidate("10.5a.5")
	assert candidate(2) == True
	assert candidate(10.0)
	assert candidate("10.5.5")
	assert candidate("1")
	assert candidate(-1.0) == True
	assert candidate(0) == False
	assert candidate(0.0) == False
	assert not candidate("FaLsE")
	assert candidate("YES")
	assert candidate("10.5.5.5.5.5.5.5.5")
	assert candidate("t")
	assert candidate(100.0) == True
	assert candidate(False) == False
	assert candidate("") == False
	assert candidate("10.5a")
	assert candidate("y")
	assert candidate("10.5.5.5.5.5.5")
	assert candidate("no") == False
	assert not candidate("n")
	assert candidate(10)
	assert candidate("T")
	assert candidate(1)
	assert candidate(True)
	assert not candidate(False)
	assert candidate(10) == True
	assert candidate("True") == True
	assert candidate("off") == False
	assert candidate(None) == False
	assert candidate(10.5)
	assert candidate("0") == False
	assert not candidate("False")
	assert candidate("n") == False
	assert candidate("True")
	assert candidate("false") == False
	assert candidate("ON") == True
	assert candidate("on")
	assert candidate(True) == True
	assert candidate("10.5.5a")
	assert candidate("Yes") == True
	assert candidate("T") == True
	assert candidate("f") == False
	assert candidate("No") == False
	assert candidate("TRUE")
	assert candidate("10.5")
	assert candidate("TrUe")
	assert not candidate(0)
	assert candidate("t") == True
	assert candidate("1") == True
	assert candidate("10.5.5.5.5.5.5.5")
	assert not candidate("")
	assert candidate("anything else") == True
	assert not candidate("no")
	assert candidate("true")
	assert candidate(10.0) == True
	assert candidate(1.0) == True
	assert candidate("Y")
	assert candidate(2.5) == True
	assert candidate(-0.5) == True
	assert not candidate("false")
	assert candidate("  ") == True
	assert not candidate("FALSE")
	assert candidate(-1) == True
	assert candidate("2") == True
	assert not candidate("F")
	assert candidate("F") == False
	assert candidate(-10.0) == True
	assert candidate(-10) == True
	assert candidate("FALSE") == False
	assert candidate(1) == True
	assert candidate("y") == True
	assert candidate("NO") == False
	assert candidate("true") == True
	assert candidate("FaLsE") == False
	assert not candidate("0")
	assert candidate("yes") == True
	assert candidate("On") == True
	assert candidate("on") == True
	assert candidate("TrUe") == True
	assert candidate("yes")
	assert not candidate("off")
	assert candidate("3") == True
	assert candidate("TRUE") == True
	assert candidate("10.5.5.5.5.5")
	assert candidate(2.0) == True
	assert candidate("foobar") == True
	assert candidate("OFF") == False
	assert candidate("10.5.5.5")
	assert candidate(100) == True
	assert candidate("Off") == False
	assert not candidate("f")
def test_check():
	check(argToBool)
