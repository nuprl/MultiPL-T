def add_or_append(base_dict, key, value, conditional=True):
    """ 
     Add or append a value to a dictionary
     
     Args:
     base_dict (dict): The existing dictionary to modify
     key (string): The key to add or append to
     value (string): The value to give that key
     [Optional] conditional (bool): exclusion parameter
     
     Returns (dict): A new dictionary with the provided key/value pair added
     """
	### Canonical solution below ###    

    new_dict = {x: base_dict[x] for x in base_dict}
    """Check if the key already exists"""
    if key in new_dict:
        if conditional:
            """Append the value to the existing array"""
            if value not in new_dict[key]:
                new_dict[key].append(value)
    else:
        """Add the new value"""
        new_dict[key] = [value]

    return new_dict

### Unit tests below ###
def check(candidate):
	assert candidate(
    {"a": ["apple"], "b": ["banana"]}, "b", "orange", conditional=True
) == {"a": ["apple"], "b": ["banana", "orange"]}
	assert candidate(
    {"a": ["apple"], "b": ["banana"], "c": ["pear"]},
    "d",
    "pineapple",
) == {"a": ["apple"], "b": ["banana"], "c": ["pear"], "d": ["pineapple"]}
	assert candidate(
    {'name': 'John', 'age': [20, 30]}, 'age', 20) == {
        'name': 'John', 'age': [20, 30]}
	assert candidate(
    {'a': ['b']}, 'a', 'c') == {'a': ['b', 'c']}
	assert candidate(
    {'key1': 'value1'}, 'key2', 'value2') == {'key1': 'value1', 'key2': ['value2']}
	assert candidate(
    {
        'key1': 'value1',
        'key2': ['value2', 'value3']
    },
    'key3',
    'value4',
    False
) == {'key1': 'value1', 'key2': ['value2', 'value3'], 'key3': ['value4']}
	assert candidate(
    {'a': ['b', 'c']}, 'a', 'c', True) == {'a': ['b', 'c']}
	assert candidate(
    {'name': 'John', 'age': [20, 30]}, 'age', 30) == {
        'name': 'John', 'age': [20, 30]}
	assert candidate(
    {'a': ['b', 'c']}, 'a', 'd', True) == {'a': ['b', 'c', 'd']}
	assert candidate(
    {'a': ['a', 'b'], 'b': ['a', 'b'], 'c': ['a', 'b'], 'd': ['a', 'b']},
    'c',
    'd',
    conditional=True) == {
        'a': ['a', 'b'],
        'b': ['a', 'b'],
        'c': ['a', 'b', 'd'],
        'd': ['a', 'b']}
	assert candidate(
    {'key': ['value1', 'value2']},
    'key',
    'value3'
) == {'key': ['value1', 'value2', 'value3']}
	assert candidate(
    {"a": [1, 2], "b": [3]},
    "c",
    4,
) == {"a": [1, 2], "b": [3], "c": [4]}
	assert candidate(
    {"a": [1, 2], "b": [3]},
    "a",
    4,
) == {"a": [1, 2, 4], "b": [3]}
	assert candidate(dict(a=["b"]), "a", "c", conditional=True) == dict(a=["b", "c"])
	assert candidate(
    {'key1': ['value1']}, 'key1', 'value2') == {'key1': ['value1', 'value2']}
	assert candidate(
    {"a": ["apple"], "b": ["banana"]}, "b", "banana", conditional=True
) == {"a": ["apple"], "b": ["banana"]}
	assert candidate(
    {'a': ['a', 'b']},
    'b',
    'c',
    conditional=False) == {'a': ['a', 'b'], 'b': ['c']}
	assert candidate(
    {"a": ["apple"], "b": ["banana"]}, "c", "orange", conditional=True
) == {"a": ["apple"], "b": ["banana"], "c": ["orange"]}
	assert candidate(
    {
        "a": ["b", "c"],
        "d": ["e"],
        "f": "g",
    },
    "z",
    "z",
    conditional=False,
) == {
    "a": ["b", "c"],
    "d": ["e"],
    "f": "g",
    "z": ["z"],
}
	assert candidate(
    {
        "key": ["value"]
    },
    "key",
    "value"
) == {
    "key": ["value"]
}
	assert candidate(dict(a=["a", "b"]), "a", "c") == dict(a=["a", "b", "c"])
	assert candidate(
    {"a": ["apple"], "b": ["banana"]}, "c", "orange", conditional=False
) == {"a": ["apple"], "b": ["banana"], "c": ["orange"]}
	assert candidate(
    {"a": [1, 2], "b": [3]},
    "c",
    4,
    conditional=False,
) == {"a": [1, 2], "b": [3], "c": [4]}
	assert candidate(
    {'a': [1, 2, 3], 'b': 'b'},
    'a',
    4
) == {'a': [1, 2, 3, 4], 'b': 'b'}
	assert candidate(
    {"a": ["apple"], "b": ["banana"], "c": ["pear"]},
    "b",
    "pineapple",
) == {"a": ["apple"], "b": ["banana", "pineapple"], "c": ["pear"]}
	assert candidate({'a': 1, 'b': 2, 'c': 3}, 'd', 4) == {'a': 1, 'b': 2, 'c': 3, 'd': [4]}
	assert candidate(
    {"a": [1, 2], "b": [3]},
    "a",
    2,
) == {"a": [1, 2], "b": [3]}
	assert candidate(
    {'a': [1, 2], 'b': [3, 4]},
    'a', 3
) == {'a': [1, 2, 3], 'b': [3, 4]}
	assert candidate(
    {"a": ["apple"], "b": ["banana"]}, "c", "banana", conditional=True
) == {"a": ["apple"], "b": ["banana"], "c": ["banana"]}
	assert candidate(
    {
        "a": ["b", "c"],
        "d": ["e"],
        "f": "g",
    },
    "z",
    "z",
    conditional=True,
) == {
    "a": ["b", "c"],
    "d": ["e"],
    "f": "g",
    "z": ["z"],
}
	assert candidate(
    {'a': [1, 2, 3], 'b': 'b'},
    'c',
    'c'
) == {'a': [1, 2, 3], 'b': 'b', 'c': ['c']}
	assert candidate(
    {'key1': 'value1'}, 'key2', 'value2', conditional=False) == {'key1': 'value1', 'key2': ['value2']}
	assert candidate(
    {'a': [1, 2], 'b': [3, 4]},
    'c', 4
) == {'a': [1, 2], 'b': [3, 4], 'c': [4]}
	assert candidate(
    {
        'key1': 'value1',
        'key2': ['value2', 'value3']
    },
    'key2',
    'value4'
) == {'key1': 'value1', 'key2': ['value2', 'value3', 'value4']}
	assert candidate(
    {'a': [1, 2], 'b': [3, 4]},
    'a', 2
) == {'a': [1, 2], 'b': [3, 4]}
	assert candidate(dict(a=["b"]), "b", "c", conditional=True) == dict(a=["b"], b=["c"])
	assert candidate(dict(a=["b"]), "b", "c", conditional=False) == dict(a=["b"], b=["c"])
	assert candidate(
    {
        "a": ["b", "c"],
        "d": ["e"],
        "f": "g",
    },
    "a",
    "z",
    conditional=True,
) == {
    "a": ["b", "c", "z"],
    "d": ["e"],
    "f": "g",
}
	assert candidate(
    {'a': [1, 2], 'b': [3, 4]},
    'c', 4, conditional=False
) == {'a': [1, 2], 'b': [3, 4], 'c': [4]}
	assert candidate(dict(a=["a", "b"]), "b", "c") == dict(a=["a", "b"], b=["c"])
	assert candidate(
    {'a': ['b', 'c']}, 'a', 'c', False) == {'a': ['b', 'c']}
	assert candidate(
    {
        "key": ["value1", "value2"]
    },
    "key",
    "value"
) == {
    "key": ["value1", "value2", "value"]
}
def test_check():
	check(add_or_append)
