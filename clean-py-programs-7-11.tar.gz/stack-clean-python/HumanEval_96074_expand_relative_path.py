def expand_relative_path(module_name, rel_path):
    """
    Turn a relative module path into an absolute one.
    
    `module_name` is the absolute name of the reference module, `rel_path` is the path relative to this module.
    """
    ### Canonical solution below ###
    module_path=module_name.split(".")
    if not rel_path.startswith("."):
        return rel_path
    else:
        while rel_path.startswith("."):
            rel_path=rel_path[1:]
            module_path=module_path[:-1]
        return ".".join(module_path)+"."+rel_path


### Unit tests below ###
def check(candidate):
	assert candidate( "a.b.c", "..c.d" ) == "a.c.d"
	assert candidate( __name__, "foo...bar")=="foo...bar"
	assert candidate( __name__, "foo.bar")=="foo.bar"
	assert candidate("foo.bar", ".baz.bar")=="foo.baz.bar"
	assert candidate(
    "a.b.c",
    ".a.b.c"
) == "a.b.a.b.c"
	assert candidate( "a.b.c", ".d" ) == "a.b.d"
	assert candidate(
    "a.b.c",
    ".d.e")=="a.b.d.e"
	assert candidate( "a.b.c", ".d.e")=="a.b.d.e"
	assert candidate("foo.bar", "baz.bar.biz")=="baz.bar.biz"
	assert candidate( "a.b.c", ".d.e") == "a.b.d.e"
	assert candidate(
    "pymel.core.modeling.nodetypes",
    "..nodetypes"
) == "pymel.core.nodetypes"
	assert candidate(
    "pythontexfigures.tests.test_utilities", "..utilities") == "pythontexfigures.utilities"
	assert candidate(
    "a.b.c",
    "..d.e"
) == "a.d.e"
	assert candidate( "x.y.z", "....")=="."
	assert candidate(module_name="foo.bar.baz", rel_path="..bar.baz.foo")=="foo.bar.baz.foo"
	assert candidate(
    "a.b.c",
    "..d")=="a.d"
	assert candidate( "a.b.c", "a.b.c") == "a.b.c"
	assert candidate(
    "pymel.core.modeling.nodetypes",
    "...nodetypes"
) == "pymel.nodetypes"
	assert candidate( "a.b.c", ".d.e" ) == "a.b.d.e"
	assert candidate(module_name="foo.bar.baz", rel_path="..bar.baz.foo.bar")
	assert candidate(module_name="a.b.c", rel_path="..d.e.f")=="a.d.e.f"
	assert candidate( "a.b.c", "..d.e" ) == "a.d.e"
	assert candidate( __name__, "foo.bar.baz")=="foo.bar.baz"
	assert candidate(module_name="foo.bar.baz", rel_path="..bar.baz")=="foo.bar.baz"
	assert candidate("foo.bar", "baz.bar")=="baz.bar"
	assert candidate( "a.b.c", "..d" ) == "a.d"
	assert candidate(
    "pymel.core.modeling.nodetypes",
    "..foo.bar.nodetypes"
) == "pymel.core.foo.bar.nodetypes"
	assert candidate(module_name="a.b.c.d", rel_path="..e.f")=="a.b.e.f"
	assert candidate( "a.b.c", "..d.e")=="a.d.e"
	assert candidate( "a.b.c", "..a") == "a.a"
	assert candidate("foo.bar", ".baz.bar.biz")=="foo.baz.bar.biz"
	assert candidate( "a.b.c", ".a") == "a.b.a"
	assert candidate(
    "a.b.c",
    ".d")=="a.b.d"
	assert candidate(module_name="a.b.c", rel_path="..d")=="a.d"
	assert candidate(module_name="a.b.c", rel_path="a.b.c.d")=="a.b.c.d"
	assert candidate( "x.y.z", ".a.b..c")=="x.y.a.b..c"
	assert candidate(
    "a.b.c",
    ".d.e.f.g")=="a.b.d.e.f.g"
	assert candidate(module_name="a.b.c", rel_path="a.b.c")=="a.b.c"
	assert candidate( "a.b.c", ".d.e.f" ) == "a.b.d.e.f"
	assert candidate( "test.foo.bar", "..baz")=="test.baz"
	assert candidate(module_name="a.b.c", rel_path="..d.e")=="a.d.e"
	assert candidate(
    "a.b.c",
    ".d.e"
) == "a.b.d.e"
	assert candidate( __name__, "foo...bar.baz.quux")=="foo...bar.baz.quux"
	assert candidate(
    "pythontexfigures.tests.test_utilities", ".utilities") == "pythontexfigures.tests.utilities"
	assert candidate( "x.y.z", ".a.b.c")=="x.y.a.b.c"
	assert candidate(module_name="a.b", rel_path=".c")=="a.c"
	assert candidate( __name__, "foo.bar.baz.quux")=="foo.bar.baz.quux"
	assert candidate( "test.foo.bar", ".baz")=="test.foo.baz"
	assert candidate(module_name="a.b.c", rel_path=".d")=="a.b.d"
	assert candidate( __name__, "foo...bar.baz")=="foo...bar.baz"
	assert candidate(
    "pymel.core.modeling.nodetypes",
    ".nodetypes"
) == "pymel.core.modeling.nodetypes"
	assert candidate(module_name="a.b.c", rel_path=".d.e")=="a.b.d.e"
def test_check():
	check(expand_relative_path)
