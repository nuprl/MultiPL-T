def get_common(d1,d2):
	"""
		returns (list of keys) the common part of two dicts
	"""
    ### Canonical solution below ###
	return [p for p in d1 if p in d2 and d1[p]==d2[p]]


### Unit tests below ###
def check(candidate):
	assert candidate(dict(a=1,b=2),dict(a=1,b=2)) == ["a","b"]
	assert candidate( {'a':1, 'b':2}, {'b':2, 'c':3} ) == ['b']
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, b=2)) == ['a','b']
	assert candidate( {'a': 1, 'b': 2}, {'a': 3} ) == []
	assert candidate( {'a':1,'b':2,'c':3}, {'e':3} ) == []
	assert candidate(dict(a=2), dict(b=3)) == []
	assert candidate(dict(a=1, b=2), dict(a=1, b=2)) == ["a", "b"]
	assert candidate(dict(a=1,b=1,c=3),dict(a=1,b=2,c=4,d=5,e=6)) == ['a']
	assert candidate(dict(a=2), dict(a=2,b=3)) == ['a']
	assert candidate(dict(a=1, b=2), dict(a=1, c=2)) == ["a"]
	assert candidate(
	{1:1, 2:2, 3:3, 4:4},
	{1:1, 2:2, 3:3, 4:5}
) == [1,2,3]
	assert candidate(
	{'a': 1, 'b': 2, 'c': 3}, 
	{'a': 1, 'b': 2, 'd': 4}
	)==['a', 'b']
	assert candidate(dict(a=1, b=2), dict(c=1, d=2)) == []
	assert candidate(dict(a=1, b=2), dict(b=2)) == ["b"]
	assert candidate(dict(a=1,b=2,c=3),dict(d=4,e=5)) == []
	assert candidate(dict(a=2), dict(a=2)) == ['a']
	assert candidate(dict(a=1,b=2),dict(a=1,b=3))==['a']
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,b=2,c=4))==['a','b']
	assert candidate( {'a': 1, 'b': 2}, {'c': 3} ) == []
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,c=3))==['a','c']
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,b=2,c=3)) == ['a','b','c']
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, b=2, c=3, d=4)) == ["a", "b", "c"]
	assert candidate(dict(a=1),dict(a=2))==[]
	assert candidate(dict(a=1,b=2),dict(b=2,c=3)) == ['b']
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':2,'c':3} ) == ['a', 'b', 'c']
	assert candidate( {'a':1, 'b':2}, {'b':2} ) == ['b']
	assert candidate( {1:2,3:4}, {3:4,5:6}) == [3]
	assert candidate(dict(A=1,B=1),dict(C=2)) == []
	assert candidate(dict(a=1, b=2), dict(a=1, b=2, c=3)) == ['a','b']
	assert candidate(dict(a=3,b=2),dict(a=3,c=4)) == ['a']
	assert candidate(dict(a=1,b=2),dict(a=1,c=3,b=2)) == ['a', 'b']
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, b=2, c=3)) == ["a", "b", "c"]
	assert candidate(dict(a=1,b=2),dict(a=1))==['a']
	assert candidate(dict(a=1, b=2), dict(a=1, b=2, c=3)) == ["a", "b"]
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, b=2, c=3)) == ['a', 'b', 'c']
	assert candidate(dict(A=1,B=1),dict(A=1,C=2)) == ["A"]
	assert candidate(dict(a=1, b=2, c=3), dict(b=2, c=3, d=4)) == ["b", "c"]
	assert candidate(dict(a=1,b=2),dict(a=1,b=2,c=3)) == ['a','b']
	assert candidate(dict(), dict(a=2)) == []
	assert candidate(dict(A=1,B=1),dict(A=1)) == ["A"]
	assert candidate(dict(a=1,b=2),dict(a=2,c=3)) == []
	assert candidate(dict(a=1,b=2,c=3),dict(b=2))==['b']
	assert candidate(dict(a=1,b=2,c=3),dict(d=4,b=2)) == ['b']
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, d=2, e=4)) == ['a']
	assert candidate( {'a':1,'b':2},{'b':2,'c':3} ) == ['b']
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,c=3,d=4)) == ['a','c']
	assert candidate(dict(a=2,b=3,c=4), dict(a=2,b=3,c=4)) == ['a','b','c']
	assert candidate({'a':1},{'a':1})==['a']
	assert candidate(dict(a=1,b=2,c=3),dict(a=2))==[]
	assert candidate( {'a':1,'b':2}, {'a':1,'b':2} ) == ['a','b']
	assert candidate( { 'a': 1, 'b': 2 }, { 'c': 3 } ) == []
	assert candidate(dict(a=1,b=1,c=3),dict(a=1,b=1)) == ['a','b']
	assert candidate(dict(a=1,b=2),dict(a=2,b=2,c=3))==['b']
	assert candidate(dict(a=1,b=1,c=3),dict(a=1,b=2,c=3)) == ['a','c']
	assert candidate(dict(a=3,b=2),dict(a=3,c=4,d=5)) == ['a']
	assert candidate(
	{"a":1,"b":2,"c":3},
	{"a":1,"b":2,"c":3}) == ["a","b","c"]
	assert candidate(dict(a=1,b=1,c=1),dict(c=1,d=1))==['c']
	assert candidate(dict(a=1,b=1),dict(b=1,c=1))==['b']
	assert candidate( {1:2, 3:4, 5:6}, {1:2, 3:4, 7:8, 5:7, 9:10} ) == [1, 3]
	assert candidate( {1:2, 3:4, 5:6}, {1:2, 3:4, 7:8, 5:6} ) == [1, 3, 5]
	assert candidate(
	{'a': 1, 'b': 2, 'c': 3}, 
	{'a': 1, 'b': 2, 'c': 3, 'd': 4}
	)==['a', 'b', 'c']
	assert candidate(dict(A=1,B=1,C=1),dict(A=1,C=1,D=1,E=1)) == ["A","C"]
	assert candidate({'a':1,'b':2},{'a':1,'b':2})==['a','b']
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,b=2,c=3,d=4))==['a','b','c']
	assert candidate(dict(a=1, b=2), dict(a=1)) == ["a"]
	assert candidate(
	{"a":1,"b":2,"c":3},
	{"b":2,"c":3}) == ["b","c"]
	assert candidate(dict(A=1, B=2), dict(B=2, D=4, A=1)) == ["A", "B"]
	assert candidate( {'a':1, 'b':2}, {'a':1, 'b':3} ) == ['a']
	assert candidate(dict(a=1, b=2), dict(a=1, b=2)) == ['a','b']
	assert candidate( {}, {'b':2} ) == []
	assert candidate(dict(a=1),dict())==[]
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,b=2)) == ['a','b']
	assert candidate( { 'a': 1, 'b': 2 }, { 'b': 2, 'c': 3 } ) == ['b']
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':2,'c':4} ) == ['a','b']
	assert candidate(dict(a=1,b=1,c=3),dict(a=1,b=1,c=3)) == ['a','b','c']
	assert candidate( {}, {} ) == []
	assert candidate(dict(a=1),dict(a=1))==['a']
	assert candidate(dict(a=1,b=2),dict(c=3)) == []
	assert candidate(dict(a=1,b=2),dict(a=1,b=2))==['a','b']
	assert candidate( {'a':1,'b':2,'c':3}, {'c':3} ) == ['c']
	assert candidate(
	{1:1, 2:2, 3:3, 4:4},
	{1:1, 2:2, 3:3}
) == [1,2,3]
	assert candidate(dict(a=1,b=2),dict(a=2,c=3))==[]
	assert candidate( {'a':1,'b':2,'c':3}, {'b':2,'c':3,'d':4} ) == ['b', 'c']
	assert candidate(dict(a=1,b=2),dict(a=3,b=3))==[]
	assert candidate(
	{"a":1,"b":2,"c":3},
	{"a":1,"b":2}) == ["a","b"]
	assert candidate(dict(a=1,b=1),dict(c=1,d=1))==[]
	assert candidate( {'a':1, 'b':2}, {'a':1, 'b':2} ) == ['a', 'b']
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1} ) == ['a']
	assert candidate( {'a':1,'b':2,'c':3}, {'d':3} ) == []
	assert candidate(dict(a=2), dict()) == []
	assert candidate(dict(a=1,b=1,c=3),dict(a=1,b=2,c=4,d=5)) == ['a']
	assert candidate({'a':1},{'a':2})==[]
	assert candidate(
	{},
	{1:1, 2:2, 3:3, 4:4}
) == []
	assert candidate(dict(a=3,b=2),dict(a=3,b=2)) == ['a','b']
	assert candidate( {1:2,3:4}, {5:6}) == []
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':2,'c':3} ) == ['a','b','c']
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':3} ) == ['a']
	assert candidate( {'a':1,'b':2}, {'c':3,'d':4,'e':5} ) == []
	assert candidate(dict(a=1,b=2),dict(a=1,c=2))==['a']
	assert candidate(dict(),dict())==[]
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':2,'c':3,'d':4,'e':5} ) == ['a','b','c']
	assert candidate(dict(a=1,b=2),dict(c=3))==[]
	assert candidate(dict(a=1,b=2),dict(a=1,b=2)) == ['a','b']
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,b=2,d=4))==['a','b']
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':2,'d':3}) == ['a','b']
	assert candidate(dict(a=1,b=2),dict(a=2))==[]
	assert candidate(dict(a=1,b=2,c=3),dict(a=2,b=2))==['b']
	assert candidate( {}, {'a':1,'b':2} ) == []
	assert candidate(
	{1:1, 2:2, 3:3, 4:4},
	{}
) == []
	assert candidate(dict(),dict(a=1))==[]
	assert candidate( {'a':1, 'b':2}, {'a':1} ) == ['a']
	assert candidate(dict(a=1,b=2),dict()) == []
	assert candidate(dict(),dict(a=1,b=2)) == []
	assert candidate( {'a': 1, 'b': 2}, {'a': 1, 'b': 2, 'c': 3} ) == ['a','b']
	assert candidate( {}, {'a': 3} ) == []
	assert candidate(dict(A=1,B=1),dict(A=1,B=1)) == ["A","B"]
	assert candidate( {'a':1, 'b':2}, {'a':1, 'b':2, 'c':3} ) == ['a', 'b']
	assert candidate(dict(a=1,b=2),dict(a=1)) == ['a']
	assert candidate(
	{'a': 1, 'b': 2, 'c': 3}, 
	{'a': 1, 'b': 2}
	)==['a', 'b']
	assert candidate(
	{1:1, 2:2, 3:3, 4:4},
	{1:1, 2:2, 3:3, 4:4}
) == [1,2,3,4]
	assert candidate( {1:2, 3:4, 5:6}, {1:2, 3:4, 7:8, 5:7} ) == [1, 3]
	assert candidate(dict(a=3,b=2),dict(a=3)) == ['a']
	assert candidate( {'a':1,'b':2}, {'a':1,'b':3} ) == ['a']
	assert candidate(dict(a=1,b=1,c=3),dict(a=1,b=2,c=4)) == ['a']
	assert candidate( {'a': 1, 'b': 2}, {'b': 2, 'c': 3} ) == ['b']
	assert candidate( {'a':1,'b':2}, {'a':1,'c':3,'d':4,'e':5} ) == ['a']
	assert candidate(dict(a=1,b=1,c=1),dict(b=1,c=1))==['b','c']
	assert candidate(dict(a=2,b=3), dict(a=2,b=3)) == ['a','b']
	assert candidate(dict(a=1,b=2),dict(c=3,d=4))==[]
	assert candidate(dict(a=1,b=2),dict(a=1,b=3)) == ['a']
	assert candidate(dict(),dict()) == []
	assert candidate( {}, {'a':1, 'b':2} ) == []
	assert candidate( {'a':1,'b':2,'c':3}, {}) == []
	assert candidate(
	{1:1, 2:2, 3:3, 4:4},
	{1:1, 2:2}
) == [1,2]
	assert candidate( { 'a':1,'b':1 }, { 'a':1,'b':1,'c':1 } ) == ['a', 'b']
	assert candidate(dict(a=1,b=2),dict(b=2,c=3))==['b']
	assert candidate( {'a':1, 'b':2}, {} ) == []
	assert candidate( {'a':1,'b':2},{'c':2,'d':3} ) == []
	assert candidate( {'a':1,'b':2}, {} ) == []
	assert candidate( {'a':1,'b':2}, {'a':1,'b':3,'c':4,'d':5} ) == ['a']
	assert candidate( {'a':1,'b':2,'c':3}, {'a':3} ) == []
	assert candidate( {'a':1,'b':2,'c':3}, {'a':2} ) == []
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':2} ) == ['a','b']
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,b=2))==['a','b']
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':3}) == ['a']
	assert candidate( {1:2, 3:4, 5:6}, {1:2, 3:4} ) == [1, 3]
	assert candidate( {1:2, 3:4, 5:6}, {1:2, 3:4, 7:8} ) == [1, 3]
	assert candidate(dict(), dict()) == []
	assert candidate( {}, {'a':1,'b':2,'c':3}) == []
	assert candidate( {'a':1,'b':2,'c':3}, {'a':1,'b':2,'c':3}) == ['a','b','c']
	assert candidate(dict(a=1,b=2,c=3),dict(b=2,c=3,d=4)) == ['b','c']
	assert candidate({'a':1,'b':2},{'b':2})==['b']
	assert candidate(
	{"a":1,"b":2,"c":3},
	{"d":4}) == []
	assert candidate(dict(a=1,b=2,c=3),dict(d=4,e=5))==[]
	assert candidate({'a':1,'b':2},{'a':1})==['a']
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, b=2, c=4)) == ['a', 'b']
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, b=2, d=4)) == ['a', 'b']
	assert candidate( {1:2,3:4}, {3:4,1:2}) == [1,3]
	assert candidate(dict(a=1,b=2),dict(a=1,c=3))==['a']
	assert candidate( {'a':1, 'b':2}, {'c':1, 'd':2} ) == []
	assert candidate(dict(A=1,B=1),dict(A=2)) == []
	assert candidate(dict(A=1,B=1,C=1),dict(A=1,C=1,D=1)) == ["A","C"]
	assert candidate(dict(a=1,b=2),dict(a=1,b=2,c=3))==['a','b']
	assert candidate( {'a':1,'b':2}, {'a':1,'b':3,'c':4} ) == ['a']
	assert candidate(dict(a=1,b=2),dict(a=1,c=3)) == ['a']
	assert candidate(dict(a=1,b=2),dict(c=1,d=3))==[]
	assert candidate(dict(a=2,b=3), dict(a=2,b=3,c=4)) == ['a','b']
	assert candidate(dict(A=1, B=2), dict(C=3, D=4)) == []
	assert candidate( { 'a':1,'b':1 }, { 'a':1,'b':1 } ) == ['a', 'b']
	assert candidate(dict(a=1,b=2,c=3),dict(a=1,b=2,c=3))==['a','b','c']
	assert candidate( {'a':1,'b':2,'c':3}, {'d':4,'e':5,'f':6} ) == []
	assert candidate(dict(a=1,b=2,c=3),dict(b=2,c=3))==['b','c']
	assert candidate(dict(a=1, b=2, c=3), dict(a=1, b=2)) == ['a', 'b']
	assert candidate(
	{1:1, 2:2, 3:3, 4:4},
	{1:1}
) == [1]
	assert candidate(dict(A=1, B=2), dict(B=2, D=4)) == ["B"]
def test_check():
	check(get_common)
