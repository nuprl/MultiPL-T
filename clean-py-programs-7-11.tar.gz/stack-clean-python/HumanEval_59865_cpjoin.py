def cpjoin(*args: str) -> str:
    """ custom path join """
	### Canonical solution below ###    

    if len(args) == 0:
        return ''

    rooted = bool(args[0].strip().startswith('/'))
    ended  = bool(args[-1].strip().endswith('/'))

    split_items = []

    for path in args:
        for item in path.split('/'):
            if item != '':
                split_items.append(item)

    joined = '/'.join(split_items)

    if rooted: joined = '/' + joined
    if ended:  joined = joined + '/'

    return joined

### Unit tests below ###
def check(candidate):
	assert candidate( '', '/' ) == '/'
	assert candidate( 'a', 'b', 'c', 'd' ) == 'a/b/c/d'
	assert candidate(   'a', 'b', 'c', 'd/' ) == 'a/b/c/d/'
	assert candidate( 'a/b', 'c/d', 'e/f' ) == 'a/b/c/d/e/f'
	assert candidate(
    'foo/bar',
    '/baz/qux',
    'qwe/rty',
) == 'foo/bar/baz/qux/qwe/rty'
	assert candidate(   'a/', 'b', 'c', 'd' ) == 'a/b/c/d'
	assert candidate( 'a/b/', 'c/d/', 'e/f' ) == 'a/b/c/d/e/f'
	assert candidate(
    '/foo/',
    '/bar/',
    'baz/',
    '/bif'
) == '/foo/bar/baz/bif'
	assert candidate( '/a', '/b', 'c' ) == '/a/b/c'
	assert candidate(
    'home/user/',
    'bin/',
    'file.txt'
) == 'home/user/bin/file.txt'
	assert candidate(   'a', 'b', 'c/', 'd' ) == 'a/b/c/d'
	assert candidate(
    'foo/', '/bar/', '/baz'
) == 'foo/bar/baz'
	assert candidate(
    'foo',
    '',
    'baz',
    'qux'
) == 'foo/baz/qux'
	assert candidate(
    '/home', 'user', 'project', 'dir1', 'dir2', 'file.ext') == \
    '/home/user/project/dir1/dir2/file.ext'
	assert candidate('foo', 'bar/', 'baz') == 'foo/bar/baz'
	assert candidate('', '/') == '/'
	assert candidate(
    'a/b/',
    'c/d'
) == 'a/b/c/d'
	assert candidate('/', '', '', '') == '/'
	assert candidate( 'a', 'b', 'c', '/d/' ) == 'a/b/c/d/'
	assert candidate(
    '/etc',
    '/var',
    'opt',
    'home',
    '/usr/local',
    'bin',
    ) == '/etc/var/opt/home/usr/local/bin'
	assert candidate(
    '/etc/',
    '/var/',
    '/opt/',
    '/home/',
    '/usr/local/',
    '/bin/',
    ) == '/etc/var/opt/home/usr/local/bin/'
	assert candidate( 'a/b', 'c/d/', 'e/f' ) == 'a/b/c/d/e/f'
	assert candidate( '/a/b/c/', 'd/e/f' ) == '/a/b/c/d/e/f'
	assert candidate( 'a', 'b/', 'c/' ) == 'a/b/c/'
	assert candidate( 'a/b/c/', '/' ) == 'a/b/c/'
	assert candidate( 'a', 'b', 'c' ) == 'a/b/c'
	assert candidate( 'a', 'b', 'c', '/d' ) == 'a/b/c/d'
	assert candidate( 'a', 'b', 'c', '' ) == 'a/b/c'
	assert candidate('', '', '/', '/', '', '/') == '/'
	assert candidate(
    '/foo/bar',
    'baz/qux',
    'qwe/rty',
) == '/foo/bar/baz/qux/qwe/rty'
	assert candidate('', '', '', '', '', '/') == '/'
	assert candidate(
    '/etc',
    'init.d',
    '/apache2',
    'apache2',
    '/sites-available',
    '000-default/'
) == '/etc/init.d/apache2/apache2/sites-available/000-default/'
	assert candidate(
    'home', 'user', 'project', 'dir1', 'dir2', 'file.ext') == \
    'home/user/project/dir1/dir2/file.ext'
	assert candidate( 'a/b/c/' ) == 'a/b/c/'
	assert candidate( 'a', '/b', '/c' ) == 'a/b/c'
	assert candidate( 'a/', 'b/', 'c' ) == 'a/b/c'
	assert candidate(
    'a/b',
    'c/d'
) == 'a/b/c/d'
	assert candidate(   'a', 'b/', 'c', 'd/' ) == 'a/b/c/d/'
	assert candidate(
    '/foo',
    '/bar',
    'baz/',
    '/bif/'
) == '/foo/bar/baz/bif/'
	assert candidate( 'a', 'b', '/c' ) == 'a/b/c'
	assert candidate('foo/', 'bar', 'baz') == 'foo/bar/baz'
	assert candidate('/', '/', '/', '', '', '') == '/'
	assert candidate(
    'foo/',
    'bar/',
    'baz/',
    'bif/'
) == 'foo/bar/baz/bif/'
	assert candidate(
    'foo', 'bar', 'baz'
) == 'foo/bar/baz'
	assert candidate('/', '', '', '', '/', '') == '/'
	assert candidate( '/a', 'b' ) == '/a/b'
	assert candidate( 'a/', 'b', 'c/' ) == 'a/b/c/'
	assert candidate(
    'foo',
    'bar',
    'baz',
    ''
) == 'foo/bar/baz'
	assert candidate(
    'foo',
    'bar',
    'baz',
    'bif'
) == 'foo/bar/baz/bif'
	assert candidate(
    'a/b/',
    'c/d',
    'e'
) == 'a/b/c/d/e'
	assert candidate(
    'foo',
    'bar',
    'baz',
    'bif/'
) == 'foo/bar/baz/bif/'
	assert candidate( 'a', 'b', 'c', '//d//' ) == 'a/b/c/d/'
	assert candidate( '/a', '/b', '/c' ) == '/a/b/c'
	assert candidate('', '', '', '', '/', '/') == '/'
	assert candidate( '/', '' ) == '/'
	assert candidate( '/foo/', 'bar/', '/baz/') == '/foo/bar/baz/'
	assert candidate('foo/', 'bar/', 'baz/') == 'foo/bar/baz/'
	assert candidate(
    '/foo',
    '/bar',
    'baz',
    '/bif'
) == '/foo/bar/baz/bif'
	assert candidate(
    'foo', '/bar/', '/baz'
) == 'foo/bar/baz'
	assert candidate( 'a/b', 'c/' ) == 'a/b/c/'
	assert candidate(   'a', 'b', 'c', 'd' ) == 'a/b/c/d'
	assert candidate(
    '/root/',
    'home',
    'test/',
    'test2/',
    'test3/',
) == '/root/home/test/test2/test3/'
	assert candidate( 'a/b', 'c' ) == 'a/b/c'
	assert candidate( 'a', 'b' ) == 'a/b'
	assert candidate(   'a/', 'b', 'c/', 'd/' ) == 'a/b/c/d/'
	assert candidate( 'a', 'b', 'c', '/d', '/e/' ) == 'a/b/c/d/e/'
	assert candidate(
    '/root',
    'home',
    'test/',
    'test2',
    'test3',
) == '/root/home/test/test2/test3'
	assert candidate( '/foo/', 'bar/', '/baz') == '/foo/bar/baz'
	assert candidate(
    'foo/',
    'bar/',
    'baz',
    'bif'
) == 'foo/bar/baz/bif'
	assert candidate(
    'foo',
    'bar',
    'baz',
    'qux',
    'quux'
) == 'foo/bar/baz/qux/quux'
	assert candidate(
    'foo/bar',
    'baz/qux',
    'qwe/rty',
) == 'foo/bar/baz/qux/qwe/rty'
	assert candidate( '', '', '' ) == ''
	assert candidate(
    '/home/', 'user/', 'project/', 'dir1/', 'dir2/', 'file.ext') == \
    '/home/user/project/dir1/dir2/file.ext'
	assert candidate( '', '' ) == ''
	assert candidate(
    '/root',
    'home',
    'test',
    'test2',
    'test3',
) == '/root/home/test/test2/test3'
	assert candidate(
    '/home/', 'user', 'project', 'dir1', 'dir2', 'file.ext') == \
    '/home/user/project/dir1/dir2/file.ext'
	assert candidate('/', '/', '/', '') == '/'
	assert candidate('/test/', 'test2') == r'/test/test2'
	assert candidate( 'a/b/', 'c/d', 'e/f' ) == 'a/b/c/d/e/f'
	assert candidate( 'a/', 'b' ) == 'a/b'
	assert candidate('/test', '/test2') == r'/test/test2'
	assert candidate(
    'a/b',
    'c/d',
    'e'
) == 'a/b/c/d/e'
	assert candidate(
    '/etc/',
    '/var/',
    'opt/',
    'home/',
    '/usr/local/',
    'bin/',
    ) == '/etc/var/opt/home/usr/local/bin/'
	assert candidate( '', '', '/' ) == '/'
	assert candidate(
    '/etc/',
    '/var/',
    'opt/',
    'home/',
    '/usr/local/',
    'bin',
    ) == '/etc/var/opt/home/usr/local/bin'
	assert candidate( 'a', '/b', 'c' ) == 'a/b/c'
	assert candidate(
    'foo',
    'bar',
    'baz',
    'qux',
    'quux',
    ''
) == 'foo/bar/baz/qux/quux'
	assert candidate( 'a/', 'b/c' ) == 'a/b/c'
	assert candidate('', '', '/', '/') == '/'
	assert candidate(
    '/root/',
    'home/',
    'test/',
    'test2',
    'test3/',
) == '/root/home/test/test2/test3/'
	assert candidate( 'foo', 'bar', 'baz') == 'foo/bar/baz'
	assert candidate(
    '/etc',
    '/var',
    'opt',
    'home',
    '/usr/local',
    'bin/',
    ) == '/etc/var/opt/home/usr/local/bin/'
	assert candidate(
    'home/user',
    'bin/',
    'file.txt'
) == 'home/user/bin/file.txt'
	assert candidate(
    '/root',
    'home',
    'test/',
    'test2/',
    'test3',
) == '/root/home/test/test2/test3'
	assert candidate( 'a/', 'b/c/', '/' ) == 'a/b/c/'
	assert candidate(
    '/a/b/',
    'c/d'
) == '/a/b/c/d'
	assert candidate(
    '/foo',
    '/bar',
    'baz',
    '/bif/'
) == '/foo/bar/baz/bif/'
	assert candidate(r'C:\Users\User', 'Desktop', 'Documents', 'Projects', 'Python/', '')
	assert candidate(   'a/', 'b/', 'c', 'd/' ) == 'a/b/c/d/'
	assert candidate(
    '/home/user',
    'bin/',
    'file.txt'
) == '/home/user/bin/file.txt'
	assert candidate( 'a' ) == 'a'
	assert candidate( 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' ) == 'a/b/c/d/e/f/g/h'
	assert candidate( 'a/', 'b', 'c' ) == 'a/b/c'
	assert candidate(
    '/foo/',
    '/bar/',
    'baz/',
    '/bif/'
) == '/foo/bar/baz/bif/'
	assert candidate( 'a', 'b/c' ) == 'a/b/c'
	assert candidate( 'a', 'b', 'c', '//d' ) == 'a/b/c/d'
	assert candidate( 'a', 'b', 'c', '/d', '/e' ) == 'a/b/c/d/e'
	assert candidate('/', '', '', '/', '', '') == '/'
	assert candidate( '/', '', '' ) == '/'
	assert candidate('/', '') == '/'
	assert candidate('/test', 'test2') == r'/test/test2'
	assert candidate(   'a', 'b/', 'c/', 'd/' ) == 'a/b/c/d/'
	assert candidate(
    '/etc',
    'init.d',
    '/apache2',
    'apache2',
    '/sites-available',
    '000-default'
) == '/etc/init.d/apache2/apache2/sites-available/000-default'
	assert candidate(   ) == ''
	assert candidate('/', '', '') == '/'
	assert candidate( 'a', 'b', 'c', '//' ) == 'a/b/c/'
	assert candidate( 'a/b/c/', 'd/e/f' ) == 'a/b/c/d/e/f'
	assert candidate(
    '/foo',
    '/bar',
    'baz',
    'qux'
) == '/foo/bar/baz/qux'
	assert candidate(
    '/home/', 'user/', 'project', 'dir1', 'dir2', 'file.ext') == \
    '/home/user/project/dir1/dir2/file.ext'
	assert candidate( 'a', 'b', 'c/' ) == 'a/b/c/'
	assert candidate('/', '/', '/', '/', '', '') == '/'
	assert candidate(
    '/', 'home', 'user', 'project', 'dir1', 'dir2', 'file.ext') == \
    '/home/user/project/dir1/dir2/file.ext'
	assert candidate( 'a/b/c', 'd/e/f' ) == 'a/b/c/d/e/f'
	assert candidate( 'a', 'b', 'c', 'd', 'e', 'f' ) == 'a/b/c/d/e/f'
	assert candidate( 'a/', 'b/', 'c/' ) == 'a/b/c/'
	assert candidate( 'a/b/c' ) == 'a/b/c'
	assert candidate(
    'foo/',
    'bar/',
    'baz/',
    'bif'
) == 'foo/bar/baz/bif'
	assert candidate(
    '/etc',
    'init.d/',
    '/apache2',
    'apache2',
    '/sites-available',
    '000-default'
) == '/etc/init.d/apache2/apache2/sites-available/000-default'
	assert candidate('', '/', '/') == '/'
	assert candidate( '/foo', 'bar', 'baz') == '/foo/bar/baz'
	assert candidate( 'a/b', 'c/', '/' ) == 'a/b/c/'
	assert candidate( 'a/', 'b/c/' ) == 'a/b/c/'
	assert candidate( 'a', 'b', 'c', 'd/' ) == 'a/b/c/d/'
	assert candidate('', '') == ''
	assert candidate( '/a', 'b', '/c' ) == '/a/b/c'
	assert candidate(
    '/home/user',
    'bin',
    'file.txt'
) == '/home/user/bin/file.txt'
	assert candidate(
    '/home/', 'user/', 'project/', 'dir1', 'dir2', 'file.ext') == \
    '/home/user/project/dir1/dir2/file.ext'
	assert candidate(
    '/home/user/',
    'bin/',
    'file.txt/'
) == '/home/user/bin/file.txt/'
	assert candidate( '/', '/', '' ) == '/'
	assert candidate(
    '/etc',
    'init.d/',
    '/apache2',
    'apache2',
    '/sites-available/',
    '000-default/'
) == '/etc/init.d/apache2/apache2/sites-available/000-default/'
	assert candidate(
    'a/b',
    'c/d/',
    'e'
) == 'a/b/c/d/e'
	assert candidate('', '', '', '/', '', '/') == '/'
	assert candidate(
    'foo/',
    'bar/',
    'baz',
    'bif/'
) == 'foo/bar/baz/bif/'
	assert candidate(
    'home/user',
    'bin',
    'file.txt'
) == 'home/user/bin/file.txt'
	assert candidate(   'a', 'b/', 'c', 'd' ) == 'a/b/c/d'
	assert candidate('foo', 'bar', 'baz/') == 'foo/bar/baz/'
	assert candidate(
    '/a/b',
    'c/d'
) == '/a/b/c/d'
	assert candidate(
    '/home/', 'user/', 'project/', 'dir1/', 'dir2', 'file.ext') == \
    '/home/user/project/dir1/dir2/file.ext'
	assert candidate(
    '/etc/',
    '/var/',
    'opt/',
    'home/',
    '/usr/local/',
    '/bin/',
    ) == '/etc/var/opt/home/usr/local/bin/'
	assert candidate( 'a', 'b', 'c', 'd', 'e' ) == 'a/b/c/d/e'
	assert candidate(
    '/home/user/',
    'bin/',
    'file.txt'
) == '/home/user/bin/file.txt'
	assert candidate(
    '/root/',
    'home/',
    'test/',
    'test2/',
    'test3/',
) == '/root/home/test/test2/test3/'
	assert candidate( '/foo', 'bar/', '/baz') == '/foo/bar/baz'
	assert candidate( '/a', 'b', 'c' ) == '/a/b/c'
	assert candidate( '' ) == ''
	assert candidate(
    '/root/',
    'home',
    'test',
    'test2',
    'test3/',
) == '/root/home/test/test2/test3/'
	assert candidate(
    '/root',
    'home/',
    'test',
    'test2/',
    'test3',
) == '/root/home/test/test2/test3'
	assert candidate(
    'foo',
    'bar',
    '',
    'qux'
) == 'foo/bar/qux'
	assert candidate( 'a/', 'b', 'c/', '/' ) == 'a/b/c/'
	assert candidate( '/foo/', 'bar', 'baz') == '/foo/bar/baz'
	assert candidate('/', '', '', '', '', '') == '/'
	assert candidate(
    'foo',
    'bar',
    'baz',
    'qux',
    'quux',
    'corge'
) == 'foo/bar/baz/qux/quux/corge'
	assert candidate(
    '/etc',
    'init.d',
    'apache2',
    'apache2',
   'sites-available',
    '000-default'
) == '/etc/init.d/apache2/apache2/sites-available/000-default'
	assert candidate(
    '/etc',
    'init.d/',
    '/apache2',
    'apache2',
    '/sites-available/',
    '/000-default/'
) == '/etc/init.d/apache2/apache2/sites-available/000-default/'
	assert candidate( '/a/b/c', 'd/e/f' ) == '/a/b/c/d/e/f'
	assert candidate('', '', '/', '', '', '/') == '/'
	assert candidate( 'a', 'b', 'c', 'd', 'e', 'f', 'g' ) == 'a/b/c/d/e/f/g'
	assert candidate( '/a/', 'b' ) == '/a/b'
	assert candidate( 'a', 'b/', 'c' ) == 'a/b/c'
	assert candidate(
    'foo/bar',
    'baz/qux',
    '/qwe/rty',
) == 'foo/bar/baz/qux/qwe/rty'
	assert candidate(
    'foo',
    'bar',
    'baz',
    'qux'
) == 'foo/bar/baz/qux'
	assert candidate(
    'foo',
    'bar',
    'baz',
    'qux',
    ''
) == 'foo/bar/baz/qux'
	assert candidate(   'a/', 'b/', 'c/', 'd/' ) == 'a/b/c/d/'
	assert candidate( 'a', 'b', 'c', '/' ) == 'a/b/c/'
	assert candidate(
    'a/b/',
    'c/d/',
    'e'
) == 'a/b/c/d/e'
def test_check():
	check(cpjoin)
