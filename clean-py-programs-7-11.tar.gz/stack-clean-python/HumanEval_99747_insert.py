def insert(L1,L):
    """ insert L1 in L in the first places with -1 in L, and return L"""
	### Canonical solution below ###    
    k=0
    for j in range(len(L)):
        if L[j] > -1:
            continue
        else:
            L[j] = L1[k]
            k = k+1
            if k >= len(L1):
                break
    return L

### Unit tests below ###
def check(candidate):
	assert candidate( [1,2], [-1, -1, -1]) == [1,2,-1]
	assert candidate( [1,2,3], [-1,-1,-1] ) == [1,2,3]
	assert candidate( [1,2,3], [1,2,3,4,5] ) == [1,2,3,4,5]
	assert candidate( [1,2,3], [-1,-1,-1,-1,-1] ) == [1,2,3,-1,-1]
	assert candidate( [1,2,3,4,5], [-1,-1,-1,-1,-1]) == [1,2,3,4,5]
	assert candidate( [1, 2, 3], [-1, -1, -1]) == [1, 2, 3]
	assert candidate( [1,2,3], [-1, -1, -1]) == [1,2,3]
def test_check():
	check(insert)
