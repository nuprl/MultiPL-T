def strip(s):
    """ Remove leading and trailing characters from string """
	### Canonical solution below ###    

    return s.strip()

### Unit tests below ###
def check(candidate):
	assert candidate('\ntest\n') == 'test'
	assert candidate("  abc") == "abc"
	assert candidate(" abc") == "abc"
	assert candidate("None ") == "None"
	assert candidate('\t\n\r\f\v a \t\n\r\f\v') == 'a'
	assert candidate("  Hello, World") == "Hello, World"
	assert candidate(u' a  ') == u'a'
	assert candidate('  a  b  ') == 'a  b'
	assert candidate('   ') == ''
	assert candidate('   a   ') == 'a'
	assert candidate("None") == "None"
	assert candidate('    ') == ''
	assert candidate(u'\t\n\r\f\v a \t\n\r\f\v') == u'a'
	assert candidate("a ") == "a"
	assert candidate(u' ') == u''
	assert candidate('  test') == 'test'
	assert candidate('a ') == 'a'
	assert candidate('\n\ta\n') == 'a'
	assert candidate("  ") == ""
	assert candidate('a   ') == 'a'
	assert candidate("abc   ") == "abc"
	assert candidate(' a b ') == 'a b'
	assert candidate('  abc') == 'abc'
	assert candidate("   ") == ""
	assert candidate(' a   b') == 'a   b'
	assert candidate(' \n\ntest\n\n ') == 'test'
	assert candidate("a") == "a"
	assert candidate(u'') == u''
	assert candidate(' a   b ') == 'a   b'
	assert candidate('a\n\n') == 'a'
	assert candidate(u"   \u00A0Hello World  ") == u"Hello World"
	assert candidate("1234") == "1234"
	assert candidate('  test  ') == 'test'
	assert candidate(" abc  ") == "abc"
	assert candidate("  1234  ") == "1234"
	assert candidate("   abc") == "abc"
	assert candidate('  a') == 'a'
	assert candidate(' abc') == 'abc'
	assert candidate("   abc   ") == "abc"
	assert candidate("hello") == "hello"
	assert candidate("   Hello World  ") == "Hello World"
	assert candidate("     ") == ""
	assert candidate("Hello, World  ") == "Hello, World"
	assert candidate('  a  ') == 'a'
	assert candidate('a') == 'a'
	assert candidate('a\t\n') == 'a'
	assert candidate("  abc  ") == "abc"
	assert candidate("abc") == "abc"
	assert candidate('a\n\n\n') == 'a'
	assert candidate(u"   Hello World  ") == u"Hello World"
	assert candidate(' a   b   c') == 'a   b   c'
	assert candidate('\t\n') == ''
	assert candidate(u'  a  b  ') == u'a  b'
	assert candidate(" ") == ""
	assert candidate("Hello World") == "Hello World"
	assert candidate('  abc  ') == 'abc'
	assert candidate(' a') == 'a'
	assert candidate('a   b ') == 'a   b'
	assert candidate('\ta') == 'a'
	assert candidate('abc ') == 'abc'
	assert candidate(' a   b   c ') == 'a   b   c'
	assert candidate('   a   b   ') == 'a   b'
	assert candidate(u' a') == u'a'
	assert candidate(u'  a') == u'a'
	assert candidate('a   b') == 'a   b'
	assert candidate('  ') == ''
	assert candidate('abc  ') == 'abc'
	assert candidate('  a b c  ') == 'a b c'
	assert candidate(' a  ') == 'a'
	assert candidate(u'  a  ') == u'a'
	assert candidate('  foo  ') == 'foo'
	assert candidate(u"   \u3000Hello World  ") == u"Hello World"
	assert candidate('a   b   c ') == 'a   b   c'
	assert candidate('test  ') == 'test'
	assert candidate('a   b   c') == 'a   b   c'
	assert candidate("  Hello World  ") == "Hello World"
	assert candidate("  Hello, World  ") == "Hello, World"
	assert candidate("  a  ") == "a"
	assert candidate(' abc ') == 'abc'
	assert candidate(' a ') == 'a'
	assert candidate(' foo ') == 'foo'
	assert candidate(' ') == ''
	assert candidate("") == ""
	assert candidate(" hello ") == "hello"
	assert candidate('a\n') == 'a'
	assert candidate(' a a ') == 'a a'
	assert candidate('abc') == 'abc'
	assert candidate("  \t\n\r  Hello  World!  \t\n\r  ") == "Hello  World!"
	assert candidate("abc  ") == "abc"
	assert candidate(" None") == "None"
	assert candidate(u' a ') == u'a'
	assert candidate(" None ") == "None"
	assert candidate(u'  ') == u''
	assert candidate("Hello, World") == "Hello, World"
	assert candidate(" a ") == "a"
	assert candidate('') == ''
	assert candidate("abc ") == "abc"
	assert candidate('   abc    ') == 'abc'
	assert candidate('test') == 'test'
	assert candidate(u"   \u2000Hello World  ") == u"Hello World"
	assert candidate('   a') == 'a'
	assert candidate(" \t\n") == ""
	assert candidate("  hello  ") == "hello"
	assert candidate('a\t\t') == 'a'
	assert candidate('a\t\n\n') == 'a'
	assert candidate('a\t') == 'a'
	assert candidate(" a b ") == "a b"
	assert candidate(" a") == "a"
	assert candidate(" abc ") == "abc"
def test_check():
	check(strip)
