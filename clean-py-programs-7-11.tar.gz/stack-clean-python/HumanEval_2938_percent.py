def percent(part, whole, need_per=True):
    """
    Percent
    :param part:
    :param whole:
    :param need_per:
    :return:
    """
    ### Canonical solution below ###
    if need_per:
        per = '%'
    else:
        per = ''
    if part == 0 and whole == 0:
        return 0
    return '{0}{1}'.format(100 * float(part) / float(whole), per)


### Unit tests below ###
def check(candidate):
	assert candidate(1, 2) == '50.0%'
	assert candidate(0, 0, False) == 0
	assert candidate(0, 0, True) == 0
	assert candidate(1, 2, True) == '50.0%'
	assert candidate(0, 0) == 0
def test_check():
	check(percent)
