def _has_capability(est, method: str) -> bool:
    """Check whether estimator has capability of method."""
    ### Canonical solution below ###
    if not hasattr(est, method):
        return False
    if method == "inverse_transform":
        return est.get_class_tag("capability:inverse_transform", False)
    return True


### Unit tests below ###
def check(candidate):
	assert candidate(None, "get_class_tag") == False
	assert candidate(None, "inverse_transform") == False
	assert candidate(None, "fit") == False
	assert candidate(None, "fit") is False
	assert candidate(None, "transform") == False
	assert candidate(None, "set_params") == False
	assert candidate(None, "get_params") == False
	assert candidate(None, "inverse_transform") is False
def test_check():
	check(_has_capability)
