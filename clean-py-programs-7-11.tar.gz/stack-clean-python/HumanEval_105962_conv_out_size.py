def conv_out_size(input_size, kernel_size, stride=1, padding=0):
    """ Calculate the output size of convolution operation on the input.
     
     Parameters
     ----------
     input_size : int
     Row/Column size of the input tensor.
     kernel_size : int
     Kernel size of the convolution filter.
     stride : int, default 1
     Stride of the convolution filter.
     padding : int, default 0
     The amount of padding added to the input's given dimension.
     
     Returns
     -------
     int
     Output size of the convolution operation on the given input's dimension.
     
     Notes
     -----
     .. math:: n_{out} = \lfloor\\frac{n_{in} + 2 * p - k}{s}\\rfloor + 1
     
     Examples
     --------
     >>> x = np.random.random((5, 5))
     >>> conv_out_size(x.shape[0], kernel_size=2, stride=2, padding=1)
     3
     """
	### Canonical solution below ###    
    return (input_size + 2 * padding - kernel_size) // stride + 1

### Unit tests below ###
def check(candidate):
	assert candidate(input_size=10, kernel_size=1, stride=1, padding=0) == 10
	assert candidate(10, 4) == 7
	assert candidate(10, 2, 1, 0) == 9
	assert candidate(28, 3, 2, 1) == 14
	assert candidate(5, 2, stride=2) == 2
	assert candidate(1, kernel_size=2, stride=1, padding=0) == 0
	assert candidate(3, 2, 1, 0) == 2
	assert candidate(5, kernel_size=2, stride=2, padding=1) == 3
	assert candidate(4, 4) == 1
	assert candidate(3, kernel_size=1, stride=1, padding=0) == 3
	assert candidate(1, 1) == 1
	assert candidate(2, kernel_size=2, stride=1, padding=0) == 1
	assert candidate(2, 3) == 0
	assert candidate(input_size=1, kernel_size=1, stride=1, padding=0) == 1
	assert candidate(10, kernel_size=3, stride=3, padding=1) == 4
	assert candidate(1, 2) == 0
	assert candidate(input_size=10, kernel_size=3, stride=2, padding=1) == 5
	assert candidate(2, kernel_size=2, stride=1, padding=1) == 3
	assert candidate(5, 2, 2, 0) == 2
	assert candidate(10, kernel_size=3, stride=2, padding=1) == 5
	assert candidate(10, 3, padding=2) == 12
	assert candidate(1, kernel_size=1, stride=1, padding=1) == 3
	assert candidate(input_size=2, kernel_size=1, stride=1, padding=0) == 2
	assert candidate(3, kernel_size=3, stride=3, padding=1) == 1
	assert candidate(3, 3) == 1
	assert candidate(3, kernel_size=3, stride=1, padding=0) == 1
	assert candidate(3, 4) == 0
	assert candidate(2, 2) == 1
	assert candidate(2, 2, 1, 0) == 1
	assert candidate(5, 3, 2, 1) == 3
	assert candidate(input_size=5, kernel_size=2, stride=2, padding=1) == 3
	assert candidate(5, 2, stride=1, padding=0) == 4
	assert candidate(2, kernel_size=3, stride=2, padding=1) == 1
	assert candidate(1, kernel_size=1, stride=1, padding=0) == 1
	assert candidate(10, 3, 2, 1) == 5
	assert candidate(28, 2, 2, 0) == 14
	assert candidate(3, 2, 2, 0) == 1
	assert candidate(2, 1) == 2
	assert candidate(4, 5) == 0
	assert candidate(10, kernel_size=2, stride=1, padding=0) == 9
	assert candidate(6, 5) == 2
	assert candidate(5, 2, stride=2, padding=1) == 3
	assert candidate(10, 3) == 8
	assert candidate(5, 2, 2, 1) == 3
	assert candidate(5, 5) == 1
	assert candidate(3, kernel_size=3, stride=3, padding=0) == 1
	assert candidate(10, kernel_size=3, stride=1, padding=1) == 10
	assert candidate(20, 3, 2, 0) == 9
	assert candidate(5, 2, 1, 0) == 4
def test_check():
	check(conv_out_size)
