def isPrime(n: int)->bool:
    """ 
     Give an Integer 'n'. Check if 'n' is Prime or Not
     :param n:
     :return: bool - True or False
     A no. is prime if it is divisible only by 1 & itself.
     1- is neither Prime nor Composite
     
     - check for n being a even number i.e divisble by 2
     - check for n being divisible by 3
     - then create a range of i following series, 5,7,11,13,17,19,23,.... till sqrt(n) with step as +6
     - check for divisibility of n with each value of i & i+2
     """
	### Canonical solution below ###    
    if n== 1:
        return False
    # handle boundary conditions
    if n == 2 or n==3:
        return True
    # Now check for divisibility of n by 2 & 3
    if n % 2 ==0 or n % 3 ==0:
        return False

    i = 5
    while (i*i <= n):
        if n%i ==0 or n%(i+2) ==0:
            return False

        i = i+ 6
    return True

### Unit tests below ###
def check(candidate):
	assert candidate(103) == True
	assert candidate(27)== False
	assert candidate(26)==False
	assert candidate(13)== True
	assert candidate(11)==True
	assert candidate(6) == False
	assert candidate(33) == False
	assert candidate(31)== True
	assert candidate(2)== True
	assert candidate(30) == False
	assert candidate(44)== False
	assert candidate(34)== False
	assert candidate(0)==False
	assert candidate(108) == False
	assert candidate(37)==True
	assert candidate(29) == True
	assert candidate(45)== False
	assert candidate(30)== False
	assert candidate(5)==True
	assert candidate(32)==False
	assert candidate(42) == False
	assert candidate(35)==False
	assert candidate(17) == True
	assert candidate(105) == False
	assert candidate(14)== False
	assert candidate(16)==False
	assert candidate(5)== True
	assert candidate(19)==True
	assert candidate(37) == True
	assert candidate(24) == False
	assert candidate(8)==False
	assert candidate(5) == True
	assert candidate(1012) == False
	assert candidate(31) == True
	assert candidate(35) == False
	assert candidate(101) == True
	assert candidate(18)==False
	assert candidate(46)== False
	assert candidate(40) == False
	assert candidate(16) == False
	assert candidate(23)== True
	assert candidate(9)==False
	assert candidate(19) == True
	assert candidate(3)==True
	assert candidate(109) == True
	assert candidate(15)== False
	assert candidate(11) == True
	assert candidate(27) == False
	assert candidate(1)== False
	assert candidate(28)==False
	assert candidate(13) == True
	assert candidate(24)== False
	assert candidate(13)==True
	assert candidate(36) == False
	assert candidate(22)== False
	assert candidate(15)==False
	assert candidate(42)== False
	assert candidate(42)==False
	assert candidate(6)== False
	assert candidate(17)== True
	assert candidate(7)== True
	assert candidate(36)==False
	assert candidate(1010) == False
	assert candidate(39)==False
	assert candidate(102) == False
	assert candidate(28)== False
	assert candidate(34) == False
	assert candidate(26)== False
	assert candidate(16)== False
	assert candidate(18)== False
	assert candidate(12) == False
	assert candidate(107) == True
	assert candidate(1009) == True
	assert candidate(25) == False
	assert candidate(3)== True
	assert candidate(4)== False
	assert candidate(39)== False
	assert candidate(8) == False
	assert candidate(4) == False
	assert candidate(22) == False
	assert candidate(32) == False
	assert candidate(9)== False
	assert candidate(7) == True
	assert candidate(1013) == True
	assert candidate(10)==False
	assert candidate(3) == True
	assert candidate(1) == False
	assert candidate(41) == True
	assert candidate(6)==False
	assert candidate(9) == False
	assert candidate(1)==False
	assert candidate(15) == False
	assert candidate(23)==True
	assert candidate(4)==False
	assert candidate(45)==False
	assert candidate(38) == False
	assert candidate(21)== False
	assert candidate(38)==False
	assert candidate(10)== False
	assert candidate(7)==True
	assert candidate(21)==False
	assert candidate(30)==False
	assert candidate(40)== False
	assert candidate(2) == True
	assert candidate(20)==False
	assert candidate(22)==False
	assert candidate(23) == True
	assert candidate(106) == False
	assert candidate(35)== False
	assert candidate(28) == False
	assert candidate(12)==False
	assert candidate(34)==False
	assert candidate(46)==False
	assert candidate(19)== True
	assert candidate(38)== False
	assert candidate(36)== False
	assert candidate(1015) == False
	assert candidate(39) == False
	assert candidate(20) == False
	assert candidate(11)== True
	assert candidate(1016) == False
	assert candidate(1014) == False
	assert candidate(33)==False
	assert candidate(17)==True
	assert candidate(10) == False
	assert candidate(12)== False
	assert candidate(44)==False
	assert candidate(32)== False
	assert candidate(24)==False
	assert candidate(110) == False
	assert candidate(40)==False
	assert candidate(14) == False
	assert candidate(104) == False
	assert candidate(2)==True
	assert candidate(25)==False
	assert candidate(37)== True
	assert candidate(25)== False
	assert candidate(18) == False
	assert candidate(21) == False
	assert candidate(26) == False
	assert candidate(20)== False
	assert candidate(8)== False
	assert candidate(14)==False
	assert candidate(33)== False
def test_check():
	check(isPrime)
