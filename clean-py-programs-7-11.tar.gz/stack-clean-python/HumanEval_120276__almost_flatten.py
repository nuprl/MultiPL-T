def _almost_flatten(metrics):
    """Turn a nested list (e.g. ['foo', ['bar', 'baz', ['tor, 'tar']]] into
    a flattened list of names anchored at the first element:
    [["foo", "bar", "baz", "tor"],
     ["foo", "bar", "baz", "tar"]]

    Two notes for posterity.: This does extra work, recursinge too
    often.  Also up the stack, the caller needs to remove duplicates.
    The order of top-level metrics are expected to be small, maybe
    10-20, so the extra work shouldn't be explosively bad.  If it ever
    gets that way, then fix this hack.

    """
    ### Canonical solution below ###
    metric_part_list = list()
    metric_head = metrics[0]
    metric_tail = metrics[1:]
    # print "metric_head, metric_tail: {0}, {1}".format(metric_head, metric_tail)
    if metric_tail == []:
        return [metric_head]
    for mt in metric_tail:
        result = _almost_flatten(mt)
        # print "result is {0}".format(result)
        for r in result:
            tail_list   = list()
            tail_list.append(metric_head)
            if type(r) in (type(list()), type(tuple())):
                tail_list.extend(r)
            else:
                tail_list.append(r)
            metric_part_list.append(tail_list)
    return metric_part_list


### Unit tests below ###
def check(candidate):
	assert candidate(list(['foo'])) == ['foo']
	assert candidate( ["foo", ["bar", "baz", ["tor", "tar"]]] )!= [["foo", "bar", "baz", "tor"], ["foo", "bar", "baz", "tar"], ["foo", "bar", "baz", "tor"]]
	assert candidate( ["foo", ["bar", "baz", ["tor", "tar"]]] )!= [["foo", "bar", "baz", "tar"], ["foo", "bar", "baz", "tor"]]
	assert candidate( ["foo", ["bar", "baz", ["tor", "tar"]]] )!= [["foo", "bar", "baz", "tor"], ["foo", "bar", "baz", "tor"]]
	assert candidate( ["foo", ["bar", "baz", ["tor", "tar"]]] )!= [["foo", "bar", "baz", "tor"], ["foo", "bar", "baz", "tar"], ["foo", "bar", "baz", "tar"]]
def test_check():
	check(_almost_flatten)
