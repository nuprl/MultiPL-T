def sanity_check_values(value):
    """We note that the leading - is often missed, but the ones within the block less so, so we
    have a sanity check here and see if adding a -ve to the first value helps"""
    ### Canonical solution below ###

    if not value[1] < value[0] < value[2]:
        if value[1] < -value[0] < value[2]:
            value = (-value[0], value[1], value[2])
    return value


### Unit tests below ###
def check(candidate):
	assert candidate(tuple([-1, -2, 4])) == tuple([-1, -2, 4])
	assert candidate( (0, 1, 1) ) == (0, 1, 1)
	assert candidate(
    (-1, 0, 1)
) == (-1, 0, 1)
	assert candidate( (3, 1, 2) ) == (3, 1, 2)
	assert candidate(
    (-1, 0, -1)
) == (-1, 0, -1)
	assert candidate( (-3, -1, 2) ) == (-3, -1, 2)
	assert candidate( (1, 1, 0) ) == (1, 1, 0)
	assert candidate( (1, 1, -1) ) == (1, 1, -1)
	assert candidate( (-1.0, -1.0, -1.0) ) == (-1.0, -1.0, -1.0)
	assert candidate( (1, 0, 2) ) == (1, 0, 2)
	assert candidate((0, -10, 10)) == (0, -10, 10)
	assert candidate( (-1,2,3) ) == (-1,2,3)
	assert candidate( (0, 1, 0) ) == (0, 1, 0)
	assert candidate( (-1, 1, 1) ) == (-1, 1, 1)
	assert candidate(
    (0, -1, 1)) == (0, -1, 1)
	assert candidate(value=(0, -1, -2)) == (-0, -1, -2)
	assert candidate(
    (0, -1, 0)) == (0, -1, 0)
	assert candidate( (1, 1, 2) ) == (1, 1, 2)
	assert candidate(tuple([-1, 2, 4])) == tuple([-1, 2, 4])
	assert candidate(
    (0, -1, -1)) == (0, -1, -1)
	assert candidate(value=(1, 2, 3)) == (1, 2, 3)
	assert candidate( (-1, 3, 2) ) == (-1, 3, 2)
	assert candidate( (-1, 1, 2) ) == (-1, 1, 2)
	assert candidate( (1, 0, 0) ) == (1, 0, 0)
	assert candidate( (3, -1, -2) ) == (3, -1, -2)
	assert candidate(tuple(-10 for _ in range(3))) == tuple(-10 for _ in range(3))
	assert candidate( (-1, -2, 3) ) == (-1, -2, 3)
	assert candidate(
    (0, 1, 1)) == (0, 1, 1)
	assert candidate(
    (-1, -1, 1)
) == (-1, -1, 1)
	assert candidate( (-1.0, 1.0, -1.0) ) == (-1.0, 1.0, -1.0)
	assert candidate(value=(0, -1, 2)) == (0, -1, 2)
	assert candidate(value=(1, 2, -3)) == (1, 2, -3)
	assert candidate( (1, -1, -1) ) == (1, -1, -1)
	assert candidate( (0, 1, 2) ) == (0, 1, 2)
	assert candidate( (1, 2, 3) ) == (1, 2, 3)
	assert candidate(value=(1, -2, 3)) == (1, -2, 3)
	assert candidate(
    (0, 1, -1)) == (0, 1, -1)
	assert candidate(
    (-1, -1, -1)) == (-1, -1, -1)
	assert candidate(
    (1, 0, 0)) == (1, 0, 0)
	assert candidate(tuple([-1, 0, 1])) == tuple([-1, 0, 1])
	assert candidate(value=(0, 1, -2)) == (-0, 1, -2)
	assert candidate(
    (-1, 1, 2)) == (-1, 1, 2)
	assert candidate( (-3, -1, -2) ) == (-3, -1, -2)
	assert candidate( (1, 0, -1) ) == (1, 0, -1)
	assert candidate(value=(-1, 2, -3)) == (-1, 2, -3)
	assert candidate( (-2, -1, 2) ) == (-2, -1, 2)
	assert candidate(
    (0, 0, 0)) == (0, 0, 0)
	assert candidate(
    (1, 1, 1)
) == (1, 1, 1)
	assert candidate( (-1, 0, 1) ) == (-1, 0, 1)
	assert candidate( (0.5, 0.6, -0.7) ) == (0.5, 0.6, -0.7)
	assert candidate( (1,-2,3) ) == (1,-2,3)
	assert candidate( (0, 0, 0) ) == (0, 0, 0)
	assert candidate( (-0.5, -0.6, 0.7) ) == (-0.5, -0.6, 0.7)
	assert candidate(
    (0, 1, 0)) == (0, 1, 0)
	assert candidate( (-3, 1, 2) ) == (-3, 1, 2)
	assert candidate(
    (10.0, -1.0, 12.0)) == (10.0, -1.0, 12.0)
	assert candidate(
    (0, 1, 2)) == (0, 1, 2)
	assert candidate( (-2, 1, 2) ) == (-2, 1, 2)
	assert candidate(
    (10.0, -1.0, -12.0)) == (10.0, -1.0, -12.0)
	assert candidate(
    (1, 0, 0)
) == (1, 0, 0)
	assert candidate(value=(-1, 2, 3)) == (-1, 2, 3)
	assert candidate( (1,2,3) ) == (1,2,3)
	assert candidate( (-1, 2, -3) ) == (-1, 2, -3)
	assert candidate(value=(-1, -2, -3)) == (-1, -2, -3)
	assert candidate(
    (-1, -1, 0)
) == (-1, -1, 0)
	assert candidate( (5, 0, 10) ) == (5, 0, 10)
	assert candidate(value=(-1, -2, 3)) == (-1, -2, 3)
	assert candidate( (-1, -2, -3) ) == (-1, -2, -3)
	assert candidate(
    (1, 0, -1)) == (1, 0, -1)
	assert candidate(
    (1, 1, 0)) == (1, 1, 0)
	assert candidate( (-1.0, 1.0, 1.0) ) == (-1.0, 1.0, 1.0)
	assert candidate( (1.0, 1.0, 1.0) ) == (1.0, 1.0, 1.0)
	assert candidate(value=(1, -2, -3)) == (1, -2, -3)
	assert candidate( (-2, 1, -2) ) == (-2, 1, -2)
	assert candidate( (1, 0, 1) ) == (1, 0, 1)
	assert candidate(
    (0, 0, 0)
) == (0, 0, 0)
	assert candidate( (-3, 1, -2) ) == (-3, 1, -2)
	assert candidate( (1, 2, 2) ) == (1, 2, 2)
	assert candidate( (-1,-2,3) ) == (-1,-2,3)
	assert candidate(
    (-1, 1, 1)
) == (-1, 1, 1)
	assert candidate( (0.5, 0.6, 0.7) ) == (0.5, 0.6, 0.7)
	assert candidate(tuple(10 for _ in range(3))) == tuple(10 for _ in range(3))
	assert candidate(
    (-10.0, -1.0, 12.0)) == (10.0, -1.0, 12.0)
	assert candidate( (-0.5, 0.6, 0.7) ) == (-0.5, 0.6, 0.7)
	assert candidate(
    (1, 0, 1)
) == (1, 0, 1)
	assert candidate( (-0.5, -0.6, -0.7) ) == (-0.5, -0.6, -0.7)
	assert candidate( (1, 2, 3)) == (1, 2, 3)
	assert candidate( (-1,-2,-3) ) == (-1,-2,-3)
	assert candidate(
    (1, 0, 1)) == (1, 0, 1)
	assert candidate(
    (10.0, 1.0, 12.0)) == (10.0, 1.0, 12.0)
	assert candidate( (-1, 0, -2) ) == (-1, 0, -2)
	assert candidate(
    (1, 1, 1)) == (1, 1, 1)
	assert candidate(
    (0, 0, 1)) == (0, 0, 1)
	assert candidate( (1.0, -1.0, 1.0) ) == (1.0, -1.0, 1.0)
	assert candidate(tuple([-1, -1, 1])) == tuple([-1, -1, 1])
	assert candidate(
    (-4.0, -0.40000000000000002, 0.40000000000000002)
) == (-4.0, -0.4, 0.4)
	assert candidate(
    (10.0, 1.0, -12.0)) == (10.0, 1.0, -12.0)
	assert candidate( (3, 1, -2) ) == (3, 1, -2)
	assert candidate( (0, 0, 1) ) == (0, 0, 1)
	assert candidate( (1, 1, 1) ) == (1, 1, 1)
	assert candidate( (-0.5, 0.6, -0.7) ) == (-0.5, 0.6, -0.7)
	assert candidate( (3, -1, 2) ) == (3, -1, 2)
	assert candidate(value=(0, 1, 2)) == (0, 1, 2)
	assert candidate(
    (1, 1, 0)
) == (1, 1, 0)
	assert candidate(
    (0, 1, 0)
) == (0, 1, 0)
	assert candidate(
    (-1, 1, 0)
) == (-1, 1, 0)
	assert candidate(
    (0, 0, 1)
) == (0, 0, 1)
	assert candidate(
    (0, 0, -1)) == (0, 0, -1)
	assert candidate( (1, -1, 1) ) == (1, -1, 1)
def test_check():
	check(sanity_check_values)
