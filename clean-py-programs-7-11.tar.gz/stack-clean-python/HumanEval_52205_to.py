def to(value, dtype):
    """Force conversion to int data type. If failed return 0:
    dtype: int8, int32, int64"""
    ### Canonical solution below ###
    isfloat = "float" in str(dtype)
    try:
        return dtype(value)
    except:
        return 0 if not isfloat else 0.0


### Unit tests below ###
def check(candidate):
	assert candidate(1, float) == 1.0
	assert candidate(123, int) == 123
	assert candidate("", float) == 0.0
	assert candidate("None", float) == 0.0
	assert candidate("1.2", float) == 1.2
	assert candidate(123, float) == 123.0
	assert candidate(None, float) == 0.0
	assert candidate("", int) == 0
	assert candidate("10.0", float) == 10.0
	assert candidate(1, str) == "1"
	assert candidate(10.0, int) == 10
	assert candidate("10.1", float) == 10.1
	assert candidate(10.5, int) == 10
	assert candidate("10", str) == "10"
	assert candidate(1.2, int) == 1
	assert candidate(2.1, int) == 2
	assert candidate("123.0", str) == "123.0"
	assert candidate("abc", int) == 0
	assert candidate("10.5", float) == 10.5
	assert candidate("1.1", float) == 1.1
	assert candidate("3.0", float) == 3.0
	assert candidate(0, float) == 0.0
	assert candidate("2.1", int) == 0
	assert candidate("1.9", float) == 1.9
	assert candidate(1.23, float) == 1.23
	assert candidate(1, float) == candidate(1.0, float)
	assert candidate("None", int) == 0
	assert candidate("1.6", float) == 1.6
	assert candidate("10.5", str) == "10.5"
	assert candidate("1.5", float) == 1.5
	assert candidate("10", float) == 10.0
	assert candidate("0", float) == 0.0
	assert candidate(10.5, float) == 10.5
	assert candidate(10.5, str) == "10.5"
	assert candidate(1.1, int) == 1
	assert candidate(10, str) == "10"
	assert candidate(123456789123456789123456789, float) == 123456789123456789123456789.0
	assert candidate(123.0, int) == 123
	assert candidate(123.4, float) == 123.4
	assert candidate(1.5, int) == 1
	assert candidate(123.0, str) == "123.0"
	assert candidate(1, int) == 1
	assert candidate("1", str) == "1"
	assert candidate("123.0", float) == 123.0
	assert candidate("0", int) == 0
	assert candidate(False, int) == 0
	assert candidate(1.23, int) == 1
	assert candidate(1.0, float) == 1.0
	assert candidate(3.0, float) == 3.0
	assert candidate(10, float) == 10.0
	assert candidate(10.0, str) == "10.0"
	assert candidate(1.5, float) == 1.5
	assert candidate("1.8", float) == 1.8
	assert candidate(False, float) == 0.0
	assert candidate(1.2, float) == 1.2
	assert candidate("abc", float) == 0.0
	assert candidate(123, str) == "123"
	assert candidate("1.3", float) == 1.3
	assert candidate("123", int) == 123
	assert candidate("123", str) == "123"
	assert candidate("a", int) == 0
	assert candidate("1.4", float) == 1.4
	assert candidate("123", float) == 123.0
	assert candidate("1.7", float) == 1.7
	assert candidate(123.0, float) == 123.0
	assert candidate("1", int) == 1
	assert candidate(True, float) == 1.0
	assert candidate(1, bool) == True
	assert candidate(None, int) == 0
	assert candidate(2.1, float) == 2.1
	assert candidate("1.0", float) == 1.0
	assert candidate(123.4, int) == 123
	assert candidate(1.0, int) == 1
	assert candidate("a", float) == 0.0
	assert candidate("2.1", float) == 2.1
	assert candidate(3.0, int) == 3
	assert candidate("1.0", str) == "1.0"
	assert candidate("1", float) == 1.0
	assert candidate(1, int) == candidate(1.0, int)
	assert candidate("10", int) == 10
	assert candidate(True, int) == 1
	assert candidate(1.9, int) == 1
	assert candidate(1.0, str) == "1.0"
	assert candidate(10, int) == 10
	assert candidate("123.4", float) == 123.4
	assert candidate(0, int) == 0
	assert candidate("", str) == ""
def test_check():
	check(to)
