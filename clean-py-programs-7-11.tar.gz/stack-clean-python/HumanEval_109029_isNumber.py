def isNumber(v):
    """
    test if object can be converted to a number
    return true if yes, false if no
    """
    ### Canonical solution below ###
    try:
        float(v)
        return True
    except ValueError:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate(1.0) == True
	assert candidate(-1.01) == True
	assert candidate("1,01") == False
	assert candidate("1.2") == True
	assert not candidate("a5")
	assert candidate("a10") == False
	assert candidate("1")
	assert candidate("1e10")
	assert candidate("5.0")
	assert candidate("a1a") == False
	assert candidate('1.0')
	assert candidate(" a") == False
	assert candidate("1.2e1")
	assert candidate('1.0') == True
	assert candidate("1.01a") == False
	assert candidate("3.14") == True
	assert candidate("1.0")
	assert candidate("123.456789") == True
	assert candidate(100.0)
	assert candidate('100')
	assert candidate("1a") == False
	assert candidate("a") == False
	assert not candidate("1.2e-1a")
	assert candidate("1,1") == False
	assert candidate("a1.01") == False
	assert not candidate("1.2e+1a")
	assert candidate("10.0.0") == False
	assert candidate("1e-1")
	assert candidate('1.1') == True
	assert candidate("1.one") == False
	assert candidate("123") == True
	assert candidate(10) == True
	assert candidate(-1.0e-10)
	assert candidate(b'100')
	assert candidate("1e1")
	assert candidate("1a23") == False
	assert candidate(5)
	assert not candidate("1.a")
	assert candidate("1.23a") == False
	assert candidate("1.2e-1")
	assert candidate(100)
	assert candidate("one.1") == False
	assert candidate(1.0e10)
	assert candidate("a1") == False
	assert candidate(1.0e-10)
	assert candidate("1.2e10")
	assert not candidate("")
	assert candidate("3") == True
	assert candidate("1e+1")
	assert not candidate("5,0")
	assert candidate('1') == True
	assert candidate("123456789") == True
	assert candidate("1e+10")
	assert candidate('1.0.a') == False
	assert candidate(1.01) == True
	assert candidate(3) == True
	assert candidate("10a") == False
	assert not candidate("1.0 + 1j")
	assert candidate(0.0) == True
	assert candidate('1.0.0') == False
	assert not candidate("string")
	assert candidate(1.23) == True
	assert candidate("5e-2")
	assert candidate("1e-10")
	assert candidate(1.1) == True
	assert candidate(10.0) == True
	assert candidate('x') == False
	assert candidate(True)
	assert candidate(" ") == False
	assert candidate("1.0") == True
	assert not candidate(" ")
	assert candidate(1e10)
	assert candidate("0") == True
	assert candidate("1") == True
	assert candidate("1.2e+1")
	assert not candidate("  ")
	assert not candidate("1.2a")
	assert not candidate("5-2")
	assert candidate(-1)
	assert candidate(1) == True
	assert candidate("-1") == True
	assert candidate('a') == False
	assert candidate(3.0) == True
	assert candidate(5.0)
	assert candidate("1.2")
	assert not candidate("a")
	assert candidate("one") == False
	assert candidate("3.0") == True
	assert candidate("10.0") == True
	assert candidate(1)
	assert candidate(bytearray(b'100'))
	assert candidate("hello") == False
	assert candidate(u"5.0")
	assert candidate(0) == True
	assert candidate("1.2e-10")
	assert candidate(-1.0e10)
	assert candidate("5")
	assert candidate("10") == True
	assert candidate(123456789) == True
	assert candidate(u"5e-2")
	assert candidate("a ") == False
	assert not candidate("5 0")
	assert candidate(1.2) == True
	assert candidate(False)
	assert candidate(1.0)
	assert candidate('True') == False
	assert not candidate("1.2.a")
	assert candidate("a1.23") == False
	assert candidate(1e-10)
	assert candidate("") == False
	assert candidate(-1.0)
	assert candidate("1.1") == True
	assert candidate("1 01") == False
	assert candidate(123.456789) == True
	assert candidate("1.23a45") == False
	assert not candidate("1a")
	assert candidate("-1.23") == True
	assert candidate(1.2)
	assert not candidate("5a")
	assert not candidate("a1")
	assert candidate("a123") == False
	assert candidate("foo") == False
	assert candidate('abc') == False
	assert candidate(1.23)
	assert candidate("a 1.01") == False
	assert candidate("1.01") == True
	assert candidate("hello world") == False
	assert not candidate("1.2e1a")
	assert not candidate('a')
	assert not candidate('1.0.1')
	assert candidate("1.23") == True
def test_check():
	check(isNumber)
