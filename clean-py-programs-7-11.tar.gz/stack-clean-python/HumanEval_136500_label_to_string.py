def label_to_string(x, label_to_char_dict):
    """ 
     x : list
     label_to_char_dict : dict(label, char)
     """
	### Canonical solution below ###    
    batch_sentence = []

    if type(x[0]) == list:
        for i in range(len(x)):
            labels = x[i]
            sentence = ''
            for j in range(len(labels)):
                sentence += label_to_char_dict[labels[j]]
            batch_sentence.append(sentence)

    else:
        sentence = ''
        for j in range(len(x)):
            sentence += label_to_char_dict[x[j]]
        batch_sentence.append(sentence)

    return batch_sentence

### Unit tests below ###
def check(candidate):
	assert candidate(
    [0, 1, 2, 3, 4],
    {0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e'}) == ['abcde']
	assert candidate(
    [[1, 2, 3], [1, 2]],
    {1: 'a', 2: 'b', 3: 'c'}
) == ['abc', 'ab']
	assert candidate(
    [[1, 2, 3], [1, 2]],
    {1: 'a', 2: 'b', 3: 'c', 4: 'd'}
) == ['abc', 'ab']
	assert candidate([[0, 1, 2, 3, 4]], {0:'a', 1:'b', 2:'c', 3:'d', 4:'e'}) == ['abcde']
	assert candidate(x=[0, 1, 2, 3],
                       label_to_char_dict={0: 'A',
                                           1: 'B',
                                           2: 'C',
                                           3: 'D',
                                           4: 'E',
                                           5: 'F'}) == ['ABCD']
	assert candidate([1,2,3], {1:'a', 2:'b', 3:'c', 4:'d'}) == ['abc']
	assert candidate([0, 1, 2, 3], {0: 'a', 1: 'b', 2: 'c', 3: 'd'}) == ['abcd']
	assert candidate([[1, 2, 3], [4, 5, 6]], {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f'}) == ['abc', 'def']
	assert candidate(x=[0, 1, 2, 3],
                       label_to_char_dict={0: 'A',
                                           1: 'B',
                                           2: 'C',
                                           3: 'D'}) == ['ABCD']
	assert candidate(
    [[1, 2, 3]],
    {1: 'a', 2: 'b', 3: 'c'}
) == ['abc']
	assert candidate(x=[[0, 1, 2, 3], [3, 2, 1, 0]],
                       label_to_char_dict={0: 'A',
                                           1: 'B',
                                           2: 'C',
                                           3: 'D'}) == ['ABCD', 'DCBA']
	assert candidate(
    [[0, 1, 2, 3, 4], [1, 2, 3, 4, 5]],
    {0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e', 5: 'f'}) == ['abcde', 'bcdef']
	assert candidate([1, 2, 3], {1: 'a', 2: 'b', 3: 'c'}) == ['abc']
	assert candidate(x=[0, 1, 2, 3],
                       label_to_char_dict={0: 'A',
                                           1: 'B',
                                           2: 'C',
                                           3: 'D',
                                           4: 'E'}) == ['ABCD']
	assert candidate([[0, 1, 2, 3], [3, 2, 1, 0]], {0: 'a', 1: 'b', 2: 'c', 3: 'd'}) == ['abcd', 'dcba']
def test_check():
	check(label_to_string)
