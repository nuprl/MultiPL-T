def surviveG(G_exo):
    """
    Input G
    Output alive or dead; gravity flag; weight coefficient 0-1
    """
    ### Canonical solution below ###
    G_extr = 5
    G_micro = 0.8
    G_hyper = 1.2
    res = {}
    res['G'] = G_exo
    if G_exo < G_micro:
        res['surv'] = True
        res['flag'] = 'micro'
        res['wt'] = 0.5 * G_exo / G_micro
    elif G_exo < G_hyper:
        res['surv'] = True
        res['flag'] = 'normal'
        res['wt'] = 0.5
    elif G_exo < G_extr:
        res['surv'] = True
        res['flag'] = 'hyper'
        res['wt'] = 0.5 + 0.5 * (G_exo - G_hyper) / (G_extr - G_hyper)
    else:
        res['surv'] = False
        res['flag'] = 'extreme'
        res['wt'] = 1
    return (res)


### Unit tests below ###
def check(candidate):
	assert candidate(2.2)['surv'] == True
	assert candidate(1.2)['G'] == 1.2
	assert candidate(0.8)['G'] == 0.8
	assert candidate(0.4)['G'] == 0.4
	assert candidate(5.1) == {'G': 5.1,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(1)['flag'] == 'normal'
	assert candidate(2.5)['surv'] == True
	assert candidate(0.01)['flag'] =='micro'
	assert candidate(6.5)['flag'] == 'extreme'
	assert candidate(1.8)['surv'] == True
	assert candidate(2.0)['flag'] == 'hyper'
	assert candidate(1.2)['surv'] == True
	assert candidate(0.8)['surv'] == True
	assert candidate(1.0)['wt'] == 0.5
	assert candidate(1.5)['flag'] == 'hyper'
	assert candidate(7) == {'G': 7,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(2.2)['G'] == 2.2
	assert candidate(4.5)['surv'] == True
	assert candidate(5.0)['surv'] == False
	assert candidate(1.1) == {'G': 1.1,'surv': True, 'flag': 'normal', 'wt': 0.5}, candidate(1.1)
	assert candidate(1.0) == {'G': 1.0,'surv': True, 'flag': 'normal', 'wt': 0.5}
	assert candidate(5.01)['flag'] == 'extreme'
	assert candidate(6.5)['wt'] == 1
	assert candidate(1) == {'G': 1,'surv': True, 'flag': 'normal', 'wt': 0.5}, candidate(1)
	assert candidate(1.5)['G'] == 1.5
	assert candidate(5) == {'G': 5,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(0.3)['surv'] == True
	assert candidate(6) == {'G': 6,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(0.2)['G'] == 0.2
	assert candidate(0.8)['wt'] == 0.5
	assert candidate(5.2) == {'G': 5.2,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(0.0) == {'G': 0.0,'surv': True, 'flag':'micro', 'wt': 0.0}
	assert candidate(12) == {'G': 12,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(8) == {'G': 8,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(5)['flag'] == 'extreme'
	assert candidate(0.0)['surv'] == True
	assert candidate(0.05)['flag'] =='micro'
	assert candidate(2.1)['surv'] == True
	assert candidate(1.0)['surv'] == True
	assert candidate(4.5)['flag'] == 'hyper'
	assert candidate(1.19)['surv'] == True
	assert candidate(1) == {'G': 1,'surv': True, 'flag': 'normal', 'wt': 0.5}
	assert candidate(0.0)['flag'] =='micro'
	assert candidate(1.1)['flag'] == 'normal'
	assert candidate(1.2)['wt'] == 0.5 + 0.5 * (1.2 - 1.2) / (5 - 1.2)
	assert candidate(5)['surv'] == False
	assert candidate(2.0)['surv'] == True
	assert candidate(5)['wt'] == 1
	assert candidate(1)['wt'] == 0.5
	assert candidate(1.5)['surv'] == True
	assert candidate(0.81)['flag'] == 'normal'
	assert candidate(0.6)['surv'] == True
	assert candidate(5.01)['wt'] == 1
	assert candidate(0.05)['surv'] == True
	assert candidate(0.5)['surv'] == True
	assert candidate(0.9)['flag'] == 'normal'
	assert candidate(1.8)['G'] == 1.8
	assert candidate(0.9)['wt'] == 0.5
	assert candidate(6.5)['surv'] == False
	assert candidate(100) == {'G': 100,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(0.8)['flag'] == 'normal'
	assert candidate(5.6) == {'G': 5.6,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(0.8) == {'G': 0.8,'surv': True, 'flag': 'normal', 'wt': 0.5}, candidate(0.8)
	assert candidate(0.1)['surv'] == True
	assert candidate(5.0)['flag'] == 'extreme'
	assert candidate(5.7) == {'G': 5.7,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(0.5)['G'] == 0.5
	assert candidate(0.81)['wt'] == 0.5
	assert candidate(4)['surv'] == True
	assert candidate(0.8) == {'G': 0.8,'surv': True, 'flag': 'normal', 'wt': 0.5}
	assert candidate(0.9) == {'G': 0.9,'surv': True, 'flag': 'normal', 'wt': 0.5}
	assert candidate(0) == {'G': 0,'surv': True, 'flag':'micro', 'wt': 0.0}
	assert candidate(10) == {'G': 10,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(5.4) == {'G': 5.4,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(50) == {'G': 50,'surv': False, 'flag': 'extreme', 'wt': 1}, candidate(50)
	assert candidate(5.0)['wt'] == 1
	assert candidate(1.0)['flag'] == 'normal'
	assert candidate(1.1)['surv'] == True
	assert candidate(5.01)['surv'] == False
	assert candidate(0.4)['surv'] == True
	assert candidate(0.05)['wt'] == 0.5 * 0.05 / 0.8
	assert candidate(0.1)['G'] == 0.1
	assert candidate(0.0)['G'] == 0.0
	assert candidate(1.2)['wt'] == 0.5
	assert candidate(0.3)['G'] == 0.3
	assert candidate(0.9)['surv'] == True
	assert candidate(1.2)['flag'] == 'hyper'
	assert candidate(0.81)['surv'] == True
	assert candidate(0.2)['surv'] == True
	assert candidate(5.3) == {'G': 5.3,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(5.5) == {'G': 5.5,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(1)['surv'] == True
	assert candidate(5.8) == {'G': 5.8,'surv': False, 'flag': 'extreme', 'wt': 1}
	assert candidate(0.5)['flag'] =='micro'
def test_check():
	check(surviveG)
