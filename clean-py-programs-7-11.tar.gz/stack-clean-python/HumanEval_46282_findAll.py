def findAll(needle, haystack):
    """ Find all occurrances of 'needle' in 'haystack', even overlapping ones.
     Returns a list of zero-based offsets.
     """
	### Canonical solution below ###    
    results = []
    offset = 0
    while True:
        search = haystack[offset:]
        if not search:
            break
        x = search.find(needle)
        if x < 0:
            break
        results.append(offset + x)
        offset += x + 1
    return results

### Unit tests below ###
def check(candidate):
	assert candidate(u"cd", u"abcd") == [2]
	assert candidate(needle="a", haystack="abca") == [0, 3]
	assert candidate(needle='a', haystack='aba') == [0, 2]
	assert candidate(b"x", b"x") == [0]
	assert candidate(needle="ab", haystack="abc") == [0]
	assert candidate(needle="abc", haystack="abc") == [0]
	assert candidate(b"a", b"b") == []
	assert candidate(b"a", b"a") == [0]
	assert candidate(b'b', b'') == []
	assert candidate(needle="a", haystack="abc") == [0]
	assert candidate(b'BAB', b'ABAB') == [1]
	assert candidate(b'', b'') == []
	assert candidate(b"a", b"ab") == [0]
	assert candidate(b'a', b'abcbcba') == [0, 6]
	assert candidate(needle="c", haystack="abc") == [2]
	assert candidate(b'a', b'a') == [0]
	assert candidate(b"aaa", b"aaaa") == [0, 1]
	assert candidate(u"abcd", u"xxabcddabxxx") == [2]
	assert candidate(u"abcd", u"xxabcddabxxxab") == [2]
	assert candidate(needle='bar', haystack='barfoo') == [0]
	assert candidate(b'xx', b'yxxx') == [1, 2]
	assert candidate(needle="a", haystack="axc") == [0]
	assert candidate(b'xx', b'xy') == []
	assert candidate(needle='a', haystack='a') == [0]
	assert candidate(b'A', b'ABAB') == [0, 2]
	assert candidate(1, []) == []
	assert candidate(b'x', b'xy') == [0]
	assert candidate(needle="b", haystack="abc") == [1]
	assert candidate(b'x', b'y') == []
	assert candidate(u"bc", u"abcd") == [1]
	assert candidate( 'a', 'a') == [0]
	assert candidate(b'BA', b'ABAB') == [1]
	assert candidate(b'a', b'aba') == [0, 2]
	assert candidate(u"abcd", u"abcd") == [0]
	assert candidate(b"aa", b"aa") == [0]
	assert candidate(needle='a', haystack='aa') == [0, 1]
	assert candidate(b"x", b"xxz") == [0, 1]
	assert candidate(u"ab", u"abcd") == [0]
	assert candidate(b"x", b"xy") == [0]
	assert candidate(b"b", b"abc") == [1]
	assert candidate(needle='bar', haystack='foo') == []
	assert candidate(b'a', b'aa') == [0, 1]
	assert candidate(b'x', b'') == []
	assert candidate( 'a', 'aba' ) == [ 0, 2 ]
	assert candidate(b'a', b'ab') == [0]
	assert candidate(b'ABAB', b'ABAB') == [0]
	assert candidate(b"aaa", b"aaa") == [0]
	assert candidate(b'b', b'abcbcba') == [1, 3, 5]
	assert candidate(b"x", b"yx") == [1]
	assert candidate( 'a', 'aa' ) == [ 0, 1 ]
	assert candidate(needle="abcd", haystack="abcdabcd") == [0, 4]
	assert candidate(b'xx', b'yx') == []
	assert candidate( 'a', 'b' ) == []
	assert candidate(b"a", b"") == []
	assert candidate(b'x', b'x') == [0]
	assert candidate(needle="d", haystack="abc") == []
	assert candidate(b'a', b'ba') == [1]
	assert candidate(needle='a', haystack='b') == []
	assert candidate( 'a', 'a' ) == [ 0 ]
	assert candidate( 'a', 'ba') == [1]
	assert candidate( 'ba', 'aaaba' ) == [ 3 ]
	assert candidate( 'a', 'ab') == [0]
	assert candidate(b'AB', b'ABAB') == [0, 2]
	assert candidate(needle="e", haystack="abc") == []
	assert candidate(b"a", b"aba") == [0, 2]
	assert candidate(needle='a', haystack='baba') == [1, 3]
	assert candidate(needle='bar', haystack='foobarbar') == [3, 6]
	assert candidate(b"aaaa", b"aaa") == []
	assert candidate(u"abcd", u"xxabcddabxxxabxxx") == [2]
	assert candidate(b'x', b'xx') == [0, 1]
	assert candidate(b"x", b"xx") == [0, 1]
	assert candidate(b'a', b'b') == []
	assert candidate(b"b", b"babc") == [0, 2]
	assert candidate(b'a', b'') == []
	assert candidate(b"a", b"ba") == [1]
	assert candidate(needle='bar', haystack='foobar') == [3]
	assert candidate(b'x', b'xxx') == [0, 1, 2]
def test_check():
	check(findAll)
