def _get_usb_hub_map(device_info_list):
    """ Creates a map of usb hub addresses to device_infos by port.
     
     Args:
     device_info_list (list): list of known usb_connections dicts.
     
     Returns:
     dict: map of usb hub addresses to device_infos by port
     """
	### Canonical solution below ###  
  map_usb_hub_ports = {}
  for device_info in device_info_list:
    hub_address = device_info['usb_hub_address']
    port = device_info['usb_hub_port']
    if hub_address:
      if hub_address not in map_usb_hub_ports:
        map_usb_hub_ports[hub_address] = {}
      if not map_usb_hub_ports[hub_address].get(
          port) or device_info['ftdi_interface'] == 2:
        map_usb_hub_ports[hub_address][port] = device_info
  return map_usb_hub_ports

### Unit tests below ###
def check(candidate):
	assert candidate(
    [{'usb_hub_address': '1', 'usb_hub_port': 1},
     {'usb_hub_address': '1', 'usb_hub_port': 2},
     {'usb_hub_address': '2', 'usb_hub_port': 1},
     {'usb_hub_address': '2', 'usb_hub_port': 2}]) == {
    '1': {1: {'usb_hub_address': '1', 'usb_hub_port': 1},
          2: {'usb_hub_address': '1', 'usb_hub_port': 2}},
    '2': {1: {'usb_hub_address': '2', 'usb_hub_port': 1},
          2: {'usb_hub_address': '2', 'usb_hub_port': 2}}}
	assert candidate(
    [{'usb_hub_address': '01', 'usb_hub_port': '00'},
     {'usb_hub_address': '01', 'usb_hub_port': '01'},
     {'usb_hub_address': '02', 'usb_hub_port': '00'},
     {'usb_hub_address': '03', 'usb_hub_port': '00'}]) == {
        '01': {'00': {'usb_hub_address': '01', 'usb_hub_port': '00'},
               '01': {'usb_hub_address': '01', 'usb_hub_port': '01'}},
        '02': {'00': {'usb_hub_address': '02', 'usb_hub_port': '00'}},
        '03': {'00': {'usb_hub_address': '03', 'usb_hub_port': '00'}}}
	assert candidate(
    [
        {'usb_hub_address': '1', 'usb_hub_port': 2, 'ftdi_interface': 1},
        {'usb_hub_address': '2', 'usb_hub_port': 3, 'ftdi_interface': 2},
        {'usb_hub_address': '1', 'usb_hub_port': 3, 'ftdi_interface': 3},
    ]) == {
        '1': {
            2: {'usb_hub_address': '1', 'usb_hub_port': 2, 'ftdi_interface': 1},
            3: {'usb_hub_address': '1', 'usb_hub_port': 3, 'ftdi_interface': 3},
        },
        '2': {
            3: {'usb_hub_address': '2', 'usb_hub_port': 3, 'ftdi_interface': 2},
        },
    }
	assert candidate(
    [
        {'usb_hub_address': '1', 'usb_hub_port': 1, 'ftdi_interface': 1},
        {'usb_hub_address': '1', 'usb_hub_port': 2, 'ftdi_interface': 2},
        {'usb_hub_address': '2', 'usb_hub_port': 1, 'ftdi_interface': 1},
        {'usb_hub_address': '2', 'usb_hub_port': 2, 'ftdi_interface': 2},
    ]) == {
        '1': {1: {'usb_hub_address': '1', 'usb_hub_port': 1,
                  'ftdi_interface': 1},
              2: {'usb_hub_address': '1', 'usb_hub_port': 2,
                  'ftdi_interface': 2}},
        '2': {1: {'usb_hub_address': '2', 'usb_hub_port': 1,
                  'ftdi_interface': 1},
              2: {'usb_hub_address': '2', 'usb_hub_port': 2,
                  'ftdi_interface': 2}},
    }
def test_check():
	check(_get_usb_hub_map)
