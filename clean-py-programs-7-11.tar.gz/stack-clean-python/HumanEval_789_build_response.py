def build_response(session_attributes, speechlet_response):
    """ 
     Build the full response JSON from the speechlet response
     """
	### Canonical solution below ###	
	return {
		'version': '1.0',
		'sessionAttributes': session_attributes,
		'response': speechlet_response
	}

### Unit tests below ###
def check(candidate):
	assert candidate(None, {'foo': 'bar'})
	assert candidate({}, None)
	assert candidate({'foo': 'bar'}, {})
	assert candidate(
	{'key': 'value'},
	{'outputSpeech': 'outputSpeech', 'card': 'card','reprompt':'reprompt','shouldEndSession': False}
) == {
	'version': '1.0',
	'sessionAttributes': {'key': 'value'},
	'response': {
		'outputSpeech': 'outputSpeech',
		'card': 'card',
		'reprompt':'reprompt',
		'shouldEndSession': False
	}
}
	assert candidate(
	{'key': 'value'},
	{
		'outputSpeech': {
			'type': 'PlainText',
			'text': 'This is a test'
		},
		'card': {
			'type': 'Simple',
			'title': 'This is a test',
			'content': 'This is a test'
		}
	}
) == {
	'version': '1.0',
	'sessionAttributes': {'key': 'value'},
	'response': {
		'outputSpeech': {
			'type': 'PlainText',
			'text': 'This is a test'
		},
		'card': {
			'type': 'Simple',
			'title': 'This is a test',
			'content': 'This is a test'
		}
	}
}
	assert candidate({}, {})
	assert candidate({ 'foo': 'bar' }, None) == {
	'version': '1.0',
	'sessionAttributes': { 'foo': 'bar' },
	'response': None
}
	assert candidate({'foo': 'bar'}, None)
	assert candidate({"a":1}, {})
	assert candidate(None, {"b":2})
	assert candidate({"a":1}, {"b":2})
	assert candidate(None, {}) == {
	'version': '1.0',
	'sessionAttributes': None,
	'response': {}
}
	assert candidate(
	None,
	{
		'outputSpeech': {
			'type': 'PlainText',
			'text': 'Hello!'
		}
	}
) == {
	'version': '1.0',
	'sessionAttributes': None,
	'response': {
		'outputSpeech': {
			'type': 'PlainText',
			'text': 'Hello!'
		}
	}
}
	assert candidate(None, {})
	assert candidate({'foo': 'bar'}, {'foo': 'bar'})
	assert candidate(
	{'key': 'value'},
	{'outputSpeech': {'text': 'text'}}
) == {
	'version': '1.0',
	'sessionAttributes': {'key': 'value'},
	'response': {'outputSpeech': {'text': 'text'}}
}
	assert candidate({'key': 'value'}, {}) == {
	'version': '1.0',
	'sessionAttributes': {'key': 'value'},
	'response': {}
}
	assert candidate({}, {'key': 'value'}) == {
	'version': '1.0',
	'sessionAttributes': {},
	'response': {'key': 'value'}
}
	assert candidate({ 'foo': 'bar' }, { 'foo': 'bar' }) == {
	'version': '1.0',
	'sessionAttributes': { 'foo': 'bar' },
	'response': { 'foo': 'bar' }
}
	assert candidate(None, None)
	assert candidate(None, None) == {
	'version': '1.0',
	'sessionAttributes': None,
	'response': None
}
def test_check():
	check(build_response)
