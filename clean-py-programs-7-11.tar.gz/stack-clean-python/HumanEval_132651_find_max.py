def find_max(maximum, t2):
    """ 
     Find the maximum.
     ans = find_max(10, 9) = 10
     ans = find_max(1, 7) = 7
     ans = find_max(3, 3) = 3
     """
	### Canonical solution below ###	
	if maximum < t2:
		return t2
	return maximum

### Unit tests below ###
def check(candidate):
	assert candidate(10, 9) == 10, "Test 1"
	assert candidate(10, 100) == 100
	assert candidate("b", "a") == "b"
	assert candidate(2, 1) == 2
	assert candidate(1, 1) == 1
	assert candidate(10, 1) == 10
	assert candidate(8, 9) == 9
	assert candidate(10, 9) == 10, "Test 1 failed."
	assert candidate(3, 3) == 3, "Test 3"
	assert candidate(3, 4) == 4
	assert candidate(2, 3) == 3
	assert candidate(6, 7) == 7
	assert candidate(7, 8) == 8
	assert candidate("b", "b") == "b"
	assert candidate(10, 10000) == 10000
	assert candidate(10, 9) == 10
	assert candidate(10, 10) == 10
	assert candidate(1, 7) == 7, "Test 2"
	assert candidate(1, 7) == 7
	assert candidate(1, 7) == 7, "Test 2 failed."
	assert candidate(10, 1000) == 1000
	assert candidate(10, 100000) == 100000
	assert candidate(1, 2) == 2
	assert candidate("a", "b") == "b"
	assert candidate(4, 5) == 5
	assert candidate(3, 3) == 3, "Test 3 failed."
	assert candidate(9, 10) == 10
	assert candidate(3, 3) == 3
	assert candidate(5, 6) == 6
def test_check():
	check(find_max)
