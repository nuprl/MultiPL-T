def is_equal(a, b):
    """ This function checks if the two variables are equal to each other.
     
     >>> is_equal(2, 2)
     True
     >>> is_equal(2, 3)
     False
     >>> is_equal("Dog", "Dog")
     True
     >>> is_equal("Cat", "Dog")
     False
     """
	### Canonical solution below ###    
    return(a == b)

### Unit tests below ###
def check(candidate):
	assert candidate(False, False) == True
	assert candidate("Dog", "Dog")
	assert candidate(2, 3) is False
	assert candidate(2, 2)
	assert not candidate("cat", "dog")
	assert candidate("Cat", "Dog") == False
	assert candidate(2, 3) == False
	assert candidate(1, 1)
	assert candidate(True, True) == True
	assert not candidate("Cat", "Dog")
	assert candidate("Dog", "Dog") is True
	assert not candidate(True, False)
	assert candidate(True, True)
	assert candidate("Dog", "Dog") == True
	assert candidate(2, 2) == True
	assert candidate(2, 2) is True
	assert not candidate(2, 3)
	assert candidate("Cat", "Dog") is False
	assert candidate("dog", "dog")
	assert not candidate(1, 2)
def test_check():
	check(is_equal)
