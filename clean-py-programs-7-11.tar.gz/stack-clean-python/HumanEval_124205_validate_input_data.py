def validate_input_data(data):
    """ 
     Takes in user input data
     Checks if all the keys are provided
     Raise key error if a key is missing
     Returns a validated data in a dict format
     """
	### Canonical solution below ###    
    cleaned_data = {}
    for key in data:
        if data[key] is None:
            assert False, key + ' key is missing'
        else:
            cleaned_data[key] = data[key]
    return cleaned_data

### Unit tests below ###
def check(candidate):
	assert candidate(dict(first_name='John', last_name='Doe', email='<EMAIL>')) == dict(first_name='John', last_name='Doe', email='<EMAIL>')
	assert candidate(data={}) == {}, 'Should return an empty dictionary'
	assert candidate(
    {'name': 'abc', 'age': 12, 'email': '<EMAIL>'}) == {
        'name': 'abc', 'age': 12, 'email': '<EMAIL>'}
	assert candidate(
    {
        "first_name": "John",
        "last_name": "Doe",
        "email": "<EMAIL>",
        "password": "<PASSWORD>",
        "phone_number": "1234567890"
    }
) == {
    "first_name": "John",
    "last_name": "Doe",
    "email": "<EMAIL>",
    "password": "<PASSWORD>",
    "phone_number": "1234567890"
}, "Valid input should return the same data"
	assert candidate(
    {
        "first_name": "John",
        "last_name": "Doe",
        "password": "<PASSWORD>",
        "phone_number": "1234567890"
    }
) == {
    "first_name": "John",
    "last_name": "Doe",
    "password": "<PASSWORD>",
    "phone_number": "1234567890"
}, "Valid input should return the same data"
	assert candidate(
    {
        'name': 'Peter',
        'email': '<EMAIL>',
        'password': '<PASSWORD>',
        'password2': '<PASSWORD>'
    }
) == {
    'name': 'Peter',
    'email': '<EMAIL>',
    'password': '<PASSWORD>',
    'password2': '<PASSWORD>'
}, 'Should return the data in a dict format'
	assert candidate(
    {'name': 'John', 'email': '<EMAIL>', 'password': '<PASSWORD>', 'confirm_password': '<PASSWORD>'}) == {
    'name': 'John', 'email': '<EMAIL>', 'password': '<PASSWORD>', 'confirm_password': '<PASSWORD>'}
	assert candidate(data={'name': 'Mike', 'age': 25}) == {'name': 'Mike', 'age': 25}
	assert candidate(
    {'first_name': 'John', 'last_name': 'Doe', 'email': '<EMAIL>'}
) == {
    'first_name': 'John',
    'last_name': 'Doe',
    'email': '<EMAIL>',
}
	assert candidate(
    {'name': 'abc', 'age': 12}) == {'name': 'abc', 'age': 12}
	assert candidate(
    {
        'first_name': 'Jane',
        'last_name': 'Doe',
        'password': '<PASSWORD>',
    }
) == {
    'first_name': 'Jane',
    'last_name': 'Doe',
    'password': '<PASSWORD>',
}
	assert candidate(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
	assert candidate(
    {
        'name': 'Johnny',
        'email': '<EMAIL>',
        'password': '<PASSWORD>',
        'confirm_password': '<PASSWORD>',
        'phone_number': '08080808080',
        'role': 'user'
    }
) == {
    'name': 'Johnny',
    'email': '<EMAIL>',
    'password': '<PASSWORD>',
    'confirm_password': '<PASSWORD>',
    'phone_number': '08080808080',
    'role': 'user'
}
	assert candidate(
    {
        'id': '2',
        'name': '<NAME>',
        'age': 45,
        'address': '123, Charming Avenue, Gotham City'
    }
) == {
    'id': '2',
    'name': '<NAME>',
    'age': 45,
    'address': '123, Charming Avenue, Gotham City'
}
	assert candidate(
    {
        'name': 'John',
        'age': 30,
        'occupation': 'Student'
    }
) == {
    'name': 'John',
    'age': 30,
    'occupation': 'Student'
}
	assert candidate(
    {"email": "<EMAIL>", "password": "<PASSWORD>", "name": "Mahi"}) == {"email": "<EMAIL>", "password": "<PASSWORD>", "name": "Mahi"}
	assert candidate({
    'first_name': 'Jane',
    'last_name': 'Doe',
    'email': '<EMAIL>',
    'password': '<PASSWORD>',
    'password_confirmation': '<PASSWORD>'
}) == {
    'first_name': 'Jane',
    'last_name': 'Doe',
    'email': '<EMAIL>',
    'password': '<PASSWORD>',
    'password_confirmation': '<PASSWORD>'
}
	assert candidate(
    {
        'key1': 'value1',
    }
) == {
    'key1': 'value1'
}
	assert candidate(
    {
        "first_name": "John",
        "last_name": "Doe",
        "email": "<EMAIL>",
        "phone_number": "1234567890"
    }
) == {
    "first_name": "John",
    "last_name": "Doe",
    "email": "<EMAIL>",
    "phone_number": "1234567890"
}, "Valid input should return the same data"
	assert candidate(data={'name': 'Mike'}) == {'name': 'Mike'}
	assert candidate(
    {"email": "<EMAIL>", "password": "<PASSWORD>", "name": "Mahi", "age": 26}) == {"email": "<EMAIL>", "password": "<PASSWORD>", "name": "Mahi", "age": 26}
	assert candidate(data={'name': 'John', 'age': 30}) == {'name': 'John', 'age': 30}
	assert candidate(dict(a=1, b=2)) == dict(a=1, b=2)
	assert candidate(
    {
        "firstName": "John",
        "lastName": "Doe",
        "email": "<EMAIL>",
        "password": "<PASSWORD>",
        "confirmPassword": "<PASSWORD>",
    }
) == {
    "firstName": "John",
    "lastName": "Doe",
    "email": "<EMAIL>",
    "password": "<PASSWORD>",
    "confirmPassword": "<PASSWORD>",
}
	assert candidate(
    {'first_name': 'John', 'last_name': 'Doe', 'email': '<EMAIL>', 'password': '<PASSWORD>', 'confirm_password': '<PASSWORD>'}) == {
        'first_name': 'John', 'last_name': 'Doe', 'email': '<EMAIL>', 'password': '<PASSWORD>', 'confirm_password': '<PASSWORD>'}
	assert candidate(
    {'first_name': 'John', 'last_name': 'Doe', 'email': '<EMAIL>', 'phone_number': '1234567890', 'company_name': 'test'}) == {'first_name': 'John', 'last_name': 'Doe', 'email': '<EMAIL>', 'phone_number': '1234567890', 'company_name': 'test'}
	assert candidate(
    {
        'key1': 'value1',
        'key2': 'value2'
    }
) == {
    'key1': 'value1',
    'key2': 'value2'
}
	assert candidate(
    {'name': 'John', 'age': 22, 'location': 'UK'}) == {
        'name': 'John', 'age': 22, 'location': 'UK'}
	assert candidate(data={
    'first_name': 'Ken',
    'last_name': 'Thomas'
}) == {
    'first_name': 'Ken',
    'last_name': 'Thomas'
}, 'Should return a validated data in a dictionary format'
	assert candidate(
    {"username": "john", "email": "<EMAIL>", "password": "<PASSWORD>", "password2": "<PASSWORD>"}
) == {"username": "john", "email": "<EMAIL>", "password": "<PASSWORD>", "password2": "<PASSWORD>"}
	assert candidate({}) == {}
	assert candidate(
    {
        'first_name': 'Jane',
        'last_name': 'Doe',
        'email': '<EMAIL>',
        'password': '<PASSWORD>',
    }
) == {
    'first_name': 'Jane',
    'last_name': 'Doe',
    'email': '<EMAIL>',
    'password': '<PASSWORD>',
}
	assert candidate(
    {'name': 'TestUser', 'password': '<PASSWORD>', 'email': '<EMAIL>'}) == {
        'name': 'TestUser', 'password': '<PASSWORD>', 'email': '<EMAIL>'}, 'Should return the same input data'
	assert candidate(
    {"email": "<EMAIL>", "password": "<PASSWORD>"}) == {"email": "<EMAIL>", "password": "<PASSWORD>"}
	assert candidate(
    {"name": "name", "email": "email", "password": "password", "confirm_password": "password"}) == \
    {"name": "name", "email": "email", "password": "password", "confirm_password": "password"}, \
    "All keys are present"
	assert candidate(dict(name='name',
                                email='<EMAIL>',
                                phone='0123456789',
                                password='<PASSWORD>',
                                confirm_password='<PASSWORD>')) == dict(name='name',
                                                                    email='<EMAIL>',
                                                                    phone='0123456789',
                                                                    password='<PASSWORD>',
                                                                    confirm_password='<PASSWORD>')
	assert candidate(dict(a=1, b=2, c=3, d=4)) == dict(a=1, b=2, c=3, d=4)
	assert candidate(
    {'first_name': 'John', 'last_name': 'Doe', 'email': '<EMAIL>', 'country': 'US'}
) == {
    'first_name': 'John',
    'last_name': 'Doe',
    'email': '<EMAIL>',
    'country': 'US',
}
	assert candidate(dict(name='name',
                                email='<EMAIL>',
                                phone='0123456789',
                                password='<PASSWORD>',
                                confirm_password='<PASSWORD>',
                                role='Admin')) == dict(name='name',
                                                        email='<EMAIL>',
                                                        phone='0123456789',
                                                        password='<PASSWORD>',
                                                        confirm_password='<PASSWORD>',
                                                        role='Admin')
	assert candidate(
    {
        'first_name': 'John',
        'last_name': 'Doe',
        'email': '<EMAIL>',
        'password': '<PASSWORD>'
    }
) == {
    'first_name': 'John',
    'last_name': 'Doe',
    'email': '<EMAIL>',
    'password': '<PASSWORD>'
}
def test_check():
	check(validate_input_data)
