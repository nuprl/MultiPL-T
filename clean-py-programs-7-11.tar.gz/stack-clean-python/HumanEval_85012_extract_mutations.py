def extract_mutations(mutation_string, offset=0):
    """ 
     Turns a string containing mutations of the format I100V into a list of tuples with
     format (100, 'I', 'V') (index, from, to)
     
     Parameters
     ----------
     mutation_string : str
     Comma-separated list of one or more mutations (e.g. "K50R,I100V")
     offset : int, default: 0
     Offset to be added to the index/position of each mutation
     
     Returns
     -------
     list of tuples
     List of tuples of the form (index+offset, from, to)
     """
	### Canonical solution below ###    
    if mutation_string.lower() not in ["wild", "wt", ""]:
        mutations = mutation_string.split(",")
        return list(map(
            lambda x: (int(x[1:-1]) + offset, x[0], x[-1]),
            mutations
        ))
    else:
        return []

### Unit tests below ###
def check(candidate):
	assert candidate("WT") == []
	assert candidate(mutation_string="I100V") == [(100, "I", "V")]
	assert candidate("wild") == []
	assert candidate(
    "K50R,I100V",
    offset=1
) == [(51, "K", "R"), (101, "I", "V")]
	assert candidate("K50R,I100V") == [
    (50, "K", "R"),
    (100, "I", "V")
]
	assert candidate("K50R,I100V", offset=5) == [(55, 'K', 'R'), (105, 'I', 'V')]
	assert candidate("K50R,I100V") == [(50, 'K', 'R'), (100, 'I', 'V')]
	assert candidate(
    "wild"
) == []
	assert candidate("Wild") == []
	assert candidate(
    "K50R,I100V",
    offset=0
) == [(50, "K", "R"), (100, "I", "V")]
	assert candidate(
    "K50R,I100V",
    offset=1
) == [(51, 'K', 'R'), (101, 'I', 'V')]
	assert candidate("wt") == []
	assert candidate("K50R") == [(50, 'K', 'R')]
	assert candidate(
    "K50R,I100V,E100K"
) == [(50, 'K', 'R'), (100, 'I', 'V'), (100, 'E', 'K')]
	assert candidate(mutation_string="I100V,I101D,I102N") == [(100, "I", "V"), (101, "I", "D"), (102, "I", "N")]
	assert candidate(
    "K50R,I100V"
) == [(50, "K", "R"), (100, "I", "V")]
	assert candidate(mutation_string="") == []
	assert candidate(
    "K50R,I100V,N42D"
) == [
    (50, "K", "R"),
    (100, "I", "V"),
    (42, "N", "D")
]
	assert candidate("K50R,I100V") == [(50, "K", "R"), (100, "I", "V")]
	assert candidate(
    ""
) == []
	assert candidate("") == []
	assert candidate(
    "WT"
) == []
	assert candidate(mutation_string="K50R,I100V", offset=0) == [(50, 'K', 'R'), (100, 'I', 'V')]
	assert candidate(
    "K50R,I100V,E150K"
) == [(50, "K", "R"), (100, "I", "V"), (150, "E", "K")]
	assert candidate("K50R") == [(50, "K", "R")]
	assert candidate("I100V") == [(100, "I", "V")]
	assert candidate("K50R,I100V", 1) == [
    (51, "K", "R"),
    (101, "I", "V")
]
	assert candidate(mutation_string="K50R") == [(50, 'K', 'R')]
	assert candidate(mutation_string="K50R,I100V") == [(50, 'K', 'R'), (100, 'I', 'V')]
	assert candidate("K50R,I100V", offset=1) == [(51, "K", "R"), (101, "I", "V")]
	assert candidate("K50R,I100V", offset=-1) == [(49, "K", "R"), (99, "I", "V")]
	assert candidate("I100V,D888N") == [(100, "I", "V"), (888, "D", "N")]
	assert candidate(mutation_string="wild") == []
	assert candidate(mutation_string="wt") == []
	assert candidate(mutation_string="I100V,I101D") == [(100, "I", "V"), (101, "I", "D")]
	assert candidate(mutation_string="wild", offset=100000) == []
	assert candidate(
    "wt"
) == []
def test_check():
	check(extract_mutations)
