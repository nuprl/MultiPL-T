def nproph_params(method=None):
    """ Default hyper-params """
    ### Canonical solution below ###
    # https://alkaline-ml.com/pmdarima/modules/generated/pmdarima.arima.auto_arima.html
    s = dict(
        nlags=4,
        changepoints_range=0.95,
        n_changepoints=30,
        weekly_seasonality=False,
        batch_size=64,
        epochs=10,
        learning_rate=1.0
    )
    if method == '0':
        # Add more cases here
        pass
    return s


### Unit tests below ###
def check(candidate):
	assert candidate(None)['n_changepoints'] == 30
	assert candidate(method='0') == {'nlags': 4, 'changepoints_range': 0.95, 'n_changepoints': 30, 'weekly_seasonality': False, 'batch_size': 64, 'epochs': 10, 'learning_rate': 1.0}
	assert candidate(method='6')['learning_rate'] == 1.0
	assert candidate(method=None) == {'nlags': 4, 'changepoints_range': 0.95, 'n_changepoints': 30, 'weekly_seasonality': False, 'batch_size': 64, 'epochs': 10, 'learning_rate': 1.0}
	assert candidate(method='0') == dict(nlags=4, changepoints_range=0.95, n_changepoints=30, weekly_seasonality=False, batch_size=64, epochs=10, learning_rate=1.0)
	assert candidate(method='0')['changepoints_range'] == 0.95
	assert candidate(method='1') == dict(
    nlags=4,
    changepoints_range=0.95,
    n_changepoints=30,
    weekly_seasonality=False,
    batch_size=64,
    epochs=10,
    learning_rate=1.0
)
	assert candidate(None) == candidate('0')
	assert candidate(method='4')['batch_size'] == 64
	assert candidate(None)['batch_size'] == 64
	assert candidate(method=None) == dict(
    nlags=4,
    changepoints_range=0.95,
    n_changepoints=30,
    weekly_seasonality=False,
    batch_size=64,
    epochs=10,
    learning_rate=1.0
)
	assert candidate(None)['changepoints_range'] == 0.95
	assert candidate(method='0')['nlags'] == 4
	assert candidate(None)['nlags'] == 4
	assert candidate('0') == dict(
    nlags=4,
    changepoints_range=0.95,
    n_changepoints=30,
    weekly_seasonality=False,
    batch_size=64,
    epochs=10,
    learning_rate=1.0
)
	assert candidate(method=None) == dict(nlags=4, changepoints_range=0.95, n_changepoints=30, weekly_seasonality=False, batch_size=64, epochs=10, learning_rate=1.0)
	assert candidate(method='1')['changepoints_range'] == 0.95
	assert candidate(method='5')['epochs'] == 10
	assert candidate(method='0')['n_changepoints'] == 30
	assert candidate(method='0')['batch_size'] == 64
	assert candidate('0') == {
    'nlags': 4,
    'changepoints_range': 0.95,
    'n_changepoints': 30,
    'weekly_seasonality': False,
    'batch_size': 64,
    'epochs': 10,
    'learning_rate': 1.0
}
	assert candidate(method='0') == dict(
    nlags=4,
    changepoints_range=0.95,
    n_changepoints=30,
    weekly_seasonality=False,
    batch_size=64,
    epochs=10,
    learning_rate=1.0
), "candidate(method='0') failed"
	assert candidate(method='0')['learning_rate'] == 1.0
	assert candidate(None)['weekly_seasonality'] == False
	assert candidate(method='0')['weekly_seasonality'] == False
	assert candidate(method='0') == dict(
    nlags=4,
    changepoints_range=0.95,
    n_changepoints=30,
    weekly_seasonality=False,
    batch_size=64,
    epochs=10,
    learning_rate=1.0
)
	assert candidate(method='3')['weekly_seasonality'] == False
	assert candidate(None)['epochs'] == 10
	assert candidate(method='2')['n_changepoints'] == 30
	assert candidate(None) == dict(
    nlags=4,
    changepoints_range=0.95,
    n_changepoints=30,
    weekly_seasonality=False,
    batch_size=64,
    epochs=10,
    learning_rate=1.0
)
	assert candidate(None) == {
    'nlags': 4,
    'changepoints_range': 0.95,
    'n_changepoints': 30,
    'weekly_seasonality': False,
    'batch_size': 64,
    'epochs': 10,
    'learning_rate': 1.0
}
	assert candidate(None)['learning_rate'] == 1.0
	assert candidate(method='0') == {
    'nlags': 4,
    'changepoints_range': 0.95,
    'n_changepoints': 30,
    'weekly_seasonality': False,
    'batch_size': 64,
    'epochs': 10,
    'learning_rate': 1.0
}
	assert candidate(method='0')['epochs'] == 10
def test_check():
	check(nproph_params)
