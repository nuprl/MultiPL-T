def _stringify_time_unit(unit, value) -> str:
    """
    Returns a string representing a certain unit of time.
    For example:
    >>> _stringify_time_unit('hours', 9)
    '9 hours'
    >>> _stringify_time_unit('minutes', 0)
    'less than a minute'
    """
    ### Canonical solution below ###
    if unit == 'seconds' and value == 0:
        return '0 seconds'
    elif value == 1:
        # Use singular noun if there is only 1 unit
        return f'{value} {unit[:-1]}'
    elif value == 0:
        # Use 'less than a' if there are 0 units
        return f'less than a {unit[:-1]}'
    else:
        return f'{value} {unit}'


### Unit tests below ###
def check(candidate):
	assert candidate(
   'seconds', 0) == '0 seconds'
	assert candidate(
   'minutes', 0) == 'less than a minute', '0 minutes should be "less than a minute"'
	assert candidate(unit='seconds', value=0) == '0 seconds'
	assert candidate(
    'hours', 9) == '9 hours', "Incorrect output for candidate"
	assert candidate(
   'minutes', 0
) == 'less than a minute'
	assert candidate(
    'days', 2) == '2 days'
	assert candidate(
   'seconds', 2) == '2 seconds'
	assert candidate(
    'days', 0) == 'less than a day'
	assert candidate(unit='minutes', value=0) == 'less than a minute'
	assert candidate(
    'hours', 0
) == 'less than a hour'
	assert candidate(
    'hours', 1) == '1 hour', '1 hour should be "1 hour"'
	assert candidate(
    'hours', 9) == '9 hours', \
    "Should be '9 hours'"
	assert candidate(
   'minutes', 0) == 'less than a minute', "Incorrect output for candidate"
	assert candidate(
    'hours', 2) == '2 hours'
	assert candidate(unit='minutes', value=2) == '2 minutes'
	assert candidate(
   'minutes', 1) == '1 minute', \
    "Should be '1 minute'"
	assert candidate(unit='hours', value=10) == '10 hours'
	assert candidate(
   'seconds', 0) == '0 seconds', 'Should return a string for 0 seconds'
	assert candidate(
   'minutes', 2) == '2 minutes'
	assert candidate(
   'seconds', 10) == '10 seconds', \
    "Should be '10 seconds'"
	assert candidate(
   'minutes', 1) == '1 minute', '1 minute should be "1 minute"'
	assert candidate(
   'minutes', 0) == 'less than a minute', \
    "Should be 'less than a minute'"
	assert candidate(
    'hours',
    9
) == '9 hours'
	assert candidate(
   'seconds', 5) == '5 seconds'
	assert candidate(
   'minutes', 1
) == '1 minute'
	assert candidate(
    'hours', 2) == '2 hours', '2 hours should be "2 hours"'
	assert candidate(
   'minutes', 0) == 'less than a minute'
	assert candidate(
   'seconds', 0) == '0 seconds', \
    "Should be '0 seconds'"
	assert candidate(unit='hours', value=2) == '2 hours'
	assert candidate(unit='days', value=1) == '1 day'
	assert candidate(
    'hours', 0) == 'less than a hour', 'Should return a string for 0 hours'
	assert candidate(
   'minutes', 10) == '10 minutes', \
    "Should be '10 minutes'"
	assert candidate(
   'seconds', 1) == '1 second', \
    "Should be '1 second'"
	assert candidate(
   'seconds', 2) == '2 seconds', \
    "Should be '2 seconds'"
	assert candidate(
   'minutes', 59
) == '59 minutes'
	assert candidate(
    'hours', 0) == 'less than a hour', '0 hours should be "less than a hour"'
	assert candidate(unit='seconds', value=9) == '9 seconds'
	assert candidate(unit='seconds', value=2) == '2 seconds'
	assert candidate(
    'hours', 0) == 'less than a hour', \
    "Should be 'less than a hour'"
	assert candidate(
    'hours', 5) == '5 hours'
	assert candidate(
   'minutes', 1) == '1 minute'
	assert candidate(
   'minutes', 2) == '2 minutes', '2 minutes should be "2 minutes"'
	assert candidate(
    'days', 1) == '1 day'
	assert candidate(
    'hours', 0) == 'less than a hour'
	assert candidate(
   'seconds', 1) == '1 second', '1 second should be "1 second"'
	assert candidate(
    'hours', 9) == '9 hours'
	assert candidate(
   'seconds', 1) == '1 second'
	assert candidate(unit='hours', value=9) == '9 hours'
	assert candidate(
    'hours', 1) == '1 hour'
	assert candidate(
    'hours', 9) == '9 hours', 'Should return a string for 9 hours'
	assert candidate(unit='minutes', value=9) == '9 minutes'
	assert candidate(unit='hours', value=0) == 'less than a hour'
	assert candidate(unit='weeks', value=0) == 'less than a week'
	assert candidate(
   'seconds', 1) == '1 second', 'Should return a string for 1 second'
	assert candidate(unit='weeks', value=1) == '1 week'
	assert candidate(
   'seconds', 0) == '0 seconds', '0 seconds should be "0 seconds"'
	assert candidate(unit='hours', value=1) == '1 hour'
	assert candidate(
    'days', 5) == '5 days'
	assert candidate(
   'minutes', 1) == '1 minute', 'Should return a string for 1 minute'
	assert candidate(
    'hours', 9
) == '9 hours'
	assert candidate(unit='seconds', value=1) == '1 second'
	assert candidate(
   'seconds', 0
) == '0 seconds'
	assert candidate(
   'minutes',
    0
) == 'less than a minute'
	assert candidate(unit='seconds', value=10) == '10 seconds'
	assert candidate(
    'days', 1
) == '1 day'
	assert candidate(
   'seconds', 2) == '2 seconds', '2 seconds should be "2 seconds"'
	assert candidate(unit='days', value=0) == 'less than a day'
	assert candidate(unit='minutes', value=10) == '10 minutes'
	assert candidate(unit='days', value=2) == '2 days'
	assert candidate(
   'minutes', 5) == '5 minutes'
	assert candidate(
   'seconds',
    0
) == '0 seconds'
	assert candidate(
   'minutes', 0) == 'less than a minute', 'Should return a string for 0 minutes'
	assert candidate(unit='minutes', value=1) == '1 minute'
def test_check():
	check(_stringify_time_unit)
