def filtered(query, filter_):
    """
    Filtered query for performing both filtering and querying at once
    """
    ### Canonical solution below ###
    return {
        "filtered": {
            "query": query,
            "filter": filter_,
        }
    }


### Unit tests below ###
def check(candidate):
	assert candidate(
    {"match": {"content": "python"}},
    {"terms": {"language": ["english", "french"]}}
) == {
    "candidate": {
        "query": {"match": {"content": "python"}},
        "filter": {"terms": {"language": ["english", "french"]}}
    }
}
	assert candidate(
    {"match": {"content": "python"}},
    {"range": {"date": {"gte": "2016-01-01", "lte": "now/d"}}}
) == {
    "candidate": {
        "query": {"match": {"content": "python"}},
        "filter": {"range": {"date": {"gte": "2016-01-01", "lte": "now/d"}}}
    }
}
	assert candidate(
    {"match_all": {}},
    {"term": {"user": "kimchy"}},
) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"user": "kimchy"}},
    }
}
	assert candidate(
    {"match": {"title": "python"}},
    {"term": {"year": 2016}}
) == {
    "candidate": {
        "query": {"match": {"title": "python"}},
        "filter": {"term": {"year": 2016}},
    }
}
	assert candidate(
    {"match": {"content": "python"}},
    {"term": {"language": "english"}}
) == {
    "candidate": {
        "query": {"match": {"content": "python"}},
        "filter": {"term": {"language": "english"}}
    }
}
	assert candidate(query={"match": {"field": "value"}}, filter_={"term": {"field": "value"}}) == {
    "candidate": {
        "query": {"match": {"field": "value"}},
        "filter": {"term": {"field": "value"}},
    }
}
	assert candidate(
    {"match": {"name": "foo"}},
    {"term": {"status": "active"}},
) == {
    "candidate": {
        "query": {"match": {"name": "foo"}},
        "filter": {"term": {"status": "active"}},
    }
}
	assert candidate(
    {"term": {"color": "red"}},
    {"term": {"color": "red"}},
) == {
    "candidate": {
        "query": {"term": {"color": "red"}},
        "filter": {"term": {"color": "red"}},
    }
}
	assert candidate(query={"match": {"name": "apple"}}, filter_={"term": {"color": "red"}}) == {
    "candidate": {
        "query": {"match": {"name": "apple"}},
        "filter": {"term": {"color": "red"}}
    }
}
	assert candidate(
    {"match_all": {}},
    {"term": {"field": "value"}},
) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"field": "value"}},
    }
}
	assert candidate(
    {"match": {"title": "python"}},
    {"term": {"year": "2012"}},
) == {
    "candidate": {
        "query": {"match": {"title": "python"}},
        "filter": {"term": {"year": "2012"}},
    }
}
	assert candidate(
    {"match": {"title": "python"}},
    {"term": {"tags": "awesome"}}
) == {
    "candidate": {
        "query": {"match": {"title": "python"}},
        "filter": {"term": {"tags": "awesome"}}
    }
}
	assert candidate({"match_all": {}}, {"term": {"foo": "bar"}}) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"foo": "bar"}},
    }
}
	assert candidate(
    {
        "query_string": {
            "query": "foo",
        }
    },
    {
        "term": {
            "field": "bar",
        }
    },
) == {
    "candidate": {
        "query": {
            "query_string": {
                "query": "foo",
            }
        },
        "filter": {
            "term": {
                "field": "bar",
            }
        },
    }
}
	assert candidate(
    {
        "match_all": {}
    },
    {
        "term": {
            "field_a": 1,
        }
    }
) == {
    "candidate": {
        "query": {
            "match_all": {}
        },
        "filter": {
            "term": {
                "field_a": 1,
            }
        }
    }
}
	assert candidate(query={"match": {"name": "<NAME>"}}, filter_={"term": {"gender": "male"}}) == {
    "candidate": {
        "query": {"match": {"name": "<NAME>"}},
        "filter": {"term": {"gender": "male"}},
    }
}
	assert candidate(
    {"match": {"content": "python"}},
    {"range": {"date": {"gte": "2016-01-01", "lt": "now/d"}}}
) == {
    "candidate": {
        "query": {"match": {"content": "python"}},
        "filter": {"range": {"date": {"gte": "2016-01-01", "lt": "now/d"}}}
    }
}
	assert candidate(
    {"match_all": {}},
    {"term": {"author": "kimchy"}}
) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"author": "kimchy"}}
    }
}
	assert candidate(query={"match_all": {}}, filter_={"term": {"tag": "python"}}) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"tag": "python"}},
    }
}
	assert candidate(query={"match_all": {}}, filter_={"term": {"user": "kimchy"}}) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"user": "kimchy"}},
    }
}
	assert candidate(
    {"term": {"color": "red"}},
    {"term": {"color": "blue"}},
) == {
    "candidate": {
        "query": {"term": {"color": "red"}},
        "filter": {"term": {"color": "blue"}},
    }
}
	assert candidate(query={"match_all": {}}, filter_={"match": {"name": "Nicholas"}}) == {
    "candidate": {
        "query": {
            "match_all": {}
        },
        "filter": {
            "match": {
                "name": "Nicholas"
            }
        }
    }
}
	assert candidate(
    {"match": {"title": "The title"}},
    {"term": {"year": 2005}}
) == {
    "candidate": {
        "query": {"match": {"title": "The title"}},
        "filter": {"term": {"year": 2005}}
    }
}
	assert candidate(
    {"match": {"f1": "v1"}},
    {"and": [{"term": {"f2": "v2"}}, {"term": {"f3": "v3"}}, {"term": {"f4": "v4"}}]}
) == {
    "candidate": {
        "query": {"match": {"f1": "v1"}},
        "filter": {"and": [{"term": {"f2": "v2"}}, {"term": {"f3": "v3"}}, {"term": {"f4": "v4"}}]},
    }
}
	assert candidate(
    {"match_all": {}},
    {"term": {"user": "kimchy"}}
) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"user": "kimchy"}},
    }
}
	assert candidate(
    {
        "bool": {
            "must": [
                {
                    "match": {
                        "title": "python",
                    },
                },
                {
                    "match": {
                        "tags": "programming",
                    },
                },
            ],
        },
    },
    {
        "term": {
            "some_field": "some_value",
        },
    },
) == {
    "candidate": {
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "title": "python",
                        },
                    },
                    {
                        "match": {
                            "tags": "programming",
                        },
                    },
                ],
            },
        },
        "filter": {
            "term": {
                "some_field": "some_value",
            },
        },
    }
}
	assert candidate(
    {"match": {"message": "test"}},
    {"match": {"message": "hello"}},
) == {
    "candidate": {
        "query": {"match": {"message": "test"}},
        "filter": {"match": {"message": "hello"}},
    }
}
	assert candidate(
    {"match_all": {}},
    {"term": {"some_field": "some_value"}},
) == {
    "candidate": {
        "query": {"match_all": {}},
        "filter": {"term": {"some_field": "some_value"}},
    }
}
	assert candidate(query={"match_all": {}}, filter_={"term": {"user": "kimchy"}}) == \
    {"candidate": {"query": {"match_all": {}}, "filter": {"term": {"user": "kimchy"}}}}
def test_check():
	check(filtered)
