def update_profile_dict_with_reverse_dict(pdict, rdict):
    """ 
     Updates the profile information in `pdict` with the reverse call
     information in `rdict`.
     
     :param pdict: profile dictionary
     :param rdict: reverse call dictionary
     :return: updated profile dictionary
     """
	### Canonical solution below ###    
    for key, calls_from in rdict.items():
        if key in pdict:
            for line in pdict[key]['lines']:
                if line['line_number'] in calls_from:
                    line['calls_from'] = calls_from[line['line_number']]

    return pdict

### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        1: {
            'lines': [
                {'line_number': 1, 'calls_from': {2: 1}},
                {'line_number': 2, 'calls_from': {3: 1}},
            ]
        }
    },
    {1: {1: {2: 1}, 2: {3: 1}}}
) == {
    1: {
        'lines': [
            {'line_number': 1, 'calls_from': {2: 1}},
            {'line_number': 2, 'calls_from': {3: 1}},
        ]
    }
}
	assert candidate(
    {'a': {'lines': [{'line_number': 1, 'calls_from': []},
                     {'line_number': 2, 'calls_from': [1]}]}},
    {'a': {1: [2, 3]}}
) == {'a': {'lines': [{'line_number': 1, 'calls_from': [2, 3]},
                     {'line_number': 2, 'calls_from': [1]}]}}
	assert candidate(
    {
        "foo": {
            "lines": [
                {
                    "line_number": 1,
                    "calls_from": [2]
                },
                {
                    "line_number": 2,
                    "calls_from": [1]
                }
            ]
        }
    },
    {
        1: {
            2: [2]
        },
        2: {
            1: [1]
        }
    }
) == {
    "foo": {
        "lines": [
            {
                "line_number": 1,
                "calls_from": [2]
            },
            {
                "line_number": 2,
                "calls_from": [1]
            }
        ]
    }
}
	assert candidate(
    {
        "foo": {
            "lines": [
                {
                    "line_number": 1,
                    "calls_from": [2]
                }
            ]
        }
    },
    {
        1: {
            2: 1,
            3: 2
        },
        2: {
            1: 1
        }
    }
) == {
    "foo": {
        "lines": [
            {
                "line_number": 1,
                "calls_from": [2]
            }
        ]
    }
}
	assert candidate(
    {
        "foo": {
            "lines": [
                {
                    "line_number": 1,
                    "calls_from": [2]
                }
            ]
        }
    },
    {
        1: {
            2: 1
        },
        2: {
            1: 1
        }
    }
) == {
    "foo": {
        "lines": [
            {
                "line_number": 1,
                "calls_from": [2]
            }
        ]
    }
}
	assert candidate(
    {'a': {'lines': [{'line_number': 1, 'calls_from': []},
                     {'line_number': 2, 'calls_from': [1]}]}},
    {'a': {1: [2]}}
) == {'a': {'lines': [{'line_number': 1, 'calls_from': [2]},
                     {'line_number': 2, 'calls_from': [1]}]}}
	assert candidate(
    {'a': {'lines': [{'line_number': 1, 'calls_from': [2]},
                    {'line_number': 2, 'calls_from': []}]},
     'b': {'lines': [{'line_number': 1, 'calls_from': []}]},
     'c': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}},
    {'a': {1: [2]},
     'c': {2: [3]}}) == {'a': {'lines': [{'line_number': 1, 'calls_from': [2]},
                                         {'line_number': 2, 'calls_from': []}]},
                        'b': {'lines': [{'line_number': 1, 'calls_from': []}]},
                        'c': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}}
	assert candidate(
    {'a': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}},
    {'a': {3: [1]}}) == {
    'a': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}}
	assert candidate(
    {
        'a': {
            'lines': [
                {
                    'line_number': 1,
                    'calls_from': [2, 3]
                },
                {
                    'line_number': 2,
                    'calls_from': [1]
                }
            ]
        }
    },
    {
        1: {
            2: [],
            3: []
        },
        2: {
            1: []
        }
    }
) == {
    'a': {
        'lines': [
            {
                'line_number': 1,
                'calls_from': [2, 3]
            },
            {
                'line_number': 2,
                'calls_from': [1]
            }
        ]
    }
}
	assert candidate(
    {'a': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}},
    {'a': {2: [1], 3: [1]}}) == {
    'a': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}}
	assert candidate(
    {
        'key1': {
            'lines': [
                {'line_number': 1},
                {'line_number': 2},
            ]
        }
    },
    {'key1': {2: [4]}}
) == {
    'key1': {
        'lines': [
            {'line_number': 1},
            {'line_number': 2, 'calls_from': [4]},
        ]
    }
}
	assert candidate(
        {'foo': {'lines': [{'line_number': 2, 'calls_from': []}]},
         'bar': {'lines': [{'line_number': 4, 'calls_from': [2]}]}},
        {2: {4: 2}}) == {'foo': {'lines': [{'line_number': 2, 'calls_from': []}]},
                         'bar': {'lines': [{'line_number': 4, 'calls_from': [2]}]}}
	assert candidate(
    {'foo': {'lines': [{'line_number': 1, 'calls_from': {2: 2}}]}},
    {'foo': {2: {1: 2}}}
)['foo']['lines'][0]['calls_from'] == {2: 2}
	assert candidate(
    {
       'main': {
            'lines': [
                {
                    'line_number': 1,
                    'calls_from': [2]
                },
                {
                    'line_number': 2,
                    'calls_from': [1]
                }
            ]
        }
    },
    {
        1: {
            2: [3]
        },
        2: {
            1: [2]
        }
    }
) == {
   'main': {
        'lines': [
            {
                'line_number': 1,
                'calls_from': [2]
            },
            {
                'line_number': 2,
                'calls_from': [1]
            }
        ]
    }
}
	assert candidate(
    {
        'a': {
            'lines': [
                {'line_number': 1, 'calls_from': []},
                {'line_number': 2, 'calls_from': []},
            ]
        }
    },
    {
        'a': {
            1: {1: 1, 2: 2},
            2: {1: 1, 2: 2},
        }
    }
) == {
    'a': {
        'lines': [
            {'line_number': 1, 'calls_from': {1: 1, 2: 2}},
            {'line_number': 2, 'calls_from': {1: 1, 2: 2}},
        ]
    }
}
	assert candidate(
    {'a': {'lines': [{'line_number': 1}, {'line_number': 2}]},
     'b': {'lines': [{'line_number': 2}, {'line_number': 3}]},
     'c': {'lines': [{'line_number': 3}, {'line_number': 1}]},
     },
    {'a': {1: [2], 2: [3]},
     'b': {2: [3], 3: [1]},
     'c': {3: [1], 1: [2]},
     }) == {
    'a': {'lines': [{'line_number': 1, 'calls_from': [2]},
                    {'line_number': 2, 'calls_from': [3]}]},
    'b': {'lines': [{'line_number': 2, 'calls_from': [3]},
                    {'line_number': 3, 'calls_from': [1]}]},
    'c': {'lines': [{'line_number': 3, 'calls_from': [1]},
                    {'line_number': 1, 'calls_from': [2]}]},
    }
	assert candidate(
    {'a': {'lines': [{'line_number': 10, 'calls_from': [1, 2, 3]}]}},
    {'a': {10: [1, 2, 3, 4, 5, 6, 7, 8, 9]}}
) == {'a': {'lines': [{'line_number': 10, 'calls_from': [1, 2, 3, 4, 5, 6, 7, 8, 9]}]}}
	assert candidate(
    {
        'a': {
            'lines': [
                {'line_number': 1, 'calls_from': []},
                {'line_number': 2, 'calls_from': []},
            ]
        }
    },
    {
        'a': {
            1: {1: 1, 2: 2},
            3: {1: 1, 2: 2},
        }
    }
) == {
    'a': {
        'lines': [
            {'line_number': 1, 'calls_from': {1: 1, 2: 2}},
            {'line_number': 2, 'calls_from': []},
        ]
    }
}
	assert candidate(
    {
        1: {
            'lines': [
                {'line_number': 1, 'calls_from': {2: 1}},
                {'line_number': 2, 'calls_from': {3: 1}},
            ]
        }
    },
    {1: {1: {2: 2}, 2: {3: 1}}}
) == {
    1: {
        'lines': [
            {'line_number': 1, 'calls_from': {2: 2}},
            {'line_number': 2, 'calls_from': {3: 1}},
        ]
    }
}
	assert candidate(
    {'a': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}},
    {'a': {2: [1]}}) == {
    'a': {'lines': [{'line_number': 1, 'calls_from': [2, 3]}]}}
	assert candidate(
    {'a': {'lines': [{'line_number': 1, 'calls_from': [2]}]}},
    {'a': {2: [1]}}) == {
    'a': {'lines': [{'line_number': 1, 'calls_from': [2]}]}}
	assert candidate(
    {
       'main': {
            'lines': [
                {
                    'line_number': 1,
                    'calls_from': [2]
                },
                {
                    'line_number': 2,
                    'calls_from': [1]
                }
            ]
        }
    },
    {
        1: {
            2: [1]
        },
        2: {
            1: [2]
        }
    }
) == {
   'main': {
        'lines': [
            {
                'line_number': 1,
                'calls_from': [2]
            },
            {
                'line_number': 2,
                'calls_from': [1]
            }
        ]
    }
}
	assert candidate(
    {
        'key1': {
            'lines': [
                {'line_number': 1},
                {'line_number': 2},
            ]
        }
    },
    {'key1': {1: [3], 2: [4]}}
) == {
    'key1': {
        'lines': [
            {'line_number': 1, 'calls_from': [3]},
            {'line_number': 2, 'calls_from': [4]},
        ]
    }
}
	assert candidate(
    {
        'key1': {
            'lines': [
                {'line_number': 1},
                {'line_number': 2},
            ]
        }
    },
    {'key1': {1: [3]}}
) == {
    'key1': {
        'lines': [
            {'line_number': 1, 'calls_from': [3]},
            {'line_number': 2},
        ]
    }
}
	assert candidate(
    {
        "foo": {
            "lines": [
                {
                    "line_number": 1,
                    "calls_from": [2]
                }
            ]
        }
    },
    {
        1: {
            2: 1,
            3: 2
        },
        2: {
            1: 1,
            3: 2
        }
    }
) == {
    "foo": {
        "lines": [
            {
                "line_number": 1,
                "calls_from": [2]
            }
        ]
    }
}
	assert candidate(
    {
        "foo": {
            "lines": [
                {
                    "line_number": 1,
                    "calls_from": [2]
                },
                {
                    "line_number": 2,
                    "calls_from": [1]
                }
            ]
        }
    },
    {
        1: {
            2: [1]
        },
        2: {
            1: [2]
        }
    }
) == {
    "foo": {
        "lines": [
            {
                "line_number": 1,
                "calls_from": [2]
            },
            {
                "line_number": 2,
                "calls_from": [1]
            }
        ]
    }
}
	assert candidate(
    {
        'a': {
            'lines': [
                {
                    'line_number': 1,
                    'calls_from': {
                        2: 10
                    }
                },
                {
                    'line_number': 2,
                    'calls_from': {
                        3: 10
                    }
                },
            ]
        }
    },
    {
        1: {2: 10},
        2: {3: 10}
    }
) == {
    'a': {
        'lines': [
            {
                'line_number': 1,
                'calls_from': {
                    2: 10
                }
            },
            {
                'line_number': 2,
                'calls_from': {
                    3: 10
                }
            },
        ]
    }
}
def test_check():
	check(update_profile_dict_with_reverse_dict)
