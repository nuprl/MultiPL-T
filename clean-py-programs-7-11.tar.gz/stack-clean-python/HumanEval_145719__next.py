def _next(user_input):
    """
    Convenience function that checks if user
    intended to skip a parameter setting.
    @param user_input: String input provided by the user.
    @return: True, if user provided an input that indicates
    parameter input skip. False otherwise.
    """
    ### Canonical solution below ###
    return user_input.upper() == "N" or len(user_input) == 0 or user_input.isspace()


### Unit tests below ###
def check(candidate):
	assert candidate("Y") is False
	assert candidate(" ")
	assert candidate("yes") == False
	assert candidate("yeah") == False
	assert candidate("abc") == False
	assert candidate("Y") == False
	assert not candidate("no")
	assert not candidate("yE")
	assert not candidate("Yes")
	assert candidate(" yes ") is False
	assert candidate("b") == False
	assert candidate("n  s  ") == False
	assert candidate("")
	assert candidate("N")
	assert candidate("yessir") == False
	assert not candidate("Ye")
	assert not candidate("test")
	assert candidate("yessirree") == False
	assert candidate("yes") is False
	assert candidate("  y") == False
	assert not candidate("Y")
	assert candidate("n  s ") == False
	assert candidate("\n")
	assert candidate("0") == False
	assert candidate("1") == False
	assert candidate("NO") == False
	assert candidate("n") == True
	assert not candidate("x")
	assert candidate("") == True
	assert candidate("  ")
	assert candidate("no") == False
	assert candidate("a") == False
	assert candidate("c") == False
	assert candidate("No") == False
	assert candidate("yah") == False
	assert candidate("  ") == True
	assert candidate("y") == False
	assert candidate("YES") is False
	assert candidate("N") == True
	assert candidate(" ") is True
	assert not candidate("a")
	assert candidate("yup") == False
	assert candidate("n")
	assert candidate("N") is True
	assert candidate("") is True
	assert candidate("YES") == False
	assert candidate("y") is False
	assert candidate("n  s") == False
	assert candidate(" ") == True
	assert candidate("Yes") is False
	assert not candidate("yes")
	assert not candidate("yup")
	assert candidate("n") is True
	assert candidate("yessiree") == False
	assert candidate("Yes") == False
	assert candidate("yea") == False
	assert candidate("ABC") == False
	assert not candidate("yEs")
	assert not candidate("YES")
	assert not candidate("y")
def test_check():
	check(_next)
