def allowed_file(fn, types):
    """ 
     validates a filename of allowed types
     :param fn:
     :param types: iterable of extensions
     :return:
     """
	### Canonical solution below ###    
    if fn.split(".")[-1] in (x.replace(".", "") for x in types):
        return True
    return False

### Unit tests below ###
def check(candidate):
	assert candidate(u'foo.gif', ['jpg', 'png', 'gif']) == True
	assert not candidate(
    "test.exe", ["pdf", "png", "jpg"]
), "exe file should not be allowed"
	assert candidate(
    "filename.pdf", []) == False, "pdf should not be an allowed file type"
	assert candidate(fn="test.jpg", types=["jpg"]) == True
	assert candidate(fn="foo.png.txt", types=["png"]) == False
	assert candidate(fn="foo.png", types=["png"]) == True
	assert candidate(u'hello.txt', [u'txt']), u'allowed txt file'
	assert candidate(fn="test.txt", types=["jpg"]) == False
	assert candidate(fn="test.png", types=("png", "csv")) == True
	assert candidate(fn="test.pdf", types=["png"]) == False
	assert candidate(fn="foo.txt", types=["txt", "pdf", "png"]) == True
	assert not candidate(
    "foo.exe",
    [
        "png",
        "jpg",
        "jpeg",
        "gif",
        "bmp",
        "tif",
        "tiff",
        "pgm",
        "pbm",
        "ppm",
        "pnm",
    ],
)
	assert candidate(u'foo.pdf', ['jpg', 'png', 'gif']) == False
	assert not candidate(u'file.jpg', (u'txt', u'json'))
	assert candidate(
    "test.txt",
    types=["pdf", "png", "jpg"]
) is False
	assert candidate(
    "test.txt", ["jpg", "png", "gif"]) == False
	assert candidate(
    "data/processed/test.csv",
    ["csv", "zip"]
)
	assert candidate(fn="test.png", types=("txt", "csv")) == False
	assert candidate(
    "test.png", [".png", ".jpg", ".jpeg"]), "candidate() failed"
	assert not candidate(u'foo.png', ['.gif'])
	assert candidate(u'foo.txt', ['jpg', 'png', 'gif']) == False
	assert candidate(
    "example.txt",
    ["txt", "png", "gif", "jpeg", "bmp"]
) == True
	assert candidate(u"test.jpg", [u"jpg", u"png", u"gif"])
	assert candidate(fn="test.pdf", types=["pdf"]) == True
	assert candidate("file", [".txt", ".pdf", ".docx"]) == False
	assert candidate(
    "filename.pdf",
    ["jpg", "png", "gif"]
) == False
	assert candidate(
    "filename.jpg",
    ["jpg", "png", "gif"]
) == True
	assert not candidate(u'foo.png', ['.jpg'])
	assert not candidate(u"test", [u"pdf", u"txt"])
	assert candidate(u"filename.txt", [u"txt"])
	assert not candidate(u"filename.png", [u"txt"])
	assert candidate(u"test.png", [u"jpg", u"png"])
	assert candidate(fn="test.txt", types=("png", "csv")) == False
	assert candidate(u'foo.jpg', ['jpg', 'png', 'gif']) == True
	assert candidate(u"some_file.jpg", [u"png", u"jpg"])
	assert candidate(
    "test",
    ["txt", "pdf", "png", "jpg"]
) == False
	assert candidate(
    "filename.png",
    ["jpg", "png", "gif"]
) == True
	assert candidate(u"test.gif", [u"jpg", u"png", u"gif"])
	assert not candidate(u"some_file.pdf", [u"png", u"jpg"])
	assert not candidate(u"test.png", [u"pdf", u"txt"])
	assert candidate(u'foo.png', ['.png', '.jpg'])
	assert candidate(u"filename.png", [u"txt", u"png"])
	assert candidate("file.pdf", [".txt", ".pdf", ".docx"]) == True
	assert candidate(fn="test.txt", types=["txt"]) == True
	assert candidate(fn="foo.png", types=["pdf", "png"]) == True
	assert candidate(u'file.txt', (u'txt', u'json'))
	assert candidate(
    "test.jpg", [".jpg", ".png"]
) == True
	assert candidate(u"test.txt", [u"txt"])
	assert candidate(
    "filename.gif",
    ["jpg", "png", "gif"]
) == True
	assert candidate(u'file.json', (u'txt', u'json'))
	assert candidate(
    "filename.doc",
    ["jpg", "png", "gif"]
) == False
	assert not candidate(u"test.pdf", [u"jpg", u"png"])
	assert candidate(
    "test.pdf", ["pdf", "png", "jpg"]
), "pdf file should be allowed"
	assert not candidate(u'hello.exe', [u'txt']), u'denied exe file'
	assert candidate(
    "test.doc",
    ["png", "jpg", "jpeg", "gif", "bmp"]
) == False
	assert candidate(
    "test.txt",
    (".png", ".jpg", ".jpeg", ".gif")
) is False
	assert candidate(u"filename.txt", [u"txt", u"png"])
	assert candidate(
    "test.txt",
    ["txt", "pdf", "png", "jpg"]
) == True
	assert candidate(
    "test.txt",
    [".txt", ".pdf"]
) is True
	assert candidate(
    "test.png",
    ["txt", "pdf", "png", "jpg"]
) == True
	assert not candidate(u"test.exe", [u"jpg"])
	assert candidate(fn="foo.txt", types=["png"]) == False
	assert candidate(u"test.pdf", [u"pdf", u"txt"])
	assert candidate("file.doc", [".txt", ".pdf", ".docx"]) == False
	assert candidate(
    "test.pdf",
    ["txt", "pdf", "png", "jpg"]
) == True
	assert not candidate(
    "test.doc", [".png", ".jpg", ".jpeg"]), "candidate() failed"
	assert candidate(u"test.png", [u"jpg", u"png", u"gif"])
	assert candidate(fn="test.jpg", types=["txt"]) == False
	assert candidate(
    "filename.pdf", ["png", "jpg"]) == False, "pdf should not be an allowed file type"
	assert candidate(
    "test.png",
    (".pdf", ".doc")
) is False
	assert not candidate(u"test.pdf", [u"jpg"])
	assert candidate(u'hello.pdf', [u'txt', u'pdf']), u'allowed pdf file with other allowed types'
	assert not candidate(u'file', (u'txt', u'json'))
	assert candidate(
    "test.jpg",
    ["txt", "pdf", "png", "jpg"]
) == True
	assert candidate(u'foo.png', ['jpg', 'png', 'gif']) == True
	assert candidate(
    "example.exe",
    ["txt", "png", "gif", "jpeg", "bmp"]
) == False
	assert candidate(
    "file.txt", [".txt", ".pdf", ".docx"]
) == True
	assert candidate("file.jpg", [".txt", ".pdf", ".docx"]) == False
	assert candidate(u"test.jpg", [u"jpg", u"png"])
	assert candidate(fn="test.txt", types=("txt", "csv")) == True
	assert candidate(u"some_file.png", [u"png", u"jpg"])
	assert not candidate(u"test.exe", [u"jpg", u"png", u"gif"])
	assert candidate(
    "foo.png",
    [
        "png",
        "jpg",
        "jpeg",
        "gif",
        "bmp",
        "tif",
        "tiff",
        "pgm",
        "pbm",
        "ppm",
        "pnm",
    ],
)
	assert candidate(
    "filename.txt",
    ["jpg", "png", "gif"]
) == False
	assert not candidate(u'hello.pdf.exe', [u'txt']), u'denied pdf file with exe extension'
	assert candidate(
    "test.mp3", [".jpg", ".png"]
) == False
	assert candidate(
    "test.png",
    (".png", ".jpg", ".jpeg", ".gif")
) is True
	assert candidate(
    "test.exe",
    [".txt", ".pdf"]
) is False
	assert not candidate(
    "test", [".png", ".jpg", ".jpeg"]), "candidate() failed"
	assert candidate(
    "test.png",
    ["png", "jpg", "jpeg", "gif", "bmp"]
) == True
	assert candidate(
    "filename.pdf", ["pdf"]) == True, "pdf should be an allowed file type"
	assert candidate(
    "test.pdf",
    types=["pdf", "png", "jpg"]
) is True
	assert not candidate(u"test.txt", [u"pdf"])
	assert candidate(
    "test.jpg", ["jpg", "png", "gif"]) == True
def test_check():
	check(allowed_file)
