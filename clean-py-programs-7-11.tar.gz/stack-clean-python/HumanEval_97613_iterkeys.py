def iterkeys(obj, **kwargs):
    """Iterate over dict keys in Python 2 & 3."""
    ### Canonical solution below ###
    return (obj.iterkeys(**kwargs)
            if hasattr(obj, 'iterkeys')
            else iter(obj.keys(**kwargs)))


### Unit tests below ###
def check(candidate):
	assert list(candidate(dict(a=1, b=2))) == ['a', 'b']
	assert list(candidate(dict.fromkeys('abc'))) == ['a', 'b', 'c']
	assert list(candidate({1: 'a', 2: 'b', 3: 'c'})) == [1, 2, 3]
	assert list(candidate({'a': 1, 'b': 2})) == ['a', 'b']
	assert list(candidate(dict(a=1, b=2, c=3))) == ['a', 'b', 'c']
	assert list(candidate({})) == []
def test_check():
	check(iterkeys)
