def _remove_batch_rule(rules):
  """Removes the batch rule and returns the rest."""
    ### Canonical solution below ###
  return [(k, v) for (k, v) in rules if k != "batch"]


### Unit tests below ###
def check(candidate):
	assert candidate(rules=[("foo", "bar"), ("batch", "baz")]) == [
    ("foo", "bar")]
	assert candidate(
    [("batch", "xla"), ("xla", "xla"), ("batch", "batch")]) == [("xla", "xla")]
	assert candidate(
    []) == []
	assert candidate(
    [("batch", "batch_rule"), ("not_batch", "not_batch_rule")]) == [
    ("not_batch", "not_batch_rule")]
	assert candidate(
    [(x, "batch") for x in ["foo"]]) == [
        ("foo", "batch"),
    ]
	assert candidate(
    [("a", 1), ("b", 2), ("batch", 3)]) == [("a", 1), ("b", 2)]
	assert candidate(
    [(x, "batch") for x in ["foo", "bar", "baz", "qux"]]) == [
        ("foo", "batch"),
        ("bar", "batch"),
        ("baz", "batch"),
        ("qux", "batch"),
    ]
	assert candidate(
    [(x, "batch") for x in ["foo", "bar"]]) == [
        ("foo", "batch"),
        ("bar", "batch"),
    ]
	assert candidate([("foo", "bar"), ("foo", "baz"), ("bar", "baz")]) == [
    ("foo", "bar"), ("foo", "baz"), ("bar", "baz")]
	assert candidate(
    [("batch", "foo"), ("batch", "bar"), ("foo", "bar")]) == [("foo", "bar")]
	assert candidate(
  [("foo", "bar"), ("baz", "qux"), ("batch", "rule")]) == [
    ("foo", "bar"), ("baz", "qux")]
	assert candidate(
  [("xla", "xla"), ("batch", "batch"), ("y", "y")]) == [("xla", "xla"), ("y", "y")]
	assert candidate([("cpu", "test"), ("tpu", "test")]) == [
    ("cpu", "test"), ("tpu", "test")
]
	assert candidate([]) == []
	assert candidate(
    [("a", "b"), ("batch", "c"), ("d", "e")]) == [("a", "b"), ("d", "e")]
	assert candidate(
    [("batch", "batch_rule"), ("not_batch", "not_batch_rule")]
) == [("not_batch", "not_batch_rule")]
	assert candidate(
    [("batch", "foo"), ("batch", "bar"), ("not_batch", "baz")]) == [
    ("not_batch", "baz")]
	assert candidate(
    [("batch", "foo"), ("batch", "bar"), ("other", "baz")]) == [
        ("other", "baz"),
    ]
	assert candidate(
    [("batch", "a"), ("batch", "b"), ("a", "c"), ("b", "c")]) == [("a", "c"), ("b", "c")]
	assert candidate(
    [("a", 1), ("batch", 2), ("c", 3)]) == [("a", 1), ("c", 3)]
	assert candidate(
    [("batch", "test"), ("cpu", "test"), ("tpu", "test")]) == [
      ("cpu", "test"), ("tpu", "test")
  ]
	assert candidate(
  [("a", "b"), ("batch", "c"), ("d", "e")]) == [("a", "b"), ("d", "e")]
	assert candidate([("batch", 1)]) == []
	assert candidate(
    [(x, "batch") for x in ["foo", "bar", "baz"]]) == [
        ("foo", "batch"),
        ("bar", "batch"),
        ("baz", "batch"),
    ]
	assert candidate(
  [("foo", "bar"), ("baz", "bat"), ("batch", "bat")]) == \
  [("foo", "bar"), ("baz", "bat")]
	assert candidate(
    [("batch", "foo"), ("batch", "bar"), ("non_batch", "baz")]) == [
        ("non_batch", "baz")]
def test_check():
	check(_remove_batch_rule)
