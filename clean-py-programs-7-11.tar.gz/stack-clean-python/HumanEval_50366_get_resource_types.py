def get_resource_types(resources):
    """
    jinja2 helper fuction to get the list of unique resource types
    """
    ### Canonical solution below ###
    return set( resource["resource_type"] for resource in resources )


### Unit tests below ###
def check(candidate):
	assert candidate( [{"resource_type":"foo"}] ) == {"foo"}
	assert candidate( [ {"resource_type": "a"}, {"resource_type": "b"}, {"resource_type": "a"} ] ) == set( ["a", "b"] )
	assert candidate( [{"resource_type": "a"}, {"resource_type": "b"}] ) == set(["a", "b"])
	assert candidate( [ {"resource_type": "a"}, {"resource_type": "a"}, {"resource_type": "b"} ] ) == set( ["a", "b"] )
	assert candidate( [ ] ) == set( [] )
	assert candidate( [{"resource_type":"foo"},{"resource_type":"bar"},{"resource_type":"foo"}] ) == {"foo","bar"}
	assert candidate( [ {"resource_type":"t1"} ] ) == set( ["t1"] )
	assert candidate(
    [
        {"resource_type": "vpc", "name": "vpc-12345"},
        {"resource_type": "vpc", "name": "vpc-67890"},
        {"resource_type": "instance", "name": "i-12345"},
        {"resource_type": "instance", "name": "i-67890"},
        {"resource_type": "vpc", "name": "vpc-12345"},
        {"resource_type": "vpc", "name": "vpc-67890"},
        {"resource_type": "instance", "name": "i-12345"},
        {"resource_type": "instance", "name": "i-67890"}
    ]
) == set(["vpc", "instance"])
	assert candidate([{"resource_type": "AWS::EC2::Volume"}, {"resource_type": "AWS::EC2::Instance"}]) == {"AWS::EC2::Volume", "AWS::EC2::Instance"}
	assert candidate( [
    {"resource_type": "type_a"},
    {"resource_type": "type_b"},
    {"resource_type": "type_a"},
    {"resource_type": "type_b"},
    {"resource_type": "type_c"}
] ) == set( ["type_a", "type_b", "type_c"] )
	assert candidate([{"resource_type": "AWS::EC2::Volume"}]) == {"AWS::EC2::Volume"}
	assert candidate(
    [
        {"resource_type": "vpc", "name": "vpc-12345"},
        {"resource_type": "vpc", "name": "vpc-67890"}
    ]
) == set(["vpc"])
	assert candidate([{"resource_type": "AWS::EC2::Instance"}]) == {"AWS::EC2::Instance"}
	assert candidate([]) == set()
	assert candidate( [] ) == set()
	assert candidate( [{"resource_type":"foo"},{"resource_type":"bar"}] ) == {"foo","bar"}
	assert candidate( [ {"resource_type": "a"} ] ) == set( ["a"] )
	assert candidate( [ { "resource_type" : "foo" }, { "resource_type" : "bar" } ] ) == set( ["foo", "bar"] )
	assert candidate( [{"resource_type":"foo"},{"resource_type":"foo"}] ) == {"foo"}
	assert candidate( [ {"resource_type":"t1"}, {"resource_type":"t2"} ] ) == set( ["t1","t2"] )
	assert candidate( [
    { "resource_type": "a" },
    { "resource_type": "a" },
    { "resource_type": "b" },
    ] ) == set( [ "a", "b" ] )
	assert candidate( [ {"resource_type": "b"}, {"resource_type": "a"} ] ) == set( ["a", "b"] )
	assert candidate( [ {"resource_type":"t1"}, {"resource_type":"t2"}, {"resource_type":"t1"} ] ) == set( ["t1","t2"] )
	assert candidate(
    [
        {"resource_type": "AWS::IAM::User"},
        {"resource_type": "AWS::IAM::User"},
        {"resource_type": "AWS::IAM::Role"},
        {"resource_type": "AWS::EC2::Instance"},
        {"resource_type": "AWS::EC2::Instance"},
    ]
) == {"AWS::IAM::User", "AWS::IAM::Role", "AWS::EC2::Instance"}
	assert candidate( [ {"resource_type": "a"}, {"resource_type": "a"} ] ) == set( ["a"] )
	assert candidate( [ { "resource_type" : "foo" } ] ) == set( ["foo"] )
	assert candidate( [ {"resource_type": "a"}, {"resource_type": "b"} ] ) == set( ["a", "b"] )
def test_check():
	check(get_resource_types)
