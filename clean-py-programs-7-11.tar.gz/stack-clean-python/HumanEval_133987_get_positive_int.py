def get_positive_int(obj: dict, name: str) -> int:
    """Get and check the value of name in obj is positive integer."""
    ### Canonical solution below ###
    value = obj[name]
    if not isinstance(value, int):
        raise TypeError(
            f'{name} must be integer: {type(value)}')
    elif value < 0:
        raise ValueError(
            f'{name} must be positive integer: {value}')
    return value


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'name': 'Alice', 'age': 24, 'weight': 60},
    'age') == 24
	assert candidate(dict(a=0), 'a') == 0
	assert candidate(
    {'a': 1, 'b': 2}, 'b') == 2
	assert candidate(
    {'a': 1, 'b': 2}, 'a') == 1
	assert candidate(
    {'name': 'Alice', 'age': 24, 'weight': 60},
    'weight') == 60
	assert candidate(
    {'a': 1}, 'a') == 1
	assert candidate(
    {'positive_int': 1}, 'positive_int') == 1
	assert candidate(
    {'a': 10}, 'a') == 10
	assert candidate(obj={'a': 10}, name='a') == 10
	assert candidate(obj={'a': 0}, name='a') == 0
	assert candidate(dict(positive_int=10), 'positive_int') == 10
	assert candidate(obj={"a": 0}, name="a") == 0
	assert candidate(
    {'positive_int': 0}, 'positive_int') == 0
	assert candidate(
    {'n': 0}, 'n') == 0
	assert candidate(
    {'a': 3}, 'a') == 3
	assert candidate(dict(a=1), 'a') == 1
	assert candidate(
    {'n': 10}, 'n') == 10
	assert candidate(
    {'a': 0}, 'a') == 0
	assert candidate(
    {'x': 1}, 'x') == 1
	assert candidate(
    {'a': 1, 'b': 'foo', 'c': -1}, 'a') == 1
	assert candidate(
    {'n': 5}, 'n') == 5
	assert candidate(
    {'name': 'John', 'age': 31}, 'age') == 31
	assert candidate(obj={"a": 1}, name="a") == 1
	assert candidate(
    {'name': 'Alice', 'age': 25}, 'age') == 25
	assert candidate(
    {'name': 'test', 'value': 10}, 'value') == 10
	assert candidate(
    {'positive_int': 1000}, 'positive_int') == 1000
	assert candidate(
    {'positive_int': 3}, 'positive_int') == 3
	assert candidate(
    {'name': 'test', 'value': 0}, 'value') == 0
	assert candidate(
    {'positive_int': 100}, 'positive_int') == 100
def test_check():
	check(get_positive_int)
