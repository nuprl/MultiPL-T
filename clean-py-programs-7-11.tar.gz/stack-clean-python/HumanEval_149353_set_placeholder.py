def set_placeholder(dirname):
    """ 
     return string of @'s with same length
     """
	### Canonical solution below ###    
    return '@' * len(dirname)

### Unit tests below ###
def check(candidate):
	assert candidate('~john') == '@' * len('~john')
	assert candidate('~john/bin') == '@' * len('~john/bin')
	assert candidate(candidate('test12345')) == '@@@@@@@@@'
	assert candidate('abc') == '@@@'
	assert candidate(u'👍🏿👍🏿') == u'@@@@'
	assert candidate('hello') == '@@@@@'
	assert candidate('~/bin') == '@' * len('~/bin')
	assert candidate("abc123") == "@@@@@@"
	assert candidate("abc") == "@@@"
	assert candidate('~john/') == '@' * len('~john/')
	assert candidate('~john/bin/') == '@' * len('~john/bin/')
	assert candidate('/usr/bin/') == '@' * len('/usr/bin/')
	assert candidate('~/') == '@' * len('~/')
	assert candidate('/usr/bin') == '@' * len('/usr/bin')
	assert candidate('~') == '@' * len('~')
	assert candidate('~/bin/') == '@' * len('~/bin/')
	assert candidate('a') == '@'
def test_check():
	check(set_placeholder)
