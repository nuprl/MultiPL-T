def colorstr(*inputs):
    """ return platform-dependent emoji-safe version of string
     
     Colors a string https://en.wikipedia.org/wiki/ANSI_escape_code, i.e.  \
     colorstr('blue', 'hello world')
     """
	### Canonical solution below ###    
    *args, string = inputs if len(inputs) > 1 else ('blue', 'bold', inputs[0])
    colors = {'black': '\033[30m',  # basic colors
              'red': '\033[31m',
              'green': '\033[32m',
              'yellow': '\033[33m',
              'blue': '\033[34m',
              'magenta': '\033[35m',
              'cyan': '\033[36m',
              'white': '\033[37m',
              'bright_black': '\033[90m',  # bright colors
              'bright_red': '\033[91m',
              'bright_green': '\033[92m',
              'bright_yellow': '\033[93m',
              'bright_blue': '\033[94m',
              'bright_magenta': '\033[95m',
              'bright_cyan': '\033[96m',
              'bright_white': '\033[97m',
              'end': '\033[0m',  # misc
              'bold': '\033[1m',
              'underline': '\033[4m'}
    return ''.join(colors[x] for x in args) + f'{string}' + colors['end']

### Unit tests below ###
def check(candidate):
	assert candidate('blue', 'hello world') == \
    '\033[34mhello world\033[0m'
	assert candidate(1) == candidate('1')
	assert candidate(
    'blue', 'hello world') == '\033[34mhello world\033[0m', 'hello world'
	assert candidate('blue', 'hello world') == f'{candidate("blue", "hello world")}'
	assert candidate('red', 'hello') == '\033[31mhello\033[0m'
	assert candidate(
    'blue', 'hello world')!= '\033[34mhello world', 'hello world'
	assert candidate(
    'blue', 'hello world') == '\033[34mhello world\033[0m'
	assert candidate(
    'Hello, World!') == '\x1b[34m\x1b[1mHello, World!\x1b[0m'
	assert candidate(
   'red', 'hello world') == '\x1b[31mhello world\x1b[0m'
	assert candidate(
    'underline', 'hello world') == '\x1b[4mhello world\x1b[0m'
	assert candidate('blue', 'hello world') == '\033[34mhello world\033[0m'
	assert candidate(
    'bold', 'hello world') == '\x1b[1mhello world\x1b[0m'
	assert candidate(
    'blue', 'hello world') == '\x1b[34mhello world\x1b[0m'
	assert candidate('blue', 'hello world') == '\x1b[34mhello world\x1b[0m'
	assert candidate('🚀') == candidate('🚀')
	assert candidate(
    'blue', 'hello world')!= '\033[34mhello world\033[0m\033[0m', 'hello world'
def test_check():
	check(colorstr)
