def recover_psois_(psois, psois_orig, recoverer, random_state):
    """ Apply a polygon recoverer to input polygons in-place.
     
     Parameters
     ----------
     psois : list of imgaug.augmentables.polys.PolygonsOnImage or imgaug.augmentables.polys.PolygonsOnImage
     The possibly broken polygons, e.g. after augmentation.
     The `recoverer` is applied to them.
     
     psois_orig : list of imgaug.augmentables.polys.PolygonsOnImage or imgaug.augmentables.polys.PolygonsOnImage
     Original polygons that were later changed to `psois`.
     They are an extra input to `recoverer`.
     
     recoverer : imgaug.augmentables.polys._ConcavePolygonRecoverer
     The polygon recoverer used to repair broken input polygons.
     
     random_state : None or int or RNG or numpy.random.Generator or numpy.random.BitGenerator or numpy.random.SeedSequence or numpy.random.RandomState
     An RNG to use during the polygon recovery.
     
     Returns
     -------
     list of imgaug.augmentables.polys.PolygonsOnImage or imgaug.augmentables.polys.PolygonsOnImage
     List of repaired polygons. Note that this is `psois`, which was
     changed in-place.
     
     """
	### Canonical solution below ###    
    input_was_list = True
    if not isinstance(psois, list):
        input_was_list = False
        psois = [psois]
        psois_orig = [psois_orig]

    for i, psoi in enumerate(psois):
        for j, polygon in enumerate(psoi.polygons):
            poly_rec = recoverer.recover_from(
                polygon.exterior, psois_orig[i].polygons[j],
                random_state)

            # Don't write into `polygon.exterior[...] = ...` because the
            # shapes might have changed. We could also first check if the
            # shapes are identical and only then write in-place, but as the
            # array for `poly_rec.exterior` was already created, that would
            # not provide any benefits.
            polygon.exterior = poly_rec.exterior

    if not input_was_list:
        return psois[0]
    return psois

### Unit tests below ###
def check(candidate):
	assert candidate([], [], None, 1) == []
	assert candidate([], None, None, None) == []
	assert candidate([], [], None, None) == []
def test_check():
	check(recover_psois_)
