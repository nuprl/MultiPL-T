def istupleoftuples(x):
    """Is an object a python list of lists x=[[1,2], [3,4]]"""
    ### Canonical solution below ###
    return type(x) is tuple and type(x[0]) is tuple


### Unit tests below ###
def check(candidate):
	assert candidate( ((1,2), (3,4)) ) == True
	assert not candidate( [ [1,2], [3,4], 5 ] )
	assert candidate( ((1,2),) ) == True
	assert not candidate( [ [1,2], [3,4] ] )
	assert candidate( [1,2,3] ) == False
	assert candidate( ( (1,2), (3,4) ) ) == True
	assert not candidate( {1:2} )
	assert candidate( ( (1,2), ) )
	assert candidate( (('a','b'),('c','d')) ) == True
	assert candidate( ((1,2), (3,4), (5,6)) ) == True
	assert candidate( ((1,2), (3,4), (5,6), (7,8), (9,10), (11,12)) ) is True
	assert candidate( ((1,2), (3,4), (5,6), (7,8), (9,10), (11,12), (13,14), (15,16)) ) is True
	assert candidate( (1,2,[3,4]) ) == False
	assert not candidate(tuple([1,2,3]))
	assert not candidate( "hello" )
	assert not candidate( [[1,2]] )
	assert candidate( [ [ (), () ], [ (), () ] ] ) == False
	assert not candidate( (1,2) )
	assert not candidate( [1,2,3] )
	assert candidate( ((1,2),(3,4)) )
	assert candidate( [ ( (), () ), [ (), () ] ] ) == False
	assert candidate( [ [1,2], [3,4] ] ) == False
	assert not candidate( [ (1,2), (3,4) ] )
	assert candidate(((1,2))) == False
	assert not candidate( [ [1,2], 3,4 ] )
	assert not candidate( [[1,2,3,4], [5,6,7,8]] )
	assert candidate( ((1,2,3,4),(5,6,7,8)) ) == True
	assert candidate( (1,2,3,4) ) == False
	assert candidate( ((1,2), (3,4), (5,6), (7,8), (9,10)) ) is True
	assert candidate( ((1,2), (3,4), (5,6), (7,8)) ) is True
	assert candidate( [1,2] ) == False
	assert candidate( ((1,2,3),(4,5,6)) ) == True
	assert candidate( ((1,2),(3,4)) ) == True
	assert candidate( (1,2,3) ) is False
	assert candidate( ( ( (), () ), ( (), () ) ) ) == True
	assert candidate( (1,(2,3)) ) is False
	assert not candidate( "abc" )
	assert candidate( ((1,2), (3,4)) )
	assert not candidate( [[1,2], [3,4], [5,6,7,8]] )
	assert candidate(1) == False
	assert candidate( ((1,2),) )
	assert candidate( (1,2, (3,4)) ) is False
	assert candidate( ((1,2),(3,4)) ) is True
	assert not candidate( [1,2] )
	assert not candidate( [[1,2], [3,4,5,6]] )
	assert candidate(((1,2), (3,4))) == True
	assert candidate(((1,2),(3,4),(5,6),(7,8))) == True
	assert candidate( ((1,2,3,4,5),(6,7,8,9,10)) ) == True
	assert not candidate((1,2,3))
	assert not candidate(1)
	assert candidate( ( (1,2), (3,4) ) )
	assert candidate( ((1,2), (3,4)) ) is True
	assert candidate([1,2]) == False
	assert candidate( [1,2] ) is False
	assert candidate((1,2,3)) == False
	assert not candidate( (1,2,3,4) )
	assert candidate( [1,2,3] ) is False
	assert candidate((tuple(), tuple()))
	assert candidate( ( (), ) ) == True
	assert candidate( (1,2) ) is False
	assert candidate( ((1,2), (3,4), (5,6), (7,8), (9,10), (11,12), (13,14)) ) is True
	assert candidate( (1,) ) == False
	assert not candidate( 1 )
	assert candidate( (1,2,3) ) == False
	assert not candidate( (1,2,3) )
	assert candidate( [ (1,2), (3,4) ] ) == False
	assert not candidate( 1.23 )
	assert candidate( ( ( (), () ), ) ) == True
	assert not candidate( [[1,2],[3,4]] )
	assert not candidate( [ (1,2), [3,4] ] )
	assert candidate(((1,2),(3,4),(5,6))) == True
	assert candidate( ((),) )
	assert candidate( (1,2,3,4,5) ) == False
	assert candidate( (('a','b'),('c','d'),('e','f')) ) == True
	assert candidate( ('a','b') ) == False
	assert candidate( ([1],) ) == False
	assert candidate( [[1,2], [3,4]] ) == False
	assert candidate( ((1,2), (3,4), (5,6), (7,8), (9,10), (11,12), (13,14), (15,16), (17,18)) ) is True
	assert not candidate( [ (1,2), (3,4,5) ] )
	assert not candidate((1,2,3, (1,2,3)))
	assert candidate( ([1], [2]) ) == False
	assert not candidate( [1,2,(3,4)] )
	assert candidate( [ (1,2,3,4) ] ) == False
	assert candidate( [ ( (), () ), ( (), () ) ] ) == False
	assert candidate([1,2,3]) == False
	assert candidate( (1,2) ) == False
	assert candidate((1,2)) == False
	assert not candidate([1,2,3])
	assert not candidate( [1,2,3,4] )
	assert not candidate( [1] )
	assert not candidate( [ (1,2,3), (3,4) ] )
def test_check():
	check(istupleoftuples)
