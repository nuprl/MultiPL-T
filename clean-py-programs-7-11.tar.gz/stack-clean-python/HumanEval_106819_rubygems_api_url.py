def rubygems_api_url(name, version=None, repo='https://rubygems.org/api'):
    """ 
     Return a package API data URL given a name, an optional version and a base
     repo API URL.
     
     For instance:
     https://rubygems.org/api/v2/rubygems/action_tracker/versions/1.0.2.json
     
     If no version, we return:
     https://rubygems.org/api/v1/versions/turbolinks.json
     
     Unused:
     https://rubygems.org/api/v1/gems/mqlight.json
     """
	### Canonical solution below ###    
    repo = repo.rstrip('/')
    if version:
        api_url = '{repo}/v2/rubygems/{name}/versions/{version}.json'
    else:
        api_url = '{repo}/v1/versions/{name}.json'
    return api_url.format(**locals())

### Unit tests below ###
def check(candidate):
	assert candidate(name='action_tracker', version='1.0.2') == \
        'https://rubygems.org/api/v2/rubygems/action_tracker/versions/1.0.2.json'
	assert candidate(name='turbolinks') == 'https://rubygems.org/api/v1/versions/turbolinks.json'
	assert candidate(
    'action_tracker',
    version='1.0.2') == 'https://rubygems.org/api/v2/rubygems/action_tracker/versions/1.0.2.json'
	assert candidate(name='turbolinks') == (
    'https://rubygems.org/api/v1/versions/turbolinks.json')
	assert candidate(name='action_tracker', version='1.0.2') == 'https://rubygems.org/api/v2/rubygems/action_tracker/versions/1.0.2.json'
	assert candidate(name='turbolinks', version='2.5.3') == \
    'https://rubygems.org/api/v2/rubygems/turbolinks/versions/2.5.3.json'
	assert candidate(name='turbolinks', version='5.1.1') == 'https://rubygems.org/api/v2/rubygems/turbolinks/versions/5.1.1.json'
	assert candidate(name='turbolinks') == \
    'https://rubygems.org/api/v1/versions/turbolinks.json'
	assert candidate(name='action_tracker', version='1.0.2') == \
    'https://rubygems.org/api/v2/rubygems/action_tracker/versions/1.0.2.json'
	assert candidate(name='turbolinks', version='5.0.0') == (
    'https://rubygems.org/api/v2/rubygems/turbolinks/versions/5.0.0.json')
	assert candidate(
    'action_tracker') == 'https://rubygems.org/api/v1/versions/action_tracker.json'
	assert candidate(name='turbolinks') == \
        'https://rubygems.org/api/v1/versions/turbolinks.json'
	assert candidate(name='action_tracker', version='1.0.2') == (
    'https://rubygems.org/api/v2/rubygems/action_tracker/versions/1.0.2.json')
	assert candidate(
    name='action_tracker',
) == 'https://rubygems.org/api/v1/versions/action_tracker.json'
	assert candidate(name='turbolinks', version='1.0.2') == \
    'https://rubygems.org/api/v2/rubygems/turbolinks/versions/1.0.2.json'
	assert candidate(
    name='action_tracker',
    version='1.0.2',
) == 'https://rubygems.org/api/v2/rubygems/action_tracker/versions/1.0.2.json'
	assert candidate(name='action_tracker') == (
    'https://rubygems.org/api/v1/versions/action_tracker.json')
	assert candidate(name='turbolinks', version='1.0.2') == 'https://rubygems.org/api/v2/rubygems/turbolinks/versions/1.0.2.json'
	assert candidate(name='action_tracker') == \
    'https://rubygems.org/api/v1/versions/action_tracker.json'
	assert candidate(name='turbolinks', version='2.5.3') == 'https://rubygems.org/api/v2/rubygems/turbolinks/versions/2.5.3.json'
def test_check():
	check(rubygems_api_url)
