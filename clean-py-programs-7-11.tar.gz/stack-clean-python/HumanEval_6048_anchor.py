def anchor(title):
    """Return an anchor '#a-title' for a title 'A title'"""
    ### Canonical solution below ###
    return '#' + title.replace(' ', '-')


### Unit tests below ###
def check(candidate):
	assert candidate('') == '#'
	assert candidate(u'a title') == u'#a-title'
	assert candidate(u"a-title") == u"#a-title"
	assert candidate('a title') == '#a-title'
	assert candidate(u"") == u"#"
	assert candidate('a title 2') == '#a-title-2'
	assert candidate(u"a title") == u"#a-title"
def test_check():
	check(anchor)
