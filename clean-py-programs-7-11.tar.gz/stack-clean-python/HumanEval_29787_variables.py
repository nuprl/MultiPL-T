def variables():
    """Data collection parameter names.
    List of strings."""
    ### Canonical solution below ###
    return ["delay","angle","laser_on","repeat","repeat2","level","translation",
            "translation_mode","chopper_mode","temperature","xray_on"]


### Unit tests below ###
def check(candidate):
	assert candidate( ) == ["delay","angle","laser_on","repeat","repeat2","level",
                         "translation","translation_mode","chopper_mode",
                         "temperature","xray_on"]
	assert candidate(
) == ['delay', 'angle', 'laser_on','repeat','repeat2', 'level', 'translation',
        'translation_mode', 'chopper_mode', 'temperature', 'xray_on'], \
    "Incorrect list of parameter names"
	assert candidate(
) == ["delay","angle","laser_on","repeat","repeat2","level","translation",
        "translation_mode","chopper_mode","temperature","xray_on"]
	assert candidate(
)==["delay","angle","laser_on","repeat","repeat2","level","translation",
    "translation_mode","chopper_mode","temperature","xray_on"],\
    "candidate() is broken"
	assert candidate( ) == ['delay', 'angle', 'laser_on','repeat','repeat2', 'level', 'translation', 'translation_mode', 'chopper_mode', 'temperature', 'xray_on']
	assert candidate(
) == ["delay","angle","laser_on","repeat","repeat2","level","translation",
        "translation_mode","chopper_mode","temperature","xray_on"], \
    "candidate() does not return correct value"
	assert candidate( ) == ["delay","angle","laser_on","repeat","repeat2","level","translation",
            "translation_mode","chopper_mode","temperature","xray_on"]
	assert candidate( ) == ["delay","angle","laser_on","repeat","repeat2","level",
                        "translation","translation_mode","chopper_mode",
                        "temperature","xray_on"]
	assert candidate( ) == ["delay","angle","laser_on","repeat","repeat2","level","translation",
                         "translation_mode","chopper_mode","temperature","xray_on"]
def test_check():
	check(variables)
