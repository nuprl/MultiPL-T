def count_change(amount):
    """ Return the number of ways to make change for amount.
     
     >>> count_change(7)
     6
     >>> count_change(10)
     14
     >>> count_change(20)
     60
     >>> count_change(100)
     9828
     >>> from construct_check import check
     >>> check(HW_SOURCE_FILE, 'count_change', ['While', 'For'])
     True
     """
	### Canonical solution below ###    

    def check_change(coin,amount):
        if amount<1: 
            return 0
        elif amount == 1: #only one way once amount is 1
            return 1
        return check_change(coin,amount-coin) + check_change(2*coin,amount-coin) #double coin value
    return check_change(1,amount)

### Unit tests below ###
def check(candidate):
	assert candidate(20) == 60
	assert candidate(7) == 6
	assert candidate(100) == 9828
	assert candidate(10) == 14
def test_check():
	check(count_change)
