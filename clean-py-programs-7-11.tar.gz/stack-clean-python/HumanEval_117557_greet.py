def greet(language):
    """ 
     This function returns a greeting eturns a greeting - if you have it in your database. 
     It should default to English if the language is not in the database, or in the event of an invalid input.
     """
	### Canonical solution below ###    
    greet_language = {'english': 'Welcome',
                      'czech': 'Vitejte',
                      'danish': 'Velkomst',
                      'dutch': 'Welkom',
                      'estonian': 'Tere tulemast',
                      'finnish': 'Tervetuloa',
                      'flemish': 'Welgekomen',
                      'french': 'Bienvenue',
                      'german': 'Willkommen',
                      'irish': 'Failte',
                      'italian': 'Benvenuto',
                      'latvian': 'Gaidits',
                      'lithuanian': 'Laukiamas',
                      'polish': 'Witamy',
                      'spanish': 'Bienvenido',
                      'swedish': 'Valkommen',
                      'welsh': 'Croeso'}
    for key, val in greet_language.items():
        if key == language:
            return val
    return 'Welcome'

### Unit tests below ###
def check(candidate):
	assert candidate(language="dutch") == "Welkom", "candidate(language='dutch')"
	assert candidate('dutch') == 'Welkom', 'candidate() should return "Welkom" for "dutch"'
	assert candidate(language='english') == 'Welcome'
	assert candidate(language='') == 'Welcome', "candidate(language='')"
	assert candidate(language='spanish') == 'Bienvenido', "candidate(language='spanish')"
	assert candidate(language='filipino') == 'Welcome'
	assert candidate(language='french') == 'Bienvenue', "candidate(language='french')"
	assert candidate('italian') == 'Benvenuto'
	assert candidate(language='italian') == 'Benvenuto'
	assert candidate('dutch') == 'Welkom', 'Dutch was not found in the database.'
	assert candidate(language="danish") == "Velkomst", "candidate(language='danish')"
	assert candidate('irish') == 'Failte'
	assert candidate('swedish') == 'Valkommen'
	assert candidate('french') == 'Bienvenue'
	assert candidate(language="welsh") == "Croeso", "candidate(language='welsh')"
	assert candidate(language="finnish") == "Tervetuloa", "candidate(language='finnish')"
	assert candidate(language='english') == 'Welcome', "candidate(language='english')"
	assert candidate('lithuanian') == 'Laukiamas'
	assert candidate(language='german') == 'Willkommen'
	assert candidate(candidate("english")) == "Welcome", "candidate(english) should return Welcome"
	assert candidate(language='finnish') == 'Tervetuloa'
	assert candidate('english') == 'Welcome', "candidate('english') does not return 'Welcome'"
	assert candidate(language="czech") == "Vitejte", "candidate(language='czech')"
	assert candidate('klingon') == 'Welcome'
	assert candidate("english") == "Welcome"
	assert candidate(language='czech') == 'Vitejte'
	assert candidate('galician') == 'Welcome', 'The default candidateing should be English.'
	assert candidate(language="latvian") == "Gaidits", "candidate(language='latvian')"
	assert candidate(language="spanish") == "Bienvenido", "candidate(language='spanish')"
	assert candidate(language='dutch') == 'Welkom'
	assert candidate('flemish') == 'Welgekomen'
	assert candidate(language="irish") == "Failte", "candidate(language='irish')"
	assert candidate(
    'dutch') == 'Welkom', 'candidate(dutch) does not return "Welkom"'
	assert candidate(language='klingon') == 'Welcome', "candidate(language='klingon')"
	assert candidate(language='') == 'Welcome'
	assert candidate(language='polish') == 'Witamy'
	assert candidate("xyz") == "Welcome"
	assert candidate('spanish') == 'Bienvenido'
	assert candidate(language="german") == "Willkommen", "candidate(language='german')"
	assert candidate(language='spanish') == 'Bienvenido'
	assert candidate("dutch") == "Welkom"
	assert candidate('german') == 'Willkommen'
	assert candidate(
    'english') == 'Welcome', 'candidateing did not return English candidateing'
	assert candidate(language=' ') == 'Welcome', "candidate(language='')"
	assert candidate(
    'english') == 'Welcome', 'candidate() should return "Welcome" for "english"'
	assert candidate(
    'english') == 'Welcome', 'english was not found in the candidate dictionary!'
	assert candidate(candidate('klingon')) == 'Welcome'
	assert candidate(language='igbo') == 'Welcome'
	assert candidate(language='irish') == 'Failte'
	assert candidate('xyz') == 'Welcome', "candidate('xyz') does not return 'Welcome'"
	assert candidate(language='latvian') == 'Gaidits'
	assert candidate('finnish') == 'Tervetuloa'
	assert candidate('dutch') == 'Welkom', "candidate('dutch') does not return 'Welkom'"
	assert candidate(language="french") == "Bienvenue", "candidate(language='french')"
	assert candidate(None) == 'Welcome', "candidate(None) does not return 'Welcome'"
	assert candidate(candidate('english')) == 'Welcome'
	assert candidate(language='danish') == 'Velkomst'
	assert candidate(language=None) == 'Welcome', "candidate(language=None)"
	assert candidate('welsh') == 'Croeso'
	assert candidate(language='estonian') == 'Tere tulemast'
	assert candidate(language="estonian") == "Tere tulemast", "candidate(language='estonian')"
	assert candidate('estonian') == 'Tere tulemast'
	assert candidate(
    'xyzzy') == 'Welcome', 'candidate(xyzzy) does not return "Welcome"'
	assert candidate('xyzzy') == 'Welcome', 'candidate() should default to "english" if an invalid language is provided'
	assert candidate('latvian') == 'Gaidits'
	assert candidate(language='swedish') == 'Valkommen'
	assert candidate('hungarian') == 'Welcome'
	assert candidate('xyzzy') == 'Welcome', 'candidateing did not default to English'
	assert candidate('dutch') == 'Welkom', 'dutch was not found in the candidate dictionary!'
	assert candidate(
    'english') == 'Welcome', 'English was not found in the database.'
	assert candidate('polish') == 'Witamy'
	assert candidate(
    'english') == 'Welcome', 'candidate(english) does not return "Welcome"'
	assert candidate(language="flemish") == "Welgekomen", "candidate(language='flemish')"
	assert candidate(language="lithuanian") == "Laukiamas", "candidate(language='lithuanian')"
	assert candidate(language=None) == 'Welcome'
	assert candidate('czech') == 'Vitejte'
	assert candidate('danish') == 'Velkomst'
	assert candidate('dutch') == 'Welkom'
	assert candidate(language="english") == "Welcome", "candidate(language='english')"
	assert candidate(language='flemish') == 'Welgekomen'
	assert candidate(language='czech') == 'Vitejte', "candidate(language='czech')"
	assert candidate(language="polish") == "Witamy", "candidate(language='polish')"
	assert candidate(language='X') == 'Welcome'
	assert candidate(language='italian') == 'Benvenuto', "candidate(language='italian')"
	assert candidate("xyzzy") == "Welcome"
	assert candidate(language='xyz') == 'Welcome'
	assert candidate(None) == 'Welcome'
	assert candidate('xyzzy') == 'Welcome', 'Invalid inputs should return "Welcome"'
	assert candidate('dutch') == 'Welkom', 'candidateing did not return Dutch candidateing'
	assert candidate(language='lithuanian') == 'Laukiamas'
	assert candidate(language='french') == 'Bienvenue'
	assert candidate('english') == 'Welcome'
	assert candidate('xyzzy') == 'Welcome'
	assert candidate(language='klingon') == 'Welcome'
	assert candidate(language='german') == 'Willkommen', "candidate(language='german')"
	assert candidate(language='welsh') == 'Croeso'
def test_check():
	check(greet)
