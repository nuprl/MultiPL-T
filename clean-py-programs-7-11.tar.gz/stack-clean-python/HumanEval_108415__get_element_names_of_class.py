def _get_element_names_of_class(elements, cls):
    """Return a frozenset of the names of the elements are instances of the class."""
    ### Canonical solution below ###
    return frozenset({name for name, element in elements.items() if isinstance(element, cls)})


### Unit tests below ###
def check(candidate):
	assert candidate({'a': 1, 'b': 2}, int) == frozenset(['a', 'b'])
	assert candidate(
    {
        'a': 1,
        'b': 2,
        'c': 3,
    },
    int
) == frozenset(['a', 'b', 'c'])
	assert candidate(
    {'a': 'a', 'b': 'b', 'c': 'c'},
    str,
) == frozenset({'a', 'b', 'c'})
	assert candidate(dict(a=1, b=2, c='c', d=dict(a='a', b='b'), e=list(), f=tuple(), g=set()), str) == frozenset(['c'])
	assert candidate(dict(a=1, b=2, c='c', d=dict(a='a', b='b')), str) == frozenset(['c'])
	assert candidate(
    {
        'a': 1,
        'b': 2,
        'c': 3,
    },
    bool
) == frozenset([])
	assert candidate(dict(a=1, b=2, c='c', d=dict(a='a', b='b'), e=list()), str) == frozenset(['c'])
	assert candidate(dict(a=1, b=2), str) == frozenset()
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    int,
) == frozenset({'a', 'b', 'c'})
	assert candidate(
    {
        'a': 1,
        'b': 2,
        'c': 3,
    },
    str
) == frozenset([])
	assert candidate(
    {
        "a": "a",
        "b": "b",
        "c": "c",
    },
    str,
) == frozenset({"a", "b", "c"})
	assert candidate(dict(a=1, b=2, c='c'), str) == frozenset(['c'])
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}, str) == frozenset({})
	assert candidate(dict(), int) == frozenset()
	assert candidate(
    {"a": "string", "b": 1, "c": 1.0, "d": [1, 2, 3], "e": {"f": 1}},
    dict) == frozenset({"e"})
	assert candidate({'a': 1, 'b': 2, 'c': 'foo'}, int) == frozenset(['a', 'b'])
	assert candidate(
    {'a': 'foo', 'b': 'bar', 'c': 42}, str) == {'a', 'b'}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    str,
) == frozenset()
	assert candidate(dict(a=1, b=2, c='c', d=dict(a='a', b='b'), e=list(), f=tuple(), g=set(), h=frozenset()), str) == frozenset(['c'])
	assert candidate(
    {
        'a': 1,
        'b': 2,
        'c': 3,
    },
    (int, str)
) == frozenset(['a', 'b', 'c'])
	assert candidate({'a': 1, 'b': 2, 'c': 'foo'}, str) == frozenset(['c'])
	assert candidate(
    {'a': 'foo', 'b': 'bar', 'c': 42}, float) == set()
	assert candidate(
    {
        'a': 1,
        'b': 2,
        'c': 3,
    },
    (str, bool)
) == frozenset([])
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}, int) == frozenset({'a', 'b', 'c'})
	assert candidate(
    {"a": "string", "b": 1, "c": 1.0, "d": [1, 2, 3], "e": {"f": 1}},
    float) == frozenset({"c"})
	assert candidate(
    {
        "a": "a",
        "b": "b",
        "c": "c",
    },
    int,
) == frozenset()
	assert candidate(dict(), str) == frozenset()
	assert candidate(
    {"a": "string", "b": 1, "c": 1.0, "d": [1, 2, 3], "e": {"f": 1}},
    list) == frozenset({"d"})
	assert candidate(dict(a=1, b=2, c='c', d=dict(a='a', b='b'), e=list(), f=tuple()), str) == frozenset(['c'])
	assert candidate({'a': 1, 'b': 2, 'c': 'foo'}, float) == frozenset()
	assert candidate(
    {'a': 'foo', 'b': 'bar', 'c': 42}, int) == {'c'}
	assert candidate(
    {"a": "string", "b": 1, "c": 1.0, "d": [1, 2, 3], "e": {"f": 1}},
    str) == frozenset({"a"})
def test_check():
	check(_get_element_names_of_class)
