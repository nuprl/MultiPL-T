def item_diffs(old_items=None, new_items=None):
    """ 
     Given previous cve-scan output and new cve-scan output for the same image, return a diff as a map.
     Keys:
     {
     'added': [],
     'removed': [],
     'updated': []
     }
     
     :param old_cves: mapped cve results (from map_rows() result) from previous value
     :param new_cves: mapped cve results (from map_rows() result) from current_value
     :return: dictionary object with results
     """
	### Canonical solution below ###    

    if not old_items:
        old_items = {}

    if not new_items:
        new_items = {}

    new_ids = set(new_items.keys())
    old_ids = set(old_items.keys())
    added = [new_items[x] for x in new_ids.difference(old_ids)]
    removed = [old_items[x] for x in old_ids.difference(new_ids)]
    intersected_ids = new_ids.intersection(old_ids)
    updated = [new_items[x] for x in filter(lambda x: new_items[x] != old_items[x], intersected_ids)]

    return {
        'added': added,
        'removed': removed,
        'updated': updated
    }

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'a': {'foo': 'bar'}},
    {'a': {'foo': 'baz'}}
) == {'added': [],'removed': [], 'updated': [{'foo': 'baz'}]}
	assert candidate(
    old_items={'a': 'A', 'b': 'B', 'c': 'C'},
    new_items={'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D'}
) == {
    'added': ['D'],
   'removed': [],
    'updated': []
}
	assert candidate(
    {
        'CVE-123': {'id': 'CVE-123', 'name': 'CVE-123'},
        'CVE-456': {'id': 'CVE-456', 'name': 'CVE-456'},
    },
    {
        'CVE-123': {'id': 'CVE-123', 'name': 'CVE-123'},
        'CVE-789': {'id': 'CVE-789', 'name': 'CVE-789'},
    }
) == {
    'added': [
        {'id': 'CVE-789', 'name': 'CVE-789'}
    ],
   'removed': [
        {'id': 'CVE-456', 'name': 'CVE-456'}
    ],
    'updated': []
}
	assert candidate(old_items={}, new_items={}) == {'added': [],'removed': [], 'updated': []}
	assert candidate(old_items={1: 2}, new_items={1: 2}) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(
    old_items={'CVE-2019-101001': 'foo'},
    new_items={'CVE-2019-101001': 'foo', 'CVE-2019-101002': 'bar'}
) == {
    'added': ['bar'],
   'removed': [],
    'updated': []
}
	assert candidate(old_items={'a': 1}, new_items={}) == {'added': [],'removed': [1], 'updated': []}
	assert candidate(
    old_items={},
    new_items={
        'CVE-1999-0001': {
            'id': 'CVE-1999-0001',
           'severity': 'low',
            'description': 'desc1',
            'link': 'link1',
            'cvss': 1.0,
           'vector': 'CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N'
        }
    }
) == {
    'added': [{
        'id': 'CVE-1999-0001',
       'severity': 'low',
        'description': 'desc1',
        'link': 'link1',
        'cvss': 1.0,
       'vector': 'CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N'
    }],
   'removed': [],
    'updated': []
}
	assert candidate(
    {
        'CVE-1234-1234': {'id': 'CVE-1234-1234', 'description': 'a'},
        'CVE-1234-1235': {'id': 'CVE-1234-1235', 'description': 'b'},
        'CVE-1234-1236': {'id': 'CVE-1234-1236', 'description': 'c'},
    },
    {
        'CVE-1234-1234': {'id': 'CVE-1234-1234', 'description': 'a'},
        'CVE-1234-1235': {'id': 'CVE-1234-1235', 'description': 'b'},
        'CVE-1234-1236': {'id': 'CVE-1234-1236', 'description': 'd'},
        'CVE-1234-1237': {'id': 'CVE-1234-1237', 'description': 'e'},
    }
) == {
    'added': [
        {'id': 'CVE-1234-1237', 'description': 'e'},
    ],
   'removed': [],
    'updated': [
        {'id': 'CVE-1234-1236', 'description': 'd'},
    ]
}
	assert candidate(old_items={'a': 1}, new_items={'a': 2, 'b': 3}) == {'added': [3],'removed': [], 'updated': [2]}
	assert candidate(old_items={}, new_items={'a': 1}) == {'added': [1],'removed': [], 'updated': []}
	assert candidate(
    old_items={'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D'},
    new_items={'a': 'A', 'b': 'B', 'c': 'C'}
) == {
    'added': [],
   'removed': ['D'],
    'updated': []
}
	assert candidate(
    {'a': {'foo': 'bar'}},
    {'a': {'foo': 'bar'}}
) == {'added': [],'removed': [], 'updated': []}
	assert candidate(
    {'CVE-1999-1234': 'a', 'CVE-2000-5678': 'b'},
    {'CVE-1999-1234': 'a', 'CVE-2000-5678': 'b'}
) == {'added': [],'removed': [], 'updated': []}
	assert candidate(old_items={'a': 1}, new_items={'a': 2}) == {'added': [],'removed': [], 'updated': [2]}
	assert candidate(
    {'CVE-1999-1234': 'a', 'CVE-2000-5678': 'b', 'CVE-2000-1111': 'c'},
    {'CVE-1999-1234': 'a', 'CVE-2000-5678': 'b'}
) == {'added': [],'removed': ['c'], 'updated': []}
	assert candidate(old_items={'foo': 'bar'}, new_items={'foo': 'bar'}) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(
    old_items={
        'CVE-1': 'item1',
        'CVE-2': 'item2',
        'CVE-3': 'item3'
    },
    new_items={
        'CVE-1': 'item1',
        'CVE-2': 'item2',
        'CVE-3': 'item3'
    }
) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(
    old_items={'a': {'id': 'a'}, 'b': {'id': 'b'}, 'c': {'id': 'c'}},
    new_items={'a': {'id': 'a'}, 'b': {'id': 'b'}, 'c': {'id': 'c'}}
) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(
    old_items={'a': 1, 'b': 2, 'c': 3, 'd': 4},
    new_items={'a': 1, 'b': 2, 'c': 3}
)
	assert candidate(
    old_items={'a': 'A', 'b': 'B'},
    new_items={'a': 'A', 'b': 'B'}
) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(
    old_items={'CVE-2019-101001': 'foo', 'CVE-2019-101002': 'bar'},
    new_items={'CVE-2019-101001': 'baz', 'CVE-2019-101002': 'bar'}
) == {
    'added': [],
   'removed': [],
    'updated': ['baz']
}
	assert candidate(old_items={'a': 'b'}, new_items={'a': 'b'}) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(
    old_items={
        'CVE-1': 'item1',
        'CVE-2': 'item2',
        'CVE-3': 'item3'
    },
    new_items={
        'CVE-1': 'item1',
        'CVE-2': 'item2',
        'CVE-4': 'item5'
    }
) == {
    'added': ['item5'],
   'removed': ['item3'],
    'updated': []
}
	assert candidate(
    old_items={'CVE-2019-101001': 'foo', 'CVE-2019-101002': 'bar'},
    new_items={'CVE-2019-101001': 'foo'}
) == {
    'added': [],
   'removed': ['bar'],
    'updated': []
}
	assert candidate(
    {
        'CVE-2019-1234': {
            'name': 'CVE-2019-1234',
            'link': 'https://nvd.nist.gov/vuln/detail/CVE-2019-1234',
           'severity': 'low',
            'description': 'A description for CVE-2019-1234'
        }
    },
    {
        'CVE-2019-1234': {
            'name': 'CVE-2019-1234',
            'link': 'https://nvd.nist.gov/vuln/detail/CVE-2019-1234',
           'severity': 'high',
            'description': 'A description for CVE-2019-1234'
        }
    }
) == {
    'added': [],
   'removed': [],
    'updated': [{
        'name': 'CVE-2019-1234',
        'link': 'https://nvd.nist.gov/vuln/detail/CVE-2019-1234',
       'severity': 'high',
        'description': 'A description for CVE-2019-1234'
    }]
}
	assert candidate(
    old_items={'a': {'id': 'a'}, 'b': {'id': 'b'}, 'c': {'id': 'c'}},
    new_items={'a': {'id': 'a'}, 'b': {'id': 'b'}}
) == {
    'added': [],
   'removed': [{'id': 'c'}],
    'updated': []
}
	assert candidate(
    {
        'CVE-2010-0001': 'CVE-2010-0001',
        'CVE-2010-0002': 'CVE-2010-0002'
    },
    {
        'CVE-2010-0001': 'CVE-2010-0001',
        'CVE-2010-0002': 'CVE-2010-0002'
    }
) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(old_items={'a': 1}, new_items={'a': 1}) == {'added': [],'removed': [], 'updated': []}
	assert candidate(old_items={}, new_items={}) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(old_items={'a': 'A', 'b': 'B'}, new_items={'a': 'A', 'b': 'B'}) == {'added': [],'removed': [], 'updated': [] }
	assert candidate(
    old_items={'a': {'id': 'a'}, 'b': {'id': 'b'}},
    new_items={'a': {'id': 'a'}, 'b': {'id': 'b'}, 'c': {'id': 'c'}}
) == {
    'added': [{'id': 'c'}],
   'removed': [],
    'updated': []
}
	assert candidate(
    {
        'CVE-2015-5223': {
            'title': 'CVE-2015-5223',
           'severity': 'Medium',
            'cvss_score': 5.0,
            'link': 'https://access.redhat.com/errata/RHSA-2015:2238',
            'fixed_in': ['1.10.1']
        }
    },
    {
        'CVE-2015-5223': {
            'title': 'CVE-2015-5223',
           'severity': 'Medium',
            'cvss_score': 5.0,
            'link': 'https://access.redhat.com/errata/RHSA-2015:2238',
            'fixed_in': ['1.10.1']
        }
    }
) == {
    'added': [],
   'removed': [],
    'updated': []
}
	assert candidate(old_items={'a': 'b'}, new_items={'a': 'b'}) == {'added': [],'removed': [], 'updated': []}
	assert candidate(
    old_items={},
    new_items={}
) == {
    'added': [],
   'removed': [],
    'updated': []
}
def test_check():
	check(item_diffs)
