def another_task_dict_to_list(iterator):
    """
    Convert a dictionary to a list to be used as partitions later.
    :param iterator:
    :return:
    """
    ### Canonical solution below ###
    ret = list()
    for i in iterator.keys():
        ret.append((i, iterator[i]))

    return ret


### Unit tests below ###
def check(candidate):
	assert candidate(
    {1: 2, 3: 4, 5: 6}) == [(1, 2), (3, 4), (5, 6)], "incorrect partitioning"
	assert candidate(dict()) == []
	assert candidate(dict(a=1, b=2, c=3, d=4)) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate(
    {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}) == [("a", 1), ("b", 2), ("c", 3), ("d", 4), ("e", 5)]
	assert candidate({'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}) == [(
        'a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5), ('f', 6)]
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4}
) == [('a', 1), ('b', 2), ('c', 3), ('d', 4)]
	assert candidate(dict(a=1, b=2, c=3)) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(dict(a=1, b=2, c=3, d=4)) == [("a", 1), ("b", 2), ("c", 3), ("d", 4)]
	assert candidate(
    {"a": 1, "b": 2, "c": 3}) == [("a", 1), ("b", 2), ("c", 3)]
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7)) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5), ('f', 6), ('g', 7)]
	assert candidate(dict()) == list()
	assert candidate({'a': 1}) == [('a', 1)]
	assert candidate(dict(a=1, b=2, c=3)) == [("a", 1), ("b", 2), ("c", 3)]
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}
) == [('a', 1), ('b', 2), ('c', 3)]
	assert candidate(dict(a=1, b=2)) == [('a', 1), ('b', 2)]
	assert candidate(
    {1: 2, 3: 4, 5: 6}) == [(1, 2), (3, 4), (5, 6)]
	assert candidate({"A": 1, "B": 2, "C": 3}) == [('A', 1), ('B', 2), ('C', 3)]
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5), ('f', 6)]
	assert candidate(
    {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4
    }
) == [("a", 1), ("b", 2), ("c", 3), ("d", 4)]
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5)]
	assert candidate({}) == []
	assert candidate({'a': 1, 'b': 2, 'c': 3}) == [('a', 1), ('b', 2), ('c', 3)]
def test_check():
	check(another_task_dict_to_list)
