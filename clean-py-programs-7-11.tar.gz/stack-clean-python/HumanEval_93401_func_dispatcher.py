def func_dispatcher(intent):
    """ 
     Simple effect dispatcher that takes callables taking a box,
     and calls them with the given box.
     """
	### Canonical solution below ###    
    def performer(dispatcher, intent, box):
        intent(box)
    return performer

### Unit tests below ###
def check(candidate):
	assert candidate(lambda box: box.set_value(1))!= candidate(lambda box: box.set_value(2))
	assert candidate(lambda box: box.set(42)) is not None
	assert candidate(lambda box: box.append(42))!= candidate(lambda box: box.append(43))
	assert not candidate(lambda x: x.append(1)) is candidate(lambda x: x.append(2))
	assert candidate(lambda box: box.push(2)) is not None
	assert candidate(lambda box: box.push(1)) is not None
	assert candidate(lambda box: box.set("a", 1))!= candidate(lambda box: box.set("a", 2))
	assert not candidate(lambda box: box.append(1)) == candidate(lambda box: box.append(2))
	assert candidate(lambda box: box.set("hi")) is not None
def test_check():
	check(func_dispatcher)
