def rectangle_to_square(rectangle, width, height):
    """ 
     Converts a rectangle in the image, to a valid square. Keeps the original
     rectangle centered whenever possible, but when that requires going outside
     the original picture, it moves the square so it stays inside.
     
     Assumes the square is able to fit inside the original picture.
     """
	### Canonical solution below ###    
    from_x, from_y, to_x, to_y = rectangle

    rectangle_width = to_x - from_x
    rectangle_height = to_y - from_y
    size = max(rectangle_width, rectangle_height)

    x_center = from_x + rectangle_width // 2
    y_center = from_y + rectangle_height // 2

    from_x = x_center - size // 2
    to_x = x_center + size // 2
    from_y = y_center - size // 2
    to_y = y_center + size // 2

    # ensure fitting horizontally
    if from_x < 0:
        to_x = to_x - from_x
        from_x = 0
    elif to_x > width:
        from_x = from_x - (to_x - width)
        to_x = width

    # ensure fitting vertically
    if from_y < 0:
        to_y = to_y - from_y
        from_y = 0
    elif to_y > height:
        from_y = from_y - (to_y - height)
        to_y = height

    return from_x, from_y, to_x, to_y

### Unit tests below ###
def check(candidate):
	assert candidate(
    (0, 0, 10, 10), 10, 10) == (0, 0, 10, 10)
	assert candidate(rectangle=(0, 0, 200, 200), width=200, height=200) == (0, 0, 200, 200)
	assert candidate(
    (10, 10, 20, 20),
    20,
    20,
) == (10, 10, 20, 20)
	assert candidate(
    (0, 0, 100, 100), 100, 100) == (0, 0, 100, 100)
	assert candidate(
    (100, 100, 150, 150), 1000, 1000) == (100, 100, 150, 150)
	assert candidate(
    (0, 0, 100, 100), 200, 100) == (0, 0, 100, 100)
	assert candidate(rectangle=(0, 0, 10, 10), width=10, height=20) == (0, 0, 10, 10)
	assert candidate(
    (-5, 0, 5, 10), 10, 20
) == (0, 0, 10, 10)
	assert candidate(
    (-5, -5, 5, 5), 10, 10
) == (0, 0, 10, 10)
	assert candidate(
    (10, 10, 20, 20), 100, 50) == (10, 10, 20, 20)
	assert candidate(
    (0, 0, 1000, 1000), 1000, 1000) == (0, 0, 1000, 1000)
	assert candidate(
    (10, 10, 20, 20), 100, 200) == (10, 10, 20, 20)
	assert candidate(
    (0, 0, 100, 100),
    100,
    100
) == (0, 0, 100, 100)
	assert candidate(
    (0, 0, 10, 10), 20, 20
) == (0, 0, 10, 10)
	assert candidate(
    (10, 10, 20, 20), 100, 100) == (10, 10, 20, 20)
	assert candidate(
    (0, 0, 100, 100), 1000, 1000) == (0, 0, 100, 100)
	assert candidate(rectangle=(100, 100, 200, 200), width=200, height=200) == (100, 100, 200, 200)
	assert candidate(
    (10, 10, 20, 20), 50, 100) == (10, 10, 20, 20)
	assert candidate(
    (0, 0, 100, 100), 200, 200) == (0, 0, 100, 100)
	assert candidate(rectangle=(10, 10, 20, 20), width=100, height=100) == (10, 10, 20, 20)
	assert candidate(
    (10, 10, 20, 20), 20, 20
) == (10, 10, 20, 20)
	assert candidate(rectangle=(10, 10, 20, 20), width=20, height=20) == (10, 10, 20, 20)
	assert candidate(
    (0, -5, 10, 5), 20, 10
) == (0, 0, 10, 10)
	assert candidate(
    (0, 0, 10, 10), 10, 20
) == (0, 0, 10, 10)
	assert candidate(rectangle=(0, 0, 10, 10), width=20, height=10) == (0, 0, 10, 10)
	assert candidate(
    (100, 100, 150, 150), 150, 150
) == (100, 100, 150, 150)
	assert candidate(
    (10, 10, 20, 20), 200, 200) == (10, 10, 20, 20)
	assert candidate(rectangle=(0, 0, 10, 10), width=100, height=100) == (0, 0, 10, 10)
	assert candidate(
    (10, 10, 20, 20), 50, 50) == (10, 10, 20, 20)
	assert candidate(
    (50, 50, 100, 100), 200, 200) == (50, 50, 100, 100)
	assert candidate(rectangle=(0, 0, 100, 100), width=100, height=100) == (0, 0, 100, 100)
	assert candidate(
    (100, 100, 150, 150), 200, 200
) == (100, 100, 150, 150)
	assert candidate(rectangle=(100, 0, 200, 100), width=200, height=200) == (100, 0, 200, 100)
	assert candidate(
    (0, 0, 10, 10), 20, 10
) == (0, 0, 10, 10)
	assert candidate(rectangle=(0, 0, 10, 10), width=21, height=21) == (0, 0, 10, 10)
	assert candidate(
    (10, 10, 20, 20), 200, 100) == (10, 10, 20, 20)
	assert candidate(
    (100, 100, 200, 200), 500, 500) == (100, 100, 200, 200)
	assert candidate(
    (100, 100, 200, 200), 300, 300) == (100, 100, 200, 200)
	assert candidate(
    (10, 10, 20, 20), 300, 300) == (10, 10, 20, 20)
	assert candidate(
    (0, 0, 100, 100),
    100,
    200
) == (0, 0, 100, 100)
	assert candidate(
    (0, 0, 10, 10), 10, 10
) == (0, 0, 10, 10)
	assert candidate(rectangle=(0, 0, 100, 100), width=200, height=200) == (0, 0, 100, 100)
	assert candidate(
    (10, 20, 30, 40), 100, 100
) == (10, 20, 30, 40)
	assert candidate(rectangle=(0, 0, 10, 10), width=10, height=10) == (0, 0, 10, 10)
	assert candidate(
    (-50, -50, 50, 50),
    200,
    150) == (0, 0, 100, 100)
	assert candidate(
    (0, 0, 100, 100),
    200,
    100
) == (0, 0, 100, 100)
	assert candidate(
    (0, 0, 100, 100), 100, 200) == (0, 0, 100, 100)
	assert candidate(rectangle=(0, 100, 100, 200), width=200, height=200) == (0, 100, 100, 200)
	assert candidate(
    (50, 50, 150, 150), 200, 200) == (50, 50, 150, 150)
	assert candidate(rectangle=(0, 0, 10, 10), width=20, height=20) == (0, 0, 10, 10)
	assert candidate(
    (100, 100, 200, 200), 100, 100) == (0, 0, 100, 100)
	assert candidate(
    (10, 10, 100, 100), 100, 100
) == (10, 10, 100, 100)
	assert candidate(rectangle=(0, 0, 50, 50), width=200, height=200) == (0, 0, 50, 50)
def test_check():
	check(rectangle_to_square)
