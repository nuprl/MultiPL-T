def get_url_walmart(search_term):
    """ 
     
     :param search_term:
     :return:
     """
	### Canonical solution below ###    
    template = "https://www.walmart.com/search?q={}"
    search_term = search_term.replace(" ", "+")
    url = template.format(search_term)
    print(f"Constructed Walmart URL: \n >>{url}<<")
    return url

### Unit tests below ###
def check(candidate):
	assert candidate(search_term="apple") == "https://www.walmart.com/search?q=apple"
	assert candidate(
    "iphone 11 pro") == "https://www.walmart.com/search?q=iphone+11+pro", "URL is incorrect"
	assert candidate(search_term="t-shirt") == "https://www.walmart.com/search?q=t-shirt"
	assert candidate(
    "iphone"
) == "https://www.walmart.com/search?q=iphone", "Incorrect Walmart URL"
	assert candidate(search_term='batteries') == 'https://www.walmart.com/search?q=batteries'
	assert candidate(search_term="socks") == "https://www.walmart.com/search?q=socks"
	assert candidate(search_term="chicken tenders hot") == "https://www.walmart.com/search?q=chicken+tenders+hot"
	assert candidate(search_term="chicken tenders hot cross buns 16 oz full fat regular") == "https://www.walmart.com/search?q=chicken+tenders+hot+cross+buns+16+oz+full+fat+regular"
	assert candidate(
    "iphone pro") == "https://www.walmart.com/search?q=iphone+pro", "URL is incorrect"
	assert candidate(search_term="python") == "https://www.walmart.com/search?q=python"
	assert candidate(search_term="Walmart") == "https://www.walmart.com/search?q=Walmart"
	assert candidate(search_term="shoes") == "https://www.walmart.com/search?q=shoes", "Error: URL construction for Walmart is incorrect."
	assert candidate(search_term="ipad") == "https://www.walmart.com/search?q=ipad"
	assert candidate(search_term="chicken tenders hot cross buns 16 oz") == "https://www.walmart.com/search?q=chicken+tenders+hot+cross+buns+16+oz"
	assert candidate(search_term="coffee") == "https://www.walmart.com/search?q=coffee"
	assert candidate("iphone") == "https://www.walmart.com/search?q=iphone"
	assert candidate(search_term="water filter") == "https://www.walmart.com/search?q=water+filter"
	assert candidate(search_term="Tide Pods and Tide Pod") == "https://www.walmart.com/search?q=Tide+Pods+and+Tide+Pod", \
    "Incorrect Walmart URL constructed!"
	assert candidate(search_term="mangoes") == "https://www.walmart.com/search?q=mangoes"
	assert candidate(
    "iphone 11") == "https://www.walmart.com/search?q=iphone+11", "URL is incorrect"
	assert candidate(search_term="Walmart.com") == "https://www.walmart.com/search?q=Walmart.com"
	assert candidate(search_term='bananas') == "https://www.walmart.com/search?q=bananas"
	assert candidate(search_term="shoes") == "https://www.walmart.com/search?q=shoes"
	assert candidate(search_term="Beyonce+Knowles")!= "https://www.walmart.com/search?q=Beyonce+Knowles+"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=1500', "url incorrect"
	assert candidate(search_term="chicken tenders hot cross buns") == "https://www.walmart.com/search?q=chicken+tenders+hot+cross+buns"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=3000', "url incorrect"
	assert candidate(search_term="ipod") == "https://www.walmart.com/search?q=ipod"
	assert candidate(search_term="Tide Pod") == "https://www.walmart.com/search?q=Tide+Pod", \
    "Incorrect Walmart URL constructed!"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=2000', "url incorrect"
	assert candidate(search_term="Walmart gift cards") == "https://www.walmart.com/search?q=Walmart+gift+cards"
	assert candidate(search_term="Walmart Gift Cards") == "https://www.walmart.com/search?q=Walmart+Gift+Cards"
	assert candidate(search_term="chicken tenders") == "https://www.walmart.com/search?q=chicken+tenders"
	assert candidate(search_term="apple iphone") == "https://www.walmart.com/search?q=apple+iphone"
	assert candidate(search_term="cereal") == "https://www.walmart.com/search?q=cereal"
	assert candidate(
    "Samsung Galaxy Tab S 10.5"
) == "https://www.walmart.com/search?q=Samsung+Galaxy+Tab+S+10.5"
	assert candidate(search_term="chicken tenders hot cross buns 16 oz full fat") == "https://www.walmart.com/search?q=chicken+tenders+hot+cross+buns+16+oz+full+fat"
	assert candidate(search_term="Beyonce+Knowles") == "https://www.walmart.com/search?q=Beyonce+Knowles"
	assert candidate(search_term="orange") == "https://www.walmart.com/search?q=orange"
	assert candidate(
    "Sony Playstation 5 Digital Edition"
) == "https://www.walmart.com/search?q=Sony+Playstation+5+Digital+Edition"
	assert candidate(search_term="coats") == "https://www.walmart.com/search?q=coats"
	assert candidate("Sony Playstation 5 Digital Edition") == "https://www.walmart.com/search?q=Sony+Playstation+5+Digital+Edition"
	assert candidate(
    "Samsung Galaxy Tab S 10.5"
)
	assert candidate(search_term="iphone") == "https://www.walmart.com/search?q=iphone"
	assert candidate(search_term="macbook pro")!= "https://www.walmart.com/search?q=macbookpro"
	assert candidate(search_term="cat") == "https://www.walmart.com/search?q=cat"
	assert candidate(search_term="walmart") == "https://www.walmart.com/search?q=walmart"
	assert candidate(search_term="Beyonce+Knowles")!= "https://www.walmart.com/search?q=Beyonce+Knowles&utm_source=google"
	assert candidate(
    "samsung galaxy s20 fe 5g") == "https://www.walmart.com/search?q=samsung+galaxy+s20+fe+5g", \
    "Incorrect URL constructed for Samsung Galaxy S20 FE 5G search"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=100', "url incorrect"
	assert candidate(search_term='shoes') == 'https://www.walmart.com/search?q=shoes', "url incorrect"
	assert candidate(search_term="bananas") == "https://www.walmart.com/search?q=bananas"
	assert candidate(search_term="Beyonce+Knowles")!= "https://www.walmart.com/search?q=Beyonce%20Knowles"
	assert candidate("Sony Playstation 5") == "https://www.walmart.com/search?q=Sony+Playstation+5"
	assert candidate("samsung s20") == "https://www.walmart.com/search?q=samsung+s20"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=1000', "url incorrect"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=500', "url incorrect"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=2500', "url incorrect"
	assert candidate(search_term="chicken") == "https://www.walmart.com/search?q=chicken"
	assert candidate(search_term="hot dog") == "https://www.walmart.com/search?q=hot+dog"
	assert candidate(search_term="Tide") == "https://www.walmart.com/search?q=Tide", \
    "Incorrect Walmart URL constructed!"
	assert candidate(search_term="shoes sandals") == "https://www.walmart.com/search?q=shoes+sandals", "Error: URL construction for Walmart is incorrect."
	assert candidate(search_term="macbook pro") == "https://www.walmart.com/search?q=macbook+pro"
	assert candidate(search_term='shoes')!= 'https://www.walmart.com/search?q=shoes&c=50', "url incorrect"
	assert candidate(search_term="Tide Pods") == "https://www.walmart.com/search?q=Tide+Pods", \
    "Incorrect Walmart URL constructed!"
def test_check():
	check(get_url_walmart)
