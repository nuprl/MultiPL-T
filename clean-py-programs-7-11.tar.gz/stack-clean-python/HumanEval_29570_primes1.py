def primes1(n): # WAYYYY FASTER
    """ Returns  a list of primes < n """
    ### Canonical solution below ###
    sieve = [True] * (n//2)
    for i in range(3,int(n**0.5)+1,2):
        if sieve[i//2]:
            sieve[i*i//2::i] = [False] * ((n-i*i-1)//(2*i)+1)
    return [2] + [2*i+1 for i in range(1,n//2) if sieve[i]]


### Unit tests below ###
def check(candidate):
	assert candidate(6) == [2, 3, 5]
	assert candidate(10) == [2,3,5,7]
	assert candidate(15) == [2, 3, 5, 7, 11, 13]
	assert candidate(14) == [2,3,5,7,11,13]
	assert candidate(100) == [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97]
	assert candidate(20) == [2, 3, 5, 7, 11, 13, 17, 19]
	assert candidate(8) == [2, 3, 5, 7]
	assert candidate(4) == [2, 3]
	assert candidate(12) == [2, 3, 5, 7, 11]
	assert candidate(200) == [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193,197,199]
	assert candidate(2) == [2]
	assert candidate(8) == [2,3,5,7]
	assert candidate(100000)[:10] == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
	assert candidate(9) == [2, 3, 5, 7]
	assert candidate(10000000)[:10] == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
	assert candidate(10) == [2, 3, 5, 7]
	assert candidate(6) == [2,3,5]
	assert candidate(9) == [2,3,5,7]
	assert candidate(100) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
	assert candidate(100000)[:5] == [2,3,5,7,11]
	assert candidate(1) == [2]
	assert candidate(4) == [2,3]
	assert candidate(14) == [2, 3, 5, 7, 11, 13]
	assert candidate(12) == [2,3,5,7,11]
def test_check():
	check(primes1)
