def get_major_dot_minor_version(version):
    """
    Convert full VERSION Django tuple to
    a dotted string containing MAJOR.MINOR.

    For example, (1, 9, 3, 'final', 0) will result in '1.9'
    """
    ### Canonical solution below ###
    return '.'.join([str(v) for v in version[:2]])


### Unit tests below ###
def check(candidate):
	assert candidate(version=(1, 9, 3, 'rc', 4)) == '1.9'
	assert candidate((1, 9, 3, 'rc2', 0)) == '1.9'
	assert candidate((1, 9)) == '1.9'
	assert candidate((1, 8, 0, 'rc', 0)) == '1.8'
	assert candidate((1, 9, 3, 'final', 2)) == '1.9'
	assert candidate((1, 9, 3, 'beta', 0)) == '1.9'
	assert candidate((1, 11, 3, 'final', 0)) == '1.11'
	assert candidate((1, 9, 3, 'final', 3)) == '1.9'
	assert candidate((1, 10, 3, 'final', 0)) == '1.10'
	assert candidate((1, 8, 0, 'beta', 0)) == '1.8'
	assert candidate(version=(1, 9, 3, 'rc', 3)) == '1.9'
	assert candidate((1, 9, 3, 'rc', 0)) == '1.9'
	assert candidate((1, 8, 0, 'final', 0)) == '1.8'
	assert candidate((2, 1, 3, 'final', 0)) == '2.1'
	assert candidate((1, 13, 3, 'final', 0)) == '1.13'
	assert candidate((1, 9, 3, 'alpha', 0)) == '1.9'
	assert candidate((1, 9, 0, 'rc', 0)) == '1.9'
	assert candidate(version=(1, 9, 3, 'beta', 0)) == '1.9'
	assert candidate(version=(1, 9, 3, 'beta', 1)) == '1.9'
	assert candidate((1, 9, 3, 'final', 5)) == '1.9'
	assert candidate(version=(1, 9, 3, 'rc', 1)) == '1.9'
	assert candidate((1, 14, 3, 'final', 0)) == '1.14'
	assert candidate((1, 8, 0, 'beta', 1)) == '1.8'
	assert candidate(version=(1, 9, 3)) == '1.9'
	assert candidate((2, 3, 3, 'final', 0)) == '2.3'
	assert candidate((2, 4, 3, 'final', 0))
	assert candidate((1, 9, 0, 'alpha', 0)) == '1.9'
	assert candidate((1, 10, 0, 'rc', 1)) == '1.10'
	assert candidate((1, 8, 0, 'alpha', 0)) == '1.8'
	assert candidate(version=(1, 9, 3, 'alpha', 0)) == '1.9'
	assert candidate(version=(1, 9, 3, 'rc', 0)) == '1.9'
	assert candidate((1, 8)) == '1.8'
	assert candidate(version=(1, 9, 3, 'beta', 2)) == '1.9'
	assert candidate((1, 9, 0, 'final', 0)) == '1.9'
	assert candidate(version=(1, 9, 3, 'final', 2)) == '1.9'
	assert candidate((1, 12, 3, 'final', 0)) == '1.12'
	assert candidate((1, 9, 3, 'beta', 1)) == '1.9'
	assert candidate((1, 10)) == '1.10'
	assert candidate((1, 9, 3, 'final', 4)) == '1.9'
	assert candidate(version=(2, 0, 0, 'final', 0)) == '2.0'
	assert candidate((1, 9, 3, 'rc4', 0)) == '1.9'
	assert candidate((1, 9, 3, 'rc', 1)) == '1.9'
	assert candidate(version=(2, 1, 0, 'final', 0)) == '2.1'
	assert candidate(version=(1, 9, 3, 'alpha', 1)) == '1.9'
	assert candidate(version=(1, 10, 3, 'final', 0)) == '1.10'
	assert candidate((1, 9, 0, 'beta', 0)) == '1.9'
	assert candidate(version=(1, 9)) == '1.9'
	assert candidate((1, 8, 3, 'final', 0)) == '1.8'
	assert candidate(version=(1, 9, 3, 'final', 1)) == '1.9'
	assert candidate((1, 9, 3, 'rc3', 0)) == '1.9'
	assert candidate((2, 0, 3, 'final', 0)) == '2.0'
	assert candidate((2, 2, 3, 'final', 0)) == '2.2'
	assert candidate(version=(1, 10)) == '1.10'
	assert candidate((1, 11, 1, 'final', 0)) == '1.11'
	assert candidate((1, 15, 3, 'final', 0)) == '1.15'
	assert candidate((1, 9, 3, 'alpha', 1)) == '1.9'
	assert candidate((1, 9, 3, 'final', 0)) == '1.9'
	assert candidate((1, 9, 3, 'final', 1)) == '1.9'
	assert candidate(version=(1, 9, 3, 'final', 0)) == '1.9'
def test_check():
	check(get_major_dot_minor_version)
