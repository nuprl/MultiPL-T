def _preprocess_pdb_parser_output(dictionary, label, warnings):
    """ 
     The mmcif dictionary values are either str or list(), which is a bit
     tricky to work with. This method makes list() of all of them in
     order to parse all of the in the same way.
     
     Args:
     dictionary (dict): mmcif category with the parser output.
     label (str): name of the category
     warnings (list): possible issues encountered when parsing
     
     Returns:
     dict: unified dictionary for structure parsing.
     """
	### Canonical solution below ###    
    if label not in dictionary:
        warnings.append('Namespace {} does not exist.'.format(label))
        return []

    check_element = list(dictionary[label].keys())[0]
    values = (dictionary[label]
              if isinstance(dictionary[label][check_element], list)
              else {k: [v] for k, v in dictionary[label].items()})
    return values

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'_entity': {'id': ['1', '2', '3']}},
    '_entity',
    []
) == {'id': ['1', '2', '3']}
	assert candidate(
    {'foo': {'bar': [1, 2, 3], 'baz': [4, 5]}},
    'foo', []) == {'bar': [1, 2, 3], 'baz': [4, 5]}
	assert candidate(
    {'_pdbx_struct_assembly.id': {'1': '1'}},
    '_pdbx_struct_assembly_gen',
    []
) == []
	assert candidate(
    {'foo': {'bar': 'baz'}}, 'foo', []) == {'bar': ['baz']}
	assert candidate(
    {'foo': {'bar': 1, 'baz': 2}},
    'foo', []) == {'bar': [1], 'baz': [2]}
	assert candidate(
    {'_atom_site.group_PDB': {'HEM': 'H', 'HETATM': 'H'}},
    '_atom_site.group_PDB',
    []) == {'HEM': ['H'], 'HETATM': ['H']}
	assert candidate({}, 'foo', []) == []
	assert candidate(
    {'atom_site': {'_atom_site.B_iso_or_equiv': '1.0'}},
    'atom_site', []) == {'_atom_site.B_iso_or_equiv': ['1.0']}
	assert candidate(
    {'_atom_site.auth_asym_id': {'A': 'A', 'B': 'B'}},
    '_atom_site.auth_asym_id', []) == {'A': ['A'], 'B': ['B']}
	assert candidate(
    {'foo': {'bar': ['baz']}}, 'foobar', []) == []
	assert candidate(
    {'pdbx_struct_assembly': {
        'id': [1, 2, 3],
        'details': ['foo', 'bar', 'baz']
    }}, 'pdbx_struct_assembly', []) == {
        'id': [1, 2, 3],
        'details': ['foo', 'bar', 'baz']
    }
	assert candidate(
    {'foo': {
        'id': [1],
        'details': 'foo'
    }}, 'pdbx_struct_assembly', []) == []
	assert candidate(
    {'_atom_site.B_iso_or_equiv': {'A': '0.000', 'B': '0.000'}},
    '_atom_site.B_iso_or_equiv',
    []) == {'A': ['0.000'], 'B': ['0.000']}
	assert candidate(
    {'_atom_site.B_iso_or_equiv': {'A': ['0.000', '0.000'], 'B': ['0.000', '0.000']}},
    '_atom_site.B_iso_or_equiv',
    []) == {'A': ['0.000', '0.000'], 'B': ['0.000', '0.000']}
	assert candidate(
    {'_atom_site.auth_asym_id': {'A': 'A', 'B': 'B'}},
    '_atom_site.auth_asym_id', ['A warning']) == {'A': ['A'], 'B': ['B']}
	assert candidate(
    {'_pdbx_struct_assembly_gen.assembly_id': {'1': '1'}},
    '_pdbx_struct_assembly',
    []
) == []
	assert candidate(
    {'foo': {'bar': 1, 'baz': 2}},
    'bar', []) == []
	assert candidate(
    {'_atom_site.label_atom_id': {'N': 'N'}},
    '_atom_site.label_atom_id',
    []
) == {'N': ['N']}
	assert candidate(
    {'pdbx_struct_assembly': {
        'id': 1,
        'details': 'foo'
    }}, 'pdbx_struct_assembly', []) == {
        'id': [1],
        'details': ['foo']
    }
	assert candidate(
    {'foo': {
        'id': 1,
        'details': 'foo'
    }}, 'pdbx_struct_assembly', []) == []
	assert candidate(
    {'pdbx_struct_assembly_gen': {
        'assembly_id': '1',
        'oper_expression': '( 1_555 )',
        'asym_id_list': 'A, B, C, D, E',
        'oligomeric_count': '5'
    }},
    'pdbx_struct_assembly_gen',
    []
) == {
    'assembly_id': ['1'],
    'oper_expression': ['( 1_555 )'],
    'asym_id_list': ['A, B, C, D, E'],
    'oligomeric_count': ['5']
}
	assert candidate(
    {'atom_site': {'B': ['B'], 'C': ['C']}}, 'atom_site', []) == {'B': ['B'], 'C': ['C']}
	assert candidate(
    {'_struct_keywords.pdbx_keywords': {
        'pdbx_keywords': ['BOND', 'ANGLE', 'CHIRALITY', 'HBOND', 'OTHER']}},
    '_struct_keywords.pdbx_keywords',
    []) == {'pdbx_keywords': ['BOND', 'ANGLE', 'CHIRALITY', 'HBOND', 'OTHER']}
	assert candidate(
    {'test': {'element': 1}}, 'test', []) == {'element': [1]}
	assert candidate(
    {'test': {'element': 1}}, 'test_wrong', []) == []
	assert candidate(
    {'atom_site': {'B': 'B', 'C': 'C'}}, 'atom_site', []) == {'B': ['B'], 'C': ['C']}
	assert candidate(
    {'foo': {'bar': ['baz']}}, 'foo', []) == {'bar': ['baz']}
	assert candidate(
    {'_entity': {'id': '1'}},
    '_entity',
    []
) == {'id': ['1']}
	assert candidate(
    {'_atom_site.occupancy': {'A': 1, 'B': 2, 'C': 3}}, '_atom_site.occupancy',
    ['WARNING']) == {'A': [1], 'B': [2], 'C': [3]}
	assert candidate(
    {'_entity': {'id': ['1', '2']}},
    '_entity',
    []
) == {'id': ['1', '2']}
	assert candidate(
    {'_atom_site.occupancy': {'A': 1, 'B': 2, 'C': 3}}, '_atom_site.occupancy',
    []) == {'A': [1], 'B': [2], 'C': [3]}
	assert candidate(
    {'test': {'element': [1]}}, 'test', []) == {'element': [1]}
	assert candidate(
    {'pdbx_struct_assembly': {
        'id': 1,
        'details': 'foo'
    }}, 'foo', []) == []
	assert candidate(
    {'atom_site': {'_atom_site.B_iso_or_equiv': ['1.0', '1.0']}},
    'atom_site', []) == {'_atom_site.B_iso_or_equiv': ['1.0', '1.0']}
def test_check():
	check(_preprocess_pdb_parser_output)
