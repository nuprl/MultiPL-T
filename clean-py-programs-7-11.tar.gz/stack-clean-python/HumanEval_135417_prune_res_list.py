def prune_res_list(res_list, ran, one_word_or_letter):
    """
    Check if res_list have consecutive lines that have only 1 word. If so , remove it/
    :param res_list:
    :return:
    """
    ### Canonical solution below ###
    new_res_list = []
    only_one = []
    for res_i, res in enumerate(res_list):
        if one_word_or_letter == "word":
            if len(res["transcript"].replace("<unk>", " ").replace("-", " ").lstrip(" ").rstrip(" ").split(" ")) == 1:
                only_one.append(True)
            else:
                only_one.append(False)
        else:
            if len(res["transcript"].replace("<unk>", " ").replace("-", " ").lstrip(" ").rstrip(" ").split(" ")) == 1 and \
                    len(res["transcript"].replace("<unk>", " ").replace("-", " ").lstrip(" ").rstrip(" ").split(" ")[0]) == 1:
                only_one.append(True)
            else:
                only_one.append(False)

    to_remove = set()
    for res_i, bol in enumerate(only_one):
        consecutive_only_one_word = True
        try:
            for i in range(ran):
                consecutive_only_one_word = consecutive_only_one_word and only_one[res_i+i]
            if consecutive_only_one_word:
                to_remove.update(range(res_i, res_i+ran))
        except IndexError:
            break

    if to_remove:
        for res_i, res in enumerate(res_list):
            if res_i not in to_remove:
                new_res_list.append(res)
        return new_res_list
    else:
        return res_list


### Unit tests below ###
def check(candidate):
	assert candidate(
    res_list=[{'transcript': 'hello'}, {'transcript': 'world'}, {'transcript': 'hello'}, {'transcript': 'world'}],
    ran=2,
    one_word_or_letter="letter") == [{'transcript': 'hello'}, {'transcript': 'world'}, {'transcript': 'hello'}, {'transcript': 'world'}], \
    "Should not remove consecutive lines with only 1 word"
	assert candidate(
    [
        {
            "transcript": "the first line",
            "confidence": 0.0
        },
        {
            "transcript": "the second line",
            "confidence": 0.0
        },
        {
            "transcript": "the third line",
            "confidence": 0.0
        },
        {
            "transcript": "the fourth line",
            "confidence": 0.0
        }
    ],
    4,
    "word"
) == [
    {
        "transcript": "the first line",
        "confidence": 0.0
    },
    {
        "transcript": "the second line",
        "confidence": 0.0
    },
    {
        "transcript": "the third line",
        "confidence": 0.0
    },
    {
        "transcript": "the fourth line",
        "confidence": 0.0
    }
]
	assert candidate(
    [
        {
            "transcript": "the first line",
            "confidence": 0.0
        },
        {
            "transcript": "the second line",
            "confidence": 0.0
        },
        {
            "transcript": "the third line",
            "confidence": 0.0
        },
        {
            "transcript": "the fourth line",
            "confidence": 0.0
        }
    ],
    4,
    "letter"
) == [
    {
        "transcript": "the first line",
        "confidence": 0.0
    },
    {
        "transcript": "the second line",
        "confidence": 0.0
    },
    {
        "transcript": "the third line",
        "confidence": 0.0
    },
    {
        "transcript": "the fourth line",
        "confidence": 0.0
    }
]
def test_check():
	check(prune_res_list)
