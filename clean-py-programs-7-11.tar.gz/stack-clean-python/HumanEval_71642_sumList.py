def sumList(inList):
    """ 
     calculates sum of the list
     INPUT:
     inList: input list 
     OUTPUT:
     sum: sum of the input list
     """
	### Canonical solution below ###    
    sum = 0
    for num in inList:
        sum += num
    return sum

### Unit tests below ###
def check(candidate):
	assert candidate(list(range(100))) == 4950
	assert candidate([1,2,3]) == 6
	assert candidate( [1,2,3,4] ) == 10, "candidate([1,2,3,4])"
	assert candidate(range(1,10001)) == 50005000, "candidate(range(1,10001))"
	assert candidate(list(range(10000000))) == 49999995000000
	assert candidate( [0,0,0,0,0] ) == 0, "candidate([0,0,0,0,0])"
	assert candidate( [1, 2, 3] ) == 6
	assert candidate([]) == 0
	assert candidate(list(range(10))) == 45, "candidate([0,1,2,3,4,5,6,7,8,9])"
	assert candidate( [1, 2, 3, 4, 5] ) == 15, "candidate([1, 2, 3, 4, 5])"
	assert candidate( [1, 2, 3, 4, 5] ) == 15
	assert candidate(range(1, 11)) == 55, "Should be 55"
	assert candidate(list(range(0,10))) == 45
	assert candidate(list(range(10000))) == 49995000
	assert candidate(range(1,101)) == 5050, "Should be 5050"
	assert candidate( [] ) == 0
	assert candidate( [5, 10, 15] ) == 30
	assert candidate( [1,2,3,4,5] ) == 15, "candidate([1,2,3,4,5])"
	assert candidate( [1, 2, 3] ) == 6, "Should be 6"
	assert candidate( [1, 2, 3, 4, 5, 6, 7] ) == 28, "Should be 28"
	assert candidate(range(1,10001)) == 50005000, "Should be 50005000"
	assert candidate(range(101)) == 5050
	assert candidate(range(1, 101)) == 5050, "Should be 5050"
	assert candidate(range(5)) == 10
	assert candidate(list(range(1000))) == 499500
	assert candidate( [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] ) == 55, "candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])"
	assert candidate(list(range(100,0,-2))) == 2550, "candidate([100,88,66,44,22,0,-2,-4,-6,-8,-10,-12,-14,-16,-18,-20,-22,-24,-26,-28,-30,-32,-34,-36,-38,-40,-42,-44,-46,-48,-50,-52,-54,-56,-58,-60,-62,-64,-66,-68,-70,-72,-74,-76,-78,-80,-82,-84,-86,-88,-90,-92,-94,-96,-98])"
	assert candidate(range(100,0,-1)) == 5050, "candidate(range(100,0,-1))"
	assert candidate(range(10)) == 45
	assert candidate( [10,20,30,40,50] ) == 150, "candidate([10,20,30,40,50])"
	assert candidate(range(1,101)) == 5050, "candidate(range(1,101))"
	assert candidate(inList=[1,2,3,4,5,6,7]) == 28, 'Test 2: candidate'
	assert candidate(list(range(100000))) == 4999950000
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 55, "Error: The candidate function is not working"
	assert candidate([-1, 1, -2, 2, -3, 3]) == 0, "Error: The candidate function is not working"
	assert candidate(list(range(1000000))) == 499999500000
	assert candidate(list(range(10))) == 45
	assert candidate( [1, 2, 3, 4, 5, 6] ) == 21
	assert candidate(list(range(1,10,2))) == 25
	assert candidate( [1, 2, 3, 4] ) == 10
	assert candidate( [1, -2, 3] ) == 2
	assert candidate(inList=[1,2,3,4]) == 10, 'Test 1: candidate'
	assert candidate( [1, 2, 3] ) == 6, "candidate([1, 2, 3])"
	assert candidate(range(100)) == 4950
	assert candidate( [1,1,1,1,1] ) == 5, "candidate([1,1,1,1,1])"
	assert candidate(range(10000,0,-1)) == 50005000, "candidate(range(10000,0,-1))"
def test_check():
	check(sumList)
