def format_xml_exception_message(location, key, value):
    """
    Generate exception message for VideoBlock class which will use for ValueError and UnicodeDecodeError
    when setting xml attributes.
    """
    ### Canonical solution below ###
    exception_message = "Block-location:{location}, Key:{key}, Value:{value}".format(
        location=str(location),
        key=key,
        value=value
    )
    return exception_message


### Unit tests below ###
def check(candidate):
	assert candidate(location=0, key=0, value="0") == "Block-location:0, Key:0, Value:0"
	assert candidate([], "key", "value") == "Block-location:[], Key:key, Value:value"
	assert candidate(
    "location", "key", None) == "Block-location:location, Key:key, Value:None"
	assert candidate(location=1.0, key=2.0, value=3.0) == "Block-location:1.0, Key:2.0, Value:3.0"
	assert candidate(location="location", key=None, value=None) == "Block-location:location, Key:None, Value:None"
	assert candidate(
    'location',
    'key',
    'value'
) == "Block-location:location, Key:key, Value:value"
	assert candidate(["1", "2", "3"], None, None) == "Block-location:['1', '2', '3'], Key:None, Value:None"
	assert candidate('1', 'key', 'value') == "Block-location:1, Key:key, Value:value"
	assert candidate(location="1", key="2", value="3") == "Block-location:1, Key:2, Value:3"
	assert candidate(location=None, key="key", value=None) == "Block-location:None, Key:key, Value:None"
	assert candidate(location=0, key="Key", value="Value") == "Block-location:0, Key:Key, Value:Value"
	assert candidate(
    location=(1, 2),
    key='id',
    value=3
) == "Block-location:(1, 2), Key:id, Value:3"
	assert candidate(
    "location", "key", 1) == "Block-location:location, Key:key, Value:1"
	assert candidate(location="1.1", key="test_key", value="test_value") == "Block-location:1.1, Key:test_key, Value:test_value"
	assert candidate(location=1000, key="Key", value="Value") == "Block-location:1000, Key:Key, Value:Value"
	assert candidate(location="location", key="key", value="value") == "Block-location:location, Key:key, Value:value"
	assert candidate("1", 2, "3") == "Block-location:1, Key:2, Value:3"
	assert candidate(
    location=(1, 2, 3),
    key="key",
    value="value"
) == "Block-location:(1, 2, 3), Key:key, Value:value"
	assert candidate([1, 2, 3], "key", "value") == "Block-location:[1, 2, 3], Key:key, Value:value"
	assert candidate([1, 2, 3], None, None) == "Block-location:[1, 2, 3], Key:None, Value:None"
	assert candidate(location="test", key="test", value="test") == "Block-location:test, Key:test, Value:test"
	assert candidate(location=100, key="Key", value="Value") == "Block-location:100, Key:Key, Value:Value"
	assert candidate(1, 2, "3") == "Block-location:1, Key:2, Value:3"
	assert candidate(None, None, None) == "Block-location:None, Key:None, Value:None"
	assert candidate(location=1, key=2, value=3) == "Block-location:1, Key:2, Value:3"
	assert candidate(location=10000000, key="Key", value="Value") == "Block-location:10000000, Key:Key, Value:Value"
	assert candidate(
    "location", "key", "value") == "Block-location:location, Key:key, Value:value"
	assert candidate("1", 2, 3) == "Block-location:1, Key:2, Value:3"
	assert candidate([1, 2], "key", "value") == "Block-location:[1, 2], Key:key, Value:value"
	assert candidate(location=None, key=0, value=None) == "Block-location:None, Key:0, Value:None"
	assert candidate(location=0, key=0, value=0) == "Block-location:0, Key:0, Value:0"
	assert candidate(1, 'key', 'value') == "Block-location:1, Key:key, Value:value"
	assert candidate(location="video", key="duration", value="abc") == "Block-location:video, Key:duration, Value:abc"
	assert candidate(location="video", key="duration", value=None) == "Block-location:video, Key:duration, Value:None"
	assert candidate(
    "location",
    "key",
    "value"
) == "Block-location:location, Key:key, Value:value"
	assert candidate("location", 'key', 'value') == "Block-location:location, Key:key, Value:value"
	assert candidate(location=100000, key="Key", value="Value") == "Block-location:100000, Key:Key, Value:Value"
	assert candidate(location="location", key="key", value=None) == "Block-location:location, Key:key, Value:None"
	assert candidate(
    location=[1, 2],
    key='key',
    value='value'
) == "Block-location:[1, 2], Key:key, Value:value"
	assert candidate(location=100000000, key="Key", value="Value") == "Block-location:100000000, Key:Key, Value:Value"
	assert candidate(location="video", key="duration", value="1") == "Block-location:video, Key:duration, Value:1"
	assert candidate(
    "location", "key", False) == "Block-location:location, Key:key, Value:False"
	assert candidate(location=None, key=None, value=None) == "Block-location:None, Key:None, Value:None"
	assert candidate(location=[1, 2], key="key", value="value") == "Block-location:[1, 2], Key:key, Value:value"
	assert candidate(location=None, key=None, value=0) == "Block-location:None, Key:None, Value:0"
	assert candidate(
    "location", "key", 1.1) == "Block-location:location, Key:key, Value:1.1"
	assert candidate(1, 'key', 1) == "Block-location:1, Key:key, Value:1"
	assert candidate(location="video", key="duration", value=1) == "Block-location:video, Key:duration, Value:1"
	assert candidate(location=None, key="key", value="value") == "Block-location:None, Key:key, Value:value"
	assert candidate(
    "location", "key", True) == "Block-location:location, Key:key, Value:True"
	assert candidate(1, 2, 3) == "Block-location:1, Key:2, Value:3"
	assert candidate([1, 2, 3], "key", None) == "Block-location:[1, 2, 3], Key:key, Value:None"
	assert candidate(location=0, key=None, value=None) == "Block-location:0, Key:None, Value:None"
	assert candidate(["1", "2", "3"], "key", None) == "Block-location:['1', '2', '3'], Key:key, Value:None"
	assert candidate(location="video", key="some_key", value="some_value") == \
    "Block-location:video, Key:some_key, Value:some_value"
	assert candidate(location=1000000, key="Key", value="Value") == "Block-location:1000000, Key:Key, Value:Value"
	assert candidate(location=1, key="key", value="value") == \
    "Block-location:1, Key:key, Value:value"
	assert candidate((0, 1), "key", "value") == "Block-location:(0, 1), Key:key, Value:value"
	assert candidate(location=10000, key="Key", value="Value") == "Block-location:10000, Key:Key, Value:Value"
	assert candidate(["1", "2", "3"], "key", "value") == "Block-location:['1', '2', '3'], Key:key, Value:value"
def test_check():
	check(format_xml_exception_message)
