def concat(str1, str2):
    """Concatenate two strings"""
    ### Canonical solution below ###
    return "%s%s" % (str1, str2)


### Unit tests below ###
def check(candidate):
	assert candidate("abc", "") == "abc"
	assert candidate('a','b') == 'ab'
	assert candidate(str1="", str2="bar") == "bar"
	assert candidate( "Hello", "World") == "HelloWorld"
	assert candidate("", "") == ""
	assert candidate("", "abc") == "abc"
	assert candidate(str1="foo", str2="bar") == "foobar"
	assert candidate( 'earth','mars' ) == 'earthmars'
	assert candidate(str1="foobar", str2="bar") == "foobarbar"
	assert candidate(str1="foobar", str2="") == "foobar"
	assert candidate("a", "b") == "ab"
	assert candidate( "Hello", "World" ) == "HelloWorld"
	assert candidate('a', 'b') == 'ab'
	assert candidate(str1="Python is ", str2="awesome") == "Python is awesome"
	assert candidate( "Hello", "World!" ) == "HelloWorld!"
	assert candidate(str1="", str2="") == ""
	assert candidate('a',1) == 'a1'
	assert candidate("1", "2") == "12"
	assert candidate(candidate("abc", "def"), "ghi") == "abcdefghi"
	assert candidate("abc", "def") == "abcdef"
def test_check():
	check(concat)
