def gcd_by_iterative(x, y):
    """
    >>> gcd_by_iterative(24, 40)
    8
    >>> greatest_common_divisor(24, 40) == gcd_by_iterative(24, 40)
    True
    """
    ### Canonical solution below ###
    while y:  # --> when y=0 then loop will terminate and return x as final GCD.
        x, y = y, x % y
    return x


### Unit tests below ###
def check(candidate):
	assert candidate(20, 8) == 4
	assert candidate(20, 100) == 20
	assert candidate(10, 10) == 10
	assert candidate(100, 0) == 100
	assert candidate(32, 40) == 8
	assert candidate(36, 27) == 9
	assert candidate(1000, 900) == 100
	assert candidate(100, 5) == 5
	assert candidate(1000, 200) == 200
	assert candidate(24, 48)
	assert candidate(24, 25) == 1
	assert candidate(12, 18) == 6
	assert candidate(30, 20) == 10
	assert candidate(100, 25) == 25
	assert candidate(1000, 800) == 200
	assert candidate(3*5*7, 11*13) == 1
	assert candidate(24, 2) == 2
	assert candidate(24, 16) == 8
	assert candidate(24, 1) == 1
	assert candidate(6, 3) == 3
	assert candidate(24, 0) == 24
	assert candidate(24, 40) == candidate(24, 40)
	assert candidate(10, 0) == 10
	assert candidate(2, 1) == 1
	assert candidate(0, 1) == 1
	assert candidate(12, 8) == 4
	assert candidate(100, 200) == 100
	assert candidate(100, 20) == 20
	assert candidate(24, 14) == 2
	assert candidate(0, 10) == 10
	assert candidate(24, 7) == 1
	assert candidate(1000, 300) == 100
	assert candidate(-10, 10) == 10
	assert candidate(1000, 1000) == 1000
	assert candidate(24, 4) == 4
	assert candidate(14, 21) == 7
	assert candidate(12, 16) == 4
	assert candidate(24, 6) == 6
	assert candidate(24, 40) == candidate(40, 24)
	assert candidate(0, 0) == 0
	assert candidate(40, 24) == 8
	assert candidate(9, 12) == 3
	assert candidate(10, 5) == 5
	assert candidate(27, 18) == 9
	assert candidate(24, 60) == 12
	assert candidate(1000, 1) == 1
	assert candidate(1, 0) == 1
	assert candidate(1000, 700) == 100
	assert candidate(24, 40) == 8
	assert candidate(24, 11) == 1
	assert candidate(1000, 400) == 200
	assert candidate(10, 20) == 10
	assert candidate(24, 10) == 2
	assert candidate(24, 24) == 24
	assert candidate(0, 100) == 100
	assert candidate(24, 13) == 1
	assert candidate(18, 24) == 6
	assert candidate(6, 9) == 3
	assert candidate(24, 5) == 1
def test_check():
	check(gcd_by_iterative)
