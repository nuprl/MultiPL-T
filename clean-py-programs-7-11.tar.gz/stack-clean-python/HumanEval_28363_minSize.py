def minSize(split, mined):
    """ 
     Called by combineCheck() to ensure that a given cleavage or peptide is larger than a given minSize.
     
     :param split: the cleavage or peptide that is to have its size checked against max size.
     :param mined: the min size that the cleavage or peptide is allowed to be.
     
     :return bool: False if the split is shorter than mined, True if it is longer.
     """
	### Canonical solution below ###
    

    if len(split) < mined:
        return False
    return True

### Unit tests below ###
def check(candidate):
	assert candidate(split='a', mined=3) == False
	assert candidate(split='AAA', mined=3) == True
	assert candidate(split="AAAAA", mined=6) == False
	assert candidate(split="A", mined=1) == True
	assert candidate(split = ['A', 'A'], mined = 1)
	assert candidate(split = "ATG", mined = 3) == True
	assert candidate(split = "ABCDEFGHI", mined = 10) == False
	assert not candidate(split = ['A', 'A'], mined = 3)
	assert candidate(split="AAAAA", mined=5) == True
	assert candidate(split = "ABCDE", mined = 4) == True
	assert candidate(split = "K", mined = 2) == False
	assert candidate(split="abcde", mined=3) == True
	assert candidate(split=("ABCDEF", "GH"), mined=5) is False
	assert candidate(split="A", mined=2) == False
	assert candidate(split="AAAAAAAAAAAAAAA", mined=10) == True
	assert candidate(split = "ATG", mined = 4) == False
	assert candidate(split='AAAAA', mined=6) is False
	assert candidate(split='abc', mined=2) == True
	assert candidate(split=("A", "B", "C"), mined=4) is False
	assert candidate(split='KKK', mined=3) == True
	assert candidate(split = "AAA", mined = 3) == True
	assert candidate(split = ['A', 'A'], mined = 2)
	assert candidate(split=("A", "B", "C"), mined=3) == True
	assert candidate(split='AA', mined=3) == False
	assert candidate(split='abcd', mined=3) == True
	assert candidate(split='abc', mined=3) == True
	assert candidate(split="AAAA", mined=2) == True
	assert candidate(split='AAAAA', mined=5) is True
	assert candidate(split='K', mined=2) == False
	assert candidate(split="A", mined=0) == True
	assert candidate(split = "A", mined = 3) == False
	assert candidate(split="abcde", mined=10) == False
	assert candidate(split = "ABCDEFGHI", mined = 9) == True
	assert candidate(split=("A", "B", "C"), mined=3) is True
	assert candidate(split="RR", mined=5) == False
	assert candidate(split = "KKKKKKKKKKKKKKKKK", mined = 2) == True
	assert candidate(split = "KKKKKKKKKKKKKKKKK", mined = 1) == True
	assert candidate(split = "K", mined = 1) == True
	assert candidate(split = 'abc', mined = 3) == True
	assert candidate(split='KKKK', mined=3) == True
def test_check():
	check(minSize)
