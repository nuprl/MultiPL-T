def common_keys(dict_a, dict_b):
    """Returns new dict with the common keys of the input dicts using dict_a values"""
    ### Canonical solution below ###
    return {key: dict_a[key] for key in dict_a.keys() & dict_b.keys()}


### Unit tests below ###
def check(candidate):
	assert candidate(dict(), dict(a=1, b=2, c=3)) == {}
	assert candidate(dict(a=1, b=2), dict(a=3, b=4, c=5)) == dict(a=1, b=2)
	assert candidate(dict(a=1, b=2), dict(c=3, d=4)) == dict()
	assert candidate(dict(a=1, b=2), dict(b=2, c=3)) == candidate(dict(b=2, c=3), dict(a=1, b=2))
	assert candidate(dict(a=1, b=2, c=3), dict(c=3, d=4)) == dict(c=3)
	assert candidate(dict(a=1, b=2), dict(b=2, c=3)) == dict(b=2)
	assert candidate(dict(a=1, b=2, c=3), dict(d=40, e=50)) == {}
	assert candidate(dict(a=1, b=2), dict(a=3, c=4)) == dict(a=1)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'a': 1, 'c': 3, 'd': 4}) == {'a': 1, 'c': 3}
	assert candidate(dict(a=1, b=2, c=3), dict(a=100, b=200)) == {'a': 1, 'b': 2}
	assert candidate(dict(a=1, b=2), dict(b=3, c=4)) == dict(b=2)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'b': 11, 'd': 13}
) == {'b': 2}
	assert candidate(dict(a=1, b=2, c=3), dict(b=20, c=30, d=40)) == dict(b=2, c=3)
	assert candidate(dict(a=1, b=2, c=3), dict(b=20, d=40)) == dict(b=2)
	assert candidate(dict(a=1, b=2, c=3), dict(c=3, d=4, e=5)) == dict(c=3)
	assert candidate(dict(a=1, b=2), dict(a=100, b=200, c=300)) == {'a': 1, 'b': 2}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'b': 11, 'c': 13}
) == {'b': 2, 'c': 3}
	assert candidate(dict(a=1, b=2), dict(b=2)) == dict(b=2)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'b': 2, 'c': 3, 'd': 4},
) == {'b': 2, 'c': 3}
	assert candidate(dict(a=1, b=2, c=3), dict(e=3, f=4, g=5)) == {}
	assert candidate(dict(a=1, b=2), dict(a=3, b=4)) == dict(a=1, b=2)
	assert candidate(dict(a=1, b=2), dict(d=4, e=5)) == dict()
	assert candidate(dict(a=1, b=2), dict(a=1, b=2)) == dict(a=1, b=2)
	assert candidate(dict_a = {'a': 1, 'b': 2}, dict_b = {'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
	assert candidate(dict(a=1, b=2), dict(b=2, c=3)) == candidate(dict(b=2, c=3), dict(b=2, a=1))
	assert candidate(dict(a=1, b=2), dict(a=100, b=200)) == {'a': 1, 'b': 2}
	assert candidate(dict(a=1, b=2), dict(b=2, c=3, d=4)) == dict(b=2)
	assert candidate(dict(a=1, b=2, c=3), dict()) == {}
	assert candidate(dict(a=1, b=2), dict(c=3, d=4)) == {}
	assert candidate(dict_a = {'a': 1, 'b': 2}, dict_b = {'b': 2, 'c': 3}) == {'b': 2}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3},
    {'d': 4, 'e': 5, 'f': 6},
) == {}
	assert candidate(dict(a=1, b=2, c=3), dict(a=100, b=200, d=400)) == {'a': 1, 'b': 2}
def test_check():
	check(common_keys)
