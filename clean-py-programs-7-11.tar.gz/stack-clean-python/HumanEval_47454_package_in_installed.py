def package_in_installed(new_package, installed):
    """ 
     Searches for new_package in the installed tree, returns error message (or empty string)
     (checks the root of the tree and walks the installed tree)
     """
	### Canonical solution below ###    
    conflict = ""
    if 'dependencies' in installed:
        previous = installed['dependencies']
        for used in previous.keys():
            # logger.debug("=====\npackage\n%s\nvs\n%s" % (pprint.pformat(new_package), pprint.pformat(previous[used])))
            used_conflict=""
            if new_package['package_description']['name'] == used:
                if 'archive' in new_package and new_package['archive']:
                    # this is a dependency of the new package, so we have archive data
                    if new_package['archive']['url'].rsplit('/',1)[-1] \
                      != previous[used]['archive']['url'].rsplit('/',1)[-1]:
                        used_conflict += "  installed url  %s\n" % previous[used]['archive']['url']
                        used_conflict += "             vs  %s\n" % new_package['archive']['url']
                    if new_package['archive']['hash'] != previous[used]['archive']['hash']:
                        used_conflict += "  installed hash %s\n" % previous[used]['archive']['hash']
                        used_conflict += "             vs  %s\n" % new_package['archive']['hash']
                else:
                    # this is the newly imported package, so we don't have a url for it
                    pass
                if new_package['configuration'] != previous[used]['configuration']:
                    used_conflict += "  installed configuration %s\n" % previous[used]['configuration']
                    used_conflict += "                      vs  %s\n" % new_package['configuration']
                if new_package['package_description']['version'] != previous[used]['package_description']['version']:
                    used_conflict += "  installed version %s\n" % previous[used]['package_description']['version']
                    used_conflict += "                vs  %s\n" % new_package['package_description']['version']
                if new_package['build_id'] != previous[used]['build_id']:
                    used_conflict += "  installed build_id %s\n" % previous[used]['build_id']
                    used_conflict += "                 vs  %s\n" % new_package['build_id']
                if used_conflict:
                    conflict += used + "\n" + used_conflict
            else:
                # recurse to check the dependencies of previous[used]
                conflict += package_in_installed(new_package, previous[used])
                if conflict:
                    conflict += "used by %s version %s build %s\n" % \
                      ( previous[used]['package_description']['name'],
                        previous[used]['package_description']['version'],
                        previous[used]['build_id'])

            if conflict:
                # in order to be able to add the import path, we only detect the first conflict
                return conflict
    return ""

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'package_description': {'name': 'a','version': '1.0', 'description': 'desc'},
     'build_id': '1', 'configuration': 'cfg',
     'archive': {'url': 'http://example.com/a.tar.gz', 'hash': '12345'}},
    {'dependencies': {'a': {'package_description': {'name': 'a','version': '1.0', 'description': 'desc'},
                           'build_id': '1', 'configuration': 'cfg',
                           'archive': {'url': 'http://example.com/a.tar.gz', 'hash': '12345'}}}}) == ""
	assert candidate(
    {'package_description': {'name': 'foo'},
     'archive': {'url': 'http://somewhere/foo.tar.gz', 'hash': '12345'},
     'configuration': 'default',
     'build_id': 'b012345'},
    {'foo': {'package_description': {'name': 'foo'},
             'archive': {'url': 'http://somewhere/foo.tar.gz', 'hash': '12345'},
             'configuration': 'default',
             'build_id': 'b012345'},
     'bar': {'package_description': {'name': 'bar'},
             'archive': {'url': 'http://somewhere/bar.tar.gz', 'hash': '12345'},
             'configuration': 'default',
             'build_id': 'b012345'}
     }) == ""
	assert candidate(
  {'package_description': {'name':'foo','version':'1.0'},
   'build_id': '1234',
   'configuration': 'default',
   'archive': {'url': 'http://foo.bar/foo.zip', 'hash': '12345'}},
  {'dependencies': {'foo': {'package_description': {'name':'foo','version':'1.0'},
                           'build_id': '1234',
                           'configuration': 'default',
                           'archive': {'url': 'http://foo.bar/foo.zip', 'hash': '12345'}}}}) == ""
	assert candidate(
  { 'package_description': { 'name': 'foo' },
    'build_id': '1234',
    'archive': { 'url': 'http://example.com/foo-1.2.3-1234.tar.bz2',
                 'hash': '1234567890123456789012345678901234567890' },
    'configuration': 'default' },
  { 'package_description': { 'name': 'foo' },
    'build_id': '1234',
    'archive': { 'url': 'http://example.com/foo-1.2.3-1234.tar.bz2',
                 'hash': '1234567890123456789012345678901234567890' },
    'configuration': 'default',
    'dependencies': { 'bar': { 'package_description': { 'name': 'bar' },
                              'build_id': '5678',
                              'archive': { 'url': 'http://example.com/bar-1.2.3-5678.tar.bz2',
                                           'hash': '1234567890123456789012345678901234567890' },
                              'configuration': 'default' } } }) == ""
	assert candidate(
  { 'package_description': {'name': 'foo','version': '1.0'},
    'configuration': 'Release',
    'archive': { 'hash': '12345', 'url': 'http://foo.org/bar.tar.gz' }
  },
  { 'package_description': {'name': 'foo','version': '1.0'},
    'configuration': 'Release',
    'archive': { 'hash': '12345', 'url': 'http://foo.org/bar.tar.gz' },
    'build_id': '12345',
    'dependencies': {
      'bar': {
        'package_description': {'name': 'bar','version': '1.0'},
        'configuration': 'Release',
        'archive': { 'hash': '12345', 'url': 'http://foo.org/bar.tar.gz' },
        'build_id': '12345'
      }
    }
  }) == "", \
  "candidate() with no conflicts"
	assert candidate(
    {'package_description': {'name': 'a','version': '1.0', 'description': 'desc'},
     'build_id': '1', 'configuration': 'cfg',
     'archive': {'url': 'http://example.com/a.tar.gz', 'hash': '12345'}},
    {'dependencies': {'a': {'package_description': {'name': 'a','version': '1.0', 'description': 'desc'},
                           'build_id': '1', 'configuration': 'cfg',
                           'archive': {'url': 'http://example.com/a.tar.gz', 'hash': '12345'}},
                      'b': {'package_description': {'name': 'b','version': '1.0', 'description': 'desc'},
                           'build_id': '1', 'configuration': 'cfg',
                           'archive': {'url': 'http://example.com/b.tar.gz', 'hash': '12345'}}}}) == ""
	assert candidate(
  {'package_description': {'name': 'foo','version': '0.0.1'},
   'archive': {'url': 'https://example.com/foo-0.0.1.tar.gz', 'hash': '1234567890abcdef'},
   'configuration': 'Release',
   'build_id': '12345'},
  {'dependencies': {
    'foo': {
      'package_description': {'name': 'foo','version': '0.0.1'},
      'archive': {'url': 'https://example.com/foo-0.0.1.tar.gz', 'hash': '1234567890abcdef'},
      'configuration': 'Release',
      'build_id': '12345',
      'dependencies': {
        'bar': {
          'package_description': {'name': 'bar','version': '0.0.1'},
          'archive': {'url': 'https://example.com/bar-0.0.1.tar.gz', 'hash': '1234567890abcdef'},
          'configuration': 'Release',
          'build_id': '12345'}}}}}) == ""
	assert candidate(
    {'package_description': {'name': 'foo'},
     'archive': {'url': 'http://somewhere/foo.tar.gz', 'hash': '12345'},
     'configuration': 'default',
     'build_id': 'b012345'},
    {'foo': {'package_description': {'name': 'foo'},
             'archive': {'url': 'http://somewhere/foo.tar.gz', 'hash': '12345'},
             'configuration': 'default',
             'build_id': 'b012345'}
     }) == ""
	assert candidate(
  {'package_description': {'name': 'foo','version': '1.0'},
   'archive': {'url': 'https://example.com/foo.tar.gz', 'hash': '12345'},
   'configuration': 'default',
   'build_id': '1234567890'},
  {'dependencies': {
    'foo': {
      'package_description': {'name': 'foo','version': '1.0'},
      'archive': {'url': 'https://example.com/foo.tar.gz', 'hash': '12345'},
      'configuration': 'default',
      'build_id': '1234567890'}}}) == ""
	assert candidate(
  { 'package_description': { 'name': 'b','version': '1.0' },
    'archive': { 'url': 'url1', 'hash': 'hash1' },
    'build_id': '1',
    'configuration': 'Release',
    'dependencies': { 'a': { 'package_description': { 'name': 'a','version': '1.0' },
                            'archive': { 'url': 'url1', 'hash': 'hash1' },
                            'build_id': '1',
                            'configuration': 'Release' } } },
  { 'a': { 'package_description': { 'name': 'a','version': '1.0' },
           'archive': { 'url': 'url1', 'hash': 'hash1' },
           'build_id': '1',
           'configuration': 'Release',
           'dependencies': { 'b': { 'package_description': { 'name': 'b','version': '1.0' },
                                   'archive': { 'url': 'url1', 'hash': 'hash1' },
                                   'build_id': '1',
                                   'configuration': 'Release' } } } }) == ""
	assert candidate(
  {'archive': {'hash': 'hash1', 'url': 'url1'},
   'build_id': 'build1',
   'configuration': 'config1',
   'package_description': {'name': 'name1','version':'version1'}},
  {'dependencies': {'name1': {'archive': {'hash': 'hash1', 'url': 'url1'},
                              'build_id': 'build1',
                              'configuration': 'config1',
                              'package_description': {'name': 'name1','version':'version1'}}}}) == ""
def test_check():
	check(package_in_installed)
