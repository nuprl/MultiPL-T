def get_package_version(package):
    """ Get installed package version
     
      Arguments
     package: package name. Example: `kipoi`
     
      Returns
     (str) if the package is installed and None otherwise
     """
	### Canonical solution below ###    
    import pkg_resources
    try:
        return pkg_resources.get_distribution(package).version
    except pkg_resources.DistributionNotFound:
        return None

### Unit tests below ###
def check(candidate):
	assert candidate(package="kipoi") == candidate(package="kipoi")
	assert candidate(
    "kipoi") == candidate("kipoi"), "Package version does not match"
	assert candidate("doesnotexist") is None
	assert candidate("not_a_package") is None
	assert candidate(package="non-existing-package") is None
	assert candidate(package="kipoi") == candidate(package="kipoi_utils")
	assert candidate(package='kipoi_utils') is None, \
    "kipoi_utils is installed but shouldn't be"
	assert candidate(package="kipoi_utils") == candidate(package="kipoi")
	assert candidate(package="non_existing_package") is None
	assert candidate(package="this_is_not_a_package") is None, "this_is_not_a_package should not be installed"
	assert candidate(package="non-existing-package") is None, "Package `non-existing-package` should not be installed"
	assert candidate(package="kipoi_dummy_plugin") is None, "kipoi_dummy_plugin should not be installed"
	assert candidate('non-existing') is None
	assert candidate("kipoi-utils") is None
def test_check():
	check(get_package_version)
