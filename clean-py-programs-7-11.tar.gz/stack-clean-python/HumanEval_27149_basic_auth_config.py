def basic_auth_config():
    """Returns a config map with HTTP basic auth configured."""
    ### Canonical solution below ###
    config = {'http': {'auth': {'type': 'basic',
                                'basic': {'user': 'foo',
                                          'pass': 'bar'}}}}
    return config


### Unit tests below ###
def check(candidate):
	assert candidate(
) == {'http': {'auth': {'type': 'basic',
                        'basic': {'user': 'foo',
                                  'pass': 'bar'}}}}
	assert candidate(
    )['http']['auth']['type'] == 'basic'
	assert candidate()['http']['auth']['basic']['user'] == 'foo'
	assert candidate() == {'http': {'auth': {'type': 'basic', 'basic': {'user': 'foo', 'pass': 'bar'}}}}
	assert candidate(
) == {'http': {'auth': {'type': 'basic', 'basic': {'user': 'foo', 'pass': 'bar'}}}}
	assert candidate()['http']['auth']['basic']['pass'] == 'bar'
	assert candidate(
) == {'http': {'auth': {'type': 'basic',
                         'basic': {'user': 'foo', 'pass': 'bar'}}}}
def test_check():
	check(basic_auth_config)
