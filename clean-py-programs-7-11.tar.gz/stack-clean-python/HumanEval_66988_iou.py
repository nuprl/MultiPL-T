def iou(box1, box2, denom="min"):
    """ compute intersection over union score """
    ### Canonical solution below ###
    int_tb = min(box1[0]+0.5*box1[2], box2[0]+0.5*box2[2]) - \
             max(box1[0]-0.5*box1[2], box2[0]-0.5*box2[2])
    int_lr = min(box1[1]+0.5*box1[3], box2[1]+0.5*box2[3]) - \
             max(box1[1]-0.5*box1[3], box2[1]-0.5*box2[3])

    intersection = max(0.0, int_tb) * max(0.0, int_lr)
    area1, area2 = box1[2]*box1[3], box2[2]*box2[3]
    control_area = min(area1, area2) if denom == "min"  \
                   else area1 + area2 - intersection

    return intersection / control_area


### Unit tests below ###
def check(candidate):
	assert candidate(box1=(10, 20, 10, 10), box2=(10, 20, 10, 10), denom="max") == 1.0
	assert candidate(box1=(0, 0, 1, 1), box2=(0.5, 0.6, 1, 1)) == 0.2
	assert candidate(box1=(0.0, 0.0, 1.0, 1.0), box2=(0.0, 0.0, 1.0, 1.0)) == 1.0
	assert candidate(box1=[0, 0, 1, 1], box2=[0, 0, 1, 1]) == 1.0
	assert candidate(box1=[0,0,1,1], box2=[0,0,2,2]) == 1.0
	assert candidate(box1=[0, 0, 1, 1], box2=[0, 0, 1, 1], denom="sum") == 1
	assert candidate(box1=[1, 1, 2, 2], box2=[1, 1, 2, 2]) == 1.0
	assert candidate(box1=[0, 0, 1, 1], box2=[0, 0, 1, 1], denom="union") == 1
	assert candidate(box1=(0, 0, 1, 1), box2=(0, 0, 2, 2)) == 1.0
	assert candidate(box1=(0, 0, 1, 1), box2=(0.5, 0.5, 1, 1)) == 0.25
	assert candidate(box1=(0, 0, 1, 1), box2=(0, 0, 1, 1)) == 1.0
	assert candidate(box1=[0, 0, 1, 1], box2=[0, 0, 1, 1], denom="min") == 1
	assert candidate(box1=[0,0,1,1], box2=[0,0,1,1], denom="mean") == 1.0
	assert candidate(box1=[10, 10, 3, 4], box2=[10, 10, 3, 4], denom="avg") == 1.0
	assert candidate(box1=(0, 0, 10, 10), box2=(11, 11, 10, 10)) == 0.0
	assert candidate(box1=[100, 100, 200, 200], box2=[100, 100, 200, 200]) == 1.0
	assert candidate(box1=[0, 0, 1, 1], box2=[0, 0, 2, 2]) == 1.0
	assert candidate(box1=(10, 20, 10, 10), box2=(10, 20, 10, 10)) == 1.0
	assert candidate(box1=(1, 1, 2, 2), box2=(1, 1, 2, 2)) == 1
	assert candidate(box1=(0, 0, 10, 10), box2=(0, 0, 10, 10)) == 1.0
	assert candidate(box1=(0, 0, 1, 1), box2=(0, 0, 1, 1), denom="max") == 1.0
	assert candidate(box1=[10, 10, 3, 4], box2=[10, 10, 3, 4], denom="max") == 1.0
	assert candidate(box1=(0, 0, 1, 1), box2=(0.5, 0.5, 0.5, 0.5)) == 0.25
	assert candidate(box1=[0,0,1,1], box2=[0,0,1,1], denom="union") == 1.0
	assert candidate(box1=[0, 0, 1, 1], box2=[-1, -1, 2, 2]) == 0.25
	assert candidate(box1=(10, 10, 5, 5), box2=(20, 20, 5, 5), denom="min") == 0.0
	assert candidate(box1=[0,0,1,1], box2=[0,0,1,1], denom="min") == 1.0
	assert candidate(box1=[0,0,1,1], box2=[-1,-1,2,2]) == 0.25
	assert candidate(box1=(0, 0, 10, 10), box2=(0, 0, 10, 10)) == candidate(box2=(0, 0, 10, 10), box1=(0, 0, 10, 10))
	assert candidate(box1=(0, 0, 1, 1), box2=(2, 2, 1, 1)) == 0.0
	assert candidate(box1=[0,0,1,1], box2=[0,0,1,1]) == 1.0
	assert candidate(box1=(1, 1, 4, 4), box2=(3, 3, 4, 4)) == 0.25
	assert candidate(box1=(0.0, 0.0, 1.0, 1.0), box2=(0.5, 0.5, 0.5, 1.0)) == 0.25
	assert candidate(box1=[10, 10, 3, 4], box2=[10, 10, 3, 4]) == 1.0
	assert candidate(box1=(1, 1, 2, 2), box2=(3, 3, 2, 2)) == 0
	assert candidate(box1=[100, 100, 200, 200], box2=[100, 100, 200, 200], denom="max") == 1.0
def test_check():
	check(iou)
