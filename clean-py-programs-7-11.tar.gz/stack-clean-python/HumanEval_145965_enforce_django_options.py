def enforce_django_options(struct, opts):
    """Make sure options reflect the Django usage.

    Args:
        struct (dict): project representation as (possibly) nested
            :obj:`dict`.
        opts (dict): given options, see :obj:`create_project` for
            an extensive list.

    Returns:
        struct, opts: updated project representation and options
    """
    ### Canonical solution below ###
    opts["package"] = opts["project"]  # required by Django
    opts["force"] = True
    opts.setdefault("requirements", []).append("django")

    return struct, opts


### Unit tests below ###
def check(candidate):
	assert candidate(dict(), dict(project="prj"))[1]["package"] == "prj"
	assert candidate(
    {"project": "spam"}, {"project": "eggs"}
)[1]["package"] == "eggs"
	assert candidate(
    {"project": "foo", "package": "foo"},
    {"project": "foo", "requirements": []}
)[1]["package"] == "foo"
	assert candidate(
    {"project": "my_project"},
    {"project": "my_project", "requirements": ["foo"]}
)[1]["requirements"] == ["foo", "django"]
	assert candidate(
    {}, {"project": "foo", "package": "bar"}
) == ({}, {"project": "foo", "package": "foo", "force": True,
          "requirements": ["django"]})
	assert candidate(
    {"project": "foo"}, {"project": "foo", "requirements": []}
)[1]["package"] == "foo"
	assert candidate(
    {},
    {"project": "foo"}
)[1]["package"] == "foo"
	assert candidate(
    {"project": "foo", "package": "foo"},
    {"project": "foo", "force": False}
)[1]["package"] == "foo"
	assert candidate(
    {},
    {"project": "foo", "requirements": [], "package": None, "force": False},
) == ({}, {"project": "foo", "requirements": ["django"], "package": "foo", "force": True})
	assert candidate(
    {"project": "foo", "package": "foo"},
    {"project": "foo"}
)[1]["package"] == "foo"
	assert candidate(
    {"project": "foo"}, {"project": "foo"}
)[1]["package"] == "foo"
	assert candidate(
    {"name": "my-project"},
    {"project": "my-project"}
)[1] == {
    "project": "my-project",
    "package": "my-project",
    "requirements": ["django"],
    "force": True,
}
def test_check():
	check(enforce_django_options)
