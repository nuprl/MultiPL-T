def pow_op_to_callable(expr: str) -> str:
    """
    Replace a string expression of the form 'a**b' or 'a^b' 
    to 'pow(a, b)'. Expressions of the form 'a**(b**c**...)' 
    will be replaced with 'pow(a, b**c**...)'.

    A necessary precondition is that the expression either contains
    '^' or '**'.

    Parameters:
     expr: string expression of the form 'a**b'
    """
    ### Canonical solution below ###
    caret, stars = expr.find('^'), expr.find('**')
    if stars >= 0 and caret < 0:
        bin_tokens = expr.split('**', 1)
    elif stars < 0 and caret >= 0:
        bin_tokens = expr.split('^', 1)
    else:
        bin_tokens = (expr.split('^', 1) if caret < stars 
                      else expr.split('**', 1))
    return 'pow(' + bin_tokens[0] + ',' + bin_tokens[1] + ')'


### Unit tests below ###
def check(candidate):
	assert candidate(expr='a**b**c^d') == 'pow(a,b**c^d)'
	assert candidate(expr = 'a**b') == 'pow(a,b)'
	assert candidate(expr = 'x**2') == 'pow(x,2)'
	assert candidate(r'x**y**z') == 'pow(x,y**z)'
	assert candidate(r'x**y^z') == 'pow(x,y^z)'
	assert candidate(
    'a**b') == 'pow(a,b)', 'Simple exponentiation'
	assert candidate(expr='a**b^c**d') == 'pow(a,b^c**d)'
	assert candidate(r'x**y') == 'pow(x,y)'
	assert candidate(expr='a**b**c**d') == 'pow(a,b**c**d)'
	assert candidate(r'a^3') == 'pow(a,3)'
	assert candidate(
    'a**b**c**d') == 'pow(a,b**c**d)', 'Exponentiation with multiple powers'
	assert candidate(r'2**3**4') == 'pow(2,3**4)'
	assert candidate(
    'a**b'
) == 'pow(a,b)'
	assert candidate(r'a**3') == 'pow(a,3)'
	assert candidate(
    "a^b"
) == "pow(a,b)"
	assert candidate(
    'a**b**c') == 'pow(a,b**c)', 'Incorrect substitution'
	assert candidate(expr = 'x^2') == 'pow(x,2)'
	assert candidate(expr='a^b**c') == 'pow(a,b**c)'
	assert candidate(
    'a**b') == 'pow(a,b)', 'Incorrect substitution'
	assert candidate(expr='a**b^c^d') == 'pow(a,b^c^d)'
	assert candidate(r'2**3') == 'pow(2,3)'
	assert candidate(r'x**2') == 'pow(x,2)'
	assert candidate(r'x^y^z') == 'pow(x,y^z)'
	assert candidate(expr='a**b**c**d**e') == 'pow(a,b**c**d**e)'
	assert candidate(r'a^b**c') == 'pow(a,b**c)'
	assert candidate(r'x^y**z') == 'pow(x,y**z)'
	assert candidate(
    'a^b^c^d') == 'pow(a,b^c^d)', 'Exponentiation with multiple powers'
	assert candidate(r'a^b') == 'pow(a,b)'
	assert candidate(expr='a^b**c^d^e') == 'pow(a,b**c^d^e)'
	assert candidate(r'a^3^4') == 'pow(a,3^4)'
	assert candidate(r'3^a') == 'pow(3,a)'
	assert candidate(r'x^y') == 'pow(x,y)'
	assert candidate(r'2^3') == 'pow(2,3)'
	assert candidate(r'x**(y**(z**t))**(w**(u**v))') == 'pow(x,(y**(z**t))**(w**(u**v)))'
	assert candidate(
    'a^b') == 'pow(a,b)', 'Incorrect substitution'
	assert candidate(expr = 'x**y') == 'pow(x,y)'
	assert candidate(r'3**a') == 'pow(3,a)'
	assert candidate(expr='a**b^c') == 'pow(a,b^c)'
	assert candidate(r'2^3**4') == 'pow(2,3**4)'
	assert candidate(r'x^2') == 'pow(x,2)'
	assert candidate(expr='a**b') == 'pow(a,b)'
	assert candidate(r'a^3**4') == 'pow(a,3**4)'
	assert candidate(
    'a^b'
) == 'pow(a,b)'
	assert candidate(expr='a**b^c^d^e') == 'pow(a,b^c^d^e)'
	assert candidate(expr = 'x^y') == 'pow(x,y)'
	assert candidate(r'a**3^4') == 'pow(a,3^4)'
	assert candidate(expr='a^b^c') == 'pow(a,b^c)'
	assert candidate(r'a**3**4') == 'pow(a,3**4)'
	assert candidate(expr='a^b^c^d^e') == 'pow(a,b^c^d^e)'
	assert candidate(r'2**3^4') == 'pow(2,3^4)'
	assert candidate(
    "a**b"
) == "pow(a,b)"
	assert candidate(expr = 'a^b') == 'pow(a,b)'
	assert candidate(r'2^3^4') == 'pow(2,3^4)'
	assert candidate(r'x**y**(z**t)') == 'pow(x,y**(z**t))'
	assert candidate(r'3**a**4') == 'pow(3,a**4)'
	assert candidate(
    'a^b^c^d') == 'pow(a,b^c^d)', 'Incorrect substitution'
	assert candidate(expr='a**b**c') == 'pow(a,b**c)'
	assert candidate(
    'a^b^c') == 'pow(a,b^c)', 'Incorrect substitution'
	assert candidate(expr='a^b^c^d') == 'pow(a,b^c^d)'
	assert candidate(
    'a^b') == 'pow(a,b)', 'Simple exponentiation'
	assert candidate(expr='a**b**(c**d)') == 'pow(a,b**(c**d))'
	assert candidate(
    'a**b**c**d') == 'pow(a,b**c**d)', 'Incorrect substitution'
	assert candidate(
    "a**b**c"
) == "pow(a,b**c)"
	assert candidate(expr='a^b') == 'pow(a,b)'
	assert candidate(r'a**b') == 'pow(a,b)'
	assert candidate(expr='a^b**c^d') == 'pow(a,b**c^d)'
	assert candidate(r'x**(y**z)**(t**(w**u))') == 'pow(x,(y**z)**(t**(w**u)))'
def test_check():
	check(pow_op_to_callable)
