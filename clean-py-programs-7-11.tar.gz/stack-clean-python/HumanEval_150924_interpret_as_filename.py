def interpret_as_filename(textbox_content):
    """ 
     docs
     """
	### Canonical solution below ###    

    FILE_TAG = "."
    return FILE_TAG in textbox_content

### Unit tests below ###
def check(candidate):
	assert candidate(
    "This.is.a.filename"
) == True
	assert candidate(
    "C:/Users/Eric/Documents/Programming/Python/Projects/CS/TextEditor/README.md"
) == True
	assert candidate("") == False
	assert candidate(
    "C:/Users/Eric/Documents/Programming/Python/Projects/CS/TextEditor/README"
) == False
	assert candidate(r"C:\Users\user\Desktop\file.txt") == True
	assert candidate(r"C:\Users\user\Downloads\file.txt") == True
	assert candidate(r"C:\test.txt") == True
	assert candidate("README") == False
	assert candidate(r"C:\Users\user\this is a test.txt.txt") == True
	assert candidate(
    ".txt") == True
	assert candidate(r"./this is a test") == True
	assert candidate("hello.txt") == True
	assert candidate(r"C:\Users\jdoe\Downloads\file.txt")
	assert candidate("1234.txt.gz.bzip.tar.bz2") == True
	assert candidate(r"test") == False
	assert candidate('test') == False
	assert candidate(
    "This.is.a.filename.with.many.dots.txt") == True
	assert candidate(
    "file.txt.zip") == True, "Should return True for file.txt.zip"
	assert candidate(r"C:\Users\user\Desktop\hello.txt")
	assert candidate("foo") is False
	assert candidate("c:\\users\\username\\documents\\python\\scripts") == False
	assert candidate("abc.txt") == True
	assert candidate(
    ".this is a.file") == True
	assert candidate("hello.") == True
	assert candidate(
    "this.is.a.file.") == True
	assert candidate(
    "C:\\Users\\User\\Documents\\file.txt") == True
	assert candidate("hello.txt.png") == True
	assert candidate(
    "This.is.a.filename") == True
	assert candidate(r"C:\Users\user\this is a test.") == True
	assert candidate(
    'C:/Users/User/Documents/test.txt') == True
	assert candidate(
    "This is a file.txt") == True
	assert candidate(
    "this is a.file") == True
	assert candidate(
    "2015-03-01-12-00-00-AM.gif") == True
	assert candidate("abc") == False
	assert not candidate(r"C:\Users\user\Desktop")
	assert candidate(
    "my_file"
) == False
	assert candidate(
    "this is a file.") == True
	assert candidate(
    ".this.is.a.file") == True
	assert candidate("1234.txt.gz") == True
	assert candidate(r"C:\Users\user\this is a test.txt") == True
	assert candidate("C:/Users/Eric/Documents/Programming/Python/README") == False
	assert candidate(
    "file.txt") == True
	assert candidate(
    "myfile.txt"
) == True
	assert candidate(r"c:\users\josh\folder\file.txt") == True
	assert candidate(r"C:\Users\user\Downloads\file") == False
	assert candidate(r"c:\users\josh\folder") == False
	assert candidate(
    "file.zip.txt") == True, "Should return True for file.zip.txt"
	assert candidate("Hello World") == False
	assert candidate(
    "This is not a filename"
) == False
	assert candidate('C:/Users/User/Documents/test.txt') == True
	assert candidate(
    "https://www.google.com/search?q=test.txt&rlz=1C5CHFA_enCA838CA838&oq=test&aqs=chrome..69i57j0i22i30l5.1821j0j7&sourceid=chrome&ie=UTF-8"
) == True
	assert candidate("foo.bar") is True
	assert candidate("") is False
	assert candidate(
    "file.zip") == True, "Should return True for file.zip"
	assert candidate(r"c:\users\josh\folder\file") == False
	assert candidate(r"C:\Users\user\Desktop\file") == False
	assert candidate("1234.txt.gz.bzip") == True
	assert candidate(r"C:\Program Files\test.txt") == True
	assert not candidate(r"C:\Users\user\Desktop\hello")
	assert candidate(
    "2015-03-01-12-00-00-AM.jpg") == True
	assert candidate(
    "C:/Users/Eric/Documents/Programming/Python/Projects/CS/TextEditor/main.py"
) == True
	assert candidate(
    "This is a file") == False
	assert candidate("hello") == False
	assert candidate(r"test.txt") == True
	assert candidate(
    "file.txt.zip.7z") == True, "Should return True for file.txt.zip.7z"
	assert candidate(
    ".this is a file") == True
	assert candidate(
    "this is a file") == False
	assert candidate('test.txt') == True
	assert candidate(
    "file") == False, "Should return False for file"
	assert candidate(r"C:\Program Files\test") == False
	assert candidate(
    ".this.is.a.file.") == True
	assert candidate(
    "2015-03-01-12-00-00-AM.png") == True
	assert candidate("filename.txt") == True
	assert candidate(
    "this is a.file.") == True
	assert candidate(r"C:\test") == False
	assert candidate("1234.txt") == True
	assert candidate(
    "This is not a filename") == False
	assert candidate(
    "file.txt") == True, "Should return True for file.txt"
	assert candidate(
    "c:\\users\\username\\documents\\python\\scripts\\myscript.py") == True
	assert candidate("1234") == False
	assert candidate(
    "my_file.txt"
) == True
def test_check():
	check(interpret_as_filename)
