def detect_publisher(fstring):
    """ Detect the publisher of a html file by searching for unique strings
    :param fstring: document HTML or XML text
    :type: byte string
    :returns: publisher name as a unique string
    """
    ### Canonical solution below ###
    if b'<meta name="dc.Identifier" scheme="doi" content="10.1021/' in fstring:
        return 'acs'
    elif b'content="10.1039/' in fstring:
        return 'rsc'
    elif b'<link rel="canonical" href="http://www.sciencedirect.com/' in fstring:
        return 'elsevier'
    elif b'full-text-retrieval-response' in fstring:
        return 'elsevier'
    elif b'<meta content="10.1007/' in fstring or b'<meta content="https://link.springer.com' in fstring:
        return 'springer'
    else:
        return None


### Unit tests below ###
def check(candidate):
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1039/c6ra05170a">') == 'rsc'
	assert candidate(b'10.1002/anie.201603977') is None
	assert candidate(b'<meta content="https://link.springer.com/article/10.1007/s10853-015-0225-z') =='springer', 'candidate springer test failed'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpcb.7b05577') == 'acs'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpcb.7b03815">') == 'acs'
	assert candidate(b'<meta content="10.1007/s12273-015-0397-5') =='springer'
	assert candidate(b'full-text-retrieval-response') == 'elsevier'
	assert candidate(b'content="10.1039/c4cp00532a') == 'rsc'
	assert candidate(b'content="10.1039/c8ta00015j') == 'rsc', 'candidate RSC test failed'
	assert candidate(b'content="10.1039/c9cp03051h"') == 'rsc'
	assert candidate(b'<meta name="citation_journal_abbrev" content="J. Chem. Phys.">') == None, 'candidate unknown publisher test failed'
	assert candidate(b'<meta content="https://link.springer.com') =='springer'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S0021961416303311') == 'elsevier'
	assert candidate(b'<meta content="10.1007/') =='springer'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/jacs.9b08723') == 'acs', 'candidate ACS test failed'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1039/C2DT22982F">') == 'rsc'
	assert candidate(b'<meta content="10.1007/s10822-011-9182-9" name="citation_doi"/>') =='springer'
	assert candidate(b'<meta name="dc.Identifier" content="10.1039/') == 'rsc'
	assert candidate(b'<meta content="10.1007/s10454-019-09678-x">') =='springer'
	assert candidate(b'<meta content="10.1007/s10822-015-9728-4">') =='springer'
	assert candidate(b'<meta content="10.1039/c5cc03941g">') == 'rsc'
	assert candidate(b'') == None
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S0021961416302034') == 'elsevier', 'candidate elsevier test failed'
	assert candidate(b'10.1016/') is None
	assert candidate(b'<meta content="10.1007/s00214-015-2799-9">') =='springer'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/jp506482b') == 'acs'
	assert candidate(b'<meta content="10.1007/s10853-016-9701-3') =='springer'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1039/') == 'rsc'
	assert candidate(b'not_a_publisher') is None
	assert candidate(b'<meta content="https://link.springer.com/article/10.1007/s10853-016-9701-3') =='springer'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S0022283615008847">') == 'elsevier'
	assert candidate(b'content="10.1039/') == 'rsc'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpcb.5b01350">') == 'acs'
	assert candidate(b'content="10.1039/C6TA04500A') == 'rsc'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpcb.6b09012">') == 'acs'
	assert candidate(b'<meta content="10.1007/s11367-017-4213-2') =='springer'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpcb.7b04495">') == 'acs'
	assert candidate(b'content="10.1039/c8cc05706h"') == 'rsc'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S0022519317303914') == 'elsevier'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S0021457X15002413">') == 'elsevier'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpcb.7b06881">') == 'acs'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S002236971830331X">') == 'elsevier'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S002196061300431X">') == 'elsevier'
	assert candidate(b'<meta content="10.1007/s10853-015-0225-z') =='springer', 'candidate springer test failed'
	assert candidate(b'<meta content="10.1007/s10854-018-0570-5" name="citation_doi">') =='springer'
	assert candidate(b'<meta content="10.1007/s10822-014-9749-6" name="citation_doi"/>') =='springer'
	assert candidate(b'<meta content="http://www.nature.com') is None
	assert candidate(b'<!-- This XML file does not appear to have any style information associated with it. The document tree is shown below. -->') is None
	assert candidate(b'<meta content="10.1039/c8cp04034h">') == 'rsc'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jctc.8b00280') == 'acs'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jctc.6b01274') == 'acs'
	assert candidate(b'<meta content="10.1007/s12021-014-9405-y" name="citation_doi"/>') =='springer'
	assert candidate(b'<meta content="https://link.springer.com/') =='springer'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpclett.7b00591">') == 'acs'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/science/article/pii/S1045401919301192">') == 'elsevier'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/') == 'acs'
	assert candidate(b'<meta content="https://link.springer.com/article/10.1007/s10454-019-09678-x">') =='springer'
	assert candidate(b'<meta name="citation_journal_title" content="Nature Communications">') is None
	assert candidate(b'<meta content="10.1039/C5CP04111B">') == 'rsc'
	assert candidate(b'<meta content="10.1007/s10529-015-1135-3') =='springer'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/acs.jpcb.6b12358">') == 'acs'
	assert candidate(b'<link rel="canonical" href="http://www.sciencedirect.com/') == 'elsevier'
	assert candidate(b'<meta content="10.1039/c3cp56967a" name="citation_doi"/>') == 'rsc'
	assert candidate(b'<meta name="dc.Identifier" scheme="doi" content="10.1021/ja900137s">') == 'acs'
	assert candidate(b'<meta content="https://www.nature.com') is None
	assert candidate(b'abc') == None
def test_check():
	check(detect_publisher)
