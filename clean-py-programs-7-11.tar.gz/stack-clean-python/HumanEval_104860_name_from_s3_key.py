def name_from_s3_key(key: str) -> str:
    """ Get the filename from the S3 key."""
	### Canonical solution below ###    
    return key.split("/")[-1]

### Unit tests below ###
def check(candidate):
	assert candidate(
    "2018-12-28/2018-12-28-13-24-18.2018-12-28-13-24-18-1545957858733.jpg") == \
    "2018-12-28-13-24-18.2018-12-28-13-24-18-1545957858733.jpg"
	assert candidate(
    "c464886c-77b8-4d7b-b36a-8716621c5560/s1/2019/07/01/00/00/00-00-00/0.0.0.0-0.0.0.0.pcap.gz"
) == "0.0.0.0-0.0.0.0.pcap.gz"
	assert candidate(
    "test_bucket/some_folder/some_file.txt") == "some_file.txt"
	assert candidate(
    "00001/00000000-0000-0000-0000-000000000000/00000000-0000-0000-0000-000000000000.txt"
) == "00000000-0000-0000-0000-000000000000.txt"
	assert candidate(
    "foo/bar/baz") == "baz"
	assert candidate(
    "my-prefix/2021-01-01/my-file-1.csv.gz"
) == "my-file-1.csv.gz"
	assert candidate(
    "s3://bucket/prefix/subprefix/filename.ext"
) == "filename.ext"
	assert candidate(
    "some/dir/file.ext"
) == "file.ext"
	assert candidate(key="test_data/1/2.txt") == "2.txt"
	assert candidate(
    "some/key/to/a/file.csv") == "file.csv"
	assert candidate(
    "census/ACS_17_5YR_DP05/ACS_17_5YR_DP05_with_ann.csv") == "ACS_17_5YR_DP05_with_ann.csv"
	assert candidate(
    "2020/12/12/12/00/00/2020-12-12T12:00:00.000000.json"
) == "2020-12-12T12:00:00.000000.json"
	assert candidate(
    "data/s3-to-dc-example/s3-to-dc-example.csv.bz2"
) == "s3-to-dc-example.csv.bz2"
	assert candidate(
    "test/test/test.txt"
) == "test.txt"
	assert candidate(key="data/my-folder/my-file.txt") == "my-file.txt"
	assert candidate(key="foo/bar/baz/") == ""
	assert candidate(
    "test-bucket/my-folder/my-file.txt"
) == "my-file.txt"
	assert candidate(key="data/2020-07-13-15-01-21.500000-000000000000.pcap") == "2020-07-13-15-01-21.500000-000000000000.pcap"
	assert candidate(
    "some/path/to/file.csv") == "file.csv"
	assert candidate(
    "data/s3-to-dc-example/s3-to-dc-example.csv.gz"
) == "s3-to-dc-example.csv.gz"
	assert candidate(
    "my-prefix/2021-01-01/my-file-1.csv.gz.enc"
) == "my-file-1.csv.gz.enc"
	assert candidate(key="foo/bar/baz/qux") == "qux"
	assert candidate(
    "data/s3-to-dc-example/s3-to-dc-example.csv"
) == "s3-to-dc-example.csv"
	assert candidate(key="test_data/1/2/3.txt") == "3.txt"
	assert candidate(
    "data/2020/03/22/2020-03-22T000000.json.gz.enc") == "2020-03-22T000000.json.gz.enc"
	assert candidate(
    "my/s3/key/myfile.txt"
) == "myfile.txt"
	assert candidate(
    "my-prefix/2021-01-01/my-file.csv"
) == "my-file.csv"
	assert candidate(
    "some/dir/file."
) == "file."
	assert candidate(
    "data/2020/03/22/2020-03-22T000000.json.enc") == "2020-03-22T000000.json.enc"
	assert candidate(
    "2020/06/28/2020-06-28T09:24:11.390292+00:00-00:00-00:00.json"
) == "2020-06-28T09:24:11.390292+00:00-00:00-00:00.json"
	assert candidate(
    "foo/bar/baz.tar.gz") == "baz.tar.gz"
	assert candidate(
    "prod/data/my-file.json"
) == "my-file.json"
	assert candidate(
    "data/2020/03/22/2020-03-22T000000.json.enc.gz") == "2020-03-22T000000.json.enc.gz"
	assert candidate(key="data/2020-07-13-15-01-21.500000-000000000000.pcap.gz.gz") == "2020-07-13-15-01-21.500000-000000000000.pcap.gz.gz"
	assert candidate(key="data/my-file.txt") == "my-file.txt"
	assert candidate(key="test_data/1.txt") == "1.txt"
	assert candidate(
    "foo/bar/baz.csv") == "baz.csv"
	assert candidate(
    "data/s3-to-dc-example/s3-to-dc-example.csv.zip/s3-to-dc-example.csv"
) == "s3-to-dc-example.csv"
	assert candidate(
    "data/2020/03/22/2020-03-22T000000.json") == "2020-03-22T000000.json"
	assert candidate(
    "foo/bar/baz.tar.gz/") == ""
	assert candidate(key="data/2020-07-13-15-01-21.500000-000000000000.pcap.gz") == "2020-07-13-15-01-21.500000-000000000000.pcap.gz"
	assert candidate(
    "some/dir/file"
) == "file"
	assert candidate(
    "data/2021-06-16-12-00-00/raw/00000000-0000-0000-0000-000000000000.jsonl"
) == "00000000-0000-0000-0000-000000000000.jsonl"
	assert candidate(
    "my-prefix/2021-01-01/my-file-1.csv"
) == "my-file-1.csv"
	assert candidate(key="foo/bar/baz") == "baz"
	assert candidate(key="foo/bar/baz/qux/") == ""
	assert candidate(
    "data/2020/03/22/2020-03-22T000000.json.gz") == "2020-03-22T000000.json.gz"
	assert candidate(
    "path/to/data/2020-01-01/2020-01-01-12345678-9abc-def0-1234-56789abcdef0.json"
) == "2020-01-01-12345678-9abc-def0-1234-56789abcdef0.json"
	assert candidate(
    "some/path/to/file.csv.gz") == "file.csv.gz"
	assert candidate(
    "baz") == "baz"
	assert candidate(
    "data/s3-to-dc-example/s3-to-dc-example.csv.zip"
) == "s3-to-dc-example.csv.zip"
def test_check():
	check(name_from_s3_key)
