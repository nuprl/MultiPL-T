def debug(text):
    """ Given a string, remove every single bug."""
	### Canonical solution below ###    
    res = text[:]
    bug_idx = [
        i for i in range(len(text)) if text.startswith('bug', i)
    ]
    bugs_idx = [
        i for i in range(len(text)) if text.startswith('bugs', i)
    ]
    if not bug_idx:
        return res
    if bug_idx and not bugs_idx:
        res = res.replace('bug', '')
        return res
    for idx in bugs_idx:
        bug_idx.remove(idx)
    if bug_idx:
        res = res[:bug_idx[0]] + res[bug_idx[0] + 3:]
        return debug(res)
    return res

### Unit tests below ###
def check(candidate):
	assert candidate("bugsbug") == "bugs", "Simple test"
	assert candidate('bugsbugs') == 'bugsbugs'
	assert candidate('There are 10 bugs in this code.') == 'There are 10 bugs in this code.'
	assert candidate(candidate('bugbugs')) == 'bugs'
	assert candidate(
    'There are many bugs in this code, but there are also many bugs in the tests.'
) == 'There are many bugs in this code, but there are also many bugs in the tests.'
	assert candidate(candidate('bugbugsbug')) == 'bugs'
	assert candidate(
    'buggys') == 'gys'
	assert candidate(
    'This sentence does not have any bugs') == 'This sentence does not have any bugs'
	assert candidate(
    'This sentence does not contain bugs.'
) == 'This sentence does not contain bugs.'
	assert candidate(
    'There are 10 bugs in this code.') == 'There are 10 bugs in this code.'
	assert candidate(
    'I am having a bug'
) == 'I am having a '
	assert candidate(
    'This is a bugs. This is a bugs. This is a bugs.'
) == 'This is a bugs. This is a bugs. This is a bugs.', 'No bugs.'
	assert candidate("bugs") == "bugs", "Simple test"
	assert candidate(candidate('bugs')) == 'bugs'
	assert candidate(
    "This sentence doesn't have any bugs, is it weird that it returns the same text? I don't think so."
) == "This sentence doesn't have any bugs, is it weird that it returns the same text? I don't think so."
def test_check():
	check(debug)
