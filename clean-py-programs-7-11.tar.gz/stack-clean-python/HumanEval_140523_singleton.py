def singleton(name: str) -> object:
	"""
	Factory function to return a string singleton.

	:param name: The name of the singleton.
	"""
    ### Canonical solution below ###

	name = str(name)

	class Singleton:
		_singleton = None

		def __new__(cls):
			if Singleton._singleton is None:
				Singleton._singleton = super().__new__(cls)
			return Singleton._singleton

		def __repr__(self) -> str:
			return name

		def __str__(self) -> str:
			return name

	Singleton.__name__ = name
	Singleton.__doc__ = f"Singleton {name}"
	return Singleton()


### Unit tests below ###
def check(candidate):
	assert candidate("test").__str__() == "test"
	assert candidate("hello") is not candidate("world")
	assert candidate(1).__str__() == candidate(1).__repr__()
	assert candidate(1).__class__._candidate.__doc__ == "Singleton 1"
	assert candidate("hello") is not candidate((1,))
	assert candidate(1)!= candidate("a")
	assert candidate(1)!= candidate(1.0)
	assert str(candidate("2")) == "2"
	assert candidate("a")!= candidate("b")
	assert candidate(1)!= candidate(2)
	assert candidate("hello") is not candidate({"hello": 1})
	assert candidate(1).__class__._candidate is not None
	assert candidate("test").__repr__() == 'test'
	assert candidate(1) is not candidate("2")
	assert candidate(1).__doc__ == "Singleton 1"
	assert str(candidate("1")) == "1"
	assert candidate(0) is not candidate(False)
	assert candidate(1)!= object()
	assert candidate("1") is not candidate("2")
	assert candidate(1)!= "1"
	assert str(candidate(1)) == str(candidate(1))
	assert candidate(1).__repr__() == "1"
	assert repr(candidate("1")) == "1"
	assert repr(candidate("2")) == "2"
	assert repr(candidate(1)) == "1"
	assert candidate(1)!= 1.0
	assert candidate(1)!= candidate("1")
	assert candidate(1).__str__() == candidate(1).__str__()
	assert candidate("1").__repr__() == "1"
	assert repr(candidate(2)) == "2"
	assert candidate(0) is not candidate(1)
	assert candidate("1").__class__.__name__ == "1"
	assert candidate("1") is not candidate(1)
	assert candidate("a") is not candidate("A")
	assert candidate("hello") is not candidate([1])
	assert candidate("hello") is not candidate(None)
	assert candidate(1).__str__() == '1'
	assert str(candidate(1)) == "1"
	assert candidate("1").__class__.__doc__ == "Singleton 1"
	assert candidate(1) is not candidate("1")
	assert candidate(1)!= candidate("hello")
	assert candidate(1)!= candidate("2")
	assert candidate("a") is not candidate("b")
	assert candidate(1)!= candidate(object())
	assert candidate("test").__str__() == 'test'
	assert candidate("1")!= candidate(1)
	assert candidate(1)!= candidate("one")
	assert candidate(1).__class__._candidate!= candidate("2")
	assert candidate(1).__class__._candidate.__str__() == "1"
	assert candidate(1).__class__.__doc__ == "Singleton 1"
	assert candidate(0) is not candidate(None)
	assert candidate(1).__class__._candidate!= candidate(2)
	assert candidate(1) is not candidate("one")
	assert candidate(0) is not candidate(0.0)
	assert candidate("hello") is not candidate(1)
	assert candidate("1").__str__() == "1"
	assert candidate(1).__str__() == "1"
	assert candidate("hello")!= candidate("world")
	assert candidate("1")!= candidate("2")
	assert str(candidate(2)) == "2"
	assert candidate(1)!= 1
	assert candidate("test").__repr__() == "test"
	assert candidate("test") is not candidate("test2")
	assert candidate(1) is not candidate(1)
	assert candidate("hello") is not candidate(1.0)
	assert candidate(1) is not candidate(2)
	assert candidate(1).__class__._candidate.__repr__() == "1"
	assert candidate(1).__class__._candidate.__class__.__doc__ == "Singleton 1"
	assert candidate(1)!= candidate(0)
	assert candidate(0) is not candidate("")
	assert candidate(1).__repr__() == '1'
	assert candidate(0) is not candidate("0")
	assert str(candidate(1))!= str(candidate(2))
def test_check():
	check(singleton)
