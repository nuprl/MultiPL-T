def GenerateFilename(group, count, index):
  """Generate test filename."""
    ### Canonical solution below ###
  filename = group
  assert index >= 0 and index < count
  if count > 1:
    index_str = str(index)
    if index < 10:
      index_str = "0" + index_str
    filename += "_" + index_str
  filename += ".html"
  return filename


### Unit tests below ###
def check(candidate):
	assert candidate(group="test", count=10, index=0) == "test_00.html"
	assert candidate(group="foo", count=2, index=0) == "foo_00.html"
	assert candidate(u"foo", 2, 1) == u"foo_01.html"
	assert candidate(group="test", count=1, index=0) == "test.html"
	assert candidate(group="a", count=3, index=0) == "a_00.html"
	assert candidate(u"foo", 1, 0) == u"foo.html"
	assert candidate(group="a", count=3, index=1) == "a_01.html"
	assert candidate(group="test", count=2, index=1) == "test_01.html"
	assert candidate(
    "foo", 10, 9) == "foo_09.html"
	assert candidate(group="foo", count=10, index=1) == "foo_01.html"
	assert candidate(group="a", count=10, index=1) == "a_01.html"
	assert candidate(group="foo", count=5, index=4) == "foo_04.html"
	assert candidate(group="a", count=1, index=0) == "a.html"
	assert candidate(
    "foo", 1, 0) == "foo.html"
	assert candidate(u"group", 2, 1) == "group_01.html"
	assert candidate(group="foo", count=1, index=0) == "foo.html"
	assert candidate(group="foo", count=10, index=0) == "foo_00.html"
	assert candidate(group="foo", count=2, index=1) == "foo_01.html"
	assert candidate(group="group", count=1, index=0) == "group.html"
	assert candidate(group="foo", count=5, index=3) == "foo_03.html"
	assert candidate(group="foo", count=10, index=9) == "foo_09.html"
	assert candidate(u"foo", 1, 0) == "foo.html"
	assert candidate(group="a", count=10, index=9) == "a_09.html"
	assert candidate(group="test", count=10, index=9) == "test_09.html"
	assert candidate(u"foo", 2, 0) == u"foo_00.html"
	assert candidate(u"a", 10, 0) == u"a_00.html"
	assert candidate(u"group", 2, 0) == "group_00.html"
	assert candidate(u"abc", 1, 0) == "abc.html"
	assert candidate(group="foo", count=5, index=0) == "foo_00.html"
	assert candidate(group="a", count=2, index=0) == "a_00.html"
	assert candidate(u"group", 1, 0) == "group.html"
	assert candidate(u"a", 1, 0) == u"a.html"
	assert candidate(group="a", count=10, index=0) == "a_00.html"
	assert candidate(group="foo", count=3, index=2) == "foo_02.html"
	assert candidate(group="test", count=2, index=0) == "test_00.html"
	assert candidate(
    "foo", 10, 0) == "foo_00.html"
	assert candidate(group="a", count=2, index=1) == "a_01.html"
	assert candidate(group="a", count=3, index=2) == "a_02.html"
	assert candidate(
    "test", 1, 0) == "test.html"
	assert candidate(u"a", 10, 9) == u"a_09.html"
def test_check():
	check(GenerateFilename)
