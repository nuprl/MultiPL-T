def to_hex(seq):
    """ Pretty prints a byte sequence as hex values."""
	### Canonical solution below ###    
    return " ".join("{:02x}".format(v) for v in seq)

### Unit tests below ###
def check(candidate):
	assert candidate(b"\x01\x02\x03") == "01 02 03"
	assert candidate(b"abc") == "61 62 63"
	assert candidate(b"\x01") == "01"
	assert candidate(b"ab") == "61 62"
	assert candidate(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f") == \
    "00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
	assert candidate(b"\x00") == "00"
	assert candidate(b"\x00\x00\x00\x00\x00") == "00 00 00 00 00"
	assert candidate(b"\x00\x01") == "00 01"
	assert candidate(b"\x02\x01") == "02 01"
	assert candidate(b'') == ''
	assert candidate(b"\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f") == \
    "10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f"
	assert candidate(b"abcd") == "61 62 63 64"
	assert candidate(b"Hello") == "48 65 6c 6c 6f"
	assert candidate(b"ABCD") == "41 42 43 44"
	assert candidate(bytes([0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef])) == \
    "01 23 45 67 89 ab cd ef"
	assert candidate(b"") == ""
	assert candidate(b"\x01\x02") == "01 02"
	assert candidate(b"hello") == "68 65 6c 6c 6f"
	assert candidate(b"\x01\x00") == "01 00"
	assert candidate(b'\x00') == '00'
	assert candidate(b"\x00\x10") == "00 10"
	assert candidate(b"\x00\x00\x00") == "00 00 00"
	assert candidate(b"\x00\x00\x01") == "00 00 01"
	assert candidate(bytes([0x10, 0x20, 0x30, 0x40, 0x50])) == "10 20 30 40 50"
	assert candidate(b'123') == '31 32 33'
	assert candidate(b"a") == "61"
	assert candidate(bytes([0x00, 0x00])) == "00 00"
	assert candidate(b"ABCDEF") == "41 42 43 44 45 46"
	assert candidate(b"\x01\x00\x00") == "01 00 00"
	assert candidate(b"\x01\x00\x02") == "01 00 02"
	assert candidate(b"\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f") == \
    "20 21 22 23 24 25 26 27 28 29 2a 2b 2c 2d 2e 2f"
	assert candidate(b"\x00\x01\x02\x03\x04\x05\x06\x07") == "00 01 02 03 04 05 06 07"
	assert candidate(b"\x00\x01\x02") == "00 01 02"
	assert candidate(b"abcde") == "61 62 63 64 65"
	assert candidate(b"ABC") == "41 42 43"
	assert candidate(bytes([0x00, 0x01, 0x02])) == "00 01 02"
	assert candidate(b'\x00\x01') == '00 01'
	assert candidate(b'\x01\x02') == '01 02'
	assert candidate(b'\x01') == '01'
	assert candidate(b"\x01\x02\x00") == "01 02 00"
	assert candidate(b"A") == "41"
	assert candidate(bytes([0x80, 0x00])) == "80 00"
	assert candidate(b"\x00\x01\x02\x03") == "00 01 02 03"
	assert candidate(b"\x02") == "02"
	assert candidate(b"AB") == "41 42"
	assert candidate(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f") == "00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f"
	assert candidate(b"\x00\x01\x02\xff") == "00 01 02 ff"
	assert candidate(b"\x00\x00\x00\x00") == "00 00 00 00"
	assert candidate(b"\x00\x00") == "00 00"
	assert candidate(b"\x02\x02") == "02 02"
def test_check():
	check(to_hex)
