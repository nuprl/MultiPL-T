def sumOfSquares(n):
    """ sumOfSquares
     
     Output the sum of the first n positive integers, where 
     n is provided by the user.
     
     passes:
     n:
     Output the sum of the first n positive integers, where 
     n is provided by the user.
     
     returns:
     Returns an array of the sum of the nth squared integers.
     """
	### Canonical solution below ###    
    sumVars = []
    for x in range(1,n+1):
        sumVars.append(x**2)
    return sumVars

### Unit tests below ###
def check(candidate):
	assert candidate(10) == [1, 4, 9, 16, 25, 36, 49, 64, 81, 100], "candidate(10) is incorrect."
	assert candidate(1) == [ 1 ]
	assert candidate(4) == [ 1, 4, 9, 16 ]
	assert candidate(1) == [1], "candidate(1) must be [1]"
	assert candidate(4) == [1, 4, 9, 16], "candidate(4) must be [1, 4, 9, 16]"
	assert candidate(1) == [1]
	assert candidate(3) == [ 1, 4, 9 ]
	assert candidate(5) == [1, 4, 9, 16, 25], "Should be [1, 4, 9, 16, 25]"
	assert candidate(10) == [1, 4, 9, 16, 25, 36, 49, 64, 81, 100], "should be [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]"
	assert candidate(-1) == []
	assert candidate(10) == [1, 4, 9, 16, 25, 36, 49, 64, 81, 100], "candidate(10) does not work"
	assert candidate(8) == [1, 4, 9, 16, 25, 36, 49, 64]
	assert candidate(20) == [1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400], "candidate(20) is incorrect."
	assert candidate(5) == [1, 4, 9, 16, 25], "candidate(5) does not work"
	assert candidate(4) == [1, 4, 9, 16], "should be [1, 4, 9, 16]"
	assert candidate(20) == [1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400]
	assert candidate(2) == [1, 4], "Should be [1, 4]"
	assert candidate(4) == [1, 4, 9, 16]
	assert candidate(10) == [ 1, 4, 9, 16, 25, 36, 49, 64, 81, 100 ]
	assert candidate(7) == [1, 4, 9, 16, 25, 36, 49]
	assert candidate(5) == [1, 4, 9, 16, 25]
	assert candidate(3) == [1, 4, 9], "should be [1, 4, 9]"
	assert candidate(2) == [1, 4], "should be [1, 4]"
	assert candidate(5) == [1, 4, 9, 16, 25], "candidate(5) is incorrect."
	assert candidate(2) == [ 1, 4 ]
	assert candidate(2) == [1, 4]
	assert candidate(3) == [1, 4, 9]
	assert candidate(2) == [1, 4], "candidate(2) must be [1, 4]"
	assert candidate(10) == [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
	assert candidate(3) == [1, 4, 9], "candidate(3) must be [1, 4, 9]"
	assert candidate(1) == [1], "should be [1]"
	assert candidate(5) == [ 1, 4, 9, 16, 25 ]
	assert candidate(0) == []
	assert candidate(3) == [1, 4, 9], "Should be [1, 4, 9]"
	assert candidate(9) == [1, 4, 9, 16, 25, 36, 49, 64, 81]
	assert candidate(6) == [1, 4, 9, 16, 25, 36]
	assert candidate(4) == [1, 4, 9, 16], "Should be [1, 4, 9, 16]"
	assert candidate(0) == [ ]
	assert candidate(1) == [1], "Should be [1]"
def test_check():
	check(sumOfSquares)
