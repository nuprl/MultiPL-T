def get_figsize(columnwidth=241.14749, wf=1.0, hf=(5. ** 0.5 - 1.0) / 2.0, b_fixed_height=False):
    """Parameters:
      - wf [float]:  width fraction in columnwidth units
      - hf [float]:  height fraction in columnwidth units.
                     Set by default to golden ratio.
      - columnwidth [float]: width of the column in latex (pt). Get this from LaTeX
                             using \showthe\columnwidth (or \the\columnwidth)
    Returns:  [fig_width,fig_height]: that should be given to matplotlib
    """
    ### Canonical solution below ###
    fig_width_pt = columnwidth*wf
    inches_per_pt = 1.0/72.27               # Convert pt to inch
    fig_width = fig_width_pt*inches_per_pt  # width in inches
    fig_height = fig_width*hf      # height in inches
    if b_fixed_height:
        fig_height = hf
    #print("fig_width", fig_width, "fig_height", fig_height)
    return [fig_width, fig_height]


### Unit tests below ###
def check(candidate):
	assert candidate(wf=0.5)[0] == candidate(wf=1.0)[0]/2.0
	assert candidate(wf=0.5, hf=0.5)[0] == candidate(wf=1.0, hf=0.5)[0]/2.0
	assert candidate(wf=0.5, hf=0.5)[1] == candidate(wf=1.0, hf=0.5)[1]/2.0
def test_check():
	check(get_figsize)
