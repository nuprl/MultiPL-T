def comparator(x, y):
    """
    Comparison between two memory values x = m' and y = m. We want to check whether x <= y
    """
    ### Canonical solution below ###
    parity_x = x % 2
    parity_y = y % 2

    if parity_x == 1:
        if parity_y == 1:
            return x <= y
        else:
            return False
    if parity_x == 0:
        if parity_y == 0:
            return x >= y
        else:
            return True


### Unit tests below ###
def check(candidate):
	assert candidate(17, 17) == True
	assert candidate(3, 1) == False
	assert candidate(1, 3)
	assert candidate(2, 1) == True
	assert candidate(8, 1) == True
	assert candidate(5, 7) == True
	assert not candidate(1, 0)
	assert candidate(9, 1) == False
	assert candidate(9, 9) == True
	assert candidate(13, 12) == False
	assert candidate(1, 3) == True
	assert candidate(10, 10) == True
	assert candidate(10, 9) == True
	assert candidate(13, 1) == False
	assert candidate(4, 1) == True
	assert candidate(9, 8) == False
	assert candidate(12, 11) == True
	assert not candidate(3, 2)
	assert candidate(2, 2)
	assert candidate(4, 4) == True
	assert candidate(5, 0) == False
	assert candidate(11, 11) == True
	assert candidate(11, 1) == False
	assert candidate(0, 0)
	assert candidate(6, 3) == True
	assert candidate(4, 2) == True
	assert candidate(1, 0) == False
	assert candidate(0, 0) == True
	assert candidate(9, 0) == False
	assert candidate(5, 4) == False
	assert candidate(7, 5) == False
	assert candidate(15, 1) == False
	assert candidate(4, 2)
	assert candidate(13, 0) == False
	assert candidate(4, 5) == True
	assert candidate(1, 2) == False
	assert candidate(16, 16) == True
	assert candidate(10, 5) == True
	assert candidate(14, 7) == True
	assert candidate(1, 1) == True
	assert candidate(3, 3)
	assert candidate(15, 15) == True
	assert candidate(7, 9) == True
	assert candidate(2, 2) is True
	assert candidate(7, 7) == True
	assert candidate(7, 6) == False
	assert candidate(2, 2) == True
	assert candidate(2, 1)
	assert candidate(7, 0) == False
	assert candidate(2, 3) == True
	assert candidate(7, 1) == False
	assert candidate(6, 6) == True
	assert candidate(5, 1) == False
	assert candidate(3, 0) == False
	assert candidate(3, 2) == False
	assert candidate(15, 0) == False
	assert candidate(3, 3) == True
	assert candidate(2, 4) == False
	assert candidate(13, 13) == True
	assert candidate(3, 5) == True
	assert candidate(9, 7) == False
	assert candidate(12, 12) == True
	assert candidate(0, 1) == True
	assert candidate(12, 1) == True
	assert candidate(14, 14) == True
	assert candidate(8, 8) == True
	assert candidate(1, 1) is True
	assert candidate(3, 2) is False
	assert candidate(5, 3) == False
	assert candidate(11, 0) == False
	assert candidate(8, 7) == True
	assert candidate(2, 0)
	assert candidate(2, 3) is True
	assert not candidate(0, 2)
	assert candidate(5, 5) == True
	assert candidate(11, 10) == False
	assert candidate(0, 1)
def test_check():
	check(comparator)
