def pred(true_r, est, u0=None):
    """Just a small tool to build a prediction with appropriate format."""
    ### Canonical solution below ###
    return (u0, None, true_r, est, None)


### Unit tests below ###
def check(candidate):
	assert candidate(0.5, 0.5) == (None, None, 0.5, 0.5, None)
	assert candidate(2, 3) == (None, None, 2, 3, None)
	assert candidate(1, 2, 3) == (3, None, 1, 2, None)
	assert candidate(1, 2, 10) == (10, None, 1, 2, None)
	assert candidate(0, 0) == (None, None, 0, 0, None)
	assert candidate(0.5, 0.5, u0=2.0) == (2.0, None, 0.5, 0.5, None)
	assert candidate(1, 1, u0=1) == (1, None, 1, 1, None)
	assert candidate(1, 1, 0) == (0, None, 1, 1, None)
	assert candidate(3, 4, 5) == (5, None, 3, 4, None)
	assert candidate(1.2, 3.4) == (None, None, 1.2, 3.4, None)
	assert candidate(1, 0) == (None, None, 1, 0, None)
	assert candidate(0, 0, 0) == (0, None, 0, 0, None)
	assert candidate(1, 1) == (None, None, 1, 1, None)
	assert candidate(1, 2) == (None, None, 1, 2, None)
	assert candidate(2, 3, 4) == (4, None, 2, 3, None)
	assert candidate(0, 0, 1) == (1, None, 0, 0, None)
	assert candidate(1, 0, 0) == (0, None, 1, 0, None)
	assert candidate(1, 1, 1) == (1, None, 1, 1, None)
	assert candidate(100, 100) == (None, None, 100, 100, None)
	assert candidate(3, 2, 1) == (1, None, 3, 2, None)
	assert candidate(100, 100, 100) == (100, None, 100, 100, None)
	assert candidate(2, 3, 1) == (1, None, 2, 3, None)
	assert candidate(1.2, 3.4, 5.6) == (5.6, None, 1.2, 3.4, None)
	assert candidate(3, 2) == (None, None, 3, 2, None)
	assert candidate(3, 4) == (None, None, 3, 4, None)
	assert candidate(1, 1, u0=2) == (2, None, 1, 1, None)
def test_check():
	check(pred)
