def _SubtractCpuStats(cpu_stats, start_cpu_stats):
    """ Computes average cpu usage over a time period for different process types.
     
     Each of the two cpu_stats arguments is a dict with the following format:
     {'Browser': {'CpuProcessTime': ..., 'TotalTime': ...},
     'Renderer': {'CpuProcessTime': ..., 'TotalTime': ...}
     'Gpu': {'CpuProcessTime': ..., 'TotalTime': ...}}
     
     The 'CpuProcessTime' fields represent the number of seconds of CPU time
     spent in each process, and total time is the number of real seconds
     that have passed (this may be a Unix timestamp).
     
     Returns:
     A dict of process type names (Browser, Renderer, etc.) to ratios of cpu
     time used to total time elapsed.
     """
	### Canonical solution below ###  
  cpu_usage = {}
  for process_type in cpu_stats:
    assert process_type in start_cpu_stats, 'Mismatching process types'
    # Skip any process_types that are empty.
    if (not cpu_stats[process_type]) or (not start_cpu_stats[process_type]):
      continue
    cpu_process_time = (cpu_stats[process_type]['CpuProcessTime'] -
                        start_cpu_stats[process_type]['CpuProcessTime'])
    total_time = (cpu_stats[process_type]['TotalTime'] -
                  start_cpu_stats[process_type]['TotalTime'])
    # Fix overflow for 32-bit jiffie counter, 64-bit counter will not overflow.
    # Linux kernel starts with a value close to an overflow, so correction is
    # necessary.
    if total_time < 0:
      total_time += 2**32
    # Assert that the arguments were given in the correct order.
    assert total_time > 0 and total_time < 2**31, (
        'Expected total_time > 0, was: %d' % total_time)
    cpu_usage[process_type] = float(cpu_process_time) / total_time
  return cpu_usage

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'Browser': {'CpuProcessTime': 100, 'TotalTime': 100},
     'Renderer': {'CpuProcessTime': 100, 'TotalTime': 100}},
    {'Browser': {'CpuProcessTime': 0, 'TotalTime': 0},
     'Renderer': {'CpuProcessTime': 0, 'TotalTime': 0}}) == {'Browser': 1.0,
                                                        'Renderer': 1.0}
	assert candidate(
    {'Browser': {'CpuProcessTime': 2, 'TotalTime': 4}},
    {'Browser': {'CpuProcessTime': 1, 'TotalTime': 2}}) == {'Browser': 0.5}
	assert candidate(
    {'Browser': {'CpuProcessTime': 1, 'TotalTime': 10},
     'Renderer': {'CpuProcessTime': 2, 'TotalTime': 10}},
    {'Browser': {'CpuProcessTime': 0, 'TotalTime': 0},
     'Renderer': {'CpuProcessTime': 0, 'TotalTime': 0}}) == {'Browser': 0.1,
                                                        'Renderer': 0.2}
	assert candidate(
    {'Browser': {'CpuProcessTime': 100, 'TotalTime': 100},
     'Renderer': {'CpuProcessTime': 100, 'TotalTime': 100}},
    {'Browser': {'CpuProcessTime': 50, 'TotalTime': 50},
     'Renderer': {'CpuProcessTime': 50, 'TotalTime': 50}}) == {'Browser': 1.0,
                                                        'Renderer': 1.0}
	assert candidate(
    {'Browser': {'CpuProcessTime': 10, 'TotalTime': 10},
     'Renderer': {'CpuProcessTime': 10, 'TotalTime': 10},
     'Gpu': {'CpuProcessTime': 10, 'TotalTime': 10}},
    {'Browser': {'CpuProcessTime': 0, 'TotalTime': 0},
     'Renderer': {'CpuProcessTime': 0, 'TotalTime': 0},
     'Gpu': {'CpuProcessTime': 0, 'TotalTime': 0}}) == {
    'Browser': 1.0, 'Renderer': 1.0, 'Gpu': 1.0}
	assert candidate(
    {'Browser': {'CpuProcessTime': 1, 'TotalTime': 2},
     'Renderer': {'CpuProcessTime': 1, 'TotalTime': 2}},
    {'Browser': {'CpuProcessTime': 0, 'TotalTime': 0},
     'Renderer': {'CpuProcessTime': 0, 'TotalTime': 0}}) == {
    'Browser': 0.5,
    'Renderer': 0.5}
	assert candidate(
    {'Browser': {'CpuProcessTime': 100, 'TotalTime': 100},
     'Renderer': {'CpuProcessTime': 200, 'TotalTime': 200},
     'Gpu': {'CpuProcessTime': 300, 'TotalTime': 300}},
    {'Browser': {'CpuProcessTime': 0, 'TotalTime': 0},
     'Renderer': {'CpuProcessTime': 0, 'TotalTime': 0},
     'Gpu': {'CpuProcessTime': 0, 'TotalTime': 0}}) == {
         'Browser': 1,
         'Renderer': 1,
         'Gpu': 1,
    }
def test_check():
	check(_SubtractCpuStats)
