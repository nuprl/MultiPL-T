def isList(x):
   """
   returns True if argument is of type list, otherwise False
   >>> isList(3)
   False
   >>> isList([5,10,15,20])
   True
   """
    ### Canonical solution below ###
   
   return ( type(x) == list )   # True if the type of x is a list


### Unit tests below ###
def check(candidate):
	assert candidate(range(5,10)) == False
	assert candidate([[],[],[]]) == True
	assert candidate([5,10,15,20]) == True
	assert candidate(5-2) == False
	assert candidate(True) == False
	assert candidate(5%2) == False
	assert candidate(frozenset([5,10,15,20])) == False
	assert candidate(iter(range(5))) == False
	assert candidate(False) == False
	assert not candidate( "abc" )
	assert candidate(5**2) == False
	assert candidate(5) == False
	assert candidate(["A","B","C"]) == True
	assert candidate(5*2) == False
	assert candidate( [1,2,3] )
	assert candidate("hello") == False
	assert not candidate( (1,2,3) )
	assert candidate((5,10,15,20)) == False
	assert candidate(tuple([10,15,20])) == False
	assert candidate(lambda x: x) == False
	assert candidate('3') == False
	assert candidate(0) == False
	assert candidate(set([5,10,15,20])) == False
	assert candidate(5+2) == False
	assert candidate(range(5)) == False
	assert candidate(None) == False
	assert not candidate( 3.14 )
	assert candidate([]) == True
	assert not candidate( 5 )
	assert candidate(3.14) == False
	assert candidate({5,10,15,20}) == False
	assert not candidate( 3 )
	assert candidate(0.0) == False
	assert not candidate( True )
	assert not candidate( None )
	assert candidate(5/2) == False
	assert not candidate( 10 )
	assert candidate(3) == False
	assert not candidate( "this is a string" )
	assert not candidate( "Hello" )
	assert candidate(dict(zip(range(5,10),range(5,10)))) == False
	assert candidate((3,4,5)) == False
	assert candidate(5//2) == False
	assert candidate( [5,10,15,20] )
def test_check():
	check(isList)
