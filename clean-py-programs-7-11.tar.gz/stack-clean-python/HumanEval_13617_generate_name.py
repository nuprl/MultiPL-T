def generate_name():
    """ 
     Generate test host name.
     
     Returns:
     str: name
     """
	### Canonical solution below ###    
    from uuid import uuid1
    return f'pytest_{str(uuid1())}'

### Unit tests below ###
def check(candidate):
	assert candidate()!= candidate()
	assert candidate()
	assert candidate(
)!= candidate(
), 'candidate() should generate different names'
	assert len(candidate()) == 43
	assert candidate().startswith('pytest_')
	assert candidate(
)!= candidate(
), 'candidate should generate a new name each time'
	assert candidate(
)!= candidate(), 'candidate() should always generate a unique name'
	assert candidate(
)!= candidate()
def test_check():
	check(generate_name)
