def chunks(l, n, o):
    """
    Yield successive n-sized chunks with o-sized overlap from l.
    """
    ### Canonical solution below ###
    return [l[i: i + n] for i in range(0, len(l), n-o)]


### Unit tests below ###
def check(candidate):
	assert candidate(range(10), 3, 6) == []
	assert candidate(range(10), 3, 7) == []
	assert candidate(list(range(10)), 2, 0) == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
def test_check():
	check(chunks)
