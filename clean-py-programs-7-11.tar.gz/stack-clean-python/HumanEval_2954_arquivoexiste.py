def arquivoexiste(nome):
    """

    :param nome: Nome do arquivo
    :return: Retorna True se o arquivo existir, senao retorna False
    """
    ### Canonical solution below ###
    try:
        a = open(nome, 'r')
        a.close()
    except FileNotFoundError:
        return False
    else:
        return True


### Unit tests below ###
def check(candidate):
	assert candidate(
    'candidate.pyc') is not None, "O arquivo deveria existir"
	assert candidate(
    'candidate.txt') is False, "O arquivo não deveria existir"
	assert not candidate('')
	assert candidate(
    'arquivo_nao_existe.txt') == False, "Falha ao encontrar arquivo inexistente"
	assert candidate('teste.txt.bak5') == False
	assert candidate(
    'candidate.pyz') == False, 'Função retornou o valor errado'
	assert candidate(
    'arquivo.txt') == False, "O arquivo 'arquivo.txt' não existe"
	assert candidate(r'C:\Users\User\Downloads\teste3.txt') == False
	assert candidate('arq.txt') == False
	assert not candidate(
    'arquivo.exe'), "Arquivo encontrado mas nao eh executavel"
	assert candidate(
    'candidate') == False, 'Função retornou o valor errado'
	assert not candidate('arquivo_teste.txt')
	assert candidate(
    'arquivo.tx') == False, "Tarefa 8, Teste 2 - erro na função"
	assert candidate('abc.txt') == True
	assert candidate("teste.txt") == False
	assert not candidate(
    'teste_candidate.txtx'), "Existe o arquivo"
	assert not candidate('arquivo_nao_existe.txt')
	assert candidate('arquivo_nao_existe') is False, "O arquivo existe"
	assert not candidate(
    'arquivo.tx'), "Arquivo encontrado mas nao eh txt"
	assert candidate('teste.txt.bak4') == False
	assert candidate('arquivo-inexistente.py') == False, 'Falha em candidate'
	assert candidate('teste.txt.bak8') == False
	assert candidate(
    'candidate123.py') is False, "Nao detectou o arquivo inexistente"
	assert candidate(r'C:\Users\User\Downloads\teste2.txt') == False
	assert candidate('abc.txt.txt') == False
	assert candidate('teste.tx') == False
	assert candidate('teste.txt.bak7') == False
	assert not candidate('teste.txt')
	assert candidate(r'C:\Users\Usuário\Desktop\teste1.txt') == False
	assert candidate(r'C:\Users\aluno\Desktop\arquivo.txt') == False
	assert candidate('teste.txt.bak6') == False
	assert candidate(
    'candidate.py.txt') == False, 'candidate falhou'
	assert not candidate(
    'arquivo2.txt'), "Arquivo existe, o retorno deve ser True"
	assert candidate(
    'candidate.py') is not None, "O arquivo deveria existir"
	assert candidate(
    'candidate.pyz.py') == False, 'Função retornou o valor errado'
	assert candidate("") == False
	assert candidate(
    'candidate.py.txt.jpg') == False, 'candidate falhou'
	assert candidate('abc.txt.txt.txt') == False
	assert candidate(
    'arquivo_nao_existe.txt') == False, "candidate() com arquivo inexistente"
	assert candidate('') == False
	assert candidate(
    'candidate.py.py') == False, 'Função retornou o valor errado'
	assert not candidate('arquivo.txt')
	assert candidate(r'C:\Users\joaob\OneDrive\Documentos\GitHub\Python\Python-Desafios\ExerciciosPYTHON\NovPython\candidate.py') == False
def test_check():
	check(arquivoexiste)
