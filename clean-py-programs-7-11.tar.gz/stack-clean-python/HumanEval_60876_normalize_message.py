def normalize_message(body):
    """ Normalize the message body to make it commit-worthy.
     
     Mostly this just means removing HTML comments, but also removes unwanted
     leading or trailing whitespace.
     
     Returns the normalized body.
     """
	### Canonical solution below ###    
    while "<!--" in body:
        body = body[: body.index("<!--")] + body[body.index("-->") + 3 :]
    return "\n\n" + body.strip()

### Unit tests below ###
def check(candidate):
	assert candidate(u"foo\nbar") == u"\n\nfoo\nbar"
	assert candidate(
    """
    <!-- This is a comment -->
    <h1>Hello!</h1>
    <!-- This is another comment -->
    """) == "\n\n<h1>Hello!</h1>"
	assert candidate(
    """Hello,

This is a test message.

Thanks,

Bob

<script>This is not a comment.</script>
"""
) == "\n\nHello,\n\nThis is a test message.\n\nThanks,\n\nBob\n\n<script>This is not a comment.</script>"
	assert candidate(
    """Hello,

This is a test message.

Thanks,

Bob

<div>This is not a comment.</div>
"""
) == "\n\nHello,\n\nThis is a test message.\n\nThanks,\n\nBob\n\n<div>This is not a comment.</div>"
	assert candidate(
    """
<!--
Hello,

This is a comment.
-->

Hello, world!
"""
) == "\n\nHello, world!"
	assert candidate(u"foo\n\nbar") == u"\n\nfoo\n\nbar"
	assert candidate(
    """
<!--
This is a comment
-->

Some more text
<!--
Another comment
-->
"""
) == "\n\nSome more text"
	assert candidate(u"foo <!-- bar --> baz <!-- qux --> bif") == u"\n\nfoo  baz  bif"
	assert candidate(
    """
<!--
This is a comment
-->

Some more text
"""
) == "\n\nSome more text"
	assert candidate(u"foo <!-- bar --> baz") == u"\n\nfoo  baz"
	assert candidate(
    """Hello,

This is a test message.

Thanks,

Bob

<!-- this is a comment --><!-- this is another comment -->
"""
) == "\n\nHello,\n\nThis is a test message.\n\nThanks,\n\nBob"
	assert candidate(
    """Hello,

This is a test message.

Thanks,

Bob

<style>This is not a comment.</style>
"""
) == "\n\nHello,\n\nThis is a test message.\n\nThanks,\n\nBob\n\n<style>This is not a comment.</style>"
	assert candidate("") == "\n\n"
	assert candidate(
    """
<!--
Hello,

This is a comment.
-->

<script>

console.log("Hello, world!");

</script>
"""
) == "\n\n<script>\n\nconsole.log(\"Hello, world!\");\n\n</script>"
	assert candidate(
    """Hello,

This is a test message.

Thanks,

Bob

<!-- this is a comment -->
"""
) == "\n\nHello,\n\nThis is a test message.\n\nThanks,\n\nBob"
def test_check():
	check(normalize_message)
