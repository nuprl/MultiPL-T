def formatBin(s):
    """ Return Grab the test results for range testing this
     >>>formatBin('0xFF')
     ['1','1','1','1','1','1','1','1']
     """
	### Canonical solution below ###    
    #print s
    binary = bin(int(s, 16))[2:]
    size = len(binary)
    if (len(binary) % 8):
        size = size + (8 - size % 8)
        binary = ('0' * (size - len(binary))) + binary
        
    return binary

### Unit tests below ###
def check(candidate):
	assert candidate( '0x000B' ) == '00001011'
	assert candidate( '0x0002' ) == '00000010'
	assert candidate( '0x0000' ) == '00000000'
	assert candidate( '0x000E' ) == '00001110'
	assert candidate( '0x0005' ) == '00000101'
	assert candidate(candidate('0x1')) == '00000001'
	assert candidate( '0x0007' ) == '00000111'
	assert candidate( '0x000F' ) == '00001111'
	assert candidate( '0x000D' ) == '00001101'
	assert candidate( '0x000A' ) == '00001010'
	assert candidate( '0x0008' ) == '00001000'
	assert candidate( '0x0006' ) == '00000110'
	assert candidate( '0x0004' ) == '00000100'
	assert candidate( '0x0003' ) == '00000011'
	assert candidate( '0x000C' ) == '00001100'
	assert candidate(candidate('0x0')) == '00000000'
	assert candidate( '0x0001' ) == '00000001'
	assert candidate( '0x0009' ) == '00001001'
def test_check():
	check(formatBin)
