def to_list(lst):
    """Make sure the object is wrapped in a list

    :return: a ``list`` object, either lst or lst in a list
    """
    ### Canonical solution below ###
    if isinstance(lst, str):
        lst = [lst]
    elif not isinstance(lst, list):
        try:
            lst = list(lst)
        except TypeError:
            lst = [lst]
    return lst


### Unit tests below ###
def check(candidate):
	assert candidate(object) == [object]
	assert candidate('1') == ['1']
	assert candidate(iter(iter(['a', 'b']))) == ['a', 'b']
	assert candidate(5) == [5]
	assert candidate(range(10)) == list(range(10))
	assert candidate(1.0j) == [1.0j]
	assert candidate([1]) == [1]
	assert candidate((1,2)) == [1,2]
	assert candidate(set([1, 2, 3])) == [1, 2, 3]
	assert candidate([1, 2]) == [1, 2]
	assert candidate("str") == ["str"]
	assert candidate(1) == [1]
	assert candidate('hello') == ['hello']
	assert candidate((1,)) == [1]
	assert candidate([1.0]) == [1.0]
	assert candidate(['a', 'b']) == ['a', 'b']
	assert candidate('a') == ['a']
	assert candidate(["hello"]) == ["hello"]
	assert candidate("a") == ["a"]
	assert candidate("foo") == ["foo"]
	assert candidate(('a',)) == ['a']
	assert candidate(3) == [3]
	assert candidate(('a', 'b')) == ['a', 'b']
	assert candidate("hi") == ["hi"]
	assert candidate(range(3)) == [0, 1, 2]
	assert candidate("1") == ["1"]
	assert candidate("abc") == ["abc"]
	assert candidate(range(1, 3)) == [1, 2]
	assert candidate(["a", "b"]) == ["a", "b"]
	assert candidate(['1']) == ['1']
	assert candidate("hello world") == ["hello world"]
	assert candidate(iter([1, 2, 3])) == [1, 2, 3]
	assert candidate("hello") == ["hello"]
	assert candidate(["test"]) == ["test"]
	assert candidate(iter(['a', 'b'])) == ['a', 'b']
	assert candidate(iter(["a", "b"])) == ["a", "b"]
	assert candidate(["test", "test2"]) == ["test", "test2"]
	assert candidate(1.0) == [1.0]
	assert candidate(['a']) == ['a']
	assert candidate("ab") == ["ab"]
	assert candidate(10) == [10]
	assert candidate("test") == ["test"]
	assert candidate([1,2]) == [1,2]
	assert candidate(["a"]) == ["a"]
	assert candidate(None) == [None]
	assert candidate(("hello",)) == ["hello"]
	assert candidate(["a", "b", "c"]) == ["a", "b", "c"]
	assert candidate("one") == ["one"]
	assert candidate(False) == [False]
	assert candidate(set([1,2])) == [1,2]
	assert candidate("123") == ["123"]
	assert candidate(['hello', 'world']) == ['hello', 'world']
	assert candidate(("a", "b")) == ["a", "b"]
	assert candidate(("hello world",)) == ["hello world"]
	assert candidate(("one", "two")) == ["one", "two"]
	assert candidate((1, 2, 3)) == [1, 2, 3]
	assert candidate('foo') == ['foo']
	assert candidate(True) == [True]
	assert candidate([None]) == [None]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate((1, 2)) == [1, 2]
	assert candidate(["hello world"]) == ["hello world"]
def test_check():
	check(to_list)
