def dist_mapper(dist, package):
    """ 
     Add download_url from source tag, if present. Typically only present in
     composer.lock
     """
	### Canonical solution below ###    
    url = dist.get('url')
    if not url:
        return package
    package.download_url = url
    return package

### Unit tests below ###
def check(candidate):
	assert candidate(dict(), dict()) == dict()
	assert candidate(
    {},
    {'name': 'foo','version': '1.2.3'}
) == {
    'name': 'foo',
   'version': '1.2.3',
}
	assert candidate(
    {
        'type': 'library',
        'name': 'foo',
       'version': '1.2.3.4',
    },
    {'name': 'foo','version': '1.2.3.4'},
) == {
    'name': 'foo',
   'version': '1.2.3.4',
}
def test_check():
	check(dist_mapper)
