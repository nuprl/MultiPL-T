def _build_param_string(param):
    """ Builds param docstring from the param dict
     
     :param param: data to create docstring from
     :type param: dict
     :returns: string giving meta info
     
     Example: ::
     status (string) : Statuses to be considered for filter
     from_date (string) : Start date filter"
     """
	### Canonical solution below ###    
    string = "\t" + param.get("name")
    type_ = param.get('$ref') or param.get('format') or param.get('type')
    if type_:
        string += (" (%s) " % type_)
    if param.get('description'):
        string += ": " + param["description"]
    return string + "\n"

### Unit tests below ###
def check(candidate):
	assert candidate(
    {"name": "limit", "type": "integer", "description": "Max number of records to return"}) == \
    "\tlimit (integer) : Max number of records to return\n"
	assert candidate(
    {
        "name": "status",
        "type": "string",
        "description": "Statuses to be considered for filter"
    }) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name':'sort', 'description': 'Comma-separated list of fields to sort by', 'type':'string'}) == \
    "\tsort (string) : Comma-separated list of fields to sort by\n"
	assert candidate(
    {'name': 'from_date', 'format': 'date', 'description': 'Start date filter'}) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {"name": "offset", "type": "integer", "description": "Offset from the start of the list"}) == \
    "\toffset (integer) : Offset from the start of the list\n"
	assert candidate(dict(name="status", type="string", description="Statuses to be considered for filter",
                                format="date")) == "\tstatus (date) : Statuses to be considered for filter\n"
	assert candidate(
    {"name": "from_date", "type": "date", "description": "Start date filter"}
) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {'name': 'from_date', 'format':'string', 'description': 'Start date filter'}) == \
    "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name': 'to_date', 'type':'string', 'description': 'End date filter'}) == "\tto_date (string) : End date filter\n"
	assert candidate(
    {"name": "status", "type": "string", "description": "Statuses to be considered for filter"}) == \
    "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name': 'from_date', 'type':'string', 'description': 'Start date filter'}
) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name': 'from_date', 'description': 'Start date filter', 'type':'string'}) == '\tfrom_date (string) : Start date filter\n'
	assert candidate(
    {'description': 'Statuses to be considered for filter',
     'format': None,
     'name':'status',
    'required': True,
     'type':'string'}) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(dict(name="status", type="string", description="Statuses to be considered for filter")) == \
    "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name': 'from_date',
     'description': 'Start date filter',
     'format': 'date'}) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {"name": "sort", "type": "string", "description": "Field to sort by"}) == \
    "\tsort (string) : Field to sort by\n"
	assert candidate(
    {'name': 'from_date', 'type':'string', 'description': 'Start date filter'}) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {"name": "status", "$ref": "string", "description": "Statuses to be considered for filter"}
) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {"name": "from_date", "type": "string", "description": "Start date filter"}) == \
    "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name':'status', 'description': 'Statuses to be considered for filter', 'type':'string', 'format':'string'}) == '\tstatus (string) : Statuses to be considered for filter\n'
	assert candidate(
    {"name": "from_date", "type": "string", "description": "Start date filter"}
) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {
        "name": "from_date",
        "type": "string",
        "description": "Start date filter"
    }) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name':'status', '$ref':'string', 'description': 'Statuses to be considered for filter'}) == \
    "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name': 'page_size', 'description': 'Page size', 'type': 'integer'}) == \
    "\tpage_size (integer) : Page size\n"
	assert candidate(
    {"name": "filter", "type": "string", "description": "Filter of records"}) == "\tfilter (string) : Filter of records\n"
	assert candidate(
    {'name': 'from_date', 'description': 'Start date filter', 'format':'string'}) == '\tfrom_date (string) : Start date filter\n'
	assert candidate(
    {
        "name": "status",
        "type": "string",
        "description": "Statuses to be considered for filter"
    }
) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name':'status', '$ref':'string', 'description': 'Statuses to be considered for filter'}) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {"name": "from_date", "type": "string", "description": "Start date filter"}) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name':'status', '$ref':'string', 'description': 'Statuses to be considered for filter'}) == '\tstatus (string) : Statuses to be considered for filter\n'
	assert candidate(
    {'name': 'from_date', 'type':'string', 'description': 'Start date filter','required': True}) == \
    "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name': 'to_date', 'type':'string', 'description': 'End date filter'}
) == "\tto_date (string) : End date filter\n"
	assert candidate(
    {'name':'status', 'type':'string', 'description': 'Statuses to be considered for filter'}) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name':'status', '$ref':'string', 'description': 'Statuses to be considered for filter'}
) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name': 'id', 'description': 'Comma-separated list of ids', 'type':'string'}) == \
    "\tid (string) : Comma-separated list of ids\n"
	assert candidate(
    {
        "name": "from_date",
        "format": "date",
        "description": "Start date filter"
    }) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {'name': 'from_date',
     'description': 'Start date filter',
     'type':'string'}) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {
        "name": "status",
        "in": "query",
        "required": True,
        "type": "string",
        "description": "Statuses to be considered for filter"
    }
) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {"name": "limit", "type": "int", "description": "Limit of records"}) == "\tlimit (int) : Limit of records\n"
	assert candidate(
    {'name':'status', 'description': 'Statuses to be considered for filter', 'format':'string'}) == '\tstatus (string) : Statuses to be considered for filter\n'
	assert candidate(
    {"name": "offset", "type": "integer", "description": "Offset from beginning of results"}) == \
    "\toffset (integer) : Offset from beginning of results\n"
	assert candidate(
    {'name':'status', 'type':'string', 'description': 'Statuses to be considered for filter'}
) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name': 'from_date', 'type': 'date', 'description': 'Start date filter'}) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {"name": "order", "type": "string", "description": "Order of records"}) == "\torder (string) : Order of records\n"
	assert candidate(
    {
        "name": "from_date",
        "in": "query",
        "required": False,
        "type": "string",
        "description": "Start date filter"
    }
) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name':'sort', 'type':'string', 'description': 'Sorting criteria in the format: property,asc/desc. Default sort order is ascending. Multiple sort criteria are supported and must be separated with a comma.'}) == "\tsort (string) : Sorting criteria in the format: property,asc/desc. Default sort order is ascending. Multiple sort criteria are supported and must be separated with a comma.\n"
	assert candidate(
    {'name':'status',
     'description': 'Statuses to be considered for filter',
     'type':'string'}) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {"name": "from_date", "format": "date", "description": "Start date filter"}) == \
    "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {'name': 'from_date', 'format': 'date', 'description': 'Start date filter'}
) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {'name': 'from_date', 'description': 'Start date filter', 'type':'string'}) == \
    "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {'name':'status', 'description': 'Statuses to be considered for filter', 'type':'string'}) == \
    "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {"name": "from_date", "type": "date"}
) == "\tfrom_date (date) \n"
	assert candidate(
    {"name": "offset", "type": "int", "description": "Offset of records"}) == "\toffset (int) : Offset of records\n"
	assert candidate(
    {'name': 'from_date', 'type':'string', 'description': 'Start date filter'}) == \
    "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {
        "name": "from_date",
        "format": "date",
        "description": "Start date filter"
    }
) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {'name':'status', 'description': 'Statuses to be considered for filter', 'type':'string', 'format':'string', '$ref':'string', 'default':'string'}) == '\tstatus (string) : Statuses to be considered for filter\n'
	assert candidate(
    {'name':'status', 'description': 'Statuses to be considered for filter', 'type':'string', 'format':'string', '$ref':'string'}) == '\tstatus (string) : Statuses to be considered for filter\n'
	assert candidate(
    {"name": "limit", "type": "integer", "description": "Number of items to return"}) == \
    "\tlimit (integer) : Number of items to return\n"
	assert candidate(
    {'name': 'limit', 'format': 'int32', 'description': 'Number of items to return'}) == "\tlimit (int32) : Number of items to return\n"
	assert candidate(
    {
        "name": "from_date",
        "type": "array",
        "description": "Start date filter"
    }) == "\tfrom_date (array) : Start date filter\n"
	assert candidate(
    {'name':'status', 'description': 'Statuses to be considered for filter', 'type':'string'}) == '\tstatus (string) : Statuses to be considered for filter\n'
	assert candidate(
    {"name": "from_date", "type": "string", "description": "Start date filter", "required": True}) == "\tfrom_date (string) : Start date filter\n"
	assert candidate(
    {"name": "status", "type": "string", "description": "Statuses to be considered for filter"}
) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {'name': 'page', 'description': 'Page number', 'type': 'integer'}) == \
    "\tpage (integer) : Page number\n"
	assert candidate(
    {"name": "status", "type": "string", "description": "Statuses to be considered for filter"}) == "\tstatus (string) : Statuses to be considered for filter\n"
	assert candidate(
    {"name": "q", "type": "string", "description": "Query of records"}) == "\tq (string) : Query of records\n"
	assert candidate(
    {"name": "from_date", "format": "date", "description": "Start date filter"}
) == "\tfrom_date (date) : Start date filter\n"
	assert candidate(
    {'name': 'user_id', 'description': 'Comma-separated list of user ids', 'type':'string'}) == \
    "\tuser_id (string) : Comma-separated list of user ids\n"
	assert candidate(
    {'name':'status', 'description': 'Statuses to be considered for filter', '$ref':'string'}) == '\tstatus (string) : Statuses to be considered for filter\n'
	assert candidate(
    {'name':'status', '$ref':'status', 'description': 'Statuses to be considered for filter'}
) == "\tstatus (status) : Statuses to be considered for filter\n"
def test_check():
	check(_build_param_string)
