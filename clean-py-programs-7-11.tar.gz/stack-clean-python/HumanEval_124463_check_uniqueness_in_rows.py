def check_uniqueness_in_rows(board: list):
    """
    Check buildings of unique height in each row.

    Return True if buildings in a row have unique length, False otherwise.

    >>> check_uniqueness_in_rows(\
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***'])
    True
    >>> check_uniqueness_in_rows(\
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***'])
    False
    >>> check_uniqueness_in_rows(\
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***'])
    False
    """
    ### Canonical solution below ###
    for i in board:
        if i[0] != '*':
            for k in i:
                if k != '*':
                    if i[1:].count(k) > 1:
                        return False
        if i[0] == '*':
            for k in i:
                if k != '*':
                    if i[:-1].count(k) > 1:
                        return False
    return True


### Unit tests below ###
def check(candidate):
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows #2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows #3"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test 2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == True, "Uniqueness in rows test 1"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "First"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows #1"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Second"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == True, "Uniqueness in rows #1"
	assert candidate( \
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows #3"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test"
	assert candidate( \
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == True, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows test 2"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Third"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) == False, "Uniqueness in rows test 3"
	assert candidate(
    ['***21**', '412453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is True, "Uniqueness in rows test 1"
	assert candidate(
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test 3"
	assert candidate( \
    ['***21**', '412453*', '423145*', '*553215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows test"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows"
	assert candidate(
    ['***21**', '452453*', '423145*', '*543215', '*35214*', '*41532*', '*2*1***']) is False, "Uniqueness in rows #2"
def test_check():
	check(check_uniqueness_in_rows)
