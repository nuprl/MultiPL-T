def get_reynolds_number(pore_diameter, uy, porosity, rho, viscosity):
    """
    Calculate the model's reynolds number after simulation
    based off of mean velocity and mean fluid density

    Parameters:
    ----------
    :param float pore_diameter:
        calculated lb pore diameter
    :param float uy:
        lb mean fluid velocity in y direction
    :param float porosity:
        porosity of the medium
    :param float rho:
        lb mean fluid density
    :param float viscosity:
        lb fluid viscosity

    Returns:
    -------
    :returns: Simulation Reynolds number
    """
    ### Canonical solution below ###
    reynolds = (pore_diameter * abs(uy) * porosity * rho) / viscosity
    return reynolds


### Unit tests below ###
def check(candidate):
	assert candidate(2, 1, 1, 1, 1) == 2
	assert candidate(0, 0.000123456, 0.5, 1.23456, 1.23456) == 0, "Unit test failed: candidate"
	assert candidate(1, 1, 1, 1, 1) == 1
	assert candidate(pore_diameter=1.0, uy=0.0, porosity=0.5, rho=1000.0, viscosity=1.0) == 0.0
	assert candidate(0, 1, 1, 1, 1) == 0
	assert candidate(1, 1, 1, 1, 1) == 1.0
	assert candidate(0, 0, 0, 0, 1) == 0
	assert candidate(0.000123456, 0.000123456, 0.5, 0, 1.23456) == 0, "Unit test failed: candidate"
	assert candidate(1, 1, 0, 1, 1) == 0
	assert candidate(1.0, 1.0, 1.0, 0.0, 1.0) == 0.0
	assert candidate(1, 1, 1, 1, 2) == 0.5
	assert candidate(pore_diameter=1.0, uy=0.0, porosity=0.5, rho=1.0, viscosity=0.1) == 0.0
	assert candidate(2, 1, 1, 1, 2) == 1
	assert candidate(pore_diameter=1.0, uy=0.0, porosity=0.5, rho=10.0, viscosity=1.0) == 0.0
	assert candidate(1.0, 1.0, 1.0, 1.0, 1.0) == 1.0
	assert candidate(1, 0, 1, 0, 1) == 0
	assert candidate(1, 2, 1, 1, 1) == 2.0
	assert candidate(0.25, 1, 0.5, 1, 1) == 0.125
	assert candidate(pore_diameter=1.0, uy=0.0, porosity=0.5, rho=1.0, viscosity=0.5) == 0.0
	assert candidate(1.0, 1.0, 1.0, 1.0, 1.0) == 1.0, 'Reynolds number calculation is incorrect.'
	assert candidate(10, 1, 1, 1, 1) == 10
	assert candidate(0, 1, 1, 0, 1) == 0
	assert candidate(pore_diameter=1.0, uy=0.0, porosity=0.5, rho=1.0, viscosity=10.0) == 0.0
	assert candidate(3, 1, 1, 1, 1) == 3.0
	assert candidate(1, 0, 1, 1, 1) == 0
	assert candidate(3, 2, 1, 1, 1) == 6.0
	assert candidate(pore_diameter=1.0, uy=0.0, porosity=0.5, rho=1.0, viscosity=1.0) == 0.0
	assert candidate(2, 1, 1, 1, 1) == 2.0
	assert candidate(2, 2, 1, 1, 1) == 4.0
	assert candidate(-1, 1, 1, 1, 1) == -1
	assert candidate(0.25, -1, 1, 1, 1) == 0.25
	assert candidate(1, 1, 0, 0, 1) == 0
	assert candidate(0.25, 1, 1, 1, 1) == 0.25
	assert candidate(1, 1, 1, 0, 1) == 0
	assert candidate(1.0, 1.0, 0.0, 1.0, 1.0) == 0.0
	assert candidate(1.0, 2.0, 1.0, 1.0, 1.0) == 2.0
	assert candidate(0.25, -1, 0.5, 1, 1) == 0.125
def test_check():
	check(get_reynolds_number)
