def zcount(list) -> float:
    """ 
     returns the number of elements in a list
     :param list: list of elements
     :return: int representing number of elements in given list
     """
	### Canonical solution below ###    
    c = 0
    for _ in list:
        c += 1
    return c

### Unit tests below ###
def check(candidate):
	assert candidate(["a", "b", "c", "d"]) == 4
	assert candidate(list('hello')) == 5
	assert candidate([3, 4, 5, 6]) == 4
	assert candidate( [2, 4, 6, 8] ) == 4
	assert candidate(list(range(1, 10, 2))) == 5
	assert candidate([1, 3, 5, 7, 9]) == 5
	assert candidate(list("1234567890")) == 10
	assert candidate(list(range(10))) == 10
	assert candidate(list()) == 0
	assert candidate(list("abcdefghijklmnopqrstuvwxyz")) == 26
	assert candidate(['a', 'b', 'c', 'd', 'e']) == 5
	assert candidate( [ ] ) == 0
	assert candidate(list('')) == 0
	assert candidate(list(range(5, 10))) == 5
	assert candidate(list("a")) == 1
	assert candidate([]) == 0
	assert candidate( [] ) == 0
	assert candidate(list("hello")) == 5
	assert candidate(list("goodbye")) == 7
	assert candidate(list(range(100))) == 100
	assert candidate([0, 1, 2, 3, 4]) == 5
	assert candidate([1]) == 1
	assert candidate([-1.0, -2.0, -3.0, -4.0, -5.0]) == 5
	assert candidate([1, 2, 3]) == 3
	assert candidate([-1, -2, -3, -4, -5]) == 5
	assert candidate(["a", "b", "c", "d", "e"]) == 5
	assert candidate( [1,2,3,4] ) == 4
	assert candidate(['a', 'b', 'c']) == 3
	assert candidate(list(range(1, 5))) == 4
	assert candidate(list("")) == 0
	assert candidate( [23.4, 67.8, 90.0, 12.4, 56.7] ) == 5
	assert candidate([1, 1, 1, 1, 1]) == 5
	assert candidate(list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])) == 10
	assert candidate([1, 2, 3, 4, 5]) == 5
	assert candidate([]) == 0, "candidate([]) should return 0"
def test_check():
	check(zcount)
