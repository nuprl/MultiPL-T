def set_placeholder(termtype):
    """ Sets input placeholder based on the radio buttons selected"""
    ### Canonical solution below ###
    placeholder = 'E.g. search: "machine learning, deep learning"' if termtype == 'Noun phrases'\
            else 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>' \
            if termtype == 'Entity mentions' else 'E.g. deep learning (one phrase only)'
    return placeholder


### Unit tests below ###
def check(candidate):
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"',\
       'candidate did not return correct placeholder for Noun phrases'
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', "Test 1 for candidate failed"
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>','candidate function error'
	assert candidate(termtype='Single phrase') == 'E.g. deep learning (one phrase only)',\
       'candidate did not return correct placeholder for Single phrase'
	assert candidate(termtype='Keyword') == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype='Single phrases') == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype="Single phrase") == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', \
        'Incorrect placeholder for entity mentions'
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', \
    "Noun phrases placeholder is not correct"
	assert candidate(termtype='Noun phrase') == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', "Test 2 for candidate failed"
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', 'Incorrect placeholder'
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', 'Noun phrases placeholder not set correctly'
	assert candidate(termtype='Phrase') == 'E.g. deep learning (one phrase only)',\
        'Incorrect placeholder for Phrase'
	assert candidate(termtype = 'Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', "Test 2 failed"
	assert candidate(termtype="Noun phrases") == 'E.g. search: "machine learning, deep learning"'
	assert candidate(termtype='Keyword') == 'E.g. deep learning (one phrase only)', 'Error in Keyword'
	assert candidate(termtype="Entity mentions") == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>'
	assert candidate(termtype='Single phrase') == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"',\
        'Incorrect placeholder for Noun phrases'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', 'Incorrect placeholder'
	assert candidate(termtype='One phrase') == 'E.g. deep learning (one phrase only)','candidate function error'
	assert candidate(termtype = 'Noun phrases') == 'E.g. search: "machine learning, deep learning"',\
    "Error: Noun phrases placeholder is not correct"
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>',\
'Incorrect placeholder for "Entity mentions"'
	assert candidate('Noun phrases') == 'E.g. search: "machine learning, deep learning"'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>',\
       'candidate did not return correct placeholder for Entity mentions'
	assert candidate(termtype='Single phrase') == 'E.g. deep learning (one phrase only)', \
    "Single phrase placeholder is not correct"
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', "Test 1 failed"
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', \
        'Incorrect placeholder for noun phrases'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>',\
        'Incorrect placeholder for Entity mentions'
	assert candidate(termtype='Single phrase') == 'E.g. deep learning (one phrase only)', 'Incorrect placeholder'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', 'Entity mentions placeholder not set correctly'
	assert candidate(termtype='Phrase mentions') == 'E.g. deep learning (one phrase only)', "Test 3 failed"
	assert candidate(termtype = 'Phrase mentions') == 'E.g. deep learning (one phrase only)', "candidate function did not return the correct placeholder for phrase mentions"
	assert candidate(termtype='Single phrase') == 'E.g. deep learning (one phrase only)',\
'Incorrect placeholder for "Single phrase"'
	assert candidate(termtype = 'Noun phrases') == 'E.g. search: "machine learning, deep learning"'
	assert candidate(termtype='Phrases') == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype='Specific phrase') == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"',\
'Incorrect placeholder for "Noun phrases"'
	assert candidate(termtype='Single term') == 'E.g. deep learning (one phrase only)', \
        'Incorrect placeholder for single term'
	assert candidate('Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>'
	assert candidate(termtype = 'Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', "candidate function did not return the correct placeholder for entity mentions"
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', "The placeholder should be 'E.g. search: \"machine learning, deep learning\"'"
	assert candidate(termtype = 'Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>',\
    "Error: Entity mentions placeholder is not correct"
	assert candidate(termtype = 'Single term') == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype = 'Single phrase') == 'E.g. deep learning (one phrase only)',\
    "Error: Single phrase placeholder is not correct"
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', 'Error in Entity mentions'
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', "The placeholder should be 'E.g. search: \"machine learning, deep learning\": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>'"
	assert candidate(termtype="Phrases") == 'E.g. deep learning (one phrase only)'
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"', 'Error in Noun phrases'
	assert candidate(termtype='Phrases') == 'E.g. deep learning (one phrase only)', 'Phrases placeholder not set correctly'
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"'
	assert candidate(termtype='Single phrase') == 'E.g. deep learning (one phrase only)', "Test 3 for candidate failed"
	assert candidate(termtype = 'Noun phrases') == 'E.g. search: "machine learning, deep learning"', "candidate function did not return the correct placeholder for noun phrases"
	assert candidate(termtype='Noun phrases') == 'E.g. search: "machine learning, deep learning"','candidate function error'
	assert candidate(termtype='Single phrase') == 'E.g. deep learning (one phrase only)', "The placeholder should be 'E.g. deep learning (one phrase only)'"
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>', \
    "Entity mentions placeholder is not correct"
	assert candidate(termtype='Entity mentions') == 'E.g. search: "machine learning, deep learning": each search term will automatically be converted to http://en.wikipedia.org/wiki/<search_term>'
def test_check():
	check(set_placeholder)
