def parse_ants(antstr):
    """Split apart command-line antennas into a list of baselines."""
    ### Canonical solution below ###
    rv = [s.split('_') for s in antstr.split(',')]
    rv = [(int(i[:-1]), int(j[:-1]), i[-1]+j[-1]) for i,j in rv]
    return rv


### Unit tests below ###
def check(candidate):
	assert candidate( '1x_2x,3x_4x,5x_6x' ) == [(1,2,'xx'),(3,4,'xx'),(5,6,'xx')]
	assert candidate('2x_3y,4x_5y,6x_7y') == [(2,3,'xy'),(4,5,'xy'),(6,7,'xy')]
	assert candidate( '01x_02y,03x_04y,01y_02x,05x_06y' ) == [(1,2,'xy'), (3,4,'xy'), (1,2,'yx'), (5,6,'xy')]
	assert candidate( '01x_02y,03x_04y' ) == [(1,2,'xy'), (3,4,'xy')]
	assert candidate('1A_2B,3A_4B') == [(1,2,'AB'), (3,4,'AB')]
	assert candidate('1A_2A,3A_4A') == [(1,2,'AA'), (3,4,'AA')]
	assert candidate( '1y_2y,3y_4y,5y_6y' ) == [(1,2,'yy'),(3,4,'yy'),(5,6,'yy')]
	assert candidate('2x_3y,4x_5y,6x_7y,8y_9y') == [(2,3,'xy'),(4,5,'xy'),(6,7,'xy'),(8,9,'yy')]
def test_check():
	check(parse_ants)
