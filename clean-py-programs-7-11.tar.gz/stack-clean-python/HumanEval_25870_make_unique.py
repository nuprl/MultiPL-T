def make_unique(s, existing):
    """ 
     make string s unique, able to be added to a sequence `existing` of
     existing names without duplication, by appending _<int> to it if needed
     """
	### Canonical solution below ###    
    n = 1
    s_out = s
    existing = set(existing)

    while s_out in existing:
        n += 1
        s_out = '{}_{}'.format(s, n)

    return s_out

### Unit tests below ###
def check(candidate):
	assert candidate(s='name_1', existing=['name', 'name_1', 'name_1_1']) == 'name_1_2'
	assert candidate('foo_1_1', ['foo']) == 'foo_1_1'
	assert candidate(None, []) is None
	assert candidate('foo', ['foo', 'foo_1']) == 'foo_2'
	assert candidate('a_1_1', ['a', 'a_1']) == 'a_1_1'
	assert candidate('foo', ['bar', 'baz']) == 'foo'
	assert candidate('None', ['None', 'None_1']) == 'None_2'
	assert candidate(s='foo', existing=['foo', 'foo_1']) == 'foo_2'
	assert candidate('foo', ['foo', 'foo_1', 'foo_2', 'foo_3', 'foo_4']) == 'foo_5'
	assert candidate(s='foo_1', existing=['foo', 'foo_1', 'foo_1_1']) == 'foo_1_2'
	assert candidate('a', ['a', 'a_1', 'a_2', 'a_3']) == 'a_4'
	assert candidate( 'a', [] ) == 'a'
	assert candidate('None', ['None', 'None_1', 'None_2']) == 'None_3'
	assert candidate('foo', ['foo', 'foo_1', 'foo_2', 'foo_3']) == 'foo_4'
	assert candidate(s='name', existing=['name', 'name_1', 'name_2']) == 'name_3'
	assert candidate( 'foo', ['foo', 'foo_1'] ) == 'foo_2'
	assert candidate('foo_1_1', ['foo', 'foo_1']) == 'foo_1_1'
	assert candidate(s='x', existing=['x', 'x_1']) == 'x_2'
	assert candidate('foo', ['foo', 'foo_1', 'foo_2']) == 'foo_3'
	assert candidate('a_1', ['a', 'a_1', 'a_1_1']) == 'a_1_2'
	assert candidate(s='foo_1', existing=['foo', 'foo_1']) == 'foo_1_2'
	assert candidate('foo_1_1_1', ['foo', 'foo_1']) == 'foo_1_1_1'
	assert candidate( 'a_1', ['a_1', 'a_1_1'] ) == 'a_1_2'
	assert candidate('a', ['a', 'a_1']) == 'a_2'
	assert candidate('foo_1', ['foo', 'foo_1', 'foo_1_1']) == 'foo_1_2'
	assert candidate('s', ['s','s_1','s_2']) =='s_3'
	assert candidate('a_1', ['a']) == 'a_1'
	assert candidate('123', ['123', '123_1', '123_2']) == '123_3'
	assert candidate('foo_1_1_1', ['foo']) == 'foo_1_1_1'
	assert candidate('s', ['s','s_1']) =='s_2'
	assert candidate(s='foo', existing=['foo', 'foo_1', 'foo_2']) == 'foo_3'
	assert candidate('foo', ['foo', 'foo_2']) == 'foo_3'
	assert candidate('123', ['123', '123_1']) == '123_2'
	assert candidate('a_1', ['a_1', 'a_1_1']) == 'a_1_2'
	assert candidate(None, []) == None
	assert candidate('', []) == ''
	assert candidate(s='a', existing=['a', 'b_1', 'c']) == 'a_2'
	assert candidate('123', ['123', '123_1', '123_2', '123_3']) == '123_4'
	assert candidate('foo', []) == 'foo'
	assert candidate(s='name', existing=['name', 'name_1']) == 'name_2'
	assert candidate(s='foo', existing=['foo', 'foo_1', 'foo_2', 'foo_3']) == 'foo_4'
	assert candidate( 'a', ['a', 'a_1'] ) == 'a_2'
	assert candidate(s='x_1', existing=['x_1', 'x_1_1']) == 'x_1_2'
	assert candidate('d', ['a', 'b', 'c']) == 'd'
	assert candidate('foo_1_1_1', ['foo', 'foo_1', 'foo_1_1']) == 'foo_1_1_1'
	assert candidate( 'foo', [] ) == 'foo'
	assert candidate('a', []) == 'a'
	assert candidate('a', ['a', 'a_1', 'a_2']) == 'a_3'
def test_check():
	check(make_unique)
