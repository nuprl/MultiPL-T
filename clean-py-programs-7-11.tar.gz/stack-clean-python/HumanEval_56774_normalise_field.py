def normalise_field(text) -> str:
    """Replace the UI access with the backend Django access"""
    ### Canonical solution below ###
    return text.strip().replace('(', '::').replace(')', '').replace(".", "__")


### Unit tests below ###
def check(candidate):
	assert candidate('field_name') == 'field_name'
	assert candidate('  ') == ''
	assert candidate(
    'a.b.c.d'
) == 'a__b__c__d'
	assert candidate("a ") == "a"
	assert candidate(
    "name: [String]") == "name: [String]"
	assert candidate(
    'field ') == 'field'
	assert candidate(
    'field') == 'field'
	assert candidate(
    "name: String") == "name: String"
	assert candidate("a") == "a"
	assert candidate('field.name') == 'field__name'
	assert candidate(
    "field1") == "field1", "Incorrect normalisation of field1"
	assert candidate(
    'first.name'
) == 'first__name'
	assert candidate(" a ") == "a"
	assert candidate(
    "name: [String] @searchable") == "name: [String] @searchable"
	assert candidate("") == ""
	assert candidate("  a ") == "a"
	assert candidate(
    'first_name'
) == 'first_name'
	assert candidate(
    'name'
) == 'name'
	assert candidate("foo") == "foo"
	assert candidate(
    "name") == "name"
	assert candidate(
    "User.first_name, User.last_name, User.email, User.password, User.is_active, User.is_staff, User.is_superuser, User.last_login, User.date_joined, User.groups, User.user_permissions"
) == "User__first_name, User__last_name, User__email, User__password, User__is_active, User__is_staff, User__is_superuser, User__last_login, User__date_joined, User__groups, User__user_permissions"
	assert candidate('') == ''
	assert candidate('field__name') == 'field__name'
def test_check():
	check(normalise_field)
