def _subject(subject):
    """
    Returns a query item matching "subject".

    Args:
        subject: The subject of the message.

    Returns:
        The query string.

    """
    ### Canonical solution below ###

    return f"subject:{subject}"


### Unit tests below ###
def check(candidate):
	assert candidate("Test Subject") == "subject:Test Subject"
	assert candidate("") == "subject:"
	assert candidate("Hello, world!") == "subject:Hello, world!"
	assert candidate("Hello world") == "subject:Hello world"
	assert candidate("hello") == "subject:hello"
	assert candidate("test") == "subject:test"
	assert candidate(
    "Test message") == "subject:Test message"
	assert candidate(None) == "subject:None"
	assert candidate(' ') =='subject: '
	assert candidate(subject="test") == "subject:test"
	assert candidate("hello world") == "subject:hello world"
	assert candidate("Test") == "subject:Test"
	assert candidate("a b") == "subject:a b"
	assert candidate("a") == "subject:a"
	assert candidate("Foo") == "subject:Foo"
	assert candidate("foo") == "subject:foo"
	assert candidate('foo') =='subject:foo'
	assert candidate("abc") == "subject:abc"
	assert candidate("b") == "subject:b"
	assert candidate('test') =='subject:test'
def test_check():
	check(_subject)
