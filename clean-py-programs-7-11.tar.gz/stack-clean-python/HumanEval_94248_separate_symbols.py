def separate_symbols(s):
    """ 
     Adds a dash to a symbol pair. btcusd -> btc-usd
     """
	### Canonical solution below ###    
    return s[:3] + '-' + s[3:]

### Unit tests below ###
def check(candidate):
	assert candidate(u'btcusd') == u'btc-usd'
	assert candidate(
    'ltcbtc') == 'ltc-btc'
	assert candidate(
    'bchusd') == 'bch-usd', 'bchusd -> bch-usd'
	assert candidate('xrpusdt') == 'xrp-usdt'
	assert candidate( 'btcusdt' ) == 'btc-usdt'
	assert candidate("ltcbtc") == "ltc-btc"
	assert candidate('etcusd') == 'etc-usd'
	assert candidate('eoseth') == 'eos-eth'
	assert candidate(
    'etcbtc') == 'etc-btc', 'etcbtc -> etc-btc'
	assert candidate("ltcbch") == "ltc-bch"
	assert candidate('etcbtc') == 'etc-btc'
	assert candidate(
    'ethusd') == 'eth-usd', 'ethusd -> eth-usd'
	assert candidate('eosusd') == 'eos-usd'
	assert candidate('ethusd') == 'eth-usd'
	assert candidate(
    "btcusd") == "btc-usd"
	assert candidate('iotusd') == 'iot-usd'
	assert candidate(
    'btcusd') == 'btc-usd','candidate failed for btcusd'
	assert candidate(
    'ltcbtc') == 'ltc-btc', 'ltcbtc -> ltc-btc'
	assert candidate(
    "ltcbtc") == "ltc-btc", "candidate failed for ltcbtc"
	assert candidate(
    'bcheur') == 'bch-eur', 'bcheur -> bch-eur'
	assert candidate(
    'ltcusd') == 'ltc-usd', 'ltcusd -> ltc-usd'
	assert candidate(
    'ethbtc') == 'eth-btc','candidate("ethbtc") is incorrect'
	assert candidate(
    'btcusd'
) == 'btc-usd','candidate does not work'
	assert candidate('eosusdt') == 'eos-usdt'
	assert candidate(
    "btcusd") == "btc-usd", "candidate failed for btcusd"
	assert candidate('iotbtc') == 'iot-btc'
	assert candidate(
    'btcusd') == 'btc-usd','candidate("btcusd") is incorrect'
	assert candidate('etcusdt') == 'etc-usdt'
	assert candidate( 'ltcusd' ) == 'ltc-usd'
	assert candidate('xrpusd') == 'xrp-usd'
	assert candidate(
    'ltcbtc') == 'ltc-btc', "candidate('ltcbtc') is incorrect"
	assert candidate(
    'ltcbtc') == 'ltc-btc','candidate("ltcbtc") is incorrect'
	assert candidate(
    'ethbtc') == 'eth-btc', "candidate('ethbtc') is incorrect"
	assert candidate("ltcusd") == "ltc-usd"
	assert candidate('eosbtc') == 'eos-btc'
	assert candidate('btcusd') == 'btc-usd'
	assert candidate(
    'ethbtc') == 'eth-btc', "Incorrect symbol separation for 'ethbtc'"
	assert candidate(
    'btcusd') == 'btc-usd'
	assert candidate('bchbtc') == 'bch-btc'
	assert candidate( 'ethbtc' ) == 'eth-btc'
	assert candidate(
    'btcusd') == 'btc-usd', 'btcusd -> btc-usd'
	assert candidate(
    'etcusd') == 'etc-usd', 'etcusd -> etc-usd'
	assert candidate(
    'btcusdt') == 'btc-usdt'
	assert candidate('ethusdt') == 'eth-usdt'
	assert candidate('bchusd') == 'bch-usd'
	assert candidate("btcxrp") == "btc-xrp"
	assert candidate(
    'btcusd') == 'btc-usd', "candidate('btcusd') is incorrect"
	assert candidate('ltcusd') == 'ltc-usd'
	assert candidate(
    'ethusd') == 'eth-usd', "candidate('ethusd') is incorrect"
	assert candidate(
    'ethbtc') == 'eth-btc', 'ethbtc -> eth-btc'
	assert candidate(
    'btcusd') == 'btc-usd', "Incorrect symbol separation for 'btcusd'"
	assert candidate(
    'btcusd') == 'btc-usd', "candidate('btcusd')"
	assert candidate('ethbtc') == 'eth-btc'
	assert candidate(
    'ltcbtc') == 'ltc-btc','candidate failed for ltcbtc'
	assert candidate('ltcbtc') == 'ltc-btc'
	assert candidate('btcusd-btceur') == 'btc-usd-btceur'
	assert candidate( 'ltcbtc' ) == 'ltc-btc'
	assert candidate( 'btcusd' ) == 'btc-usd'
	assert candidate(
    'ltcbtc') == 'ltc-btc', "Incorrect symbol separation for 'ltcbtc'"
	assert candidate('xrpbtc') == 'xrp-btc'
	assert candidate(
    'ethbtc') == 'eth-btc'
	assert candidate('bchusdt') == 'bch-usdt'
	assert candidate('ioteth') == 'iot-eth'
def test_check():
	check(separate_symbols)
