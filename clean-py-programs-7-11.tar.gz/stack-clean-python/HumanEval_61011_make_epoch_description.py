def make_epoch_description(history: dict, current: int, total: int, best: int, exclude: list = []):
    """Create description string for logging progress."""
    ### Canonical solution below ###
    pfmt = f">{len(str(total))}d"
    desc = f" Epoch: [{current:{pfmt}}/{total:{pfmt}}] ({best:{pfmt}}) |"
    for metric_name, metric_dict  in history.items():
        if not isinstance(metric_dict, dict):
            raise TypeError("`history` must be a nested dictionary.")
        if metric_name in exclude:
            continue
        for k, v in metric_dict.items():
            desc += f" {k}_{metric_name}: {v:.4f} |"
    return desc


### Unit tests below ###
def check(candidate):
	assert candidate(history={}, current=0, total=0, best=0) == " Epoch: [0/0] (0) |"
	assert candidate(history={"loss": {"train": 0.1, "val": 0.2}}, current=1, total=3, best=1) == \
    " Epoch: [1/3] (1) | train_loss: 0.1000 | val_loss: 0.2000 |"
	assert candidate(
    history={"train": {"loss": 1.0}, "val": {"loss": 1.0}},
    current=1,
    total=10,
    best=1,
    exclude=["loss", "val", "train"],
) == " Epoch: [ 1/10] ( 1) |"
	assert candidate(
    history={"train": {"loss": 1.0}, "val": {"loss": 1.0}},
    current=1,
    total=10,
    best=1,
    exclude=["loss", "val"],
) == " Epoch: [ 1/10] ( 1) | loss_train: 1.0000 |"
	assert candidate(
    history={"train": {"loss": 1.0}, "val": {"loss": 1.0}},
    current=1,
    total=10,
    best=1,
) == " Epoch: [ 1/10] ( 1) | loss_train: 1.0000 | loss_val: 1.0000 |"
	assert candidate(
    history={"loss": {"train": 1.0, "val": 0.5}, "acc": {"train": 0.9, "val": 0.9}},
    current=3, total=10, best=5, exclude=["loss", "acc", "acc_train", "acc_val"]
) == " Epoch: [ 3/10] ( 5) |"
	assert candidate(
    history={
        "train": {
            "loss": 0.1,
            "accuracy": 0.9,
            "accuracy_top5": 0.95,
        },
        "validation": {
            "loss": 0.2,
            "accuracy": 0.8,
            "accuracy_top5": 0.85,
        }
    },
    current=1,
    total=3,
    best=1,
) == " Epoch: [1/3] (1) | loss_train: 0.1000 | accuracy_train: 0.9000 | accuracy_top5_train: 0.9500 | loss_validation: 0.2000 | accuracy_validation: 0.8000 | accuracy_top5_validation: 0.8500 |"
	assert candidate(
    history={"loss": {"train": 1.0, "val": 0.5}, "acc": {"train": 0.9, "val": 0.9}},
    current=3, total=10, best=5, exclude=["loss", "acc"]
) == " Epoch: [ 3/10] ( 5) |"
def test_check():
	check(make_epoch_description)
