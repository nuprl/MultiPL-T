def filter_out_quotes(comment):
    """
    Removes any quoted text from reddit comment text. On reddit, lines of 
    quoted text begin with \n\n>. Single \n dont register as new line 
    in regards to quotes.
    :param comment_text: string of comment
    :return:
    """
    ### Canonical solution below ###
    lines = comment.split("\n\n")
    i = 0
    while i < len(lines):
        if lines[i].startswith(">"):
            lines.pop(i)
        else:
            i += 1
    return "\n\n".join(lines)


### Unit tests below ###
def check(candidate):
	assert candidate(
    "This is a test\n\n>And this is a quote\n\nAnd this is more text\n\nAnd this is more text\n\nAnd this is more text") == \
    "This is a test\n\nAnd this is more text\n\nAnd this is more text\n\nAnd this is more text"
	assert candidate(
    "This is a test\n\n>And this is a quote\n\nAnd this is more text") == \
    "This is a test\n\nAnd this is more text"
	assert candidate(
    "This is a test\n\n> quote 1\n> quote 2\n\nThis is also a test") == \
    "This is a test\n\nThis is also a test", \
    "candidate failed"
	assert candidate(
    "Hi\n\n> This is a quote\n\nIt's a quote"
) == "Hi\n\nIt's a quote"
	assert candidate(
    "This is a test\n\n> this is a quote\n\n> this is also a quote\n\n"
    "this is not a quote") == "This is a test\n\nthis is not a quote"
	assert candidate(
    "text\n\n> quote\n\nmore text") == "text\n\nmore text"
	assert candidate(
    "This is a test\n\n> this is a quote\n\n"
    "this is not a quote") == "This is a test\n\nthis is not a quote"
	assert candidate(
    "What a great thread!\n\n> I agree.") == (
    "What a great thread!")
	assert candidate(
    "This is a quote.\n\n>This is the quote") == "This is a quote."
	assert candidate(
    "This is a quote.\n\n>This is the quote.\n\nThis is another quote.") == "This is a quote.\n\nThis is another quote."
	assert candidate(
    "This is a line of text\n\n> This is a quote.\n\nThis is another line of text") == "This is a line of text\n\nThis is another line of text"
	assert candidate(
    "This is the first line\n\nThis is the second line"
) == "This is the first line\n\nThis is the second line"
	assert candidate(
    "this is a test\n\n> this is a quote\n\nthis is more text\n\n"
    "this is yet more text") == (
        "this is a test\n\nthis is more text\n\nthis is yet more text")
	assert candidate(
    "text\n\n> quote\n\n> more quote\n\nmore text") == "text\n\nmore text"
	assert candidate(
    "This is a test\n\n>And this is a quote\n\nAnd this is more text\n\n") == \
    "This is a test\n\nAnd this is more text\n\n"
	assert candidate(
    "This is the first line\n\n> This is a quoted line\n\n> This is another quoted line\n\n> This is a third quoted line\n\n> This is a fourth quoted line\n\nThis is the second line"
) == "This is the first line\n\nThis is the second line"
	assert candidate(
    "Hey, I'm a comment") == \
       "Hey, I'm a comment"
	assert candidate(
    "This is a quote\n\n> This is quoted text\n\nThis is not a quote\n"
) == "This is a quote\n\nThis is not a quote\n"
	assert candidate(
    "This is a test\n\n> quote 1\n\nThis is also a test") == \
    "This is a test\n\nThis is also a test", \
    "candidate failed"
	assert candidate(
    "This is a comment\n\n> This is a quote") == "This is a comment"
	assert candidate(
    "Hello\n\n> I am a quoted line\n\nHow are you?") == "Hello\n\nHow are you?"
	assert candidate(
    "Hey, I'm a comment\n\n>Hey, I'm a quote\n\n>Hey, I'm a quote\n\n>Hey, I'm a quote") == \
       "Hey, I'm a comment"
	assert candidate(
    "Hey, I'm a comment\n\n>Hey, I'm a quote\n\n>Hey, I'm a quote") == \
       "Hey, I'm a comment"
	assert candidate(
    "Hello \n\n") == "Hello \n\n"
	assert candidate(
    "This is a quote\n\n> This is quoted text\n\nThis is not a quote\n\n\n"
) == "This is a quote\n\nThis is not a quote\n\n\n"
	assert candidate(
    "Hey, I'm a comment\n\n>Hey, I'm a quote") == \
       "Hey, I'm a comment"
	assert candidate(
    "this is a test\n\n> this is a quote\n\nthis is more text\n\n"
    "this is yet more text\n\n> this is another quote\n\n"
    "this is yet another text\n\n") == (
        "this is a test\n\nthis is more text\n\nthis is yet more text\n\n"
        "this is yet another text\n\n")
	assert candidate(
    "This is a line of text\n\n> This is a quote.") == "This is a line of text"
	assert candidate(
    "This is the first line\n\n> This is a quoted line\n\n> This is another quoted line\n\nThis is the second line"
) == "This is the first line\n\nThis is the second line"
	assert candidate(
    "Hi\n\n> This is a quote\n> It's a quote"
) == "Hi"
	assert candidate(
    "This is a quote\n\n> This is quoted text\n\n This is not a quote"
) == "This is a quote\n\n This is not a quote"
	assert candidate(
    "This is a comment\n\n> This is a quoted line\n\nThis is a second comment") == \
    "This is a comment\n\nThis is a second comment"
	assert candidate(
    "This is a test\n\n> quote 1\n\nquote 2\n\nThis is also a test") == \
    "This is a test\n\nquote 2\n\nThis is also a test", \
    "candidate failed"
	assert candidate(
    "This is a line of text\n\n> This is a quote.\n\nThis is another line of text\n\n> This is another quote.") == "This is a line of text\n\nThis is another line of text"
	assert candidate(
    "Hello\n\n> This is a quote\n\nThis is not") == "Hello\n\nThis is not"
	assert candidate(
    "This is a quote\n\n> This is quoted text\n\nThis is not a quote\n\n\n\n"
) == "This is a quote\n\nThis is not a quote\n\n\n\n"
	assert candidate(
    "This is a test\n\nAnd this is more text") == "This is a test\n\nAnd this is more text"
	assert candidate(
    "This is a quote\n\n> This is quoted text\n\nThis is not a quote\n\n"
) == "This is a quote\n\nThis is not a quote\n\n"
	assert candidate(
    "This is a quote\n\n> This is quoted text\n\nThis is not a quote"
) == "This is a quote\n\nThis is not a quote"
	assert candidate(
    "text\n\n> quote\n\n> more quote\n\n> \n\nmore text") == "text\n\nmore text"
	assert candidate("foo") == "foo"
	assert candidate(
    "This is the first line\n\n> This is a quoted line\n\n> This is another quoted line\n\n> This is a third quoted line\n\nThis is the second line"
) == "This is the first line\n\nThis is the second line"
	assert candidate(
    "this is a test\n\n> this is a quote\n\nthis is more text\n\n") == (
        "this is a test\n\nthis is more text\n\n")
	assert candidate(
    "Hello \n\n> world \n\n") == "Hello \n\n"
	assert candidate(
    "this is a test\n\n> this is a quote\n\nthis is more text\n\n"
    "this is yet more text\n\n> this is another quote") == (
        "this is a test\n\nthis is more text\n\nthis is yet more text")
def test_check():
	check(filter_out_quotes)
