def sqrt(x):
  """
  Calculate the square root of argument x.
  """
    ### Canonical solution below ###
  #Check that x is positive.
  if x < 0:
   print("Error: negative value supplied")
   return -1
  else:
   print("Here we go...")

  #Initial guess for the square root.
  z = x / 2.0

  #Continously improve the guess.
  while abs(x - (z*z)) > 0.000001:
   z = z - (((z * z) - x) / (2 * z))

  return z


### Unit tests below ###
def check(candidate):
	assert candidate(4)!= 3
	assert candidate(-4) == -1
	assert candidate(10000) == 100
	assert candidate(-2) == -1.0
	assert candidate(-1.0) == -1
	assert candidate(0) == 0
	assert candidate(-1) == -1
	assert candidate(4.0) == 2.0
	assert candidate(49) == 7
	assert candidate(0) == 0.0
	assert candidate(4) == 2.0
	assert candidate(4) == 2
def test_check():
	check(sqrt)
