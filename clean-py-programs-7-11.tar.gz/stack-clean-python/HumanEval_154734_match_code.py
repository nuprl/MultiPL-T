def match_code(code:str, raw_line:bytes)->bool:
    """ returns True if code is met at the beginning of the line."""
	### Canonical solution below ###    
    line = raw_line.decode("ascii")
    return line.startswith(code + " ") or line.startswith(code + ";")

### Unit tests below ###
def check(candidate):
	assert candidate( "C", b"D;" ) == False
	assert candidate(r"^", b"^  ")
	assert candidate( "C", b"D " ) == False
	assert candidate( "C", b"  " ) == False
	assert candidate( "C", b"CC " ) == False
	assert candidate(r"//", b";test\n") == False
	assert candidate(code="!N", raw_line=b"!N 1 ;comment")
	assert candidate(code="ABC", raw_line=b"ABC DEF") == True
	assert candidate(r"//", b"") == False
	assert candidate(r"^$", b"^$  ;")
	assert candidate(code="!L", raw_line=b"!L;")
	assert not candidate(r"^% ", b"%!foo")
	assert candidate(code="ABC", raw_line=b"ABC; DEF") == True
	assert candidate(r"//", b"test") == False
	assert not candidate(r"^", b"a^;")
	assert candidate(code="AB", raw_line=b"AB; 0001") == True
	assert not candidate(r"^$", b"a^$")
	assert candidate(code="L", raw_line=b"L 0 0 0 0 0 0 0\n")
	assert candidate(r"//", b"test\n") == False
	assert candidate(r"^", b"^  ;")
	assert candidate(r"//", b";test") == False
	assert candidate(r"^;", b"^; ; ;")
	assert candidate(code="IF", raw_line=b"IF ; comment\n")
	assert candidate(r";", b"test") == False
	assert candidate( "C", b"C;" ) == True
	assert not candidate(code="!L", raw_line=b"L;")
	assert candidate(code="ABC", raw_line=b"DEF ABC") == False
	assert candidate(code="G1", raw_line=b"G1 X123.456 Y789.012")
	assert not candidate(code="!N", raw_line=b"!N")
	assert candidate(code="IF", raw_line=b"IF 1 GOTO 50")
	assert not candidate(code="IF", raw_line=b"IFX  \n")
	assert candidate(code="X", raw_line=b"X;comment\n")
	assert candidate(code="F", raw_line=b"F; 0") == True
	assert not candidate(code="X", raw_line=b"Y ;comment\n")
	assert candidate(code="L", raw_line=b"L 0 0 0 0 0 0 0 ; comment\n")
	assert candidate(code="X", raw_line=b"X ;comment\n")
	assert candidate(code="AB", raw_line=b"AB 0001") == True
	assert candidate(r"^;", b"^; ;")
	assert candidate( "C", b"CC;" ) == False
	assert candidate(code="GOTO", raw_line=b"GOTO 50")
	assert not candidate(code="!L", raw_line=b"!L1")
	assert candidate(r"^$", b"^$  ")
	assert candidate(code="L", raw_line=b"M 115 115 115 115") == False
	assert not candidate(r"^", b"a^  ")
	assert not candidate(r"^", b"^a;")
	assert candidate(r"//", b" ") == False
	assert candidate(code="AB", raw_line=b"BA 0001") == False
	assert not candidate(code="!N", raw_line=b"!M 1")
	assert candidate(code="a", raw_line=b"a; ") == True
	assert candidate(code="L", raw_line=b"L 115 115 115 115") == True
	assert not candidate(code="G1", raw_line=b"G0 X123.456 Y789.012")
	assert not candidate(r"^", b"a^  ;")
	assert candidate(r"^", b"^ ")
	assert candidate(code="G1", raw_line=b"G1 X1 Y1 Z1")
	assert candidate( "C", b"  ;" ) == False
	assert not candidate(r"^$", b"a^$  ")
	assert candidate(code="X", raw_line=b"X ;comment")
	assert not candidate(code="L", raw_line=b"M 0 0 0 0 0 0 0\n")
	assert candidate(code="REM", raw_line=b"REM This is a comment.")
	assert candidate(code="G1", raw_line=b"G1 X1 Y1 Z1;comment")
	assert not candidate(code="GOTO", raw_line=b"GOT 50")
	assert candidate(code="M", raw_line=b"M 115 115 115 115") == True
	assert not candidate(r"^% ", b"%foo")
	assert not candidate(r"^", b"^a")
	assert not candidate(r"^", b"a^ ")
	assert candidate(code="!L", raw_line=b"!L ")
	assert not candidate(r"^$", b"a^$;")
	assert candidate(r"//", b"\r") == False
	assert candidate(code="G1", raw_line=b"G1 X123.456 Y789.012 F2000")
	assert candidate(r"^;", b"^; ;  ")
	assert not candidate(code="G1", raw_line=b"G2 X1 Y1 Z1")
	assert candidate(code="a", raw_line=b"b") == False
	assert candidate(code="ABC", raw_line=b"DEF; ABC") == False
	assert candidate(code="O", raw_line=b"O;comment") == True
	assert candidate(code="!N", raw_line=b"!N 1")
	assert candidate(r"^", b"^;")
	assert candidate(r";", b"") == False
	assert candidate(r"^;", b"^; ; ")
	assert candidate(code="a", raw_line=b"a;") == True
	assert candidate(r"//", b"// test") == True
	assert not candidate(code="REM", raw_line=b"This is a comment.")
	assert not candidate(code="ENDIF", raw_line=b"IF 1")
	assert candidate(r";", b"test\n") == False
	assert candidate(r"^;", b"^; ")
	assert candidate(r";", b" ") == False
	assert candidate(r"C", b"C13.000000000000000") == False
	assert candidate(r"//", b"// test\n") == True
	assert candidate(r"//", b"\n") == False
	assert candidate(code="F", raw_line=b"F 0") == True
	assert candidate(code="a", raw_line=b"a ") == True
	assert candidate(code="AB", raw_line=b"BA") == False
	assert candidate( "C", b"C " ) == True
	assert candidate(code="O", raw_line=b"G;comment") == False
	assert candidate(r";", b"\n") == False
	assert not candidate(r"^$", b"a^$  ;")
	assert candidate(r"^;", b"^;  ")
	assert candidate(r"C", b"C 13.000000000000000") == True
	assert candidate(code="IF", raw_line=b"IF  \n")
	assert candidate(r"C", b"C; 13.000000000000000") == True
	assert candidate(code="X", raw_line=b"X ;")
	assert candidate(code="AB", raw_line=b"BA; 0001") == False
	assert not candidate(code="IF", raw_line=b"IFX ; comment\n")
	assert candidate(r"C", b"H 13.000000000000000") == False
	assert candidate(code="F", raw_line=b"F0") == False
	assert not candidate(r"\begin", b"\\documentclass{article}")
	assert candidate(r"^$", b"^$;")
	assert candidate(code="M", raw_line=b"L 115 115 115 115") == False
	assert candidate(code="AB", raw_line=b"AB") == False
	assert candidate(r"//", b"\t") == False
def test_check():
	check(match_code)
