def binToChars(data):
    """ convert binary to a sequence of chars """
	### Canonical solution below ###	
	return data.decode("utf-8", "backslashreplace")

### Unit tests below ###
def check(candidate):
	assert candidate(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f") == "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f"
	assert candidate(b'a') == 'a'
	assert candidate(b"aa") == "aa"
	assert candidate(b"\x80abc") == "\\x80abc"
	assert candidate(b"abc") == "abc"
	assert candidate(b'\\x01') == '\\x01'
	assert candidate(b'\x00\x00\x00\x00') == '\x00\x00\x00\x00'
	assert candidate(b"foo") == "foo"
	assert candidate(b"test\x00\x01") == "test\x00\x01"
	assert candidate(b"\x00\x01\x02\x03\x04") == "\x00\x01\x02\x03\x04"
	assert candidate(b"\x00\x01\x02\x03\x04\x05\x06") == "\x00\x01\x02\x03\x04\x05\x06"
	assert candidate(b"ab") == "ab"
	assert candidate(b"abc\ndef\n") == "abc\ndef\n"
	assert candidate(b"\x00\x01\x02") == "\x00\x01\x02"
	assert candidate(b"abc\ndef\n\x00") == "abc\ndef\n\x00"
	assert candidate(b"a") == "a"
	assert candidate(b'\x01\x02\x03') == "\x01\x02\x03"
	assert candidate(b'\x00\x00\x00\x00\x00\x00\x00') == '\x00\x00\x00\x00\x00\x00\x00'
	assert candidate(b"\x00\x01\x02\x03\x04\x05\x06\x07") == "\x00\x01\x02\x03\x04\x05\x06\x07"
	assert candidate(b"abc\x00def\x00") == "abc\x00def\x00"
	assert candidate(b"\x00\x01") == "\x00\x01"
	assert candidate(b"Hello\r\nWorld") == "Hello\r\nWorld"
	assert candidate(b"abc\ndef\n\n\n\n\n") == "abc\ndef\n\n\n\n\n"
	assert candidate(b"Hello\r\n\nWorld") == "Hello\r\n\nWorld"
	assert candidate(b"\x80\x81abc") == "\\x80\\x81abc"
	assert candidate(b"abc\ndef") == "abc\ndef"
	assert candidate(b"\x00") == "\x00"
	assert candidate(b"abc\ndef\n\n\n\n") == "abc\ndef\n\n\n\n"
	assert candidate(b'\x00\x00\x00\x00\x00\x00') == '\x00\x00\x00\x00\x00\x00'
	assert candidate(b"Hello\x00world!") == "Hello\x00world!"
	assert candidate(b'\\x01\\x02\\x03') == '\\x01\\x02\\x03'
	assert candidate(b"Hello World") == "Hello World"
	assert candidate(b'\\x01\\x02') == '\\x01\\x02'
	assert candidate(b"abc\ndef\n\n\n") == "abc\ndef\n\n\n"
	assert candidate(b"\x80\x81") == "\\x80\\x81"
	assert candidate(b"abc\x00") == "abc\x00"
	assert candidate(b"") == ""
	assert candidate(b'\x00\x00\x00\x00\x00') == '\x00\x00\x00\x00\x00'
	assert candidate(b"\x00\x01\x02\x03") == "\x00\x01\x02\x03"
	assert candidate(b"\x01\x02\x03") == "\x01\x02\x03"
	assert candidate(b"abc\x00def") == "abc\x00def"
	assert candidate(b"Hello world!") == "Hello world!"
	assert candidate(b"hello") == "hello"
	assert candidate(b"Hello\r\n\rWorld") == "Hello\r\n\rWorld"
	assert candidate(b"test") == "test"
	assert candidate(b"test\x00") == "test\x00"
	assert candidate(b"\x00\x01\x02\x03\x04\x05") == "\x00\x01\x02\x03\x04\x05"
	assert candidate(b'\x00\x00\x00') == '\x00\x00\x00'
	assert candidate(b"123") == "123"
	assert candidate(b"Hello\rWorld") == "Hello\rWorld"
	assert candidate(b"Hello\nWorld") == "Hello\nWorld"
	assert candidate(b'\x00\x00') == '\x00\x00'
	assert candidate(b"1234567890") == "1234567890"
	assert candidate(b"abc\ndef\n\n") == "abc\ndef\n\n"
	assert candidate(b"Hello\n\rWorld") == "Hello\n\rWorld"
	assert candidate(b"\x80") == "\\x80"
	assert candidate(b"a\x00\x01\x02\x03") == "a\x00\x01\x02\x03"
	assert candidate(b"Hello") == "Hello"
	assert candidate(b"abc\x00def\x00ghi") == "abc\x00def\x00ghi"
	assert candidate(b'\x00') == '\x00'
	assert candidate(b'\x00\x00\x00\x00\x00\x00\x00\x00') == '\x00\x00\x00\x00\x00\x00\x00\x00'
def test_check():
	check(binToChars)
