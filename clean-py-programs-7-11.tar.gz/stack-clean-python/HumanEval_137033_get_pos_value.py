def get_pos_value (my_pos, dict_tagset) :
    """Get the pos value"""
    ### Canonical solution below ###

    if my_pos in dict_tagset:
        return dict_tagset[my_pos]
    return 0


### Unit tests below ###
def check(candidate):
	assert candidate(2, {1:1}) == 0
	assert candidate(u'JJR', {}) == 0
	assert candidate(u'VBZ', {}) == 0
	assert candidate(3, {'ADJ': 1}) == 0
	assert candidate(u'NNP', {}) == 0
	assert candidate(1, {1: 1}) == 1
	assert candidate(u'NNS', {}) == 0
	assert candidate(1, {1: 1, 2: 2}) == 1
	assert candidate(u'RBR', {}) == 0
	assert candidate(1, {}) == 0
	assert candidate(1, {1:2}) == 2
	assert candidate(1, {1:1}) == 1
	assert candidate(u'VBP', {}) == 0
	assert candidate(u'RB', {}) == 0
	assert candidate(2, {1: 1, 2: 2}) == 2
	assert candidate(2, {1: 1}) == 0
	assert candidate('NNP', {'NN': 1}) == 0
	assert candidate('NN', {'NN': 1}) == 1
	assert candidate(u'NN', {}) == 0
	assert candidate(u'JJ', {}) == 0
	assert candidate(0, {1:1}) == 0
	assert candidate(u'VB', {}) == 0
def test_check():
	check(get_pos_value)
