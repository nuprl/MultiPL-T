def get_number_of_pages(image_size, page_size):
    """calculates the number of pages required for the image"""
    ### Canonical solution below ###
    return (image_size + page_size - 1) / page_size


### Unit tests below ###
def check(candidate):
	assert candidate(21, 2) == 11
	assert candidate(13, 3) == 5
	assert candidate(0, 1) == 0
	assert candidate(11, 1) == 11
	assert candidate(5, 2) == 3
	assert candidate(10, 1) == 10
	assert candidate(16, 3) == 6
	assert candidate(7, 1) == 7
	assert candidate(5, 1) == 5
	assert candidate(19, 3) == 7
	assert candidate(1, 1) == 1
	assert candidate(3, 2) == 2
	assert candidate(6, 1) == 6
	assert candidate(11, 10) == 2
	assert candidate(10, 3) == 4
	assert candidate(2, 1) == 2
	assert candidate(6, 5) == 2
	assert candidate(1, 2) == 1
	assert candidate(7, 3) == 3
	assert candidate(28, 3) == 10
	assert candidate(4, 3) == 2
	assert candidate(4, 1) == 4
	assert candidate(25, 3) == 9
	assert candidate(3, 1) == 3
	assert candidate(31, 30) == 2
	assert candidate(11, 5) == 3
	assert candidate(22, 3) == 8
	assert candidate(5, 4) == 2
	assert candidate(11, 2) == 6
	assert candidate(10, 9) == 2
def test_check():
	check(get_number_of_pages)
