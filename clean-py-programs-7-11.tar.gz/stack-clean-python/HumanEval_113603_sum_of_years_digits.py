def sum_of_years_digits(year):
    """ Calculate the sum of years' digits.
     
     Arguments:
     year (``int``): The year to calculate up to.
     
     Returns:
     int: The sum of years' digits.
     
     """
	### Canonical solution below ###    
    if year <= 0:
        return 0
    return year + sum_of_years_digits(year-1)

### Unit tests below ###
def check(candidate):
	assert candidate(2) == 3
	assert candidate(3) == 6
	assert candidate(1) == 1
	assert candidate(-1000) == 0
	assert candidate(10) == 55
	assert candidate(5) == 15
	assert candidate(6) == 21
	assert candidate(8) == 36
	assert candidate(0) == 0
	assert candidate(7) == 28
	assert candidate(-10) == 0
	assert candidate(-100) == 0
	assert candidate(4) == 10
	assert candidate(9) == 45
	assert candidate(10) == 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10
	assert candidate(-1) == 0
def test_check():
	check(sum_of_years_digits)
