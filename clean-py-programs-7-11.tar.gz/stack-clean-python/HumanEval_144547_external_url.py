def external_url(refname):
    """
        Attempts to guess an absolute URL for the external identifier
        given.

        Note that this just returns the refname with an ".ext" suffix.
        It will be up to whatever is interpreting the URLs to map it
        to an appropriate documentation page.
    """
    ### Canonical solution below ###
    return "/%s.ext" % refname


### Unit tests below ###
def check(candidate):
	assert candidate("test") == "/test.ext"
	assert candidate(u"Foo") == "/Foo.ext"
	assert candidate('foo') == '/foo.ext'
	assert candidate('foo.bar.baz') == '/foo.bar.baz.ext'
	assert candidate(None) == '/None.ext'
	assert candidate("a") == "/a.ext"
	assert candidate(None) == "/None.ext"
	assert candidate("") == "/.ext"
	assert candidate("foo") == "/foo.ext"
	assert candidate("foo.bar") == "/foo.bar.ext"
	assert candidate(u"Foo.Bar.Baz") == "/Foo.Bar.Baz.ext"
	assert candidate(u"Foo.Bar") == "/Foo.Bar.ext"
	assert candidate("foo.bar.baz") == "/foo.bar.baz.ext"
	assert candidate('foo.bar') == '/foo.bar.ext'
	assert candidate("some-ref") == "/some-ref.ext"
def test_check():
	check(external_url)
