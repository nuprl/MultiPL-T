def select_to_text_readable(caption, choices):
    """
    A function to convert a select item to text in a more verbose, readable 
    format.
    Format is:
    
    [question] Send 1 for [choice1], 2 for [choice2]...
    """
    ### Canonical solution below ###
    return "%s Send %s" % (caption,
                      ", ".join(["%s for %s" % (i+1, val) for i, val in \
                                 enumerate(choices)]))


### Unit tests below ###
def check(candidate):
	assert candidate(caption="What's your favorite color?",
                               choices=["Red", "Green", "Blue"]) == \
       "What's your favorite color? Send 1 for Red, 2 for Green, 3 for Blue"
	assert candidate(
    "What color is the sky?",
    ["blue", "green", "red", "yellow"]) == "What color is the sky? Send 1 for blue, 2 for green, 3 for red, 4 for yellow"
	assert candidate("foo", ["bar"]) == "foo Send 1 for bar"
	assert candidate(caption="Which option?", choices=["one", "two", "three"]) == \
       "Which option? Send 1 for one, 2 for two, 3 for three"
	assert candidate(caption="Test question", choices=["a", "b"]) == \
       "Test question Send 1 for a, 2 for b"
	assert candidate("foo", ["bar", "baz", "qux"]) == "foo Send 1 for bar, 2 for baz, 3 for qux"
	assert candidate(
    "Do you want to continue?",
    ["Yes"]) == "Do you want to continue? Send 1 for Yes"
	assert candidate("foo", ["bar", "baz"]) == "foo Send 1 for bar, 2 for baz"
	assert candidate(caption="Test", choices=["a", "b", "c", "d", "e", "f"]) == \
    "Test Send 1 for a, 2 for b, 3 for c, 4 for d, 5 for e, 6 for f"
	assert candidate(caption="What color is the sky?", 
                               choices=["blue", "white", "black", "green"]) == \
       "What color is the sky? Send 1 for blue, 2 for white, 3 for black, 4 for green"
	assert candidate(caption="How many", choices=["one", "two", "three"]) == "How many Send 1 for one, 2 for two, 3 for three"
	assert candidate(caption="Select a choice", choices=["a"]) == "Select a choice Send 1 for a"
	assert candidate(caption="Test", choices=["a", "b", "c", "d"]) == \
    "Test Send 1 for a, 2 for b, 3 for c, 4 for d"
	assert candidate(caption="Send me", choices=["one", "two"]) == "Send me Send 1 for one, 2 for two"
	assert candidate(caption="Select a choice", choices=["a", "b"]) == "Select a choice Send 1 for a, 2 for b"
	assert candidate(caption='Send this to', choices=['a', 'b']) == \
    'Send this to Send 1 for a, 2 for b'
	assert candidate(caption="Send me", choices=["one", "two", "three"]) == "Send me Send 1 for one, 2 for two, 3 for three"
	assert candidate(caption="What's your favorite color?",
                               choices=["Red", "Green", "Blue", "Yellow",
                                        "Pink", "Purple"]) == \
       "What's your favorite color? Send 1 for Red, 2 for Green, 3 for Blue, 4 for Yellow, 5 for Pink, 6 for Purple"
	assert candidate(caption="Is this a test?", choices=["Yes", "No"]) \
       == "Is this a test? Send 1 for Yes, 2 for No"
	assert candidate(caption="How many", choices=["one"]) == "How many Send 1 for one"
	assert candidate(caption="Select a number", choices=["a", "b", "c"]) == \
       "Select a number Send 1 for a, 2 for b, 3 for c"
	assert candidate(caption="Test", choices=["a", "b", "c", "d", "e"]) == \
    "Test Send 1 for a, 2 for b, 3 for c, 4 for d, 5 for e"
	assert candidate(
    "Do you want to continue?",
    ["Yes", "No", "Maybe"]) == "Do you want to continue? Send 1 for Yes, 2 for No, 3 for Maybe"
	assert candidate(caption="Hello", choices=["1", "2", "3"]) == \
       "Hello Send 1 for 1, 2 for 2, 3 for 3"
	assert candidate(
    "Which number?",
    ["one", "two", "three"]) == "Which number? Send 1 for one, 2 for two, 3 for three"
	assert candidate(caption="What is your favorite color?",
                               choices=["red", "green", "blue"]) == \
       "What is your favorite color? Send 1 for red, 2 for green, 3 for blue"
	assert candidate(caption="Test", choices=["a", "b", "c"]) == \
    "Test Send 1 for a, 2 for b, 3 for c"
	assert candidate(caption="What's up?", choices=["Good", "Bad"]) \
       == "What's up? Send 1 for Good, 2 for Bad"
	assert candidate(caption="How many", choices=["one", "two"]) == "How many Send 1 for one, 2 for two"
	assert candidate(
    "What color is the sky?",
    ["blue", "green", "red", "yellow", "orange", "purple"]) == "What color is the sky? Send 1 for blue, 2 for green, 3 for red, 4 for yellow, 5 for orange, 6 for purple"
	assert candidate(caption="What color is the sky?",
                                choices=["blue", "green", "yellow"]) == \
       "What color is the sky? Send 1 for blue, 2 for green, 3 for yellow"
	assert candidate(caption="How many?", choices=["one", "two"]) == \
        "How many? Send 1 for one, 2 for two"
	assert candidate(caption="Send me", choices=["one"]) == "Send me Send 1 for one"
	assert candidate(
    "Do you want to continue?",
    ["Yes", "No"]) == "Do you want to continue? Send 1 for Yes, 2 for No"
	assert candidate(caption="How many?", choices=["one", "two"]) == \
       "How many? Send 1 for one, 2 for two"
	assert candidate("question", ["a", "b", "c"]) == \
    "question Send 1 for a, 2 for b, 3 for c"
	assert candidate(caption="What's your favorite color?",
                               choices=["Red", "Green", "Blue", "Yellow",
                                        "Pink"]) == \
       "What's your favorite color? Send 1 for Red, 2 for Green, 3 for Blue, 4 for Yellow, 5 for Pink"
	assert candidate(caption="What's your favorite color?",
                               choices=["Red", "Green", "Blue", "Yellow",
                                        "Pink", "Purple", "Teal"]) == \
       "What's your favorite color? Send 1 for Red, 2 for Green, 3 for Blue, 4 for Yellow, 5 for Pink, 6 for Purple, 7 for Teal"
	assert candidate(caption="Select a choice", choices=["a", "b", "c"]) == "Select a choice Send 1 for a, 2 for b, 3 for c"
	assert candidate(caption="What's your favorite color?",
                               choices=["Red", "Green", "Blue", "Yellow"]) == \
       "What's your favorite color? Send 1 for Red, 2 for Green, 3 for Blue, 4 for Yellow"
	assert candidate(caption="Send a message", choices=["a", "b", "c"]) == \
    "Send a message Send 1 for a, 2 for b, 3 for c"
	assert candidate(caption="Which", choices=["choice1", "choice2", "choice3"]) == \
    "Which Send 1 for choice1, 2 for choice2, 3 for choice3"
	assert candidate(caption="What is your favorite color?", 
                               choices=["red", "blue", "green", "yellow"]) == \
        "What is your favorite color? Send 1 for red, 2 for blue, 3 for green, 4 for yellow"
	assert candidate(
    "Which day of the week?",
    ["Monday", "Tuesday", "Wednesday"]) == "Which day of the week? Send 1 for Monday, 2 for Tuesday, 3 for Wednesday"
	assert candidate(caption="How many?", choices=["a", "b"]) == \
    "How many? Send 1 for a, 2 for b"
	assert candidate(caption="Is this a test?", choices=["yes", "no"]) == \
    "Is this a test? Send 1 for yes, 2 for no"
def test_check():
	check(select_to_text_readable)
