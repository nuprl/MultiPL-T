def IsTryJobResultAtRevisionValid(result, revision):
    """ Determines whether a try job's results are sufficient to be used.
     
     Args:
     result (dict): A dict expected to be in the format
     {
     'report': {
     'result': {
     'revision': (dict)
     }
     }
     }
     revision (str): The revision to ensure is in the result dict.
     """
	### Canonical solution below ###  
  return result and revision in result.get('report', {}).get('result', {})

### Unit tests below ###
def check(candidate):
	assert not candidate(
    {'report': {'result': {'rev2': {}}}},'rev1')
	assert candidate(
    {'report': {'result': {'rev1':'stuff'}}},'rev1')
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'report': {
                       'result': {
                           'rev2': 'try job report'
                        }
                    }
                }
            }
        }
    },
    '')
	assert not candidate(
    {'report': {'result': {'rev2': {'report': {}}}}},'rev1')
	assert not candidate({'report': {'result': {'rev2': {}}}},
                                      'rev1')
	assert candidate(
    {'report': {'result': {'rev1': {},'rev2': {}}}},'rev1')
	assert not candidate(None,'rev1')
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'rev1':'rev1_result',
                },
            },
        },
    },
   'rev2',
)
	assert candidate(
    {'report': {'result': {'rev1': {}}}, 'try_job_id': '1'},'rev1')
	assert not candidate({}, '1234')
	assert not candidate(
    {'report': {'result': {'rev1': 'pass'}}},'rev2')
	assert not candidate(
    {'report': {'result': {}}}, 'r1')
	assert not candidate(
    {'report': {'result': {'abc': {}}}}, 'def')
	assert candidate(
    {'report': {'result': {'r1': {}}}, 'try_job_id': 1}, 'r1')
	assert not candidate(
    {'report': {'result': {
       'rev1': {'try_job_id': 1234},'rev2': {'try_job_id': 12345}}}},'rev3')
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {},
            }
        }
    },
   'rev2')
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {},
               'rev2': {}
            }
        }
    },
   'rev3'
)
	assert not candidate({'report': {}},'rev1')
	assert not candidate(
    {'report': {'result': {}}},
   'revision')
	assert not candidate(
    {'report': {'result': {'rev1': {},'rev2': {}}}},'rev3')
	assert candidate({'report': {'result': {}}}, 'a') is False
	assert not candidate(
    {'report': {'result': {'rev1':'stuff'}}},'rev2')
	assert not candidate({'report': {}}, 'abc123')
	assert candidate(
    {'report': {'result': {'1234': {
       'report': {'result': {'revision': '1234'}}}}}}, '1234')
	assert candidate(
    {
       'report': {
           'result': {
               'rev1': {},
               'rev2': {}
            }
        }
    },
   'rev1'
)
	assert not candidate(
    {'report': {'result': {}}},
    'b')
	assert not candidate({}, 'abc')
	assert not candidate(
    {'report': {'result': {'r1': {}}}, 'try_job_id': 1}, 'r2')
	assert candidate(
    {'report': {'result': {'rev1': {'report': {}}}}},'rev1')
	assert not candidate({},'rev')
	assert not candidate(
    {}, 'r1')
	assert candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'rev1':'rev1_result',
                },
               'rev2': {
                   'rev2':'rev2_result',
                },
            },
        },
    },
   'rev1',
)
	assert not candidate({'report': {'result': {}}}, 'abc123')
	assert candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'rev1': {
                       'status': 'passed',
                    },
                },
               'rev2': {
                   'rev2': {
                       'status': 'failed',
                    },
                },
            },
        },
    },
   'rev1',
)
	assert not candidate({}, 'a_revision')
	assert candidate(
    {'report': {'result': {'rev1': 'pass','rev2': 'fail'}}},'rev2')
	assert not candidate(
    {'report': {'result': {'rev1': 'pass','rev2': 'pass'}}},'rev3')
	assert candidate(
    {'report': {'result': {'a_revision': {'try_job_id': 1}}}}, 'a_revision')
	assert not candidate(
    None,
   'revision')
	assert not candidate({},'rev3')
	assert not candidate(
    {'report': {'result': {'revision': {'rev': 'a'}}}},
    'b')
	assert candidate(
    {'report': {'result': {'abc123': {}}}}, 'abc123')
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'rev1': {
                       'status': 'passed',
                    },
                },
               'rev2': {
                   'rev2': {
                       'status': 'failed',
                    },
                },
            },
        },
    },
   'rev3',
)
	assert not candidate(
    {'report': {}}, 'r1')
	assert not candidate({'report': {}}, 'a_revision')
	assert not candidate(None,'rev3')
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'report': {
                       'result': {
                           'rev2': 'try job report'
                        }
                    }
                }
            }
        }
    },
   'rev3')
	assert candidate(
    {'report': {'result': {'revision': {'properties': {'a': 1}}}}},
   'revision') is True
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {},
               'rev2': {},
            }
        }
    },
   'rev3'
)
	assert not candidate(
    {'report': {}},
   'revision')
	assert candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'report': {
                       'result': {
                           'rev2': 'try job report'
                        }
                    }
                }
            }
        }
    },
   'rev1')
	assert candidate({'report': {'result': {'b': {}}}}, 'a') is False
	assert not candidate(None,'rev2')
	assert not candidate(
    {'report': {}},'rev1')
	assert not candidate({'report': {'result': {}}}, 'r1')
	assert candidate(
    {'report': {'result': {'rev1': {}}}},'rev1')
	assert candidate({'report': {'result': {'a': {}}}}, 'a') is True
	assert not candidate(
    {'report': {'result': {'rev1': {}}}},'rev2')
	assert candidate(
    {
       'report': {
           'result': {
               'rev1': {},
               'rev2': {},
            }
        }
    },
   'rev1'
)
	assert not candidate(
    {'report': {}},
    'b')
	assert not candidate(
    {},'rev1')
	assert candidate(
    {'report': {'result': {'rev1': {'status': 'passed'}}}},'rev1')
	assert candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'status': 'failed',
                    'valid': True
                },
               'rev2': {
                   'status': 'failed',
                    'valid': True
                },
               'rev3': {
                   'status': 'failed',
                    'valid': False
                },
            }
        }
    },'rev2')
	assert candidate({'report': {}}, 'a') is False
	assert not candidate({'report': {}}, 'r1')
	assert not candidate(
    {
       'report': {
           'result': {
               'rev1': {
                   'report': {
                       'result': {
                           'rev2': 'try job report'
                        }
                    }
                }
            }
        }
    },
    None)
	assert not candidate({'report': {'result': {}}},'rev1')
	assert not candidate(
    {'report': {'result': {'rev1': {},'rev2': {}}}}, None)
	assert not candidate(
    {'report': {'result': {'a_different_revision': {'try_job_id': 1}}}},
    'a_revision')
	assert not candidate(
    {'report': {'result': {}}},'rev1')
	assert not candidate(
    {'report': {'result': {
       'rev1': {'status': 'failed', 'valid': True},
       'rev2': {'status': 'failed', 'valid': True},
    }}},'rev3')
	assert candidate(
    {'report': {'result': {
       'rev1': {'status': 'failed', 'valid': True},
       'rev2': {'status': 'failed', 'valid': True},
    }}},'rev1')
	assert candidate(
    {'report': {'result': {'abc': {}}}}, 'abc')
	assert not candidate(
    {'report': {'result': {
       'rev1': {'status': 'completed', 'pass_fail_counts': {'pass': 1, 'fail': 0}},
       'rev2': {'status': 'completed', 'pass_fail_counts': {'pass': 1, 'fail': 1}},
    }}},'rev3')
	assert not candidate(
    {'report': {'result': {'rev': {'status': 'failed'}}}}, 'other_rev')
	assert not candidate({}, 'abc123')
	assert not candidate({},'rev2')
	assert not candidate({},'rev1')
	assert not candidate(
    {'report': {'result': {'rev1': {'status': 'passed'}}}},'rev2')
	assert candidate(
    {'report': {'result': {'other_revision': None}}},'revision') is False
	assert not candidate(
    {},
   'revision')
	assert not candidate(None, 'abc')
	assert candidate(
    {'report': {'result': {
       'rev1': {'status': 'completed', 'pass_fail_counts': {'pass': 1, 'fail': 0}},
       'rev2': {'status': 'completed', 'pass_fail_counts': {'pass': 1, 'fail': 1}},
    }}},'rev1')
	assert candidate(
    {
       'report': {
           'result': {
               'rev1': {},
               'rev2': {},
            }
        }
    },
   'rev2')
	assert not candidate(
    {},
    'b')
	assert not candidate(
    {'report': {'result': {'r1': {}}}}, 'r2')
	assert candidate(
    {'report': {'result': {
       'rev1': {'try_job_id': 1234},'rev2': {'try_job_id': 12345}}}},'rev1')
	assert candidate(
    {'report': {'result': {'revision': {}}}},
   'revision')
	assert candidate(
    {'report': {'result': {'rev': {'status': 'failed'}}}},'rev')
	assert not candidate({}, 'r1')
	assert candidate(
    {'report': {'result': {'r1': {}}}}, 'r1')
def test_check():
	check(IsTryJobResultAtRevisionValid)
