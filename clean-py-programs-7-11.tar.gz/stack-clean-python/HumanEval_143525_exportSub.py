def exportSub(arg, prefixMatch = False):
    """ 
     Decorator for subscription handlers.
     """
	### Canonical solution below ###   
   def inner(f):
      f._autobahn_sub_id = arg
      f._autobahn_sub_prefix_match = prefixMatch
      return f
   return inner

### Unit tests below ###
def check(candidate):
	assert candidate(1).__module__ == __name__
	assert candidate(1, prefixMatch = True)!= candidate(1, prefixMatch = False)
	assert candidate(u"foo", False)
	assert candidate(123)(lambda: None)._autobahn_sub_id == 123
	assert candidate(u"test")(lambda x: x)
	assert candidate(2)!= candidate(1)
	assert candidate(u"foo", prefixMatch = False)(lambda x: x)
	assert candidate(5).__name__ == 'inner'
	assert candidate(2).__name__ == 'inner'
	assert candidate(u"foo", 1)(lambda x: x)
	assert candidate(u"foo", True)
	assert candidate("prefix", True)
	assert candidate(u'foo', prefixMatch = True).__name__ == 'inner'
	assert candidate(u'foo.bar.baz.qux.*', True)(lambda x:x)
	assert candidate(123) is not None
	assert candidate(123, True)(lambda: None)._autobahn_sub_id == 123
	assert candidate(4).__name__ == 'inner'
	assert candidate(u"foo", None)(lambda x: x)
	assert candidate(6).__name__ == 'inner'
	assert candidate(u"test", True)(lambda x: x)
	assert candidate(u'foo.bar')(lambda x:x)
	assert candidate(1, True)!= candidate(2, True)
	assert candidate(u'foo.bar.*')(lambda x:x)
	assert candidate(u'foo', prefixMatch = True).__module__ == __name__
	assert candidate(u"foo", prefixMatch = True).__name__ == "inner"
	assert candidate(u'foo.bar.#')(lambda x:x)
	assert candidate(1).__doc__ == None
	assert candidate(1)!= candidate(2, prefixMatch=True)
	assert candidate(u'foo')(lambda x:x)
	assert candidate(u'foo', True)!= candidate(u'foo')
	assert candidate("test", True)
	assert candidate(1, True)!= candidate(1, False)
	assert candidate(1).__name__ == 'inner'
	assert candidate(u"foo", True)(lambda x: x)
	assert candidate(u'foo').__name__ == 'inner'
	assert candidate(u'foo').__module__ == __name__
	assert candidate(u"foo", "bar")(lambda x: x)
	assert candidate(1, True) is not None
	assert candidate(1, prefixMatch=True)!= candidate(1, prefixMatch=False)
	assert candidate(u"foo", False)(lambda x: x)
	assert candidate(u'foo.bar.baz.qux.#', True)(lambda x:x)
	assert candidate(1, True)
	assert candidate(1, prefixMatch = True) is not None
	assert candidate(1, prefixMatch = True)!= candidate(1)
	assert candidate(1)
	assert candidate(u'foo.bar.baz.qux', True)(lambda x:x)
	assert candidate(u"foo").__name__ == "inner"
	assert candidate(1, prefixMatch=True)!= candidate(2, prefixMatch=False)
	assert candidate(u'foo').__doc__ is None
	assert candidate(1)!= candidate(2)
	assert candidate(3).__name__ == 'inner'
	assert candidate("prefix", False)
	assert candidate(u"foo")(lambda x: x)
	assert candidate(1) is not None
	assert candidate(u'foo', prefixMatch = True).__doc__ is None
	assert candidate(u"foo", prefixMatch = True)(lambda x: x)
	assert candidate(7).__name__ == 'inner'
	assert candidate(123, True)(lambda: None)._autobahn_sub_prefix_match == True
	assert candidate(2, True) is not None
	assert candidate(1, prefixMatch=True)!= candidate(2, prefixMatch=True)
	assert candidate("test")
	assert candidate(1, True)!= candidate(2, False)
	assert candidate(1)!= candidate(2, True)
	assert candidate(u"foo")
def test_check():
	check(exportSub)
