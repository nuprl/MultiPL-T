def to_list(value):
    """ 
     Puts value into a list if it's not already one.
     Returns an empty list if value is None.
     """
	### Canonical solution below ###    
    if value is None:
        value = []
    elif not isinstance(value, list):
        value = [value]
    return value

### Unit tests below ###
def check(candidate):
	assert candidate(5) == [5]
	assert candidate(["test"]) == ["test"]
	assert candidate([3]) == [3]
	assert candidate(None) == []
	assert candidate("test") == ["test"]
	assert candidate('one') == ['one']
	assert candidate(['foo', 'bar']) == ['foo', 'bar']
	assert candidate(1) == [1]
	assert candidate(['a']) == ['a']
	assert candidate(['two', 'three']) == ['two', 'three']
	assert candidate(["a", "b"]) == ["a", "b"]
	assert candidate('a') == ['a']
	assert candidate('test') == ['test']
	assert candidate(['foo']) == ['foo']
	assert candidate(['test']) == ['test']
	assert candidate([4]) == [4]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate(3) == [3]
	assert candidate([1, 2]) == [1, 2]
	assert candidate(["b"]) == ["b"]
	assert candidate('foo') == ['foo']
	assert candidate([1]) == [1]
	assert candidate("a") == ["a"]
	assert candidate(['b', 'c']) == ['b', 'c']
	assert candidate(['a', 'b']) == ['a', 'b']
	assert candidate([1,2,3]) == [1,2,3]
	assert candidate("abc") == ["abc"]
	assert candidate(["abc"]) == ["abc"]
def test_check():
	check(to_list)
