def MakeFindPackage(modules):
    """ 
     Make a useful find_package command.
     """
	### Canonical solution below ###    
    # Print a useful cmake command
    res = 'find_package(VTK COMPONENTS\n'
    for module in sorted(modules):
        res += '  ' + module.replace('VTK::', 'vtk') + '\n'
    res += ')'
    return res

### Unit tests below ###
def check(candidate):
	assert candidate(set()) == 'find_package(VTK COMPONENTS\n)'
	assert candidate({'vtkIOXML'}) == 'find_package(VTK COMPONENTS\n  vtkIOXML\n)'
	assert candidate({'VTK::a', 'VTK::b', 'VTK::c'}) == 'find_package(VTK COMPONENTS\n  vtka\n  vtkb\n  vtkc\n)'
	assert candidate({'VTK::a'}) == 'find_package(VTK COMPONENTS\n  vtka\n)'
	assert candidate({'vtkIOXML', 'vtkIOXMLParser'}) == 'find_package(VTK COMPONENTS\n  vtkIOXML\n  vtkIOXMLParser\n)'
	assert candidate({'VTK::a', 'VTK::b'}) == 'find_package(VTK COMPONENTS\n  vtka\n  vtkb\n)'
	assert candidate(set(['VTK::Rendering'])) == "find_package(VTK COMPONENTS\n  vtkRendering\n)"
	assert candidate({'vtkRenderingContextOpenGL2'}) == 'find_package(VTK COMPONENTS\n  vtkRenderingContextOpenGL2\n)'
	assert candidate(set(['VTK::CommonCore'])) == \
    'find_package(VTK COMPONENTS\n  vtkCommonCore\n)'
	assert candidate(set(['VTK::RenderingCore'])) == """find_package(VTK COMPONENTS
  vtkRenderingCore
)"""
def test_check():
	check(MakeFindPackage)
