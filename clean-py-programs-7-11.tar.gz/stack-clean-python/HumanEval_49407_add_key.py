def add_key(rec, idx):
    """Add a key value to the character records."""
    ### Canonical solution below ###

    rec["_key"] = idx
    return rec


### Unit tests below ###
def check(candidate):
	assert candidate(dict(name="Fred"), 1)["_key"] == 1
	assert candidate(dict(), 1) == {"_key": 1}
	assert candidate(rec=dict(name="John", _key=2), idx=2) == dict(name="John", _key=2)
	assert candidate(dict(name="a"), 0)["_key"] == 0
	assert candidate(dict(), "Hello") == {"_key": "Hello"}
	assert candidate(dict(), "") == {"_key": ""}
	assert candidate(dict(), "z") == {"_key": "z"}
	assert candidate(
    {"name": "Adam", "age": 25, "gender": "Male"}, 1
)["_key"] == 1
	assert candidate(dict(), "a") == {"_key": "a"}
	assert candidate({}, 1) == {"_key": 1}
	assert candidate(dict(), None) == {"_key": None}
	assert candidate(rec=dict(name="John", _key=2), idx=1) == dict(name="John", _key=1)
	assert candidate(dict(name="a"), 0) == {"name": "a", "_key": 0}
	assert candidate(dict(), 0) == {"_key": 0}
	assert candidate(dict(), "A") == {"_key": "A"}
	assert candidate(
    {"name": "<NAME>", "occupation": "Researcher"}, 42)["_key"] == 42
	assert candidate(rec=dict(name="John", _key=2), idx=3) == dict(name="John", _key=3)
	assert candidate(dict(), -1) == {"_key": -1}
	assert candidate(dict(), "Z") == {"_key": "Z"}
	assert candidate(dict(), 100) == {"_key": 100}
	assert candidate(candidate({}, 0), 1) == {"_key": 1}
	assert candidate(dict(), True) == {"_key": True}
	assert candidate(dict(), 3.14) == {"_key": 3.14}
	assert candidate(dict(), "1") == {"_key": "1"}
	assert candidate(dict(name="Wilma"), 2)["_key"] == 2
	assert candidate(rec=dict(name="John"), idx=1) == dict(name="John", _key=1)
def test_check():
	check(add_key)
