def radix_sort(lst):
    """ Implement radix sort algorithm."""
	### Canonical solution below ###    
    if len(lst) < 2:
        return lst

    def fill_buckets(lst, iteration):
        """Divide."""
        buckets = [[] for x in range(10)]
        for number in lst:
            digit = (number // (10 ** iteration)) % 10
            buckets[digit].append(number)
        return buckets

    def empty_buckets(buckets):
        """Conquer."""
        lst = []
        for bucket in buckets:
            for number in bucket:
                lst.append(number)
        return lst

    largest = max(lst)
    iteration = 0

    while 10 ** iteration <= largest:
        lst = empty_buckets(fill_buckets(lst, iteration))
        iteration += 1

    return lst

### Unit tests below ###
def check(candidate):
	assert candidate([2, 5, 3, 4, 1]) == [1, 2, 3, 4, 5]
	assert candidate(candidate([5, 4, 3, 2, 1])) == [1, 2, 3, 4, 5]
	assert candidate([3, 2, 1, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate([3, 1, 2, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate(candidate([13, 5, 2, 7, 1, 9])) == [1, 2, 5, 7, 9, 13]
	assert candidate([1, 3, 5, 4, 2]) == [1, 2, 3, 4, 5]
	assert candidate([6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6]
	assert candidate([2, 3, 1]) == [1, 2, 3]
	assert candidate([11, 13, 17, 21, 42, 57]) == [11, 13, 17, 21, 42, 57]
	assert candidate(candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([5, 3, 2, 8, 1, 4, 7, 6]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(
    [329, 457, 657, 839, 436, 720, 355]) == [329, 355, 436, 457, 657, 720, 839]
	assert candidate(list()) == list()
	assert candidate(candidate([1, 5, 2])) == [1, 2, 5]
	assert candidate(candidate([1, 3, 5, 4, 2])) == [1, 2, 3, 4, 5]
	assert candidate(candidate([10, 9, 8, 7, 6, 5, 4, 3, 2, 1])) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([6, 5, 3, 1, 8, 7, 2, 4]) == [1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate([3, 1, 2]) == [1, 2, 3]
	assert candidate(candidate([10, 8, 6, 4, 2])) == [2, 4, 6, 8, 10]
	assert candidate(candidate([1, 2, 3, 4, 5])) == [1, 2, 3, 4, 5]
	assert candidate([13, 21, 42, 57]) == [13, 21, 42, 57]
	assert candidate([3, 30, 34, 5, 9]) == [3, 5, 9, 30, 34]
	assert candidate([2, 3, 1, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
	assert candidate([13, 14, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
	assert candidate(
    [0, 3, 4, 9, 5, 1, 8, 7, 2, 6]) == candidate(
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
	assert candidate([11, 13, 21, 42, 57]) == [11, 13, 21, 42, 57]
	assert candidate(
    [54, 26, 93, 17, 77, 31, 44, 55, 20]) == [17, 20, 26, 31, 44, 54, 55, 77, 93]
	assert candidate(candidate([9, 7, 5, 3, 1])) == [1, 3, 5, 7, 9]
	assert candidate([11, 13, 21, 42, 57, 17]) == [11, 13, 17, 21, 42, 57]
	assert candidate([1, 5, 3, 4, 2]) == [1, 2, 3, 4, 5]
	assert candidate(
    [170, 45, 75, 90, 802, 24, 2, 66, 23, 77, 31, 44, 55, 190]) == [2, 23, 24, 31, 44, 45, 55, 66, 75, 77, 90, 170, 190, 802]
	assert candidate([2, 1]) == [1, 2]
	assert candidate([]) == []
	assert candidate([5, 1, 3, 4, 2]) == [1, 2, 3, 4, 5]
	assert candidate([5, 1, 3, 4, 2, 10, 20, 30, 40, 50]) == [1, 2, 3, 4, 5, 10, 20, 30, 40, 50]
	assert candidate([1]) == [1]
	assert candidate([13, 42, 57, 21]) == [13, 21, 42, 57]
	assert candidate([1, 2]) == [1, 2]
	assert candidate([3, 2, 1]) == [1, 2, 3]
	assert candidate([42, 57]) == [42, 57]
	assert candidate([10, 2, 3, 4, 5, 6, 7, 8, 9, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([3, 5, 4, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate(list(range(10))) == list(range(10))
	assert candidate(candidate([5, 1, 2])) == [1, 2, 5]
	assert candidate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
	assert candidate([42]) == [42]
	assert candidate([57, 42]) == [42, 57]
	assert candidate([2, 1, 3]) == [1, 2, 3]
	assert candidate(candidate([4, 3, 5, 2, 1])) == [1, 2, 3, 4, 5]
	assert candidate(candidate([5, 2, 1])) == [1, 2, 5]
	assert candidate(
    [0, 3, 4, 9, 5, 1, 8, 7, 2, 6]) == candidate(
    [6, 5, 4, 3, 2, 1, 0, 9, 8, 7])
	assert candidate(candidate([3, 2, 1, 6, 5, 4])) == [1, 2, 3, 4, 5, 6]
	assert candidate([329, 457, 657, 839, 436, 720, 355, 436]) == [329, 355, 436, 436, 457, 657, 720, 839]
	assert candidate(candidate([5, 13, 2, 7, 1, 9])) == [1, 2, 5, 7, 9, 13]
	assert candidate(candidate([54, 26, 93, 17, 77, 31, 44, 55, 20])) == [17, 20, 26, 31, 44, 54, 55, 77, 93]
	assert candidate([5, 3, 4, 2, 1]) == [1, 2, 3, 4, 5]
	assert candidate(candidate([45, 5, 4, 3, 2, 1])) == [1, 2, 3, 4, 5, 45]
	assert candidate([1, 2, 3]) == [1, 2, 3]
	assert candidate([4, 6, 2, 7, 1, 3, 9, 8, 0, 5]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([42, 57, 13]) == [13, 42, 57]
	assert candidate(candidate([2, 4, 6, 8, 10])) == [2, 4, 6, 8, 10]
	assert candidate(
    [170, 45, 75, 90, 802, 24, 2, 66]) == [2, 24, 45, 66, 75, 90, 170, 802]
	assert candidate([5]) == [5]
	assert candidate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([2, 1, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 3, 2]) == [1, 2, 3]
	assert candidate([5, 3, 2, 8, 1, 4]) == [1, 2, 3, 4, 5, 8]
	assert candidate([13, 21, 42, 57, 11]) == [11, 13, 21, 42, 57]
	assert candidate([10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(candidate([13, 2, 5, 7, 1, 9])) == [1, 2, 5, 7, 9, 13]
	assert candidate([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
	assert candidate(list(range(100))) == list(range(100))
	assert candidate(candidate([2, 5, 1])) == [1, 2, 5]
	assert candidate(candidate([1, 3, 5, 7, 9])) == [1, 3, 5, 7, 9]
	assert candidate([5, 2, 3, 1, 4]) == [1, 2, 3, 4, 5]
	assert candidate([13, 42, 57]) == [13, 42, 57]
	assert candidate(candidate([1, 2, 5])) == [1, 2, 5]
	assert candidate([14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
	assert candidate(
    [0, 3, 4, 9, 5, 1, 8, 7, 2, 6]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
	assert candidate([1, 3, 4, 5, 2]) == [1, 2, 3, 4, 5]
	assert candidate(candidate([2, 13, 5, 7, 1, 9])) == [1, 2, 5, 7, 9, 13]
	assert candidate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate([10, 11, 2, 3, 4, 5, 6, 7, 8, 9]) == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
	assert candidate([10, 2, 3, 4, 5, 6, 7, 8, 9, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
	assert candidate(candidate([2, 1, 5])) == [1, 2, 5]
	assert candidate(list()) == []
	assert candidate(
    [0, 3, 4, 9, 5, 1, 8, 7, 2, 6]) == candidate(
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0])
	assert candidate(candidate([1, 3, 5, 2, 4])) == [1, 2, 3, 4, 5]
def test_check():
	check(radix_sort)
