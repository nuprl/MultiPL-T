def convert_iobes_to_bracket(tag):
    """ 
     Convert tags from the IOBES scheme to the CoNLL bracketing.
     
     Example:
     B-A0 -> (A0*
     I-A0 -> *
     E-A0 -> *)
     S-A1 -> (A1*)
     O    -> *
     """
	### Canonical solution below ###    
    if tag.startswith('I') or tag.startswith('O'):
        return '*'
    if tag.startswith('B'):
        return '(%s*' % tag[2:]
    if tag.startswith('E'):
        return '*)'
    if tag.startswith('S'):
        return '(%s*)' % tag[2:]
    else:
        raise ValueError("Unknown tag: %s" % tag)

### Unit tests below ###
def check(candidate):
	assert candidate(
    'B-A0-B1') == '(A0-B1*'
	assert candidate(u'O-A1-B1') == u'*'
	assert candidate( 'O' ) == '*'
	assert candidate('S-A1') == '(A1*)'
	assert candidate(
    'B-A0') == '(A0*'
	assert candidate(u'S-A1-B1') == u'(%s*)' % u'A1-B1'
	assert candidate(
    'S-A1') == '(%s*)' % 'A1'
	assert candidate(
    "O") == "*"
	assert candidate(u'B-A0-B1') == u'(%s*' % u'A0-B1'
	assert candidate( 'E-A0' ) == '*)'
	assert candidate(
    'O') == '*'
	assert candidate(
    'S-A1-S2-S3') == '(A1-S2-S3*)'
	assert candidate('S-A0') == '(%s*)' % 'A0'
	assert candidate(u'S-A1') == u'(%s*)' % u'A1'
	assert candidate(u'O') == u'*'
	assert candidate('O') == '*'
	assert candidate(
    "E-A0") == "*%s" % ")"
	assert candidate(u"O") == u"*"
	assert candidate(u'E-A0') == u'*)'
	assert candidate(u"I-A0") == u"*"
	assert candidate('S-A0') == '(A0*)'
	assert candidate(u'B-A0') == u'(%s*' % u'A0'
	assert candidate(u'I-A0-B1') == u'*'
	assert candidate('I-A0') == '*'
	assert candidate(tag='S-A1') == '(A1*)'
	assert candidate(tag='I-A0') == '*'
	assert candidate(tag='E-A0') == '*)'
	assert candidate(tag='B-A0-X') == '(A0-X*'
	assert candidate(
    'B-A0-B1-B2') == '(A0-B1-B2*'
	assert candidate(
    'E-A0-E1-E2') == '*)'
	assert candidate(u"S-A1") == u"(A1*)"
	assert candidate(u'B-A0') == u'(A0*'
	assert candidate( 'O'    ) == '*'
	assert candidate(
    'E-A0') == '*)'
	assert candidate('B-A0') == '(A0*'
	assert candidate(
    'S-A1-S2') == '(A1-S2*)'
	assert candidate(
    "B-A0") == "(%s*" % "A0"
	assert candidate(
    "S-A1") == "(%s*)" % "A1"
	assert candidate(u'E-A0-B1') == u'*)'
	assert candidate(tag='S-A0') == '(A0*)'
	assert candidate(tag='B-A0') == '(A0*'
	assert candidate(tag='O') == '*'
	assert candidate(
    'E-A0-E1') == '*)'
	assert candidate('E-A0') == '*)'
	assert candidate(u'I-A0') == u'*'
	assert candidate( 'B-A0' ) == '(A0*'
	assert candidate( 'S-A1' ) == '(A1*)'
	assert candidate(u"E-A0") == u"*)"
	assert candidate(tag='E-A0-X') == '*)'
	assert candidate(
    'B-A0') == '(%s*' % 'A0'
	assert candidate(tag='S-A1-X') == '(A1-X*)'
	assert candidate(u'S-A1') == u'(A1*)'
	assert candidate(
    'S-A1') == '(A1*)'
def test_check():
	check(convert_iobes_to_bracket)
