def prt2tpg(portals):
    """ Convert list of dicts to list.
     
     :param portals: list of portals dicts
     :returns flat list of portals
     """
	### Canonical solution below ###    
    tpg = []
    for portal in portals:
        hostport = '%(host)s:%(port)s' % {
            'host': portal['address'],
            'port': portal['port']
        }
        tpg.append(hostport)
    return tpg

### Unit tests below ###
def check(candidate):
	assert candidate(
    [
        {'address': '10.10.10.10', 'port': '6000'},
        {'address': '10.10.10.11', 'port': '6000'}
    ]
) == ['10.10.10.10:6000', '10.10.10.11:6000']
	assert candidate(
    [{
        'address': '10.10.10.10',
        'port': 12345,
    }, {
        'address': '10.10.10.11',
        'port': 12345,
    }]
) == ['10.10.10.10:12345', '10.10.10.11:12345']
	assert candidate(
    [
        {'address': '10.0.0.1', 'port': '3000'},
        {'address': '10.0.0.2', 'port': '3000'},
        {'address': '10.0.0.3', 'port': '3000'},
        {'address': '10.0.0.4', 'port': '3000'},
    ]
) == [
    '10.0.0.1:3000',
    '10.0.0.2:3000',
    '10.0.0.3:3000',
    '10.0.0.4:3000',
]
	assert candidate(
    [{
        'address': '1.1.1.1',
        'port': 1
    }, {
        'address': '2.2.2.2',
        'port': 2
    }]
) == ['1.1.1.1:1', '2.2.2.2:2']
	assert candidate(
    [
        {
            'address': '1.2.3.4',
            'port': 6000
        },
        {
            'address': '5.6.7.8',
            'port': 6001
        }
    ]
) == ['1.2.3.4:6000', '5.6.7.8:6001']
	assert candidate(
    [{'address': '1.2.3.4', 'port': '6000'},
     {'address': '5.6.7.8', 'port': '7000'}]
) == ['1.2.3.4:6000', '5.6.7.8:7000']
def test_check():
	check(prt2tpg)
