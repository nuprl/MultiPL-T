def mermin_klyshko_quantum_bound(n):
    """ The quantum bound for the Mermin-Klyshko inequality is :math:`2^{3(n-1)/2}`.
     
     :param n: The number of measurement nodes.
     :type n: Int
     
     :returns: The quantum bound.
     :rtype: Float
     """
	### Canonical solution below ###    
    return 2 ** (3 * (n - 1) / 2)

### Unit tests below ###
def check(candidate):
	assert candidate(4) == 2 ** (3 * 3 / 2)
	assert candidate(2) == 2 ** (3 / 2)
	assert candidate(5) == 64
	assert candidate(10) == 2 ** (3 * 9 / 2)
	assert candidate(1) == 1
	assert candidate(3) == 8
def test_check():
	check(mermin_klyshko_quantum_bound)
