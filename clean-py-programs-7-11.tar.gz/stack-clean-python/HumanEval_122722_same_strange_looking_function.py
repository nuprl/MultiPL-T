def same_strange_looking_function(param1, callback_fn):
    """ 
     This function is documented, but the function is identical to some_strange_looking_function
     and should result in the same hash
     """
	### Canonical solution below ###    
    tail = param1[-1]
    # return the callback value from the tail of param whatever that is
    return callback_fn(tail)

### Unit tests below ###
def check(candidate):
	assert candidate(
    "abcdefghi",
    lambda x: x
) == "i"
	assert candidate(param1="l", callback_fn=str) == "l"
	assert candidate(
    'world', lambda x: x.upper()) == 'D'
	assert candidate(
    '1234',
    lambda x: x * 2
) == candidate(
    '1234',
    lambda x: x * 2
)
	assert candidate(
    "hello", lambda x: x + "!") == "o!"
	assert candidate(param1="h", callback_fn=str) == "h"
	assert candidate("abcd", lambda x: x) == "d"
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz",
    lambda x: x.lower()
) == "z"
	assert candidate(
    "abcdefghijklmn",
    lambda x: x
) == "n"
	assert candidate(
    "hello",
    lambda x: x.lower()
) == "o"
	assert candidate(
    "123456",
    lambda x: x,
) == "6"
	assert candidate(param1="c", callback_fn=str) == "c"
	assert candidate(
    'hello',
    lambda x: x) == 'o'
	assert candidate(
    "abcdefghijkl",
    lambda x: x
) == "l"
	assert candidate(
    'hello', lambda x: x.lower()) == 'o'
	assert candidate(
    "some string", lambda x: x) == "g"
	assert candidate(
    "abcdefghijklmnop",
    lambda x: x
) == "p"
	assert candidate(param1="i", callback_fn=str) == "i"
	assert candidate(
    "abcde", lambda x: x * 3
) == "eee", "candidate did not work"
	assert candidate(param1="f", callback_fn=str) == "f"
	assert candidate(
    "abcdefghij",
    lambda x: x
) == "j"
	assert candidate(param1="e", callback_fn=str) == "e"
	assert candidate(
    '1234567890',
    lambda tail: tail[0],
) == '0'
	assert candidate.__hash__()!= candidate("Hello World", lambda x: x).__hash__()
	assert candidate(
    "abcdefgh",
    lambda x: x
) == "h"
	assert candidate(
    "abcdefghijklmno",
    lambda x: x
) == "o"
	assert candidate(
    "Hello", lambda x: x) == "o"
	assert candidate(
    "world",
    lambda x: x
) == "d"
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz",
    lambda x: x
) == "z"
	assert candidate(
    'Hello World',
    lambda x: x) == 'd', "Expected 'd' but got %s" % (candidate(
        'Hello World',
        lambda x: x))
	assert candidate(
    "hello",
    lambda x: x.upper()
) == "O"
	assert candidate(
    'hello', lambda x: x.upper()) == 'O'
	assert candidate(
    "some_string",
    lambda x: x
) == "g"
	assert candidate(param1="k", callback_fn=str) == "k"
	assert candidate(param1="d", callback_fn=str) == "d"
	assert candidate(
    "abcd", lambda tail: tail[0]
) == "d"
	assert candidate(param1="o", callback_fn=str) == "o"
	assert candidate(
    '1234',
    lambda x: x
) == '4'
	assert candidate(
    "abcd",
    lambda x: x.upper()
) == "D"
	assert candidate(param1="a", callback_fn=str) == "a"
	assert candidate(
    "Hello World",
    lambda x: x.upper()
) == "D"
	assert candidate(
    'hello',
    lambda x: x) == candidate(
        'hello',
        lambda x: x)
	assert candidate(param1="g", callback_fn=str) == "g"
	assert candidate(
    "abcd", lambda tail: tail
) == "d"
	assert candidate(param1="m", callback_fn=str) == "m"
	assert candidate(
    "abcdefghijklm",
    lambda x: x
) == "m"
	assert candidate(
    'world', lambda x: x.lower()) == 'd'
	assert candidate(
    "abcde", lambda x: x
) == "e", "candidate did not work"
	assert candidate(
    "another string", lambda x: x) == "g"
	assert candidate(
    '1234',
    lambda x: x * 2
)!= candidate(
    '1234',
    lambda x: x * 3
)
	assert candidate(
    "abcde",
    lambda x: x
) == "e"
	assert candidate(
    '1234',
    lambda x: x * 2
) == '44'
	assert candidate(param1="j", callback_fn=str) == "j"
	assert candidate(
    "abcdefghijklmnopqr",
    lambda x: x
) == "r"
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz",
    lambda x: x.upper()
) == "Z"
	assert candidate(
    "Hello", lambda x: x.upper()) == "O"
	assert candidate(
    "abc",
    lambda x: x
) == "c"
	assert candidate(
    '1234567890',
    lambda tail: tail,
) == '0'
	assert candidate(
    "Hello World",
    lambda x: x
) == "d"
	assert candidate(
    "hello",
    lambda x: x
) == "o"
	assert candidate(param1="b", callback_fn=str) == "b"
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz",
    lambda x: x.capitalize()
) == "Z"
	assert candidate(
    "abcde", lambda x: x * 2
) == "ee", "candidate did not work"
	assert candidate(
    "Hello", lambda x: x.lower()) == "o"
	assert candidate(
    "abcdef",
    lambda x: x
) == "f"
	assert candidate(
    "hello world",
    lambda x: x
) == "d"
	assert candidate.__hash__()!= candidate("Hello World", lambda x: x.upper()).__hash__()
	assert candidate(
    "hello", lambda x: x) == "o"
	assert candidate(
    "foo", lambda x: x) == "o"
	assert candidate(
    "abcdefghijklmnopq",
    lambda x: x
) == "q"
	assert candidate(
    "abcd",
    lambda x: x
) == "d"
	assert candidate(
    "foo", lambda x: x*2) == "oo"
	assert candidate(
    "foo", lambda x: x*4) == "oooo"
	assert candidate(
    "abcdefghijk",
    lambda x: x
) == "k"
	assert candidate(param1="n", callback_fn=str) == "n"
	assert candidate(
    "foo", lambda x: x*3) == "ooo"
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz",
    lambda x: x.title()
) == "Z"
	assert candidate(
    "abcdefghijklmnopqrstuvwxyz",
    lambda x: x.swapcase()
) == "Z"
def test_check():
	check(same_strange_looking_function)
