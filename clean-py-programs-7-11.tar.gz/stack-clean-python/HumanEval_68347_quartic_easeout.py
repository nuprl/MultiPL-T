def quartic_easeout(pos):
    """ 
     Easing function for animations: Quartic Ease Out
     """
	### Canonical solution below ###    
    fos = pos - 1
    return fos * fos * fos * (1 - pos) + 1

### Unit tests below ###
def check(candidate):
	assert candidate(1.0) == 1.0
	assert candidate(0.0) == 0.0
	assert candidate(1) == 1
	assert candidate(0) == 0
def test_check():
	check(quartic_easeout)
