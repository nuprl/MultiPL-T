def google_get_category(types_array):
    """ 
     Parameters:
     types_array consists of the "types" field that can be found in the google raw_response
     
     Output:
     categories_string: string
     
     Returns a concatenated string of the different types
     """
	### Canonical solution below ###    
    categories_string = None
    if types_array:
        categories_string = ', '.join(types_array)
    return categories_string

### Unit tests below ###
def check(candidate):
	assert candidate(types_array=['test1', 'test2']) == 'test1, test2'
	assert candidate(types_array=None) == None
	assert candidate(['food', 'cafe']) == 'food, cafe'
	assert candidate(['restaurant', 'cafe']) =='restaurant, cafe'
	assert candidate(["point of interest", "establishment"]) == "point of interest, establishment"
	assert candidate([]) == None
	assert candidate(["restaurant", "food"]) == "restaurant, food"
	assert candidate(None) == None
	assert candidate(None) is None
	assert candidate(['A', 'B', 'C']) == 'A, B, C'
	assert candidate(['bar', 'foo']) == 'bar, foo'
	assert candidate(["point of interest"]) == "point of interest"
	assert candidate(None) == None, 'Should be None'
	assert candidate(['restaurant']) =='restaurant'
	assert candidate(types_array=[]) == None, 'Should be None'
	assert candidate(['bar', 'baz']) == 'bar, baz'
	assert candidate(types_array=['test']) == 'test'
	assert candidate(['A', 'B']) == 'A, B'
	assert candidate(['A']) == 'A'
	assert candidate(['restaurant', 'food']) =='restaurant, food'
def test_check():
	check(google_get_category)
