def expression_depth(expr):
    """Given an expression expressed as Python lists, uses recursion to return
    the depth of the expression, where depth is defined by the maximum number of
    nested operations."""
    ### Canonical solution below ###
    if not isinstance(expr, list):
        return 0
    return max(map(expression_depth, expr)) + 1


### Unit tests below ###
def check(candidate):
	assert candidate([1,2,3]) == 1
	assert candidate([5, 6, [7, 8, [9, 10]]]) == 3
	assert candidate([1,2,[1,2,3]]) == 2
	assert candidate(5) == 0
	assert candidate([1, 2]) == 1
	assert candidate([5, 6, [7, 8]]) == 2
	assert candidate(1) == 0
	assert candidate([1, [2, 3]]) == 2
	assert candidate([3, [4, 5]]) == 2
	assert candidate([1, '+', 2]) == 1
	assert candidate([5, 6, 7]) == 1
	assert candidate([5]) == 1
	assert candidate([1,2,[1,2,[1,2,3]]]) == 3
	assert candidate([5, 6]) == 1
	assert candidate([1,[2,3]]) == 2
	assert candidate([1, [2, 3], 4]) == 2
	assert candidate([1, [2, [3, 4]]]) == 3
	assert candidate([1, '+', [2, '*', 3]]) == 2
	assert candidate([1, 2, 3]) == 1
	assert candidate(3) == 0
	assert candidate(None) == 0
	assert candidate([[1, 2], [3, 4]]) == 2
	assert candidate(
    ['/', ['+', 1, ['*', 2, 3]], ['-', 4, 5]]) == 3
	assert candidate([1,[2,[3]]]) == 3
	assert candidate([3, [4, [5, 6]]]) == 3
	assert candidate([1]) == 1
	assert candidate([1, [2, [3, 4]], 5]) == 3
	assert candidate([3, 4]) == 1
def test_check():
	check(expression_depth)
