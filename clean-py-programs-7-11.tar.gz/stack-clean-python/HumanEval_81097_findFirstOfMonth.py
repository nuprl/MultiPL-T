def findFirstOfMonth(date):
    """change date to the first of the following month.
    If the date already is the first of the month, no change"""
    ### Canonical solution below ###
    if date[2] == 1:
        return date
    
    date[2] = 1
    date[1] += 1
    if date[1] > 12:
        date[1] = 1
        date[0] += 1
    return date


### Unit tests below ###
def check(candidate):
	assert candidate( [2015, 2, 1] ) == [2015, 2, 1]
	assert candidate( [2015, 1, 15] ) == [2015, 2, 1]
	assert candidate( [2015, 12, 15] ) == [2016, 1, 1]
	assert candidate( [ 2016, 2, 29 ] ) == [ 2016, 3, 1 ]
	assert candidate( [ 2000, 1, 1 ] ) == [ 2000, 1, 1 ]
	assert candidate( [ 2000, 12, 31 ] ) == [ 2001, 1, 1 ]
def test_check():
	check(findFirstOfMonth)
