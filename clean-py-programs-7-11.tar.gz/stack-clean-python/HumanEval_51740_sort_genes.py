def sort_genes(gene_dict, key):
    """ Return list of genes ordered by key, in descending order
     """
	### Canonical solution below ###    
    sorted_genes = sorted(
        gene_dict.items(), key=lambda x: x[1][key],
        reverse=True
    )

    # print(f"Gene with highest {key}: {str(sorted_genes[0])}")

    return sorted_genes

### Unit tests below ###
def check(candidate):
	assert candidate(
    {'a': {'a': 1, 'b': 2}, 'b': {'a': 3, 'b': 4}}, 'a'
)[0][0] == 'b'
	assert candidate(
    {
        'A': {'length': 100, 'gc': 0.5},
        'B': {'length': 200, 'gc': 0.4},
        'C': {'length': 50, 'gc': 0.3}
    },
    'length'
) == [('B', {'length': 200, 'gc': 0.4}), ('A', {'length': 100, 'gc': 0.5}), ('C', {'length': 50, 'gc': 0.3})]
	assert candidate(
    {"a": {"a": 0, "b": 1}, "b": {"a": 2, "b": 3}},
    "b"
) == [("b", {"a": 2, "b": 3}), ("a", {"a": 0, "b": 1})]
def test_check():
	check(sort_genes)
