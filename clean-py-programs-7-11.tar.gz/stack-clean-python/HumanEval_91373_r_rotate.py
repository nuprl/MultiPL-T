def r_rotate(lst, i):
    """ RIGHTROTATE """
    ### Canonical solution below ###
    return lst[-i:] + lst[:-i]


### Unit tests below ###
def check(candidate):
	assert candidate(list(range(10)), 6) == [4, 5, 6, 7, 8, 9, 0, 1, 2, 3]
	assert candidate(list(range(10)), 4) == [6, 7, 8, 9, 0, 1, 2, 3, 4, 5]
	assert candidate(list(range(5)), 6) == [0, 1, 2, 3, 4]
	assert candidate(list(range(10)), 2) == [8, 9, 0, 1, 2, 3, 4, 5, 6, 7]
	assert candidate(list(range(5)), 5) == [0, 1, 2, 3, 4]
	assert candidate(list('abcd'), 4) == list('abcd')
	assert candidate([], 1) == []
	assert candidate(['a'], 1) == ['a']
	assert candidate(list(range(5)), 1) == [4, 0, 1, 2, 3]
	assert candidate(list(range(10)), 5) == [5, 6, 7, 8, 9, 0, 1, 2, 3, 4]
	assert candidate(list(range(5)), 3) == [2, 3, 4, 0, 1]
	assert candidate(list('abcd'), 3) == list('bcda')
	assert candidate(list(range(10)), 3) == [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]
	assert candidate(list(range(10)), 8) == [2, 3, 4, 5, 6, 7, 8, 9, 0, 1]
	assert candidate(list('abcd'), 1) == list('dabc')
	assert candidate(list(range(10)), 7) == [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]
	assert candidate(list(range(5)), 4) == [1, 2, 3, 4, 0]
	assert candidate(list(range(5)), 2) == [3, 4, 0, 1, 2]
	assert candidate(list(range(10)), 1) == [9, 0, 1, 2, 3, 4, 5, 6, 7, 8]
	assert candidate(list('abcd'), 2) == list('cdab')
	assert candidate(list('abcd'), 0) == list('abcd')
def test_check():
	check(r_rotate)
