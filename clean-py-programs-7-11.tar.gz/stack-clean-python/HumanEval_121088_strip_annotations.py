def strip_annotations(annotations):
    """ 
     Recibe una lista de textos y quita los espacios al comienzo y final
     """
	### Canonical solution below ###    
    return [ann.strip() for ann in annotations]

### Unit tests below ###
def check(candidate):
	assert candidate(
    ["        a", "b       ", "        c"]) == ["a", "b", "c"]
	assert candidate(
    ['   a   ','  b   ','  c   ']) == ['a', 'b', 'c']
	assert candidate(
    ['   This is a sentence.   ','  This is another one.   ']) == [
        'This is a sentence.', 'This is another one.']
	assert candidate(
    ["    Este es un texto con espacios al principio y al final    "]) == ["Este es un texto con espacios al principio y al final"]
	assert candidate(
    ['     This is a test.     ', 'Another test.']) == \
    ['This is a test.', 'Another test.']
	assert candidate(
    ['  this is a test  ', 'this is another test  ']) == [
        'this is a test', 'this is another test']
	assert candidate(
    ['     This is a test.', 'Another test.     ']) == \
    ['This is a test.', 'Another test.']
	assert candidate(
    ['this is a test', 'this is another test']) == [
        'this is a test', 'this is another test']
	assert candidate(
    ["  Hola  ", "  adios  ", "  como estas  ", "  mi nombre  "]) == \
    ["Hola", "adios", "como estas", "mi nombre"]
	assert candidate(
    ["  hola", "  como estas  ", "  chao  "]
) == ["hola", "como estas", "chao"]
	assert candidate(
    ["   Este es un texto   ", " otro texto"]) == ["Este es un texto", "otro texto"]
	assert candidate(
    ['  1',' 2',' 3']) == ['1', '2', '3']
	assert candidate(
    [" a b c ", "d e f", "   ghi   ", "j k l ", "m n o ", "p q r s t u v"]) == [
    "a b c", "d e f", "ghi", "j k l", "m n o", "p q r s t u v"]
	assert candidate(
    ["A", "B", "C"]) == ["A", "B", "C"]
	assert candidate(
    ['1', '2', '3']) == ['1', '2', '3']
	assert candidate(
    ['foo  ', 'bar  ', 'baz  ']) == ['foo', 'bar', 'baz']
	assert candidate(
    ["  Hello, world!  ", "  Hello, world!  "]) == ["Hello, world!", "Hello, world!"]
	assert candidate([]) == []
	assert candidate(
    ['\t \t \t  foo  \t \t \t ',
     '\t \t \t  bar  \t \t \t ',
     '\t \t \t  baz  \t \t \t ']) == ['foo', 'bar', 'baz']
	assert candidate(
        ["  hola", "  como estas  ", "  chao  "]
    ) == ["hola", "como estas", "chao"]
	assert candidate(
    [' 1 ','2 ','3 ']) == ['1', '2', '3']
	assert candidate(
    ["  This is a sentence.  ", "This is a second sentence."]
) == ["This is a sentence.", "This is a second sentence."]
	assert candidate(
    ['  this is a test', 'this is another test  ']) == [
        'this is a test', 'this is another test']
	assert candidate(
    [' aaa ','bbb ','ccc ']) == ['aaa', 'bbb', 'ccc']
	assert candidate(
    ["Este es un texto sin espacios al principio y al final"]) == ["Este es un texto sin espacios al principio y al final"]
	assert candidate(
    ['     This is a test.     ', 'Another test.     ']) == \
    ['This is a test.', 'Another test.']
	assert candidate(
    ['foo\t', 'bar\t', 'baz\t']) == ['foo', 'bar', 'baz']
	assert candidate(
    ['   1','  2','  3']) == ['1', '2', '3']
	assert candidate(
    ["  Hello, world!  ", "  Hello, world!  ", "  Hello, world!  "]) == [
    "Hello, world!", "Hello, world!", "Hello, world!"]
	assert candidate(
    [" Este es un texto con espacios al principio"]) == ["Este es un texto con espacios al principio"]
	assert candidate(
    ["    This is a sentence.     ", "    This is another sentence.     "])!= [
        "    This is a sentence.     ", "    This is another sentence.     "]
	assert candidate(
    ['    Hello world    ','   How are you?    ']) == [
        'Hello world', 'How are you?']
	assert candidate(
    [" A ", " B ", " C "]) == ["A", "B", "C"]
	assert candidate(
    ["    This is a sentence.     ", "    This is another sentence.     "]) == [
        "This is a sentence.", "This is another sentence."]
	assert candidate(
    ['foo\t ', 'bar\t ', 'baz\t ']) == ['foo', 'bar', 'baz']
	assert candidate(
    ["Este es un texto con espacios al final "]) == ["Este es un texto con espacios al final"]
	assert candidate(
        ["hola", "como estas", "chao"]
    ) == ["hola", "como estas", "chao"]
	assert candidate(
        [""]
    ) == [""]
	assert candidate(
        []
    ) == []
	assert candidate(
    ['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']
	assert candidate(
    ["This is a sentence.", "This is another one."]) == [
        "This is a sentence.", "This is another one."], "Wrong output"
def test_check():
	check(strip_annotations)
