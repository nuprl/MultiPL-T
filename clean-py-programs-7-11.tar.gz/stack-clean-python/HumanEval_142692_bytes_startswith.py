def bytes_startswith(x: bytes, prefix: bytes) -> bool:
    """ Does given bytes object start with the subsequence prefix?
     
     Compiling bytes.startswith, with no range arguments, compiles this function.
     This function is only intended to be executed in this compiled form.
     
     Args:
     x: The bytes object to examine.
     prefix: The subsequence to look for.
     
     Returns:
     Result of check.
     """
	### Canonical solution below ###    
    if len(x) < len(prefix):
        return False
    index = 0
    for i in prefix:
        if x[index] != i:
            return False
        index += 1
    return True

### Unit tests below ###
def check(candidate):
	assert candidate(b'abc', b'ab')
	assert candidate(b'hello', b'hello')
	assert candidate(b"123456", b"12345")
	assert not candidate(b"", b"x")
	assert candidate(b'hello', b'hellox') == False
	assert candidate(b'Hello, world!', b'ello') == False
	assert candidate(b'abcdef', b'abc') == True
	assert candidate(b'hello', b'he')
	assert candidate(b"hello", b"hel")
	assert candidate(b'hello', b'') == True
	assert not candidate(b"123456", b"12345678")
	assert not candidate(b"abcdef", b"abcdefg")
	assert not candidate(b"hello", b"helloo")
	assert candidate(b'hello', b'he') == True
	assert candidate(b"x", b"x")
	assert candidate(b"", b"")
	assert candidate(b"abc", b"ab")
	assert not candidate(b'abc', bytearray(b'abcd'))
	assert not candidate(b"123456", b"1234578")
	assert candidate(b"ab", b"ab")
	assert candidate(b"abcdef", b"abcde")
	assert not candidate(b'abcdef', b'abd')
	assert not candidate(b"hello", b"o")
	assert candidate(b"hello", b"h")
	assert not candidate(b"123456", b"1234567")
	assert not candidate(b"123456", b"1234567890")
	assert not candidate(b"abcdef", b"abcdefgh")
	assert not candidate(b'abc', b'x')
	assert candidate(b'abc', b'a')
	assert candidate(b'Hello, world!', b'Hello, world!') == True
	assert not candidate(b'hello', b'el')
	assert not candidate(b'abc', (b'x', b'y'))
	assert not candidate(b"", b"a")
	assert candidate(b'abcdef', b'ab') == True
	assert not candidate(b'hello', b'ello')
	assert candidate(b"abc", b"a") is True
	assert candidate(b'Hello, world!', b'') == True
	assert not candidate(b'abc', b'bc')
	assert not candidate(b'abc', (b'd', b'e'))
	assert not candidate(b"hello", b"hxllo")
	assert candidate(b'abc', b'abc')
	assert candidate(b'abcdef', b'abcdef') == True
	assert candidate(b'hello', b'hello') == True
	assert not candidate(b"hello", b"hellox")
	assert candidate(b"123456", b"123456")
	assert not candidate(b"abc", b"abcd")
	assert candidate(b'abcdef', b'')
	assert candidate(b"foobar", b"foo")
	assert candidate(b"abc", b"") is True
	assert candidate(b'', b'Hello') == False
	assert not candidate(b"123456", b"123457890")
	assert candidate(b'hello', b'xhello') == False
	assert not candidate(b"foobar", b"foobarx")
	assert not candidate(b'abc', b'abcd')
	assert candidate(b'hello', b'hel') == True
	assert not candidate(b"123456", b"12345789")
	assert candidate(b"abcdef", b"abc")
	assert candidate(b'', b'') == True
	assert not candidate(b"abc", b"abcde")
	assert candidate(b'abcdef', b'abcd') == True
	assert not candidate(b"abc", b"abd")
	assert not candidate(b'abc', b'bcde')
	assert not candidate(b'abc', b'de')
	assert candidate(b"abc", b"abc")
	assert candidate(b'hello', b'hell') == True
	assert candidate(b'x', b'x') == True
	assert candidate(b'abc', bytearray(b'a'))
	assert candidate(b'abcdef', b'abcdefg') == False
	assert candidate(b'abcdef', b'abcdefghi') == False
	assert candidate(b"abc", b"abcd") is False
	assert candidate(b'abcdef', b'abcdefgh') == False
	assert not candidate(b"abc", b"cba")
	assert not candidate(b'abc', b'b')
	assert candidate(b'', b'')
	assert not candidate(b"ab", b"abc")
	assert not candidate(b'abc', b'abcde')
	assert not candidate(b"hello", b"x")
	assert candidate(b"abc", b"")
	assert not candidate(b'abc', bytearray(b'bc'))
	assert not candidate(b"foobar", b"foo bar")
	assert candidate(b"abc", b"abc") is True
	assert candidate(b'abcdef', b'abcdef')
	assert candidate(b'hello', b'hel')
	assert candidate(b'hello', b'h') == True
	assert candidate(b"123456", b"123")
	assert candidate(b'', b'x') == False
	assert candidate(b"hello", b"")
	assert candidate(b"abcdef", b"")
	assert candidate(b"abcdef", b"a")
	assert not candidate(b"123456", b"123456789")
	assert candidate(b"x", b"")
	assert not candidate(b"abc", b"cab")
	assert candidate(b"xx", b"x")
	assert not candidate(b"ab", b"bc")
	assert candidate(b"a", b"")
	assert not candidate(b'abc', b'cde')
	assert candidate(b'abc', bytearray(b''))
	assert candidate(b'abcdef', b'') == True
	assert candidate(b"ab", b"a")
	assert candidate(b"ab", b"")
	assert not candidate(b"hello", b"llo")
	assert not candidate(b"123456", b"123457")
	assert not candidate(b'abcdef', b'abcdefg')
	assert candidate(b"abcdef", b"ab")
	assert not candidate(b"foobar", b"bar")
	assert candidate(b'abc', bytearray(b'ab'))
	assert not candidate(b"abc", b"b")
	assert candidate(b'Hello, world!', b'Hello, world!!') == False
	assert candidate(b'hello', b'')
	assert not candidate(b"a", b"b")
	assert candidate(b'abc', b'')
	assert not candidate(b"abc", b"bac")
	assert candidate(b"a", b"a")
	assert not candidate(b"ab", b"c")
	assert not candidate(b"foobar", b"foobar ")
	assert candidate(b'abcdef', b'abc')
	assert candidate(b'abcdef', b'a') == True
	assert not candidate(b"foobar", b"foo bar baz")
	assert candidate(b"abc", b"a")
	assert not candidate(b"hello", b"lo")
	assert candidate(b'abcdef', b'abcde') == True
	assert not candidate(b"a", b"ab")
	assert candidate(b"hello", b"hello")
	assert candidate(b"hello", b"he")
	assert candidate(b"hello", b"hell")
	assert candidate(b"abc", b"ab") is True
	assert not candidate(b'', b'abc')
	assert candidate(b'Hello, world!', b'Hello') == True
	assert not candidate(b"abc", b"bc")
	assert not candidate(b"hello", b"ello")
	assert not candidate(b'hello', b'hello world')
	assert candidate(b"abcdef", b"abcd")
def test_check():
	check(bytes_startswith)
