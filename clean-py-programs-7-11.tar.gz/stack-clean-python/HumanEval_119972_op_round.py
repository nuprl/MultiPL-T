def op_round(x):
    """Returns the rounded version of this mathematical object."""
    ### Canonical solution below ###
    if isinstance(x, list):
        return [op_round(a) for a in x]
    elif isinstance(x, complex):
        return complex(round(x.real), round(x.imag))
    else:
        return round(x)


### Unit tests below ###
def check(candidate):
	assert candidate(1.4999999999999) == 1
	assert candidate(2.6) == 3.0
	assert candidate(10.8) == 11
	assert candidate([1.23456789j, 2.34567890, 3.45678901j]) == [1j, 2, 3j]
	assert candidate(-1.4) == -1
	assert candidate(2.00) == 2
	assert candidate(2.4) == 2
	assert candidate(-1j) == -1j
	assert candidate(1.5 + 0j) == 2 + 0j
	assert candidate(1.23456) == 1
	assert candidate(10.2 + 20.2j) == complex(10, 20)
	assert candidate(1.23) == 1
	assert candidate(-10.499999) == -10
	assert candidate(complex(-0.0, 2.2)) == complex(0, 2)
	assert candidate(3.14159265359) == 3.0
	assert candidate(-1.1) == -1
	assert candidate(-1j + 0j) == -1j + 0j
	assert candidate([3]) == [3]
	assert candidate(10.8 - 20.8j) == complex(11, -21)
	assert candidate(4.3) == 4
	assert candidate(complex(1, 2.2)) == complex(1, 2)
	assert candidate(-3.141592653589793) == -3
	assert candidate(1.23e20) == 1.23e+20
	assert candidate(-123456789.123456789) == -123456789
	assert candidate(100.51) == 101
	assert candidate(complex(3.999999999999999, 3.999999999999999)) == complex(4, 4)
	assert candidate(-1e-20) == 0
	assert candidate(-1.99) == -2
	assert candidate(2.6 + 1j) == complex(3, 1)
	assert candidate(complex(1.4, 2.4)) == complex(1, 2)
	assert candidate(-1.00000001) == -1
	assert candidate(-3.99999999999+4j) == -4+4j
	assert candidate(3+4j) == complex(candidate(3), candidate(4))
	assert candidate(-3.5) == -4
	assert candidate(-1.31) == -1
	assert candidate(3.999999999999999) == 4
	assert candidate(complex(-1.6, -2.6)) == complex(-2, -3)
	assert candidate(1.78) == 2
	assert candidate(-3.99999999999) == -4
	assert candidate(complex(0.4, 0.4)) == complex(0, 0)
	assert candidate(123456789.123456789) == 123456789
	assert candidate(-3) == -3
	assert candidate(1.23-2j) == 1-2j
	assert candidate(1.499) == 1
	assert candidate(-10.8) == -11
	assert candidate(-10.8 + 20.8j) == complex(-11, 21)
	assert candidate(-1.0) == -1
	assert candidate([3.14159265359]) == [3.0]
	assert candidate(complex(1.30, 4.56)) == complex(1, 5)
	assert candidate(complex(1.1, -2.2)) == complex(1, -2)
	assert candidate(-1.5+1j) == -2+1j
	assert candidate(10) == 10
	assert candidate(3.5+4j) == 4+4j
	assert candidate(1.2) == 1
	assert candidate([1.4, 2.2, 3.3]) == [1, 2, 3]
	assert candidate(1j) == 1j
	assert candidate(2.4 + 1j) == complex(2, 1)
	assert candidate(complex(-1.1, 2.2)) == complex(-1, 2)
	assert candidate(complex(1.29, 4.56)) == complex(1, 5)
	assert candidate(1.75+1j) == 2.0+1j
	assert candidate(-3.5+4j) == -4+4j
	assert candidate(complex(1.1, 2.2)) == complex(1, 2)
	assert candidate(0.5) == 0
	assert candidate(0.4) == 0
	assert candidate(10.2) == 10
	assert candidate(-1.0001) == -1
	assert candidate(10 + 20j) == complex(10, 20)
	assert candidate(1) == 1
	assert candidate(1.29) == 1
	assert candidate(1.6) == 2
	assert candidate(3.5) == 4.0
	assert candidate(1.75) == 2
	assert candidate(-2.6) == -3.0
	assert candidate(complex(-1.0, 2.2)) == complex(-1, 2)
	assert candidate(2.9 + 1j) == complex(3, 1)
	assert candidate(-1.5-1j) == -2-1j
	assert candidate(3.9999999999999999+4.65359265359j) == 4+5j
	assert candidate([1.25+1j, 1.75+1j]) == [1.0+1j, 2.0+1j]
	assert candidate(3.14) == 3
	assert candidate(3.9999999999999999) == 4
	assert candidate(-3.14+4.5j) == complex(candidate(-3.14), candidate(4.5))
	assert candidate(-1.9) == -2
	assert candidate([1.23456789j, 2.34567890, 3.45678901]) == [1j, 2, 3]
	assert candidate(1 + 0j) == 1 + 0j
	assert candidate(10.8 + 20.8j) == complex(11, 21)
	assert candidate(complex(3.5, 3.5)) == complex(4, 4)
	assert candidate(2.5) == 2.0
	assert candidate(1.49) == 1
	assert candidate(3) == 3
	assert candidate([-3.14159265359]) == [-3.0]
	assert candidate(-3.5) == -4.0
	assert candidate(10 - 20j) == complex(10, -20)
	assert candidate(complex(1.0, -2.2)) == complex(1, -2)
	assert candidate(1.23+1j) == 1+1j
	assert candidate(-10.2 - 20.2j) == complex(-10, -20)
	assert candidate(10.0 - 20.0j) == complex(10, -20)
	assert candidate([1.23456789, 2.34567890, 3.45678901]) == [1, 2, 3]
	assert candidate(12345.6789) == 12346
	assert candidate(3.0) == 3
	assert candidate([1.23456789, 2.34567890j, 3.45678901]) == [1, 2j, 3]
	assert candidate(-10.2 + 20.2j) == complex(-10, 20)
	assert candidate(complex(1.4, 2.2)) == complex(1, 2)
	assert candidate(-1.89) == -2
	assert candidate(1.4) == 1
	assert candidate(1.00000001) == 1
	assert candidate(complex(-3.14159)) == complex(-3, 0)
	assert candidate(-1.23e-20) == 0
	assert candidate(4.8) == 5
	assert candidate(1.2345) == 1
	assert candidate(10.0) == 10
	assert candidate(2.9) == 3
	assert candidate(-3-4j) == complex(candidate(-3), candidate(-4))
	assert candidate(-1.98765) == -2
	assert candidate(-0.0) == 0
	assert candidate(complex(1.6, 2.2)) == complex(2, 2)
	assert candidate(3.14-4.5j) == complex(candidate(3.14), candidate(-4.5))
	assert candidate(10000) == 10000
	assert candidate(1.23e-20) == 0
	assert candidate(1.25) == 1
	assert candidate(-1.00001) == -1
	assert candidate(3.99999999999) == 4
	assert candidate(3.99999999999-4j) == 4-4j
	assert candidate(3.4999) == 3
	assert candidate(-1.5) == -2
	assert candidate(-1e20) == -1e+20
	assert candidate(-10.5) == -10
	assert candidate(complex(0, 2.2)) == complex(0, 2)
	assert candidate(1.0000001) == 1
	assert candidate(1.23+0j) == 1+0j
	assert candidate(-3.4999) == -3
	assert candidate(1.000001) == 1
	assert candidate(1j + 0j) == 1j + 0j
	assert candidate(complex(-3.5)) == complex(-4, 0)
	assert candidate(3.5) == 4
	assert candidate(0) == 0
	assert candidate(-1.25) == -1
	assert candidate(1.0001) == 1
	assert candidate(-10.8 - 20.8j)
	assert candidate(3.6) == 4
	assert candidate(-1.23e20) == -1.23e+20
	assert candidate(complex(1.0, 2.2)) == complex(1, 2)
	assert candidate(100) == 100
	assert candidate(-3.999999999999999) == -4
	assert candidate(-10.9) == -11
	assert candidate([1.23456789, 2.34567890, 3.45678901j]) == [1, 2, 3j]
	assert candidate(complex(0.6, 0.6)) == complex(1, 1)
	assert candidate(complex(1.5, -2.2)) == complex(2, -2)
	assert candidate([-3]) == [-3]
	assert candidate(2.01) == 2
	assert candidate(-2.01) == -2
	assert candidate(1.234567) == 1
	assert candidate(-10.2) == -10
	assert candidate(complex(1.6, 2.6)) == complex(2, 3)
	assert candidate(-1.6) == -2
	assert candidate(1.25+1j) == 1.0+1j
	assert candidate(3+4j) == 3+4j
	assert candidate(3.141592653589793) == 3
	assert candidate(3.99999999999+4j) == 4+4j
	assert candidate(-10000) == -10000
	assert candidate(-1.51) == -2
	assert candidate(complex(1.25, 4.56)) == complex(1, 5)
	assert candidate(1.23+2j) == 1+2j
	assert candidate(-3.99999999999) == -4.0
	assert candidate(complex(1.9, 2.2)) == complex(2, 2)
	assert candidate(1.23-1j) == 1-1j
	assert candidate(-1.29) == -1
	assert candidate(3.14+4.5j) == complex(candidate(3.14), candidate(4.5))
	assert candidate(-3.000000000000001) == -3
	assert candidate(-12345.6789) == -12346
	assert candidate(3.14159) == 3
	assert candidate(-1.0000001) == -1
	assert candidate(complex(0.5, 0.5)) == complex(0, 0)
	assert candidate([3.99999999999]) == [4.0]
	assert candidate(complex(3.14159)) == complex(3, 0)
	assert candidate(complex(3.141592653589793, 3.141592653589793)) == complex(3, 3)
	assert candidate([-3.99999999999]) == [-4.0]
	assert candidate(-10.3) == -10
	assert candidate(-3.9999) == -4
	assert candidate(-2.5) == -2.0
	assert candidate(3.14159265359+4.65359265359j) == 3+5j
	assert candidate(1.9+1j) == 2+1j
	assert candidate(123456789) == 123456789
	assert candidate(-0) == 0
	assert candidate([1.23, 4.56]) == [1, 5]
	assert candidate(-1.499) == -1
	assert candidate(-10.1) == -10
	assert candidate([1.1, 2.2, 3.3]) == [1, 2, 3]
	assert candidate(1e20) == 1e+20
	assert candidate(complex(-1.5, 2.2)) == complex(-2, 2)
	assert candidate(complex(1.5, 2.2)) == complex(2, 2)
	assert candidate(1.0) == 1.0
	assert candidate(-1.5 + 0j) == -2 + 0j
	assert candidate(3.000000000000001) == 3
	assert candidate(10.3) == 10
	assert candidate(1.99) == 2
	assert candidate(-1.9-1j) == -2-1j
	assert candidate(2.6) == 3
	assert candidate(0 + 0j) == 0 + 0j
	assert candidate(1234.56789) == 1235
	assert candidate(1.5) == 2
	assert candidate(-100) == -100
	assert candidate(1.4 + 0j) == 1 + 0j
	assert candidate(-3.14-4.5j) == complex(candidate(-3.14), candidate(-4.5))
	assert candidate(-1.23) == -1
	assert candidate([1.23456789, 2.34567890j, 3.45678901j]) == [1, 2j, 3j]
	assert candidate(-1.000001) == -1
	assert candidate(100.49) == 100
	assert candidate(-1.9+1j) == -2+1j
	assert candidate(-3.6) == -4
	assert candidate(1.1) == 1
	assert candidate(3-4j) == 3-4j
	assert candidate(1.98765) == 2
	assert candidate(-3.0) == -3
	assert candidate(-1234.56789) == -1235
	assert candidate(-1.75) == -2
	assert candidate(-3.5-4j) == -4-4j
	assert candidate(10.2 - 20.2j) == complex(10, -20)
	assert candidate(complex(3.5)) == complex(4, 0)
	assert candidate(-2.00) == -2
	assert candidate([3.5]) == [4.0]
	assert candidate(-1) == -1
	assert candidate(10.499999) == 10
	assert candidate(1.23-3j) == 1-3j
	assert candidate(10.5) == 10
	assert candidate(10.9) == 11
	assert candidate(100000) == 100000
	assert candidate(1.0) == 1
	assert candidate(1.23456789) == 1
	assert candidate(1.23456789j) == 1j
	assert candidate(10.0 + 20.0j) == complex(10, 20)
	assert candidate(-10.0) == -10
	assert candidate(-1 + 0j) == -1 + 0j
	assert candidate(complex(1.9, -2.2)) == complex(2, -2)
	assert candidate(-3.99999999999-4j) == -4-4j
	assert candidate(1.23+3j) == 1+3j
	assert candidate(-1.2345) == -1
	assert candidate(1.9) == 2
	assert candidate(3.99999999999) == 4.0
	assert candidate(3.5-4j) == 4-4j
	assert candidate(-3.14159265359) == -3.0
	assert candidate([1.5, 1.25, 1.75]) == [2, 1, 2]
	assert candidate(10.1) == 10
	assert candidate(3-4j) == complex(candidate(3), candidate(-4))
	assert candidate([1.4, 2.4, 3.4]) == [1, 2, 3]
	assert candidate(-123456789) == -123456789
	assert candidate(1.8) == 2
	assert candidate(-1.23456) == -1
	assert candidate(-3+4j) == -3+4j
	assert candidate(complex(3.6)) == complex(4, 0)
	assert candidate(-1.4 + 0j) == -1 + 0j
	assert candidate(1e-20) == 0
	assert candidate(3.9999) == 4
	assert candidate(complex(-3.6)) == complex(-4, 0)
	assert candidate([3+4j]) == [3+4j]
	assert candidate(-3.14159) == -3
	assert candidate(-1.30) == -1
	assert candidate(1.30) == 1
	assert candidate(1.31) == 1
	assert candidate(-3+4j) == complex(candidate(-3), candidate(4))
	assert candidate(-100000) == -100000
	assert candidate([1.23456, 1.98765, 1234.56789, 12345.6789, -1.23456, -1.98765, -1234.56789, -12345.6789]) == [1, 2, 1235, 12346, -1, -2, -1235, -12346]
	assert candidate(0.6) == 1
	assert candidate(-3-4j) == -3-4j
	assert candidate(0.123456) == 0
	assert candidate(-3.499999999999999) == -3
	assert candidate(1.89) == 2
	assert candidate(complex(-1.4, -2.4)) == complex(-1, -2)
	assert candidate(1.001) == 1
	assert candidate(3.499999999999999) == 3
	assert candidate(1.51) == 2
	assert candidate(0.123) == 0
	assert candidate(1.9-1j) == 2-1j
	assert candidate(-1.001) == -1
	assert candidate(complex(1.23, 4.56)) == complex(1, 5)
	assert candidate(complex(-1.9, 2.2)) == complex(-2, 2)
	assert candidate(1.00001) == 1
	assert candidate(3.14159265359) == 3
	assert candidate(-10) == -10
	assert candidate(-3.14) == -3
	assert candidate(1.5000000000001) == 2
	assert candidate([-3.5]) == [-4.0]
def test_check():
	check(op_round)
