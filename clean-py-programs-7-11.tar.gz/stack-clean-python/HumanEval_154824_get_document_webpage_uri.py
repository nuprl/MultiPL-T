def get_document_webpage_uri(data, query_param_names=None):
    """
    Recebe data
    retorna uri no padrao /j/:acron/a/:id_doc?format=pdf&lang=es
    """
    ### Canonical solution below ###
    uri = "/j/{}/a/{}".format(data['acron'], data['doc_id'])
    query_param_names = query_param_names or ("format", "lang")
    query_items = [
        "{}={}".format(name, data.get(name))
        for name in query_param_names
        if data.get(name)
    ]
    if len(query_items):
        uri += "?" + "&".join(query_items)
    return uri


### Unit tests below ###
def check(candidate):
	assert candidate(
    {'acron': 'tb', 'doc_id': '12345', 'lang': 'es'}
) == '/j/tb/a/12345?lang=es'
	assert candidate(
    {'acron': 'j', 'doc_id': '1234567'}
) == '/j/j/a/1234567'
	assert candidate(dict(acron="XXX", doc_id=123, format="pdf", lang="en"), query_param_names=("format", "lang", "xxx")) == "/j/XXX/a/123?format=pdf&lang=en"
	assert candidate(
    {'acron': 'j', 'doc_id': '1234567', 'lang': 'es'}
) == '/j/j/a/1234567?lang=es'
	assert candidate(
    {
        'acron': 'jorn',
        'doc_id': '1234',
        'format': 'pdf',
        'lang': None
    }
) == '/j/jorn/a/1234?format=pdf'
	assert candidate(dict(acron="XXX", doc_id=123, format="pdf", lang="en"), query_param_names=("format",)) == "/j/XXX/a/123?format=pdf"
	assert candidate(
    {
        'acron': 'jorn',
        'doc_id': '1234',
        'format': None,
        'lang': 'es'
    }
) == '/j/jorn/a/1234?lang=es'
	assert candidate(
    {'acron':'scl', 'doc_id': '123'}
) == '/j/scl/a/123'
	assert candidate({'acron': 'jorn', 'doc_id': '123'}) == "/j/jorn/a/123"
	assert candidate(
    {
        "acron": "abc",
        "doc_id": "123",
        "lang": "es",
    }
) == "/j/abc/a/123?lang=es"
	assert candidate(
    {'acron':'scl', 'doc_id': '123', 'format': 'pdf', 'lang': 'es'}
) == '/j/scl/a/123?format=pdf&lang=es'
	assert candidate(
    {'acron': 'j', 'doc_id': '1234567', 'format': 'pdf', 'lang': 'es'}
) == '/j/j/a/1234567?format=pdf&lang=es'
	assert candidate(
    {"acron": "SBRJ", "doc_id": "SBRJ_111111111_2019", "lang": "es"}
) == "/j/SBRJ/a/SBRJ_111111111_2019?lang=es"
	assert candidate(
    {'acron':'saa', 'doc_id': '123', 'format': 'pdf', 'lang': 'pt-br'},
    ['format', 'lang']) == '/j/saa/a/123?format=pdf&lang=pt-br'
	assert candidate(
    {
        "acron": "abc",
        "doc_id": "123",
        "format": "pdf",
        "lang": "es",
    },
    query_param_names=("format", "lang"),
) == "/j/abc/a/123?format=pdf&lang=es"
	assert candidate(
    {
        'acron': 'jorn',
        'doc_id': '1234',
        'format': None,
        'lang': None
    }
) == '/j/jorn/a/1234'
	assert candidate(dict(
    acron='jus',
    doc_id='1234-5678',
    format='pdf',
    lang='es',
    extra='ignore',
), query_param_names=("format", "lang")) == '/j/jus/a/1234-5678?format=pdf&lang=es'
	assert candidate(
    {'acron':'scl', 'doc_id': '123', 'lang': 'es'}
) == '/j/scl/a/123?lang=es'
	assert candidate(
    {'acron':'saa', 'doc_id': '12345678901234567890123456789012345678901234567890'},
    query_param_names=("format", "lang")
) == "/j/saa/a/12345678901234567890123456789012345678901234567890"
	assert candidate(
    {'acron': 'tb', 'doc_id': '12345', 'format': 'pdf', 'lang': 'es'},
    query_param_names=('format', 'lang')
) == '/j/tb/a/12345?format=pdf&lang=es'
	assert candidate(dict(acron="saa", doc_id="00001", format="pdf")) == "/j/saa/a/00001?format=pdf"
	assert candidate(
    {
        "doc_id": "12345",
        "acron": "acron",
        "format": "pdf",
        "lang": "es",
    }
) == "/j/acron/a/12345?format=pdf&lang=es"
	assert candidate(data={'acron': 'abc', 'doc_id': '123', 'format': 'pdf', 'lang': 'es'}, query_param_names=("format",)) == "/j/abc/a/123?format=pdf"
	assert candidate(
    {
        'acron': 'cadernos',
        'doc_id': '1234',
        'format': 'pdf',
    }
) == "/j/cadernos/a/1234?format=pdf"
	assert candidate(
    {
        "doc_id": "12345",
        "acron": "acron",
        "format": "pdf",
    }
) == "/j/acron/a/12345?format=pdf"
	assert candidate(dict(acron="XXX", doc_id=123, format="pdf", lang="en")) == "/j/XXX/a/123?format=pdf&lang=en"
	assert candidate(
    {'acron':'saa', 'doc_id': '123', 'format': 'pdf', 'lang': 'pt-br'}) == \
        '/j/saa/a/123?format=pdf&lang=pt-br'
	assert candidate(
    data={'acron': 'wpo', 'doc_id': '12345'}
) == "/j/wpo/a/12345"
	assert candidate(
    {
        "doc_id": "12345",
        "acron": "acron",
    }
) == "/j/acron/a/12345"
	assert candidate(dict(acron="SJP", doc_id="2001-267X-jrba-51-01-0001", format="pdf")) == "/j/SJP/a/2001-267X-jrba-51-01-0001?format=pdf"
	assert candidate(
    {'acron': 'a', 'doc_id': 'b', 'format': 'c', 'lang': 'd'},
    query_param_names=('format', 'lang')) == \
    '/j/a/a/b?format=c&lang=d'
	assert candidate(data={'acron': 'abc', 'doc_id': '123', 'format': 'pdf', 'lang': 'es'}, query_param_names=("format", "lang")) == "/j/abc/a/123?format=pdf&lang=es"
	assert candidate(dict(acron="abc", doc_id=123, lang="es")) == "/j/abc/a/123?lang=es"
	assert candidate(
    {'acron': 'tb', 'doc_id': '12345', 'format': 'pdf'}
) == '/j/tb/a/12345?format=pdf'
	assert candidate(
    {'acron': 'xx', 'doc_id': '123', 'format': 'pdf'},
) == '/j/xx/a/123?format=pdf'
	assert candidate(
    {
        "acron": "jus",
        "doc_id": "123",
        "format": "pdf",
    }
) == "/j/jus/a/123?format=pdf"
	assert candidate(dict(acron="XXX", doc_id=123, format="pdf", lang="en"), query_param_names=("format", "lang")) == "/j/XXX/a/123?format=pdf&lang=en"
	assert candidate(
    {'acron': 'xx', 'doc_id': '123', 'format': 'pdf', 'lang': 'pt'},
) == '/j/xx/a/123?format=pdf&lang=pt'
	assert candidate(
    {'acron': 'SciELO', 'doc_id': 'S0034-89102010000500001'}) == \
    '/j/SciELO/a/S0034-89102010000500001'
	assert candidate(data={'acron': 'abc', 'doc_id': '123'}) == "/j/abc/a/123"
	assert candidate(
    {'acron': 'tst', 'doc_id': 1, 'lang': 'es'}) == "/j/tst/a/1?lang=es"
	assert candidate(
    {
        'acron': 'cadernos',
        'doc_id': '1234',
        'format': 'pdf',
        'lang': 'es',
    }
) == "/j/cadernos/a/1234?format=pdf&lang=es"
	assert candidate(dict(acron="saa", doc_id="00001")) == "/j/saa/a/00001"
	assert candidate(data={'acron': 'abc', 'doc_id': '123', 'format': 'pdf', 'lang': 'es'}, query_param_names=("lang",)) == "/j/abc/a/123?lang=es"
	assert candidate(dict(acron="abc", doc_id=123, format="pdf", lang="es"), query_param_names=["lang"]) == "/j/abc/a/123?lang=es"
	assert candidate(dict(acron="SJR", doc_id="201800027", format="pdf")) == "/j/SJR/a/201800027?format=pdf"
	assert candidate(
    {'acron': 'tst', 'doc_id': 1}) == "/j/tst/a/1"
	assert candidate(
    {'acron': 'tb', 'doc_id': '12345', 'format': 'pdf', 'lang': 'es'},
    query_param_names=('format',)
) == '/j/tb/a/12345?format=pdf'
	assert candidate(
    {'acron': 'SciELO', 'doc_id': 'S0034-89102010000500001', 'format': 'pdf'}) == \
    '/j/SciELO/a/S0034-89102010000500001?format=pdf'
	assert candidate(dict(acron="SJP", doc_id="2001-267X-jrba-51-01-0001", format="pdf", lang="en")) == "/j/SJP/a/2001-267X-jrba-51-01-0001?format=pdf&lang=en"
	assert candidate(
    data={'acron': 'wpo', 'doc_id': '12345', 'format': 'pdf', 'lang': 'es'},
    query_param_names=("lang",)
) == "/j/wpo/a/12345?lang=es"
	assert candidate(
    {"acron": "SBRJ", "doc_id": "SBRJ_111111111_2019"}
) == "/j/SBRJ/a/SBRJ_111111111_2019"
	assert candidate(dict(acron="SJP", doc_id="2001-267X-jrba-51-01-0001")) == "/j/SJP/a/2001-267X-jrba-51-01-0001"
	assert candidate(
    {'acron': 'jorn', 'doc_id': '123', 'format': 'pdf', 'lang': 'pt'}
) == "/j/jorn/a/123?format=pdf&lang=pt"
	assert candidate(
    {'acron': 'tb', 'doc_id': '12345', 'format': 'pdf', 'lang': 'es'},
    query_param_names=('lang',)
) == '/j/tb/a/12345?lang=es'
	assert candidate(dict(
    acron='jus',
    doc_id='1234-5678',
    format='pdf',
    extra='ignore',
), query_param_names=("format", "lang")) == '/j/jus/a/1234-5678?format=pdf'
	assert candidate(
    {"acron": "SBRJ", "doc_id": "SBRJ_111111111_2019", "format": "pdf", "lang": "es"}
) == "/j/SBRJ/a/SBRJ_111111111_2019?format=pdf&lang=es"
	assert candidate(
    data={'acron': 'wpo', 'doc_id': '12345', 'format': 'pdf', 'lang': 'es'}
) == "/j/wpo/a/12345?format=pdf&lang=es"
	assert candidate(
    {'acron': 'xx', 'doc_id': '123'},
) == '/j/xx/a/123'
	assert candidate(dict(acron="SJR", doc_id="201800027")) == "/j/SJR/a/201800027"
	assert candidate(
    {
        "acron": "abc",
        "doc_id": "123",
        "format": "pdf",
    }
) == "/j/abc/a/123?format=pdf"
	assert candidate(
    {"acron": "SBRJ", "doc_id": "SBRJ_111111111_2019", "format": "pdf"}
) == "/j/SBRJ/a/SBRJ_111111111_2019?format=pdf"
	assert candidate(dict(acron="abc", doc_id=123)) == "/j/abc/a/123"
	assert candidate(dict(acron="SJR", doc_id="201800027", format="pdf", lang="es")) == "/j/SJR/a/201800027?format=pdf&lang=es"
	assert candidate(
    {'acron': 'abc', 'doc_id': 123, 'format': 'pdf'}) == "/j/abc/a/123?format=pdf"
	assert candidate(
    {'acron': 'a', 'doc_id': 'b', 'format': 'c', 'lang': 'd'}) == \
    '/j/a/a/b?format=c&lang=d'
	assert candidate(
    {
        'acron': 'cadernos',
        'doc_id': '1234',
    }
) == "/j/cadernos/a/1234"
	assert candidate(
    {
        'acron': 'jorn',
        'doc_id': '1234',
        'format': 'pdf',
        'lang': 'es'
    },
    ('format', 'lang')
) == '/j/jorn/a/1234?format=pdf&lang=es'
	assert candidate(
    {'acron': 'tst', 'doc_id': 1, 'format': 'pdf', 'lang': 'es'}) == "/j/tst/a/1?format=pdf&lang=es"
	assert candidate(dict(
    acron='jus',
    doc_id='1234-5678',
)) == '/j/jus/a/1234-5678'
	assert candidate(
    {
        "acron": "abc",
        "doc_id": "123",
        "format": "pdf",
        "lang": "es",
    }
) == "/j/abc/a/123?format=pdf&lang=es"
	assert candidate(
    {'acron': 'a', 'doc_id': 'b', 'format': 'c', 'lang': 'd'},
    query_param_names=('format',)) == \
    '/j/a/a/b?format=c'
	assert candidate(
    {'acron':'scl', 'doc_id': '123', 'format': 'pdf'}
) == '/j/scl/a/123?format=pdf'
	assert candidate(
    {
        "acron": "abc",
        "doc_id": "123",
        "format": "pdf",
        "lang": "es",
    },
    query_param_names=("lang", "format"),
) == "/j/abc/a/123?lang=es&format=pdf"
	assert candidate(
    {'acron': 'tst', 'doc_id': 1, 'format': 'pdf'}) == "/j/tst/a/1?format=pdf"
	assert candidate(
    {'acron':'saa', 'doc_id': '12345678901234567890123456789012345678901234567890', 'format': 'pdf', 'lang': 'es'},
    query_param_names=("format", "lang")
) == "/j/saa/a/12345678901234567890123456789012345678901234567890?format=pdf&lang=es"
	assert candidate(
    {
        "acron": "abc",
        "doc_id": "123",
    }
) == "/j/abc/a/123"
	assert candidate(dict(acron="abc", doc_id=123, format="pdf", lang="es")) == "/j/abc/a/123?format=pdf&lang=es"
	assert candidate(
    {'acron': 'abc', 'doc_id': 123}) == "/j/abc/a/123"
	assert candidate(
    {'acron': 'SciELO', 'doc_id': 'S0034-89102010000500001', 'format': 'pdf', 'lang': 'pt'}) == \
    '/j/SciELO/a/S0034-89102010000500001?format=pdf&lang=pt'
	assert candidate(
    {'acron': 'tb', 'doc_id': '12345', 'format': 'pdf', 'lang': 'es'}
) == '/j/tb/a/12345?format=pdf&lang=es'
	assert candidate(dict(acron="XXX", doc_id=123, format="pdf", lang="en"), query_param_names=("lang",)) == "/j/XXX/a/123?lang=en"
	assert candidate(
    {'acron': 'xx', 'doc_id': '123', 'format': 'pdf', 'lang': 'pt'},
    query_param_names=('format',),
) == '/j/xx/a/123?format=pdf'
	assert candidate(dict(acron="abc", doc_id=123, format="pdf")) == "/j/abc/a/123?format=pdf"
	assert candidate(
    {
        "acron": "jus",
        "doc_id": "123",
        "lang": "es",
    }
) == "/j/jus/a/123?lang=es"
	assert candidate(
    {
        "acron": "jus",
        "doc_id": "123",
    }
) == "/j/jus/a/123"
	assert candidate(
    data={'acron': 'wpo', 'doc_id': '12345', 'format': 'pdf', 'lang': 'es'},
    query_param_names=("format", "lang")
) == "/j/wpo/a/12345?format=pdf&lang=es"
	assert candidate(
    {'acron': 'j', 'doc_id': '1234567', 'format': 'pdf'}
) == '/j/j/a/1234567?format=pdf'
	assert candidate(
    {
        'acron': 'jorn',
        'doc_id': '1234',
        'format': 'pdf',
        'lang': 'es'
    }
) == '/j/jorn/a/1234?format=pdf&lang=es'
	assert candidate(
    {'acron': 'xx', 'doc_id': '12345'},
    query_param_names=()) == '/j/xx/a/12345'
	assert candidate(dict(
    acron='jus',
    doc_id='1234-5678',
    format='pdf',
    lang='es',
)) == '/j/jus/a/1234-5678?format=pdf&lang=es'
	assert candidate(
    {
        "doc_id": "12345",
        "acron": "acron",
        "lang": "es",
    }
) == "/j/acron/a/12345?lang=es"
	assert candidate(
    {'acron': 'xx', 'doc_id': '123', 'lang': 'pt'},
) == '/j/xx/a/123?lang=pt'
	assert candidate(
    {'acron':'scl', 'doc_id': '123', 'format': 'pdf', 'lang': 'es', 'foo': 'bar'}
) == '/j/scl/a/123?format=pdf&lang=es'
	assert candidate(
    {
        "acron": "jus",
        "doc_id": "123",
        "format": "pdf",
        "lang": "es",
    }
) == "/j/jus/a/123?format=pdf&lang=es"
	assert candidate(dict(acron="saa", doc_id="00001", format="pdf", lang="pt")) == "/j/saa/a/00001?format=pdf&lang=pt"
	assert candidate(dict(acron="saa", doc_id="00001", lang="pt")) == "/j/saa/a/00001?lang=pt"
	assert candidate(
    {'acron': 'abc', 'doc_id': 123, 'format': 'pdf', 'lang': 'es'}) == "/j/abc/a/123?format=pdf&lang=es"
	assert candidate(
    {'acron': 'xx', 'doc_id': '123', 'format': 'pdf', 'lang': 'pt'},
    query_param_names=('format', 'lang'),
) == '/j/xx/a/123?format=pdf&lang=pt'
	assert candidate(
    data={'acron': 'wpo', 'doc_id': '12345', 'format': 'pdf'}
) == "/j/wpo/a/12345?format=pdf"
	assert candidate(dict(
    acron='jus',
    doc_id='1234-5678',
    format='pdf',
)) == '/j/jus/a/1234-5678?format=pdf'
	assert candidate(data={'acron': 'abc', 'doc_id': '123', 'format': 'pdf'}) == "/j/abc/a/123?format=pdf"
	assert candidate(data={'acron': 'abc', 'doc_id': '123', 'format': 'pdf', 'lang': 'es'}) == "/j/abc/a/123?format=pdf&lang=es"
def test_check():
	check(get_document_webpage_uri)
