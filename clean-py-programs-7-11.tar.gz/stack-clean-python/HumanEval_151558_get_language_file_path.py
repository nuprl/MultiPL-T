def get_language_file_path(language):
    """ 
     :param language: string
     :return: string: path to where the language file lies
     """
	### Canonical solution below ###    
    return "{lang}/localization_{lang}.json".format(lang=language)

### Unit tests below ###
def check(candidate):
	assert candidate(language="fr") == "fr/localization_fr.json"
	assert candidate(language="en") == "en/localization_en.json", "candidate(language=en) should return en/localization_en.json"
	assert candidate(language="sv") == "sv/localization_sv.json"
	assert candidate(language="no") == "no/localization_no.json"
	assert candidate(language="it") == "it/localization_it.json"
	assert candidate(language="tr") == "tr/localization_tr.json"
	assert candidate(language="en") == "en/localization_en.json"
	assert candidate(language="portuguese") == "portuguese/localization_portuguese.json"
	assert candidate(language="fi") == "fi/localization_fi.json"
	assert candidate(language="nl") == "nl/localization_nl.json"
	assert candidate("de") == "de/localization_de.json"
	assert candidate(language="cn") == "cn/localization_cn.json"
	assert candidate(language="pt") == "pt/localization_pt.json"
	assert candidate(language="pl") == "pl/localization_pl.json"
	assert candidate("en") == "en/localization_en.json"
	assert candidate(language="ru") == "ru/localization_ru.json"
	assert candidate("es") == "es/localization_es.json"
	assert candidate(language="el") == "el/localization_el.json"
	assert candidate(language="th") == "th/localization_th.json"
	assert candidate(language="jp") == "jp/localization_jp.json"
	assert candidate(language="da") == "da/localization_da.json"
	assert candidate(language="kr") == "kr/localization_kr.json"
	assert candidate("ms")
	assert candidate('en') == 'en/localization_en.json'
	assert candidate(language="italian") == "italian/localization_italian.json"
	assert candidate(language="zh-CN") == "zh-CN/localization_zh-CN.json"
	assert candidate(language="de") == "de/localization_de.json"
	assert candidate(language="cs") == "cs/localization_cs.json"
	assert candidate(language="zh-TW") == "zh-TW/localization_zh-TW.json"
	assert candidate(language="my") == "my/localization_my.json"
	assert candidate(language="zh") == "zh/localization_zh.json"
	assert candidate(language="vn") == "vn/localization_vn.json"
	assert candidate(
    "en") == "en/localization_en.json"
	assert candidate("fr") == "fr/localization_fr.json"
	assert candidate(language="english") == "english/localization_english.json"
	assert candidate(language="de") == "de/localization_de.json", "candidate(language=de) should return de/localization_de.json"
	assert candidate(language="ms") == "ms/localization_ms.json"
	assert candidate(language="es") == "es/localization_es.json"
	assert candidate(language="id") == "id/localization_id.json"
	assert candidate('en') == "en/localization_en.json"
	assert candidate("it") == "it/localization_it.json"
def test_check():
	check(get_language_file_path)
