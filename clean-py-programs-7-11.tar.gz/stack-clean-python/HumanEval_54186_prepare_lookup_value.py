def prepare_lookup_value(key, value):
    """
    Returns a lookup value prepared to be used in queryset filtering.
    """
    ### Canonical solution below ###
    # if key ends with __in, split parameter into separate values
    if key.endswith('__in'):
        value = value.split(',')
    # if key ends with __isnull, special case '' and false
    if key.endswith('__isnull'):
        if value.lower() in ('', 'false'):
            value = False
        else:
            value = True
    return value


### Unit tests below ###
def check(candidate):
	assert candidate(u'name__isnull', u'anything') == True
	assert candidate(key='key__in', value='a,b,c') == ['a', 'b', 'c']
	assert candidate(key='test__isnull', value='') == False
	assert candidate(
    'name__isnull',
    'false'
) == False
	assert candidate(key='foo', value='bar') == 'bar'
	assert candidate(
    'name', 'John'
) == 'John'
	assert candidate(
    'a', 'b'
) == 'b'
	assert candidate(
    'name__isnull', 'false') == False
	assert candidate(
    'name__in', 'John,Jane'
) == ['John', 'Jane']
	assert candidate(key='id__isnull', value='False') == False
	assert candidate(
   'somekey__isnull',
    'true',
) == True
	assert candidate(key='id__isnull', value='') == False
	assert candidate(
   'some_field__isnull',
    ''
) == False
	assert candidate(key='foo__in', value='bar,baz') == ['bar', 'baz']
	assert candidate(key='name__in', value='test,foo,bar') == ['test', 'foo', 'bar']
	assert candidate(
    'title__startswith', 'a') == 'a'
	assert candidate(
    'test__in', '1,2,3'
) == ['1', '2', '3']
	assert candidate(u'name__isnull', u'True') == True
	assert candidate(key='name__isnull', value='true') is True
	assert candidate(
    'name__isnull', 'true'
) is True
	assert candidate(key='name', value='test') == 'test'
	assert candidate(key='key__isnull', value='false') is False
	assert candidate(
    'a__in', 'b,c'
) == ['b', 'c']
	assert candidate(key='foo__isnull', value='True') == True
	assert candidate('__in', '1,2,3') == ['1', '2', '3']
	assert candidate(
    'username__isnull', '1') is True
	assert candidate(u'name__isnull', u'1') == True
	assert candidate(
    'username__isnull', '') is False
	assert candidate(key='name__isnull', value='True') is True
	assert candidate(
   'somekey__in',
   'somevalue,othervalue',
) == ['somevalue', 'othervalue']
	assert candidate(key='key__isnull', value='true') is True
	assert candidate(
   'some_field',
   'some_value'
) =='some_value'
	assert candidate(
    'a__isnull', 'false'
) is False
	assert candidate(
    'id__isnull',
    'True'
) == True
	assert candidate(
   'somekey',
   'somevalue',
) =='somevalue'
	assert candidate(key='name__in', value='test1,test2') == ['test1', 'test2']
	assert candidate(key='key__isnull', value='') is False
	assert candidate(
    'id__isnull',
    ''
) == False
	assert candidate(
    'username__in', 'john,doe') == ['john', 'doe']
	assert candidate(
    'field__in',
    'value1,value2',
) == ['value1', 'value2']
	assert candidate(
    'foo__in', 'bar,baz'
) == ['bar', 'baz']
	assert candidate(key='name__isnull', value='') is False
	assert candidate(
    'name__in',
    'one,two'
) == ['one', 'two']
	assert candidate(key='foo__in', value='1,2,3') == ['1', '2', '3']
	assert candidate(
    'test__isnull', 'false'
) is False
	assert candidate(key='foo__isnull', value='true') is True
	assert candidate('foo__in', 'test') == ['test']
	assert candidate(
    'username__isnull', 'true') is True
	assert candidate('__isnull', 'false') is False
	assert candidate(
    'foo__isnull', 'false'
) is False
	assert candidate(
   'some_field__isnull',
    'True'
) == True
	assert candidate(key='name__in', value='foo,bar,baz') == ['foo', 'bar', 'baz']
	assert candidate(
    'name__in', 'a,b,c') == ['a', 'b', 'c']
	assert candidate(u'foo__isnull', u'False') is False
	assert candidate(key='test__isnull', value='test') == True
	assert candidate(u'foo__isnull', u'') is False
	assert candidate(key='name__isnull', value='false') == False
	assert candidate('__isnull', 'true') is True
	assert candidate(key='test__isnull', value='false') == False
	assert candidate(
    'id__in',
    '1,2,3'
) == ['1', '2', '3']
	assert candidate(key='foo__isnull', value='false') is False
	assert candidate(
    'foo', 'bar'
) == 'bar'
	assert candidate(u'foo__isnull', u'True') is True
	assert candidate(key='foo__isnull', value='true') == True
	assert candidate(
    'id__isnull',
    'False'
) == False
	assert candidate(
    'title__startswith', '') == ''
	assert candidate(key='name__isnull', value='false') is False
	assert candidate(key='id__isnull', value='True') == True
	assert candidate(u'name__in', u'a,b,c') == [u'a', u'b', u'c']
	assert candidate(
    'field__isnull',
    'false',
) == False
	assert candidate(
    'username__isnull', 'false') is False
	assert candidate(
    'name__isnull',
    'true'
) == True
	assert candidate('foo', 'test') == 'test'
	assert candidate(key='foo__isnull', value='') == False
	assert candidate(
   'some_field__isnull',
    'false'
) == False
	assert candidate(
    'name__isnull', '') == False
	assert candidate(
    'field',
    'value',
) == 'value'
	assert candidate(key='test', value='test') == 'test'
	assert candidate(u'name__startswith', u'test') == u'test'
	assert candidate(u'name__isnull', u'true') == True
	assert candidate(
    'name__isnull', 'false'
) is False
	assert candidate(
    'name__isnull', ''
) is False
	assert candidate(u'name__isnull', u'') == False
	assert candidate(key='name__isnull', value='true') == True
	assert candidate(
    'name__isnull', 'True') == True
	assert candidate('foo__isnull', 'test') == True
	assert candidate(
   'somekey__isnull',
    '',
) == False
	assert candidate(
   'somekey__isnull',
    'false',
) == False
	assert candidate(key='name__isnull', value='False') is False
	assert candidate(u'foo__isnull', u'1') is True
	assert candidate(u'name__isnull', u'false') == False
	assert candidate('__isnull', '') is False
	assert candidate(key='test__in', value='test,test2') == ['test', 'test2']
	assert candidate(key='foo__isnull', value='') is False
	assert candidate(key='foo__isnull', value='false') == False
def test_check():
	check(prepare_lookup_value)
