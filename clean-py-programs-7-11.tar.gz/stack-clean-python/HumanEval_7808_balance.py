def balance(text, bal=0):
    """
    Checks whether the parens in the text are balanced:
        - zero: balanced
        - negative: too many right parens
        - positive: too many left parens
    """
    ### Canonical solution below ###
    if text == '':
        return bal
    elif text[0] == '(' and bal >= 0:
        return balance(text[1:], bal + 1)
    elif text[0] == ')':
        return balance(text[1:], bal - 1)
    else:
        return balance(text[1:], bal)


### Unit tests below ###
def check(candidate):
	assert candidate(r'())') == -1
	assert candidate(r')') == -1
	assert candidate(r'(((())())(()))') == 0
	assert candidate('((hello))') == 0
	assert candidate('()') == 0
	assert candidate('a(b(c)d)e') == 0
	assert candidate(r'()') == 0
	assert candidate('(((hello)))') == 0
	assert candidate(r'((())())') == 0
	assert candidate(r'())()') == -2
	assert candidate('(())') == 0
	assert candidate('(hello)') == 0
	assert candidate('(()())') == 0, "Text is candidated"
	assert candidate('(((hello))world)') == 0
	assert candidate(r'') == 0
	assert candidate('a(b)c') == 0
	assert candidate('((())') == 1
	assert candidate('(()') == 1
	assert candidate('())') == -1
	assert candidate('(((') == 3
	assert candidate(r'(()') == 1
	assert candidate(r'((())') == 1
	assert candidate('((()))') == 0
	assert candidate(r'(()(()))') == 0
	assert candidate('(()))') == -1
	assert candidate(')') == -1
	assert candidate('()()()') == 0, "Text is candidated"
	assert candidate(r'(())') == 0
	assert candidate(r')(') == -1
	assert candidate(r'((()))') == 0
	assert candidate('(((hello)))world') == 0
	assert candidate(r'((())(()())())') == 0
	assert candidate('()()()') == 0
	assert candidate('((hello)world)') == 0
	assert candidate(')(') == -1
def test_check():
	check(balance)
