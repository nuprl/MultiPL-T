def get_required_static_files(analysis_settings):
    """Based on config options, return a list of static data files that
    will be required.

    """
    ### Canonical solution below ###

    # Start with list of files that are always required
    static_files = ['footprint', 'vulnerability', 'damage_bin_dict']

    # Check if random is required
    if 'model_settings' in analysis_settings:
        if (('use_random_number_file'in analysis_settings['model_settings']) and
                (analysis_settings['model_settings']['use_random_number_file'])):
         static_files.append('random')

    return static_files


### Unit tests below ###
def check(candidate):
	assert candidate({'model_settings':{'use_random_number_file':True}}) == ['footprint', 'vulnerability', 'damage_bin_dict', 'random']
	assert candidate({'model_settings': {'use_random_number_file': True}, 'random_number_file': 'random.bin'}) == ['footprint', 'vulnerability', 'damage_bin_dict', 'random']
	assert candidate({'model_settings':{}}) == ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate({'model_settings': {}}) == ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate({'model_settings': {'use_random_number_file': False}}) == ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate(
    {'vulnerability': 'rcp45', 'footprint': 'global','model_settings': {'use_random_number_file': True}}) == ['footprint', 'vulnerability', 'damage_bin_dict', 'random']
	assert candidate(
    {'model_settings': {'use_random_number_file': False}}) == ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate(
    {'model_settings': {'use_random_number_file': False}}) == \
    ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate(
    {}) == ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate(
    {'vulnerability': 'rcp45', 'footprint': 'global','model_settings': {'use_random_number_file': False}}) == ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate({'model_settings': {'use_random_number_file': True}}) == ['footprint', 'vulnerability', 'damage_bin_dict', 'random']
	assert candidate(
    {'model_settings': {'use_random_number_file': True}}) == ['footprint', 'vulnerability', 'damage_bin_dict', 'random']
	assert candidate({}) == ['footprint', 'vulnerability', 'damage_bin_dict']
	assert candidate(
    {'model_settings': {'use_random_number_file': True}}) == \
    ['footprint', 'vulnerability', 'damage_bin_dict', 'random']
def test_check():
	check(get_required_static_files)
