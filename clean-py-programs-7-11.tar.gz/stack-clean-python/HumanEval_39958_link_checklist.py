def link_checklist(checklist, regex):
    """ 
     QoL function to help compare automatic vs manual treatment
     :param checklist: an array of manual entries deemed present
     :param regex:  a regex entry in the dataframe resulting of wikipedia banlist scraping
     :return: nothing :)
     """
	### Canonical solution below ###    
    keywords = [{'key': X.split('.')[0], 'name': X} for X in checklist]
    for keyword in keywords:
        if keyword['key'] in regex:
            return keyword['name']
    return None

### Unit tests below ###
def check(candidate):
	assert candidate(checklist=['A', 'B', 'C'], regex='A|B|C') == 'A'
	assert candidate(checklist=['a.b', 'c.d'], regex='c.d') == 'c.d'
	assert candidate(checklist=['A', 'B', 'C'], regex='B|C') == 'B'
	assert candidate(checklist=['A', 'B', 'C'], regex='A') == 'A'
	assert candidate(checklist=['A', 'B', 'C'], regex='D') == None
	assert candidate(checklist=['A', 'B', 'C'], regex='C') == 'C'
	assert candidate(checklist=['1984', 'Animal Farm', 'The Great Gatsby'], regex='The Great Gatsby') == 'The Great Gatsby'
	assert candidate(checklist=['1984', 'Animal Farm', 'The Great Gatsby'], regex='Animal Farm') == 'Animal Farm'
	assert candidate(checklist=['A', 'B', 'C'], regex='A|B|C|D') == 'A'
	assert candidate(checklist=['a.b', 'c.d'], regex='a.b') == 'a.b'
	assert candidate(checklist=['Palestine'], regex='Palestine') == 'Palestine'
	assert candidate(checklist= ['<NAME>', '<NAME>'], regex= ['<NAME>']) == '<NAME>'
	assert candidate(checklist=['A', 'B', 'C'], regex='A|B') == 'A'
	assert candidate(checklist=['A.1', 'A.2'], regex='A.1') == 'A.1'
	assert candidate(checklist=['1.2', '1.3', '1.4', '1.5'], regex='1.2') == '1.2', "1.2 should be in regex"
	assert candidate(checklist=['1984', 'Animal Farm', 'The Great Gatsby'], regex='1984') == '1984'
	assert candidate(checklist=['Palestine', 'Palestine', 'Palestine'], regex='Palestine') == 'Palestine'
	assert candidate(checklist=['A', 'B', 'C'], regex='B') == 'B'
	assert candidate(checklist=['Palestine', 'Palestine'], regex='Palestine') == 'Palestine'
def test_check():
	check(link_checklist)
