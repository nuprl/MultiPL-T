def _xml_escape_attr(attr, skip_single_quote=True):
    """ Escape the given string for use in an HTML/XML tag attribute.
     
     By default this doesn't bother with escaping `'` to `&39;`, presuming that
     the tag attribute is surrounded by double quotes.
     """
	### Canonical solution below ###    
    escaped = (attr
        .replace('&', '&amp;')
        .replace('"', '&quot;')
        .replace('<', '&lt;')
        .replace('>', '&gt;'))
    if not skip_single_quote:
        escaped = escaped.replace("'", "&#39;")
    return escaped

### Unit tests below ###
def check(candidate):
	assert candidate('foo>') == 'foo&gt;'
	assert candidate('1>2') == '1&gt;2'
	assert candidate('"foo&bar"') == '&quot;foo&amp;bar&quot;'
	assert candidate(r'"<&>') == r'&quot;&lt;&amp;&gt;'
	assert candidate(u"foo'bar", skip_single_quote=False) == u"foo&#39;bar"
	assert candidate(r"a'b<c>d", skip_single_quote=False) == r"a&#39;b&lt;c&gt;d"
	assert candidate(u'<abc>') == u'&lt;abc&gt;'
	assert candidate(
    'This is a string that needs > to be escaped') == \
    'This is a string that needs &gt; to be escaped'
	assert candidate(u"He said, & hi.") == u"He said, &amp; hi."
	assert candidate(u"He said, <hi>.") == u"He said, &lt;hi&gt;."
	assert candidate(
    'This is a string that needs < to be escaped') == \
    'This is a string that needs &lt; to be escaped'
	assert candidate('hello') == 'hello'
	assert candidate('1<2') == '1&lt;2'
	assert candidate(u"foo\"bar") == u'foo&quot;bar'
	assert candidate('hello>world') == 'hello&gt;world'
	assert candidate(u'&') == u'&amp;'
	assert candidate(u'"') == u'&quot;'
	assert candidate(u"hello&goodbye") == u"hello&amp;goodbye"
	assert candidate(u"abc&def", skip_single_quote=True) == u"abc&amp;def"
	assert candidate(u"foo<bar") == u'foo&lt;bar'
	assert candidate(u'foo>bar') == u'foo&gt;bar'
	assert candidate('foo>bar') == 'foo&gt;bar'
	assert candidate('1"2') == '1&quot;2'
	assert candidate(u"foo&\"") == u"foo&amp;&quot;"
	assert candidate('foo') == 'foo'
	assert candidate(u'>') == u'&gt;'
	assert candidate(u'abc&def"') == u'abc&amp;def&quot;'
	assert candidate(r"a&b<c>d") == r"a&amp;b&lt;c&gt;d"
	assert candidate('a&b') == 'a&amp;b'
	assert candidate("'hello'", skip_single_quote=True) == "'hello'"
	assert candidate(u'x < y', False) == u"x &lt; y"
	assert candidate(u"hello") == u"hello"
	assert candidate(u"abc") == u"abc"
	assert candidate(
    'This is a string that needs to be escaped',
    skip_single_quote=False) == \
    'This is a string that needs to be escaped'
	assert candidate(r"A<B") == r"A&lt;B"
	assert candidate(u'foo&bar') == u'foo&amp;bar'
	assert candidate('foo<bar') == 'foo&lt;bar'
	assert candidate(u'abc"def"') == u'abc&quot;def&quot;'
	assert candidate("'hello'") == "'hello'"
	assert candidate('foo"bar') == 'foo&quot;bar'
	assert candidate(
    'This is a string that needs " to be escaped',
    skip_single_quote=False) == \
    'This is a string that needs &quot; to be escaped'
	assert candidate(u'') == ''
	assert candidate(
    '<script>alert("hello");</script>',
    skip_single_quote=False) == (
    '&lt;script&gt;alert(&quot;hello&quot;);&lt;/script&gt;')
	assert candidate(
    '<script>alert("hello");</script>',
    skip_single_quote=True) == (
    '&lt;script&gt;alert(&quot;hello&quot;);&lt;/script&gt;')
	assert candidate(
    "The <quick> <brown> <fox> jumps over the lazy dog") == (
    "The &lt;quick&gt; &lt;brown&gt; &lt;fox&gt; jumps over the lazy dog")
	assert candidate(u'') == u''
	assert candidate(r"A>B") == r"A&gt;B"
	assert candidate(u'abc') == u'abc'
	assert candidate(u'x < y') == u'x &lt; y'
	assert candidate(u"foo&bar") == u'foo&amp;bar'
	assert candidate(u"foo\"") == u'foo&quot;'
	assert candidate(
    "<script>alert('hello');</script>",
    skip_single_quote=False) == (
    '&lt;script&gt;alert(&#39;hello&#39;);&lt;/script&gt;')
	assert candidate(u'<') == u'&lt;'
	assert candidate(u"abc&def") == u"abc&amp;def"
	assert candidate(r"a'b'c'e", skip_single_quote=False) == r"a&#39;b&#39;c&#39;e"
	assert candidate(u"") == u""
	assert candidate(u'foo<bar') == u'foo&lt;bar'
	assert candidate('<foo>') == '&lt;foo&gt;'
	assert candidate(u"'") == u"'"
	assert candidate(
    'This is a string that needs " to be escaped') == \
    'This is a string that needs &quot; to be escaped'
	assert candidate(u"foo>") == u"foo&gt;"
	assert candidate(u'hello"goodbye') == u'hello&quot;goodbye'
	assert candidate(u"foo") == u"foo"
	assert candidate(u'foo') == u'foo'
	assert candidate(r"a&b<c>d", skip_single_quote=False) == r"a&amp;b&lt;c&gt;d"
	assert candidate(u'abc"def') == u'abc&quot;def'
	assert candidate(r'a&b"c<d>e') == r'a&amp;b&quot;c&lt;d&gt;e'
	assert candidate('foo&') == 'foo&amp;'
	assert candidate('"foo"') == '&quot;foo&quot;'
	assert candidate(u"foo<") == u"foo&lt;"
	assert candidate('foo&bar') == 'foo&amp;bar'
	assert candidate('hello<world') == 'hello&lt;world'
	assert candidate(u'abc"') == u'abc&quot;'
	assert candidate('') == ''
	assert candidate(u"foo>bar") == u'foo&gt;bar'
	assert candidate(u"Hello, world!") == u"Hello, world!"
	assert candidate('hello&world') == 'hello&amp;world'
	assert candidate("<foo&bar>") == '&lt;foo&amp;bar&gt;'
	assert candidate(u'x "y') == u'x &quot;y'
	assert candidate(u'abc def') == u'abc def'
	assert candidate('foo\'bar', skip_single_quote=False) == 'foo&#39;bar'
	assert candidate('abc') == 'abc'
	assert candidate(r"a&b<c>d", skip_single_quote=True) == r"a&amp;b&lt;c&gt;d"
	assert candidate(u"foo&") == u"foo&amp;"
	assert candidate(u'abc&def') == u'abc&amp;def'
	assert candidate(u'foo"bar') == u'foo&quot;bar'
	assert candidate(r'A"B') == r"A&quot;B"
	assert candidate(r'abc"def&ghi"jkl"mno', skip_single_quote=False) == r'abc&quot;def&amp;ghi&quot;jkl&quot;mno'
	assert candidate(u"hello'goodbye", False) == u"hello&#39;goodbye"
	assert candidate(u"abc&def", skip_single_quote=False) == u"abc&amp;def"
	assert candidate('"a&b"') == '&quot;a&amp;b&quot;'
	assert candidate(
    'This is a string that needs to be escaped') == \
    'This is a string that needs to be escaped'
	assert candidate(u'&<>') == u'&amp;&lt;&gt;'
	assert candidate('1&2') == '1&amp;2'
def test_check():
	check(_xml_escape_attr)
