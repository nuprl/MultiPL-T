def validate_password(data):
    """ 
     Validates the given password in a request data. First, checks if
     it exists, then check if the password has the necessary length
     :param data: Dict containing all the request data
     :return: Boolean determining the request has a valid password
     """
	### Canonical solution below ###    

    if "password" not in data:
        return False
    password = data["password"]
    if len(password) < 4 or len(password) > 16:
        return False

    return True

### Unit tests below ###
def check(candidate):
	assert candidate(
    {"password": "<PASSWORD>"}
) == True
	assert candidate(
    {"password": "<PASSWORD>"}
) is True
	assert candidate(dict(password="a")) == False
	assert candidate(data={"password": "<PASSWORD>"}) is True
	assert candidate(
    {"password": "<PASSWORD>"}
), "Password with 16 characters is valid"
	assert candidate(dict(password="<PASSWORD>"))
	assert candidate({"password": "a"}) == False
	assert candidate(
    {"password": ""}
) == False, "Empty passwords are invalid"
	assert candidate(dict(password="")) == False
	assert candidate({"password": "<PASSWORD>"}) == True
	assert not candidate(
    {}
), "Password not in request is invalid"
	assert candidate(dict(password="password")) == True
	assert candidate(dict(password="<PASSWORD>")) == True
	assert candidate(
    {"password": "<PASSWORD>"}
), "Password with 4 characters is valid"
	assert candidate(dict(password="<PASSWORD>")) is True
	assert not candidate(dict())
	assert candidate(data={"password": "<PASSWORD>"}) == True
	assert candidate(
    {"password": "<PASSWORD>"}
) == True, "Passwords with 4-16 characters are valid"
	assert not candidate(
    {}
), "Missing password failed validation"
	assert candidate(
    {"password": "<PASSWORD>"}
), "Valid password failed validation"
	assert candidate(dict()) == False
def test_check():
	check(validate_password)
