def split_reaches(l, new_reach_pts):
    """ splits l into sections where new_reach_pts contains the starting indices for each slice"""
	### Canonical solution below ###    
    new_reach_pts = sorted(new_reach_pts)
    sl = [l[i1:i2] for i1, i2 in zip(new_reach_pts, new_reach_pts[1:])]
    last_index = new_reach_pts[-1]
    sl.append(l[last_index:])
    return sl

### Unit tests below ###
def check(candidate):
	assert candidate(range(10), [1, 3, 4, 7, 10]) == [range(1, 3), range(3, 4), range(4, 7), range(7, 10), range(10, 10)]
	assert candidate(list(range(10)), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
	assert candidate(list(range(6)), [0,2,4]) == [[0, 1], [2, 3], [4, 5]]
	assert candidate(range(10), [0, 3, 6, 9]) == [range(0, 3), range(3, 6), range(6, 9), range(9, 10)]
	assert candidate(range(10), [0, 3, 6, 8]) == [range(0, 3), range(3, 6), range(6, 8), range(8, 10)]
	assert candidate(range(10), [0, 4, 8, 10]) == [range(0, 4), range(4, 8), range(8, 10), range(10, 10)]
	assert candidate(range(10), [0, 2, 3, 7, 10]) == [range(0, 2), range(2, 3), range(3, 7), range(7, 10), range(10, 10)]
	assert candidate(range(10), [0]) == [range(10)]
	assert candidate(range(10), [0, 5]) == [range(5), range(5, 10)]
	assert candidate(range(10), [0, 5, 9]) == [range(5), range(5, 9), range(9, 10)]
	assert candidate(range(10), [0, 2, 3, 7]) == [range(0, 2), range(2, 3), range(3, 7), range(7, 10)]
	assert candidate(range(10), [0, 2, 4, 6, 8]) == [range(0, 2), range(2, 4), range(4, 6), range(6, 8), range(8, 10)]
def test_check():
	check(split_reaches)
