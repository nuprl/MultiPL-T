def timeout_check(value):
    """ Check Timeout Argument.
     
     Checks timeout for validity.
     
     Keyword Arguments:
     value                  -- Time in seconds to wait before timing out request.
     
     Return Value:
     Floating point number representing the time (in seconds) that should be
     used for the timeout.
     
     NOTE:  Will raise an exception if the timeout in invalid.
     """
	### Canonical solution below ###    
    from argparse import ArgumentTypeError

    try:
        timeout = float(value)
    except ValueError:
        raise ArgumentTypeError(f"Timeout '{value}' must be a number.")
    if timeout <= 0:
        raise ArgumentTypeError(f"Timeout '{value}' must be greater than 0.0s.")
    return timeout

### Unit tests below ###
def check(candidate):
	assert candidate(1) == 1
	assert candidate(3.0) == 3.0
	assert candidate(1) == 1.0
	assert candidate(10) == 10.0
	assert candidate(1000) == 1000
	assert candidate(100) == 100.0
	assert candidate(10) == 10
	assert candidate(1.5) == 1.5, "Timeout of 1.5s should be allowed."
	assert candidate("10") == 10.0
	assert candidate(1) == 1.0, "Timeout of 1.0s should be allowed."
	assert candidate('1.0') == 1.0
	assert candidate("1000") == 1000
	assert candidate('0.1') == 0.1
	assert candidate(100.0) == 100.0
	assert candidate(3) == 3.0
	assert candidate(10.0) == 10.0
	assert candidate("0.1") == 0.1
	assert candidate(10.0) == 10
	assert candidate(1.0) == 1.0
	assert candidate(0.1) == 0.1
	assert candidate("10.0") == 10.0
	assert candidate("1000.0") == 1000.0
	assert candidate(1.5) == 1.5
	assert candidate(2.0) == 2.0
	assert candidate(1.0) == 1.0, "Timeout of 1.0s should be allowed."
	assert candidate('10') == 10.0
	assert candidate('10.0') == 10.0
	assert candidate(3.14) == 3.14
	assert candidate("1") == 1.0
	assert candidate(0.000001) == 0.000001
	assert candidate(1000.0) == 1000.0
	assert candidate("1.0") == 1.0
	assert candidate('10.1') == 10.1
def test_check():
	check(timeout_check)
