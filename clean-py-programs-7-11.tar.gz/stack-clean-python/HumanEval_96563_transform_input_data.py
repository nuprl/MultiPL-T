def transform_input_data(data):
    """Transform input data dictionary into format ready to use with 
        model.predict"""
    ### Canonical solution below ###
    return {key: [value] for key, value in data.items()}


### Unit tests below ###
def check(candidate):
	assert candidate(data={"a": 1, "b": 2}) == {"a": [1], "b": [2]}
	assert candidate(
    {"age": 5, "workclass": "Private", "fnlwgt": 100000, "education": "HS-grad",
     "education_num": 9, "marital_status": "Married-civ-spouse",
     "occupation": "Craft-repair", "relationship": "Husband",
     "race": "White", "sex": "Male", "capital_gain": 0, "capital_loss": 0,
     "hours_per_week": 60, "native_country": "United-States"}) == \
    {"age": [5], "workclass": ["Private"], "fnlwgt": [100000], "education": ["HS-grad"],
     "education_num": [9], "marital_status": ["Married-civ-spouse"],
     "occupation": ["Craft-repair"], "relationship": ["Husband"],
     "race": ["White"], "sex": ["Male"], "capital_gain": [0], "capital_loss": [0],
     "hours_per_week": [60], "native_country": ["United-States"]}
	assert candidate(
    {'CRIM': 0.00632, 'ZN': 18.0, 'INDUS': 2.31, 'CHAS': 0.0,
     'NOX': 0.538, 'RM': 6.575, 'AGE': 65.2, 'DIS': 4.09,
     'RAD': 1.0, 'TAX': 296.0, 'PTRATIO': 15.3, 'B': 396.9,
     'LSTAT': 4.98}) == {
    'CRIM': [0.00632], 'ZN': [18.0], 'INDUS': [2.31], 'CHAS': [0.0],
    'NOX': [0.538], 'RM': [6.575], 'AGE': [65.2], 'DIS': [4.09],
    'RAD': [1.0], 'TAX': [296.0], 'PTRATIO': [15.3], 'B': [396.9],
    'LSTAT': [4.98]}
	assert candidate(
        {'age': 30, 'workclass': 'Private', 'education_num': 9,
       'marital_status': 'Married', 'occupation': 'Prof-specialty',
       'relationship': 'Husband', 'race': 'White','sex': 'Male',
        'capital_gain': 0, 'capital_loss': 0, 'hours_per_week': 60}) == \
    {'age': [30], 'workclass': ['Private'], 'education_num': [9],
   'marital_status': ['Married'], 'occupation': ['Prof-specialty'],
   'relationship': ['Husband'], 'race': ['White'],'sex': ['Male'],
    'capital_gain': [0], 'capital_loss': [0], 'hours_per_week': [60]}
	assert candidate(data={'a': 1, 'b': 2}) == {'a': [1], 'b': [2]}
	assert candidate(
    {'age': 26, 'workclass': 'Private', 'education': 'HS-grad', 
    'marital-status': 'Married-civ-spouse', 'occupation': 'Craft-repair', 
    'relationship': 'Husband', 'race': 'White','sex': 'Male', 
     'capital-gain': 0, 'capital-loss': 0, 'hours-per-week': 60, 
     'native-country': 'United-States'}) == {'age': [26], 
                                             'workclass': ['Private'], 
                                             'education': ['HS-grad'], 
                                            'marital-status': ['Married-civ-spouse'], 
                                             'occupation': ['Craft-repair'], 
                                            'relationship': ['Husband'], 
                                             'race': ['White'], 
                                            'sex': ['Male'], 
                                             'capital-gain': [0], 
                                             'capital-loss': [0], 
                                             'hours-per-week': [60], 
                                             'native-country': ['United-States']}
	assert candidate(
    {"fixed acidity": 7.4, "volatile acidity": 0.7, "citric acid": 0, "residual sugar": 1.9, "chlorides": 0.076, "free sulfur dioxide": 11, "total sulfur dioxide": 34, "density": 0.9978, "pH": 3.51, "sulphates": 0.56, "alcohol": 9.4, "quality": 6}) == \
    {"fixed acidity": [7.4], "volatile acidity": [0.7], "citric acid": [0], "residual sugar": [1.9], "chlorides": [0.076], "free sulfur dioxide": [11], "total sulfur dioxide": [34], "density": [0.9978], "pH": [3.51], "sulphates": [0.56], "alcohol": [9.4], "quality": [6]}
	assert candidate(
    {"age": 5, "workclass": "Private", "fnlwgt": 100000, "education": "HS-grad", "education-num": 9, "marital-status": "Married-civ-spouse", "occupation": "Craft-repair", "relationship": "Husband", "race": "White", "sex": "Male", "capital-gain": 0, "capital-loss": 0, "hours-per-week": 60, "native-country": "United-States"}
) == {
    "age": [5],
    "workclass": ["Private"],
    "fnlwgt": [100000],
    "education": ["HS-grad"],
    "education-num": [9],
    "marital-status": ["Married-civ-spouse"],
    "occupation": ["Craft-repair"],
    "relationship": ["Husband"],
    "race": ["White"],
    "sex": ["Male"],
    "capital-gain": [0],
    "capital-loss": [0],
    "hours-per-week": [60],
    "native-country": ["United-States"],
}
	assert candidate(
    {"x1": 1, "x2": 2, "x3": 3, "x4": 4}) == {"x1": [1], "x2": [2], "x3": [3], "x4": [4]}
	assert candidate(
    {"x1": 1, "x2": 2, "x3": 3, "x4": 4, "x5": 5, "x6": 6}) == {"x1": [1], "x2": [2], "x3": [3], "x4": [4], "x5": [5], "x6": [6]}
	assert candidate(
    {"age": 2, "workclass": "Private", "fnlwgt": 2147483647, "education": "HS-grad", "education-num": 9, "marital-status": "Married-civ-spouse", "occupation": "Craft-repair", "relationship": "Husband", "race": "White", "sex": "Male", "capital-gain": 0, "capital-loss": 0, "hours-per-week": 60, "native-country": "United-States"}
) == {"age": [2], "workclass": ["Private"], "fnlwgt": [2147483647], "education": ["HS-grad"], "education-num": [9], "marital-status": ["Married-civ-spouse"], "occupation": ["Craft-repair"], "relationship": ["Husband"], "race": ["White"], "sex": ["Male"], "capital-gain": [0], "capital-loss": [0], "hours-per-week": [60], "native-country": ["United-States"]}
	assert candidate(
    {'temp': 300, 'pres': 1000, 'humid': 10, 'wind': 10}) == \
    {'temp': [300], 'pres': [1000], 'humid': [10], 'wind': [10]}
	assert candidate(
    {'bore': 0.27200,'stroke': 0.45600, 'compression-ratio': 0.30000, 'horsepower': 134.00000, 'city-mpg': 23.00000}) == {'bore': [0.27200],'stroke': [0.45600], 'compression-ratio': [0.30000], 'horsepower': [134.00000], 'city-mpg': [23.00000]}
	assert candidate(
    {'sepal_length': 5.1,'sepal_width': 3.5, 'petal_length': 1.4, 'petal_width': 0.2}) == \
    {'sepal_length': [5.1],'sepal_width': [3.5], 'petal_length': [1.4], 'petal_width': [0.2]}
	assert candidate(
    {'fixed acidity': 7.4, 'volatile acidity': 0.7, 'citric acid': 0,
    'residual sugar': 1.9, 'chlorides': 0.076, 'free sulfur dioxide': 11,
     'total sulfur dioxide': 34, 'density': 0.9978, 'pH': 3.51,
    'sulphates': 0.56, 'alcohol': 9.4, 'quality': 6}) == {
         'fixed acidity': [7.4], 'volatile acidity': [0.7],
         'citric acid': [0],'residual sugar': [1.9], 'chlorides': [0.076],
         'free sulfur dioxide': [11], 'total sulfur dioxide': [34],
         'density': [0.9978], 'pH': [3.51],'sulphates': [0.56],
         'alcohol': [9.4], 'quality': [6]}
	assert candidate(
    {"x1": 1, "x2": 2, "x3": 3, "x4": 4, "x5": 5}) == {"x1": [1], "x2": [2], "x3": [3], "x4": [4], "x5": [5]}
	assert candidate(
    {"first_name": "John", "last_name": "Doe", "age": 32, "workclass": "Private", "fnlwgt": 123456, "education": "HS-grad", "education_num": 9, "marital_status": "Married-civ-spouse", "occupation": "Craft-repair", "relationship": "Husband", "race": "White", "sex": "Male", "capital_gain": 0, "capital_loss": 0, "hours_per_week": 60, "native_country": "United-States"}) == \
    {'age': [32],
     'capital_gain': [0],
     'capital_loss': [0],
     'education': ['HS-grad'],
     'education_num': [9],
     'first_name': ['John'],
     'fnlwgt': [123456],
     'hours_per_week': [60],
     'last_name': ['Doe'],
    'marital_status': ['Married-civ-spouse'],
     'native_country': ['United-States'],
     'occupation': ['Craft-repair'],
     'race': ['White'],
    'relationship': ['Husband'],
    'sex': ['Male'],
     'workclass': ['Private']}
	assert candidate(data={'sqft_living': 1000}) == \
    {'sqft_living': [1000]}
	assert candidate(
    {"x1": 1, "x2": 2, "x3": 3, "x4": 4, "x5": 5, "x6": 6, "x7": 7}) == {"x1": [1], "x2": [2], "x3": [3], "x4": [4], "x5": [5], "x6": [6], "x7": [7]}
	assert candidate(data={'a': 1}) == {'a': [1]}
	assert candidate(
    {'bore': 0.27200,'stroke': 0.45600, 'compression-ratio': 0.30000, 'horsepower': 134.00000, 'city-mpg': 23.00000, 'price': 30700.00000}) == {'bore': [0.27200],'stroke': [0.45600], 'compression-ratio': [0.30000], 'horsepower': [134.00000], 'city-mpg': [23.00000], 'price': [30700.00000]}
	assert candidate(
    {'store': 1, 'item': 2, 'day_of_week': 3,'sales': 4, 'customers': 5, 'open': 6, 'promo': 7,'school_holiday': 8,'state_holiday': 9}) == {'store': [1], 'item': [2], 'day_of_week': [3],'sales': [4], 'customers': [5], 'open': [6], 'promo': [7],'school_holiday': [8],'state_holiday': [9]}
def test_check():
	check(transform_input_data)
