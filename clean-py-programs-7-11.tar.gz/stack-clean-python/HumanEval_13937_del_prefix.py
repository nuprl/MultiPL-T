def del_prefix(key):
    """ 
     Removes prefixes from the key
     """
	### Canonical solution below ###    
    return key.split('||')[-1]

### Unit tests below ###
def check(candidate):
	assert candidate(
    "red") == "red"
	assert candidate( '||test') == 'test'
	assert candidate("||1") == "1"
	assert candidate('a||b||c') == 'c'
	assert candidate('foo||bar') == 'bar'
	assert candidate('test') == 'test'
	assert candidate( 'test') == 'test'
	assert candidate('a||b') == 'b'
	assert candidate(key='a') == 'a'
	assert candidate("prefix||||value") == "value"
	assert candidate('a') == 'a'
	assert candidate('foo') == 'foo'
	assert candidate('||') == ''
	assert candidate("||test") == "test"
	assert candidate("||") == ""
	assert candidate('||abc') == 'abc'
	assert candidate("prefix||") == ""
	assert candidate(key='test') == 'test'
	assert candidate('||foo') == 'foo'
	assert candidate("prefix||value") == "value"
	assert candidate(
    "||red") == "red"
	assert candidate('||a||b') == 'b'
	assert candidate('') == ''
	assert candidate('foo||bar||baz') == 'baz'
	assert candidate('||test') == 'test'
	assert candidate('||a') == 'a'
	assert candidate(key='||test') == 'test'
def test_check():
	check(del_prefix)
