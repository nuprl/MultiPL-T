def split_string(string):
    """ split and lower the string"""
	### Canonical solution below ###    
    return string.lower().split(' ')

### Unit tests below ###
def check(candidate):
	assert candidate(
    'A regular sentence with a few words') == \
    ['a','regular','sentence', 'with', 'a', 'few', 'words']
	assert candidate(
    'How are you today?') == ['how', 'are', 'you', 'today?']
	assert candidate("i") == ['i']
	assert candidate("1, 2, 3") == ['1,', '2,', '3']
	assert candidate(
    'Portable Network Graphics') == ['portable', 'network', 'graphics']
	assert candidate('A B C') == ['a', 'b', 'c']
	assert candidate('a b c') == ['a', 'b', 'c']
	assert candidate('Test String') == ['test','string']
	assert candidate("hi") == ["hi"]
	assert candidate('python web framework') == [
    'python', 'web', 'framework']
	assert candidate(
    'How Now Brown Cow') == ['how', 'now', 'brown', 'cow']
	assert candidate(
    'This is a string') == ['this', 'is', 'a','string']
	assert candidate(
    "This is a test string"
) == ["this", "is", "a", "test", "string"]
	assert candidate("i") == ["i"]
	assert candidate('a b') == ['a', 'b']
	assert candidate('a') == ['a']
	assert candidate('This Is A Test String') == ['this', 'is', 'a', 'test','string']
	assert candidate('test string') == ['test','string']
	assert candidate('I like pie') == ['i', 'like', 'pie']
	assert candidate('python is the best language') == ['python', 'is', 'the', 'best', 'language']
	assert candidate('i') == ['i']
	assert candidate('1,222,333') == ['1,222,333']
	assert candidate('HELLO WORLD!') == ['hello', 'world!']
	assert candidate('Test String 123') == ['test','string', '123']
	assert candidate(string='A sentence without punctuation') == ['a','sentence', 'without', 'punctuation']
	assert candidate(
    '1234567890') == ['1234567890']
	assert candidate(
    "Howdy, world!"
) == ["howdy,", "world!"]
	assert candidate('hello') == ['hello']
	assert candidate('hello world!') == ['hello', 'world!']
	assert candidate('this IS a test STRING') == ['this', 'is', 'a', 'test','string']
	assert candidate(
    'Data Science at the Command Line') == ['data','science', 'at', 'the', 'command', 'line']
	assert candidate('oNLy cAPS wOrdS') == ['only', 'caps', 'words']
def test_check():
	check(split_string)
