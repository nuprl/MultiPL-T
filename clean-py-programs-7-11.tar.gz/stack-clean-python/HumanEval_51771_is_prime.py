def is_prime(number: int) -> bool:
    """ 
     Info:
     Check if a number is prime, if so return True if not return False
     
     Paramaters:
     number: int - The number to check if is prime.
     
     Usage:
     is_prime(number)
     
     Returns:
     bool
     """
	### Canonical solution below ###    
    if number <= 0: return False
        
    for i in range(2, number):
        if number % i == 0: return False

    return True

### Unit tests below ###
def check(candidate):
	assert candidate(17) == True
	assert candidate(49) == False
	assert candidate(46) == False
	assert candidate(11) == True
	assert candidate(213) == False
	assert candidate(32) == False
	assert candidate(2) == True
	assert candidate(-1) == False
	assert candidate(37) == True
	assert candidate(34) == False
	assert candidate(-12) == False
	assert candidate(44) == False
	assert candidate(8) == False
	assert candidate(21) == False
	assert candidate(48) == False
	assert candidate(30) == False
	assert candidate(13196) == False
	assert candidate(101) == True
	assert candidate(24) == False
	assert candidate(45) == False
	assert candidate(131) == True
	assert candidate(9) == False
	assert candidate(38) == False
	assert candidate(212) == False
	assert candidate(133) == False
	assert candidate(-7) == False
	assert candidate(31) == True
	assert candidate(22) == False
	assert candidate(13197) == False
	assert candidate(0) == False
	assert candidate(26) == False
	assert candidate(8919) == False
	assert candidate(13) == True
	assert candidate(6) == False
	assert candidate(15) == False
	assert candidate(7) == True
	assert candidate(942) == False
	assert candidate(132) == False
	assert candidate(199) == True
	assert candidate(40) == False
	assert candidate(29) == True
	assert candidate(211) == True
	assert candidate(37)
	assert candidate(20) == False
	assert candidate(10000) == False
	assert candidate(12) == False
	assert candidate(42) == False
	assert candidate(27) == False
	assert candidate(9879) == False
	assert candidate(97) == True
	assert candidate(14) == False
	assert candidate(25) == False
	assert candidate(33) == False
	assert candidate(23) == True
	assert candidate(36) == False
	assert candidate(4) == False
	assert candidate(28) == False
	assert candidate(10) == False
	assert candidate(5) == True
	assert candidate(35) == False
	assert candidate(50) == False
	assert candidate(1000) == False
	assert candidate(16) == False
	assert candidate(52) == False
	assert candidate(7919) == True
	assert candidate(3) == True
	assert candidate(100) == False
	assert candidate(19) == True
	assert candidate(18) == False
	assert candidate(200) == False
def test_check():
	check(is_prime)
