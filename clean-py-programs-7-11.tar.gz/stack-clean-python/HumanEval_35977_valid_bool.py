def valid_bool(boolean_str):
    """ 
     Returns true if string given is a valid boolean
     """
	### Canonical solution below ###    
    if boolean_str.lower() in ['true', '1', 'false', '0']:
        return True
    return False

### Unit tests below ###
def check(candidate):
	assert candidate('not a boolean') == False
	assert candidate('yEs') == False
	assert candidate('-0.0') == False
	assert candidate('000000001') == False
	assert candidate('oN') == False
	assert candidate('no') == False
	assert candidate('tru') == False
	assert candidate('true') == True
	assert candidate('Nope') == False
	assert candidate("true") is True
	assert candidate("true") == True
	assert candidate('TrUe') == True
	assert candidate('1 ') == False
	assert candidate('00') == False
	assert candidate('YES') == False
	assert candidate('false') is True
	assert candidate('0') == True
	assert candidate('falsefalse') == False
	assert candidate("n") is False
	assert candidate("N") is False
	assert candidate("0") is True
	assert candidate("FaLsE") is True
	assert candidate('bar') == False
	assert candidate('-1') == False
	assert candidate('FaLsE ') == False
	assert candidate("1") == True
	assert candidate("True") is True
	assert candidate('abcdefghijklmnopqrstuvwxyz') == False
	assert candidate('No') == False
	assert candidate('wut?') == False
	assert candidate("True") == True
	assert candidate('True ') == False
	assert candidate('y') == False
	assert candidate('ON') == False
	assert candidate('T') == False
	assert candidate('1.234') == False
	assert candidate('yes') == False
	assert candidate('0 ') == False
	assert candidate("false") == True
	assert candidate('nO') == False
	assert candidate('1  ') == False
	assert candidate('FaLsE   ') == False
	assert candidate('TrUe ') == False
	assert candidate('FALSE') == True
	assert candidate('foo') == False
	assert candidate('11') == False
	assert candidate('true false') == False
	assert candidate('F') == False
	assert candidate('false true') == False
	assert candidate("FALSE") is True
	assert candidate('FaLsE') == True
	assert candidate("123") is False
	assert candidate("1230") is False
	assert candidate("False") is True
	assert candidate('t') == False
	assert candidate('nope') == False
	assert candidate('100000000') == False
	assert candidate('yeah') == False
	assert candidate('010000000') == False
	assert candidate('123456789012345678901234567890') == False
	assert candidate('1.1') == False
	assert candidate('TrUe    ') == False
	assert candidate('n') == False
	assert candidate('True  ') == False
	assert candidate('OFF') == False
	assert candidate('Y') == False
	assert candidate("TRUE") is True
	assert candidate('True') is True
	assert candidate('false true false') == False
	assert candidate('OfF') == False
	assert candidate("Yes") is False
	assert candidate('!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~') == False
	assert candidate('TrUe     ') == False
	assert candidate('False ') == False
	assert candidate("0") == True
	assert candidate("false") is True
	assert candidate('000') == False
	assert candidate("TrUe") is True
	assert candidate('100') == False
	assert candidate('true false true') == False
	assert candidate('-1.234') == False
	assert candidate("YES") is False
	assert candidate('1') == True
	assert candidate('ABCDEFGHIJKLMNOPQRSTUVWXYZ') == False
	assert candidate('ye') == False
	assert candidate('TRUE') == True
	assert candidate("NO") is False
	assert candidate('110000001') == False
	assert candidate('0.0') == False
	assert candidate('Yes') == False
	assert candidate('N') == False
	assert candidate('false') == True
	assert candidate('0') is True
	assert candidate('on') == False
	assert candidate('FaLsE    ') == False
	assert candidate("y") is False
	assert candidate('False') == True
	assert candidate("Y") is False
	assert candidate('Yeah') == False
	assert candidate('truetrue') == False
	assert candidate('100000001') == False
	assert candidate("no") is False
	assert candidate('TrUe  ') == False
	assert candidate('f') == False
	assert candidate("False") == True
	assert candidate("1") is True
	assert candidate('False  ') == False
	assert candidate("yes") is False
	assert candidate('FaLsE  ') == False
	assert candidate("True123") is False
	assert candidate('010000001') == False
	assert candidate('1234') == False
	assert candidate('falsetruefalse') == False
	assert candidate('-0.1') == False
	assert candidate('wut') == False
	assert candidate('fal') == False
	assert candidate('1234567890') == False
	assert candidate('NO') == False
	assert candidate('TrUe   ') == False
	assert candidate('110000000') == False
	assert candidate('1e234') == False
	assert candidate('True') == True
	assert candidate('0  ') == False
	assert candidate('0.1') == False
	assert candidate('000000000') == False
	assert candidate('FaLsE     ') == False
	assert candidate("No") is False
	assert candidate("0123") is False
	assert candidate('1') is True
	assert candidate('off') == False
	assert candidate('banana') == False
def test_check():
	check(valid_bool)
