def decode_string(s):
    """
    Decode bytes s to string. Return original if decode failed.
    """
    ### Canonical solution below ###
    try:
        return s.decode('utf-8')
    except (UnicodeDecodeError, AttributeError):
        return s


### Unit tests below ###
def check(candidate):
	assert candidate(u'\u4e2d\u6587') == u'\u4e2d\u6587'
	assert candidate('hello'.encode('utf-8')) == 'hello'
	assert candidate('中') == '中'
	assert candidate(b"foo") == "foo"
	assert candidate(b'\xc2\x80') == '\u0080'
	assert candidate(None) is None
	assert candidate(123) == 123
	assert candidate(b'abc') == 'abc'
	assert candidate('hello') == 'hello'
	assert candidate(u'abc') == 'abc'
	assert candidate(b'hello') == 'hello'
	assert candidate('bar') == 'bar'
	assert candidate('中文') == '中文'
	assert candidate('hello\xff') == 'hello\xff'
	assert candidate(b'') == ''
	assert candidate(b'\xff\xff\xff') == b'\xff\xff\xff'
	assert candidate('abc') == 'abc'
	assert candidate(b'\x80abc') == b'\x80abc'
	assert candidate(u'abc') == u'abc'
	assert candidate(b"") == ""
	assert candidate(b'\xe4\xbd\xa0\xe5\xa5\xbd') == u'你好'
	assert candidate(1) == 1
	assert candidate(b'\xe4\xbd\xa0\xe5\xa5\xbd') == '你好'
	assert candidate(u'你好') == u'你好'
	assert candidate(b'\xf0\x90\x80\x80') == '\U00010000'
	assert candidate(b'\xff') == b'\xff'
	assert candidate(u'\xff') == '\xff'
	assert candidate(b'\xe4\xb8\xad\xe6\x96\x87') == u'中文'
	assert candidate(u'\u4e2d\u6587') == '\u4e2d\u6587'
	assert candidate(b'foo') == 'foo'
	assert candidate(b'\xf8\x88\x80\x80\x80') == b'\xf8\x88\x80\x80\x80'
	assert candidate("foo") == "foo"
	assert candidate(b'\x80') == b'\x80'
	assert candidate(None) == None
	assert candidate(b'\xc3\xa9') == u'é'
	assert candidate(b'\xe4\xb8\xad\xe6\x96\x87') == '中文'
	assert candidate(b'\xe0\xa0\x80') == '\u0800'
	assert candidate(b"abc") == "abc"
	assert candidate(u'hello') == 'hello'
	assert candidate(b'\xfc\x84\x80\x80\x80\x80') == b'\xfc\x84\x80\x80\x80\x80'
	assert candidate(u'\xe9') == u'\xe9'
def test_check():
	check(decode_string)
