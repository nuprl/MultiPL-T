def longitud_url(url):
    """ Determina la longitud de la url
    url: es la direccion de la pagina web """
    ### Canonical solution below ###
    return len(str(url))


### Unit tests below ###
def check(candidate):
	assert candidate(
    "https://www.youtube.com/watch?v=5L13aR7u-j4&list=PL032B_GjLSupaGtbbnl7-iDt-uV4-hzYh&index=4") == 91, "longitud url incorrecta"
	assert candidate(
    'https://www.udacity.com/courses/all') == len(
        'https://www.udacity.com/courses/all'), 'longitud de la url incorrecta'
	assert candidate(
    "http://www.ibm.com") == 18, "longitud de url incorrecta"
	assert candidate(
    "https://www.pagina12.com") == 24, "Longitud incorrecta"
	assert candidate(
    "http://www.google.com") == 21, "Should be 21"
	assert candidate(
    "https://www.pagina12.com/") == 25, "Longitud incorrecta"
def test_check():
	check(longitud_url)
