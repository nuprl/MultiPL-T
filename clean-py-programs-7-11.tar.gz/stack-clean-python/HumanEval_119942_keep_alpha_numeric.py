def keep_alpha_numeric(input_text: str) -> str:
    """ Remove any character except alphanumeric characters """
    ### Canonical solution below ###
    return ''.join(c for c in input_text if c.isalnum())


### Unit tests below ###
def check(candidate):
	assert candidate("abc±123") == "abc123"
	assert candidate('Hello World!!!') == 'HelloWorld'
	assert candidate(input_text='abc123#xyz') == 'abc123xyz'
	assert candidate("abc¦123") == "abc123"
	assert candidate('1234567890_') == '1234567890'
	assert candidate('123abc') == '123abc'
	assert candidate("1234\t5678") == "12345678"
	assert candidate('1234567890!') == '1234567890'
	assert candidate(input_text="!@#$%^&*()_+~`|}{][]['><,./?=-") == ""
	assert candidate("") == ""
	assert candidate("abc£123") == "abc123"
	assert candidate(
    "1234567890") == "1234567890", "String with digits"
	assert candidate('abc123 def') == 'abc123def'
	assert candidate("123abc") == "123abc"
	assert candidate(input_text='abcd') == 'abcd'
	assert candidate(input_text="Hello World!") == "HelloWorld"
	assert candidate(' ') == ''
	assert candidate("1234\u30005678") == "12345678"
	assert candidate(input_text="") == ""
	assert candidate("abc¥123") == "abc123"
	assert candidate('abc123 def_') == 'abc123def'
	assert candidate('123.123') == '123123'
	assert candidate('12345678') == '12345678'
	assert candidate('abc123 def?') == 'abc123def'
	assert candidate("abc_123 def") == "abc123def"
	assert candidate('Ab1234!') == 'Ab1234'
	assert candidate("abc€123") == "abc123"
	assert candidate("foo") == "foo"
	assert candidate('hello world!') == 'helloworld'
	assert candidate("abc!@#") == "abc"
	assert candidate('!@#Hello World') == 'HelloWorld'
	assert candidate('HELLO WORLD') == 'HELLOWORLD'
	assert candidate(input_text="abcd!@#") == "abcd"
	assert candidate("abc¢123") == "abc123"
	assert candidate(input_text='123#xyz!') == '123xyz'
	assert candidate('hello world') == 'helloworld'
	assert candidate(input_text="Hello 123") == "Hello123"
	assert candidate(
    "hello world!") == "helloworld", "String with punctuation"
	assert candidate('1234') == '1234'
	assert candidate("!@#$%^&*()") == ""
	assert candidate(
    "The 5 quick brown fox jumps over the 2 lazy dogs") == "The5quickbrownfoxjumpsoverthe2lazydogs"
	assert candidate("1234\n5678") == "12345678"
	assert candidate("12345") == "12345"
	assert candidate("abc_123") == "abc123"
	assert candidate(input_text='this is a test 123 ') == 'thisisatest123'
	assert candidate("123") == "123"
	assert candidate("1234\u205f5678") == "12345678"
	assert candidate("1234567890") == "1234567890"
	assert candidate('123abcABC!@#') == '123abcABC'
	assert candidate("!@#123abc") == "123abc"
	assert candidate(input_text='abcd!@#') == 'abcd'
	assert candidate(input_text='abc123#xyz!') == 'abc123xyz'
	assert candidate('1234567890!@#$%^&*()1234567890') == '12345678901234567890'
	assert candidate('Hello World!!') == 'HelloWorld'
	assert candidate("abc") == "abc"
	assert candidate('1234567890.') == '1234567890'
	assert candidate(
    "hello world") == "helloworld", "String with spaces"
	assert candidate('!@#$%^&*()_+|}{":?><') == ''
	assert candidate('1234567890-') == '1234567890'
	assert candidate(
    '1234567890!@#$%^&*()') == '1234567890', "Should be 1234567890"
	assert candidate('1234567890/') == '1234567890'
	assert candidate("1234\u20095678") == "12345678"
	assert candidate("abc¬123") == "abc123"
	assert candidate('abc123 def-') == 'abc123def'
	assert candidate("abc123!@#") == "abc123"
	assert candidate('Ab1234_') == 'Ab1234'
	assert candidate("abc\r123") == "abc123"
	assert candidate('1234567890') == '1234567890'
	assert candidate('hello') == 'hello'
	assert candidate(input_text="!@#") == ""
	assert candidate(input_text="abcd") == "abcd"
	assert candidate('Hello World') == 'HelloWorld'
	assert candidate('1234567890,') == '1234567890'
	assert candidate('abc123') == 'abc123'
	assert candidate("!@#$%^&*()_+{}|:\"<>?[]\;',./~`") == ""
	assert candidate("1234\ufeff5678") == "12345678"
	assert candidate(input_text="!@#$%^&*()_+~`|}{][]['><,./?=-1234567890") == "1234567890"
	assert candidate(input_text='this is a test') == 'thisisatest'
	assert candidate("abc123ABC") == "abc123ABC"
	assert candidate('1') == '1'
	assert candidate("abc 123 def") == "abc123def"
	assert candidate('Ab1234-') == 'Ab1234'
	assert candidate("abc.123 def") == "abc123def"
	assert candidate(
    " ") == "", "String with only spaces"
	assert candidate("foo123bar") == "foo123bar"
	assert candidate('123abcABC') == '123abcABC'
	assert candidate('1234567890!@#$%^&*()') == '1234567890'
	assert candidate('!@#1234567890!@#$%^&*()') == '1234567890'
	assert candidate("1234 5678") == "12345678"
	assert candidate(input_text='abc123#') == 'abc123'
	assert candidate(
    "hello-world_123") == "helloworld123", "String with dashes and underscores"
	assert candidate('1234567890"') == '1234567890'
	assert candidate("abc123!@# ") == "abc123"
	assert candidate(input_text="Hello, 123, how are you?") == "Hello123howareyou"
	assert candidate("abc123ABC!@#$%^&*()_+{}|:\"<>?[]\;',./~`") == "abc123ABC"
	assert candidate('123456789012') == '123456789012'
	assert candidate("abc\n123") == "abc123"
	assert candidate('123456789') == '123456789'
	assert candidate(input_text='this is a test 123') == 'thisisatest123'
	assert candidate('123456') == '123456'
	assert candidate('1234567890!@#$%^&*()_+') == '1234567890'
	assert candidate('1234567890\\') == '1234567890'
	assert candidate(
    "I love 3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679") == "Ilove31415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679"
	assert candidate(input_text="1234567890") == "1234567890"
	assert candidate(input_text='abcd1234') == 'abcd1234'
	assert candidate("1234\r5678") == "12345678"
	assert candidate(input_text='this is a test 123!@#$%^&*()') == 'thisisatest123'
	assert candidate('1234567890;') == '1234567890'
	assert candidate('a') == 'a'
	assert candidate(input_text="hello, world!") == "helloworld"
	assert candidate(input_text="abcd123") == "abcd123"
	assert candidate('1234567890\'') == '1234567890'
	assert candidate('!@#Hello World!@#') == 'HelloWorld'
	assert candidate('hello!@#world') == 'helloworld'
	assert candidate('12345678901') == '12345678901'
	assert candidate('12') == '12'
	assert candidate("!@#abc") == "abc"
	assert candidate('abc') == 'abc'
	assert candidate('Hello World!') == 'HelloWorld'
	assert candidate(input_text='abc123') == 'abc123'
	assert candidate('1234567890:') == '1234567890'
	assert candidate('abc123 def$') == 'abc123def'
	assert candidate("1234\u00a05678") == "12345678"
	assert candidate('12345') == '12345'
	assert candidate("foo123bar!") == "foo123bar"
	assert candidate(
    "The quick brown fox jumps over the lazy dog") == "Thequickbrownfoxjumpsoverthelazydog"
	assert candidate("abc\t123") == "abc123"
	assert candidate(input_text="1234") == "1234"
	assert candidate("!@#abc123") == "abc123"
	assert candidate(input_text='this is a test, 123') == 'thisisatest123'
	assert candidate("abc123") == "abc123"
	assert candidate("abc 123") == "abc123"
	assert candidate('123') == '123'
	assert candidate(
    '1234567890') == '1234567890'
	assert candidate("abc\v123") == "abc123"
	assert candidate(input_text='this is a test123') == 'thisisatest123'
	assert candidate(
    '1234567890') == '1234567890', "Should be 1234567890"
	assert candidate(input_text="123") == "123"
	assert candidate("abc-123 def") == "abc123def"
	assert candidate('abc123 def!') == 'abc123def'
	assert candidate(input_text='1234567890') == '1234567890'
	assert candidate(input_text="Hello! 123, how are you?") == "Hello123howareyou"
	assert candidate('Ab1234') == 'Ab1234'
	assert candidate('') == ''
	assert candidate(input_text='this is a test!@#$%^&*()') == 'thisisatest'
	assert candidate(input_text='this is a test: 123') == 'thisisatest123'
	assert candidate("foo123") == "foo123"
	assert candidate('Hello World!@#') == 'HelloWorld'
	assert candidate('1234567') == '1234567'
	assert candidate("abc\f123") == "abc123"
	assert candidate("abc!@#123") == "abc123"
	assert candidate(input_text="Hello 123, how are you?") == "Hello123howareyou"
def test_check():
	check(keep_alpha_numeric)
