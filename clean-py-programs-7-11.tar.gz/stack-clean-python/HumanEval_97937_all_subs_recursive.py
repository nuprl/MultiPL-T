def all_subs_recursive(string):
    """ 
     sub-problem: 
     all_subs_recursive([string[1:]])
     """
	### Canonical solution below ###    
    if len(string) == 1:
        return string[0]

    new_subs = []
    subs = all_subs_recursive(string[1:])

    new_subs.append(string[0])
    for sub in subs:
        new_subs.append(string[0] + sub)

    return new_subs

### Unit tests below ###
def check(candidate):
	assert candidate(list("abcd")) == ["a", "ab", "abc", "abcd"]
	assert candidate(list("abc")) == ["a", "ab", "abc"]
	assert candidate(list("abcde")) == ["a", "ab", "abc", "abcd", "abcde"]
	assert candidate(string='abc') == ['a', 'ab', 'abc']
	assert candidate(string='ab') == ['a', 'ab']
def test_check():
	check(all_subs_recursive)
