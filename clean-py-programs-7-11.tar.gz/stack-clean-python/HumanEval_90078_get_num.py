def get_num(string_with_number):
    """
    get numbers in a string

    :param string_with_number:
    :return:
    """
    ### Canonical solution below ###
    try:
        return int(''.join(ele for ele in string_with_number if ele.isdigit()))  # get digits
    except ValueError:  # if no digits in the string, just assign -1
        return -1


### Unit tests below ###
def check(candidate):
	assert candidate(string_with_number='10') == 10
	assert candidate("123abc") == 123
	assert candidate("123456 ") == 123456
	assert candidate(string_with_number='123') == 123
	assert candidate(
    'I have 1000000 dollars') == 1000000, 'I have 1000000 dollars'
	assert candidate("abc") == -1
	assert candidate(
    'Random string with no numbers') == -1, 'Random string with no numbers'
	assert candidate("1234") == 1234
	assert candidate('123-456-789') == 123456789
	assert candidate(
    'i am 123 years old') == 123, "Should be 123"
	assert candidate(u'123abc') == 123
	assert candidate('bar123baz') == 123
	assert candidate("123abc") == 123, "Testing string with digits and letters"
	assert candidate("") == -1
	assert candidate(
    'I have 1000000') == 1000000, 'I have 1000000'
	assert candidate(r'abc123') == 123
	assert candidate(
    'a1b2c3d4'
) == 1234
	assert candidate('bar123') == 123
	assert candidate(
    'This is a string with a number 4 in it') == 4, '4 is a number, not a string'
	assert candidate(string_with_number="abc") == -1
	assert candidate(
    'I have 2 cats') == 2
	assert candidate(string_with_number='123a') == 123
	assert candidate(
    'a1b2c3d4e5f6g7h8') == 12345678
	assert candidate(
    'I have ¥1000000') == 1000000, 'I have ¥1000000'
	assert candidate("No numbers here") == -1
	assert candidate("a") == -1
	assert candidate('123_456_789') == 123456789
	assert candidate(r'abc123abc') == 123
	assert candidate(
    'I have many things') == -1
	assert candidate("123a") == 123
	assert candidate("12345") == 12345
	assert candidate("1") == 1
	assert candidate(
    'a1b2c3d4e5f6g7h8i9') == 123456789
	assert candidate(
    '123abc') == 123, 'candidate("123abc") is not correct'
	assert candidate('abc123') == 123
	assert candidate(
    'abcabc123') == 123, 'candidate("abcabc123") is not correct'
	assert candidate(u'123') == 123
	assert candidate("abc34") == 34
	assert candidate(
    'abc123456def') == 123456, 'candidate("abc123456def") is not correct'
	assert candidate('23b99') == 2399
	assert candidate(string_with_number="123") == 123
	assert candidate(
    '123') == 123, 'candidate("123") is not correct'
	assert candidate(
    'a1b2c3d4e5f6') == 123456
	assert candidate(
    'I have $1000000') == 1000000, 'I have $1000000'
	assert candidate(u'abc') == -1
	assert candidate(r'123') == 123
	assert candidate( '12345' ) == 12345
	assert candidate("123") == 123, "Testing string of digits"
	assert candidate('123 456 789') == 123456789
	assert candidate(" 123456") == 123456
	assert candidate('123') == 123
	assert candidate('123 456 789 123') == 123456789123
	assert candidate("34") == 34
	assert candidate(
    'There are no numbers in this string') == -1, 'There are no numbers in this string'
	assert candidate('foo') == -1
	assert candidate(string_with_number='abc10def') == 10
	assert candidate(
    'a1b2c3d4e5f6g7h') == 1234567
	assert candidate(" 123456 ") == 123456
	assert candidate('no digits here') == -1
	assert candidate(
    "I am 2 years old.") == 2
	assert candidate('1a2b3c') == 123
	assert candidate(r'123abc') == 123
	assert candidate("abc 123 def") == 123, "Testing string with letters, spaces, digits, and letters"
	assert candidate("abc123") == 123
	assert candidate(string_with_number="This is a test string") == -1
	assert candidate("no digits here") == -1
	assert candidate("12") == 12
	assert candidate(
    'a1b2c3d4e5') == 12345
	assert candidate('123a') == 123
	assert candidate(
    '4') == 4, 'Only one number, value returned correctly'
	assert candidate(
    'I have £1000000') == 1000000, 'I have £1000000'
	assert candidate('1234567890') == 1234567890
	assert candidate(
    'I have no money') == -1, 'I have no money'
	assert candidate(
    'a1b2c3d4e5f') == 12345
	assert candidate('a123') == 123
	assert candidate(
    'I have €1000000') == 1000000, 'I have €1000000'
	assert candidate(u'123456') == 123456
	assert candidate(
    'a1b2c3d4e'
) == 1234
	assert candidate(
    'a1b2c3d4e') == 1234
	assert candidate(
    'abc123abc') == 123, 'candidate("abc123abc") is not correct'
	assert candidate(
    'I have 3 dogs') == 3
	assert candidate(
    'I have no pets') == -1
	assert candidate('abc') == -1
	assert candidate('12') == 12
	assert candidate('123.456.789') == 123456789
	assert candidate("abc") == -1, "Testing string with letters"
	assert candidate('123abc') == 123
	assert candidate('0') == 0
	assert candidate('123,456,789') == 123456789
	assert candidate(
    'a1b2c3d4e5f6g') == 123456
	assert candidate(
    'This is just a string with no numbers in it') == -1, 'No numbers, no value returned'
	assert candidate(
    'Random string with a 3 in it') == 3, 'Random string with a 3 in it'
	assert candidate("abc123def") == 123
	assert candidate("34abc") == 34
	assert candidate(
    '123') == 123, '123'
	assert candidate(
    'I have no age') == -1, "Should be -1"
	assert candidate(r'abc') == -1
	assert candidate(
    'a1b2c3d4e5f6g7') == 1234567
	assert candidate(string_with_number="This is a test string 123") == 123
	assert candidate('1') == 1
	assert candidate('23') == 23
	assert candidate(u'abc123def') == 123
	assert candidate("abc123") == 123, "Testing string with letters and digits"
	assert candidate(
    'four') == -1, 'No numbers, no value returned'
	assert candidate(
    'abc') == -1, 'candidate("abc") is not correct'
	assert candidate(string_with_number="123abc") == 123
	assert candidate(u'abc123') == 123
	assert candidate(
    'There are 12 numbers in this string') == 12, 'There are 12 numbers in this string'
	assert candidate("123") == 123
	assert candidate("abc 123") == 123, "Testing string with letters and spaces and digits"
def test_check():
	check(get_num)
