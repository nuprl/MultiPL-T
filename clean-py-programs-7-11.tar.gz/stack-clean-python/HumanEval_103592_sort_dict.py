def sort_dict(src_dict):
    """ 
     Sort given dictionary
     
     :param src_dict: source dict
     :return: sorted dictionary
     """
	### Canonical solution below ###    
    sorted_dict = {k: src_dict[k] for k in sorted(src_dict.keys())}
    return sorted_dict

### Unit tests below ###
def check(candidate):
	assert candidate(dict(b=1, a=2)) == dict(a=2, b=1)
	assert candidate(dict(a=2, b=1, c=3)) == dict(a=2, b=1, c=3)
	assert candidate(
    {
        1: "one",
        2: "two",
        3: "three",
        4: "four",
        5: "five",
        6: "six",
        7: "seven",
        8: "eight",
        9: "nine",
        10: "ten",
    }
) == {
    1: "one",
    2: "two",
    3: "three",
    4: "four",
    5: "five",
    6: "six",
    7: "seven",
    8: "eight",
    9: "nine",
    10: "ten",
}
	assert candidate(dict(f=6, e=5, d=4, c=3, b=2, a=1)) == dict(a=1, b=2, c=3, d=4, e=5, f=6)
	assert candidate(dict(b=2, a=1)) == dict(a=1, b=2)
	assert candidate(dict(a=1, c=3, b=2, e=4)) == dict(a=1, b=2, c=3, e=4)
	assert candidate(dict(b=2, c=3, a=1)) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(src_dict={"c": 3, "a": 1, "b": 2}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5)) == dict(a=1, b=2, c=3, d=4, e=5)
	assert candidate(dict(b=2, a=1, c=3, d=4)) == dict(a=1, b=2, c=3, d=4)
	assert candidate(dict(b=2, c=3, a=1, e=5, d=4)) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
	assert candidate(dict(b=2, a=1, c=3, d=4)) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4}
) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
	assert candidate(dict(b=2, c=3, a=1, d=4, e=5)) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
	assert candidate(src_dict={"b": 2, "c": 3, "a": 1, "d": 4, "e": 5}) == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
	assert candidate(dict(a=1, b=2, c=3)) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
	assert candidate(src_dict={'b': 2, 'a': 1}) == {'a': 1, 'b': 2}
	assert candidate(dict(c=3, b=2, a=1)) == dict(a=1, b=2, c=3)
	assert candidate(dict(c=3)) == dict(c=3)
	assert candidate(src_dict={"b": 1, "a": 2, "c": 3}) == {'a': 2, 'b': 1, 'c': 3}
	assert candidate(src_dict={"b": 2, "a": 1}) == {"a": 1, "b": 2}
	assert candidate(src_dict={}) == {}
	assert candidate(src_dict={2: 2, 1: 1}) == {1: 1, 2: 2}
	assert candidate(src_dict={"a": 1, "c": 3, "b": 2}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(
    {'d': 4, 'c': 3, 'b': 2, 'a': 1}
) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
	assert candidate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}
	assert candidate(src_dict={"b": 2, "c": 3, "a": 1}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(src_dict={'a': 1, 'c': 3, 'b': 2}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(a=1, b=2)) == dict(a=1, b=2)
	assert candidate(dict(b=2, c=3, a=1)) == dict(a=1, b=2, c=3)
	assert candidate(src_dict={'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
	assert candidate(dict(b=2)) == dict(b=2)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3}
) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(a=1)) == dict(a=1)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
	assert candidate(src_dict={"a": 1, "b": 2, "c": 3}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(b=1, a=2, c=3)) == dict(a=2, b=1, c=3)
	assert candidate(
    {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}
	assert candidate(src_dict={'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(src_dict={1: 1, 2: 2}) == {1: 1, 2: 2}
	assert candidate(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == dict(a=1, b=2, c=3, d=4, e=5, f=6)
	assert candidate(src_dict={"c": 3, "b": 2, "a": 1}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(dict(a=2, c=3, b=1)) == dict(a=2, b=1, c=3)
	assert candidate(src_dict={3: 1, 2: 2, 1: 3}) == {1: 3, 2: 2, 3: 1}
	assert candidate(dict(b=2, a=1, c=3)) == dict(a=1, b=2, c=3)
	assert candidate(dict(a=1, c=3, b=2)) == dict(a=1, b=2, c=3)
	assert candidate(
    {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
        "key4": "value4",
        "key5": "value5",
    }
) == {
    "key1": "value1",
    "key2": "value2",
    "key3": "value3",
    "key4": "value4",
    "key5": "value5",
}
	assert candidate(dict(c=3, b=2, e=4, a=1)) == dict(a=1, b=2, c=3, e=4)
	assert candidate({"b": 2, "c": 3, "a": 1}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(
    {'a': 1, 'c': 3, 'b': 2, 'd': 4}
) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
	assert candidate(dict()) == dict()
	assert candidate(dict(a=1, c=3, b=2, d=4, e=5)) == dict(a=1, b=2, c=3, d=4, e=5)
	assert candidate(dict(c=3, a=1, b=2)) == dict(a=1, b=2, c=3)
	assert candidate(src_dict={"b": 2, "a": 1, "c": 3}) == {"a": 1, "b": 2, "c": 3}
	assert candidate({"c": 3, "b": 2, "a": 1}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(src_dict={"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
	assert candidate(src_dict={'a': 1}) == {'a': 1}
	assert candidate(
    {
        "key1": "value1",
        "key5": "value5",
        "key3": "value3",
        "key2": "value2",
        "key4": "value4",
    }
) == {
    "key1": "value1",
    "key2": "value2",
    "key3": "value3",
    "key4": "value4",
    "key5": "value5",
}
	assert candidate(dict(a=1, b=2, c=3, d=4)) == dict(a=1, b=2, c=3, d=4)
	assert candidate(dict(b=2, a=1, c=3)) == {'a': 1, 'b': 2, 'c': 3}
	assert candidate(dict(b=2, a=1)) == {'a': 1, 'b': 2}
	assert candidate(src_dict={"b": 2, "c": 3, "a": 1, "d": 4}) == {"a": 1, "b": 2, "c": 3, "d": 4}
def test_check():
	check(sort_dict)
