def ratio(rels, nonrels):
    """ expect two floats
    """
    ### Canonical solution below ###
    dem = rels + nonrels
    if dem > 0.0:
        return round((rels * rels) / dem, 2)
    else:
        return 0.0


### Unit tests below ###
def check(candidate):
	assert candidate(0.9, 0.1) == 0.81
	assert candidate(0, 4) == 0.0
	assert candidate(0.0, 0.0) == 0.0
	assert candidate(0.0, 5.0) == 0.0
	assert candidate(0,2) == 0.0
	assert candidate(0.99, 0.01) == 0.98
	assert candidate(2, 2) == 1.0
	assert candidate(0,0) == 0.0
	assert candidate(0, 2) == 0.0
	assert candidate(0.0, 100.0) == 0.0
	assert candidate(1.0, 100.0) == 0.01
	assert candidate(0, 0) == 0.0
	assert candidate(0, 20) == 0.0
	assert candidate(0, 3) == 0.0
	assert candidate(2,2) == 1.0
	assert candidate(0.0, 0.5) == 0.0
	assert candidate(0,10) == 0.0
	assert candidate(0.0, 1.0) == 0.0
	assert candidate(1.0, 0.0) == 1.0
	assert candidate(0, 1) == 0.0
	assert candidate(0,1) == 0.0
def test_check():
	check(ratio)
