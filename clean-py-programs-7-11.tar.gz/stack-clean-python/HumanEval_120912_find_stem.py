def find_stem(arr):
    """Find longest common substring in array of strings.

    From https://www.geeksforgeeks.org/longest-common-substring-array-strings/
    """
    ### Canonical solution below ###
    # Determine size of the array
    n_items_in_array = len(arr)

    # Take first word from array as reference
    reference_string = arr[0]
    n_chars_in_first_item = len(reference_string)

    res = ""
    for i_char in range(n_chars_in_first_item):
        # Generate all starting substrings of our reference string
        stem = reference_string[:i_char]

        j_item = 1  # Retained in case of an array with only one item
        for j_item in range(1, n_items_in_array):
            # Check if the generated stem is common to to all words
            if not arr[j_item].startswith(stem):
                break

        # If current substring is present in all strings and its length is
        # greater than current result
        if (j_item + 1 == n_items_in_array) and (len(res) < len(stem)):
            res = stem

    return res


### Unit tests below ###
def check(candidate):
	assert candidate(arr=['abc', 'abc', 'ab']) == 'ab'
	assert candidate(["a", "b"]) == ""
	assert candidate(
    ['abcfgh', 'abcefg', 'abcgh', 'abcf', 'abce', 'abc']
) == 'abc', 'Test 4 failed'
	assert candidate(['a', 'b', 'c', 'd', 'e']) == ''
	assert candidate(["a", "b", "", "c"]) == ""
	assert candidate(["", "a"]) == ""
	assert candidate(["abc", "ab", "cd"]) == "ab"
	assert candidate(
    ['abcfgh', 'abcefg', 'abcgh', 'abcf']
) == 'abc', 'Test 2 failed'
	assert candidate(["a", "", "b", "c"]) == ""
	assert candidate(arr=['abc', 'ab', 'ab']) == 'ab'
	assert candidate(["abc", "def", "ghi"]) == ""
	assert candidate(
    ['abcfgh', 'abcefg', 'abcgh']
) == 'abc', 'Test 1 failed'
	assert candidate(
    ["abca", "abcd", "abcb", "abc", "acb", "ab", "ac"]
) == "a"
	assert candidate(['aa', 'b', 'c', 'dd', 'e']) == ''
	assert candidate(
    ["abcdxyz", "abcde", "abcdf", "abddefg"]) == "abcd"
	assert candidate(["a", ""]) == ""
	assert candidate(["geek", "geezer"]) == "gee"
	assert candidate(["a", "b", "c", ""]) == ""
	assert candidate(
    ['dog', 'racecar', 'car']) == ''
	assert candidate(["", ""]) == ""
	assert candidate(["ab", "cd", "ef", "gh"]) == ""
	assert candidate(
    ["abca", "abcd", "abcb", "abc", "acb", "ab", "ac", "b"]
) == "a"
	assert candidate(["", "a", "b", "c"]) == ""
	assert candidate(
    ["flowers", "flight", "flow", "football", "foot", "foo", "f"]) == "f"
	assert candidate(["abcd", "abc", "abc"]) == "abc"
	assert candidate(
    ["flower", "flow", "flight"]) == "flow"
	assert candidate(["a", "b", ""]) == ""
	assert candidate(["ab", "cd", "ef", "gh", "ij"]) == ""
	assert candidate(['']) == ''
	assert candidate(
    ["dog", "racecar", "car"]) == ""
	assert candidate(["", "a", "b"]) == ""
	assert candidate(["ab", "cd", "ef"]) == ""
	assert candidate(["a", "", "b"]) == ""
	assert candidate(
    ["dog", "cat", "car"]) == ""
	assert candidate(
    ["ab", "xyz", "1221"]) == ""
	assert candidate(
    ["dog", "racecar", "car"]
) == "", "Should be ''"
	assert candidate(["dog", "cat", "apple", "app"]) == ""
	assert candidate(["ab", "cd", "ef", "gh", "ij", "kl"]) == ""
	assert candidate(
    ['abcfgh', 'abcefg', 'abcgh', 'abcf', 'abce']
) == 'abc', 'Test 3 failed'
def test_check():
	check(find_stem)
