def find_largest(n: int, L: list) -> list:
    """Return the n largest values in L in order from smallest to largest.
    >>> L= [3, 4, 7, -1, 2, 5]
    >>> find_largest(3, L)
    [4, 5, 7]
    """
    ### Canonical solution below ###
    copy=sorted(L)
    return copy[-n:]


### Unit tests below ###
def check(candidate):
	assert candidate(0, []) == []
	assert candidate(1, [1, 2, 3]) == [3]
	assert candidate(2, []) == []
	assert candidate(2, [3, 4, 7, -1, 2, 5]) == [5, 7]
	assert candidate(2, [3, 3, 3]) == [3, 3]
	assert candidate(3, [3, 4, 7, -1, 2, 5])!= [5, 4, 7]
	assert candidate(3, [3, 4, 7, -1, 2, 5, 4]) == [4, 5, 7]
	assert candidate(3, [3]) == [3]
	assert candidate(1, []) == []
	assert candidate(1, [3]) == [3]
	assert candidate(3, []) == []
	assert candidate(2, [3]) == [3]
	assert candidate(3, [3, 4, 7, 3, 2, 5]) == [4, 5, 7]
	assert candidate(3, [3, 4, 7, 4, 2, 5]) == [4, 5, 7]
	assert candidate(1, [3, 3, 3]) == [3]
	assert candidate(3, [3, 3, 3]) == [3, 3, 3]
	assert candidate(1, [3, 4, 7, -1, 2, 5]) == [7]
	assert candidate(3, [3, 4, 7, -1, 2, 5]) == [4, 5, 7]
	assert candidate(4, [5]) == [5]
	assert candidate(1, [1]) == [1]
	assert candidate(3, [5]) == [5]
	assert candidate(3, [3, 4, 7, -1, 2, 5, 1, 0]) == [4, 5, 7]
	assert candidate(1, [5]) == [5]
def test_check():
	check(find_largest)
