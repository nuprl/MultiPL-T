def deindented_source(src):
    """ De-indent source if all lines indented.
     
     This is necessary before parsing with ast.parse to avoid "unexpected
     indent" syntax errors if the function is not module-scope in its
     original implementation (e.g., staticmethods encapsulated in classes).
     
     Parameters
     ----------
     src : str
     input source
     
     Returns
     -------
     str :
     de-indented source; the first character of at least one line is
     non-whitespace, and all other lines are deindented by the same
     """
	### Canonical solution below ###    
    lines = src.splitlines()
    n_chars = float("inf")
    for line in lines:
        len_line = len(line)
        idx = 0

        # we're Python 3, so we assume you're not mixing tabs and spaces
        while idx < n_chars and idx < len_line and line[idx] in [" ", '\t']:
            idx += 1

        if len_line > idx:
            n_chars = min(idx, n_chars)

    lines = [line[n_chars:] for line in lines]
    src = "\n".join(lines)
    return src

### Unit tests below ###
def check(candidate):
	assert candidate(
    """
    def foo():
        if True:
            def bar():
                print('bar')
    """
) == """
def foo():
    if True:
        def bar():
            print('bar')
"""
	assert candidate(
    """
    def foo():
        if True:
            def bar():
                print('bar')
        else:
            print('baz')
    """
) == """
def foo():
    if True:
        def bar():
            print('bar')
    else:
        print('baz')
"""
	assert candidate(
    """
    def foo():
        if True:
            def bar():
                print('bar')
        elif False:
            print('baz')
        else:
            print('baz')
    """
) == """
def foo():
    if True:
        def bar():
            print('bar')
    elif False:
        print('baz')
    else:
        print('baz')
"""
	assert candidate(
    """
    def foo():
        def bar():
            print('bar')
    """
) == """
def foo():
    def bar():
        print('bar')
"""
	assert candidate(
    """
    def foo():
        print("hello")
    """) == """
def foo():
    print("hello")
"""
	assert candidate(
    """
    def foo():
        print('bar')
    """
) == """
def foo():
    print('bar')
"""
	assert candidate(
    """
    def foo():
        if True:
            def bar():
                print('bar')
        elif False:
            print('baz')
        else:
            print('baz')
        print('bar')
    """
) == """
def foo():
    if True:
        def bar():
            print('bar')
    elif False:
        print('baz')
    else:
        print('baz')
    print('bar')
"""
def test_check():
	check(deindented_source)
