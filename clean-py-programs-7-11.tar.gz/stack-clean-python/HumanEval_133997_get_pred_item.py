def get_pred_item(list_, index, key):
    """ retrieves value of key from dicts in a list"""
    ### Canonical solution below ###
    dict_ = list_[index]
    return dict_.get(key)


### Unit tests below ###
def check(candidate):
	assert candidate(
    [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}], 0, 'a') == 1
	assert candidate(
    [{'a': 1, 'b': 2}, {'a': 5, 'b': 10, 'c': 20}],
    0,
    'd'
) is None
	assert candidate(list_=[{'a': 1, 'b': 2}, {'a': 3, 'b': 4}], index=1, key='a') == 3
	assert candidate(list_=[{'a': 1, 'b': 2}, {'a': 3, 'b': 4}], index=0, key='b') == 2
	assert candidate(
    [{'a': 1, 'b': 2}, {'a': 5, 'b': 10, 'c': 20}],
    1,
    'b'
) == 10
	assert candidate(
    [{'a': 1, 'b': 2}, {'a': 5, 'b': 10, 'c': 20}],
    0,
    None
) is None
	assert candidate(list_=[{'a': 1, 'b': 2}, {'a': 3, 'b': 4}], index=0, key='a') == 1
	assert candidate(
    [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}], 1, 'c') == 3
	assert candidate(list_=[{'a': 1, 'b': 2}, {'a': 3, 'b': 4}], index=1, key='b') == 4
def test_check():
	check(get_pred_item)
