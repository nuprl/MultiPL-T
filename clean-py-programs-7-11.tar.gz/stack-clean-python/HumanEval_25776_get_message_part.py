def get_message_part(message):
    """ Get message part."""
	### Canonical solution below ###    
    message_part = message["payload"]
    return message_part

### Unit tests below ###
def check(candidate):
	assert candidate(
    {
        "payload": "A payload"
    }
) == "A payload"
	assert candidate(
    {
        "payload": {
            "data": "dGVzdCBtZXNzYWdlIDM=",
            "attributes": {"attribute1": "value1"},
        }
    }
) == {"data": "dGVzdCBtZXNzYWdlIDM=", "attributes": {"attribute1": "value1"}}
	assert candidate(
    {"payload": None}
) == None
	assert candidate(
    {"payload": {"text": "Hello, world!"}}) == {"text": "Hello, world!"}
	assert candidate(
    {
        "payload": {
            "data": "dGVzdCBtZXNzYWdlIDM=",
            "attributes": {"attribute1": "value1"},
        },
        "other_key": "other_value",
    }
) == {"data": "dGVzdCBtZXNzYWdlIDM=", "attributes": {"attribute1": "value1"}}
def test_check():
	check(get_message_part)
