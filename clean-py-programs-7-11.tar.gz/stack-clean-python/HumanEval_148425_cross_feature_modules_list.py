def cross_feature_modules_list():
    """ 
     :return: dictionary with a tuple of features as keys and a list of
     modules to be included if all those features are selected as values
     
     Some modules depend on more than one feature, i.e. they are included
     only if multiple features are selected. These relationships are
     described in the 'cross_modules' dictionary here.
     """
	### Canonical solution below ###    
    cross_modules = {
        ("transmission", "transmission_hurdle_rates"): [
            "transmission.operations.hurdle_costs",
            "objective.transmission.aggregate_hurdle_costs",
        ],
        ("transmission", "carbon_cap", "track_carbon_imports"): [
            "system.policy.carbon_cap" ".aggregate_transmission_carbon_emissions",
            "transmission.operations.carbon_emissions",
        ],
        ("transmission", "carbon_cap", "track_carbon_imports", "tuning"): [
            "objective.transmission.carbon_imports_tuning_costs"
        ],
        ("transmission", "simultaneous_flow_limits"): [
            "transmission.operations.simultaneous_flow_limits"
        ],
        ("prm", "elcc_surface"): [
            "project.reliability.prm.elcc_surface",
            "system.reliability.prm.elcc_surface",
        ],
        ("prm", "elcc_surface", "tuning"): [
            "objective.system.reliability.prm.dynamic_elcc_tuning_penalties"
        ],
    }
    return cross_modules

### Unit tests below ###
def check(candidate):
	assert candidate(
) == {("transmission", "transmission_hurdle_rates"): [
        "transmission.operations.hurdle_costs",
        "objective.transmission.aggregate_hurdle_costs",
    ],
    ("transmission", "carbon_cap", "track_carbon_imports"): [
        "system.policy.carbon_cap" ".aggregate_transmission_carbon_emissions",
        "transmission.operations.carbon_emissions",
    ],
    ("transmission", "carbon_cap", "track_carbon_imports", "tuning"): [
        "objective.transmission.carbon_imports_tuning_costs"
    ],
    ("transmission", "simultaneous_flow_limits"): [
        "transmission.operations.simultaneous_flow_limits"
    ],
    ("prm", "elcc_surface"): [
        "project.reliability.prm.elcc_surface",
        "system.reliability.prm.elcc_surface",
    ],
    ("prm", "elcc_surface", "tuning"): [
        "objective.system.reliability.prm.dynamic_elcc_tuning_penalties"
    ],
}
	assert candidate(
) == {
    ('transmission', 'transmission_hurdle_rates'): [
        'transmission.operations.hurdle_costs',
        'objective.transmission.aggregate_hurdle_costs'],
    ('transmission', 'carbon_cap', 'track_carbon_imports'): [
       'system.policy.carbon_cap.aggregate_transmission_carbon_emissions',
        'transmission.operations.carbon_emissions'],
    ('transmission', 'carbon_cap', 'track_carbon_imports', 'tuning'): [
        'objective.transmission.carbon_imports_tuning_costs'],
    ('transmission','simultaneous_flow_limits'): [
        'transmission.operations.simultaneous_flow_limits'],
    ('prm', 'elcc_surface'): [
        'project.reliability.prm.elcc_surface',
       'system.reliability.prm.elcc_surface'],
    ('prm', 'elcc_surface', 'tuning'): [
        'objective.system.reliability.prm.dynamic_elcc_tuning_penalties']}
	assert candidate(
) == {("transmission", "transmission_hurdle_rates"): [
    "transmission.operations.hurdle_costs",
    "objective.transmission.aggregate_hurdle_costs",
], ("transmission", "carbon_cap", "track_carbon_imports"): [
    "system.policy.carbon_cap" ".aggregate_transmission_carbon_emissions",
    "transmission.operations.carbon_emissions",
], ("transmission", "carbon_cap", "track_carbon_imports", "tuning"): [
    "objective.transmission.carbon_imports_tuning_costs"
], ("transmission", "simultaneous_flow_limits"): [
    "transmission.operations.simultaneous_flow_limits"
], ("prm", "elcc_surface"): [
    "project.reliability.prm.elcc_surface",
    "system.reliability.prm.elcc_surface",
], ("prm", "elcc_surface", "tuning"): [
    "objective.system.reliability.prm.dynamic_elcc_tuning_penalties"
]}
	assert candidate(
) == {("transmission", "transmission_hurdle_rates"): ["transmission.operations.hurdle_costs", "objective.transmission.aggregate_hurdle_costs"], ("transmission", "carbon_cap", "track_carbon_imports"): ["system.policy.carbon_cap" ".aggregate_transmission_carbon_emissions", "transmission.operations.carbon_emissions"], ("transmission", "carbon_cap", "track_carbon_imports", "tuning"): ["objective.transmission.carbon_imports_tuning_costs"], ("transmission", "simultaneous_flow_limits"): ["transmission.operations.simultaneous_flow_limits"], ("prm", "elcc_surface"): ["project.reliability.prm.elcc_surface", "system.reliability.prm.elcc_surface"], ("prm", "elcc_surface", "tuning"): ["objective.system.reliability.prm.dynamic_elcc_tuning_penalties"]}
	assert candidate(
) == {
    ("transmission", "transmission_hurdle_rates"): [
        "transmission.operations.hurdle_costs",
        "objective.transmission.aggregate_hurdle_costs",
    ],
    ("transmission", "carbon_cap", "track_carbon_imports"): [
        "system.policy.carbon_cap" ".aggregate_transmission_carbon_emissions",
        "transmission.operations.carbon_emissions",
    ],
    ("transmission", "carbon_cap", "track_carbon_imports", "tuning"): [
        "objective.transmission.carbon_imports_tuning_costs"
    ],
    ("transmission", "simultaneous_flow_limits"): [
        "transmission.operations.simultaneous_flow_limits"
    ],
    ("prm", "elcc_surface"): [
        "project.reliability.prm.elcc_surface",
        "system.reliability.prm.elcc_surface",
    ],
    ("prm", "elcc_surface", "tuning"): [
        "objective.system.reliability.prm.dynamic_elcc_tuning_penalties"
    ],
}
def test_check():
	check(cross_feature_modules_list)
