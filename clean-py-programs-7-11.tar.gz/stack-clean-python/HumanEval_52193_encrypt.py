def encrypt(plaintext, cipher, shift):
    """
    Caesar encryption of a plaintext using a shifted cipher.

    You can specify a positiv shift to rotate the cipher to the right
    and using a negative shift to rotate the cipher to the left.

    :param plaintext: the text to encrypt.
    :param cipher: set of characters, shifted in a directed to used for character substitution.
    :param shift: offset to rotate cipher.
    :returns: encrypted plaintext (ciphertext).

    See: https://en.wikipedia.org/wiki/Caesar_cipher
    Example:

    >>> encrypt("hello world", "abcdefghijklmnopqrstuvwxyz ", 1)
    'gdkknzvnqkc'
    >>> encrypt("hello world", "abcdefghijklmnopqrstuvwxyz ", -1)
    'ifmmpaxpsme'
    """
    ### Canonical solution below ###
    # calculating shifted cipher
    shifted_cipher = cipher
    if shift > 0:
        while shift > 0:
            shifted_cipher = shifted_cipher[-1] + shifted_cipher[0:len(shifted_cipher) - 1]
            shift -= 1
    else:
        while shift < 0:
            shifted_cipher = shifted_cipher[1:] + shifted_cipher[0]
            shift += 1

    return "".join([shifted_cipher[cipher.index(character)] for character in plaintext])


### Unit tests below ###
def check(candidate):
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    -26
) == "gdkknzvnqkc", "offset -26"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    -1) == "ifmmpaxpsme", "hello world failed"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    1
) == "gdkknzvnqkc"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    0
) == "hello world"
	assert candidate("hello world", "abcdefghijklmnopqrstuvwxyz ", 1)!= "ifmmpaxpsme"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    -1) == "ifmmpaxpsme"
	assert candidate(plaintext="hello world", cipher="abcdefghijklmnopqrstuvwxyz ", shift=0) == "hello world"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    1
) == "gdkknzvnqkc", "hello"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    -1
) == "ifmmpaxpsme", "world"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    1) == "gdkknzvnqkc"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    1) == "gdkknzvnqkc", "hello world"
	assert candidate(
    "gdkknzvnqkc",
    "abcdefghijklmnopqrstuvwxyz ",
    -1) == "hello world"
	assert candidate("hello world", "abcdefghijklmnopqrstuvwxyz ", 0) == "hello world"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    -1) == "ifmmpaxpsme", "hello world"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    -1
) == "ifmmpaxpsme"
	assert candidate(plaintext="HELLO WORLD", cipher="ABCDEFGHIJKLMNOPQRSTUVWXYZ ", shift=-1) == "IFMMPAXPSME"
	assert candidate(
    "ifmmpaxpsme",
    "abcdefghijklmnopqrstuvwxyz ",
    1) == "hello world"
	assert candidate(plaintext="hello world", cipher="abcdefghijklmnopqrstuvwxyz ", shift=-26) == "gdkknzvnqkc"
	assert candidate(plaintext="hello world", cipher="abcdefghijklmnopqrstuvwxyz ", shift=-1) == "ifmmpaxpsme"
	assert candidate(
    "hello world", "abcdefghijklmnopqrstuvwxyz ", -1) == "ifmmpaxpsme"
	assert candidate(
    "hello world", "abcdefghijklmnopqrstuvwxyz ", 1) == "gdkknzvnqkc", "hello world failed"
	assert candidate(plaintext="hello world", cipher="abcdefghijklmnopqrstuvwxyz ", shift=26) == "ifmmpaxpsme"
	assert candidate(
    "hello world", "abcdefghijklmnopqrstuvwxyz ", 0) == "hello world"
	assert candidate(plaintext="HELLO WORLD", cipher="ABCDEFGHIJKLMNOPQRSTUVWXYZ ", shift=1) == "GDKKNZVNQKC"
	assert candidate(
    "hello world", "abcdefghijklmnopqrstuvwxyz ", 0) == "hello world", "hello world failed"
	assert candidate(plaintext="hello world", cipher="abcdefghijklmnopqrstuvwxyz ", shift=1) == "gdkknzvnqkc"
	assert candidate(
    "hello world", "abcdefghijklmnopqrstuvwxyz ", -1) == "ifmmpaxpsme", "hello world failed"
	assert candidate(
    "hello world", "abcdefghijklmnopqrstuvwxyz ", 1) == "gdkknzvnqkc"
	assert candidate(
    "hello world",
    "abcdefghijklmnopqrstuvwxyz ",
    1) == "gdkknzvnqkc", "hello world failed"
def test_check():
	check(encrypt)
