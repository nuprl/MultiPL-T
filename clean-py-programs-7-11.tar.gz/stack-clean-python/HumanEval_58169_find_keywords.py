def find_keywords(sql, keywords):
    """ Find all the keywords in `sql`.
     
     :param sql: The sql string being manipulated.
     :param keywords: A list of all the keywords being found in sql.
     :return: A dictionary with keys of sql keywords and values of two element lists with the starting and ending indexes of the keywords.
     """
	### Canonical solution below ###    
    keyword_positions = []
    sql_len = len(sql)
    jude_list = [' ', '\n', '(', ')', '\t', ',']
    for n in range(sql_len):
        for kw in keywords:
            if sql[n:n + len(kw)].lower() == kw.lower():
                pre_single = False
                suf_single = False
                if (n == 0) or (sql[n - 1] in jude_list):
                    pre_single = True
                if (n == (sql_len - len(kw))) or (sql[n + len(kw)] in jude_list):
                    suf_single = True
                single = all([pre_single, suf_single])
                if single:
                    keyword_positions.append([sql[n:n + len(kw)], n, n + len(kw)])

    to_delete = []
    for kw1 in keyword_positions:
        for kw2 in keyword_positions:
            if (kw1[0].lower() in kw2[0].lower()) & (len(kw1[0]) < len(kw2[0])) & (kw1[1] >= kw2[1]) & (
                    kw2[2] <= kw2[2]):
                to_delete.append(kw1)

    for n in to_delete:
        if n in keyword_positions:
            keyword_positions.remove(n)

    keyword_positions = sorted(keyword_positions, key=lambda x: x[1])
    return keyword_positions

### Unit tests below ###
def check(candidate):
	assert candidate("SELECT col1, col2, col3 FROM my_table",
                     ['where', 'group', 'order']) == []
	assert candidate('select 1', ['select']) == [['select', 0, 6]]
	assert candidate('select * from a', ['join', 'where']) == []
	assert candidate("SELECT col1 FROM my_table", ['where', 'group', 'order']) == []
	assert candidate(
   'select a, b from table where c = 1', ['2']) == []
	assert candidate('select * from a join b on a.id = b.id where a.id = 10', ['select']) == [['select', 0, 6]]
	assert candidate(
   'select a, b from table where c = 1', ['a']) == [['a', 7, 8]]
	assert candidate(
   'select distinct a from b', ['distinct']) == [['distinct', 7, 15]]
def test_check():
	check(find_keywords)
