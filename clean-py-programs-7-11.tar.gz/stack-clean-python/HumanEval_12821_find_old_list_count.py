def find_old_list_count(list_id, all_lists_state):
    """
    Returns the last list size saved for the provided list
    :param list_id:
    :param all_lists_state:
    :return:
    """
    ### Canonical solution below ###
    last_size = 0
    for x in all_lists_state:
        if x['id'] == list_id:
            last_size = x['member_count']

    return last_size


### Unit tests below ###
def check(candidate):
	assert candidate(3, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 20}, {'id': 3,'member_count': 30}]) == 30
	assert candidate(1235, [{'id': 1234,'member_count': 2}, {'id': 1235,'member_count': 4}]) == 4, \
    "Expected 4, got {0}".format(candidate(1235, [{'id': 1234,'member_count': 2}, {'id': 1235,'member_count': 4}]))
	assert candidate(123, [{'id': 123,'member_count': 100}, {'id': 456,'member_count': 50}]) == 100
	assert candidate(1, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 100}, {'id': 3,'member_count': 200}]) == 10
	assert candidate(1, [{'id': 2,'member_count': 5}]) == 0
	assert candidate(1, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 20}]) == 10
	assert candidate(123, [{'id': 123,'member_count': 100}, {'id': 456,'member_count': 200}]) == 100
	assert candidate(1235, [{'id': 1234,'member_count': 400}, {'id': 1235,'member_count': 600}]) == 600
	assert candidate(2, [{'id': 1,'member_count': 2}, {'id': 2,'member_count': 3}]) == 3
	assert candidate(1236, [{'id': 1234,'member_count': 2}, {'id': 1235,'member_count': 4}]) == 0, \
    "Expected 0, got {0}".format(candidate(1236, [{'id': 1234,'member_count': 2}, {'id': 1235,'member_count': 4}]))
	assert candidate(1234567890123456789012345678901234567890,
                          [{'id': 1234567890123456789012345678901234567890,'member_count': 5000}]) == 5000
	assert candidate(1234, [{
    'id': 1234,
   'member_count': 10
}, {
    'id': 5678,
   'member_count': 100
}]) == 10
	assert candidate(1234, [{'id': 1234,'member_count': 2}, {'id': 1235,'member_count': 4}]) == 2, \
    "Expected 2, got {0}".format(candidate(1234, [{'id': 1234,'member_count': 2}, {'id': 1235,'member_count': 4}]))
	assert candidate(1, [{'id': 1,'member_count': 10}]) == 10
	assert candidate(2, []) == 0
	assert candidate(list_id='211287169', all_lists_state=[{'id': '211287169', 'name': 'Test 1','member_count': 11}]) == 11
	assert candidate(3, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 20}]) == 0
	assert candidate(9999, [{
    'id': 1234,
   'member_count': 10
}, {
    'id': 5678,
   'member_count': 100
}]) == 0
	assert candidate(123, [{'id': 123,'member_count': 100}, {'id': 456,'member_count': 200}, {'id': 789,'member_count': 300}]) == 100
	assert candidate(3, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 100}]) == 0
	assert candidate(list_id='12345', all_lists_state=[{'id': '12345','member_count': 2}]) == 2
	assert candidate(456, [{'id': 123,'member_count': 100}, {'id': 456,'member_count': 200}]) == 200
	assert candidate(3, [{'id': 1,'member_count': 2}, {'id': 2,'member_count': 4}]) == 0
	assert candidate(4, []) == 0
	assert candidate(1, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 20}, {'id': 3,'member_count': 30}]) == 10
	assert candidate(789, [{'id': 123,'member_count': 100}, {'id': 456,'member_count': 200}, {'id': 789,'member_count': 300}]) == 300
	assert candidate(123, [{"id": 123, "member_count": 4}]) == 4
	assert candidate(1, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 100}]) == 10
	assert candidate(4, [{'id': 1,'member_count': 100}, {'id': 2,'member_count': 100}, {'id': 3,'member_count': 100}, {'id': 4,'member_count': 100}]) == 100
	assert candidate(1234, [{'id': 1234,'member_count': 234567890}, {'id': 5678,'member_count': 234567890}]) == 234567890
	assert candidate(123, [{"id": 456, "member_count": 6}]) == 0
	assert candidate(2, [{'id': 1,'member_count': 1}, {'id': 2,'member_count': 2}]) == 2
	assert candidate(1234, [{'id': 5678,'member_count': 234567890}]) == 0
	assert candidate(54321, [{'id': 12345,'member_count': 10}, {'id': 54321,'member_count': 30}]) == 30
	assert candidate(1, [{'id': 1,'member_count': 1}, {'id': 2,'member_count': 2}]) == 1
	assert candidate(1234, [{'id': 1234,'member_count': 400}, {'id': 1235,'member_count': 600}]) == 400
	assert candidate(123, [{'id': 123,'member_count': 100}]) == 100
	assert candidate(list_id='12345', all_lists_state=[{'id': '12345','member_count': 2}, {'id': '54321','member_count': 3}]) == 2
	assert candidate(3, [{'id': 1,'member_count': 2}, {'id': 2,'member_count': 3}]) == 0
	assert candidate(2, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 20}, {'id': 3,'member_count': 30}]) == 20
	assert candidate(2, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 20}]) == 20
	assert candidate(2, [{'id': 1,'member_count': 10}]) == 0
	assert candidate(123, [{'id': 321,'member_count': 100}]) == 0
	assert candidate(list_id='54321', all_lists_state=[{'id': '12345','member_count': 2}, {'id': '54321','member_count': 3}]) == 3
	assert candidate(1234, [{'id': 1234,'member_count': 234567890}]) == 234567890
	assert candidate(12345, [{'id': 12345,'member_count': 10}]) == 10
	assert candidate(2, [{'id': 1,'member_count': 2}, {'id': 2,'member_count': 4}]) == 4
	assert candidate(3, [{'id': 1,'member_count': 1}, {'id': 2,'member_count': 2}]) == 0
	assert candidate(1, [{'id': 1,'member_count': 2}, {'id': 2,'member_count': 4}]) == 2
	assert candidate(1, [{'id': 1,'member_count': 5}, {'id': 2,'member_count': 10}]) == 5
	assert candidate(2, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 100}, {'id': 3,'member_count': 200}]) == 100
	assert candidate(3, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 100}, {'id': 3,'member_count': 200}]) == 200
	assert candidate(456, []) == 0
	assert candidate(123, [{'id': 123,'member_count': 100}, {'id': 321,'member_count': 100}]) == 100
	assert candidate(123, [{'id': 456,'member_count': 50}]) == 0
	assert candidate(123, []) == 0
	assert candidate(456, [{'id': 123,'member_count': 100}, {'id': 456,'member_count': 200}, {'id': 789,'member_count': 300}]) == 200
	assert candidate(123, [{'id': 124,'member_count': 100}]) == 0
	assert candidate(1, [{'id': 1,'member_count': 2}, {'id': 2,'member_count': 3}]) == 2
	assert candidate(1, [{'id': 1,'member_count': 5}]) == 5
	assert candidate(4, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 20}, {'id': 3,'member_count': 30}]) == 0
	assert candidate(123, [{"id": 123, "member_count": 4}, {"id": 456, "member_count": 6}]) == 4
	assert candidate(1, []) == 0
	assert candidate(4, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 100}, {'id': 3,'member_count': 200}]) == 0
	assert candidate(1, [{'id': 2,'member_count': 10}, {'id': 2,'member_count': 20}, {'id': 2,'member_count': 30}]) == 0
	assert candidate(2, [{'id': 1,'member_count': 10}, {'id': 2,'member_count': 100}]) == 100
	assert candidate(1234567890123456789012345678901234567891,
                          [{'id': 1234567890123456789012345678901234567890,'member_count': 5000}]) == 0
	assert candidate(4, [{'id': 1,'member_count': 100}, {'id': 2,'member_count': 100}, {'id': 3,'member_count': 100}]) == 0
def test_check():
	check(find_old_list_count)
