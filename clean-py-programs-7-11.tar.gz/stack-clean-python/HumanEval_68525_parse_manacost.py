def parse_manacost(s: str):
    """
    Split a mana cost string into a list of each mana cost symbol 
    in the string.
    
    :param cost: The mana cost :class:string.
    :return: :class:list
    :rtype: list
    """
    ### Canonical solution below ###
    cost = s[:]
    out = []
    buf = ''
    
    # Handle split card mana costs
    cost = cost.replace(' // ', '')
    
    for char in cost:
        buf += char
        if char == '}' or char == ' ':
            out.append(buf)
            buf = ''
    return out


### Unit tests below ###
def check(candidate):
	assert candidate(r'{1}{2}{3}{4}{5}{6}{7}{G}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{G}']
	assert candidate(r'{2}{W/P}{U/P}{B/P}{R/P}') == ['{2}', '{W/P}', '{U/P}', '{B/P}', '{R/P}']
	assert candidate(r'{1}{W}{U}') == ['{1}', '{W}', '{U}']
	assert candidate(r'{3}{W}{U}{B}') == ['{3}', '{W}', '{U}', '{B}']
	assert candidate(r'{1}{U}') == ['{1}', '{U}']
	assert candidate(r'{X}{X}') == ['{X}', '{X}']
	assert candidate(r'{1}{W/P}{U/P}{B/P}') == ['{1}', '{W/P}', '{U/P}', '{B/P}']
	assert candidate(r'{1}') == ['{1}']
	assert candidate(r'{2}{U}{B}{1}{R}') == ['{2}', '{U}', '{B}', '{1}', '{R}']
	assert candidate(r'{T}') == ['{T}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}{7}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}']
	assert candidate(r'{W}{U/P}{B}{R}{G}') == ['{W}', '{U/P}', '{B}', '{R}', '{G}']
	assert candidate(r'{1}{W/P}') == ['{1}', '{W/P}']
	assert candidate(r'{1}{W}{U}{B}') == ['{1}', '{W}', '{U}', '{B}']
	assert candidate(r'{W/P}{U/P}{B}{R/P}{G/P}') == ['{W/P}', '{U/P}', '{B}', '{R/P}', '{G/P}']
	assert candidate(r'{R/P}') == ['{R/P}']
	assert candidate(r'{1}{2}{3}{W}{U}{B}{R}{G}{C}') == ['{1}', '{2}', '{3}', '{W}', '{U}', '{B}', '{R}', '{G}', '{C}']
	assert candidate(r'{2}{W/P}{U/B}{R/G}{Q}') == ['{2}', '{W/P}', '{U/B}', '{R/G}', '{Q}']
	assert candidate(r'{2}{U}{B}') == ['{2}', '{U}', '{B}']
	assert candidate(r'{1}{2}{3}') == ['{1}', '{2}', '{3}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}{7}{8}{9}{G}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{G}']
	assert candidate(r'{1}{2}{3}{W}{U}{B}{R}{G}') == ['{1}', '{2}', '{3}', '{W}', '{U}', '{B}', '{R}', '{G}']
	assert candidate(r'{2}{T}') == ['{2}', '{T}']
	assert candidate(r'{2}{W/P}{U/P}{B/P}{R/P}{G/P}') == ['{2}', '{W/P}', '{U/P}', '{B/P}', '{R/P}', '{G/P}']
	assert candidate(r'{2}{W/P}') == ['{2}', '{W/P}']
	assert candidate(r'{W}{U}{B}}') == ['{W}', '{U}', '{B}', '}']
	assert candidate(r'{2}{W/P}{U}{B}') == ['{2}', '{W/P}', '{U}', '{B}']
	assert candidate(r'{1}{2}{3}{W}{U}{B}') == ['{1}', '{2}', '{3}', '{W}', '{U}', '{B}']
	assert candidate(r'{1}{G}{G}{G}{G}') == ['{1}', '{G}', '{G}', '{G}', '{G}']
	assert candidate(r'{1}{W}{W}') == ['{1}', '{W}', '{W}']
	assert candidate(r'{2}{W/U}{B}') == ['{2}', '{W/U}', '{B}']
	assert candidate(r'{2}{G}{G}{G}{G}{G}') == ['{2}', '{G}', '{G}', '{G}', '{G}', '{G}']
	assert candidate(r'{4}{B}{B}') == ['{4}', '{B}', '{B}']
	assert candidate(r'{1}{2}') == ['{1}', '{2}']
	assert candidate(r'{2}{T}{Q}') == ['{2}', '{T}', '{Q}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}{7}{8}{9}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}']
	assert candidate(r'{2}{G}{G}') == ['{2}', '{G}', '{G}']
	assert candidate(r'{1}{2}{3}{W}{U}{B}{R}') == ['{1}', '{2}', '{3}', '{W}', '{U}', '{B}', '{R}']
	assert candidate(r'{G/P}') == ['{G/P}']
	assert candidate(r'{3}{G}{G}{G}{G}') == ['{3}', '{G}', '{G}', '{G}', '{G}']
	assert candidate(r'{W/P}') == ['{W/P}']
	assert candidate(r'{W}{U}{B}{R} // {2}{W}{U}') == ['{W}', '{U}', '{B}', '{R}', '{2}', '{W}', '{U}']
	assert candidate(r'{W/U}') == ['{W/U}']
	assert candidate(r'{1}{G}') == ['{1}', '{G}']
	assert candidate(r'{2}{W/P}{U/P}{B/P}') == ['{2}', '{W/P}', '{U/P}', '{B/P}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}{7}{8}{G}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{G}']
	assert candidate(r'{2}{W/P}{U/B}') == ['{2}', '{W/P}', '{U/B}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}']
	assert candidate(r'{2}{W}{U}') == ['{2}', '{W}', '{U}']
	assert candidate(r'{T/Q}') == ['{T/Q}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}{7}{8}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}']
	assert candidate(r'{2}{W/P}{U/B}{R/G}') == ['{2}', '{W/P}', '{U/B}', '{R/G}']
	assert candidate(r'{W}{U/P}{B}{R}') == ['{W}', '{U/P}', '{B}', '{R}']
	assert candidate(r'{1}{2}{3}{4}{5}') == ['{1}', '{2}', '{3}', '{4}', '{5}']
	assert candidate(r'{W}{U}{B}') == ['{W}', '{U}', '{B}']
	assert candidate(r'{1}{2}{3}{4}{G}') == ['{1}', '{2}', '{3}', '{4}', '{G}']
	assert candidate(r'{5}{R}{R}') == ['{5}', '{R}', '{R}']
	assert candidate(r'{1}{W/P}{U/P}') == ['{1}', '{W/P}', '{U/P}']
	assert candidate(r'{2}{R}{G}') == ['{2}', '{R}', '{G}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}{G}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{G}']
	assert candidate(r'{1}{2}{3}{G}') == ['{1}', '{2}', '{3}', '{G}']
	assert candidate(r'{1}{2}{W}{U}{B}') == ['{1}', '{2}', '{W}', '{U}', '{B}']
	assert candidate(r'{1}{W/G}{U/R}{B/P}') == ['{1}', '{W/G}', '{U/R}', '{B/P}']
	assert candidate(r'{1}{2}{G}') == ['{1}', '{2}', '{G}']
	assert candidate(r'{2}{R/P}') == ['{2}', '{R/P}']
	assert candidate(r'{W/P}{U/P}{B}{R}{G}') == ['{W/P}', '{U/P}', '{B}', '{R}', '{G}']
	assert candidate(r'{W}{U}{B}{R}') == ['{W}', '{U}', '{B}', '{R}']
	assert candidate(r'{2}{W}{U/B}') == ['{2}', '{W}', '{U/B}']
	assert candidate(r'{1}{G}{G}{G}{G}{G}') == ['{1}', '{G}', '{G}', '{G}', '{G}', '{G}']
	assert candidate(r'{3}{U}{U}') == ['{3}', '{U}', '{U}']
	assert candidate(r'{T/Q}{U/Q}') == ['{T/Q}', '{U/Q}']
	assert candidate(r'{2}{W/U}{B}{B}') == ['{2}', '{W/U}', '{B}', '{B}']
	assert candidate(r'{2}{T}{Q}{W}{B}') == ['{2}', '{T}', '{Q}', '{W}', '{B}']
	assert candidate(r'{3}{G}{G}{G}') == ['{3}', '{G}', '{G}', '{G}']
	assert candidate(r'{2}{T}{Q}{W}') == ['{2}', '{T}', '{Q}', '{W}']
	assert candidate(r'{5}') == ['{5}']
	assert candidate(r'{2}{G}{G}{G}') == ['{2}', '{G}', '{G}', '{G}']
	assert candidate(r'{1}{2}{3}{W}{U}{B}{R}{G}{C}{G}') == ['{1}', '{2}', '{3}', '{W}', '{U}', '{B}', '{R}', '{G}', '{C}', '{G}']
	assert candidate(r'{W}{U}') == ['{W}', '{U}']
	assert candidate(r'{}') == ['{}']
	assert candidate(r'{B/P}') == ['{B/P}']
	assert candidate(
    '{3}{W}{W}{W}') == ['{3}', '{W}', '{W}', '{W}']
	assert candidate(r'{2}{B/P}') == ['{2}', '{B/P}']
	assert candidate(r'{1}{G}{G}{G}') == ['{1}', '{G}', '{G}', '{G}']
	assert candidate(r'{} // {W}') == ['{}', '{W}']
	assert candidate(r'{1}{2}{3}{4}{5}{G}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{G}']
	assert candidate(r'{1}{2}{3}{4}') == ['{1}', '{2}', '{3}', '{4}']
	assert candidate(r'{3}{G}{G}') == ['{3}', '{G}', '{G}']
	assert candidate(r'{2}{U}') == ['{2}', '{U}']
	assert candidate(r'{} // {}') == ['{}', '{}']
	assert candidate(r'{2}{G}{G}{G}{G}') == ['{2}', '{G}', '{G}', '{G}', '{G}']
	assert candidate(r'{W/U}{2}{B}') == ['{W/U}', '{2}', '{B}']
	assert candidate(r'{2}{G/P}') == ['{2}', '{G/P}']
	assert candidate(r'{1}{2}{3}{W}{U}') == ['{1}', '{2}', '{3}', '{W}', '{U}']
	assert candidate(r'{2}{W}{U}{B}') == ['{2}', '{W}', '{U}', '{B}']
	assert candidate(r'{W/U/B}') == ['{W/U/B}']
	assert candidate(r'{2}{W/P}{U/B}{R}') == ['{2}', '{W/P}', '{U/B}', '{R}']
	assert candidate(r'{1}{2}{3}{4}{5}{6}{7}{8}{9}{10}') == ['{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}']
	assert candidate(r'{1}{2}{W}{U}') == ['{1}', '{2}', '{W}', '{U}']
	assert candidate(r'{W/P}{U/P}{B}{R}{G/P}') == ['{W/P}', '{U/P}', '{B}', '{R}', '{G/P}']
def test_check():
	check(parse_manacost)
