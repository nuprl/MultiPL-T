def all_in_any(a, b):
    """return true if every item of 'a' is found
    inside 'b'
    else return false
    """
    ### Canonical solution below ###
    if len([x for x in a if x in b]) == len(a):
        return True
    else:
        return False


### Unit tests below ###
def check(candidate):
	assert candidate(set([1, 2, 3]), [1, 4, 3]) == False
	assert not candidate(set('abc'), set('c'))
	assert candidate(list('xy'), list('abc')) == False
	assert candidate(
    ["a", "b", "c", "d"], ["a", "b", "c", "d"]
    ) == True, "Test 3"
	assert candidate(list('abc'), list('abc'))
	assert candidate(a = [1, 2, 3], b = [4, 5, 6]) == False
	assert candidate(set([1,2,3]), set([4,5,6])) == False
	assert candidate(set(['a', 'c']), set(['a', 'b', 'c']))
	assert candidate([1, 2, 3], [4, 5, 6]) == False
	assert candidate(list('c'), list('abc')) == True
	assert not candidate(a=[1, 2, 3], b=[1, 2, 4])
	assert candidate(list('b'), list('abc')) == True
	assert not candidate(set(['a', 'c']), set(['a', 'b']))
	assert candidate(
    ["hello", "hi", "hey"],
    ["hello", "hey", "there"]
) == False
	assert candidate(set("ab"), set("ab")) == True
	assert candidate(list('abc'), list('cabd'))
	assert not candidate(list("xyz"), list("123"))
	assert candidate(list('abcd'), list('abcd'))
	assert candidate( [1, 2, 3, 4], [1, 2, 3, 4, 5, 6, 7]) == True
	assert not candidate(set('abc'), set('abd'))
	assert candidate(
    ["hello", "hi", "hey"],
    ["howdy", "hi", "hey", "there"]
) == False
	assert candidate(set('abc'), set('abc'))
	assert candidate(list('a'), list('abc')) == True
	assert candidate(range(10), range(5, 15)) == False
	assert candidate( [1, 2, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 6]) == False
	assert candidate(
    ["a", "b", "c", "d"], ["a", "c", "e", "f"]
    ) == False, "Test 2"
	assert candidate(list('x'), list('abc')) == False
	assert candidate(set(), set()) == True
	assert candidate(a=[1, 2, 3], b=[1, 2, 3, 4, 5])
	assert not candidate(list('abc'), list('ac'))
	assert not candidate(set('abc'), set('b'))
	assert candidate(
    ["a", "b", "c", "d"], ["a", "b", "c", "d", "e", "f", "g"]
    ) == True, "Test 4"
	assert not candidate(list('abc'), list('ad'))
	assert candidate(a=[2, 1, 3, 5], b=[1, 2, 3, 4, 5])
	assert candidate(list('ab'), list('cab')) == True
	assert candidate(a = [1, 2, 3], b = [1, 4, 5]) == False
	assert not candidate(a=[1, 2, 3], b=[1, 2, 4, 5])
	assert candidate(set(''), set('')) == True
	assert candidate(
    ["a", "b", "c", "d"], ["e", "f", "g", "h"]
    ) == False, "Test 8"
	assert candidate(set("abc"), set("abcd")) == True
	assert candidate({1, 2}, {1, 2, 3}) == True
	assert candidate(list('ab'), list('')) == False
	assert not candidate(a=['apple', 'banana', 'pear'],
                      b=['apple', 'banana', 'orange'])
	assert candidate(range(5, 10), range(5, 15)) == True
	assert candidate( [1,2,3], [1,2,3,4,5] )
	assert candidate( [1, 2, 3, 4], [1, 2, 3, 4, 5, 6]) == True
	assert candidate( [1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6, 7]) == True
	assert candidate(
    ["hello", "hi", "hey"],
    ["hello", "hi", "hey", "there"]
) == True
	assert candidate(list("abcdefg"), list("")) is False
	assert candidate(range(10), range(10)) == True
	assert candidate( [1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6]) == True
	assert candidate(list("abcdefg"), list("bcdefgh")) is False
	assert not candidate(set('abc'), set('bcd'))
	assert candidate(
    ["a", "b", "c", "d"], []
    ) == False, "Test 7"
	assert not candidate( [1,2,3], [1,2,4,5] )
	assert candidate(list('ab'), list('ca')) == False
	assert candidate(set('abcdef'), set('')) == False
	assert candidate(set([1,2,3]), set([1,2,3,4,5])) == True
	assert candidate(list(''), list('')) == True
	assert candidate( [1, 2, 3], [1, 2, 3, 4, 5, 6]) == True
	assert candidate(set("abc"), set("ab")) == False
	assert candidate(list("abcdefg"), list("x")) is False
	assert candidate(set('abcdef'), set('gfed')) == False
	assert candidate(list("a"), list("abc"))
	assert candidate(list('abc'), list('cab'))
	assert candidate( [1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6, 7]) == True
	assert not candidate(a=['apple', 'banana', 'pear'],
                      b=['apple', 'banana', 'orange', 'grape'])
	assert not candidate(set('abc'), set('a'))
	assert candidate(list('ab'), list('abc')) == True
	assert candidate(a=['apple', 'banana', 'pear'],
                  b=['apple', 'banana', 'pear', 'grape', 'orange'])
	assert not candidate(a=[2, 1, 3, 5], b=[1, 2, 3, 4])
	assert candidate(list(''), list(''))
	assert candidate(set('abcdef'), set('cdegf')) == False
	assert candidate({1, 2, 4}, {1, 2, 3}) == False
	assert candidate(list("abcdefg"), list("bacdefg")) is True
	assert candidate(set(['a', 'b']), set(['a', 'b', 'c']))
	assert candidate( [1, 2, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 6, 7]) == True
	assert candidate( [1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6]) == True
	assert candidate(set([1, 2, 3]), [1, 2, 3]) == True
	assert candidate(set(), []) == True
def test_check():
	check(all_in_any)
