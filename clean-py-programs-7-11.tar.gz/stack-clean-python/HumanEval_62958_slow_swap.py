def slow_swap(A, B):
    """
    This is a N(O^2) solution
    """
    ### Canonical solution below ###
    n = len(A)
    sumA = sum(A)
    sumB = sum(B)

    for i in range(n):
        for j in range(n):
            change = B[j] - A[i]
            sumA += change
            sumB -= change

            if sumA == sumB:
                return True, A[i], B[j]
            sumA -= change
            sumB += change
    return False


### Unit tests below ###
def check(candidate):
	assert candidate( [1, 2, 3], [1, 2, 3] ) == (True, 1, 1)
	assert candidate(
    [10, 2, 3, 4, 5, 6],
    [6, 5, 4, 3, 2, 10]
) == (True, 10, 10)
	assert candidate(
    [1, 2, 3, 4, 5, 6],
    [6, 5, 4, 3, 2, 1]
) == (True, 1, 1)
def test_check():
	check(slow_swap)
