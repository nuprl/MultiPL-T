def optimizeAngle(angle):
	"""
	Because any rotation can be expressed within 360 degrees
	of any given number, and since negative angles sometimes
	are one character longer than corresponding positive angle,
	we shorten the number to one in the range to [-90, 270[.
	"""
    ### Canonical solution below ###
	# First, we put the new angle in the range ]-360, 360[.
	# The modulo operator yields results with the sign of the
	# divisor, so for negative dividends, we preserve the sign
	# of the angle.
	if angle < 0:     angle %= -360
	else:             angle %=  360
	# 720 degrees is unneccessary, as 360 covers all angles.
	# As "-x" is shorter than "35x" and "-xxx" one character
	# longer than positive angles <= 260, we constrain angle
	# range to [-90, 270[ (or, equally valid: ]-100, 260]).
	if  angle >= 270: angle -=  360
	elif angle < -90: angle +=  360
	return angle


### Unit tests below ###
def check(candidate):
	assert candidate(-10) == -10
	assert candidate(-36) == -36
	assert candidate( 12) ==  12
	assert candidate( 23) ==  23
	assert candidate(215)
	assert candidate( 260) == 260
	assert candidate(-280) == 80
	assert candidate( -1) == -1
	assert candidate( 17) ==  17
	assert candidate(-450) == -90
	assert candidate(0) == 0
	assert candidate(360) == 0
	assert candidate(260) == 260
	assert candidate(-270.0) == 90
	assert candidate(-73) == -73
	assert candidate(361) == 1
	assert candidate( 450) ==  90
	assert candidate( 26) ==  26
	assert candidate(-1440) == 0
	assert candidate(361) ==   1
	assert candidate(-72) == -72
	assert candidate(-180)  == 180
	assert candidate( 810) ==  90
	assert candidate(101) == 101
	assert candidate(-15) == -15
	assert candidate( 20) ==  20
	assert candidate(360) ==   0
	assert candidate(-720) ==   0
	assert candidate(100.0) == 100
	assert candidate(1440) ==   0
	assert candidate(-180) == 180
	assert candidate(  1) ==  1
	assert candidate(280) == -80
	assert candidate(  0) ==   0
	assert candidate(1620) == 180
	assert candidate( 22) ==  22
	assert candidate(360)   == 0
	assert candidate(400) == 40
	assert candidate( 32)
	assert candidate(36180) == 180
	assert candidate(-271) == 89
	assert candidate( -1) ==  -1
	assert candidate(-1) == -1
	assert candidate( 16) ==  16
	assert candidate(720)   == 0
	assert candidate(-360) == 0
	assert candidate(-722) == -2
	assert candidate(-80) == -80
	assert candidate(180) == 180
	assert candidate(  180) ==  180
	assert candidate( 29) ==  29
	assert candidate( 360) ==   0
	assert candidate(0.0) == 0
	assert candidate(10) == 10
	assert candidate(  2) ==   2
	assert candidate( 25) ==  25
	assert candidate(269) == 269
	assert candidate(720) == 0
	assert candidate( 24) ==  24
	assert candidate( 14) ==  14
	assert candidate( 15) ==  15
	assert candidate( 28) ==  28
	assert candidate(362) == 2
	assert candidate( 260) ==  260
	assert candidate( 21) ==  21
	assert candidate(  0) ==  0
	assert candidate(1080) ==   0
	assert candidate(450) == 90
	assert candidate( 90) ==  90
	assert candidate( 36) ==  36
	assert candidate(  4) ==   4
	assert candidate( 27) ==  27
	assert candidate(-719) == 1
	assert candidate(-360) ==   0
	assert candidate(  8) ==   8
	assert candidate(100) == 100
	assert candidate( 13) ==  13
	assert candidate( 540) == 180
	assert candidate(1800) ==   0
	assert candidate(1980) == 180
	assert candidate(  3) ==   3
	assert candidate(-270) == 90
	assert candidate(-85) == -85
	assert candidate(-45) == -45
	assert candidate(-100)  == 260
	assert candidate(179) == 179
	assert candidate( 89) == 89
	assert candidate(  7) ==   7
	assert candidate(721) == 1
	assert candidate(-721) == -1
	assert candidate( 180) == 180
	assert candidate(  5) ==   5
	assert candidate(-37) == -37
	assert candidate(250) == 250
	assert candidate(0)   == 0
	assert candidate(120) == 120
	assert candidate(1530) ==  90
	assert candidate(1440) == 0
	assert candidate( 99) ==  99
	assert candidate(180)   == 180
	assert candidate( 89) ==  89
	assert candidate(-360+1) == 1
	assert candidate(-89) == -89
	assert candidate( 90) == 90
	assert candidate(  90) ==  90
	assert candidate( 720) ==   0
	assert candidate(-25) == -25
	assert candidate(350) == -10
	assert candidate( 0) == 0
	assert candidate( 19) ==  19
	assert candidate(370) == 10
	assert candidate(-181) == 179
	assert candidate( 10) ==  10
	assert candidate( 91) ==  91
	assert candidate(-1080) == 0
	assert candidate( 30) ==  30
	assert candidate( 1) == 1
	assert candidate( 18) ==  18
	assert candidate(  6) ==   6
	assert candidate(90) == 90
	assert candidate(1260) == 180
	assert candidate(-362) == -2
	assert candidate(  9) ==   9
	assert candidate( 45) ==  45
	assert candidate(-90) == -90
	assert candidate( 31) ==  31
	assert candidate( 11) ==  11
	assert candidate(361)   == 1
	assert candidate(271) == -89
	assert candidate(20)  == 20
	assert candidate(181) == 181
	assert candidate(-720) == 0
	assert candidate( 80) == 80
	assert candidate(-400) == -40
	assert candidate(360-1) == -1
	assert candidate(1170) ==  90
	assert candidate(-720)  == 0
	assert candidate(-361) == -1
	assert candidate(  1) ==   1
	assert candidate(1890) ==  90
	assert candidate(-2000) == 160
	assert candidate(   0) ==   0
	assert candidate( 900) == 180
	assert candidate(1) == 1
	assert candidate(-20) == -20
	assert candidate(722) == 2
	assert candidate(-84) == -84
def test_check():
	check(optimizeAngle)
