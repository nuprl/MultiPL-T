def js_splice(arr: list, start: int, delete_count=None, *items):
    """ Implementation of javascript's splice function.
     
     :param list arr:
     Array to splice
     :param int start:
     Index at which to start changing the array
     :param int delete_count:
     Number of elements to delete from the array
     :param *items:
     Items to add to the array
     
     Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/splice   noqa:E501
     """
	### Canonical solution below ###    
    # Special conditions for start value
    try:
        if start > len(arr):
            start = len(arr)
        # If start is negative, count backwards from end
        if start < 0:
            start = len(arr) - start
    except TypeError:
        # Non-integer start values are treated as 0 in js
        start = 0

    # Special condition when delete_count is greater than remaining elements
    if not delete_count or delete_count >= len(arr) - start:
        delete_count = len(arr) - start  # noqa: N806

    deleted_elements = arr[start:start + delete_count]

    # Splice appropriately.
    new_arr = arr[:start] + list(items) + arr[start + delete_count:]

    # Replace contents of input array
    arr.clear()
    for el in new_arr:
        arr.append(el)

    return deleted_elements

### Unit tests below ###
def check(candidate):
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=3) == [2, 3, 4]
	assert candidate(arr=[], start=0, delete_count=0) == []
	assert candidate(
    [1, 2, 3, 4], 0, 2, 100, 200) == [1, 2]
	assert candidate(arr=[1, 2, 3, 4], start=2) == [3, 4]
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=-2) == [2, 3]
	assert candidate(arr=[1, 2, 3, 4], start=0, delete_count=100) == [1, 2, 3, 4]
	assert candidate(arr=[1, 2, 3, 4, 5], start=0, delete_count=6) == [1, 2, 3, 4, 5]
	assert candidate(
    [1, 2, 3], -100, 100
) == []
	assert candidate(list(range(10)), 0, 10, 10, 10, 10) == list(range(10))
	assert candidate(arr=[1, 2, 3, 4, 5], start=0, delete_count=4) == [1, 2, 3, 4]
	assert candidate(arr=[1, 2, 3], start=2) == [3]
	assert candidate(
    [1, 2, 3, 4], 1
) == [2, 3, 4]
	assert candidate(list('abcd'), 0, 2, 'X', 'Y') == ['a', 'b']
	assert candidate(
    [1, 2, 3, 4], 0, 4, 100, 200) == [1, 2, 3, 4]
	assert candidate(list(range(10)), 0, 1, 10) == [0]
	assert candidate(arr=[1, 2, 3, 4], start=1) == [2, 3, 4]
	assert candidate(arr=[1, 2, 3], start=2, delete_count=1) == [3]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=0) == [1, 2, 3]
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=4) == [2, 3, 4]
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=-3) == [2]
	assert candidate(arr=[1, 2, 3, 4, 5], start=0, delete_count=3) == [1, 2, 3]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=1, *[]) == [2]
	assert candidate(list(range(10)), 10, 10, 10, 10, 10) == []
	assert candidate(
    [1, 2, 3, 4], 1, 2, 100, 200) == [2, 3]
	assert candidate(list('abcd'), -1, 0, 'X', 'Y') == []
	assert candidate(list('abcd'), -4, 0, 'X', 'Y') == []
	assert candidate(arr=[1, 2, 3], start=1, delete_count=2, *[]) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=4, *[]) == [1, 2, 3]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=10) == [2, 3]
	assert candidate(
    [1, 2, 3, 4], 0, 4
) == [1, 2, 3, 4]
	assert candidate(list('abcd'), 0, 5, 'X', 'Y') == ['a', 'b', 'c', 'd']
	assert candidate(
    [1, 2, 3, 4], 0, 1, 100, 200) == [1]
	assert candidate(
    [1, 2, 3, 4], 0, 1
) == [1]
	assert candidate(list('abcd'), -2, 0, 'X', 'Y') == []
	assert candidate(arr=[1, 2, 3, 4], start=4) == []
	assert candidate(list(range(10)), 0, 10, 10) == list(range(10))
	assert candidate(arr=[1, 2, 3, 4], start=0, delete_count=2) == [1, 2]
	assert candidate(
    [1, 2, 3, 4], 0, 5
) == [1, 2, 3, 4]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=3, *[]) == [1, 2, 3]
	assert candidate(
    [1, 2, 3], 0, 100
) == [1, 2, 3]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=3, *[]) == [2, 3]
	assert candidate(list(range(10)), 9, 10, 10, 10, 10) == list(range(9, 10))
	assert candidate(
    [1, 2, 3, 4], 1, 4, 100, 200) == [2, 3, 4]
	assert candidate(
    [1, 2, 3], 100, 100
) == []
	assert candidate(
    [1, 2, 3, 4], 1, 2) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=4, *[]) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=0) == [1, 2, 3]
	assert candidate(arr=[1, 2, 3, 4], start=0) == [1, 2, 3, 4]
	assert candidate(list('abcd'), 0, 1, 'X', 'Y') == ['a']
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=-4) == []
	assert candidate(
    [1, 2, 3, 4], 0, 1, 100) == [1]
	assert candidate(
    [1, 2, 3, 4], 0, 3
) == [1, 2, 3]
	assert candidate(
    [1, 2, 3, 4], 1, 2
) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=-4) == []
	assert candidate(list(range(5)), 0, 2, 10, 11, 12) == [0, 1]
	assert candidate(arr=[1, 2, 3, 4, 5], start=1, delete_count=2) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=5, *[]) == [1, 2, 3]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=3) == [1, 2, 3]
	assert candidate(
    [1, 2, 3, 4], 1, 1, 100, 200) == [2]
	assert candidate(
    [1, 2, 3], 0, 2, 4, 5, 6
) == [1, 2]
	assert candidate(arr=[1, 2, 3, 4], start=100) == []
	assert candidate(
    [1, 2, 3, 4], 4
) == []
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=2) == [2, 3]
	assert candidate(list('abcd'), 4, 0, 'X', 'Y') == []
	assert candidate(
    [1, 2, 3], 0, 1
) == [1]
	assert candidate(
    [1, 2, 3, 4], 0, 1) == [1]
	assert candidate(arr=[], start=0, delete_count=1) == []
	assert candidate(arr=[1, 2, 3], start=1) == [2, 3]
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=5) == [2, 3, 4]
	assert candidate(arr=[1, 2, 3], start=100) == []
	assert candidate(arr=[1, 2, 3], start=100, delete_count=-2) == []
	assert candidate(arr=[1, 2, 3], start=100, delete_count=2) == []
	assert candidate(arr=[], start=0) == []
	assert candidate(
    [1, 2, 3, 4], 0, 2
) == [1, 2]
	assert candidate(arr=[1, 2, 3, 4], start=0, delete_count=0) == [1, 2, 3, 4]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=4) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=1) == [1]
	assert candidate(list('abcd'), 0, 3, 'X', 'Y') == ['a', 'b', 'c']
	assert candidate(arr=[1, 2, 3], start=0, delete_count=1, *[]) == [1]
	assert candidate(arr=[1, 2, 3, 4, 5], start=0, delete_count=5) == [1, 2, 3, 4, 5]
	assert candidate(list(range(10)), -10, 10, 10, 10, 10) == []
	assert candidate(
    [1, 2, 3, 4], 1, 3, 100, 200) == [2, 3, 4]
	assert candidate(
    [1, 2, 3, 4], 2
) == [3, 4]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=4) == [1, 2, 3]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=2, *[]) == [1, 2]
	assert candidate(arr=[1, 2, 3], start=0, delete_count=2) == [1, 2]
	assert candidate(list(range(10)), 1, 10, 10, 10, 10) == list(range(1, 10))
	assert candidate(arr=[1, 2, 3], start=2, delete_count=3)
	assert candidate(arr=[1, 2, 3], start=1, delete_count=1) == [2]
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=1) == [2]
	assert candidate(
    [1, 2, 3, 4], 3
) == [4]
	assert candidate(arr=[1, 2, 3], start=3) == []
	assert candidate(arr=[1, 2, 3, 4], start=2, delete_count=2) == [3, 4]
	assert candidate(arr=[1, 2, 3], start=2, delete_count=2) == [3]
	assert candidate(list(range(5)), 0, 5, 10, 11, 12) == [0, 1, 2, 3, 4]
	assert candidate(arr=[1, 2, 3, 4], start=1, delete_count=0) == [2, 3, 4]
	assert candidate(arr=[1, 2, 3, 4, 5], start=0, delete_count=0) == [1, 2, 3, 4, 5]
	assert candidate(arr=[1, 2, 3, 4, 5], start=0, delete_count=1) == [1]
	assert candidate(arr=[1, 2, 3, 4], start=3) == [4]
	assert candidate(list(range(5)), 0, 1000) == [0, 1, 2, 3, 4]
	assert candidate(list('abcd'), 0, 4, 'X', 'Y') == ['a', 'b', 'c', 'd']
	assert candidate(
    [1, 2, 3, 4], 1, 1
) == [2]
	assert candidate(list(range(5)), 0) == [0, 1, 2, 3, 4]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=3) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=5, *[])
	assert candidate(
    [1, 2, 3, 4], 0
) == [1, 2, 3, 4]
	assert candidate(arr=[1, 2, 3], start=1, delete_count=2) == [2, 3]
	assert candidate(arr=[1, 2, 3], start=100, delete_count=1000) == []
def test_check():
	check(js_splice)
