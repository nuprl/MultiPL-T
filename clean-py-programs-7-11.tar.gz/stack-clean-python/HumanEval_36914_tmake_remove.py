def tmake_remove(all_list, removed_list):
    """ remove path in list"""
	### Canonical solution below ###    
    if all_list is None:
        return []
    if removed_list is None:
        return all_list
    if not isinstance(removed_list, list):
        removed_list = [removed_list]
    removed_list = set(removed_list)
    all_list = filter(lambda x: x not in removed_list, all_list)
    return all_list

### Unit tests below ###
def check(candidate):
	assert candidate(None, ['hello']) == []
	assert candidate(['a'], None) == ['a']
	assert candidate(['hello'], None) == ['hello']
	assert candidate([1, 2], None) == [1, 2]
	assert candidate(None, [1, 2, 3, 4]) == []
	assert candidate(['a', 'b', 'c'], None) == ['a', 'b', 'c']
	assert candidate(["a"], None) == ["a"]
	assert candidate(["a", "b"], None) == ["a", "b"]
	assert candidate(None, ["a", "b", "c"]) == []
	assert candidate(None, ['abc']) == []
	assert candidate(None, [1]) == []
	assert candidate([1, 2, 3], None) == [1, 2, 3]
	assert candidate(["test"], None) == ["test"]
	assert candidate(None, ['a']) == []
	assert candidate(None, "a") == []
	assert candidate(None, "test") == []
	assert candidate(['abc'], None) == ['abc']
	assert candidate(["1", "2", "3"], None) == ["1", "2", "3"]
	assert candidate(None, ["a"]) == []
	assert candidate(['a', 'b'], None) == ['a', 'b']
	assert candidate([], None) == []
	assert candidate(None, []) == []
	assert candidate(None, ['a', 'b']) == []
	assert candidate([1, 2, 3, 4], None) == [1, 2, 3, 4]
	assert candidate(None, ["a", "b"]) == []
	assert candidate(None, None) == []
	assert candidate(None, [1, 2]) == []
	assert candidate(["a", "b", "c"], None) == ["a", "b", "c"]
def test_check():
	check(tmake_remove)
