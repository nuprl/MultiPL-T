def to_integer(given_input: str):
    """
    Finds the number in a given input(should be a string with numbers) using regular expression.

    >>> to_integer('abc')
    0
    >>> to_integer('1')
    1
    >>> to_integer('abc123')
    '123'
    >>> to_integer('abc123abc')
    '123'
    >>> to_integer('abc123abc456')
    '123,456'

    Args:
        given_input (str): any text with numbers in it

    Returns:
        Number: returns number in a comma separated form if found else returns 0
    """
    ### Canonical solution below ###
    from re import findall
    if isinstance(given_input, str):
        match = findall('\d+', given_input)
        if match:
            return ",".join(match)
        return 0  # default value
    return given_input


### Unit tests below ###
def check(candidate):
	assert candidate(True) == 1
	assert candidate("abc123abc456.789") == "123,456,789"
	assert candidate("abc123abc456") == '123,456'
	assert candidate("abc") == 0
	assert candidate('abc123abc456xyz') == '123,456'
	assert candidate("abc123abc456.789abc000") == "123,456,789,000"
	assert candidate("abc123abc456") == "123,456"
	assert candidate("abcABC123abc456") == "123,456"
	assert candidate("abc123abc456abc789") == "123,456,789"
	assert candidate('abc') == 0
	assert candidate('abc123') == '123'
	assert candidate("abc123abc") == '123'
	assert candidate('abc123abc456') == '123,456'
	assert candidate("None") == 0
	assert candidate('123abc') == '123'
	assert candidate('abc 123 abc 456') == '123,456'
	assert candidate("abc123") == "123"
	assert candidate('') == 0
	assert candidate("ABC123") == "123"
	assert candidate("") == 0
	assert candidate(1) == 1
	assert candidate(False) == 0
	assert candidate("abc123") == '123'
	assert candidate(123) == 123
	assert candidate("abc123abc") == "123"
	assert candidate(0) == 0
	assert candidate("abc123abc456.789abc") == "123,456,789"
	assert candidate("abc123abc456def789") == "123,456,789"
	assert candidate(1.0) == 1
	assert candidate("abc123abc456def789ghi123") == "123,456,789,123"
	assert candidate("abc123abc456.789abc000abc123") == "123,456,789,000,123"
	assert candidate("abc123abc456def789ghi") == "123,456,789"
	assert candidate("abc123abc456.789abc000abc") == "123,456,789,000"
	assert candidate("abc123abc456def") == "123,456"
	assert candidate('abc123abc') == '123'
	assert candidate('abc123abc456abc') == '123,456'
	assert candidate("abc123abc456abc") == "123,456"
	assert candidate("abcABC123abc") == "123"
	assert candidate("abc123abc456.789abc000abc123abc") == "123,456,789,000,123"
def test_check():
	check(to_integer)
