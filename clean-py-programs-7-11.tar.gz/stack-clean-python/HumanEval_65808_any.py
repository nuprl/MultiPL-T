def any(array, mapFunc):
    """ 
     Checks if any of the elements of array returns true, when applied on a function that returns a boolean.
     :param array: The array that will be checked, for if any of the elements returns true, when applied on the function. \t
     :type array: [mixed] \n
     :param mapFunc: The function that gives a boolean value, when applied on the element of the array. \t
     :type mapFunc: function \n
     :returns: Whether any of the elements of the array, returned true or not.  \t
     :rtype: : bool \n
     """
	### Canonical solution below ###    
    for elem in array:
        if mapFunc(elem):
            return True
    return False

### Unit tests below ###
def check(candidate):
	assert candidate(array = [1,2,3,4,5], mapFunc = lambda x: x < 2) == True
	assert candidate(array=[1, 2, 3], mapFunc=lambda x: x == 1) == True
	assert candidate(array = [], mapFunc = lambda x: x == 0) == False
	assert candidate(
    [0, False, None, {}, [], "", 0.0, -1, -1.0],
    lambda x: x
) == True
	assert candidate(
    [1, 2, 3, 4],
    lambda x: x > 5
) == False
	assert candidate(
    [
        {"name": "John", "age": 24, "country": "Norway"},
        {"name": "Jane", "age": 23, "country": "Sweden"},
        {"name": "Mark", "age": 25, "country": "Sweden"},
    ],
    lambda person: person["age"] > 30,
) == False
	assert candidate(range(5), lambda x: x > 2) == True
	assert candidate(
    [1, 2, 3, 4],
    lambda x: x > 0
) == True
	assert candidate(array = [1,2,3,4,5], mapFunc = lambda x: x > 10) == False
	assert candidate(
    [
        {"name": "Rick", "age": 10},
        {"name": "Morty", "age": 10},
        {"name": "Jerry", "age": 10},
    ],
    lambda person: person["name"] == "Jerry",
) == True
	assert candidate(
    [
        {"id": 1, "name": "Bart"},
        {"id": 2, "name": "Lisa"},
        {"id": 3, "name": "Maggie"},
        {"id": 4, "name": "Homer"},
        {"id": 5, "name": "Marge"},
    ],
    lambda person: person["name"] == "Santa",
) == False
	assert candidate(array = [1, 2, 3], mapFunc = lambda x: x == 0) == False
	assert candidate(list(range(10)), lambda x: x > 10) == False
	assert candidate(range(10), lambda x: x == 10) == False
	assert not candidate(
    [1, 2, 3, 4, 5],
    lambda x: x == 6
)
	assert candidate(array=[1, 2, 3], mapFunc=lambda x: x > 2) == True
	assert candidate(range(10), lambda x: x == 0) == True
	assert candidate(range(5), lambda x: x > 5) == False
	assert candidate(
    [1, 2, 3],
    lambda x: x
) == True
	assert candidate(array = [1, 2, 3], mapFunc = lambda x: x == 2) == True
	assert candidate( [1, 2, 3], lambda x: x > 0 ) == True
	assert candidate(array=[1, 2, 3, 4], mapFunc=lambda x: x > 2) == True
	assert candidate(range(10), lambda x: x == 11) == False
	assert candidate( [1, 2, 3], lambda x: x > 2 ) == True
	assert candidate(
    [1, 2, 3, 4],
    lambda x: x == 1
) == True
	assert candidate(range(10), lambda x: x > 5)
	assert candidate(
    [1, 2, 3, 4, 5],
    lambda x: x % 2 == 0
) == True
	assert candidate(
    [1, 2, 3, 4, 5],
    lambda x: x == 3
)
	assert candidate(array=[1, 2, 3], mapFunc=lambda x: x == 4) == False
	assert candidate(range(10), lambda x: x == -1) == False
	assert candidate(
    [
        {"name": "Rick", "age": 10},
        {"name": "Morty", "age": 10},
        {"name": "Jerry", "age": 10},
    ],
    lambda person: person["name"] == "Jerry" and person["age"] == 11,
) == False
	assert candidate(range(10), lambda x: x == 5) == True
	assert candidate(
    [
        {"id": 1, "name": "Bart"},
        {"id": 2, "name": "Lisa"},
        {"id": 3, "name": "Maggie"},
        {"id": 4, "name": "Homer"},
        {"id": 5, "name": "Marge"},
    ],
    lambda person: person["name"] == "Marge",
) == True
	assert candidate(
    [
        {"name": "Rick", "age": 10},
        {"name": "Morty", "age": 10},
        {"name": "Jerry", "age": 10},
    ],
    lambda person: person["age"] == 11,
) == False
	assert candidate(
    [
        {"name": "Rick", "age": 10},
        {"name": "Morty", "age": 10},
        {"name": "Jerry", "age": 10},
    ],
    lambda person: person["name"] == "Jerry" and person["age"] == 10,
) == True
	assert candidate(array=[1, 2, 3, 4], mapFunc=lambda x: x > 5) == False
	assert candidate(array = [1, 2, 3], mapFunc = lambda x: x == 5) == False
	assert not candidate(range(10), lambda x: x > 100)
	assert candidate(
    [1, 2, 3, 4, 5],
    lambda x: x == 0
) == False
	assert candidate(array=[1, 2, 3], mapFunc=lambda x: x > 4) == False
	assert candidate(
    [1, 2, 3, 4, 5],
    lambda x: x == 5
) == True
	assert candidate(
    [1, 2, 3],
    lambda x: x > 2
) == True
	assert candidate(
    [
        {"name": "John", "age": 24, "country": "Norway"},
        {"name": "Jane", "age": 23, "country": "Sweden"},
        {"name": "Mark", "age": 25, "country": "Sweden"},
    ],
    lambda person: person["age"] > 24,
) == True
	assert candidate(range(10), lambda x: x > 100) == False
	assert candidate( [1,2,3,4,5], lambda x: x > 3 ) == True
	assert candidate(list(range(10)), lambda x: x < 5) == True
	assert candidate(
    [
        {"name": "Rick", "age": 10},
        {"name": "Morty", "age": 10},
        {"name": "Jerry", "age": 10},
    ],
    lambda person: person["age"] == 10,
) == True
	assert candidate( [1,2,3,4,5], lambda x: x > 10 ) == False
	assert candidate(array=[1, 2, 3], mapFunc=lambda x: x > 3) == False
	assert candidate( [1, 2, 3], lambda x: x > 10 ) == False
	assert candidate(
    [1, 2, 3],
    lambda x: x > 4
) == False
	assert candidate(range(10), lambda x: x % 2 == 1) == True
	assert candidate(range(10), lambda x: x % 2 == 0) == True
	assert candidate(
    [],
    lambda x: x > 5
) == False
	assert candidate( [1, 2, 3], lambda x: x > -1 ) == True
	assert candidate(range(10), lambda x: x > 10) == False
def test_check():
	check(any)
