def fields_values(d, k):
    """ 
     Returns the string contained in the setting ADMIN_MEDIA_PREFIX.
     """
	### Canonical solution below ###    
    values = d.get(k,[])
    return ",".join(map(str,values))

### Unit tests below ###
def check(candidate):
	assert candidate({},'ADMIN_MEDIA_PREFIX') == ''
	assert candidate({}, 'k') == ''
	assert candidate(dict(), "foo") == ""
	assert candidate(dict(foo=1, bar=[2,3]), "bar") == "2,3"
	assert candidate({'':[1]},'') == '1'
	assert candidate({'':[1,2]},'') == '1,2'
	assert candidate({}, 'foo') == ''
	assert candidate(dict(), "FOO") == ""
	assert candidate(dict(a=[1,2]), "a") == "1,2"
	assert candidate(dict(a=[1,2]), "b") == ""
	assert candidate(dict(foo=[1,2,3], bar=[4,5]), "bar") == "4,5"
	assert candidate(dict(a=[1,2,3]), "a") == "1,2,3"
	assert candidate(dict(ADMIN_MEDIA_PREFIX=[1,2,3]),'ADMIN_MEDIA_PREFIX') == '1,2,3'
	assert candidate(dict(FOO=[1,2],BAR=3), "FOO") == "1,2"
	assert candidate(dict(foo=['bar','baz']), 'foo') == 'bar,baz'
	assert candidate(dict(foo=['bar','baz']),'foo') == 'bar,baz'
	assert candidate(dict(FOO=[1,2]), "FOO") == "1,2"
	assert candidate(dict(FOO=()), "FOO") == ""
	assert candidate(dict(FOO=[1]), "FOO") == "1"
	assert candidate(dict(a=[1,2,3]), "c") == ""
	assert candidate(dict(a=[1,2,3]), "b") == ""
	assert candidate({'':[]},'') == ''
	assert candidate(dict(),'a') == ''
	assert candidate(dict(foo=[1,2]),"foo") == "1,2"
	assert candidate(dict(foo=[1,2,3]), "foo") == "1,2,3"
	assert candidate(dict(foo=["1","2","3"]), "foo") == "1,2,3"
	assert candidate({"foo":[]},"foo") == ""
	assert candidate({'k':[1,2]}, 'k') == '1,2'
	assert candidate(dict(a=[1,2]),"a") == "1,2"
	assert candidate(dict(foo=[1,2,3], bar=[4,5]), "foo") == "1,2,3"
	assert candidate(dict(foo=[1,2]), "foo") == "1,2"
	assert candidate({'foo':[1,2,3]}, 'foo') == '1,2,3'
	assert candidate(dict(),"foo") == ""
	assert candidate(dict(a=[1,2],b=2), "a") == "1,2"
	assert candidate(dict(FOO=[]), "FOO") == ""
	assert candidate({},'') == ''
	assert candidate({},"foo") == ""
	assert candidate(dict(a=[1,2,3]), 'a') == '1,2,3'
	assert candidate(dict(),'foo') == ''
	assert candidate(
    {'foo': ['bar', 'baz']},
    'bar'
) == ''
	assert candidate(dict(foo=['bar']), 'foo') == 'bar'
	assert candidate(
    {'foo': ['bar', 'baz']},
    'foo'
) == 'bar,baz'
	assert candidate(dict(foo=[1]), "foo") == "1"
	assert candidate({"foo":[1,2]}, "foo") == "1,2"
	assert candidate(
    {'foo': ['bar', 'baz']},
    'baz'
) == ''
	assert candidate(dict(), "bar") == ""
	assert candidate(dict(), 'foo') == ''
	assert candidate({}, "foo") == ""
	assert candidate(dict(),"a") == ""
	assert candidate(dict(foo=1), "bar") == ""
	assert candidate({'':[1,2,3]},'') == '1,2,3'
	assert candidate({"foo":[1,2,3]},"foo") == "1,2,3"
def test_check():
	check(fields_values)
