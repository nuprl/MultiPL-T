def _check_sequence(graph_seq, known_seq):
    """ 
     Check that the sequence matches up to a certain point for the known sequence. If it does
     return the index to where it matches. If it doesn't return 0.
     :param graph_seq: Actual sequence in the graph
     :param known_seq: One of the known sequences
     :return: Index up to which a match is found
     """
	### Canonical solution below ###    
    if len(known_seq) < len(graph_seq):
        return 0

    if known_seq[0:len(graph_seq)] == graph_seq:
        match_len = len(graph_seq)
    else:
        match_len = 0

    return match_len

### Unit tests below ###
def check(candidate):
	assert candidate(
    graph_seq=[1, 2, 3, 4, 5],
    known_seq=[1, 2, 3, 4, 5, 6, 7]
) == 5
	assert candidate( [1, 2, 3], [2, 3] ) == 0
	assert candidate(list(range(5, 15)), list(range(10))) == 0
	assert candidate(list("12345678"), list("12345678")) == 8
	assert candidate(list(range(0, 10)), list(range(0, 10)) + [1]) == len(list(range(0, 10)))
	assert candidate( [1, 2, 3], [1, 2, 3] ) == 3
	assert candidate(graph_seq=['a', 'b', 'c'], known_seq=[]) == 0
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCDABCDABCDABCE") == 4
	assert candidate(graph_seq=['A', 'B', 'C', 'D'], known_seq=['A', 'B', 'C', 'D']) == 4
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCDABCD") == 4
	assert candidate(
    ['a', 'b', 'c'],
    ['d', 'e', 'f']
) == 0
	assert candidate(list(range(10)), list(range(15, 20, -1))) == 0
	assert candidate(graph_seq="ATGC", known_seq="ATG") == 0
	assert candidate(list('abcde'), list('')) == 0
	assert candidate(graph_seq = [0, 1, 2], known_seq = [0, 1, 2, 3, 4]) == 3
	assert candidate(
    graph_seq=[1, 2, 3, 4, 5],
    known_seq=[1, 2, 3, 4, 5, 6]
) == 5
	assert candidate(list(range(1, 11)), list(range(10))) == 0
	assert candidate(list(range(0, 10)), list(range(0, 9))) == 0
	assert candidate(list(range(10)), list()) == 0
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCD") == 4
	assert candidate(graph_seq=['a', 'b', 'c', 'd'], known_seq=['a', 'b', 'c', 'd']) == 4
	assert candidate(list('ABC'), list('D')) == 0
	assert candidate( [1, 2, 3], [1, 2, 3, 4] ) == 3
	assert candidate(list(range(10)), list(range(15, 10, -1))) == 0
	assert candidate(list(), list(range(10))) == 0
	assert candidate(graph_seq="ATGC", known_seq="TG") == 0
	assert candidate(list(range(0, 10)), list(range(1, 11))) == 0
	assert candidate(list('abcde'), list('abcdef')) == 5
	assert candidate(
    graph_seq=[1, 2, 3, 4, 5],
    known_seq=[1, 2, 3, 4, 5]
) == 5
	assert candidate(graph_seq=['a', 'b', 'c'], known_seq=['a', 'b', 'c']) == 3
	assert candidate(list("12345678"), list("2345678")) == 0
	assert candidate(list('ABC'), list('ABCDE')) == 3
	assert candidate(list('abcde'), list('abcde')) == 5
	assert candidate(list("12345678"), list("678")) == 0
	assert candidate( [1, 2, 3], [4, 1, 2, 3] ) == 0
	assert candidate(graph_seq="ATGC", known_seq="ATGCG") == 4
	assert candidate(graph_seq=['a', 'b', 'c', 'd'], known_seq=['a', 'b', 'c', 'd', 'e']) == 4
	assert candidate(graph_seq="ATGC", known_seq="CG") == 0
	assert candidate(graph_seq=['a', 'b', 'c', 'd', 'e'], known_seq=['a', 'b', 'c', 'd', 'e']) == 5
	assert candidate(graph_seq="ATGC", known_seq="AT") == 0
	assert candidate(list(range(0, 10)), list(range(0, 10))) == len(list(range(0, 10)))
	assert candidate(list(range(10, 20)), list(range(10))) == 0
	assert candidate(graph_seq=['A', 'B', 'C', 'D'], known_seq=['A', 'B', 'E']) == 0
	assert candidate([2, 1, 0], list(range(3))) == 0
	assert candidate(graph_seq=[], known_seq=['a', 'b', 'c']) == 0
	assert candidate(list(range(10)), list(range(10))) == 10
	assert candidate(
    [
        (1, 0),
        (2, 1),
        (3, 2),
        (4, 3),
        (5, 4),
    ],
    [
        (1, 0),
        (2, 1),
        (3, 2),
        (4, 3),
        (5, 4),
        (6, 5),
    ]
) == 5
	assert candidate(list("12345678"), list("345678")) == 0
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCDABCDABCD") == 4
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b', 'c', 'd', 'e']
) == 3
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b', 'c', 'd']
) == 3
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
) == 12
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCDABCDABCDABCD") == 4
	assert candidate(graph_seq=['a', 'b', 'c'], known_seq=['a', 'b']) == 0
	assert candidate(
    graph_seq=[1, 2, 3, 4, 5],
    known_seq=[1, 2, 3, 4, 6, 7, 8]
) == 0
	assert candidate(list(range(4)), list(range(3))) == 0
	assert candidate(list(), list()) == 0
	assert candidate(graph_seq="ABCD", known_seq="ABCE") == 0
	assert candidate(list(range(10)), list(range(10, 20))) == 0
	assert candidate(list('ABC'), list('')) == 0
	assert candidate(
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31],
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]) == len([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31])
	assert candidate(graph_seq="ATGC", known_seq="AC") == 0
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 6]) == 0
	assert candidate(list('ABC'), list('ABC')) == 3
	assert candidate(list(range(0, 10)), list(range(0, 10)) + [2]) == len(list(range(0, 10)))
	assert candidate(
    [
        (1, 0),
        (2, 1),
        (3, 2),
    ],
    [
        (1, 0),
        (2, 1),
        (3, 2),
        (4, 3),
        (5, 4),
    ]
) == 3
	assert candidate(graph_seq="ATGC", known_seq="ATGC") == 4
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCE") == 4
	assert candidate(list(range(0, 10)), list(range(5, 11))) == 0
	assert candidate(list("12345678"), list("45678")) == 0
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCDABCDABCE") == 4
	assert candidate(list('ABC'), list('ABCD')) == 3
	assert candidate(graph_seq="ABCD", known_seq="ABCD") == 4
	assert candidate(list(range(3)), list(range(3))) == 3
	assert candidate(
    [1, 2, 3, 4, 5],
    [1, 2, 3, 4, 5]) == 5
	assert candidate(graph_seq="ABCD", known_seq="ABCDABCDABCE") == 4
	assert candidate(list('abcde'), list('fgh')) == 0
	assert candidate(list("abc"), list("abc")) == 3
	assert candidate(
    graph_seq=[1, 2, 3, 4, 5],
    known_seq=[1, 2, 3, 4, 6]
) == 0
	assert candidate(graph_seq=['a', 'b', 'c'], known_seq=['a']) == 0
	assert candidate(list("12345678"), list("78")) == 0
	assert candidate(graph_seq=['a', 'b', 'c'], known_seq=['a', 'b', 'c', 'd']) == 3
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
) == 12
	assert candidate(graph_seq="ATGC", known_seq="TC") == 0
	assert candidate(list("12345678"), list("5678")) == 0
	assert candidate(list(range(10)), list(range(15, 20))) == 0
	assert candidate(list(range(10)), list(range(15, 5, -1))) == 0
	assert candidate(
    ['a', 'b', 'c'],
    ['a', 'b', 'c']
) == 3
	assert candidate([2, 1, 0], [2, 1, 0]) == 3
	assert candidate(
    [1, 2, 3, 4, 5],
    []) == 0
	assert candidate(list('ABC'), list('F')) == 0
	assert candidate(list('ABC'), list('E')) == 0
	assert candidate(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
) == 0
	assert candidate(graph_seq = [0, 1, 2, 3], known_seq = [0, 1, 2, 3]) == 4
def test_check():
	check(_check_sequence)
