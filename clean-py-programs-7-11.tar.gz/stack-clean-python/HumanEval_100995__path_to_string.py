def _path_to_string(path):
    """ Convert a list of path elements into a single path string."""
	### Canonical solution below ###    
    return '.'.join(path)

### Unit tests below ###
def check(candidate):
	assert candidate(['com', 'apple']) == 'com.apple'
	assert candidate(path=['root', 'child']) == 'root.child'
	assert candidate(
    ['a']
) == 'a'
	assert candidate(path=['one']) == 'one'
	assert candidate(
    ['com', 'apple', 'developer', 'xcode', 'tools', 'lldb']) == 'com.apple.developer.xcode.tools.lldb'
	assert candidate(['a', 'b', 'c']) == 'a.b.c'
	assert candidate(path=['a']) == 'a'
	assert candidate(path=['1', '2', '3']) == '1.2.3'
	assert candidate(path=['one', 'two', 'three']) == 'one.two.three'
	assert candidate(
    ['foo']) == 'foo'
	assert candidate(path=['a', 'b']) == 'a.b'
	assert candidate(
    ['a', 'b', 'c']) == 'a.b.c', "Simple path test"
	assert candidate(['com', 'apple', 'developer', 'xcode']) == 'com.apple.developer.xcode'
	assert candidate(
    ['one', 'two', 'three', 'four', 'five']) == 'one.two.three.four.five'
	assert candidate(
    ['a', 'b', 'c', 'd']
) == 'a.b.c.d'
	assert candidate(
    ['a', 'b', 'c', 'd']) == 'a.b.c.d', "Path with trailing string"
	assert candidate( ['a','b','c'] ) == 'a.b.c'
	assert candidate(path=['root']) == 'root'
	assert candidate(
    ['foo', 'bar', 'baz']) == 'foo.bar.baz'
	assert candidate( ['a','b'] ) == 'a.b'
	assert candidate(path=['a', 'b', 'c']) == 'a.b.c'
	assert candidate(path=[]) == ''
	assert candidate( ['a', 'b', 'c'] ) == 'a.b.c'
	assert candidate(
    ['a', 'b', 'c']
) == 'a.b.c'
	assert candidate( ['a'] ) == 'a'
	assert candidate( ['a', 'b'] ) == 'a.b'
	assert candidate(path=['one', 'two']) == 'one.two'
	assert candidate(['com']) == 'com'
	assert candidate(
    []) == ''
	assert candidate(list()) == ''
	assert candidate(['a']) == 'a'
	assert candidate(['a', 'b']) == 'a.b'
	assert candidate(['a', 'b', 'c', 'd']) == 'a.b.c.d'
	assert candidate([]) == ''
	assert candidate(
    ['foo', 'bar', 'baz', '']) == 'foo.bar.baz.'
	assert candidate( ['a','b','c','d'] ) == 'a.b.c.d'
def test_check():
	check(_path_to_string)
