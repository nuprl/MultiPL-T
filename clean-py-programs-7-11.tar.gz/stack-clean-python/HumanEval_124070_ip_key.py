def ip_key(key):
    """Function to make a 'canonical' IP string for sorting.
    The given IP has each subfield expanded to 3 numeric digits, eg:

        given '1.255.24.6' return '001.255.014.006'
    """
    ### Canonical solution below ###

    ip = key[0]
    fields = ip.split('.')
    result = []
    for f in fields:
        result.append('%03d' % int(f))

    return result


### Unit tests below ###
def check(candidate):
	assert candidate( ('1.2.3.4', 2) ) == ['001', '002', '003', '004']
	assert candidate( ('1.1.1.1',) ) == ['001', '001', '001', '001']
	assert candidate( ('1.2.3.4', 1) ) == ['001', '002', '003', '004']
	assert candidate( ('192.168.1.1', 16) ) == ['192', '168', '001', '001']
	assert candidate( ('192.168.1.1', 12345) ) == ['192', '168', '001', '001']
	assert candidate( ('1.2.3.4', 0) ) == ['001', '002', '003', '004']
	assert candidate( ('1.255.24.6', 20) )!= ['001', '255', '24', '6']
	assert candidate( ('10.10.10.10', '10.10.10.10') ) == ['010', '010', '010', '010']
	assert candidate( ('1.2.3.4', 1234) ) == ['001', '002', '003', '004']
	assert candidate( ('1.2.3.0',) ) == ['001', '002', '003', '000']
	assert candidate( ('10.10.10.10',) ) == ['010', '010', '010', '010']
	assert candidate( ('192.168.1.1',) ) == ['192', '168', '001', '001']
	assert candidate( ('1.2.3.4',) ) == ['001', '002', '003', '004']
	assert candidate( ('1.2.3.4', '1.2.3.4') ) == ['001', '002', '003', '004']
	assert candidate( ('10.10.10.10', '192.168.3.11') ) == ['010', '010', '010', '010']
	assert candidate( ('1.255.24.6', '10.10.10.10') )!= ['001', '255', '014']
def test_check():
	check(ip_key)
