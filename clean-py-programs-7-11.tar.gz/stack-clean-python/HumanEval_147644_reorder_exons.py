def reorder_exons(exon_ids):
	"""
	Reorder exons if they were out of order.

	Parameters:
		exon_ids (list of str): List of exons 'chrom_coord1_coord2_strand_exon'

	Returns:
		exons (list of str): List of same exon IDs ordered based on strand
			and genomic location
	"""
    ### Canonical solution below ###
	strand = exon_ids[0].split('_')[-2]
	coords = [int(i.split('_')[-4]) for i in exon_ids]
	exons = sorted(zip(exon_ids, coords), key=lambda x: x[1])
	exons = [i[0] for i in exons]
	if strand == '-':
		exons.reverse()
	return exons


### Unit tests below ###
def check(candidate):
	assert candidate(['chr1_1000_2000_+_exon_1', 'chr1_1000_2000_+_exon_2', 'chr1_1000_2000_+_exon_3', 'chr1_1000_2000_+_exon_4', 'chr1_1000_2000_+_exon_5', 'chr1_1000_2000_+_exon_6']) == ['chr1_1000_2000_+_exon_1', 'chr1_1000_2000_+_exon_2', 'chr1_1000_2000_+_exon_3', 'chr1_1000_2000_+_exon_4', 'chr1_1000_2000_+_exon_5', 'chr1_1000_2000_+_exon_6']
	assert candidate(
	['chr1_100_200_+_exon', 'chr1_300_400_+_exon', 'chr1_200_300_+_exon']
) == ['chr1_100_200_+_exon', 'chr1_200_300_+_exon', 'chr1_300_400_+_exon']
	assert candidate(
	['chr1_1000_2000_+_exon', 'chr1_2000_3000_+_exon', 'chr1_3000_4000_+_exon', 'chr1_4000_5000_+_exon']) == ['chr1_1000_2000_+_exon', 'chr1_2000_3000_+_exon', 'chr1_3000_4000_+_exon', 'chr1_4000_5000_+_exon']
	assert candidate(
	['chr1_1221103_1221112_+_exon',
	 'chr1_1221123_1221132_+_exon',
	 'chr1_1221133_1221142_+_exon']
) == ['chr1_1221103_1221112_+_exon', 'chr1_1221123_1221132_+_exon', 'chr1_1221133_1221142_+_exon']
	assert candidate(
	['chr1_100_200_+_exon', 'chr1_200_300_+_exon', 'chr1_300_400_+_exon']
) == ['chr1_100_200_+_exon', 'chr1_200_300_+_exon', 'chr1_300_400_+_exon']
	assert candidate(
	['chr1_1221123_1221132_+_exon',
	 'chr1_1221133_1221142_+_exon',
	 'chr1_1221103_1221112_+_exon']
) == ['chr1_1221103_1221112_+_exon', 'chr1_1221123_1221132_+_exon', 'chr1_1221133_1221142_+_exon']
def test_check():
	check(reorder_exons)
