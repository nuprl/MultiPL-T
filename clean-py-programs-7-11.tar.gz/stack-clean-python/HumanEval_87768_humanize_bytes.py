def humanize_bytes(
    """ Return a human friendly byte representation.
     
     Modified from: https://stackoverflow.com/questions/1094841/10949331094933
     
     Args:
     num: Raw bytes
     suffix: String to append
     si_prefix: Use 1000 instead of 1024 as divisor
     round_digits: Number of decimal places to round
     
     Returns: Human-readable string representation of bytes
     """
	### Canonical solution below ###    num: float, suffix: str = "B", si_prefix: bool = False, round_digits: int = 2
) -> str:
    
    div = 1000.0 if si_prefix else 1024.0
    unit_suffix = "i" if si_prefix else ""
    for unit in ["", "k", "M", "G", "T", "P", "E", "Z"]:
        if abs(num) < div:
            return f"{num:3.{round_digits}f} {unit}{unit_suffix}{suffix}"
        num /= div
    return f"{num:3.{round_digits}f} Y{unit_suffix}{suffix}"

### Unit tests below ###
def check(candidate):
	assert candidate(100) == "100.00 B"
	assert candidate(0) == "0.00 B"
	assert candidate(1) == "1.00 B"
	assert candidate(1023) == "1023.00 B"
def test_check():
	check(humanize_bytes)
