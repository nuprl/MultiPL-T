def get_output_type(operation):
  """
  Find the name of the output type of the specified operation. This method first explores
  the responseMessages defined for the operation. If a successful responseMessage (i.e.
  response code in 200's range), has been declared with a responseModel, that will be
  considered output type of the operation. Otherwise, it will fallback to the 'type'
  attribute defined in the operation. If neither is defined, returns None.

  Args:
    operation - A Swagger operation description (dictionary)

  Returns:
    A string representing a data type name or None
  """
    ### Canonical solution below ###
  if operation.get('responseMessages'):
    for rm in operation['responseMessages']:
      if 200 <= rm['code'] < 210 and rm.get('responseModel'):
        return rm['responseModel']
  if operation.get('type'):
    return operation['type']
  return None


### Unit tests below ###
def check(candidate):
	assert candidate({'responseMessages': []}) is None
	assert candidate(
    {
      'type': 'foo'
    }
  ) == 'foo'
	assert candidate({'responseMessages': [{'code': 200,'responseModel': 'Foo'}, {'code': 404,'responseModel': 'Bar'}]}) == 'Foo'
	assert candidate({'responseMessages': [{'code': 200,'responseModel': 'foo'}]}) == 'foo'
	assert candidate({'type': 'TestType'}) == 'TestType'
	assert candidate({'responseMessages': [{'code': 200,'responseModel': 'Foo'}]}) == 'Foo'
	assert candidate({'responseMessages': []}) == None
	assert candidate({'responseMessages': [{'code': 200,'responseModel': 'void'}]}) == 'void'
	assert candidate({}) is None
	assert candidate(
    {'responseMessages': [
        {'code': 200,'responseModel': 'foo'}
    ]}) == 'foo'
	assert candidate(
    {
     'responseMessages': [
        {'code': 200,'responseModel': 'foo'},
        {'code': 400,'responseModel': 'bar'},
      ]
    }
  ) == 'foo'
	assert candidate(
    {'type': 'void','responseMessages': [{'code': 200,'responseModel': 'Foo'}]}) == 'Foo'
	assert candidate({'responseMessages': [{'code': 200}]}) is None
	assert candidate(
  {'type': 'array', 'items': {'$ref': '#/definitions/CustomType'}}) == 'array'
	assert candidate({'type': 'Foo'}) == 'Foo'
	assert candidate({'type': 'void','responseMessages': [{'code': 200,'responseModel': 'void'}]}) == 'void'
	assert candidate({'type': 'foo'}) == 'foo'
	assert candidate({'type': 'test_type'}) == 'test_type'
	assert candidate(
    {'type': 'void','responseMessages': [{'code': 200,'responseModel': 'foo'}, {'code': 201,'responseModel': 'bar'}]}) == 'foo'
	assert candidate(
  {'responseMessages': [{'code': 200,'responseModel': 'output_type'}]}) == 'output_type'
	assert candidate({'type': 'output_type'}) == 'output_type'
	assert candidate(
    {'responseMessages': [
        {'code': 200,'responseModel': 'foo'}
    ], 'type': 'bar'}) == 'foo'
	assert candidate(
    {'responseMessages': [{'code': 200,'responseModel': 'test_response_model'}]}) == 'test_response_model'
	assert candidate({'responseMessages': [{'code': 200}]}) == None
	assert candidate(
    {
    }
  ) == None
	assert candidate({}) == None
	assert candidate(
    {'type': 'void','responseMessages': [{'code': 200,'responseModel': 'foo'}]}) == 'foo'
	assert candidate(
  {'responseMessages': [{'code': 200,'responseModel': 'TestModel'}]}) == 'TestModel'
	assert candidate(
  {'type': 'array', 'items': {'type':'string'}}) == 'array'
def test_check():
	check(get_output_type)
