def decode_vigenere_character(character, key):
    """
    Decode a single character according to the Vigenere cipher.
    Will maintain the case of the ciphertext character
    """
    ### Canonical solution below ###
    a_value = ord('a') if character.islower() else ord('a')
    return chr((ord(character.lower()) - ord(key.lower())) % 26 + a_value)


### Unit tests below ###
def check(candidate):
	assert candidate(
    'd', 'a') == 'd'
	assert candidate(character='z', key='A') == 'z'
	assert candidate(
    't', 'a') == 't'
	assert candidate(character='a', key='i') =='s'
	assert candidate(character='b', key='a') == 'b'
	assert candidate(character='a', key='r') == 'j'
	assert candidate(u'b', u'b') == u'a'
	assert candidate(
    'k', 'a') == 'k'
	assert candidate(character='a', key='j') == 'r'
	assert candidate(
    'r', 'a') == 'r'
	assert candidate(
    'x', 'a') == 'x'
	assert candidate(character='x', key='a') == 'x'
	assert candidate(
    'y', 'a') == 'y'
	assert candidate(
    'B', 'a') == 'b'
	assert candidate(character='a', key='m') == 'o'
	assert candidate(
    'z', 'c') == 'x'
	assert candidate(
    'Z', 'b') == 'y'
	assert candidate(
    'a', 'c') == 'y'
	assert candidate(
    'a', 'b') == 'z', 'Should decode a to z'
	assert candidate(character="z", key="a") == "z"
	assert candidate(
    'C', 'a') == 'c'
	assert candidate(
    'a', 'a') == 'a', 'Single-character decode failed'
	assert candidate(
    'z', 'b') == 'y', 'Should decode z to y'
	assert candidate(character='a', key='l') == 'p'
	assert candidate(character='B', key='b') == 'a'
	assert candidate(
    'c', 'a') == 'c'
	assert candidate(character='a', key='f') == 'v'
	assert candidate(
    'a', 'a') == 'a'
	assert candidate(
    'a', 'b') == 'z'
	assert candidate(character='a', key='p') == 'l'
	assert candidate(u'a', u'b') == u'z'
	assert candidate(
    'h', 'a') == 'h'
	assert candidate(
    'w', 'a') == 'w'
	assert candidate(
    'e', 'a') == 'e'
	assert candidate(
    'i', 'a') == 'i'
	assert candidate(character='a', key='q') == 'k'
	assert candidate(
    'u', 'a') == 'u'
	assert candidate(character='a', key='g') == 'u'
	assert candidate(character='a', key='d') == 'x'
	assert candidate(
    'f', 'a') == 'f'
	assert candidate(
    'a', 'a') == 'a', 'Should decode a to a'
	assert candidate(
    'j', 'a') == 'j'
	assert candidate(character="z", key="B") == "y"
	assert candidate(
    'Z', 'a') == 'z'
	assert candidate(character='z', key='c') == 'x'
	assert candidate(
    'z', 'a') == 'z'
	assert candidate(character='a', key='h') == 't'
	assert candidate(u'b', u'a') == u'b'
	assert candidate(character="a", key="a") == "a"
	assert candidate(
    'b', 'a') == 'b'
	assert candidate(
    'g', 'a') == 'g'
	assert candidate(character='a', key='b') == 'z'
	assert candidate(character='z', key='b') == 'y'
	assert candidate(u'a', u'a') == u'a'
	assert candidate(character='z', key='a') == 'z'
	assert candidate(character='b', key='b') == 'a'
	assert candidate(character='a', key='n') == 'n'
	assert candidate(
    'a', 'a') == 'a', 'failed to decode single character'
	assert candidate(
    'a', 'a') == 'a', "candidate('a', 'a') failed"
	assert candidate(
    'v', 'a') == 'v'
	assert candidate(character='a', key='o') =='m'
	assert candidate(character='a', key='a') == 'a'
	assert candidate(character='a', key='e') == 'w'
	assert candidate(character='a', key='k') == 'q'
	assert candidate(character='a', key='c') == 'y'
	assert candidate(
    'z', 'b') == 'y'
	assert candidate(
    'A', 'a') == 'a'
def test_check():
	check(decode_vigenere_character)
