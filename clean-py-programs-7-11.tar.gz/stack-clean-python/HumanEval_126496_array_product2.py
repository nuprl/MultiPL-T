def array_product2(arr):
    """ 
     :param arr: input array of integers
     :return: product array
     """
	### Canonical solution below ###    

    prod_arr = [1 for _ in range(0, len(arr))]

    for i in range(0, len(arr)):
        for j in range(0, len(arr)):
            if j == i:
                continue
            else:
                prod_arr[i] *= arr[j]

    return prod_arr

### Unit tests below ###
def check(candidate):
	assert candidate(candidate([1])) == [1]
	assert candidate(arr=[1, 2, 3, 4, 5]) == [120, 60, 40, 30, 24]
	assert candidate([1, 2, 3, 4, 5]) == [120, 60, 40, 30, 24]
	assert candidate(candidate([0, 0])) == [0, 0]
	assert candidate( [0, 0, 0] ) == [0, 0, 0]
	assert candidate( [0, 0, 0, 0, 0] ) == [0, 0, 0, 0, 0]
	assert candidate( [] ) == []
	assert candidate([3, 2, 1]) == [2, 3, 6]
	assert candidate(range(1, 6)) == [120, 60, 40, 30, 24]
	assert candidate([1, 2, 3, 4]) == [24, 12, 8, 6]
	assert candidate(candidate([1, 1, 1, 1, 1])) == [1, 1, 1, 1, 1]
	assert candidate( [3, 2, 1] ) == [2, 3, 6]
	assert candidate(arr=[3, 2, 1]) == [2, 3, 6]
	assert candidate([]) == []
	assert candidate( [1, 2, 3, 4, 5] ) == [120, 60, 40, 30, 24]
def test_check():
	check(array_product2)
